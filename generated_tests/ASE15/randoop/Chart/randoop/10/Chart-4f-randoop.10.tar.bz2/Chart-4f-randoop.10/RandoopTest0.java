
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity(var0, var1, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setInsets(var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    java.awt.Stroke var4 = null;
    var3.setRadiusGridlineStroke(var4);
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setNoDataMessageFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("", "October", "", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(var0, var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.CategoryLabelPositions var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.util.List var1 = null;
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var1, var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 0.0f, 100.0f, var4);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-1));
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    double var2 = var1.getFixedDimension();
    java.awt.Paint var3 = var1.getTickMarkPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var6 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var1, "October", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    double var2 = var1.getFixedDimension();
    java.awt.Paint var3 = var1.getTickMarkPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var4 = new org.jfree.chart.title.LegendGraphic(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays((-1), var1);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-1), 100, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Stroke var4 = var3.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var3.zoomRangeAxes((-1.0d), var6, var7);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    java.awt.Stroke var4 = var3.getAngleGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var1 = var0.getLabelFont();
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addCategoryLabelToolTip(var2, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var14 = var4.getDomainCrosshairPaint();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var4.drawBackground(var15, var16);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(var0, 0, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     var10.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var20 = var10.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.axis.AxisState var22 = var0.draw(var2, 1.0d, var4, var5, var20, var21);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var16 = var4.getQuadrantPaint(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     var10.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var20 = var10.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.axis.AxisState var22 = var0.draw(var2, 10.0d, var4, var5, var20, var21);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    java.awt.Stroke var11 = null;
    var10.setRadiusGridlineStroke(var11);
    var6.setParent((org.jfree.chart.plot.Plot)var10);
    var6.setRangeZeroBaselineVisible(false);
    java.awt.Paint var16 = var6.getRangeGridlinePaint();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var22, var23, var24);
    java.awt.Stroke var26 = null;
    var25.setRadiusGridlineStroke(var26);
    var21.setParent((org.jfree.chart.plot.Plot)var25);
    var21.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var31 = var21.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.PolarItemRenderer var39 = null;
    org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot(var37, var38, var39);
    java.awt.Stroke var41 = null;
    var40.setRadiusGridlineStroke(var41);
    var36.setParent((org.jfree.chart.plot.Plot)var40);
    var36.setRangeZeroBaselineVisible(false);
    java.awt.Paint var46 = var36.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
    java.awt.Stroke var56 = null;
    var55.setRadiusGridlineStroke(var56);
    var51.setParent((org.jfree.chart.plot.Plot)var55);
    var51.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var61 = var51.getRangeCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var63 = new org.jfree.chart.plot.IntervalMarker(100.0d, 1.0d, var16, var31, var46, var61, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    org.jfree.data.Range var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setDefaultAutoRange(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var0);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var21 = null;
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot(var19, var20, var21);
//     java.awt.Stroke var23 = null;
//     var22.setRadiusGridlineStroke(var23);
//     var18.setParent((org.jfree.chart.plot.Plot)var22);
//     var18.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var28 = var18.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = var32.getAngleGridlineStroke();
//     var18.setRangeZeroBaselineStroke(var33);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     var18.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var36, true);
//     boolean var39 = var36.isMinorTickMarksVisible();
//     int var40 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var36);
//     
//     // Checks the contract:  equals-hashcode on var8 and var22
//     assertTrue("Contract failed: equals-hashcode on var8 and var22", var8.equals(var22) ? var8.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var8
//     assertTrue("Contract failed: equals-hashcode on var22 and var8", var22.equals(var8) ? var22.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     var4.setDomainCrosshairLockedOnData(false);
//     java.util.List var17 = null;
//     var4.mapDatasetToRangeAxes(0, var17);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.AxisLocation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 1.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 0.05d, 1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((java.lang.Number)(-1.0d), (java.lang.Number)100);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var0 = new org.jfree.chart.renderer.category.GradientBarPainter();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var2 = null;
//     java.awt.geom.RectangularShape var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     var0.paintBarShadow(var1, var2, (-1), 4, true, var6, var7, true);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    var4.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance(var0);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var4.handleClick(10, 15, var16);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    org.jfree.data.Range var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setRangeWithMargins(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Font var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setLabelFont(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieToolTipGenerator var3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var8.zoomRangeAxes(100.0d, 0.0d, var15, var16);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 1.0d, var2);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.LineUtilities.clipLine(var0, var1);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getEndY(4, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.awt.Paint var2 = var0.getTickMarkPaint();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     var10.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var20 = var10.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     var10.setRangeAxis((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.util.RectangleEdge var24 = var10.getDomainAxisEdge(31);
//     double var25 = var0.getCategoryStart(0, 10, var5, var24);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", var1, var2);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    java.util.List var27 = null;
    var4.drawRangeTickBands(var25, var26, var27);
    org.jfree.chart.axis.AxisLocation var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation(var29, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     org.jfree.chart.plot.PlotState var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     var4.draw(var15, var16, var17, var18, var19);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var4 = var0.getSeriesPaint(31);
//     boolean var5 = var0.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var9 = var0.getURLGenerator(10, 31, true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = null;
//     var19.setRadiusGridlineStroke(var20);
//     var15.setParent((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.axis.AxisSpace var23 = null;
//     var15.setFixedDomainAxisSpace(var23, false);
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     var15.setFixedRangeAxisSpace(var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
//     java.awt.Stroke var37 = null;
//     var36.setRadiusGridlineStroke(var37);
//     var32.setParent((org.jfree.chart.plot.Plot)var36);
//     var32.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var42 = var32.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var45 = null;
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var43, var44, var45);
//     java.awt.Stroke var47 = var46.getAngleGridlineStroke();
//     var32.setRangeZeroBaselineStroke(var47);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     var32.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var50, true);
//     java.awt.geom.Rectangle2D var53 = null;
//     var0.fillDomainGridBand(var10, var15, (org.jfree.chart.axis.ValueAxis)var50, var53, 100.0d, 0.05d);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.awt.Shape var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    java.awt.Stroke var20 = var19.getAngleGridlineStroke();
    var5.setRangeZeroBaselineStroke(var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
    boolean var26 = var23.isMinorTickMarksVisible();
    java.awt.Font var27 = var23.getTickLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var23, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    double var2 = var1.getUpperMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var5 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var1, "October", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var4.drawBackground(var15, var16);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    float var6 = var1.getMinorTickMarkOutsideLength();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(0.05d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var4.setInsets(var25);
//     org.jfree.chart.renderer.xy.XYStepRenderer var27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var27.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var35, var36, var37);
//     java.awt.Stroke var39 = null;
//     var38.setRadiusGridlineStroke(var39);
//     var34.setParent((org.jfree.chart.plot.Plot)var38);
//     var34.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var44 = var34.getDomainCrosshairPaint();
//     var27.setBaseFillPaint(var44);
//     var4.setRangeZeroBaselinePaint(var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var38
//     assertTrue("Contract failed: equals-hashcode on var8 and var38", var8.equals(var38) ? var8.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var8
//     assertTrue("Contract failed: equals-hashcode on var38 and var8", var38.equals(var8) ? var38.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, (-1.0f), (-1.0f), var4);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    var22.setUpperMargin(0.05d);
    org.jfree.chart.axis.NumberTickUnit var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setTickUnit(var27, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    java.awt.Shape var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var15 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var9, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    boolean var25 = var22.isMinorTickMarksVisible();
    java.awt.Font var26 = var22.getTickLabelFont();
    float var27 = var22.getTickMarkOutsideLength();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setRange(100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.getStartYValue(4, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 1);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = null;
//     var20.setRadiusGridlineStroke(var21);
//     var16.setParent((org.jfree.chart.plot.Plot)var20);
//     var16.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var26 = var16.getDomainCrosshairPaint();
//     var8.setAngleGridlinePaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(var0, (-1), 0.05d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    java.lang.String var5 = var4.toString();
    double var7 = var4.calculateTopOutset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"+ "'", var5.equals("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RangeType.FULL", var1, 0.0f, 1.0f, var4);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.awt.Shape var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    java.awt.Paint var15 = var5.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var16 = new org.jfree.chart.title.LegendGraphic(var0, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     var4.configureDomainAxes();
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var25 = null;
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var23, var24, var25);
//     java.awt.Stroke var27 = null;
//     var26.setRadiusGridlineStroke(var27);
//     var22.setParent((org.jfree.chart.plot.Plot)var26);
//     var22.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var32 = var22.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
//     java.awt.Stroke var37 = var36.getAngleGridlineStroke();
//     var22.setRangeZeroBaselineStroke(var37);
//     var4.setRangeGridlineStroke(var37);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.renderer.RendererUtilities var0 = new org.jfree.chart.renderer.RendererUtilities();

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    java.awt.Paint var9 = var0.getItemOutlinePaint(10, 1, false);
    org.jfree.chart.plot.DrawingSupplier var10 = var0.getDrawingSupplier();
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.util.List var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var6 = var5.getPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var0.getCategoryMiddle((java.lang.Comparable)"hi!", var2, var3, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.plot.DrawingSupplier var4 = null;
    var3.setDrawingSupplier(var4, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var3.clone();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var4.setInsets(var25);
    org.jfree.chart.plot.SeriesRenderingOrder var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSeriesRenderingOrder(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    java.text.DateFormat var6 = var1.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var1, 0, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var1.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
//     java.awt.Stroke var13 = null;
//     var12.setRadiusGridlineStroke(var13);
//     var8.setParent((org.jfree.chart.plot.Plot)var12);
//     var8.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var18 = var8.getDomainCrosshairPaint();
//     var1.setBaseFillPaint(var18);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Font var22 = var21.getLabelFont();
//     var1.setLegendTextFont(0, var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var38 = var28.getRangeGridlinePaint();
//     org.jfree.chart.text.TextMeasurer var40 = null;
//     org.jfree.chart.text.TextBlock var41 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var38, (-1.0f), var40);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var32
//     assertTrue("Contract failed: equals-hashcode on var12 and var32", var12.equals(var32) ? var12.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var12
//     assertTrue("Contract failed: equals-hashcode on var32 and var12", var32.equals(var12) ? var32.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0f), 2.0f, var4, 0.05d, (-1.0f), 1.0f);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isNotify();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     java.awt.Stroke var18 = var10.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var24 = var10.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var21, var22, true);
//     org.jfree.chart.util.Layer var25 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var21, var25);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var18 = var17.getFixedDimension();
//     java.awt.Paint var19 = var17.getTickMarkPaint();
//     var15.setLabelPaint(var19);
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var19};
//     org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var22.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     var29.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var39 = var29.getDomainCrosshairPaint();
//     var22.setBaseFillPaint(var39);
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var39};
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     java.awt.Stroke var46 = var45.getAngleGridlineStroke();
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var55 = null;
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot(var53, var54, var55);
//     java.awt.Stroke var57 = null;
//     var56.setRadiusGridlineStroke(var57);
//     var52.setParent((org.jfree.chart.plot.Plot)var56);
//     var52.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var62 = var52.getRangeCrosshairStroke();
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Shape var64 = null;
//     java.awt.Shape[] var65 = new java.awt.Shape[] { var64};
//     org.jfree.chart.plot.DefaultDrawingSupplier var66 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var41, var47, var63, var65);
//     
//     // Checks the contract:  equals-hashcode on var29 and var52
//     assertTrue("Contract failed: equals-hashcode on var29 and var52", var29.equals(var52) ? var29.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var29
//     assertTrue("Contract failed: equals-hashcode on var52 and var29", var52.equals(var29) ? var52.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var56
//     assertTrue("Contract failed: equals-hashcode on var8 and var56", var8.equals(var56) ? var8.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var56
//     assertTrue("Contract failed: equals-hashcode on var33 and var56", var33.equals(var56) ? var33.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var8
//     assertTrue("Contract failed: equals-hashcode on var56 and var8", var56.equals(var8) ? var56.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var33
//     assertTrue("Contract failed: equals-hashcode on var56 and var33", var56.equals(var33) ? var56.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    java.lang.String var5 = var4.toString();
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var4.createInsetRectangle(var6, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"+ "'", var5.equals("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.KeyedValues var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var1.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
    java.awt.Stroke var13 = null;
    var12.setRadiusGridlineStroke(var13);
    var8.setParent((org.jfree.chart.plot.Plot)var12);
    var8.setRangeZeroBaselineVisible(false);
    java.awt.Paint var18 = var8.getDomainCrosshairPaint();
    var1.setBaseFillPaint(var18);
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var22 = var21.getLabelFont();
    var1.setLegendTextFont(0, var22);
    org.jfree.chart.renderer.xy.XYStepRenderer var24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var24.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
    java.awt.Stroke var36 = null;
    var35.setRadiusGridlineStroke(var36);
    var31.setParent((org.jfree.chart.plot.Plot)var35);
    var31.setRangeZeroBaselineVisible(false);
    java.awt.Paint var41 = var31.getDomainCrosshairPaint();
    var24.setBaseFillPaint(var41);
    org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var45 = var44.getPosition();
    org.jfree.chart.util.HorizontalAlignment var46 = null;
    org.jfree.chart.util.VerticalAlignment var47 = null;
    org.jfree.chart.util.RectangleInsets var52 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    java.lang.String var53 = var52.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var22, var41, var45, var46, var47, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"+ "'", var53.equals("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RangeType.FULL", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 1.0d, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    java.util.Date var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumDate(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     boolean var21 = var4.isNotify();
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var4.rendererChanged(var22);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    java.lang.Object var5 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var1.getSeries((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     java.util.List var2 = null;
//     org.jfree.data.Range var4 = var1.getDomainBounds(var2, false);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     java.awt.Paint var20 = var19.getPaint();
//     var4.setRangeZeroBaselinePaint(var20);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var38 = var28.getRangeCrosshairStroke();
//     var23.setOutlineStroke(var38);
//     org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     java.lang.String var45 = var44.toString();
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder(var20, var38, var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var32
//     assertTrue("Contract failed: equals-hashcode on var8 and var32", var8.equals(var32) ? var8.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var8
//     assertTrue("Contract failed: equals-hashcode on var32 and var8", var32.equals(var8) ? var32.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getFixedDimension();
    int var2 = var0.getCategoryLabelPositionOffset();
    java.awt.Paint var4 = null;
    var0.setTickLabelPaint((java.lang.Comparable)1L, var4);
    var0.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Paint var14 = var4.getRangeGridlinePaint();
    int var15 = var4.getBackgroundImageAlignment();
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainCrosshairPaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    java.text.NumberFormat var1 = null;
    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    java.lang.Object var5 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var1.getSurroundingItems(1, 10L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var5.setFixedDomainAxisSpace(var13, false);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var5.setFixedRangeAxisSpace(var16);
    boolean var18 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var5.getRangeMarkers(1, var20);
    org.jfree.chart.axis.AxisLocation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setDomainAxisLocation((-1), var23, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 2.0f, (-1.0f), var4, 0.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var21, var22, var23);
//     java.awt.Stroke var25 = null;
//     var24.setRadiusGridlineStroke(var25);
//     var20.setParent((org.jfree.chart.plot.Plot)var24);
//     java.awt.Stroke var28 = var20.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var34 = var20.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var31, var32, true);
//     org.jfree.chart.util.Layer var35 = null;
//     boolean var36 = var4.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var31, var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var20
//     assertTrue("Contract failed: equals-hashcode on var4 and var20", var4.equals(var20) ? var4.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var4
//     assertTrue("Contract failed: equals-hashcode on var20 and var4", var20.equals(var4) ? var20.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var24
//     assertTrue("Contract failed: equals-hashcode on var8 and var24", var8.equals(var24) ? var8.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var8
//     assertTrue("Contract failed: equals-hashcode on var24 and var8", var24.equals(var8) ? var24.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     int var12 = var8.getSeriesCount();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     java.awt.Stroke var22 = null;
//     var21.setRadiusGridlineStroke(var22);
//     var17.setParent((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var17.setFixedDomainAxisSpace(var25, false);
//     var17.setDomainMinorGridlinesVisible(false);
//     boolean var30 = var8.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    java.lang.Object var10 = var3.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((java.lang.Number)100L, (java.lang.Number)Double.NaN);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    var4.setRangeCrosshairLockedOnData(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Paint var20 = var19.getPaint();
    var4.setRangeZeroBaselinePaint(var20);
    float var22 = var4.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0f);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, 10.0f, var4, 1.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getMiddleMillisecond(var1);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(0, var1);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var0, var1, var2);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.util.GradientPaintTransformer var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setGradientTransformer(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(100.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0, var1, var2);
    org.jfree.chart.JFreeChart var4 = null;
    var3.setChart(var4);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
    int var6 = var4.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getUpperMargin();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var7 = var6.getPosition();
//     double var8 = var0.getCategoryEnd(0, 1, var4, var7);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getEndX((-1), 31);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    org.jfree.chart.axis.NumberTickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     boolean var21 = var4.isNotify();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var22, var23, var24);
//     java.awt.Stroke var26 = null;
//     var25.setRadiusGridlineStroke(var26);
//     org.jfree.chart.plot.PlotOrientation var28 = var25.getOrientation();
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var30 = var29.getFixedDimension();
//     java.awt.Paint var31 = var29.getTickMarkPaint();
//     boolean var32 = var28.equals((java.lang.Object)var31);
//     var4.setOrientation(var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     java.awt.Image var0 = null;
//     java.io.ObjectOutputStream var1 = null;
//     org.jfree.chart.util.SerialUtilities.writeImage(var0, var1);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var4 = new org.jfree.chart.renderer.xy.XYItemRendererState(var3);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    java.awt.Stroke var15 = null;
    var14.setRadiusGridlineStroke(var15);
    var10.setParent((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.renderer.xy.XYStepRenderer var18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var18.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Font var24 = var18.getItemLabelFont(0, 0, false);
    var10.setNoDataMessageFont(var24);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var31, var32, var33);
    java.awt.Stroke var35 = null;
    var34.setRadiusGridlineStroke(var35);
    var30.setParent((org.jfree.chart.plot.Plot)var34);
    var30.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var40 = var30.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.PolarItemRenderer var43 = null;
    org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot(var41, var42, var43);
    java.awt.Stroke var45 = var44.getAngleGridlineStroke();
    var30.setRangeZeroBaselineStroke(var45);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
    var30.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var48, true);
    boolean var51 = var48.isMinorTickMarksVisible();
    java.awt.Font var52 = var48.getTickLabelFont();
    boolean var53 = var48.isInverted();
    var48.setAutoRangeIncludesZero(false);
    org.jfree.chart.ui.Library var60 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis();
    boolean var62 = var60.equals((java.lang.Object)var61);
    var61.resizeRange2((-1.0d), 10.0d);
    org.jfree.data.time.TimeSeries var66 = null;
    org.jfree.data.time.TimeSeriesCollection var67 = new org.jfree.data.time.TimeSeriesCollection(var66);
    org.jfree.data.Range var68 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var67);
    org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var67, true);
    java.lang.Object var71 = var67.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.drawItem(var2, var4, var5, var10, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.axis.ValueAxis)var61, (org.jfree.data.xy.XYDataset)var67, 10, 0, false, 10);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    org.jfree.data.xy.XYSeries var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addSeries(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     boolean var25 = var22.isMinorTickMarksVisible();
//     java.awt.Shape var26 = var22.getRightArrow();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
//     java.awt.Stroke var37 = null;
//     var36.setRadiusGridlineStroke(var37);
//     var32.setParent((org.jfree.chart.plot.Plot)var36);
//     var32.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var42 = var32.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var45 = null;
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var43, var44, var45);
//     java.awt.Stroke var47 = var46.getAngleGridlineStroke();
//     var32.setRangeZeroBaselineStroke(var47);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     var32.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var50, true);
//     boolean var53 = var50.isMinorTickMarksVisible();
//     java.awt.Font var54 = var50.getTickLabelFont();
//     boolean var55 = var50.isInverted();
//     var50.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var58 = null;
//     org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot(var27, (org.jfree.chart.axis.ValueAxis)var50, var58);
//     org.jfree.chart.entity.AxisEntity var62 = new org.jfree.chart.entity.AxisEntity(var26, (org.jfree.chart.axis.Axis)var50, "org.jfree.chart.event.ChartChangeEvent[source=0]", "hi!");
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var36
//     assertTrue("Contract failed: equals-hashcode on var8 and var36", var8.equals(var36) ? var8.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var46
//     assertTrue("Contract failed: equals-hashcode on var18 and var46", var18.equals(var46) ? var18.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var8
//     assertTrue("Contract failed: equals-hashcode on var36 and var8", var36.equals(var8) ? var36.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var18
//     assertTrue("Contract failed: equals-hashcode on var46 and var18", var46.equals(var18) ? var46.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Stroke var4 = null;
//     var3.setRadiusGridlineStroke(var4);
//     org.jfree.chart.plot.PlotOrientation var6 = var3.getOrientation();
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var8 = var7.getFixedDimension();
//     java.awt.Paint var9 = var7.getTickMarkPaint();
//     boolean var10 = var6.equals((java.lang.Object)var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     org.jfree.chart.plot.PlotOrientation var17 = var14.getOrientation();
//     boolean var18 = var6.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var3
//     assertTrue("Contract failed: equals-hashcode on var14 and var3", var14.equals(var3) ? var14.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     java.awt.Stroke var22 = null;
//     var21.setRadiusGridlineStroke(var22);
//     var17.setParent((org.jfree.chart.plot.Plot)var21);
//     var17.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var27 = var17.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
//     java.awt.Stroke var32 = var31.getAngleGridlineStroke();
//     var17.setRangeZeroBaselineStroke(var32);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var17.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var35, true);
//     boolean var38 = var35.isMinorTickMarksVisible();
//     java.awt.Font var39 = var35.getTickLabelFont();
//     boolean var40 = var35.isInverted();
//     int var41 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = var20.getAngleGridlineStroke();
//     var6.setRangeZeroBaselineStroke(var21);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var27 = var24.isMinorTickMarksVisible();
//     java.awt.Font var28 = var24.getTickLabelFont();
//     boolean var29 = var24.isInverted();
//     var24.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var42 = null;
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var40, var41, var42);
//     java.awt.Stroke var44 = null;
//     var43.setRadiusGridlineStroke(var44);
//     var39.setParent((org.jfree.chart.plot.Plot)var43);
//     var39.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var49 = var39.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     var39.setRangeAxis((org.jfree.chart.axis.ValueAxis)var50);
//     org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var53 = var52.getFixedDimension();
//     java.awt.Paint var54 = var52.getTickMarkPaint();
//     var50.setLabelPaint(var54);
//     org.jfree.chart.text.TextMeasurer var58 = null;
//     org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, var54, 0.0f, 31, var58);
//     
//     // Checks the contract:  equals-hashcode on var10 and var43
//     assertTrue("Contract failed: equals-hashcode on var10 and var43", var10.equals(var43) ? var10.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var10
//     assertTrue("Contract failed: equals-hashcode on var43 and var10", var43.equals(var10) ? var43.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    java.awt.Shape var6 = null;
    var0.setBaseLegendShape(var6);
    var0.setBaseCreateEntities(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    boolean var4 = var0.isAutoWidth();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getEndY((-1), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("October", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "RangeType.FULL", "RangeType.FULL");

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("October");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var4 = var0.getSeriesOutlinePaint(31);
//     var0.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     var0.setPlot(var12);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
//     java.awt.Stroke var32 = null;
//     var31.setRadiusGridlineStroke(var32);
//     var27.setParent((org.jfree.chart.plot.Plot)var31);
//     org.jfree.chart.renderer.xy.XYStepRenderer var35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var35.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Font var41 = var35.getItemLabelFont(0, 0, false);
//     var27.setNoDataMessageFont(var41);
//     var0.setBaseLegendTextFont(var41);
//     
//     // Checks the contract:  equals-hashcode on var16 and var31
//     assertTrue("Contract failed: equals-hashcode on var16 and var31", var16.equals(var31) ? var16.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var16
//     assertTrue("Contract failed: equals-hashcode on var31 and var16", var31.equals(var16) ? var31.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.getStartXValue(0, 31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesOutlinePaint(31);
    java.awt.Font var5 = var0.getBaseLegendTextFont();
    boolean var9 = var0.isItemLabelVisible((-1), 4, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("RangeType.FULL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getFixedDimension();
    int var2 = var0.getCategoryLabelPositionOffset();
    java.awt.Paint var4 = null;
    var0.setTickLabelPaint((java.lang.Comparable)1L, var4);
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var0.setTickLabelInsets(var10);
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var17 = var16.getPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var0.getCategoryMiddle(4, 1, var14, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    float var6 = var1.getMinorTickMarkOutsideLength();
    var1.zoomRange(Double.NaN, 10.0d);
    org.jfree.data.Range var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("{0}: ({1}, {2})", var1);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var4.setFixedRangeAxisSpace(var15);
    org.jfree.chart.plot.SeriesRenderingOrder var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSeriesRenderingOrder(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.plot.PieLabelRecord var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addPieLabelRecord(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = var1.getTickUnit();
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var3, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     boolean var28 = var23.isInverted();
//     var23.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var23, var31);
//     java.awt.Font var33 = var32.getNoDataMessageFont();
//     double var34 = var32.getMaxRadius();
//     java.awt.Graphics2D var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var48 = null;
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot(var46, var47, var48);
//     java.awt.Stroke var50 = null;
//     var49.setRadiusGridlineStroke(var50);
//     var45.setParent((org.jfree.chart.plot.Plot)var49);
//     var45.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var55 = var45.getRangeAxisEdge();
//     var45.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleAnchor var62 = null;
//     java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var62);
//     var45.zoomDomainAxes(0.0d, (-1.0d), var60, var63);
//     var37.zoomDomainAxes(100.0d, Double.NaN, var40, var63);
//     org.jfree.chart.plot.PlotState var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     var32.draw(var35, var36, var63, var66, var67);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 15, var2);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    org.jfree.data.xy.XYDataItem var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var11 = var3.addOrUpdate(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var20, var21, var22);
//     java.awt.Stroke var24 = null;
//     var23.setRadiusGridlineStroke(var24);
//     var19.setParent((org.jfree.chart.plot.Plot)var23);
//     var19.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var29 = var19.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = var33.getAngleGridlineStroke();
//     var19.setRangeZeroBaselineStroke(var34);
//     var4.setOutlineStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isNotify();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     int var18 = var14.getSeriesCount();
//     var4.setParent((org.jfree.chart.plot.Plot)var14);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(var0, 1);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelToolTipGenerator();
    var1.setLabelLinkMargin(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var1 = var0.isDrawBarOutline();
    boolean var2 = var0.getBaseSeriesVisibleInLegend();
    var0.setSeriesVisible(0, (java.lang.Boolean)false, false);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(4, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Apr"+ "'", var2.equals("Apr"));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var4 = var3.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var5 = var3.getLabelOffset();
//     var1.setLabelOffset(var5);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    boolean var4 = var0.isAutoWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset)var0, 1, 0.2d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    java.awt.Stroke var20 = var19.getAngleGridlineStroke();
    var5.setRangeZeroBaselineStroke(var20);
    org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var5.setInsets(var26);
    double var29 = var26.calculateRightOutset((-1.0d));
    var0.setLabelInsets(var26);
    org.jfree.chart.axis.NumberTickUnit var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 100.0d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.chart.event.RendererChangeEvent var15 = null;
//     var4.rendererChanged(var15);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
    java.awt.Stroke var12 = null;
    var11.setRadiusGridlineStroke(var12);
    var7.setParent((org.jfree.chart.plot.Plot)var11);
    var7.setRangeZeroBaselineVisible(false);
    java.awt.Paint var17 = var7.getDomainCrosshairPaint();
    var0.setBaseFillPaint(var17);
    org.jfree.chart.labels.XYItemLabelGenerator var19 = null;
    var0.setBaseItemLabelGenerator(var19, false);
    org.jfree.chart.labels.XYItemLabelGenerator var23 = null;
    var0.setSeriesItemLabelGenerator(4, var23);
    boolean var25 = var0.getUseFillPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var29.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var33 = var29.getSeriesPaint(31);
    boolean var34 = var29.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var38 = var29.getURLGenerator(10, 31, true);
    var29.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var41 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var41.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var41.setLegendShape(100, var47);
    var29.setBaseLegendShape(var47);
    var28.setLegendArea(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-16777216), var47, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    var4.setRangeCrosshairLockedOnData(true);
    var4.configureDomainAxes();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.data.xy.XYSeries var22 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var25 = var22.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var28 = var22.addOrUpdate(0.0d, 0.05d);
    java.util.List var29 = var22.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setSubtitles(var29);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    java.lang.String var5 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"+ "'", var5.equals("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]"));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "", "{0}: ({1}, {2})");

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    java.awt.Stroke var20 = var19.getAngleGridlineStroke();
    var5.setRangeZeroBaselineStroke(var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
    boolean var26 = var23.isMinorTickMarksVisible();
    java.awt.Font var27 = var23.getTickLabelFont();
    boolean var28 = var23.isInverted();
    var23.setMinorTickMarksVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var23, var31);
    float var33 = var23.getMinorTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0f);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
    var1.setVisible(false);
    var1.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    java.awt.Paint var9 = var0.getItemOutlinePaint(10, 1, false);
    org.jfree.chart.plot.DrawingSupplier var10 = var0.getDrawingSupplier();
    org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var13 = var12.isDrawBarOutline();
    boolean var14 = var12.getBaseSeriesVisibleInLegend();
    boolean var15 = var12.getShadowsVisible();
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
    var16.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
    java.awt.Stroke var33 = null;
    var32.setRadiusGridlineStroke(var33);
    var28.setParent((org.jfree.chart.plot.Plot)var32);
    var28.setRangeZeroBaselineVisible(false);
    var16.setPlot(var28);
    org.jfree.chart.labels.ItemLabelPosition var40 = var16.getSeriesPositiveItemLabelPosition(0);
    var12.setNegativeItemLabelPositionFallback(var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-16777216), var40, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    java.lang.Object var10 = var3.clone();
    var3.setKey((java.lang.Comparable)'#');
    var3.add(Double.NaN, (java.lang.Number)31);
    org.jfree.data.xy.XYDataItem var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.add(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    var4.setRangeCrosshairLockedOnData(true);
    var4.configureDomainAxes();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
//     java.awt.Color var22 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
//     boolean var26 = var25.isShapeFilled();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var29 = var28.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getLabelOffset();
//     org.jfree.chart.renderer.xy.XYStepRenderer var31 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var31.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var35 = var31.getSeriesOutlinePaint(31);
//     var31.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var46 = null;
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot(var44, var45, var46);
//     java.awt.Stroke var48 = null;
//     var47.setRadiusGridlineStroke(var48);
//     var43.setParent((org.jfree.chart.plot.Plot)var47);
//     var43.setRangeZeroBaselineVisible(false);
//     var31.setPlot(var43);
//     org.jfree.chart.labels.ItemLabelPosition var55 = var31.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var56 = var55.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var57 = var55.getTextAnchor();
//     var28.setLabelTextAnchor(var57);
//     java.awt.Paint var59 = var28.getOutlinePaint();
//     var25.setOutlinePaint(var59);
//     
//     // Checks the contract:  equals-hashcode on var9 and var47
//     assertTrue("Contract failed: equals-hashcode on var9 and var47", var9.equals(var47) ? var9.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var9
//     assertTrue("Contract failed: equals-hashcode on var47 and var9", var47.equals(var9) ? var47.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
//     java.awt.Stroke var13 = null;
//     var12.setRadiusGridlineStroke(var13);
//     var8.setParent((org.jfree.chart.plot.Plot)var12);
//     var8.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var18 = var8.getRangeAxisEdge();
//     double var19 = var1.java2DToValue(100.0d, var3, var18);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    float var6 = var1.getMinorTickMarkOutsideLength();
    var1.zoomRange(Double.NaN, 10.0d);
    var1.setNegativeArrowVisible(true);
    java.util.Date var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinimumDate(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var1.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var5 = var1.getSeriesPaint(31);
    boolean var6 = var1.getDrawSeriesLineAsPath();
    java.awt.Paint var10 = var1.getItemOutlinePaint(10, 1, false);
    org.jfree.chart.plot.DrawingSupplier var11 = var1.getDrawingSupplier();
    org.jfree.chart.renderer.xy.XYStepRenderer var13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var13.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var21, var22, var23);
    java.awt.Stroke var25 = null;
    var24.setRadiusGridlineStroke(var25);
    var20.setParent((org.jfree.chart.plot.Plot)var24);
    var20.setRangeZeroBaselineVisible(false);
    java.awt.Paint var30 = var20.getDomainCrosshairPaint();
    var13.setBaseFillPaint(var30);
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var34 = var33.getLabelFont();
    var13.setLegendTextFont(0, var34);
    var1.setLegendTextFont(10, var34);
    java.awt.Paint var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var34, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     java.util.List var27 = null;
//     var4.drawRangeTickBands(var25, var26, var27);
//     var4.setRangeCrosshairValue((-1.0d));
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var33 = var32.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var34 = var32.getLabelOffset();
//     org.jfree.chart.renderer.xy.XYStepRenderer var35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var35.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var39 = var35.getSeriesOutlinePaint(31);
//     var35.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var50 = null;
//     org.jfree.chart.plot.PolarPlot var51 = new org.jfree.chart.plot.PolarPlot(var48, var49, var50);
//     java.awt.Stroke var52 = null;
//     var51.setRadiusGridlineStroke(var52);
//     var47.setParent((org.jfree.chart.plot.Plot)var51);
//     var47.setRangeZeroBaselineVisible(false);
//     var35.setPlot(var47);
//     org.jfree.chart.labels.ItemLabelPosition var59 = var35.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var60 = var59.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var61 = var59.getTextAnchor();
//     var32.setLabelTextAnchor(var61);
//     java.awt.Paint var63 = var32.getOutlinePaint();
//     var4.setOutlinePaint(var63);
//     
//     // Checks the contract:  equals-hashcode on var8 and var51
//     assertTrue("Contract failed: equals-hashcode on var8 and var51", var8.equals(var51) ? var8.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var8
//     assertTrue("Contract failed: equals-hashcode on var51 and var8", var51.equals(var8) ? var51.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.util.RectangleEdge var18 = var4.getDomainAxisEdge(31);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var24, var25, var26);
    java.awt.Stroke var28 = null;
    var27.setRadiusGridlineStroke(var28);
    var23.setParent((org.jfree.chart.plot.Plot)var27);
    java.awt.Stroke var31 = var23.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var35 = null;
    boolean var37 = var23.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var34, var35, true);
    org.jfree.chart.util.Layer var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((org.jfree.chart.plot.Marker)var34, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    java.awt.Stroke var11 = null;
    var10.setRadiusGridlineStroke(var11);
    var6.setParent((org.jfree.chart.plot.Plot)var10);
    var6.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.PolarItemRenderer var19 = null;
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
    java.awt.Stroke var21 = var20.getAngleGridlineStroke();
    var6.setRangeZeroBaselineStroke(var21);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
    boolean var27 = var24.isMinorTickMarksVisible();
    java.awt.Font var28 = var24.getTickLabelFont();
    boolean var29 = var24.isInverted();
    var24.setMinorTickMarksVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
    java.awt.Font var34 = var33.getNoDataMessageFont();
    java.awt.Paint var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("{0}: ({1}, {2})", var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var1 = var0.isDrawBarOutline();
    boolean var2 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Font var4 = null;
    var0.setSeriesItemLabelFont(4, var4, true);
    org.jfree.chart.labels.StandardXYToolTipGenerator var8 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var0.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.XYToolTipGenerator)var8);
    java.lang.String var10 = var8.getFormatString();
    java.text.NumberFormat var11 = var8.getYFormat();
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var12, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var8.generateToolTip((org.jfree.data.xy.XYDataset)var12, 31, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "{0}: ({1}, {2})"+ "'", var10.equals("{0}: ({1}, {2})"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = var1.getTickUnit();
//     java.util.Date var3 = null;
//     java.util.TimeZone var4 = null;
//     java.util.Date var5 = var2.rollDate(var3, var4);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.axis.MarkerAxisBand var17 = null;
    var15.setMarkerBand(var17);
    java.awt.Shape var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setUpArrow(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimeSeries var3 = var1.getSeries((java.lang.Comparable)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var1.getSurroundingItems(100, 100L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var3.getY((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     java.util.List var27 = null;
//     var4.drawRangeTickBands(var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     org.jfree.chart.plot.PlotOrientation var35 = var32.getOrientation();
//     org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var37 = var36.getFixedDimension();
//     java.awt.Paint var38 = var36.getTickMarkPaint();
//     boolean var39 = var35.equals((java.lang.Object)var38);
//     var4.setDomainZeroBaselinePaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var8 and var32
//     assertTrue("Contract failed: equals-hashcode on var8 and var32", var8.equals(var32) ? var8.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var8
//     assertTrue("Contract failed: equals-hashcode on var32 and var8", var32.equals(var8) ? var32.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var4 = var0.getSeriesPaint(31);
//     boolean var8 = var0.getItemCreateEntity(10, (-1), true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = null;
//     var18.setRadiusGridlineStroke(var19);
//     var14.setParent((org.jfree.chart.plot.Plot)var18);
//     var14.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var24 = var14.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var25, var26, var27);
//     java.awt.Stroke var29 = var28.getAngleGridlineStroke();
//     var14.setRangeZeroBaselineStroke(var29);
//     boolean var31 = var14.isNotify();
//     org.jfree.chart.axis.LogAxis var32 = new org.jfree.chart.axis.LogAxis();
//     java.awt.geom.Rectangle2D var33 = null;
//     var0.drawDomainGridLine(var9, var14, (org.jfree.chart.axis.ValueAxis)var32, var33, 10.0d);
//     var32.setSmallestValue(1.0d);
//     java.text.NumberFormat var38 = var32.getNumberFormatOverride();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var43 = var42.getPosition();
//     double var44 = var32.exponentLengthToJava2D(0.2d, var40, var43);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var2.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var6 = var2.getSeriesPaint(31);
//     boolean var7 = var2.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var14.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var14.setLegendShape(100, var20);
//     var2.setBaseLegendShape(var20);
//     var1.setLegendArea(var20);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
//     var28.setRangeCrosshairLockedOnData(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
//     var42.setNotify(false);
//     java.awt.RenderingHints var48 = null;
//     var42.setRenderingHints(var48);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var3.setLabelInsets(var8);
    var1.setInsets(var8, false);
    java.awt.Paint var12 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = var1.getTickUnit();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelToolTipGenerator();
    org.jfree.chart.plot.AbstractPieLabelDistributor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
    var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
    boolean var27 = var1.equals((java.lang.Object)var12);
    java.awt.Paint var28 = var1.getPaint();
    org.jfree.chart.util.RectangleInsets var29 = var1.getPadding();
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2, true, false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var12 = var11.getPosition();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.axis.AxisState var14 = var1.draw(var6, 1.05d, var8, var9, var12, var13);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)10L);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.util.TimeZone var0 = null;
    java.util.Locale var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.RenderingHints var19 = null;
//     var18.setRenderingHints(var19);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var2.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var6 = var2.getSeriesPaint(31);
    boolean var7 = var2.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var14.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var14.setLegendShape(100, var20);
    var2.setBaseLegendShape(var20);
    var1.setLegendArea(var20);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
    java.awt.Stroke var33 = null;
    var32.setRadiusGridlineStroke(var33);
    var28.setParent((org.jfree.chart.plot.Plot)var32);
    var28.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
    var28.setRangeCrosshairLockedOnData(true);
    var28.configureDomainAxes();
    org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
    org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
    org.jfree.chart.util.RectangleAnchor var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, var46, Double.NaN, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
    var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
    org.jfree.chart.labels.XYSeriesLabelGenerator var23 = null;
    var16.setLegendItemURLGenerator(var23);
    org.jfree.chart.annotations.XYAnnotation var25 = null;
    org.jfree.chart.util.Layer var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addAnnotation(var25, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var16 = null;
//     boolean var18 = var4.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var15, var16, true);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
//     var20.setVisible(false);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     var29.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var39 = var29.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var42 = null;
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var40, var41, var42);
//     java.awt.Stroke var44 = var43.getAngleGridlineStroke();
//     var29.setRangeZeroBaselineStroke(var44);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
//     var29.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var47, true);
//     boolean var50 = var47.isMinorTickMarksVisible();
//     java.awt.Font var51 = var47.getTickLabelFont();
//     boolean var52 = var47.isInverted();
//     var47.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var55 = null;
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot(var24, (org.jfree.chart.axis.ValueAxis)var47, var55);
//     java.awt.Font var57 = var56.getNoDataMessageFont();
//     var20.setFont(var57);
//     var15.setLabelFont(var57);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)10.0f);
    var1.add(0.0d, 0.0d);
    java.lang.Comparable var5 = var1.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    double var3 = var1.getMinimumArcAngleToDraw();
    org.jfree.chart.urls.PieURLGenerator var4 = var1.getURLGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = null;
    var1.setLabelGenerator(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(var0, var1);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getFirstMillisecond();
//     double[] var3 = null;
//     double[][] var4 = new double[][] { var3};
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.addSeries((java.lang.Comparable)var1, var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
//     java.awt.Stroke var12 = null;
//     var11.setRadiusGridlineStroke(var12);
//     var7.setParent((org.jfree.chart.plot.Plot)var11);
//     var7.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var17 = var7.getDomainCrosshairPaint();
//     var0.setBaseFillPaint(var17);
//     org.jfree.chart.labels.XYItemLabelGenerator var19 = null;
//     var0.setBaseItemLabelGenerator(var19, false);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
//     java.awt.Stroke var31 = null;
//     var30.setRadiusGridlineStroke(var31);
//     var26.setParent((org.jfree.chart.plot.Plot)var30);
//     int var34 = var30.getSeriesCount();
//     boolean var35 = var30.isRangeZoomable();
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var30);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var30
//     assertTrue("Contract failed: equals-hashcode on var11 and var30", var11.equals(var30) ? var11.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var11
//     assertTrue("Contract failed: equals-hashcode on var30 and var11", var30.equals(var11) ? var30.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)2.0f, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var0.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var4 = var0.getSeriesOutlinePaint(31);
//     var0.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     var0.setPlot(var12);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var39, var40, var41);
//     java.awt.Stroke var43 = var42.getAngleGridlineStroke();
//     var28.setRangeZeroBaselineStroke(var43);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     var28.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var46, true);
//     var28.setBackgroundImageAlignment(100);
//     java.awt.Paint var51 = var28.getDomainZeroBaselinePaint();
//     var0.setSeriesFillPaint(0, var51);
//     
//     // Checks the contract:  equals-hashcode on var16 and var32
//     assertTrue("Contract failed: equals-hashcode on var16 and var32", var16.equals(var32) ? var16.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var16
//     assertTrue("Contract failed: equals-hashcode on var32 and var16", var32.equals(var16) ? var32.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var4 = var3.getLabelOffsetType();
//     var1.setLabelOffsetType(var4);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     var0.clear();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.05d, 0.0d);
//     org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = null;
//     org.jfree.chart.util.Size2D var10 = var0.arrange(var7, var8, var9);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2, true, false);
    float var6 = var1.getMinorTickMarkOutsideLength();
    var1.zoomRange(Double.NaN, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(0.025d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var0.setLabelInsets(var5);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var5.createInsetRectangle(var7, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var26, var27, var28);
//     java.awt.Stroke var30 = null;
//     var29.setRadiusGridlineStroke(var30);
//     var25.setParent((org.jfree.chart.plot.Plot)var29);
//     var25.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var35 = var25.getRangeAxisEdge();
//     var25.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleAnchor var42 = null;
//     java.awt.geom.Point2D var43 = org.jfree.chart.util.RectangleAnchor.coordinates(var41, var42);
//     var25.zoomDomainAxes(0.0d, (-1.0d), var40, var43);
//     var17.zoomDomainAxes(100.0d, Double.NaN, var20, var43);
//     var4.zoomDomainAxes(100.0d, var16, var43, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     boolean var25 = var22.isMinorTickMarksVisible();
//     java.awt.Shape var26 = var22.getRightArrow();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     java.awt.Stroke var36 = null;
//     var35.setRadiusGridlineStroke(var36);
//     var31.setParent((org.jfree.chart.plot.Plot)var35);
//     var31.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var41 = var31.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     var31.setRangeAxis((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.util.RectangleEdge var45 = var31.getDomainAxisEdge(31);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var31.getDomainMarkers(var46);
//     org.jfree.chart.entity.PlotEntity var48 = new org.jfree.chart.entity.PlotEntity(var26, (org.jfree.chart.plot.Plot)var31);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var1);
    java.awt.Shape var4 = var0.getSeriesShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     boolean var1 = var0.isAutoRange();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
//     java.awt.Stroke var13 = null;
//     var12.setRadiusGridlineStroke(var13);
//     var8.setParent((org.jfree.chart.plot.Plot)var12);
//     var8.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var18 = var8.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var8.setRangeAxis((org.jfree.chart.axis.ValueAxis)var19);
//     org.jfree.chart.util.RectangleEdge var22 = var8.getDomainAxisEdge(31);
//     double var23 = var0.valueToJava2D(0.05d, var3, var22);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    java.awt.Stroke var11 = null;
    var10.setRadiusGridlineStroke(var11);
    var6.setParent((org.jfree.chart.plot.Plot)var10);
    var6.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var16 = var6.getRangeCrosshairStroke();
    boolean var17 = var6.isOutlineVisible();
    var0.add(var6, 100);
    org.jfree.chart.plot.XYPlot var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var3.setLabelInsets(var8);
    var1.setInsets(var8, false);
    org.jfree.chart.plot.PieLabelLinkStyle var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStyle(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.chart.event.ChartChangeEvent[source=0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
    var22.setUpperMargin(0.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setRange(0.05d, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesOutlinePaint(31);
    var0.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    var0.setPlot(var12);
    org.jfree.chart.labels.XYSeriesLabelGenerator var23 = var0.getLegendItemToolTipGenerator();
    boolean var24 = var0.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
//     org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight((-1.0d));
//     org.jfree.chart.util.Size2D var12 = var4.arrange(var5, var6, var11);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = var20.getAngleGridlineStroke();
//     var6.setRangeZeroBaselineStroke(var21);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var27 = var24.isMinorTickMarksVisible();
//     java.awt.Font var28 = var24.getTickLabelFont();
//     boolean var29 = var24.isInverted();
//     var24.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var42 = null;
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var40, var41, var42);
//     java.awt.Stroke var44 = null;
//     var43.setRadiusGridlineStroke(var44);
//     var39.setParent((org.jfree.chart.plot.Plot)var43);
//     var39.setRangeZeroBaselineVisible(false);
//     var39.setDomainCrosshairLockedOnData(false);
//     java.awt.Color var53 = java.awt.Color.getColor("October", 15);
//     var39.setDomainMinorGridlinePaint((java.awt.Paint)var53);
//     org.jfree.chart.text.TextMeasurer var57 = null;
//     org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var34, (java.awt.Paint)var53, 10.0f, 31, var57);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var23, var24, var25);
    java.awt.Stroke var27 = null;
    var26.setRadiusGridlineStroke(var27);
    var22.setParent((org.jfree.chart.plot.Plot)var26);
    java.awt.Stroke var30 = var22.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var34 = null;
    boolean var36 = var22.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var33, var34, true);
    org.jfree.chart.util.Layer var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(10, (org.jfree.chart.plot.Marker)var33, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    var4.configureRangeAxes();
    org.jfree.chart.annotations.XYAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var4.removeAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var2, var3, var4);
    java.awt.Stroke var6 = null;
    var5.setRadiusGridlineStroke(var6);
    org.jfree.chart.plot.PlotOrientation var8 = var5.getOrientation();
    boolean var9 = var1.equals((java.lang.Object)var5);
    boolean var10 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)(byte)1);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Image var1 = org.jfree.chart.util.SerialUtilities.readImage(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     var4.clearRangeAxes();
//     org.jfree.chart.plot.DrawingSupplier var22 = var4.getDrawingSupplier();
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
//     java.awt.Stroke var32 = null;
//     var31.setRadiusGridlineStroke(var32);
//     var27.setParent((org.jfree.chart.plot.Plot)var31);
//     var27.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var37 = var27.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
//     java.awt.Stroke var42 = var41.getAngleGridlineStroke();
//     var27.setRangeZeroBaselineStroke(var42);
//     org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var27.setInsets(var48);
//     double var51 = var48.calculateRightOutset((-1.0d));
//     var4.setInsets(var48);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var41
//     assertTrue("Contract failed: equals-hashcode on var18 and var41", var18.equals(var41) ? var18.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var18
//     assertTrue("Contract failed: equals-hashcode on var41 and var18", var41.equals(var18) ? var41.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.plot.PlotOrientation var15 = var4.getOrientation();
    org.jfree.chart.plot.DatasetRenderingOrder var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDatasetRenderingOrder(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    boolean var2 = var1.isVisible();
    var1.setMargin(100.0d, 0.025d, (-1.0d), 0.025d);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
    boolean var13 = var4.isDomainGridlinesVisible();
    org.jfree.chart.annotations.XYAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var4.removeAnnotation(var14, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    org.jfree.data.time.TimeSeries var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addSeries(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    boolean var6 = var4.equals((java.lang.Object)var5);
    var5.resizeRange2((-1.0d), 10.0d);
    double var10 = var5.getFixedAutoRange();
    org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var5.setLabelInsets(var15, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var4 = var2.getPieLabelRecord(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var16 = var6.getRangeCrosshairStroke();
//     boolean var17 = var6.isOutlineVisible();
//     var0.add(var6, 100);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
//     java.awt.Stroke var31 = null;
//     var30.setRadiusGridlineStroke(var31);
//     var26.setParent((org.jfree.chart.plot.Plot)var30);
//     var26.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var36 = var26.getRangeCrosshairStroke();
//     var21.setOutlineStroke(var36);
//     var0.setDomainGridlineStroke(var36);
//     
//     // Checks the contract:  equals-hashcode on var10 and var30
//     assertTrue("Contract failed: equals-hashcode on var10 and var30", var10.equals(var30) ? var10.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var10
//     assertTrue("Contract failed: equals-hashcode on var30 and var10", var30.equals(var10) ? var30.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    java.lang.Object var10 = var3.clone();
    var3.setKey((java.lang.Comparable)'#');
    java.lang.Number var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var14 = var3.remove(var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var9 = var0.getURLGenerator(10, 31, true);
    var0.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Stroke var13 = var0.getSeriesOutlineStroke(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var7 = var6.getPosition();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.axis.AxisState var9 = var0.draw(var1, 0.025d, var3, var4, var7, var8);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var2 = var1.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
//     org.jfree.chart.renderer.xy.XYStepRenderer var4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var4.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var8 = var4.getSeriesOutlinePaint(31);
//     var4.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = null;
//     var20.setRadiusGridlineStroke(var21);
//     var16.setParent((org.jfree.chart.plot.Plot)var20);
//     var16.setRangeZeroBaselineVisible(false);
//     var4.setPlot(var16);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var4.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var29 = var28.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var30 = var28.getTextAnchor();
//     var1.setLabelTextAnchor(var30);
//     org.jfree.data.general.DatasetGroup var32 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
//     java.awt.Stroke var42 = null;
//     var41.setRadiusGridlineStroke(var42);
//     var37.setParent((org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var37.setFixedDomainAxisSpace(var45, false);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var37.setFixedRangeAxisSpace(var48);
//     boolean var50 = var32.equals((java.lang.Object)var37);
//     java.awt.Paint var51 = var37.getOutlinePaint();
//     var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var37);
//     
//     // Checks the contract:  equals-hashcode on var16 and var37
//     assertTrue("Contract failed: equals-hashcode on var16 and var37", var16.equals(var37) ? var16.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var16
//     assertTrue("Contract failed: equals-hashcode on var37 and var16", var37.equals(var16) ? var37.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var41
//     assertTrue("Contract failed: equals-hashcode on var20 and var41", var20.equals(var41) ? var20.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var20
//     assertTrue("Contract failed: equals-hashcode on var41 and var20", var41.equals(var20) ? var41.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}: ({1}, {2})", var1, var2);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(true);
    double[] var4 = null;
    double[][] var5 = new double[][] { var4};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var1, (java.lang.Comparable[])var3, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.util.RectangleEdge var18 = var4.getDomainAxisEdge(31);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var26 = null;
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var24, var25, var26);
//     java.awt.Stroke var28 = null;
//     var27.setRadiusGridlineStroke(var28);
//     var23.setParent((org.jfree.chart.plot.Plot)var27);
//     var23.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var33 = var23.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var34, var35, var36);
//     java.awt.Stroke var38 = var37.getAngleGridlineStroke();
//     var23.setRangeZeroBaselineStroke(var38);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     var23.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var41, true);
//     boolean var44 = var41.isMinorTickMarksVisible();
//     java.awt.Font var45 = var41.getTickLabelFont();
//     float var46 = var41.getTickMarkOutsideLength();
//     double var47 = var41.getUpperBound();
//     org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var41};
//     var4.setDomainAxes(var48);
//     
//     // Checks the contract:  equals-hashcode on var8 and var27
//     assertTrue("Contract failed: equals-hashcode on var8 and var27", var8.equals(var27) ? var8.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var8
//     assertTrue("Contract failed: equals-hashcode on var27 and var8", var27.equals(var8) ? var27.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(4, var1);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Apr", var1);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.xy.XYSeries var6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
//     org.jfree.data.xy.XYDataItem var9 = var6.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
//     org.jfree.data.xy.XYDataItem var12 = var6.addOrUpdate(0.0d, 0.05d);
//     java.util.List var13 = var6.getItems();
//     org.jfree.data.Range var15 = var1.getDomainBounds(var13, true);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var5.setFixedDomainAxisSpace(var13, false);
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var5.setFixedRangeAxisSpace(var16);
//     boolean var18 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var5.getRangeMarkers(1, var20);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     var29.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var39 = var29.getRangeAxisEdge();
//     var29.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleAnchor var46 = null;
//     java.awt.geom.Point2D var47 = org.jfree.chart.util.RectangleAnchor.coordinates(var45, var46);
//     var29.zoomDomainAxes(0.0d, (-1.0d), var44, var47);
//     var5.zoomRangeAxes(0.0d, 0.0d, var24, var47);
//     
//     // Checks the contract:  equals-hashcode on var5 and var29
//     assertTrue("Contract failed: equals-hashcode on var5 and var29", var5.equals(var29) ? var5.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var5
//     assertTrue("Contract failed: equals-hashcode on var29 and var5", var29.equals(var5) ? var29.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var16 = null;
//     boolean var18 = var4.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var15, var16, true);
//     java.awt.Color var21 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     var4.setDomainZeroBaselinePaint((java.awt.Paint)var21);
//     var4.clearRangeMarkers((-1));
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var29 = var28.getLabelOffsetType();
//     java.awt.Font var30 = var28.getLabelFont();
//     org.jfree.chart.util.Layer var31 = null;
//     var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var28, var31, true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var28
//     assertTrue("Contract failed: equals-hashcode on var15 and var28", var15.equals(var28) ? var15.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var15
//     assertTrue("Contract failed: equals-hashcode on var28 and var15", var28.equals(var15) ? var28.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getYValue(4, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     java.awt.Stroke var22 = null;
//     var21.setRadiusGridlineStroke(var22);
//     var17.setParent((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var17.setFixedDomainAxisSpace(var25, false);
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var17.setFixedRangeAxisSpace(var28);
//     org.jfree.chart.axis.AxisLocation var31 = var17.getRangeAxisLocation((-16777216));
//     var4.setRangeAxisLocation(var31);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    java.awt.Paint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainMinorGridlinePaint(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var3.setLabelInsets(var8);
    var1.setInsets(var8, false);
    org.jfree.chart.util.RectangleInsets var12 = var1.getSimpleLabelOffset();
    var1.setIgnoreZeroValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.renderer.xy.XYStepRenderer var13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var13.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Font var19 = var13.getItemLabelFont(0, 0, false);
//     var5.setNoDataMessageFont(var19);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
//     java.awt.Stroke var31 = null;
//     var30.setRadiusGridlineStroke(var31);
//     var26.setParent((org.jfree.chart.plot.Plot)var30);
//     java.awt.Stroke var34 = var26.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var40 = var26.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var37, var38, true);
//     java.awt.Color var43 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var44 = var43.getColorSpace();
//     var26.setDomainZeroBaselinePaint((java.awt.Paint)var43);
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var43);
//     org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("", var19, (java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var9 and var30
//     assertTrue("Contract failed: equals-hashcode on var9 and var30", var9.equals(var30) ? var9.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var9
//     assertTrue("Contract failed: equals-hashcode on var30 and var9", var30.equals(var9) ? var30.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    var0.setBaseLinesVisible(true);
    boolean var10 = var0.getItemLineVisible(0, 0);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseFillPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.plot.PlotOrientation var15 = var4.getOrientation();
    java.lang.String var16 = var15.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var16.equals("PlotOrientation.VERTICAL"));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var2.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var6 = var2.getSeriesPaint(31);
    boolean var7 = var2.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var14.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var14.setLegendShape(100, var20);
    var2.setBaseLegendShape(var20);
    var1.setLegendArea(var20);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var26 = new org.jfree.chart.renderer.xy.XYItemRendererState(var25);
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
    java.awt.Stroke var37 = null;
    var36.setRadiusGridlineStroke(var37);
    var32.setParent((org.jfree.chart.plot.Plot)var36);
    var32.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var42 = var32.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    var32.setRangeAxis((org.jfree.chart.axis.ValueAxis)var43);
    org.jfree.chart.util.RectangleEdge var46 = var32.getDomainAxisEdge(31);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
    java.awt.Stroke var56 = null;
    var55.setRadiusGridlineStroke(var56);
    var51.setParent((org.jfree.chart.plot.Plot)var55);
    var51.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var61 = var51.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.PolarItemRenderer var64 = null;
    org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
    java.awt.Stroke var66 = var65.getAngleGridlineStroke();
    var51.setRangeZeroBaselineStroke(var66);
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
    var51.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var69, true);
    org.jfree.chart.axis.LogAxis var72 = new org.jfree.chart.axis.LogAxis();
    double var73 = var72.getUpperBound();
    org.jfree.data.time.TimeSeries var74 = null;
    org.jfree.data.time.TimeSeriesCollection var75 = new org.jfree.data.time.TimeSeriesCollection(var74);
    org.jfree.data.Range var76 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var75);
    org.jfree.data.Range var78 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var75, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.drawItem(var24, var26, var27, var32, (org.jfree.chart.axis.ValueAxis)var69, (org.jfree.chart.axis.ValueAxis)var72, (org.jfree.data.xy.XYDataset)var75, (-16777216), 0, false, 100);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    double var2 = var0.getIntervalWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getEndYValue(0, 31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
    var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
    org.jfree.chart.labels.XYSeriesLabelGenerator var23 = null;
    var16.setLegendItemURLGenerator(var23);
    boolean var25 = var16.getAutoPopulateSeriesPaint();
    java.awt.Paint var27 = var16.getSeriesOutlinePaint(2);
    boolean var28 = var16.getDrawOutlines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    double var1 = var0.getHeight();
    java.lang.String var2 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var2.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimeSeries var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.indexOf(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     boolean var25 = var22.isMinorTickMarksVisible();
//     java.awt.Font var26 = var22.getTickLabelFont();
//     float var27 = var22.getTickMarkOutsideLength();
//     double var28 = var22.getUpperBound();
//     org.jfree.chart.util.ObjectList var29 = new org.jfree.chart.util.ObjectList();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     org.jfree.chart.plot.PlotOrientation var36 = var33.getOrientation();
//     boolean var37 = var29.equals((java.lang.Object)var33);
//     boolean var38 = var33.isAngleGridlinesVisible();
//     var22.setPlot((org.jfree.chart.plot.Plot)var33);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.xy.XYStepRenderer var5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var5.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var9 = var5.getSeriesOutlinePaint(31);
//     var5.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     java.awt.Stroke var22 = null;
//     var21.setRadiusGridlineStroke(var22);
//     var17.setParent((org.jfree.chart.plot.Plot)var21);
//     var17.setRangeZeroBaselineVisible(false);
//     var5.setPlot(var17);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var5.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var30 = var29.getRotationAnchor();
//     var1.draw(var2, 1.0f, (-1.0f), var30, 2.0f, 10.0f, 0.0d);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
    var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
    boolean var23 = var4.isDomainCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.data.xy.XYSeries var4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var7 = var4.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var10 = var4.addOrUpdate(0.0d, 0.05d);
    java.lang.Object var11 = var4.clone();
    var4.setKey((java.lang.Comparable)'#');
    var4.add(Double.NaN, (java.lang.Number)31);
    org.jfree.data.xy.XYSeries var20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var23 = var20.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var26 = var20.addOrUpdate(0.0d, 0.05d);
    org.jfree.data.xy.XYDataItem var29 = var20.addOrUpdate(0.0d, Double.NaN);
    org.jfree.data.xy.XYDataItem var30 = var4.addOrUpdate(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)var30, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, (org.jfree.data.Range)var1);
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var4 = org.jfree.data.Range.combine(var0, (org.jfree.data.Range)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = org.jfree.data.Range.scale(var4, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset)var0, 15, 1.05d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     var4.setBackgroundAlpha(1.0f);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.data.xy.XYSeries var21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
//     org.jfree.data.xy.XYDataItem var24 = var21.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
//     org.jfree.data.xy.XYDataItem var27 = var21.addOrUpdate(0.0d, 0.05d);
//     java.util.List var28 = var21.getItems();
//     var4.drawDomainTickBands(var16, var17, var28);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var36, var37, var38);
//     java.awt.Stroke var40 = null;
//     var39.setRadiusGridlineStroke(var40);
//     var35.setParent((org.jfree.chart.plot.Plot)var39);
//     java.awt.Stroke var43 = var35.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var47 = null;
//     boolean var49 = var35.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var46, var47, true);
//     org.jfree.chart.util.Layer var50 = null;
//     boolean var51 = var4.removeDomainMarker(100, (org.jfree.chart.plot.Marker)var46, var50);
//     
//     // Checks the contract:  equals-hashcode on var4 and var35
//     assertTrue("Contract failed: equals-hashcode on var4 and var35", var4.equals(var35) ? var4.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var4
//     assertTrue("Contract failed: equals-hashcode on var35 and var4", var35.equals(var4) ? var35.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var39
//     assertTrue("Contract failed: equals-hashcode on var8 and var39", var8.equals(var39) ? var8.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var8
//     assertTrue("Contract failed: equals-hashcode on var39 and var8", var39.equals(var8) ? var39.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    var5.setRangeCrosshairLockedOnData(true);
    var5.configureDomainAxes();
    boolean var19 = var5.isDomainMinorGridlinesVisible();
    boolean var20 = var0.equals((java.lang.Object)var19);
    org.jfree.chart.util.HorizontalAlignment var21 = null;
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, 1.05d, 0.0d);
    org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var25);
    var26.clear();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.block.RectangleConstraint var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var30 = var0.arrange(var26, var28, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    java.awt.Shape var1 = var0.getBaseShape();
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 0.0d, 1.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(var0, 0.025d, 0.025d, 2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseFillPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var1 = var0.isDrawBarOutline();
    boolean var2 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Font var4 = null;
    var0.setSeriesItemLabelFont(4, var4, true);
    org.jfree.chart.labels.StandardXYToolTipGenerator var8 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var0.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.XYToolTipGenerator)var8);
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 31);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     var4.setBackgroundImageAlignment(100);
//     var4.setDomainCrosshairValue(1.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var36, var37, var38);
//     java.awt.Stroke var40 = null;
//     var39.setRadiusGridlineStroke(var40);
//     var35.setParent((org.jfree.chart.plot.Plot)var39);
//     var35.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var45 = var35.getRangeAxisEdge();
//     var35.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleAnchor var52 = null;
//     java.awt.geom.Point2D var53 = org.jfree.chart.util.RectangleAnchor.coordinates(var51, var52);
//     var35.zoomDomainAxes(0.0d, (-1.0d), var50, var53);
//     var4.zoomRangeAxes(1.05d, var30, var53, true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var39
//     assertTrue("Contract failed: equals-hashcode on var8 and var39", var8.equals(var39) ? var8.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var8
//     assertTrue("Contract failed: equals-hashcode on var39 and var8", var39.equals(var8) ? var39.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 1.0d, 1.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     boolean var3 = var2.isDrawBarOutline();
//     boolean var4 = var2.getBaseSeriesVisibleInLegend();
//     java.awt.Font var6 = null;
//     var2.setSeriesItemLabelFont(4, var6, true);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var10 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//     var2.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.XYToolTipGenerator)var10);
//     boolean var12 = var2.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var18 = var17.getPosition();
//     var17.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var24 = var17.getPosition();
//     java.awt.geom.Rectangle2D var25 = var17.getBounds();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var33 = null;
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var31, var32, var33);
//     java.awt.Stroke var35 = null;
//     var34.setRadiusGridlineStroke(var35);
//     var30.setParent((org.jfree.chart.plot.Plot)var34);
//     var30.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var40 = var30.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var41);
//     org.jfree.chart.util.RectangleEdge var44 = var30.getDomainAxisEdge(31);
//     var0.paintBar(var1, var2, 15, 10, true, (java.awt.geom.RectangularShape)var25, var44);
// 
//   }

//  public void test316() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December 2014", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
    var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
    boolean var27 = var1.equals((java.lang.Object)var12);
    boolean var28 = var1.getExpandToFitSpace();
    org.jfree.chart.renderer.xy.XYStepRenderer var29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var29.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var33 = var29.getSeriesPaint(31);
    boolean var34 = var29.getDrawSeriesLineAsPath();
    java.awt.Paint var38 = var29.getItemOutlinePaint(10, 1, false);
    var1.setBackgroundPaint(var38);
    org.jfree.chart.util.RectangleInsets var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPadding(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RangeType.FULL");

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     int var2 = var0.getSeriesCount();
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis();
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     boolean var5 = var4.isDrawBarOutline();
//     org.jfree.chart.renderer.xy.XYStepRenderer var7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var7.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var11 = var7.getSeriesPaint(31);
//     boolean var12 = var7.getDrawSeriesLineAsPath();
//     java.awt.Paint var16 = var7.getItemOutlinePaint(10, 1, false);
//     var4.setSeriesOutlinePaint(31, var16);
//     boolean var18 = var3.equals((java.lang.Object)31);
//     var3.setMinorTickCount((-1));
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var26, var27, var28);
//     java.awt.Stroke var30 = null;
//     var29.setRadiusGridlineStroke(var30);
//     var25.setParent((org.jfree.chart.plot.Plot)var29);
//     var25.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var35 = var25.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var36, var37, var38);
//     java.awt.Stroke var40 = var39.getAngleGridlineStroke();
//     var25.setRangeZeroBaselineStroke(var40);
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
//     var25.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var43, true);
//     boolean var46 = var43.isMinorTickMarksVisible();
//     java.awt.Shape var47 = var43.getRightArrow();
//     var3.setRightArrow(var47);
//     boolean var49 = var0.equals((java.lang.Object)var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var39
//     assertTrue("Contract failed: equals-hashcode on var0 and var39", var0.equals(var39) ? var0.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("{0}: ({1}, {2})", var1);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var16.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
    var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.renderer.xy.XYStepRenderer var24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var24.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var28 = var24.getSeriesPaint(31);
    org.jfree.chart.labels.ItemLabelPosition var29 = var24.getBaseNegativeItemLabelPosition();
    var23.setBaseNegativeItemLabelPosition(var29);
    var4.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setSeriesItemLabelsVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeSeries(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.data.time.TimeSeries var3 = var1.getSeries((java.lang.Comparable)(-1));
//     org.jfree.data.xy.XYSeries var7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
//     org.jfree.data.xy.XYDataItem var10 = var7.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
//     org.jfree.data.xy.XYDataItem var13 = var7.addOrUpdate(0.0d, 0.05d);
//     java.util.List var14 = var7.getItems();
//     org.jfree.data.Range var16 = var1.getDomainBounds(var14, true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var1.getItemCount(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
//     java.awt.Color var22 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
//     java.lang.Object var26 = var25.clone();
//     java.awt.Shape var27 = var25.getShape();
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var29 = null;
//     org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var28, var29);
//     org.jfree.chart.block.RectangleConstraint var32 = var30.toFixedHeight((-1.0d));
//     org.jfree.chart.renderer.xy.XYAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var35.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var39 = var35.getSeriesPaint(31);
//     boolean var40 = var35.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var44 = var35.getURLGenerator(10, 31, true);
//     var35.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var47 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var47.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var47.setLegendShape(100, var53);
//     var35.setBaseLegendShape(var53);
//     var34.setLegendArea(var53);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var64 = null;
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
//     java.awt.Stroke var66 = null;
//     var65.setRadiusGridlineStroke(var66);
//     var61.setParent((org.jfree.chart.plot.Plot)var65);
//     var61.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var71 = var61.getRangeAxisEdge();
//     var61.setRangeCrosshairLockedOnData(true);
//     var61.configureDomainAxes();
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var61);
//     org.jfree.chart.entity.JFreeChartEntity var78 = new org.jfree.chart.entity.JFreeChartEntity(var53, var75, "Apr", "");
//     var75.setNotify(false);
//     org.jfree.chart.event.ChartChangeEvent var81 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var32, var75);
//     org.jfree.chart.entity.JFreeChartEntity var82 = new org.jfree.chart.entity.JFreeChartEntity(var27, var75);
//     
//     // Checks the contract:  equals-hashcode on var9 and var65
//     assertTrue("Contract failed: equals-hashcode on var9 and var65", var9.equals(var65) ? var9.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var9
//     assertTrue("Contract failed: equals-hashcode on var65 and var9", var65.equals(var9) ? var65.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     boolean var28 = var23.isInverted();
//     var23.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var23, var31);
//     java.awt.Font var33 = var32.getNoDataMessageFont();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var36, var37, var38);
//     org.jfree.chart.plot.DrawingSupplier var40 = null;
//     var39.setDrawingSupplier(var40, true);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var46 = var45.getPosition();
//     var45.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var52 = var45.getPosition();
//     java.awt.geom.Rectangle2D var53 = var45.getBounds();
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var65 = null;
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot(var63, var64, var65);
//     java.awt.Stroke var67 = null;
//     var66.setRadiusGridlineStroke(var67);
//     var62.setParent((org.jfree.chart.plot.Plot)var66);
//     var62.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var72 = var62.getRangeAxisEdge();
//     var62.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleAnchor var79 = null;
//     java.awt.geom.Point2D var80 = org.jfree.chart.util.RectangleAnchor.coordinates(var78, var79);
//     var62.zoomDomainAxes(0.0d, (-1.0d), var77, var80);
//     var54.zoomDomainAxes(100.0d, Double.NaN, var57, var80);
//     org.jfree.chart.plot.PlotState var83 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var84 = null;
//     var39.draw(var43, var53, var80, var83, var84);
//     var32.zoomDomainAxes(0.2d, var35, var80);
//     
//     // Checks the contract:  equals-hashcode on var9 and var66
//     assertTrue("Contract failed: equals-hashcode on var9 and var66", var9.equals(var66) ? var9.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var54
//     assertTrue("Contract failed: equals-hashcode on var19 and var54", var19.equals(var54) ? var19.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var19
//     assertTrue("Contract failed: equals-hashcode on var54 and var19", var54.equals(var19) ? var54.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var9
//     assertTrue("Contract failed: equals-hashcode on var66 and var9", var66.equals(var9) ? var66.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var5 = null;
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot(var3, var4, var5);
//     org.jfree.chart.plot.DrawingSupplier var7 = null;
//     var6.setDrawingSupplier(var7, true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var13 = var12.getPosition();
//     var12.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var19 = var12.getPosition();
//     java.awt.geom.Rectangle2D var20 = var12.getBounds();
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     var29.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var39 = var29.getRangeAxisEdge();
//     var29.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleAnchor var46 = null;
//     java.awt.geom.Point2D var47 = org.jfree.chart.util.RectangleAnchor.coordinates(var45, var46);
//     var29.zoomDomainAxes(0.0d, (-1.0d), var44, var47);
//     var21.zoomDomainAxes(100.0d, Double.NaN, var24, var47);
//     org.jfree.chart.plot.PlotState var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     var6.draw(var10, var20, var47, var50, var51);
//     org.jfree.chart.plot.XYPlot var53 = null;
//     org.jfree.data.time.TimeSeries var54 = null;
//     org.jfree.data.time.TimeSeriesCollection var55 = new org.jfree.data.time.TimeSeriesCollection(var54);
//     org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var64 = null;
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
//     java.awt.Stroke var66 = null;
//     var65.setRadiusGridlineStroke(var66);
//     var61.setParent((org.jfree.chart.plot.Plot)var65);
//     var61.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var71 = var61.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot(var72, var73, var74);
//     java.awt.Stroke var76 = var75.getAngleGridlineStroke();
//     var61.setRangeZeroBaselineStroke(var76);
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis();
//     var61.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var79, true);
//     boolean var82 = var79.isMinorTickMarksVisible();
//     java.awt.Font var83 = var79.getTickLabelFont();
//     boolean var84 = var79.isInverted();
//     org.jfree.chart.renderer.PolarItemRenderer var85 = null;
//     org.jfree.chart.plot.PolarPlot var86 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var55, (org.jfree.chart.axis.ValueAxis)var79, var85);
//     org.jfree.chart.plot.PlotRenderingInfo var87 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var88 = var0.initialise(var2, var20, var53, (org.jfree.data.xy.XYDataset)var55, var87);
//     
//     // Checks the contract:  equals-hashcode on var21 and var75
//     assertTrue("Contract failed: equals-hashcode on var21 and var75", var21.equals(var75) ? var21.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var65
//     assertTrue("Contract failed: equals-hashcode on var33 and var65", var33.equals(var65) ? var33.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var33
//     assertTrue("Contract failed: equals-hashcode on var65 and var33", var65.equals(var33) ? var65.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var21
//     assertTrue("Contract failed: equals-hashcode on var75 and var21", var75.equals(var21) ? var75.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var1.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var5 = var1.getSeriesOutlinePaint(31);
    var1.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var14, var15, var16);
    java.awt.Stroke var18 = null;
    var17.setRadiusGridlineStroke(var18);
    var13.setParent((org.jfree.chart.plot.Plot)var17);
    var13.setRangeZeroBaselineVisible(false);
    var1.setPlot(var13);
    org.jfree.chart.labels.ItemLabelPosition var25 = var1.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var26 = var25.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var27 = var25.getTextAnchor();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    org.jfree.chart.util.RectangleInsets var31 = var29.getLabelOffset();
    org.jfree.chart.renderer.xy.XYStepRenderer var32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var32.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var36 = var32.getSeriesOutlinePaint(31);
    var32.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
    org.jfree.data.xy.XYDataset var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.PolarItemRenderer var47 = null;
    org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot(var45, var46, var47);
    java.awt.Stroke var49 = null;
    var48.setRadiusGridlineStroke(var49);
    var44.setParent((org.jfree.chart.plot.Plot)var48);
    var44.setRangeZeroBaselineVisible(false);
    var32.setPlot(var44);
    org.jfree.chart.labels.ItemLabelPosition var56 = var32.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var57 = var56.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var58 = var56.getTextAnchor();
    var29.setLabelTextAnchor(var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var61 = new org.jfree.chart.labels.ItemLabelPosition(var0, var27, var58, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    java.awt.Shape var4 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var5 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     var4.setBackgroundImageAlignment(100);
//     var4.setDomainCrosshairValue(1.0d);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var34, var35, var36);
//     java.awt.Stroke var38 = null;
//     var37.setRadiusGridlineStroke(var38);
//     var33.setParent((org.jfree.chart.plot.Plot)var37);
//     var33.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var43 = var33.getRangeAxisEdge();
//     var33.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var49 = null;
//     boolean var50 = var33.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var48, var49);
//     java.awt.Paint var51 = var48.getPaint();
//     org.jfree.chart.util.Layer var52 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var48, var52);
//     
//     // Checks the contract:  equals-hashcode on var8 and var37
//     assertTrue("Contract failed: equals-hashcode on var8 and var37", var8.equals(var37) ? var8.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var8
//     assertTrue("Contract failed: equals-hashcode on var37 and var8", var37.equals(var8) ? var37.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setBaseCreateEntities(true, true);
    boolean var4 = var0.getAutoPopulateSeriesShape();
    org.jfree.chart.renderer.xy.XYStepRenderer var5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var5.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var9 = var5.getSeriesOutlinePaint(31);
    var5.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
    java.awt.Stroke var22 = null;
    var21.setRadiusGridlineStroke(var22);
    var17.setParent((org.jfree.chart.plot.Plot)var21);
    var17.setRangeZeroBaselineVisible(false);
    var5.setPlot(var17);
    java.awt.Stroke var28 = var17.getRangeGridlineStroke();
    var0.setBaseOutlineStroke(var28);
    boolean var30 = var0.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    java.beans.PropertyChangeListener var4 = null;
    var3.removePropertyChangeListener(var4);
    var3.setDescription("");
    java.lang.Number var9 = null;
    var3.add((java.lang.Number)1L, var9, true);
    org.jfree.data.xy.XYDataItem var14 = var3.addOrUpdate(1.0d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var16 = var3.remove((java.lang.Number)(short)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = var20.getAngleGridlineStroke();
//     var6.setRangeZeroBaselineStroke(var21);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var27 = var24.isMinorTickMarksVisible();
//     java.awt.Font var28 = var24.getTickLabelFont();
//     boolean var29 = var24.isInverted();
//     var24.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=0]", var34);
//     java.awt.Font var36 = var35.getFont();
//     org.jfree.chart.block.BlockFrame var37 = var35.getFrame();
//     org.jfree.data.general.DatasetGroup var38 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var46 = null;
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot(var44, var45, var46);
//     java.awt.Stroke var48 = null;
//     var47.setRadiusGridlineStroke(var48);
//     var43.setParent((org.jfree.chart.plot.Plot)var47);
//     org.jfree.chart.axis.AxisSpace var51 = null;
//     var43.setFixedDomainAxisSpace(var51, false);
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var43.setFixedRangeAxisSpace(var54);
//     boolean var56 = var38.equals((java.lang.Object)var43);
//     java.awt.Paint var57 = var43.getOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepRenderer var58 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var58.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Font var64 = var58.getItemLabelFont(0, 0, false);
//     var43.setNoDataMessageFont(var64);
//     var35.setFont(var64);
//     
//     // Checks the contract:  equals-hashcode on var10 and var47
//     assertTrue("Contract failed: equals-hashcode on var10 and var47", var10.equals(var47) ? var10.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var10
//     assertTrue("Contract failed: equals-hashcode on var47 and var10", var47.equals(var10) ? var47.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setBaseCreateEntities(true, true);
    boolean var4 = var0.getAutoPopulateSeriesShape();
    boolean var5 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    var0.setUseFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth(100.0d);
    org.jfree.data.Range var5 = null;
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, (org.jfree.data.Range)var6);
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var9 = org.jfree.data.Range.combine(var5, (org.jfree.data.Range)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var10 = var2.toRangeHeight(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var16 = null;
//     boolean var18 = var4.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var15, var16, true);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var21 = var20.getLabelOffsetType();
//     var15.setLabelOffsetType(var21);
//     
//     // Checks the contract:  equals-hashcode on var15 and var20
//     assertTrue("Contract failed: equals-hashcode on var15 and var20", var15.equals(var20) ? var15.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var15
//     assertTrue("Contract failed: equals-hashcode on var20 and var15", var20.equals(var15) ? var20.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("WMAP_Plot", var1, 100.0f, 2.0f, 1.05d, 0.0f, 10.0f);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.renderer.xy.XYStepRenderer var12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var12.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var20, var21, var22);
//     java.awt.Stroke var24 = null;
//     var23.setRadiusGridlineStroke(var24);
//     var19.setParent((org.jfree.chart.plot.Plot)var23);
//     var19.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var29 = var19.getDomainCrosshairPaint();
//     var12.setBaseFillPaint(var29);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     java.awt.Paint var33 = var32.getPaint();
//     boolean var34 = org.jfree.chart.util.PaintUtilities.equal(var29, var33);
//     var4.setRangeCrosshairPaint(var29);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     var4.setDomainMinorGridlinesVisible(false);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var20 = var19.getPosition();
//     var19.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var33 = null;
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var31, var32, var33);
//     java.awt.Stroke var35 = null;
//     var34.setRadiusGridlineStroke(var35);
//     var30.setParent((org.jfree.chart.plot.Plot)var34);
//     var30.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var40 = var30.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     var30.setRangeAxis((org.jfree.chart.axis.ValueAxis)var41);
//     org.jfree.chart.util.RectangleEdge var44 = var30.getDomainAxisEdge(31);
//     boolean var45 = var19.equals((java.lang.Object)var30);
//     java.awt.Paint var46 = var19.getPaint();
//     var17.setBorderPaint(var46);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var4.setFixedRangeAxisSpace(var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var20 = var19.getPosition();
//     var19.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var26 = var19.getPosition();
//     java.awt.geom.Rectangle2D var27 = var19.getBounds();
//     var4.drawBackground(var17, var27);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-16777216), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var5 = var2.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     java.awt.Color var30 = java.awt.Color.getColor("October", 15);
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27, (java.awt.Paint)var30);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var39, var40, var41);
//     java.awt.Stroke var43 = null;
//     var42.setRadiusGridlineStroke(var43);
//     var38.setParent((org.jfree.chart.plot.Plot)var42);
//     java.awt.Stroke var46 = var38.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var50 = null;
//     boolean var52 = var38.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var49, var50, true);
//     java.awt.Color var55 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var56 = var55.getColorSpace();
//     var38.setDomainZeroBaselinePaint((java.awt.Paint)var55);
//     org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var55);
//     org.jfree.data.general.Dataset var59 = var58.getDataset();
//     org.jfree.chart.renderer.xy.XYStepRenderer var60 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var60.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Font var66 = var60.getItemLabelFont(0, 0, false);
//     var58.setLabelFont(var66);
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot(var68);
//     java.awt.Paint var70 = var69.getBaseSectionPaint();
//     var31.addLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var66, var70);
//     
//     // Checks the contract:  equals-hashcode on var9 and var42
//     assertTrue("Contract failed: equals-hashcode on var9 and var42", var9.equals(var42) ? var9.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var9
//     assertTrue("Contract failed: equals-hashcode on var42 and var9", var42.equals(var9) ? var42.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var3.setLabelInsets(var8);
    var1.setInsets(var8, false);
    org.jfree.chart.labels.PieSectionLabelGenerator var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendLabelGenerator(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
//     var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
//     boolean var27 = var1.equals((java.lang.Object)var12);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var30.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var34 = var30.getSeriesPaint(31);
//     boolean var35 = var30.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var39 = var30.getURLGenerator(10, 31, true);
//     var30.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var42 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var42.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var42.setLegendShape(100, var48);
//     var30.setBaseLegendShape(var48);
//     var29.setLegendArea(var48);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var59 = null;
//     org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
//     java.awt.Stroke var61 = null;
//     var60.setRadiusGridlineStroke(var61);
//     var56.setParent((org.jfree.chart.plot.Plot)var60);
//     var56.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var66 = var56.getRangeAxisEdge();
//     var56.setRangeCrosshairLockedOnData(true);
//     var56.configureDomainAxes();
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var56);
//     org.jfree.chart.entity.JFreeChartEntity var73 = new org.jfree.chart.entity.JFreeChartEntity(var48, var70, "Apr", "");
//     int var74 = var70.getBackgroundImageAlignment();
//     boolean var75 = var70.getAntiAlias();
//     boolean var76 = var70.isBorderVisible();
//     var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var70);
//     
//     // Checks the contract:  equals-hashcode on var16 and var60
//     assertTrue("Contract failed: equals-hashcode on var16 and var60", var16.equals(var60) ? var16.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var16
//     assertTrue("Contract failed: equals-hashcode on var60 and var16", var60.equals(var16) ? var60.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var14 = var4.getDomainCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var18 = null;
//     var17.plotChanged(var18);
//     int var20 = var17.getDatasetCount();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var25 = null;
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var23, var24, var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = null;
//     var26.setDrawingSupplier(var27, true);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var33 = var32.getPosition();
//     var32.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var39 = var32.getPosition();
//     java.awt.geom.Rectangle2D var40 = var32.getBounds();
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var52 = null;
//     org.jfree.chart.plot.PolarPlot var53 = new org.jfree.chart.plot.PolarPlot(var50, var51, var52);
//     java.awt.Stroke var54 = null;
//     var53.setRadiusGridlineStroke(var54);
//     var49.setParent((org.jfree.chart.plot.Plot)var53);
//     var49.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var59 = var49.getRangeAxisEdge();
//     var49.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     java.awt.geom.Rectangle2D var65 = null;
//     org.jfree.chart.util.RectangleAnchor var66 = null;
//     java.awt.geom.Point2D var67 = org.jfree.chart.util.RectangleAnchor.coordinates(var65, var66);
//     var49.zoomDomainAxes(0.0d, (-1.0d), var64, var67);
//     var41.zoomDomainAxes(100.0d, Double.NaN, var44, var67);
//     org.jfree.chart.plot.PlotState var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var26.draw(var30, var40, var67, var70, var71);
//     var17.panRangeAxes(0.0d, var22, var67);
//     var4.panDomainAxes(1.0d, var16, var67);
//     
//     // Checks the contract:  equals-hashcode on var4 and var49
//     assertTrue("Contract failed: equals-hashcode on var4 and var49", var4.equals(var49) ? var4.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var53
//     assertTrue("Contract failed: equals-hashcode on var8 and var53", var8.equals(var53) ? var8.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var8
//     assertTrue("Contract failed: equals-hashcode on var53 and var8", var53.equals(var8) ? var53.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "February"+ "'", var1.equals("February"));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    java.util.Iterator var2 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     java.awt.Stroke var14 = var6.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var18 = null;
//     boolean var20 = var6.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var17, var18, true);
//     java.awt.Color var23 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var24 = var23.getColorSpace();
//     var6.setDomainZeroBaselinePaint((java.awt.Paint)var23);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var23);
//     java.lang.Object var27 = var26.clone();
//     var0.add(var26);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var35, var36, var37);
//     java.awt.Stroke var39 = null;
//     var38.setRadiusGridlineStroke(var39);
//     var34.setParent((org.jfree.chart.plot.Plot)var38);
//     java.awt.Stroke var42 = var34.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var46 = null;
//     boolean var48 = var34.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var45, var46, true);
//     java.awt.Color var51 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var52 = var51.getColorSpace();
//     var34.setDomainZeroBaselinePaint((java.awt.Paint)var51);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var51);
//     java.lang.Object var55 = var54.clone();
//     var54.setLineVisible(true);
//     var0.add(var54);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var38
//     assertTrue("Contract failed: equals-hashcode on var10 and var38", var10.equals(var38) ? var10.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var10
//     assertTrue("Contract failed: equals-hashcode on var38 and var10", var38.equals(var10) ? var38.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var45
//     assertTrue("Contract failed: equals-hashcode on var17 and var45", var17.equals(var45) ? var17.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var17
//     assertTrue("Contract failed: equals-hashcode on var45 and var17", var45.equals(var17) ? var45.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var55
//     assertTrue("Contract failed: equals-hashcode on var27 and var55", var27.equals(var55) ? var27.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var27
//     assertTrue("Contract failed: equals-hashcode on var55 and var27", var55.equals(var27) ? var55.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getIntegerInstance(var0);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = var1.getTickUnit();
//     var1.setLowerMargin(1.05d);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.AxisState var7 = new org.jfree.chart.axis.AxisState(1.0d);
//     var7.setMax(0.0d);
//     var7.cursorLeft(Double.NaN);
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = null;
//     var16.setDrawingSupplier(var17, true);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var23 = var22.getPosition();
//     var22.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var29 = var22.getPosition();
//     java.awt.geom.Rectangle2D var30 = var22.getBounds();
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var42 = null;
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var40, var41, var42);
//     java.awt.Stroke var44 = null;
//     var43.setRadiusGridlineStroke(var44);
//     var39.setParent((org.jfree.chart.plot.Plot)var43);
//     var39.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var49 = var39.getRangeAxisEdge();
//     var39.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleAnchor var56 = null;
//     java.awt.geom.Point2D var57 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var56);
//     var39.zoomDomainAxes(0.0d, (-1.0d), var54, var57);
//     var31.zoomDomainAxes(100.0d, Double.NaN, var34, var57);
//     org.jfree.chart.plot.PlotState var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     var16.draw(var20, var30, var57, var60, var61);
//     var12.setChartArea(var30);
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var66 = var65.getPosition();
//     java.util.List var67 = var1.refreshTicks(var5, var7, var30, var66);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    var4.setBackgroundAlpha(1.0f);
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.data.xy.XYSeries var21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var24 = var21.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var27 = var21.addOrUpdate(0.0d, 0.05d);
    java.util.List var28 = var21.getItems();
    var4.drawDomainTickBands(var16, var17, var28);
    org.jfree.chart.renderer.xy.XYStepRenderer var30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var30.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var34 = var30.getSeriesPaint(31);
    boolean var35 = var30.getDrawSeriesLineAsPath();
    java.awt.Paint var39 = var30.getItemOutlinePaint(10, 1, false);
    var4.setDomainGridlinePaint(var39);
    java.awt.Stroke var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeZeroBaselineStroke(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
    java.awt.Color var22 = java.awt.Color.getColor("October", 15);
    java.awt.color.ColorSpace var23 = var22.getColorSpace();
    var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
    java.lang.Object var26 = var25.clone();
    org.jfree.data.general.Dataset var27 = var25.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    java.beans.PropertyChangeListener var4 = null;
    var3.removePropertyChangeListener(var4);
    var3.setDescription("");
    java.lang.Number var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var9 = var3.remove(var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getFixedDimension();
    java.awt.Paint var2 = var0.getTickMarkPaint();
    var0.setTickMarkInsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var5 = var0.getLabelInsets();
    java.awt.Paint var7 = null;
    var0.setTickLabelPaint((java.lang.Comparable)10.0f, var7);
    double var9 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, var1);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var1 = null;
//     var0.plotChanged(var1);
//     int var3 = var0.getDatasetCount();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     org.jfree.chart.plot.DrawingSupplier var10 = null;
//     var9.setDrawingSupplier(var10, true);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var16 = var15.getPosition();
//     var15.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var22 = var15.getPosition();
//     java.awt.geom.Rectangle2D var23 = var15.getBounds();
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
//     java.awt.Stroke var37 = null;
//     var36.setRadiusGridlineStroke(var37);
//     var32.setParent((org.jfree.chart.plot.Plot)var36);
//     var32.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var42 = var32.getRangeAxisEdge();
//     var32.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleAnchor var49 = null;
//     java.awt.geom.Point2D var50 = org.jfree.chart.util.RectangleAnchor.coordinates(var48, var49);
//     var32.zoomDomainAxes(0.0d, (-1.0d), var47, var50);
//     var24.zoomDomainAxes(100.0d, Double.NaN, var27, var50);
//     org.jfree.chart.plot.PlotState var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var9.draw(var13, var23, var50, var53, var54);
//     var0.panRangeAxes(0.0d, var5, var50);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var64 = null;
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
//     java.awt.Stroke var66 = null;
//     var65.setRadiusGridlineStroke(var66);
//     var61.setParent((org.jfree.chart.plot.Plot)var65);
//     org.jfree.chart.axis.AxisSpace var69 = null;
//     var61.setFixedDomainAxisSpace(var69, false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var73 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var73.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var77 = var73.getSeriesOutlinePaint(31);
//     var61.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var73, true);
//     java.awt.Stroke var80 = var61.getDomainCrosshairStroke();
//     var0.add(var61);
//     
//     // Checks the contract:  equals-hashcode on var36 and var65
//     assertTrue("Contract failed: equals-hashcode on var36 and var65", var36.equals(var65) ? var36.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var36
//     assertTrue("Contract failed: equals-hashcode on var65 and var36", var65.equals(var36) ? var65.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var4.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var19, var20);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var24 = var23.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var25 = var23.getLabelOffset();
//     java.lang.String var26 = var25.toString();
//     var19.setLabelOffset(var25);
//     
//     // Checks the contract:  equals-hashcode on var19 and var23
//     assertTrue("Contract failed: equals-hashcode on var19 and var23", var19.equals(var23) ? var19.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var19
//     assertTrue("Contract failed: equals-hashcode on var23 and var19", var23.equals(var19) ? var23.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    boolean var8 = var0.getItemVisible((-1), 100);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = null;
    var18.setRadiusGridlineStroke(var19);
    var14.setParent((org.jfree.chart.plot.Plot)var18);
    var14.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var24 = var14.getRangeCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-1), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     java.awt.Stroke var14 = var6.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var18 = null;
//     boolean var20 = var6.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var17, var18, true);
//     java.awt.Color var23 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var24 = var23.getColorSpace();
//     var6.setDomainZeroBaselinePaint((java.awt.Paint)var23);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var23);
//     java.lang.Object var27 = var26.clone();
//     var0.add(var26);
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = null;
//     var33.setDrawingSupplier(var34, true);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var40 = var39.getPosition();
//     var39.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var46 = var39.getPosition();
//     java.awt.geom.Rectangle2D var47 = var39.getBounds();
//     org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var59 = null;
//     org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
//     java.awt.Stroke var61 = null;
//     var60.setRadiusGridlineStroke(var61);
//     var56.setParent((org.jfree.chart.plot.Plot)var60);
//     var56.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var66 = var56.getRangeAxisEdge();
//     var56.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     java.awt.geom.Rectangle2D var72 = null;
//     org.jfree.chart.util.RectangleAnchor var73 = null;
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.RectangleAnchor.coordinates(var72, var73);
//     var56.zoomDomainAxes(0.0d, (-1.0d), var71, var74);
//     var48.zoomDomainAxes(100.0d, Double.NaN, var51, var74);
//     org.jfree.chart.plot.PlotState var77 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var78 = null;
//     var33.draw(var37, var47, var74, var77, var78);
//     var29.setChartArea(var47);
//     var26.setShape((java.awt.Shape)var47);
//     
//     // Checks the contract:  equals-hashcode on var10 and var60
//     assertTrue("Contract failed: equals-hashcode on var10 and var60", var10.equals(var60) ? var10.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var10
//     assertTrue("Contract failed: equals-hashcode on var60 and var10", var60.equals(var10) ? var60.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("poly");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = var20.getAngleGridlineStroke();
//     var6.setRangeZeroBaselineStroke(var21);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var27 = var24.isMinorTickMarksVisible();
//     java.awt.Font var28 = var24.getTickLabelFont();
//     boolean var29 = var24.isInverted();
//     var24.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=0]", var34);
//     var35.setMargin(0.0d, 0.0d, (-1.0d), 0.2d);
//     org.jfree.data.Range var41 = null;
//     org.jfree.data.Range var42 = null;
//     org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(var41, var42);
//     org.jfree.chart.block.RectangleConstraint var45 = var43.toFixedHeight((-1.0d));
//     org.jfree.chart.renderer.xy.XYAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var48 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var48.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var52 = var48.getSeriesPaint(31);
//     boolean var53 = var48.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var57 = var48.getURLGenerator(10, 31, true);
//     var48.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var60 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var60.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var60.setLegendShape(100, var66);
//     var48.setBaseLegendShape(var66);
//     var47.setLegendArea(var66);
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var70, var71, var72, var73);
//     org.jfree.data.xy.XYDataset var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var77 = null;
//     org.jfree.chart.plot.PolarPlot var78 = new org.jfree.chart.plot.PolarPlot(var75, var76, var77);
//     java.awt.Stroke var79 = null;
//     var78.setRadiusGridlineStroke(var79);
//     var74.setParent((org.jfree.chart.plot.Plot)var78);
//     var74.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var84 = var74.getRangeAxisEdge();
//     var74.setRangeCrosshairLockedOnData(true);
//     var74.configureDomainAxes();
//     org.jfree.chart.JFreeChart var88 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var74);
//     org.jfree.chart.entity.JFreeChartEntity var91 = new org.jfree.chart.entity.JFreeChartEntity(var66, var88, "Apr", "");
//     var88.setNotify(false);
//     org.jfree.chart.event.ChartChangeEvent var94 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var45, var88);
//     boolean var95 = var35.equals((java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var10 and var78
//     assertTrue("Contract failed: equals-hashcode on var10 and var78", var10.equals(var78) ? var10.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var10
//     assertTrue("Contract failed: equals-hashcode on var78 and var10", var78.equals(var10) ? var78.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.05d, 0.0d);
    org.jfree.chart.renderer.xy.XYStepRenderer var5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var5.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Stroke var11 = var5.getItemOutlineStroke(10, 4, false);
    boolean var12 = var4.equals((java.lang.Object)var5);
    java.awt.Shape var13 = var5.getBaseShape();
    java.awt.Stroke var15 = var5.getSeriesStroke(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var2, var3, var4);
    java.awt.Stroke var6 = null;
    var5.setRadiusGridlineStroke(var6);
    org.jfree.chart.plot.PlotOrientation var8 = var5.getOrientation();
    boolean var9 = var1.equals((java.lang.Object)var5);
    boolean var10 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)10.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getStartY(4, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var0.setLabelInsets(var5);
    boolean var7 = var0.isTickMarksVisible();
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var14.setDrawingSupplier(var15, true);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
    var20.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleEdge var27 = var20.getPosition();
    java.awt.geom.Rectangle2D var28 = var20.getBounds();
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.PolarItemRenderer var40 = null;
    org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
    java.awt.Stroke var42 = null;
    var41.setRadiusGridlineStroke(var42);
    var37.setParent((org.jfree.chart.plot.Plot)var41);
    var37.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var47 = var37.getRangeAxisEdge();
    var37.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    java.awt.geom.Rectangle2D var53 = null;
    org.jfree.chart.util.RectangleAnchor var54 = null;
    java.awt.geom.Point2D var55 = org.jfree.chart.util.RectangleAnchor.coordinates(var53, var54);
    var37.zoomDomainAxes(0.0d, (-1.0d), var52, var55);
    var29.zoomDomainAxes(100.0d, Double.NaN, var32, var55);
    org.jfree.chart.plot.PlotState var58 = null;
    org.jfree.chart.plot.PlotRenderingInfo var59 = null;
    var14.draw(var18, var28, var55, var58, var59);
    var10.setChartArea(var28);
    org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var64 = var63.getPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var65 = var0.getCategoryMiddle(10, 1, var28, var64);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var4 = var0.getStringArray("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
//     var1.setVisible(false);
//     org.jfree.chart.block.BlockFrame var5 = var1.getFrame();
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var1.removeChangeListener(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var8);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.05d, 0.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.block.Arrangement var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setArrangement(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2, true, false);
//     java.util.Date var6 = var1.getMinimumDate();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var6);
//     long var8 = var7.getFirstMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var7.getLastMillisecond(var9);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var1 = var0.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "NOID"+ "'", var1.equals("NOID"));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.util.LineUtilities var0 = new org.jfree.chart.util.LineUtilities();

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
    java.awt.Stroke var12 = null;
    var11.setRadiusGridlineStroke(var12);
    var7.setParent((org.jfree.chart.plot.Plot)var11);
    var7.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var17 = var7.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
    java.awt.Stroke var22 = var21.getAngleGridlineStroke();
    var7.setRangeZeroBaselineStroke(var22);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    var7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var25, true);
    boolean var28 = var25.isMinorTickMarksVisible();
    java.awt.Font var29 = var25.getTickLabelFont();
    boolean var30 = var25.isInverted();
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var25, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var35 = var1.getStartX(12, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2, true, false);
//     java.util.Date var6 = var1.getMinimumDate();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState(1.0d);
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     var9.moveCursor(100.0d, var11);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var15 = var14.getPosition();
//     var14.setVisible(false);
//     org.jfree.chart.block.BlockFrame var18 = var14.getFrame();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
//     var20.setVisible(false);
//     org.jfree.chart.block.BlockFrame var24 = var20.getFrame();
//     var14.setFrame(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var26, var27, var28);
//     org.jfree.chart.plot.DrawingSupplier var30 = null;
//     var29.setDrawingSupplier(var30, true);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var36 = var35.getPosition();
//     var35.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var42 = var35.getPosition();
//     java.awt.geom.Rectangle2D var43 = var35.getBounds();
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var55 = null;
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot(var53, var54, var55);
//     java.awt.Stroke var57 = null;
//     var56.setRadiusGridlineStroke(var57);
//     var52.setParent((org.jfree.chart.plot.Plot)var56);
//     var52.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var62 = var52.getRangeAxisEdge();
//     var52.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleAnchor var69 = null;
//     java.awt.geom.Point2D var70 = org.jfree.chart.util.RectangleAnchor.coordinates(var68, var69);
//     var52.zoomDomainAxes(0.0d, (-1.0d), var67, var70);
//     var44.zoomDomainAxes(100.0d, Double.NaN, var47, var70);
//     org.jfree.chart.plot.PlotState var73 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     var29.draw(var33, var43, var70, var73, var74);
//     var14.setBounds(var43);
//     org.jfree.data.xy.XYDataset var77 = null;
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var77, var78, var79, var80);
//     org.jfree.data.xy.XYDataset var82 = null;
//     org.jfree.chart.axis.ValueAxis var83 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var84 = null;
//     org.jfree.chart.plot.PolarPlot var85 = new org.jfree.chart.plot.PolarPlot(var82, var83, var84);
//     java.awt.Stroke var86 = null;
//     var85.setRadiusGridlineStroke(var86);
//     var81.setParent((org.jfree.chart.plot.Plot)var85);
//     var81.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var91 = var81.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var92 = new org.jfree.chart.axis.NumberAxis();
//     var81.setRangeAxis((org.jfree.chart.axis.ValueAxis)var92);
//     org.jfree.chart.util.RectangleEdge var95 = var81.getDomainAxisEdge(31);
//     java.util.List var96 = var1.refreshTicks(var7, var9, var43, var95);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var3 = null;
//     float[] var10 = new float[] { (-1.0f), 100.0f, (-1.0f)};
//     float[] var11 = java.awt.Color.RGBtoHSB(1, 31, (-1), var10);
//     float[] var12 = var2.getComponents(var3, var11);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
//     var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
//     boolean var27 = var1.equals((java.lang.Object)var12);
//     java.awt.Paint var28 = var1.getPaint();
//     org.jfree.chart.util.RectangleInsets var29 = var1.getPadding();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var32.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var36 = var32.getSeriesPaint(31);
//     boolean var37 = var32.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var41 = var32.getURLGenerator(10, 31, true);
//     var32.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var44.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var44.setLegendShape(100, var50);
//     var32.setBaseLegendShape(var50);
//     var31.setLegendArea(var50);
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
//     org.jfree.data.xy.XYDataset var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var61 = null;
//     org.jfree.chart.plot.PolarPlot var62 = new org.jfree.chart.plot.PolarPlot(var59, var60, var61);
//     java.awt.Stroke var63 = null;
//     var62.setRadiusGridlineStroke(var63);
//     var58.setParent((org.jfree.chart.plot.Plot)var62);
//     var58.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var68 = var58.getRangeAxisEdge();
//     var58.setRangeCrosshairLockedOnData(true);
//     var58.configureDomainAxes();
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
//     org.jfree.chart.entity.JFreeChartEntity var75 = new org.jfree.chart.entity.JFreeChartEntity(var50, var72, "Apr", "");
//     int var76 = var72.getBackgroundImageAlignment();
//     var72.setBackgroundImageAlignment(10);
//     boolean var79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var72);
//     
//     // Checks the contract:  equals-hashcode on var16 and var62
//     assertTrue("Contract failed: equals-hashcode on var16 and var62", var16.equals(var62) ? var16.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var16
//     assertTrue("Contract failed: equals-hashcode on var62 and var16", var62.equals(var16) ? var62.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2, true, false);
//     java.util.Date var6 = var1.getMinimumDate();
//     org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = null;
//     var12.setDrawingSupplier(var13, true);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var19 = var18.getPosition();
//     var18.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var25 = var18.getPosition();
//     java.awt.geom.Rectangle2D var26 = var18.getBounds();
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var38 = null;
//     org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot(var36, var37, var38);
//     java.awt.Stroke var40 = null;
//     var39.setRadiusGridlineStroke(var40);
//     var35.setParent((org.jfree.chart.plot.Plot)var39);
//     var35.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var45 = var35.getRangeAxisEdge();
//     var35.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleAnchor var52 = null;
//     java.awt.geom.Point2D var53 = org.jfree.chart.util.RectangleAnchor.coordinates(var51, var52);
//     var35.zoomDomainAxes(0.0d, (-1.0d), var50, var53);
//     var27.zoomDomainAxes(100.0d, Double.NaN, var30, var53);
//     org.jfree.chart.plot.PlotState var56 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     var12.draw(var16, var26, var53, var56, var57);
//     var8.setChartArea(var26);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var67 = null;
//     org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot(var65, var66, var67);
//     java.awt.Stroke var69 = null;
//     var68.setRadiusGridlineStroke(var69);
//     var64.setParent((org.jfree.chart.plot.Plot)var68);
//     var64.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var74 = var64.getRangeAxisEdge();
//     double var75 = var1.java2DToValue(3.0d, var26, var74);
//     
//     // Checks the contract:  equals-hashcode on var39 and var68
//     assertTrue("Contract failed: equals-hashcode on var39 and var68", var39.equals(var68) ? var39.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var39
//     assertTrue("Contract failed: equals-hashcode on var68 and var39", var68.equals(var39) ? var68.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var64
//     assertTrue("Contract failed: equals-hashcode on var35 and var64", var35.equals(var64) ? var35.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var35
//     assertTrue("Contract failed: equals-hashcode on var64 and var35", var64.equals(var35) ? var64.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var5 = var2.getPieLabelRecord(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    java.util.List var10 = var3.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.update((java.lang.Number)1, (java.lang.Number)4);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 12, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)0, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var5 = var3.remove((java.lang.Number)1404331199999L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    org.jfree.data.time.TimeSeries var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var3);
    var1.endSeriesPass((org.jfree.data.xy.XYDataset)var3, (-1), (-16777216), 0, 0, (-1));
    org.jfree.data.time.TimeSeries var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.removeSeries(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, (-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2097352));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
    java.awt.Color var22 = java.awt.Color.getColor("October", 15);
    java.awt.color.ColorSpace var23 = var22.getColorSpace();
    var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
    java.lang.Object var26 = var25.clone();
    boolean var27 = var25.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var2.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var6 = var2.getSeriesPaint(31);
    boolean var7 = var2.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var14.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var14.setLegendShape(100, var20);
    var2.setBaseLegendShape(var20);
    var1.setLegendArea(var20);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
    java.awt.Stroke var33 = null;
    var32.setRadiusGridlineStroke(var33);
    var28.setParent((org.jfree.chart.plot.Plot)var32);
    var28.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
    var28.setRangeCrosshairLockedOnData(true);
    var28.configureDomainAxes();
    org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
    org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
    var42.setNotify(false);
    boolean var49 = var42.equals((java.lang.Object)2);
    org.jfree.chart.event.ChartChangeListener var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var42.removeChangeListener(var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var1 = null;
//     var0.plotChanged(var1);
//     int var3 = var0.getDatasetCount();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var5);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var6.rendererChanged(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var12 = null;
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot(var10, var11, var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var13.setDrawingSupplier(var14, true);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var20 = var19.getPosition();
//     var19.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var26 = var19.getPosition();
//     java.awt.geom.Rectangle2D var27 = var19.getBounds();
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var39 = null;
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot(var37, var38, var39);
//     java.awt.Stroke var41 = null;
//     var40.setRadiusGridlineStroke(var41);
//     var36.setParent((org.jfree.chart.plot.Plot)var40);
//     var36.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var46 = var36.getRangeAxisEdge();
//     var36.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleAnchor var53 = null;
//     java.awt.geom.Point2D var54 = org.jfree.chart.util.RectangleAnchor.coordinates(var52, var53);
//     var36.zoomDomainAxes(0.0d, (-1.0d), var51, var54);
//     var28.zoomDomainAxes(100.0d, Double.NaN, var31, var54);
//     org.jfree.chart.plot.PlotState var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     var13.draw(var17, var27, var54, var57, var58);
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.chart.util.RectangleAnchor var61 = null;
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.RectangleAnchor.coordinates(var60, var61);
//     org.jfree.chart.plot.PlotState var63 = null;
//     org.jfree.chart.ChartRenderingInfo var64 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = var64.getPlotInfo();
//     var6.draw(var9, var27, var62, var63, var65);
//     org.jfree.chart.ChartRenderingInfo var67 = var65.getOwner();
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     org.jfree.data.xy.XYDataset var73 = null;
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var75 = null;
//     org.jfree.chart.plot.PolarPlot var76 = new org.jfree.chart.plot.PolarPlot(var73, var74, var75);
//     java.awt.Stroke var77 = null;
//     var76.setRadiusGridlineStroke(var77);
//     var72.setParent((org.jfree.chart.plot.Plot)var76);
//     var72.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var82 = var72.getRangeAxisEdge();
//     var72.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var87 = null;
//     java.awt.geom.Rectangle2D var88 = null;
//     org.jfree.chart.util.RectangleAnchor var89 = null;
//     java.awt.geom.Point2D var90 = org.jfree.chart.util.RectangleAnchor.coordinates(var88, var89);
//     var72.zoomDomainAxes(0.0d, (-1.0d), var87, var90);
//     var0.zoomRangeAxes(2.0d, var65, var90);
//     
//     // Checks the contract:  equals-hashcode on var40 and var76
//     assertTrue("Contract failed: equals-hashcode on var40 and var76", var40.equals(var76) ? var40.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var40
//     assertTrue("Contract failed: equals-hashcode on var76 and var40", var76.equals(var40) ? var76.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var72
//     assertTrue("Contract failed: equals-hashcode on var36 and var72", var36.equals(var72) ? var36.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var36
//     assertTrue("Contract failed: equals-hashcode on var72 and var36", var72.equals(var36) ? var72.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var4.setInsets(var25);
    org.jfree.data.xy.XYDataset var27 = var4.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
    double var18 = var17.getFixedDimension();
    java.awt.Paint var19 = var17.getTickMarkPaint();
    var15.setLabelPaint(var19);
    org.jfree.data.Range var21 = null;
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(var21, (org.jfree.data.Range)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeWithMargins(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    java.awt.Stroke var11 = null;
    var10.setRadiusGridlineStroke(var11);
    var6.setParent((org.jfree.chart.plot.Plot)var10);
    var6.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var16 = var6.getRangeCrosshairStroke();
    var6.configureRangeAxes();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var0.getXValue((-16777216), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     java.awt.Color var30 = java.awt.Color.getColor("October", 15);
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27, (java.awt.Paint)var30);
//     java.util.List var32 = var31.getLines();
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var36 = var35.getLabelOffsetType();
//     java.awt.Font var37 = var35.getLabelFont();
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var45 = null;
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var43, var44, var45);
//     java.awt.Stroke var47 = null;
//     var46.setRadiusGridlineStroke(var47);
//     var42.setParent((org.jfree.chart.plot.Plot)var46);
//     java.awt.Stroke var50 = var42.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var54 = null;
//     boolean var56 = var42.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var53, var54, true);
//     java.awt.Color var59 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var60 = var59.getColorSpace();
//     var42.setDomainZeroBaselinePaint((java.awt.Paint)var59);
//     java.awt.image.ColorModel var62 = null;
//     java.awt.Rectangle var63 = null;
//     java.awt.geom.Rectangle2D var64 = null;
//     java.awt.geom.AffineTransform var65 = null;
//     java.awt.RenderingHints var66 = null;
//     java.awt.PaintContext var67 = var59.createContext(var62, var63, var64, var65, var66);
//     var31.addLine("Pie Plot", var37, (java.awt.Paint)var59);
//     
//     // Checks the contract:  equals-hashcode on var9 and var46
//     assertTrue("Contract failed: equals-hashcode on var9 and var46", var9.equals(var46) ? var9.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var9
//     assertTrue("Contract failed: equals-hashcode on var46 and var9", var46.equals(var9) ? var46.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var53
//     assertTrue("Contract failed: equals-hashcode on var35 and var53", var35.equals(var53) ? var35.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var35
//     assertTrue("Contract failed: equals-hashcode on var53 and var35", var53.equals(var35) ? var53.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var1 = var0.isDrawBarOutline();
    boolean var2 = var0.getBaseSeriesVisibleInLegend();
    boolean var3 = var0.getShadowsVisible();
    org.jfree.chart.renderer.xy.XYStepRenderer var4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var4.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var8 = var4.getSeriesOutlinePaint(31);
    var4.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.PolarItemRenderer var19 = null;
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
    java.awt.Stroke var21 = null;
    var20.setRadiusGridlineStroke(var21);
    var16.setParent((org.jfree.chart.plot.Plot)var20);
    var16.setRangeZeroBaselineVisible(false);
    var4.setPlot(var16);
    org.jfree.chart.labels.ItemLabelPosition var28 = var4.getSeriesPositiveItemLabelPosition(0);
    var0.setNegativeItemLabelPositionFallback(var28);
    org.jfree.chart.LegendItem var32 = var0.getLegendItem((-16777216), 1);
    org.jfree.chart.labels.ItemLabelPosition var33 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var4.setFixedRangeAxisSpace(var15);
//     org.jfree.chart.axis.AxisLocation var18 = var4.getRangeAxisLocation((-16777216));
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var27 = null;
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var25, var26, var27);
//     java.awt.Stroke var29 = null;
//     var28.setRadiusGridlineStroke(var29);
//     var24.setParent((org.jfree.chart.plot.Plot)var28);
//     var24.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var34 = var24.getRangeAxisEdge();
//     var24.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var40 = null;
//     boolean var41 = var24.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var39, var40);
//     java.awt.Paint var42 = var39.getPaint();
//     org.jfree.chart.util.Layer var43 = null;
//     boolean var45 = var4.removeDomainMarker(4, (org.jfree.chart.plot.Marker)var39, var43, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var4.setInsets(var25);
//     double var27 = var25.getRight();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
//     org.jfree.chart.plot.DrawingSupplier var32 = null;
//     var31.setDrawingSupplier(var32, true);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var38 = var37.getPosition();
//     var37.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var44 = var37.getPosition();
//     java.awt.geom.Rectangle2D var45 = var37.getBounds();
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var57 = null;
//     org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot(var55, var56, var57);
//     java.awt.Stroke var59 = null;
//     var58.setRadiusGridlineStroke(var59);
//     var54.setParent((org.jfree.chart.plot.Plot)var58);
//     var54.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var64 = var54.getRangeAxisEdge();
//     var54.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     java.awt.geom.Rectangle2D var70 = null;
//     org.jfree.chart.util.RectangleAnchor var71 = null;
//     java.awt.geom.Point2D var72 = org.jfree.chart.util.RectangleAnchor.coordinates(var70, var71);
//     var54.zoomDomainAxes(0.0d, (-1.0d), var69, var72);
//     var46.zoomDomainAxes(100.0d, Double.NaN, var49, var72);
//     org.jfree.chart.plot.PlotState var75 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     var31.draw(var35, var45, var72, var75, var76);
//     org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var80 = var79.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var82 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var83 = var82.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var84 = var25.createAdjustedRectangle(var45, var80, var83);
//     
//     // Checks the contract:  equals-hashcode on var8 and var58
//     assertTrue("Contract failed: equals-hashcode on var8 and var58", var8.equals(var58) ? var8.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var46
//     assertTrue("Contract failed: equals-hashcode on var18 and var46", var18.equals(var46) ? var18.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var18
//     assertTrue("Contract failed: equals-hashcode on var46 and var18", var46.equals(var18) ? var46.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var8
//     assertTrue("Contract failed: equals-hashcode on var58 and var8", var58.equals(var8) ? var58.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var82
//     assertTrue("Contract failed: equals-hashcode on var79 and var82", var79.equals(var82) ? var79.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var79
//     assertTrue("Contract failed: equals-hashcode on var82 and var79", var82.equals(var79) ? var82.hashCode() == var79.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var8 = var0.getItemCreateEntity(10, (-1), true);
    int var9 = var0.getPassCount();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.plot.AbstractPieLabelDistributor var12 = var11.getLabelDistributor();
    double var13 = var11.getMinimumArcAngleToDraw();
    org.jfree.chart.urls.PieURLGenerator var14 = var11.getURLGenerator();
    org.jfree.chart.urls.PieURLGenerator var15 = null;
    var11.setLegendLabelURLGenerator(var15);
    java.awt.Stroke var17 = var11.getBaseSectionOutlineStroke();
    var0.setBaseStroke(var17, true);
    org.jfree.chart.urls.StandardXYURLGenerator var22 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-16777216), (org.jfree.chart.urls.XYURLGenerator)var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setBaseCreateEntities(true, true);
    boolean var4 = var0.getAutoPopulateSeriesShape();
    org.jfree.chart.labels.XYSeriesLabelGenerator var5 = var0.getLegendItemURLGenerator();
    var0.setUseFillPaint(false);
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var10 = var9.isDrawBarOutline();
    boolean var11 = var9.getBaseSeriesVisibleInLegend();
    java.awt.Font var13 = null;
    var9.setSeriesItemLabelFont(4, var13, true);
    org.jfree.chart.labels.StandardXYToolTipGenerator var17 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    var9.setSeriesToolTipGenerator(10, (org.jfree.chart.labels.XYToolTipGenerator)var17);
    java.lang.String var19 = var17.getFormatString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-2097352), (org.jfree.chart.labels.XYToolTipGenerator)var17, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "{0}: ({1}, {2})"+ "'", var19.equals("{0}: ({1}, {2})"));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var6.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var10 = var6.getSeriesPaint(31);
    boolean var11 = var6.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var15 = var6.getURLGenerator(10, 31, true);
    var6.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var18.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var18.setLegendShape(100, var24);
    var6.setBaseLegendShape(var24);
    var5.setLegendArea(var24);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
    java.awt.Stroke var37 = null;
    var36.setRadiusGridlineStroke(var37);
    var32.setParent((org.jfree.chart.plot.Plot)var36);
    var32.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var42 = var32.getRangeAxisEdge();
    var32.setRangeCrosshairLockedOnData(true);
    var32.configureDomainAxes();
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.entity.JFreeChartEntity var49 = new org.jfree.chart.entity.JFreeChartEntity(var24, var46, "Apr", "");
    org.jfree.chart.renderer.xy.XYStepRenderer var50 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var50.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.PolarItemRenderer var60 = null;
    org.jfree.chart.plot.PolarPlot var61 = new org.jfree.chart.plot.PolarPlot(var58, var59, var60);
    java.awt.Stroke var62 = null;
    var61.setRadiusGridlineStroke(var62);
    var57.setParent((org.jfree.chart.plot.Plot)var61);
    var57.setRangeZeroBaselineVisible(false);
    java.awt.Paint var67 = var57.getDomainCrosshairPaint();
    var50.setBaseFillPaint(var67);
    org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Paint var71 = var70.getPaint();
    boolean var72 = org.jfree.chart.util.PaintUtilities.equal(var67, var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem(var0, "{0}: ({1}, {2})", "21-December-2014", "", var24, var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    var4.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var20 = null;
    boolean var21 = var4.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var19, var20);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
    java.awt.Stroke var32 = null;
    var31.setRadiusGridlineStroke(var32);
    var27.setParent((org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.AxisSpace var35 = null;
    var27.setFixedDomainAxisSpace(var35, false);
    org.jfree.chart.axis.AxisSpace var38 = null;
    var27.setFixedRangeAxisSpace(var38);
    org.jfree.chart.axis.AxisLocation var41 = var27.getRangeAxisLocation((-16777216));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-1), var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     boolean var28 = var23.isInverted();
//     var23.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var23, var31);
//     org.jfree.chart.renderer.PolarItemRenderer var33 = var32.getRenderer();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var43 = null;
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot(var41, var42, var43);
//     java.awt.Stroke var45 = null;
//     var44.setRadiusGridlineStroke(var45);
//     var40.setParent((org.jfree.chart.plot.Plot)var44);
//     var40.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var50 = var40.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var53 = null;
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot(var51, var52, var53);
//     java.awt.Stroke var55 = var54.getAngleGridlineStroke();
//     var40.setRangeZeroBaselineStroke(var55);
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     var40.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var58, true);
//     boolean var61 = var58.isMinorTickMarksVisible();
//     java.awt.Font var62 = var58.getTickLabelFont();
//     boolean var63 = var58.isInverted();
//     var58.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var66 = null;
//     org.jfree.chart.plot.PolarPlot var67 = new org.jfree.chart.plot.PolarPlot(var35, (org.jfree.chart.axis.ValueAxis)var58, var66);
//     java.awt.Font var68 = var67.getNoDataMessageFont();
//     org.jfree.chart.block.LabelBlock var69 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=0]", var68);
//     var32.setNoDataMessageFont(var68);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var44
//     assertTrue("Contract failed: equals-hashcode on var9 and var44", var9.equals(var44) ? var9.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var54
//     assertTrue("Contract failed: equals-hashcode on var19 and var54", var19.equals(var54) ? var19.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var67
//     assertTrue("Contract failed: equals-hashcode on var32 and var67", var32.equals(var67) ? var32.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var9
//     assertTrue("Contract failed: equals-hashcode on var44 and var9", var44.equals(var9) ? var44.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var19
//     assertTrue("Contract failed: equals-hashcode on var54 and var19", var54.equals(var19) ? var54.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var32
//     assertTrue("Contract failed: equals-hashcode on var67 and var32", var67.equals(var32) ? var67.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
    java.awt.Color var22 = java.awt.Color.getColor("October", 15);
    java.awt.color.ColorSpace var23 = var22.getColorSpace();
    var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
    java.lang.Object var26 = var25.clone();
    var25.setLineVisible(true);
    boolean var29 = var25.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getXValue(15, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    boolean var5 = var0.getDrawSeriesLineAsPath();
    var0.setBaseLinesVisible(true);
    var0.setDefaultEntityRadius(2);
    boolean var10 = var0.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.plot.PlotRenderingInfo var0 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
//     org.jfree.data.time.TimeSeries var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var3);
//     var1.endSeriesPass((org.jfree.data.xy.XYDataset)var3, (-1), (-16777216), 0, 0, (-1));
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = null;
//     var19.setRadiusGridlineStroke(var20);
//     var15.setParent((org.jfree.chart.plot.Plot)var19);
//     var15.setRangeZeroBaselineVisible(false);
//     var15.setBackgroundAlpha(1.0f);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.data.xy.XYSeries var32 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
//     org.jfree.data.xy.XYDataItem var35 = var32.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
//     org.jfree.data.xy.XYDataItem var38 = var32.addOrUpdate(0.0d, 0.05d);
//     java.util.List var39 = var32.getItems();
//     var15.drawDomainTickBands(var27, var28, var39);
//     org.jfree.data.Range var43 = new org.jfree.data.Range(1.0d, 1.05d);
//     org.jfree.data.Range var45 = var3.getRangeBounds(var39, var43, false);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    java.lang.Object var10 = var3.clone();
    var3.setKey((java.lang.Comparable)'#');
    var3.add(Double.NaN, (java.lang.Number)31);
    org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var22 = var19.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var25 = var19.addOrUpdate(0.0d, 0.05d);
    org.jfree.data.xy.XYDataItem var28 = var19.addOrUpdate(0.0d, Double.NaN);
    org.jfree.data.xy.XYDataItem var29 = var3.addOrUpdate(var28);
    java.lang.String var30 = var28.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "[0.0, 0.05]"+ "'", var30.equals("[0.0, 0.05]"));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
    java.awt.Stroke var12 = null;
    var11.setRadiusGridlineStroke(var12);
    var7.setParent((org.jfree.chart.plot.Plot)var11);
    var7.setRangeZeroBaselineVisible(false);
    java.awt.Paint var17 = var7.getDomainCrosshairPaint();
    var0.setBaseFillPaint(var17);
    java.awt.Paint var20 = var0.lookupSeriesOutlinePaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesOutlinePaint(31);
    var0.setBaseItemLabelsVisible(true, true);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    var0.setPlot(var12);
    org.jfree.chart.labels.ItemLabelPosition var24 = var0.getSeriesPositiveItemLabelPosition(0);
    java.awt.Stroke var28 = var0.getItemStroke(15, 15, false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var29 = var0.getLegendItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.getStartYValue((-16777216), (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.renderer.PolarItemRenderer var12 = var8.getRenderer();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
//     java.awt.Stroke var22 = null;
//     var21.setRadiusGridlineStroke(var22);
//     var17.setParent((org.jfree.chart.plot.Plot)var21);
//     var17.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var27 = var17.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     var17.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
//     var8.setAxis((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.data.general.WaferMapDataset var33 = null;
//     org.jfree.chart.plot.WaferMapPlot var34 = new org.jfree.chart.plot.WaferMapPlot(var33);
//     org.jfree.chart.event.RendererChangeEvent var35 = null;
//     var34.rendererChanged(var35);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = null;
//     var41.setDrawingSupplier(var42, true);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var48 = var47.getPosition();
//     var47.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var54 = var47.getPosition();
//     java.awt.geom.Rectangle2D var55 = var47.getBounds();
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var67 = null;
//     org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot(var65, var66, var67);
//     java.awt.Stroke var69 = null;
//     var68.setRadiusGridlineStroke(var69);
//     var64.setParent((org.jfree.chart.plot.Plot)var68);
//     var64.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var74 = var64.getRangeAxisEdge();
//     var64.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     java.awt.geom.Rectangle2D var80 = null;
//     org.jfree.chart.util.RectangleAnchor var81 = null;
//     java.awt.geom.Point2D var82 = org.jfree.chart.util.RectangleAnchor.coordinates(var80, var81);
//     var64.zoomDomainAxes(0.0d, (-1.0d), var79, var82);
//     var56.zoomDomainAxes(100.0d, Double.NaN, var59, var82);
//     org.jfree.chart.plot.PlotState var85 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     var41.draw(var45, var55, var82, var85, var86);
//     java.awt.geom.Rectangle2D var88 = null;
//     org.jfree.chart.util.RectangleAnchor var89 = null;
//     java.awt.geom.Point2D var90 = org.jfree.chart.util.RectangleAnchor.coordinates(var88, var89);
//     org.jfree.chart.plot.PlotState var91 = null;
//     org.jfree.chart.ChartRenderingInfo var92 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var93 = var92.getPlotInfo();
//     var34.draw(var37, var55, var90, var91, var93);
//     org.jfree.chart.ChartRenderingInfo var95 = var93.getOwner();
//     java.awt.geom.Point2D var96 = null;
//     var8.zoomRangeAxes(0.0d, 1.0E-100d, var93, var96);
//     
//     // Checks the contract:  equals-hashcode on var4 and var64
//     assertTrue("Contract failed: equals-hashcode on var4 and var64", var4.equals(var64) ? var4.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var4
//     assertTrue("Contract failed: equals-hashcode on var64 and var4", var64.equals(var4) ? var64.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var68
//     assertTrue("Contract failed: equals-hashcode on var21 and var68", var21.equals(var68) ? var21.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var21
//     assertTrue("Contract failed: equals-hashcode on var68 and var21", var68.equals(var21) ? var68.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
    var0.setLabelInsets(var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)'a');
    var0.setCategoryMargin(1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     var4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var22, true);
//     int var25 = var4.getDomainAxisCount();
//     org.jfree.chart.plot.DrawingSupplier var26 = var4.getDrawingSupplier();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     java.awt.Stroke var36 = null;
//     var35.setRadiusGridlineStroke(var36);
//     var31.setParent((org.jfree.chart.plot.Plot)var35);
//     var31.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     java.awt.Stroke var46 = var45.getAngleGridlineStroke();
//     var31.setRangeZeroBaselineStroke(var46);
//     var31.clearRangeAxes();
//     org.jfree.chart.plot.DrawingSupplier var49 = var31.getDrawingSupplier();
//     var4.setDrawingSupplier(var49, false);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var49
//     assertTrue("Contract failed: equals-hashcode on var26 and var49", var26.equals(var49) ? var26.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var26
//     assertTrue("Contract failed: equals-hashcode on var49 and var26", var49.equals(var26) ? var49.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.05d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.block.Arrangement var6 = var5.getArrangement();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var9 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, var9);
//     org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight((-1.0d));
//     org.jfree.data.Range var13 = var12.getWidthRange();
//     org.jfree.chart.util.Size2D var14 = var5.arrange(var7, var12);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Font var6 = var0.getItemLabelFont(0, 0, false);
    boolean var7 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.annotations.XYAnnotation var8 = null;
    boolean var9 = var0.removeAnnotation(var8);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    java.awt.Paint var13 = var12.getBaseSectionPaint();
    var0.setSeriesItemLabelPaint(31, var13);
    org.jfree.chart.labels.XYToolTipGenerator var18 = var0.getToolTipGenerator(0, 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-2097352));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2, true, false);
//     java.util.Date var6 = var1.getMinimumDate();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var6);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     int var10 = var9.getMinorTickCount();
//     java.util.TimeZone var11 = var9.getTimeZone();
//     java.util.Locale var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var6, var11, var12);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    double var3 = var1.getMinimumArcAngleToDraw();
    org.jfree.chart.urls.PieURLGenerator var4 = var1.getURLGenerator();
    var1.setAutoPopulateSectionOutlinePaint(true);
    org.jfree.chart.plot.PieLabelLinkStyle var7 = var1.getLabelLinkStyle();
    java.lang.Object var8 = null;
    boolean var9 = var7.equals(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.LengthAdjustmentType var19 = var18.getLabelOffsetType();
    java.awt.Font var20 = var18.getLabelFont();
    org.jfree.chart.util.Layer var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((org.jfree.chart.plot.Marker)var18, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var4.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var19, var20);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var24 = var23.getLabelOffsetType();
//     var19.setLabelOffsetType(var24);
//     
//     // Checks the contract:  equals-hashcode on var19 and var23
//     assertTrue("Contract failed: equals-hashcode on var19 and var23", var19.equals(var23) ? var19.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var19
//     assertTrue("Contract failed: equals-hashcode on var23 and var19", var23.equals(var19) ? var23.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getFixedDimension();
//     int var2 = var0.getCategoryLabelPositionOffset();
//     java.awt.Paint var4 = null;
//     var0.setTickLabelPaint((java.lang.Comparable)1L, var4);
//     org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var0.setTickLabelInsets(var10);
//     org.jfree.chart.axis.CategoryAnchor var12 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     org.jfree.chart.plot.DrawingSupplier var19 = null;
//     var18.setDrawingSupplier(var19, true);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var25 = var24.getPosition();
//     var24.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var31 = var24.getPosition();
//     java.awt.geom.Rectangle2D var32 = var24.getBounds();
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     java.awt.Stroke var46 = null;
//     var45.setRadiusGridlineStroke(var46);
//     var41.setParent((org.jfree.chart.plot.Plot)var45);
//     var41.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var51 = var41.getRangeAxisEdge();
//     var41.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleAnchor var58 = null;
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var57, var58);
//     var41.zoomDomainAxes(0.0d, (-1.0d), var56, var59);
//     var33.zoomDomainAxes(100.0d, Double.NaN, var36, var59);
//     org.jfree.chart.plot.PlotState var62 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     var18.draw(var22, var32, var59, var62, var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var72 = null;
//     org.jfree.chart.plot.PolarPlot var73 = new org.jfree.chart.plot.PolarPlot(var70, var71, var72);
//     java.awt.Stroke var74 = null;
//     var73.setRadiusGridlineStroke(var74);
//     var69.setParent((org.jfree.chart.plot.Plot)var73);
//     var69.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var79 = var69.getRangeAxisEdge();
//     double var80 = var0.getCategoryJava2DCoordinate(var12, (-2097352), 2147483647, var32, var79);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.chart.event.RendererChangeEvent var2 = null;
//     var1.rendererChanged(var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var8.setDrawingSupplier(var9, true);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var15 = var14.getPosition();
//     var14.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var21 = var14.getPosition();
//     java.awt.geom.Rectangle2D var22 = var14.getBounds();
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     java.awt.Stroke var36 = null;
//     var35.setRadiusGridlineStroke(var36);
//     var31.setParent((org.jfree.chart.plot.Plot)var35);
//     var31.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge();
//     var31.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleAnchor var48 = null;
//     java.awt.geom.Point2D var49 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var48);
//     var31.zoomDomainAxes(0.0d, (-1.0d), var46, var49);
//     var23.zoomDomainAxes(100.0d, Double.NaN, var26, var49);
//     org.jfree.chart.plot.PlotState var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     var8.draw(var12, var22, var49, var52, var53);
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleAnchor var56 = null;
//     java.awt.geom.Point2D var57 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var56);
//     org.jfree.chart.plot.PlotState var58 = null;
//     org.jfree.chart.ChartRenderingInfo var59 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var60 = var59.getPlotInfo();
//     var1.draw(var4, var22, var57, var58, var60);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var70 = null;
//     org.jfree.chart.plot.PolarPlot var71 = new org.jfree.chart.plot.PolarPlot(var68, var69, var70);
//     java.awt.Stroke var72 = null;
//     var71.setRadiusGridlineStroke(var72);
//     var67.setParent((org.jfree.chart.plot.Plot)var71);
//     var67.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var77 = var67.getRangeGridlinePaint();
//     org.jfree.chart.JFreeChart var78 = new org.jfree.chart.JFreeChart("{0}: ({1}, {2})", (org.jfree.chart.plot.Plot)var67);
//     org.jfree.chart.entity.PlotEntity var79 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape)var22, (org.jfree.chart.plot.Plot)var67);
//     
//     // Checks the contract:  equals-hashcode on var35 and var71
//     assertTrue("Contract failed: equals-hashcode on var35 and var71", var35.equals(var71) ? var35.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var35
//     assertTrue("Contract failed: equals-hashcode on var71 and var35", var71.equals(var35) ? var71.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var67
//     assertTrue("Contract failed: equals-hashcode on var31 and var67", var31.equals(var67) ? var31.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var31
//     assertTrue("Contract failed: equals-hashcode on var67 and var31", var67.equals(var31) ? var67.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     double var2 = var0.getRangeLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var5 = var0.getEndY(4, 10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=0]", var3, "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "RangeType.FULL", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.chart.ui.Library var12 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    java.lang.String var13 = var12.getName();
    var7.addOptionalLibrary(var12);
    var7.setLicenceName("RangeType.FULL");
    java.util.List var17 = var7.getContributors();
    java.awt.Image var21 = null;
    org.jfree.chart.ui.ProjectInfo var25 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=0]", var21, "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "RangeType.FULL", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    org.jfree.data.xy.XYSeries var29 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var32 = var29.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var35 = var29.addOrUpdate(0.0d, 0.05d);
    java.util.List var36 = var29.getItems();
    var25.setContributors(var36);
    var7.addLibrary((org.jfree.chart.ui.Library)var25);
    java.lang.String var39 = var25.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + ""+ "'", var13.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "RangeType.FULL"+ "'", var39.equals("RangeType.FULL"));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.annotations.XYAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var4.removeAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
    org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var2.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var6 = var2.getSeriesPaint(31);
    boolean var7 = var2.getDrawSeriesLineAsPath();
    org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var14.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var14.setLegendShape(100, var20);
    var2.setBaseLegendShape(var20);
    var1.setLegendArea(var20);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
    java.awt.Stroke var33 = null;
    var32.setRadiusGridlineStroke(var33);
    var28.setParent((org.jfree.chart.plot.Plot)var32);
    var28.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
    var28.setRangeCrosshairLockedOnData(true);
    var28.configureDomainAxes();
    org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
    org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
    java.lang.String var46 = var45.getShapeCoords();
    org.jfree.chart.JFreeChart var47 = var45.getChart();
    org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var50 = var49.getPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var47.setTextAntiAlias((java.lang.Object)var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "-100,100,100,-100,0,-141,-100,-100,100,100,141,0,100,-100,-100,100,0,141,100,100,-100,-100,-141,0,-141,0"+ "'", var46.equals("-100,100,100,-100,0,-141,-100,-100,100,100,141,0,100,-100,-100,100,0,141,100,100,-100,-100,-141,0,-141,0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    java.awt.Stroke var12 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var16 = null;
    boolean var18 = var4.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var15, var16, true);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var20 = var19.getInsets();
    var15.setLabelOffset(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    java.awt.Stroke var19 = var18.getAngleGridlineStroke();
    var4.setRangeZeroBaselineStroke(var19);
    var4.clearRangeAxes();
    org.jfree.chart.plot.DrawingSupplier var22 = var4.getDrawingSupplier();
    java.awt.geom.Point2D var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setQuadrantOrigin(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     boolean var15 = var4.isDomainCrosshairVisible();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var19 = var18.getPosition();
//     var18.setVisible(false);
//     org.jfree.chart.block.BlockFrame var22 = var18.getFrame();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var25 = var24.getPosition();
//     var24.setVisible(false);
//     org.jfree.chart.block.BlockFrame var28 = var24.getFrame();
//     var18.setFrame(var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = null;
//     var33.setDrawingSupplier(var34, true);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var40 = var39.getPosition();
//     var39.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var46 = var39.getPosition();
//     java.awt.geom.Rectangle2D var47 = var39.getBounds();
//     org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var59 = null;
//     org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
//     java.awt.Stroke var61 = null;
//     var60.setRadiusGridlineStroke(var61);
//     var56.setParent((org.jfree.chart.plot.Plot)var60);
//     var56.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var66 = var56.getRangeAxisEdge();
//     var56.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     java.awt.geom.Rectangle2D var72 = null;
//     org.jfree.chart.util.RectangleAnchor var73 = null;
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.RectangleAnchor.coordinates(var72, var73);
//     var56.zoomDomainAxes(0.0d, (-1.0d), var71, var74);
//     var48.zoomDomainAxes(100.0d, Double.NaN, var51, var74);
//     org.jfree.chart.plot.PlotState var77 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var78 = null;
//     var33.draw(var37, var47, var74, var77, var78);
//     var18.setBounds(var47);
//     var4.drawBackgroundImage(var16, var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var56
//     assertTrue("Contract failed: equals-hashcode on var4 and var56", var4.equals(var56) ? var4.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var4
//     assertTrue("Contract failed: equals-hashcode on var56 and var4", var56.equals(var4) ? var56.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var60
//     assertTrue("Contract failed: equals-hashcode on var8 and var60", var8.equals(var60) ? var8.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var8
//     assertTrue("Contract failed: equals-hashcode on var60 and var8", var60.equals(var8) ? var60.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, (org.jfree.data.Range)var1);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.awt.Font var6 = var0.getItemLabelFont(0, 0, false);
    boolean var7 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.labels.XYSeriesLabelGenerator var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var4 = var0.getSeriesPaint(31);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    java.awt.Stroke var15 = null;
    var14.setRadiusGridlineStroke(var15);
    var10.setParent((org.jfree.chart.plot.Plot)var14);
    var10.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var20 = var10.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var21, var22, var23);
    java.awt.Stroke var25 = var24.getAngleGridlineStroke();
    var10.setRangeZeroBaselineStroke(var25);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var10.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var28, true);
    java.awt.Graphics2D var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    java.util.List var33 = null;
    var10.drawRangeTickBands(var31, var32, var33);
    var10.setRangeCrosshairValue((-1.0d));
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    var10.clearRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, (org.jfree.data.Range)var1);
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
//     org.jfree.data.Range var4 = org.jfree.data.Range.combine(var0, (org.jfree.data.Range)var3);
//     org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { "RangeType.FULL"};
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { var2};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
    org.jfree.chart.plot.DrawingSupplier var6 = null;
    var4.setDrawingSupplier(var6);
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var4.getRangeMarkers(4, var9);
    var4.setRangeZeroBaselineVisible(true);
    java.awt.Stroke var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainMinorGridlineStroke(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1, var2);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 10.0d, 2, (java.lang.Comparable)100L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2, var1);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    java.awt.Paint var15 = var5.getRangeGridlinePaint();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("{0}: ({1}, {2})", (org.jfree.chart.plot.Plot)var5);
    java.awt.Color var20 = java.awt.Color.getHSBColor(1.0f, 10.0f, 10.0f);
    java.awt.Color var23 = java.awt.Color.getColor("October", 15);
    java.awt.color.ColorSpace var24 = var23.getColorSpace();
    java.awt.color.ColorSpace var25 = var23.getColorSpace();
    int var26 = var23.getBlue();
    boolean var27 = var20.equals((java.lang.Object)var23);
    var16.setBorderPaint((java.awt.Paint)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var29 = var16.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL", var1);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimeSeries var3 = var1.getSeries((java.lang.Comparable)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.getXValue(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     java.awt.Color var30 = java.awt.Color.getColor("October", 15);
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27, (java.awt.Paint)var30);
//     java.util.List var32 = var31.getLines();
//     org.jfree.chart.util.HorizontalAlignment var33 = var31.getLineAlignment();
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.util.Size2D var35 = var31.calculateDimensions(var34);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var16.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
//     var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.renderer.xy.XYStepRenderer var24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var24.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var28 = var24.getSeriesPaint(31);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var24.getBaseNegativeItemLabelPosition();
//     var23.setBaseNegativeItemLabelPosition(var29);
//     var4.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var23);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
//     java.awt.Stroke var42 = null;
//     var41.setRadiusGridlineStroke(var42);
//     var37.setParent((org.jfree.chart.plot.Plot)var41);
//     var37.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var47 = var37.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     var37.setRangeAxis((org.jfree.chart.axis.ValueAxis)var48);
//     boolean var50 = var48.isVerticalTickLabels();
//     var4.setDomainAxis(2014, (org.jfree.chart.axis.ValueAxis)var48, false);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.ChartRenderingInfo var6 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = var6.getPlotInfo();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var22 = var12.getRangeAxisEdge();
//     var12.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleAnchor var29 = null;
//     java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
//     var12.zoomDomainAxes(0.0d, (-1.0d), var27, var30);
//     var3.zoomRangeAxes(8.64E7d, 3.0d, var7, var30);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var2.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var6 = var2.getSeriesPaint(31);
//     boolean var7 = var2.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var14.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var14.setLegendShape(100, var20);
//     var2.setBaseLegendShape(var20);
//     var1.setLegendArea(var20);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
//     var28.setRangeCrosshairLockedOnData(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
//     int var46 = var42.getBackgroundImageAlignment();
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var54 = null;
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
//     java.awt.Stroke var56 = null;
//     var55.setRadiusGridlineStroke(var56);
//     var51.setParent((org.jfree.chart.plot.Plot)var55);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     java.awt.geom.Point2D var62 = null;
//     var55.zoomDomainAxes(Double.NaN, 0.05d, var61, var62);
//     org.jfree.chart.block.CenterArrangement var64 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var67 = var66.getPosition();
//     var66.setVisible(false);
//     org.jfree.chart.block.BlockFrame var70 = var66.getFrame();
//     org.jfree.chart.title.TextTitle var72 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var73 = var72.getPosition();
//     var72.setVisible(false);
//     org.jfree.chart.block.BlockFrame var76 = var72.getFrame();
//     var66.setFrame(var76);
//     org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var80 = var79.getLabelOffsetType();
//     java.awt.Font var81 = var79.getLabelFont();
//     var64.add((org.jfree.chart.block.Block)var66, (java.lang.Object)var81);
//     org.jfree.chart.util.HorizontalAlignment var83 = null;
//     org.jfree.chart.util.VerticalAlignment var84 = null;
//     org.jfree.chart.block.FlowArrangement var87 = new org.jfree.chart.block.FlowArrangement(var83, var84, 0.0d, 1.0d);
//     org.jfree.chart.axis.DateAxis var89 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var90 = null;
//     var89.setTickUnit(var90, true, false);
//     boolean var94 = var87.equals((java.lang.Object)false);
//     org.jfree.chart.title.LegendTitle var95 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55, (org.jfree.chart.block.Arrangement)var64, (org.jfree.chart.block.Arrangement)var87);
//     var42.addLegend(var95);
//     
//     // Checks the contract:  equals-hashcode on var28 and var51
//     assertTrue("Contract failed: equals-hashcode on var28 and var51", var28.equals(var51) ? var28.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var28
//     assertTrue("Contract failed: equals-hashcode on var51 and var28", var51.equals(var28) ? var51.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var55
//     assertTrue("Contract failed: equals-hashcode on var32 and var55", var32.equals(var55) ? var32.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var32
//     assertTrue("Contract failed: equals-hashcode on var55 and var32", var55.equals(var32) ? var55.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.ChartRenderingInfo var2 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var5 = null;
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot(var3, var4, var5);
//     org.jfree.chart.plot.DrawingSupplier var7 = null;
//     var6.setDrawingSupplier(var7, true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var13 = var12.getPosition();
//     var12.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var19 = var12.getPosition();
//     java.awt.geom.Rectangle2D var20 = var12.getBounds();
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     var29.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var39 = var29.getRangeAxisEdge();
//     var29.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleAnchor var46 = null;
//     java.awt.geom.Point2D var47 = org.jfree.chart.util.RectangleAnchor.coordinates(var45, var46);
//     var29.zoomDomainAxes(0.0d, (-1.0d), var44, var47);
//     var21.zoomDomainAxes(100.0d, Double.NaN, var24, var47);
//     org.jfree.chart.plot.PlotState var50 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     var6.draw(var10, var20, var47, var50, var51);
//     var2.setChartArea(var20);
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
//     org.jfree.data.time.TimeSeries var59 = null;
//     org.jfree.data.time.TimeSeriesCollection var60 = new org.jfree.data.time.TimeSeriesCollection(var59);
//     org.jfree.data.Range var61 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var60);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var63 = var0.initialise(var1, var20, var58, (org.jfree.data.xy.XYDataset)var60, var62);
//     
//     // Checks the contract:  equals-hashcode on var29 and var58
//     assertTrue("Contract failed: equals-hashcode on var29 and var58", var29.equals(var58) ? var29.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var29
//     assertTrue("Contract failed: equals-hashcode on var58 and var29", var58.equals(var29) ? var58.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    java.awt.Stroke var20 = var19.getAngleGridlineStroke();
    var5.setRangeZeroBaselineStroke(var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
    boolean var26 = var23.isMinorTickMarksVisible();
    java.awt.Font var27 = var23.getTickLabelFont();
    java.awt.Color var30 = java.awt.Color.getColor("October", 15);
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27, (java.awt.Paint)var30);
    org.jfree.chart.util.HorizontalAlignment var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setLineAlignment(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    boolean var3 = var0.containsKey("poly");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.getString("October");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     double var2 = var0.getRangeLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var5 = var0.getY((-16777216), 2147483647);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var2.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var6 = var2.getSeriesPaint(31);
//     boolean var7 = var2.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var14.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var14.setLegendShape(100, var20);
//     var2.setBaseLegendShape(var20);
//     var1.setLegendArea(var20);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
//     var28.setRangeCrosshairLockedOnData(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var53 = null;
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot(var51, var52, var53);
//     java.awt.Stroke var55 = null;
//     var54.setRadiusGridlineStroke(var55);
//     var50.setParent((org.jfree.chart.plot.Plot)var54);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Point2D var61 = null;
//     var54.zoomDomainAxes(Double.NaN, 0.05d, var60, var61);
//     org.jfree.chart.block.CenterArrangement var63 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var66 = var65.getPosition();
//     var65.setVisible(false);
//     org.jfree.chart.block.BlockFrame var69 = var65.getFrame();
//     org.jfree.chart.title.TextTitle var71 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var72 = var71.getPosition();
//     var71.setVisible(false);
//     org.jfree.chart.block.BlockFrame var75 = var71.getFrame();
//     var65.setFrame(var75);
//     org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var79 = var78.getLabelOffsetType();
//     java.awt.Font var80 = var78.getLabelFont();
//     var63.add((org.jfree.chart.block.Block)var65, (java.lang.Object)var80);
//     org.jfree.chart.util.HorizontalAlignment var82 = null;
//     org.jfree.chart.util.VerticalAlignment var83 = null;
//     org.jfree.chart.block.FlowArrangement var86 = new org.jfree.chart.block.FlowArrangement(var82, var83, 0.0d, 1.0d);
//     org.jfree.chart.axis.DateAxis var88 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var89 = null;
//     var88.setTickUnit(var89, true, false);
//     boolean var93 = var86.equals((java.lang.Object)false);
//     org.jfree.chart.title.LegendTitle var94 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var54, (org.jfree.chart.block.Arrangement)var63, (org.jfree.chart.block.Arrangement)var86);
//     org.jfree.chart.entity.TitleEntity var97 = new org.jfree.chart.entity.TitleEntity(var20, (org.jfree.chart.title.Title)var94, "", "java.awt.Color[r=0,g=0,b=15]");
//     
//     // Checks the contract:  equals-hashcode on var28 and var50
//     assertTrue("Contract failed: equals-hashcode on var28 and var50", var28.equals(var50) ? var28.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var28
//     assertTrue("Contract failed: equals-hashcode on var50 and var28", var50.equals(var28) ? var50.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var54
//     assertTrue("Contract failed: equals-hashcode on var32 and var54", var32.equals(var54) ? var32.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var32
//     assertTrue("Contract failed: equals-hashcode on var54 and var32", var54.equals(var32) ? var54.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
//     org.jfree.chart.renderer.xy.XYStepRenderer var2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var2.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var6 = var2.getSeriesPaint(31);
//     boolean var7 = var2.getDrawSeriesLineAsPath();
//     org.jfree.chart.urls.XYURLGenerator var11 = var2.getURLGenerator(10, 31, true);
//     var2.setDataBoundsIncludesVisibleSeriesOnly(false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var14.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var14.setLegendShape(100, var20);
//     var2.setBaseLegendShape(var20);
//     var1.setLegendArea(var20);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var29, var30, var31);
//     java.awt.Stroke var33 = null;
//     var32.setRadiusGridlineStroke(var33);
//     var28.setParent((org.jfree.chart.plot.Plot)var32);
//     var28.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var38 = var28.getRangeAxisEdge();
//     var28.setRangeCrosshairLockedOnData(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.entity.JFreeChartEntity var45 = new org.jfree.chart.entity.JFreeChartEntity(var20, var42, "Apr", "");
//     int var46 = var42.getBackgroundImageAlignment();
//     var42.setBackgroundImageAlignment(10);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var51 = var50.getPosition();
//     var50.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var64 = null;
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
//     java.awt.Stroke var66 = null;
//     var65.setRadiusGridlineStroke(var66);
//     var61.setParent((org.jfree.chart.plot.Plot)var65);
//     var61.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var71 = var61.getRangeAxisEdge();
//     var50.setPosition(var71);
//     var42.removeSubtitle((org.jfree.chart.title.Title)var50);
//     
//     // Checks the contract:  equals-hashcode on var28 and var61
//     assertTrue("Contract failed: equals-hashcode on var28 and var61", var28.equals(var61) ? var28.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var28
//     assertTrue("Contract failed: equals-hashcode on var61 and var28", var61.equals(var28) ? var61.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var65
//     assertTrue("Contract failed: equals-hashcode on var32 and var65", var32.equals(var65) ? var32.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var32
//     assertTrue("Contract failed: equals-hashcode on var65 and var32", var65.equals(var32) ? var65.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = var4.getFixedLegendItems();
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = var7.getPlotInfo();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var11 = null;
//     var10.setTickUnit(var11, true, false);
//     var10.setLowerBound(Double.NaN);
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var10);
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = var19.getPlotInfo();
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleAnchor var22 = null;
//     java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var22);
//     var17.zoomDomainAxes(11.0d, var20, var23, false);
//     var4.panRangeAxes(1.0E-100d, var8, var23);
//     
//     // Checks the contract:  equals-hashcode on var7 and var19
//     assertTrue("Contract failed: equals-hashcode on var7 and var19", var7.equals(var19) ? var7.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var7
//     assertTrue("Contract failed: equals-hashcode on var19 and var7", var19.equals(var7) ? var19.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var20
//     assertTrue("Contract failed: equals-hashcode on var8 and var20", var8.equals(var20) ? var8.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var8
//     assertTrue("Contract failed: equals-hashcode on var20 and var8", var20.equals(var8) ? var20.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot(var2, var3, var4);
    java.awt.Stroke var6 = null;
    var5.setRadiusGridlineStroke(var6);
    org.jfree.chart.plot.PlotOrientation var8 = var5.getOrientation();
    boolean var9 = var1.equals((java.lang.Object)var5);
    boolean var10 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var0.getKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    boolean var4 = var0.isAutoWidth();
    org.jfree.data.DomainOrder var5 = var0.getDomainOrder();
    org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    boolean var7 = var5.equals((java.lang.Object)var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var22 = var12.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.PolarItemRenderer var25 = null;
    org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot(var23, var24, var25);
    java.awt.Stroke var27 = var26.getAngleGridlineStroke();
    var12.setRangeZeroBaselineStroke(var27);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    var12.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var30, true);
    boolean var33 = var30.isMinorTickMarksVisible();
    java.awt.Font var34 = var30.getTickLabelFont();
    boolean var35 = var30.isInverted();
    var30.setMinorTickMarksVisible(false);
    boolean var38 = var5.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var4.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var19, var20);
//     java.awt.Paint var22 = var19.getPaint();
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var25 = var24.getLabelOffsetType();
//     org.jfree.chart.util.RectangleInsets var26 = var24.getLabelOffset();
//     org.jfree.chart.renderer.xy.XYStepRenderer var27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var27.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var31 = var27.getSeriesOutlinePaint(31);
//     var27.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var42 = null;
//     org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot(var40, var41, var42);
//     java.awt.Stroke var44 = null;
//     var43.setRadiusGridlineStroke(var44);
//     var39.setParent((org.jfree.chart.plot.Plot)var43);
//     var39.setRangeZeroBaselineVisible(false);
//     var27.setPlot(var39);
//     org.jfree.chart.labels.ItemLabelPosition var51 = var27.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var52 = var51.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var53 = var51.getTextAnchor();
//     var24.setLabelTextAnchor(var53);
//     var19.setLabelTextAnchor(var53);
//     
//     // Checks the contract:  equals-hashcode on var4 and var39
//     assertTrue("Contract failed: equals-hashcode on var4 and var39", var4.equals(var39) ? var4.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var4
//     assertTrue("Contract failed: equals-hashcode on var39 and var4", var39.equals(var4) ? var39.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var24
//     assertTrue("Contract failed: equals-hashcode on var19 and var24", var19.equals(var24) ? var19.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var19
//     assertTrue("Contract failed: equals-hashcode on var24 and var19", var24.equals(var19) ? var24.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setBaseCreateEntities(true, true);
    var0.setSeriesVisible(100, (java.lang.Boolean)false, true);
    java.lang.Boolean var9 = var0.getSeriesItemLabelsVisible(31);
    java.awt.Paint var10 = var0.getBaseLegendTextPaint();
    var0.setBaseShapesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var2 = var1.getLabelOffsetType();
//     java.awt.Font var3 = var1.getLabelFont();
//     java.awt.Stroke var4 = var1.getStroke();
//     org.jfree.chart.util.RectangleAnchor var5 = var1.getLabelAnchor();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     java.awt.Stroke var15 = null;
//     var14.setRadiusGridlineStroke(var15);
//     var10.setParent((org.jfree.chart.plot.Plot)var14);
//     var10.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var20 = var10.getRangeAxisEdge();
//     var10.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var26 = null;
//     boolean var27 = var10.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var25, var26);
//     java.awt.Stroke var28 = var25.getOutlineStroke();
//     boolean var29 = var5.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.chart.event.RendererChangeEvent var2 = null;
    var1.rendererChanged(var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var8.setDrawingSupplier(var9, true);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var15 = var14.getPosition();
    var14.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleEdge var21 = var14.getPosition();
    java.awt.geom.Rectangle2D var22 = var14.getBounds();
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
    java.awt.Stroke var36 = null;
    var35.setRadiusGridlineStroke(var36);
    var31.setParent((org.jfree.chart.plot.Plot)var35);
    var31.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge();
    var31.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleAnchor var48 = null;
    java.awt.geom.Point2D var49 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var48);
    var31.zoomDomainAxes(0.0d, (-1.0d), var46, var49);
    var23.zoomDomainAxes(100.0d, Double.NaN, var26, var49);
    org.jfree.chart.plot.PlotState var52 = null;
    org.jfree.chart.plot.PlotRenderingInfo var53 = null;
    var8.draw(var12, var22, var49, var52, var53);
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleAnchor var56 = null;
    java.awt.geom.Point2D var57 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var56);
    org.jfree.chart.plot.PlotState var58 = null;
    org.jfree.chart.ChartRenderingInfo var59 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.plot.PlotRenderingInfo var60 = var59.getPlotInfo();
    var1.draw(var4, var22, var57, var58, var60);
    java.io.ObjectOutputStream var62 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var57, var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = var1.getLabelDistributor();
    double var3 = var1.getLabelLinkMargin();
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    double var5 = var4.getFixedDimension();
    java.awt.Paint var6 = var4.getTickMarkPaint();
    var4.setTickMarkInsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var9 = var4.getLabelInsets();
    var1.setSimpleLabelOffset(var9);
    int var11 = var1.getPieIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
//     var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
//     boolean var27 = var1.equals((java.lang.Object)var12);
//     boolean var28 = var1.getExpandToFitSpace();
//     org.jfree.chart.renderer.xy.XYStepRenderer var29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var29.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var33 = var29.getSeriesPaint(31);
//     boolean var34 = var29.getDrawSeriesLineAsPath();
//     java.awt.Paint var38 = var29.getItemOutlinePaint(10, 1, false);
//     var1.setBackgroundPaint(var38);
//     org.jfree.chart.renderer.xy.XYStepRenderer var41 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var41.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Font var47 = var41.getItemLabelFont(0, 0, false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var48 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var48.setAutoPopulateSeriesPaint(false);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var51, var52, var53, var54);
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var58 = null;
//     org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot(var56, var57, var58);
//     java.awt.Stroke var60 = null;
//     var59.setRadiusGridlineStroke(var60);
//     var55.setParent((org.jfree.chart.plot.Plot)var59);
//     var55.setRangeZeroBaselineVisible(false);
//     java.awt.Paint var65 = var55.getDomainCrosshairPaint();
//     var48.setBaseFillPaint(var65);
//     org.jfree.chart.text.TextFragment var67 = new org.jfree.chart.text.TextFragment("RangeType.FULL", var47, var65);
//     var1.setFont(var47);
//     
//     // Checks the contract:  equals-hashcode on var16 and var59
//     assertTrue("Contract failed: equals-hashcode on var16 and var59", var16.equals(var59) ? var16.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var16
//     assertTrue("Contract failed: equals-hashcode on var59 and var16", var59.equals(var16) ? var59.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(10.0d);
    var0.setTranslateX(2.0d);
    boolean var5 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getFixedDimension();
    java.awt.Paint var2 = var0.getTickMarkPaint();
    var0.setTickMarkInsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var5 = var0.getLabelInsets();
    double var7 = var5.calculateBottomInset(100.0d);
    double var8 = var5.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.0d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var1.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var5 = var1.getSeriesPaint(31);
    org.jfree.chart.labels.ItemLabelPosition var6 = var1.getBaseNegativeItemLabelPosition();
    var0.setBaseNegativeItemLabelPosition(var6);
    var0.setBase(0.0d);
    var0.setDrawBarOutline(true);
    org.jfree.chart.urls.XYURLGenerator var12 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var4.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.renderer.xy.XYStepRenderer var16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var16.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var20 = var16.getSeriesOutlinePaint(31);
//     var4.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var16, true);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.general.DatasetGroup var24 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
//     java.awt.Stroke var34 = null;
//     var33.setRadiusGridlineStroke(var34);
//     var29.setParent((org.jfree.chart.plot.Plot)var33);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     var29.setFixedDomainAxisSpace(var37, false);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var29.setFixedRangeAxisSpace(var40);
//     boolean var42 = var24.equals((java.lang.Object)var29);
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var29.getRangeMarkers(1, var44);
//     java.awt.Image var46 = var29.getBackgroundImage();
//     org.jfree.chart.ui.Library var51 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]", "hi!", "RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     boolean var53 = var51.equals((java.lang.Object)var52);
//     var52.resizeRange2((-1.0d), 10.0d);
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var58 = var57.getFixedDimension();
//     java.awt.Paint var59 = var57.getTickMarkPaint();
//     var57.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.util.RectangleInsets var62 = var57.getLabelInsets();
//     java.awt.Paint var64 = null;
//     var57.setTickLabelPaint((java.lang.Comparable)10.0f, var64);
//     java.awt.Graphics2D var66 = null;
//     org.jfree.chart.axis.AxisState var68 = new org.jfree.chart.axis.AxisState(1.0d);
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     var68.moveCursor(100.0d, var70);
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var74 = var73.getPosition();
//     var73.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var80 = var73.getPosition();
//     java.awt.geom.Rectangle2D var81 = var73.getBounds();
//     org.jfree.data.xy.XYDataset var82 = null;
//     org.jfree.chart.axis.ValueAxis var83 = null;
//     org.jfree.chart.axis.ValueAxis var84 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var85 = null;
//     org.jfree.chart.plot.XYPlot var86 = new org.jfree.chart.plot.XYPlot(var82, var83, var84, var85);
//     org.jfree.data.xy.XYDataset var87 = null;
//     org.jfree.chart.axis.ValueAxis var88 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var89 = null;
//     org.jfree.chart.plot.PolarPlot var90 = new org.jfree.chart.plot.PolarPlot(var87, var88, var89);
//     java.awt.Stroke var91 = null;
//     var90.setRadiusGridlineStroke(var91);
//     var86.setParent((org.jfree.chart.plot.Plot)var90);
//     var86.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var96 = var86.getRangeAxisEdge();
//     java.util.List var97 = var57.refreshTicks(var66, var68, var81, var96);
//     var16.drawDomainGridLine(var23, var29, (org.jfree.chart.axis.ValueAxis)var52, var81, 0.0d);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.util.RectangleEdge var18 = var4.getDomainAxisEdge(31);
//     org.jfree.chart.util.Layer var19 = null;
//     java.util.Collection var20 = var4.getDomainMarkers(var19);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var30 = null;
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot(var28, var29, var30);
//     java.awt.Stroke var32 = null;
//     var31.setRadiusGridlineStroke(var32);
//     var27.setParent((org.jfree.chart.plot.Plot)var31);
//     var27.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var37 = var27.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var40 = null;
//     org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot(var38, var39, var40);
//     java.awt.Stroke var42 = var41.getAngleGridlineStroke();
//     var27.setRangeZeroBaselineStroke(var42);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     var27.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var45, true);
//     boolean var48 = var45.isMinorTickMarksVisible();
//     java.awt.Font var49 = var45.getTickLabelFont();
//     boolean var50 = var45.isInverted();
//     var45.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var53 = null;
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot(var22, (org.jfree.chart.axis.ValueAxis)var45, var53);
//     java.awt.Font var55 = var54.getNoDataMessageFont();
//     org.jfree.chart.LegendItemSource[] var56 = new org.jfree.chart.LegendItemSource[] { var54};
//     var21.setSources(var56);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getEndX((-1), 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis();
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    boolean var6 = var5.isDrawBarOutline();
    org.jfree.chart.renderer.xy.XYStepRenderer var8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var8.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var12 = var8.getSeriesPaint(31);
    boolean var13 = var8.getDrawSeriesLineAsPath();
    java.awt.Paint var17 = var8.getItemOutlinePaint(10, 1, false);
    var5.setSeriesOutlinePaint(31, var17);
    boolean var19 = var4.equals((java.lang.Object)31);
    var4.setMinorTickCount((-1));
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.PolarItemRenderer var29 = null;
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
    java.awt.Stroke var31 = null;
    var30.setRadiusGridlineStroke(var31);
    var26.setParent((org.jfree.chart.plot.Plot)var30);
    var26.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var36 = var26.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.PolarItemRenderer var39 = null;
    org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot(var37, var38, var39);
    java.awt.Stroke var41 = var40.getAngleGridlineStroke();
    var26.setRangeZeroBaselineStroke(var41);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    var26.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var44, true);
    boolean var47 = var44.isMinorTickMarksVisible();
    java.awt.Shape var48 = var44.getRightArrow();
    var4.setRightArrow(var48);
    org.jfree.chart.renderer.xy.XYStepRenderer var50 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var50.setAutoPopulateSeriesPaint(false);
    org.jfree.data.xy.XYDataset var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.PolarItemRenderer var60 = null;
    org.jfree.chart.plot.PolarPlot var61 = new org.jfree.chart.plot.PolarPlot(var58, var59, var60);
    java.awt.Stroke var62 = null;
    var61.setRadiusGridlineStroke(var62);
    var57.setParent((org.jfree.chart.plot.Plot)var61);
    var57.setRangeZeroBaselineVisible(false);
    java.awt.Paint var67 = var57.getDomainCrosshairPaint();
    var50.setBaseFillPaint(var67);
    org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Paint var71 = var70.getPaint();
    boolean var72 = org.jfree.chart.util.PaintUtilities.equal(var67, var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.event.ChartChangeEvent[source=0]", "java.awt.Color[r=0,g=0,b=15]", "October", var48, var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
//     java.awt.Stroke var11 = null;
//     var10.setRadiusGridlineStroke(var11);
//     var6.setParent((org.jfree.chart.plot.Plot)var10);
//     var6.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var16 = var6.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     java.awt.Stroke var21 = var20.getAngleGridlineStroke();
//     var6.setRangeZeroBaselineStroke(var21);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var27 = var24.isMinorTickMarksVisible();
//     java.awt.Font var28 = var24.getTickLabelFont();
//     boolean var29 = var24.isInverted();
//     var24.setMinorTickMarksVisible(false);
//     org.jfree.chart.renderer.PolarItemRenderer var32 = null;
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var24, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=0]", var34);
//     var35.setURLText("December 2014");
//     java.awt.Paint var38 = var35.getPaint();
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var46 = null;
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot(var44, var45, var46);
//     java.awt.Stroke var48 = null;
//     var47.setRadiusGridlineStroke(var48);
//     var43.setParent((org.jfree.chart.plot.Plot)var47);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     java.awt.geom.Point2D var54 = null;
//     var47.zoomDomainAxes(Double.NaN, 0.05d, var53, var54);
//     org.jfree.chart.block.CenterArrangement var56 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var59 = var58.getPosition();
//     var58.setVisible(false);
//     org.jfree.chart.block.BlockFrame var62 = var58.getFrame();
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var65 = var64.getPosition();
//     var64.setVisible(false);
//     org.jfree.chart.block.BlockFrame var68 = var64.getFrame();
//     var58.setFrame(var68);
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.LengthAdjustmentType var72 = var71.getLabelOffsetType();
//     java.awt.Font var73 = var71.getLabelFont();
//     var56.add((org.jfree.chart.block.Block)var58, (java.lang.Object)var73);
//     org.jfree.chart.util.HorizontalAlignment var75 = null;
//     org.jfree.chart.util.VerticalAlignment var76 = null;
//     org.jfree.chart.block.FlowArrangement var79 = new org.jfree.chart.block.FlowArrangement(var75, var76, 0.0d, 1.0d);
//     org.jfree.chart.axis.DateAxis var81 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
//     org.jfree.chart.axis.DateTickUnit var82 = null;
//     var81.setTickUnit(var82, true, false);
//     boolean var86 = var79.equals((java.lang.Object)false);
//     org.jfree.chart.title.LegendTitle var87 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var47, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var79);
//     java.awt.Graphics2D var88 = null;
//     org.jfree.data.Range var89 = null;
//     org.jfree.data.Range var90 = null;
//     org.jfree.chart.block.RectangleConstraint var91 = new org.jfree.chart.block.RectangleConstraint(var89, var90);
//     org.jfree.chart.block.RectangleConstraint var93 = var91.toFixedWidth(100.0d);
//     org.jfree.chart.util.Size2D var94 = var87.arrange(var88, var91);
//     org.jfree.chart.util.RectangleAnchor var95 = var87.getLegendItemGraphicLocation();
//     var35.setTextAnchor(var95);
//     
//     // Checks the contract:  equals-hashcode on var10 and var47
//     assertTrue("Contract failed: equals-hashcode on var10 and var47", var10.equals(var47) ? var10.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var10
//     assertTrue("Contract failed: equals-hashcode on var47 and var10", var47.equals(var10) ? var47.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     var4.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var4.removeDomainMarker(1, (org.jfree.chart.plot.Marker)var19, var20);
//     java.lang.Class var22 = null;
//     java.util.EventListener[] var23 = var19.getListeners(var22);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    var0.setBaseCreateEntities(false);
    java.awt.Stroke var4 = var0.getSeriesStroke(1);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    var0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var6, false);
    java.awt.Paint var9 = var0.getBaseLegendTextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var14 = var4.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     java.awt.Stroke var19 = var18.getAngleGridlineStroke();
//     var4.setRangeZeroBaselineStroke(var19);
//     var4.clearRangeAxes();
//     org.jfree.chart.plot.DrawingSupplier var22 = var4.getDrawingSupplier();
//     org.jfree.data.time.TimeSeries var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
//     org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     java.awt.Stroke var36 = null;
//     var35.setRadiusGridlineStroke(var36);
//     var31.setParent((org.jfree.chart.plot.Plot)var35);
//     var31.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var41 = var31.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     java.awt.Stroke var46 = var45.getAngleGridlineStroke();
//     var31.setRangeZeroBaselineStroke(var46);
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     var31.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var49, true);
//     boolean var52 = var49.isMinorTickMarksVisible();
//     java.awt.Font var53 = var49.getTickLabelFont();
//     boolean var54 = var49.isInverted();
//     org.jfree.chart.renderer.PolarItemRenderer var55 = null;
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var25, (org.jfree.chart.axis.ValueAxis)var49, var55);
//     var4.setDataset(4, (org.jfree.data.xy.XYDataset)var25);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var1 = null;
//     var0.plotChanged(var1);
//     int var3 = var0.getDatasetCount();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     org.jfree.chart.plot.DrawingSupplier var10 = null;
//     var9.setDrawingSupplier(var10, true);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var16 = var15.getPosition();
//     var15.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var22 = var15.getPosition();
//     java.awt.geom.Rectangle2D var23 = var15.getBounds();
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
//     java.awt.Stroke var37 = null;
//     var36.setRadiusGridlineStroke(var37);
//     var32.setParent((org.jfree.chart.plot.Plot)var36);
//     var32.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var42 = var32.getRangeAxisEdge();
//     var32.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleAnchor var49 = null;
//     java.awt.geom.Point2D var50 = org.jfree.chart.util.RectangleAnchor.coordinates(var48, var49);
//     var32.zoomDomainAxes(0.0d, (-1.0d), var47, var50);
//     var24.zoomDomainAxes(100.0d, Double.NaN, var27, var50);
//     org.jfree.chart.plot.PlotState var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var9.draw(var13, var23, var50, var53, var54);
//     var0.panRangeAxes(0.0d, var5, var50);
//     java.util.List var57 = var0.getSubplots();
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var65 = null;
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot(var63, var64, var65);
//     java.awt.Stroke var67 = null;
//     var66.setRadiusGridlineStroke(var67);
//     var62.setParent((org.jfree.chart.plot.Plot)var66);
//     var62.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var72 = var62.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var73 = null;
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var75 = null;
//     org.jfree.chart.plot.PolarPlot var76 = new org.jfree.chart.plot.PolarPlot(var73, var74, var75);
//     java.awt.Stroke var77 = var76.getAngleGridlineStroke();
//     var62.setRangeZeroBaselineStroke(var77);
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     var62.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var80, true);
//     java.awt.Graphics2D var83 = null;
//     java.awt.geom.Rectangle2D var84 = null;
//     java.util.List var85 = null;
//     var62.drawRangeTickBands(var83, var84, var85);
//     var62.setRangeCrosshairValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var89 = var62.getInsets();
//     var0.add(var62);
//     
//     // Checks the contract:  equals-hashcode on var24 and var76
//     assertTrue("Contract failed: equals-hashcode on var24 and var76", var24.equals(var76) ? var24.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var66
//     assertTrue("Contract failed: equals-hashcode on var36 and var66", var36.equals(var66) ? var36.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var36
//     assertTrue("Contract failed: equals-hashcode on var66 and var36", var66.equals(var36) ? var66.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var24
//     assertTrue("Contract failed: equals-hashcode on var76 and var24", var76.equals(var24) ? var76.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)1L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.05d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
//     org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight((-1.0d));
//     org.jfree.chart.util.Size2D var12 = var5.arrange(var6, var9);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 2);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     java.awt.Stroke var9 = null;
//     var8.setRadiusGridlineStroke(var9);
//     var4.setParent((org.jfree.chart.plot.Plot)var8);
//     var4.setRangeZeroBaselineVisible(false);
//     var4.setBackgroundAlpha(1.0f);
//     org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = var17.getPlotInfo();
//     java.awt.geom.Point2D var19 = null;
//     var4.zoomRangeAxes(1.0d, var18, var19, false);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var23 = var22.getFixedDimension();
//     java.awt.Paint var24 = var22.getTickMarkPaint();
//     var22.setTickMarkInsideLength(0.0f);
//     org.jfree.chart.util.RectangleInsets var27 = var22.getLabelInsets();
//     java.awt.Paint var29 = null;
//     var22.setTickLabelPaint((java.lang.Comparable)10.0f, var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.AxisState var33 = new org.jfree.chart.axis.AxisState(1.0d);
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     var33.moveCursor(100.0d, var35);
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var39 = var38.getPosition();
//     var38.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var45 = var38.getPosition();
//     java.awt.geom.Rectangle2D var46 = var38.getBounds();
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var54 = null;
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
//     java.awt.Stroke var56 = null;
//     var55.setRadiusGridlineStroke(var56);
//     var51.setParent((org.jfree.chart.plot.Plot)var55);
//     var51.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var61 = var51.getRangeAxisEdge();
//     java.util.List var62 = var22.refreshTicks(var31, var33, var46, var61);
//     var18.setDataArea(var46);
//     
//     // Checks the contract:  equals-hashcode on var4 and var51
//     assertTrue("Contract failed: equals-hashcode on var4 and var51", var4.equals(var51) ? var4.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var4
//     assertTrue("Contract failed: equals-hashcode on var51 and var4", var51.equals(var4) ? var51.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var55
//     assertTrue("Contract failed: equals-hashcode on var8 and var55", var8.equals(var55) ? var8.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var8
//     assertTrue("Contract failed: equals-hashcode on var55 and var8", var55.equals(var8) ? var55.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined_Domain_XYPlot", var1);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
    org.jfree.data.xy.XYDataItem var6 = var3.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
    org.jfree.data.xy.XYDataItem var9 = var3.addOrUpdate(0.0d, 0.05d);
    org.jfree.data.xy.XYDataItem var12 = var3.addOrUpdate(0.0d, Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var14 = var3.getDataItem(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    var4.setDomainCrosshairLockedOnData(false);
    java.awt.Color var18 = java.awt.Color.getColor("October", 15);
    var4.setDomainMinorGridlinePaint((java.awt.Paint)var18);
    boolean var20 = var4.isSubplot();
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var22.setAutoPopulateSeriesPaint(false);
    java.awt.Paint var26 = var22.getSeriesPaint(31);
    org.jfree.chart.labels.ItemLabelPosition var27 = var22.getBaseNegativeItemLabelPosition();
    var4.setRenderer(31, (org.jfree.chart.renderer.xy.XYItemRenderer)var22);
    org.jfree.chart.ChartRenderingInfo var30 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var31, var32, var33);
    org.jfree.chart.plot.DrawingSupplier var35 = null;
    var34.setDrawingSupplier(var35, true);
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var41 = var40.getPosition();
    var40.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleEdge var47 = var40.getPosition();
    java.awt.geom.Rectangle2D var48 = var40.getBounds();
    org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    org.jfree.data.xy.XYDataset var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.PolarItemRenderer var60 = null;
    org.jfree.chart.plot.PolarPlot var61 = new org.jfree.chart.plot.PolarPlot(var58, var59, var60);
    java.awt.Stroke var62 = null;
    var61.setRadiusGridlineStroke(var62);
    var57.setParent((org.jfree.chart.plot.Plot)var61);
    var57.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var67 = var57.getRangeAxisEdge();
    var57.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.PlotRenderingInfo var72 = null;
    java.awt.geom.Rectangle2D var73 = null;
    org.jfree.chart.util.RectangleAnchor var74 = null;
    java.awt.geom.Point2D var75 = org.jfree.chart.util.RectangleAnchor.coordinates(var73, var74);
    var57.zoomDomainAxes(0.0d, (-1.0d), var72, var75);
    var49.zoomDomainAxes(100.0d, Double.NaN, var52, var75);
    org.jfree.chart.plot.PlotState var78 = null;
    org.jfree.chart.plot.PlotRenderingInfo var79 = null;
    var34.draw(var38, var48, var75, var78, var79);
    var30.setChartArea(var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setSeriesShape(2147483647, (java.awt.Shape)var48, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    var5.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
    java.awt.Stroke var20 = var19.getAngleGridlineStroke();
    var5.setRangeZeroBaselineStroke(var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
    boolean var26 = var23.isMinorTickMarksVisible();
    java.awt.Font var27 = var23.getTickLabelFont();
    org.jfree.data.Range var30 = new org.jfree.data.Range(1.0d, 1.05d);
    var23.setRange(var30, false, false);
    org.jfree.data.Range var34 = null;
    org.jfree.data.Range var35 = null;
    org.jfree.chart.block.RectangleConstraint var36 = new org.jfree.chart.block.RectangleConstraint(var34, var35);
    org.jfree.chart.block.RectangleConstraint var38 = var36.toFixedHeight((-1.0d));
    org.jfree.data.Range var39 = var38.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var40 = var38.getWidthConstraintType();
    java.lang.String var41 = var40.toString();
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=100.0,l=-1.0,b=-1.0,r=100.0]");
    int var45 = var44.getMinorTickCount();
    java.util.TimeZone var46 = var44.getTimeZone();
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
    java.awt.Stroke var56 = null;
    var55.setRadiusGridlineStroke(var56);
    var51.setParent((org.jfree.chart.plot.Plot)var55);
    var51.setRangeZeroBaselineVisible(false);
    org.jfree.chart.util.RectangleEdge var61 = var51.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.PolarItemRenderer var64 = null;
    org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot(var62, var63, var64);
    java.awt.Stroke var66 = var65.getAngleGridlineStroke();
    var51.setRangeZeroBaselineStroke(var66);
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
    var51.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var69, true);
    boolean var72 = var69.isMinorTickMarksVisible();
    java.awt.Font var73 = var69.getTickLabelFont();
    float var74 = var69.getTickMarkOutsideLength();
    org.jfree.data.RangeType var75 = var69.getRangeType();
    org.jfree.data.Range var76 = var69.getDefaultAutoRange();
    var44.setRange(var76);
    org.jfree.chart.block.LengthConstraintType var78 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var79 = new org.jfree.chart.block.RectangleConstraint(0.0d, var30, var40, 0.0d, var76, var78);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var41.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    int var13 = var9.getSeriesCount();
    boolean var14 = var9.isRadiusGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Paint var17 = var16.getPaint();
    var9.setAngleLabelPaint(var17);
    java.awt.Stroke var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.PolarItemRenderer var27 = null;
    org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot(var25, var26, var27);
    java.awt.Stroke var29 = null;
    var28.setRadiusGridlineStroke(var29);
    var24.setParent((org.jfree.chart.plot.Plot)var28);
    int var32 = var28.getSeriesCount();
    boolean var33 = var28.isRadiusGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(1.0d);
    java.awt.Paint var36 = var35.getPaint();
    var28.setAngleLabelPaint(var36);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
    org.jfree.chart.plot.AbstractPieLabelDistributor var40 = var39.getLabelDistributor();
    double var41 = var39.getMinimumArcAngleToDraw();
    java.awt.Stroke var42 = var39.getLabelLinkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(1.0d, var17, var19, var36, var42, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     var5.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var15 = var5.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var16, var17, var18);
//     java.awt.Stroke var20 = var19.getAngleGridlineStroke();
//     var5.setRangeZeroBaselineStroke(var20);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var23, true);
//     boolean var26 = var23.isMinorTickMarksVisible();
//     java.awt.Font var27 = var23.getTickLabelFont();
//     java.awt.Color var30 = java.awt.Color.getColor("October", 15);
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var27, (java.awt.Paint)var30);
//     java.util.List var32 = var31.getLines();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var39, var40, var41);
//     java.awt.Stroke var43 = null;
//     var42.setRadiusGridlineStroke(var43);
//     var38.setParent((org.jfree.chart.plot.Plot)var42);
//     var38.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var48 = var38.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var51 = null;
//     org.jfree.chart.plot.PolarPlot var52 = new org.jfree.chart.plot.PolarPlot(var49, var50, var51);
//     java.awt.Stroke var53 = var52.getAngleGridlineStroke();
//     var38.setRangeZeroBaselineStroke(var53);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     var38.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var56, true);
//     boolean var59 = var56.isMinorTickMarksVisible();
//     java.awt.Font var60 = var56.getTickLabelFont();
//     java.awt.Color var63 = java.awt.Color.getColor("October", 15);
//     org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var60, (java.awt.Paint)var63);
//     java.util.List var65 = var64.getLines();
//     org.jfree.chart.util.HorizontalAlignment var66 = var64.getLineAlignment();
//     var31.setLineAlignment(var66);
//     
//     // Checks the contract:  equals-hashcode on var5 and var38
//     assertTrue("Contract failed: equals-hashcode on var5 and var38", var5.equals(var38) ? var5.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var5
//     assertTrue("Contract failed: equals-hashcode on var38 and var5", var38.equals(var5) ? var38.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var42
//     assertTrue("Contract failed: equals-hashcode on var9 and var42", var9.equals(var42) ? var9.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var9
//     assertTrue("Contract failed: equals-hashcode on var42 and var9", var42.equals(var9) ? var42.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Rotation.CLOCKWISE", var1);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("Pie Plot");

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Stroke var4 = null;
//     var3.setRadiusGridlineStroke(var4);
//     org.jfree.chart.renderer.xy.XYStepRenderer var6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var6.setBaseCreateEntities(true, true);
//     boolean var10 = var6.getAutoPopulateSeriesShape();
//     org.jfree.chart.renderer.xy.XYStepRenderer var11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var11.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var15 = var11.getSeriesOutlinePaint(31);
//     var11.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var26 = null;
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot(var24, var25, var26);
//     java.awt.Stroke var28 = null;
//     var27.setRadiusGridlineStroke(var28);
//     var23.setParent((org.jfree.chart.plot.Plot)var27);
//     var23.setRangeZeroBaselineVisible(false);
//     var11.setPlot(var23);
//     java.awt.Stroke var34 = var23.getRangeGridlineStroke();
//     var6.setBaseOutlineStroke(var34);
//     var3.setRadiusGridlineStroke(var34);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var45 = null;
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var43, var44, var45);
//     java.awt.Stroke var47 = null;
//     var46.setRadiusGridlineStroke(var47);
//     var42.setParent((org.jfree.chart.plot.Plot)var46);
//     var42.setRangeZeroBaselineVisible(false);
//     var42.setBackgroundAlpha(1.0f);
//     org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PlotRenderingInfo var56 = var55.getPlotInfo();
//     java.awt.geom.Point2D var57 = null;
//     var42.zoomRangeAxes(1.0d, var56, var57, false);
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.chart.util.RectangleAnchor var61 = null;
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.RectangleAnchor.coordinates(var60, var61);
//     var3.zoomRangeAxes(90.0d, var56, var62);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     java.lang.Class var2 = null;
//     java.util.EventListener[] var3 = var1.getListeners(var2);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
    var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    java.awt.Stroke var17 = null;
    var16.setRadiusGridlineStroke(var17);
    var12.setParent((org.jfree.chart.plot.Plot)var16);
    var12.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
    boolean var27 = var1.equals((java.lang.Object)var12);
    java.awt.Paint var28 = var1.getPaint();
    org.jfree.chart.util.RectangleInsets var29 = var1.getPadding();
    org.jfree.chart.util.HorizontalAlignment var30 = var1.getTextAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    var4.setRangeZeroBaselineVisible(false);
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.axis.MarkerAxisBand var17 = null;
    var15.setMarkerBand(var17);
    var15.setAutoRangeMinimumSize(100.0d);
    var15.centerRange(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var2 = var1.getPosition();
//     var1.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
//     java.awt.Stroke var17 = null;
//     var16.setRadiusGridlineStroke(var17);
//     var12.setParent((org.jfree.chart.plot.Plot)var16);
//     var12.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var22 = var12.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var12.setRangeAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var12.getDomainAxisEdge(31);
//     boolean var27 = var1.equals((java.lang.Object)var12);
//     boolean var28 = var1.getExpandToFitSpace();
//     org.jfree.chart.renderer.xy.XYStepRenderer var29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var29.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var33 = var29.getSeriesPaint(31);
//     boolean var34 = var29.getDrawSeriesLineAsPath();
//     java.awt.Paint var38 = var29.getItemOutlinePaint(10, 1, false);
//     var1.setBackgroundPaint(var38);
//     java.lang.String var40 = var1.getID();
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var48 = null;
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot(var46, var47, var48);
//     java.awt.Stroke var50 = null;
//     var49.setRadiusGridlineStroke(var50);
//     var45.setParent((org.jfree.chart.plot.Plot)var49);
//     var45.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var55 = var45.getRangeAxisEdge();
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var58 = null;
//     org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot(var56, var57, var58);
//     java.awt.Stroke var60 = var59.getAngleGridlineStroke();
//     var45.setRangeZeroBaselineStroke(var60);
//     org.jfree.chart.util.RectangleInsets var66 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var45.setInsets(var66);
//     double var69 = var66.calculateRightOutset((-1.0d));
//     var1.setPadding(var66);
//     
//     // Checks the contract:  equals-hashcode on var16 and var49
//     assertTrue("Contract failed: equals-hashcode on var16 and var49", var16.equals(var49) ? var16.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var16
//     assertTrue("Contract failed: equals-hashcode on var49 and var16", var49.equals(var16) ? var49.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     double var1 = var0.getFixedDimension();
//     int var2 = var0.getCategoryLabelPositionOffset();
//     java.awt.Paint var4 = null;
//     var0.setTickLabelPaint((java.lang.Comparable)1L, var4);
//     org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets(100.0d, (-1.0d), (-1.0d), 100.0d);
//     var0.setTickLabelInsets(var10);
//     org.jfree.chart.axis.CategoryAnchor var12 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     org.jfree.chart.plot.DrawingSupplier var19 = null;
//     var18.setDrawingSupplier(var19, true);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.RectangleEdge var25 = var24.getPosition();
//     var24.setMargin(100.0d, 10.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var31 = var24.getPosition();
//     java.awt.geom.Rectangle2D var32 = var24.getBounds();
//     org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     java.awt.Stroke var46 = null;
//     var45.setRadiusGridlineStroke(var46);
//     var41.setParent((org.jfree.chart.plot.Plot)var45);
//     var41.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.util.RectangleEdge var51 = var41.getRangeAxisEdge();
//     var41.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleAnchor var58 = null;
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var57, var58);
//     var41.zoomDomainAxes(0.0d, (-1.0d), var56, var59);
//     var33.zoomDomainAxes(100.0d, Double.NaN, var36, var59);
//     org.jfree.chart.plot.PlotState var62 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     var18.draw(var22, var32, var59, var62, var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var72 = null;
//     org.jfree.chart.plot.PolarPlot var73 = new org.jfree.chart.plot.PolarPlot(var70, var71, var72);
//     java.awt.Stroke var74 = null;
//     var73.setRadiusGridlineStroke(var74);
//     var69.setParent((org.jfree.chart.plot.Plot)var73);
//     var69.setRangeZeroBaselineVisible(false);
//     java.awt.Stroke var79 = var69.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     var69.setRangeAxis((org.jfree.chart.axis.ValueAxis)var80);
//     org.jfree.chart.util.RectangleEdge var83 = var69.getDomainAxisEdge(31);
//     double var84 = var0.getCategoryJava2DCoordinate(var12, 0, 0, var32, var83);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    java.awt.Stroke var10 = null;
    var9.setRadiusGridlineStroke(var10);
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.Layer var17 = null;
    boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
    java.awt.Color var22 = java.awt.Color.getColor("October", 15);
    java.awt.color.ColorSpace var23 = var22.getColorSpace();
    var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
    java.lang.Object var26 = var25.clone();
    java.awt.Shape var27 = var25.getShape();
    java.awt.Shape var28 = var25.getLine();
    java.io.ObjectOutputStream var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var28, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
//     java.awt.Stroke var10 = null;
//     var9.setRadiusGridlineStroke(var10);
//     var5.setParent((org.jfree.chart.plot.Plot)var9);
//     java.awt.Stroke var13 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var19 = var5.removeDomainMarker(31, (org.jfree.chart.plot.Marker)var16, var17, true);
//     java.awt.Color var22 = java.awt.Color.getColor("October", 15);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     var5.setDomainZeroBaselinePaint((java.awt.Paint)var22);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("October", (java.awt.Paint)var22);
//     java.lang.Object var26 = var25.clone();
//     var25.setLineVisible(true);
//     java.lang.Comparable var29 = var25.getSeriesKey();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot(var35, var36, var37);
//     java.awt.Stroke var39 = null;
//     var38.setRadiusGridlineStroke(var39);
//     var34.setParent((org.jfree.chart.plot.Plot)var38);
//     var34.setRangeZeroBaselineVisible(false);
//     var34.setBackgroundAlpha(1.0f);
//     java.awt.Graphics2D var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.data.xy.XYSeries var51 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(byte)10, false, false);
//     org.jfree.data.xy.XYDataItem var54 = var51.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)(short)100);
//     org.jfree.data.xy.XYDataItem var57 = var51.addOrUpdate(0.0d, 0.05d);
//     java.util.List var58 = var51.getItems();
//     var34.drawDomainTickBands(var46, var47, var58);
//     org.jfree.chart.renderer.xy.XYStepRenderer var60 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     var60.setAutoPopulateSeriesPaint(false);
//     java.awt.Paint var64 = var60.getSeriesPaint(31);
//     boolean var65 = var60.getDrawSeriesLineAsPath();
//     java.awt.Paint var69 = var60.getItemOutlinePaint(10, 1, false);
//     var34.setDomainGridlinePaint(var69);
//     var25.setLabelPaint(var69);
//     
//     // Checks the contract:  equals-hashcode on var9 and var38
//     assertTrue("Contract failed: equals-hashcode on var9 and var38", var9.equals(var38) ? var9.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var9
//     assertTrue("Contract failed: equals-hashcode on var38 and var9", var38.equals(var9) ? var38.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    java.awt.Stroke var9 = null;
    var8.setRadiusGridlineStroke(var9);
    var4.setParent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedDomainAxisSpace(var12, false);
    var4.setDomainMinorGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
    double var18 = var17.getFixedDimension();
    java.awt.Paint var19 = var17.getTickMarkPaint();
    var17.setTickMarkInsideLength(0.0f);
    org.jfree.chart.util.RectangleInsets var22 = var17.getLabelInsets();
    var4.setInsets(var22, false);
    double var26 = var22.calculateRightOutset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3.0d);

  }

}
