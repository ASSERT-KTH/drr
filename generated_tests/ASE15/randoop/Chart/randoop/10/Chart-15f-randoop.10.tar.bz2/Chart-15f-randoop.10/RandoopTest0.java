
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 0.0f, 1.0d, 1.0f, 10.0f);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("hi!", var1, var2, false);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, 100.0d, 100.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var4.removeAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 10);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     org.jfree.chart.plot.PlotState var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var4.draw(var5, var6, var7, var8, var9);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", var3);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var3.draw(var4, var5, var6, var7, var8);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0d, (-1.0f), 1.0f);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0f, 10.0f, var4, 10.0d, var6);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, 100.0f, (-1.0f), var4, 1.0d, var6);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var3.zoomRangeAxes(1.0d, var9, var10);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

//  public void test25() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == true);
//
//  }
//
  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.axis.TickUnit var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setAngleTickUnit(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var4.zoomDomainAxes(100.0d, var15, var16);
//     org.jfree.chart.plot.Marker var18 = null;
//     boolean var19 = var4.removeDomainMarker(var18);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     org.jfree.chart.plot.PlotState var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var3.draw(var5, var6, var7, var8, var9);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.event.RendererChangeEvent var1 = null;
//     var0.rendererChanged(var1);
//     org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
    java.lang.Object var8 = var7.clone();
    java.util.Iterator var9 = var7.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var4.zoomDomainAxes(100.0d, var15, var16);
    org.jfree.chart.JFreeChart var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Category Plot", var1);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     boolean var8 = var4.removeDomainMarker(0, var6, var7);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.Marker var5 = null;
//     boolean var6 = var4.removeDomainMarker(var5);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)'a', 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var0.setRenderer(var3);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0d, 100.0f, 10.0f);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 100.0f, var4, 0.05d, var6);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1), 10.0d, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    var4.setWeight(10);
    org.jfree.chart.plot.Marker var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var4.removeRangeMarker(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.event.PlotChangeEvent var14 = null;
//     var4.notifyListeners(var14);
//     var4.zoom((-1.0d));
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var4.draw(var5, var6);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 1.0E-8d, var3);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = var16.getDataset();
    java.awt.Stroke var18 = null;
    var16.setRadiusGridlineStroke(var18);
    org.jfree.chart.LegendItemCollection var20 = var16.getLegendItems();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets();
    boolean var22 = var20.equals((java.lang.Object)var21);
    var4.setFixedLegendItems(var20);
    org.jfree.chart.axis.CategoryAnchor var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainGridlinePosition(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", var1, var2, var3);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.plot.PiePlotState var6 = var0.initialise(var1, var2, (org.jfree.chart.plot.PiePlot)var3, (java.lang.Integer)15, var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    var0.setAutoRange(false);
    org.jfree.data.Range var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     org.jfree.chart.LegendItemCollection var7 = null;
//     var6.setFixedLegendItems(var7);
//     var6.setRangeCrosshairVisible(true);
//     var6.configureDomainAxes();
//     org.jfree.chart.plot.Plot var12 = var6.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var14 = var13.getAxisLinePaint();
//     var6.setBackgroundPaint(var14);
//     org.jfree.chart.text.TextMeasurer var17 = null;
//     org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var1, var14, (-1.0f), var17);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.05d, 0.0f, 1.0f);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getUpperMargin();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var7.setRangeCrosshairVisible(true);
    var7.configureDomainAxes();
    org.jfree.chart.plot.Plot var13 = var7.getRootPlot();
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    org.jfree.data.Range var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot(var1);
    org.jfree.chart.ChartColor var6 = new org.jfree.chart.ChartColor(0, 10, 10);
    var2.setAggregatedItemsPaint((java.awt.Paint)var6);
    boolean var8 = var0.equals((java.lang.Object)var6);
    float[] var9 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var10 = var6.getRGBComponents(var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.plot.Marker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var4.removeRangeMarker(255, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.plot.Marker var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var14 = var4.removeRangeMarker(255, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var17.setBackgroundPaint(var25);
    var4.setRangeCrosshairPaint(var25);
    org.jfree.chart.plot.PlotOrientation var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setOrientation(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.Marker var5 = null;
//     org.jfree.chart.util.Layer var6 = null;
//     boolean var7 = var4.removeDomainMarker(var5, var6);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var1 = var0.getAxisLinePaint();
//     double var2 = var0.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var7.setFixedLegendItems(var8);
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var14 = null;
//     var12.setTickLabelFont((java.lang.Comparable)"", var14);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     java.awt.Paint var21 = var20.getRangeGridlinePaint();
//     var12.setTickLabelPaint(var21);
//     java.util.List var23 = var7.getCategoriesForAxis(var12);
//     
//     // Checks the contract:  equals-hashcode on var7 and var20
//     assertTrue("Contract failed: equals-hashcode on var7 and var20", var7.equals(var20) ? var7.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var7
//     assertTrue("Contract failed: equals-hashcode on var20 and var7", var20.equals(var7) ? var20.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var19 = var18.getAxisLinePaint();
    double var20 = var18.getUpperMargin();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    org.jfree.chart.LegendItemCollection var26 = null;
    var25.setFixedLegendItems(var26);
    var25.setRangeCrosshairVisible(true);
    var25.configureDomainAxes();
    org.jfree.chart.plot.Plot var31 = var25.getRootPlot();
    boolean var32 = var18.hasListener((java.util.EventListener)var31);
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, var33);
    boolean var35 = var16.equals((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var3 = var0.getRangeAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setVisible(false);
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var16.setRangeCrosshairVisible(true);
//     var16.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var24 = var16.getDrawingSupplier();
//     java.awt.Stroke var25 = var16.getDomainGridlineStroke();
//     var0.setSeparatorStroke(var25);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    java.awt.Color var1 = java.awt.Color.getColor("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setHorizontalAlignment(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setRangeCrosshairVisible(true);
    var15.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
    boolean var23 = var15.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.plot.Plot var34 = var28.getRootPlot();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    var28.setBackgroundPaint(var36);
    var15.setRangeCrosshairPaint(var36);
    var10.setBackgroundPaint(var36);
    java.awt.Graphics2D var40 = null;
    org.jfree.data.Range var41 = null;
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(var41, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var44 = var10.arrange(var40, var43);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 0.0f, (-1.0f), var4, 1.0d, var6);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.plot.Marker var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var11.removeRangeMarker(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 4);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("Category Plot");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var17.setBackgroundPaint(var25);
    var4.setRangeCrosshairPaint(var25);
    org.jfree.chart.plot.Marker var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var29 = var4.removeRangeMarker(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var12 = var4.removeRangeMarker(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setVisible(false);
    int var4 = var1.getMaximumCategoryLabelLines();
    org.jfree.chart.axis.CategoryLabelPositions var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    org.jfree.chart.axis.TickUnit var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setAngleTickUnit(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.AbstractPieLabelDistributor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-1));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("Multiple Pie Plot");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 10, 10);
    var1.setAggregatedItemsPaint((java.awt.Paint)var5);
    java.lang.Comparable var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAggregatedItemsKey(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getUpperMargin();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var7.setRangeCrosshairVisible(true);
    var7.configureDomainAxes();
    org.jfree.chart.plot.Plot var13 = var7.getRootPlot();
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    var0.setNegativeArrowVisible(false);
    var0.setRangeAboutValue(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.RectangleEdge var5 = var4.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     int var5 = var3.getBackgroundImageAlignment();
//     var3.setAngleGridlinesVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var3.zoomRangeAxes(1.0d, 0.025d, var10, var11);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setVisible(false);
    boolean var4 = var0.equals((java.lang.Object)1);
    boolean var5 = var0.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    double var2 = var0.getDomainCrosshairValue();
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.arrange(var1, var2, var3);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.05d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.chart.util.TableOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataExtractOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Multiple Pie Plot"+ "'", var1.equals("Multiple Pie Plot"));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    org.jfree.chart.LegendItemCollection var7 = null;
    var6.setFixedLegendItems(var7);
    var6.setRangeCrosshairVisible(true);
    var6.configureDomainAxes();
    org.jfree.chart.plot.Plot var12 = var6.getRootPlot();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var14 = var13.getAxisLinePaint();
    var6.setBackgroundPaint(var14);
    org.jfree.chart.event.PlotChangeEvent var16 = null;
    var6.notifyListeners(var16);
    org.jfree.chart.axis.AxisLocation var18 = var6.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-16774646), var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 0.0f, 1.0f, var4);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     org.jfree.chart.plot.PlotState var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.draw(var1, var2, var3, var4, var5);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     var0.setRenderer(0, var5);
//     org.jfree.chart.plot.Marker var7 = null;
//     boolean var8 = var0.removeDomainMarker(var7);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    java.util.List var3 = var0.getAnnotations();
    org.jfree.chart.plot.SeriesRenderingOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var2 = var1.getAxisLinePaint();
//     var1.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.setVisible(false);
//     boolean var9 = var5.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var11.zoomDomainAxes(100.0d, var13, var14, true);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var1 = var0.toString();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var0.createOutsetRectangle(var2, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.chart.ChartColor[r=0,g=10,b=10]", var1);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    java.awt.Paint var7 = var6.getPaint();
    var0.setDomainCrosshairPaint(var7);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var0.setFixedDomainAxisSpace(var9);
    org.jfree.chart.plot.Marker var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    var1.setAggregatedItemsKey((java.lang.Comparable)10.0f);
    org.jfree.chart.util.TableOrder var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var4.zoomRangeAxes((-1.0d), var15, var16);
//     org.jfree.chart.util.RectangleEdge var18 = var4.getDomainAxisEdge();
//     var4.zoom(0.0d);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    java.awt.Font var6 = null;
    var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
    var1.configure();
    var1.setCategoryMargin(0.05d);
    double var11 = var1.getCategoryMargin();
    var1.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var6 = null;
//     var4.setTickLabelFont((java.lang.Comparable)"", var6);
//     java.awt.Font var9 = var4.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("ThreadContext", var9);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var9);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var16.setRangeCrosshairVisible(true);
//     var16.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation(10);
//     boolean var24 = var16.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
//     org.jfree.chart.LegendItemCollection var30 = null;
//     var29.setFixedLegendItems(var30);
//     var29.setRangeCrosshairVisible(true);
//     var29.configureDomainAxes();
//     org.jfree.chart.plot.Plot var35 = var29.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var37 = var36.getAxisLinePaint();
//     var29.setBackgroundPaint(var37);
//     var16.setRangeCrosshairPaint(var37);
//     var11.setBackgroundPaint(var37);
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var37};
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var42.getRangeMarkers(255, var44);
//     org.jfree.chart.util.RectangleEdge var46 = var42.getRangeAxisEdge();
//     double var47 = var42.getRangeCrosshairValue();
//     org.jfree.chart.block.BlockBorder var52 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var55 = null;
//     org.jfree.chart.plot.PolarPlot var56 = new org.jfree.chart.plot.PolarPlot(var53, var54, var55);
//     org.jfree.data.xy.XYDataset var57 = var56.getDataset();
//     int var58 = var56.getBackgroundImageAlignment();
//     java.lang.Object var59 = var56.clone();
//     org.jfree.chart.axis.ValueAxis var60 = var56.getAxis();
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var62 = var61.getTickMarkStroke();
//     var56.setRadiusGridlineStroke(var62);
//     boolean var64 = var52.equals((java.lang.Object)var62);
//     var42.setRangeGridlineStroke(var62);
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var62};
//     org.jfree.chart.block.BlockBorder var71 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot(var72, var73, var74);
//     org.jfree.data.xy.XYDataset var76 = var75.getDataset();
//     int var77 = var75.getBackgroundImageAlignment();
//     java.lang.Object var78 = var75.clone();
//     org.jfree.chart.axis.ValueAxis var79 = var75.getAxis();
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var81 = var80.getTickMarkStroke();
//     var75.setRadiusGridlineStroke(var81);
//     boolean var83 = var71.equals((java.lang.Object)var81);
//     java.awt.Stroke[] var84 = new java.awt.Stroke[] { var81};
//     org.jfree.chart.axis.NumberAxis var85 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var86 = var85.getAxisLinePaint();
//     double var87 = var85.getAutoRangeMinimumSize();
//     java.awt.Shape var88 = var85.getDownArrow();
//     java.awt.Shape[] var89 = new java.awt.Shape[] { var88};
//     org.jfree.chart.plot.DefaultDrawingSupplier var90 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var41, var66, var84, var89);
//     
//     // Checks the contract:  equals-hashcode on var52 and var71
//     assertTrue("Contract failed: equals-hashcode on var52 and var71", var52.equals(var71) ? var52.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var52
//     assertTrue("Contract failed: equals-hashcode on var71 and var52", var71.equals(var52) ? var71.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var75
//     assertTrue("Contract failed: equals-hashcode on var56 and var75", var56.equals(var75) ? var56.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var56
//     assertTrue("Contract failed: equals-hashcode on var75 and var56", var75.equals(var56) ? var75.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var78
//     assertTrue("Contract failed: equals-hashcode on var59 and var78", var59.equals(var78) ? var59.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var59
//     assertTrue("Contract failed: equals-hashcode on var78 and var59", var78.equals(var59) ? var78.hashCode() == var59.hashCode() : true);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var1 = var0.getLabelGap();
    org.jfree.chart.util.Rotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.025d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var3 = null;
//     var1.setTickLabelFont((java.lang.Comparable)"", var3);
//     java.awt.Font var6 = null;
//     var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
//     var1.configure();
//     var1.setCategoryMargin(0.05d);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     java.awt.Paint var22 = var17.getNoDataMessagePaint();
//     boolean var23 = var12.equals((java.lang.Object)var17);
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var25.getRangeMarkers(255, var27);
//     org.jfree.chart.util.RectangleEdge var29 = var25.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     org.jfree.chart.axis.AxisSpace var31 = var1.reserveSpace(var11, (org.jfree.chart.plot.Plot)var17, var24, var29, var30);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    boolean var11 = var0.isNegativeArrowVisible();
    org.jfree.data.Range var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDefaultAutoRange(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var7.getRangeMarkers(var11);
    org.jfree.chart.plot.CategoryMarker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(100, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var1 = var0.getAxisLinePaint();
//     double var2 = var0.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var7.setFixedLegendItems(var8);
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var7.getRangeMarkers(var11);
//     var7.zoom((-1.0d));
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("Category Plot");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     double var12 = var0.getLabelGap();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var19 = null;
//     var17.setTickLabelFont((java.lang.Comparable)"", var19);
//     java.awt.Font var22 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("ThreadContext", var22);
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
//     org.jfree.chart.LegendItemCollection var30 = null;
//     var29.setFixedLegendItems(var30);
//     var29.setRangeCrosshairVisible(true);
//     var29.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var36 = var29.getDomainAxisLocation(10);
//     boolean var37 = var29.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     org.jfree.chart.LegendItemCollection var43 = null;
//     var42.setFixedLegendItems(var43);
//     var42.setRangeCrosshairVisible(true);
//     var42.configureDomainAxes();
//     org.jfree.chart.plot.Plot var48 = var42.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var50 = var49.getAxisLinePaint();
//     var42.setBackgroundPaint(var50);
//     var29.setRangeCrosshairPaint(var50);
//     var24.setBackgroundPaint(var50);
//     java.awt.geom.Rectangle2D var54 = var24.getBounds();
//     org.jfree.chart.plot.RingPlot var55 = new org.jfree.chart.plot.RingPlot();
//     boolean var56 = var55.isCircular();
//     java.awt.Stroke var58 = var55.getSectionOutlineStroke((java.lang.Comparable)1.0E-8d);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.plot.PiePlotState var61 = var0.initialise(var13, var54, (org.jfree.chart.plot.PiePlot)var55, (java.lang.Integer)0, var60);
//     
//     // Checks the contract:  equals-hashcode on var0 and var55
//     assertTrue("Contract failed: equals-hashcode on var0 and var55", var0.equals(var55) ? var0.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var0
//     assertTrue("Contract failed: equals-hashcode on var55 and var0", var55.equals(var0) ? var55.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var4 = null;
//     var2.setTickLabelFont((java.lang.Comparable)"", var4);
//     java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var13 = null;
//     var11.setTickLabelFont((java.lang.Comparable)"", var13);
//     java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
//     var2.setTickLabelFont(var16);
//     org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", var16);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.TextAnchor var22 = null;
//     float var23 = var20.calculateBaselineOffset(var21, var22);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setVisible(false);
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var8 = var7.getAxisLinePaint();
//     double var9 = var7.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     org.jfree.chart.LegendItemCollection var15 = null;
//     var14.setFixedLegendItems(var15);
//     var7.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     java.awt.Shape var18 = var7.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var25 = null;
//     var23.setTickLabelFont((java.lang.Comparable)"", var25);
//     java.awt.Font var28 = var23.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("ThreadContext", var28);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var28);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var35.setRangeCrosshairVisible(true);
//     var35.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var42 = var35.getDomainAxisLocation(10);
//     boolean var43 = var35.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.plot.Plot var54 = var48.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var56 = var55.getAxisLinePaint();
//     var48.setBackgroundPaint(var56);
//     var35.setRangeCrosshairPaint(var56);
//     var30.setBackgroundPaint(var56);
//     java.awt.geom.Rectangle2D var60 = var30.getBounds();
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var63 = null;
//     java.util.Collection var64 = var61.getRangeMarkers(255, var63);
//     org.jfree.chart.util.RectangleEdge var65 = var61.getRangeAxisEdge();
//     double var66 = var7.java2DToValue(1.0E-8d, var60, var65);
//     org.jfree.data.category.CategoryDataset var67 = null;
//     org.jfree.chart.axis.CategoryAxis var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var67, var68, var69, var70);
//     org.jfree.chart.LegendItemCollection var72 = null;
//     var71.setFixedLegendItems(var72);
//     var71.setRangeCrosshairVisible(true);
//     var71.configureDomainAxes();
//     org.jfree.chart.plot.Plot var77 = var71.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var79 = var78.getAxisLinePaint();
//     var71.setBackgroundPaint(var79);
//     org.jfree.chart.event.PlotChangeEvent var81 = null;
//     var71.notifyListeners(var81);
//     org.jfree.chart.util.RectangleEdge var83 = var71.getRangeAxisEdge();
//     double var84 = var1.getCategoryJava2DCoordinate(var4, 10, (-1), var60, var83);
//     
//     // Checks the contract:  equals-hashcode on var48 and var71
//     assertTrue("Contract failed: equals-hashcode on var48 and var71", var48.equals(var71) ? var48.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var48
//     assertTrue("Contract failed: equals-hashcode on var71 and var48", var71.equals(var48) ? var71.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var77
//     assertTrue("Contract failed: equals-hashcode on var54 and var77", var54.equals(var77) ? var54.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var54
//     assertTrue("Contract failed: equals-hashcode on var77 and var54", var77.equals(var54) ? var77.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Stroke var3 = var0.getSectionOutlineStroke((java.lang.Comparable)1.0E-8d);
    double var4 = var0.getInnerSeparatorExtension();
    org.jfree.chart.urls.PieURLGenerator var5 = var0.getLegendLabelURLGenerator();
    org.jfree.chart.util.Rotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    var0.setLabelURL("Multiple Pie Plot");
    java.awt.Shape var4 = var0.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    java.awt.Font var6 = null;
    var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
    var1.clearCategoryLabelToolTips();

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var14 = var13.getAxisLinePaint();
//     var13.setLabelURL("Multiple Pie Plot");
//     var13.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var25 = null;
//     var23.setTickLabelFont((java.lang.Comparable)"", var25);
//     java.awt.Font var28 = var23.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("ThreadContext", var28);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var28);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var35.setRangeCrosshairVisible(true);
//     var35.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var42 = var35.getDomainAxisLocation(10);
//     boolean var43 = var35.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.plot.Plot var54 = var48.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var56 = var55.getAxisLinePaint();
//     var48.setBackgroundPaint(var56);
//     var35.setRangeCrosshairPaint(var56);
//     var30.setBackgroundPaint(var56);
//     java.awt.geom.Rectangle2D var60 = var30.getBounds();
//     var13.setUpArrow((java.awt.Shape)var60);
//     org.jfree.chart.plot.RingPlot var62 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var63, var64, var65, var66);
//     org.jfree.chart.LegendItemCollection var68 = null;
//     var67.setFixedLegendItems(var68);
//     var67.setRangeCrosshairVisible(true);
//     java.awt.Paint var72 = var67.getNoDataMessagePaint();
//     boolean var73 = var62.equals((java.lang.Object)var67);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var74 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var62.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var74);
//     java.lang.Integer var76 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     org.jfree.chart.plot.PiePlotState var78 = var0.initialise(var12, var60, (org.jfree.chart.plot.PiePlot)var62, var76, var77);
//     
//     // Checks the contract:  equals-hashcode on var0 and var62
//     assertTrue("Contract failed: equals-hashcode on var0 and var62", var0.equals(var62) ? var0.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var0
//     assertTrue("Contract failed: equals-hashcode on var62 and var0", var62.equals(var0) ? var62.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var67
//     assertTrue("Contract failed: equals-hashcode on var5 and var67", var5.equals(var67) ? var5.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var5
//     assertTrue("Contract failed: equals-hashcode on var67 and var5", var67.equals(var5) ? var67.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 2.00000001d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var3.handleClick(10, 15, var9);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var3.zoomRangeAxes(90.0d, 0.025d, var13, var14);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    boolean var4 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var9 = var1.createBufferedImage(0, 4, 0, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, (-1.0d));
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.util.Size2D var7 = var2.calculateConstrainedSize(var5);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("UnitType.ABSOLUTE", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    boolean var4 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     int var5 = var3.getBackgroundImageAlignment();
//     java.lang.Object var6 = var3.clone();
//     org.jfree.chart.axis.ValueAxis var7 = var3.getAxis();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var9 = var8.getTickMarkStroke();
//     var3.setRadiusGridlineStroke(var9);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     var3.zoom((-1.0d));
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
//     boolean var9 = var7.equals((java.lang.Object)var8);
//     org.jfree.chart.util.UnitType var10 = var8.getUnitType();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = null;
//     var15.setFixedLegendItems(var16);
//     var15.setRangeCrosshairVisible(true);
//     java.awt.Paint var20 = var15.getNoDataMessagePaint();
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(var8, var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     var26.setRangeCrosshairVisible(true);
//     var26.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var33 = var26.getDomainAxisLocation(10);
//     boolean var34 = var26.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     org.jfree.chart.LegendItemCollection var40 = null;
//     var39.setFixedLegendItems(var40);
//     var39.setRangeCrosshairVisible(true);
//     java.awt.Paint var44 = var39.getNoDataMessagePaint();
//     var26.setRangeCrosshairPaint(var44);
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var8, var44);
//     
//     // Checks the contract:  equals-hashcode on var15 and var39
//     assertTrue("Contract failed: equals-hashcode on var15 and var39", var15.equals(var39) ? var15.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var15
//     assertTrue("Contract failed: equals-hashcode on var39 and var15", var39.equals(var15) ? var39.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var46
//     assertTrue("Contract failed: equals-hashcode on var21 and var46", var21.equals(var46) ? var21.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var21
//     assertTrue("Contract failed: equals-hashcode on var46 and var21", var46.equals(var21) ? var46.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var16 = var15.getAxisLinePaint();
//     var15.setLabelURL("Multiple Pie Plot");
//     var15.resizeRange(0.05d, 0.0d);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     var26.setRangeCrosshairVisible(true);
//     var15.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var13, var14, (org.jfree.chart.axis.ValueAxis)var15, var32);
//     boolean var34 = var33.isRangeCrosshairLockedOnData();
//     org.jfree.chart.plot.PlotOrientation var35 = var33.getOrientation();
//     var4.setOrientation(var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var3 = var2.getAxisLinePaint();
//     double var4 = var2.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     java.awt.Shape var13 = var2.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var20 = null;
//     var18.setTickLabelFont((java.lang.Comparable)"", var20);
//     java.awt.Font var23 = var18.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("ThreadContext", var23);
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var23);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     org.jfree.chart.LegendItemCollection var31 = null;
//     var30.setFixedLegendItems(var31);
//     var30.setRangeCrosshairVisible(true);
//     var30.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var37 = var30.getDomainAxisLocation(10);
//     boolean var38 = var30.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     org.jfree.chart.LegendItemCollection var44 = null;
//     var43.setFixedLegendItems(var44);
//     var43.setRangeCrosshairVisible(true);
//     var43.configureDomainAxes();
//     org.jfree.chart.plot.Plot var49 = var43.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var51 = var50.getAxisLinePaint();
//     var43.setBackgroundPaint(var51);
//     var30.setRangeCrosshairPaint(var51);
//     var25.setBackgroundPaint(var51);
//     java.awt.geom.Rectangle2D var55 = var25.getBounds();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var58 = null;
//     java.util.Collection var59 = var56.getRangeMarkers(255, var58);
//     org.jfree.chart.util.RectangleEdge var60 = var56.getRangeAxisEdge();
//     double var61 = var2.java2DToValue(1.0E-8d, var55, var60);
//     var0.draw(var1, var55);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 0.5f, 10.0f, Double.POSITIVE_INFINITY, 10.0f, 0.5f);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.event.PlotChangeEvent var14 = null;
//     var4.notifyListeners(var14);
//     org.jfree.chart.axis.AxisLocation var16 = var4.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var18 = var4.getRangeAxisForDataset(255);
//     var4.setRangeCrosshairValue(Double.POSITIVE_INFINITY);
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     var4.addRangeMarker(var21, var22);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.StrokeMap var1 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(0, 10, 10);
    var3.setAggregatedItemsPaint((java.awt.Paint)var7);
    boolean var9 = var1.equals((java.lang.Object)var7);
    int var10 = var7.getAlpha();
    java.awt.Stroke var11 = null;
    java.awt.Paint var12 = null;
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var25 = var17.getDrawingSupplier();
    java.awt.Stroke var26 = var17.getDomainGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(90.0d, (java.awt.Paint)var7, var11, var12, var26, 0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0E-8d, 0.025d, 0, (java.lang.Comparable)0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var1 = var0.toString();
    double var2 = var0.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getUpperMargin();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var7.setRangeCrosshairVisible(true);
    var7.configureDomainAxes();
    org.jfree.chart.plot.Plot var13 = var7.getRootPlot();
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    var0.setNegativeArrowVisible(false);
    boolean var17 = var0.isTickLabelsVisible();
    var0.setLowerBound((-1.0d));
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     boolean var12 = var4.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     var17.configureDomainAxes();
//     org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var25 = var24.getAxisLinePaint();
//     var17.setBackgroundPaint(var25);
//     var4.setRangeCrosshairPaint(var25);
//     var4.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = var4.getRendererForDataset(var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var33 = var32.getAxisLinePaint();
//     double var34 = var32.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     org.jfree.chart.LegendItemCollection var40 = null;
//     var39.setFixedLegendItems(var40);
//     var32.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     java.awt.Shape var43 = var32.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var50 = null;
//     var48.setTickLabelFont((java.lang.Comparable)"", var50);
//     java.awt.Font var53 = var48.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("ThreadContext", var53);
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("", var53);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var56, var57, var58, var59);
//     org.jfree.chart.LegendItemCollection var61 = null;
//     var60.setFixedLegendItems(var61);
//     var60.setRangeCrosshairVisible(true);
//     var60.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var67 = var60.getDomainAxisLocation(10);
//     boolean var68 = var60.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var69 = null;
//     org.jfree.chart.axis.CategoryAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var69, var70, var71, var72);
//     org.jfree.chart.LegendItemCollection var74 = null;
//     var73.setFixedLegendItems(var74);
//     var73.setRangeCrosshairVisible(true);
//     var73.configureDomainAxes();
//     org.jfree.chart.plot.Plot var79 = var73.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var81 = var80.getAxisLinePaint();
//     var73.setBackgroundPaint(var81);
//     var60.setRangeCrosshairPaint(var81);
//     var55.setBackgroundPaint(var81);
//     java.awt.geom.Rectangle2D var85 = var55.getBounds();
//     org.jfree.chart.plot.XYPlot var86 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var88 = null;
//     java.util.Collection var89 = var86.getRangeMarkers(255, var88);
//     org.jfree.chart.util.RectangleEdge var90 = var86.getRangeAxisEdge();
//     double var91 = var32.java2DToValue(1.0E-8d, var85, var90);
//     var4.drawOutline(var31, var85);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    var0.setDomainCrosshairValue(2.00000001d);
    var0.setRangeCrosshairLockedOnData(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var16 = var0.getRangeAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("ChartEntity: tooltip = ", "hi!", "hi!", var3, "", "hi!", "hi!");
    var7.setVersion("Category Plot");

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.025d, 8.025d, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     var0.setLabelLinkMargin(100.0d);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     org.jfree.chart.LegendItemCollection var20 = null;
//     var19.setFixedLegendItems(var20);
//     var19.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var19.zoomDomainAxes((-1.0d), 0.0d, var26, var27);
//     boolean var29 = var19.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     java.awt.geom.Point2D var33 = null;
//     var19.zoomRangeAxes(0.025d, 100.0d, var32, var33);
//     java.awt.Paint var35 = var19.getRangeCrosshairPaint();
//     var0.setSectionOutlinePaint((java.lang.Comparable)Double.POSITIVE_INFINITY, var35);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleAnchor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setLegendItemGraphicAnchor(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (byte)1};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 2.00000001d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var3 = var1.getExplodePercent((java.lang.Comparable)(short)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     int var6 = var0.getDomainAxisCount();
//     org.jfree.chart.plot.Marker var7 = null;
//     boolean var8 = var0.removeDomainMarker(var7);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
//     boolean var9 = var7.equals((java.lang.Object)var8);
//     org.jfree.chart.util.UnitType var10 = var8.getUnitType();
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.lang.String var12 = var11.getPlotType();
//     java.awt.Image var13 = var11.getBackgroundImage();
//     org.jfree.chart.LegendItemCollection var14 = var11.getLegendItems();
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var7 and var14
//     assertTrue("Contract failed: equals-hashcode on var7 and var14", var7.equals(var14) ? var7.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var7
//     assertTrue("Contract failed: equals-hashcode on var14 and var7", var14.equals(var7) ? var14.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    double var11 = var10.getHeight();
    java.awt.Font var12 = var10.getFont();
    java.awt.Graphics2D var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var14 = var10.arrange(var13);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
//     org.jfree.data.general.PieDataset var2 = null;
//     java.lang.Comparable var3 = null;
//     java.text.AttributedString var4 = var1.generateAttributedSectionLabel(var2, var3);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("UnitType.ABSOLUTE", var1, 100.0f, 100.0f, var4, 2.00000001d, 1.0f, (-1.0f));
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var9 = null;
//     java.util.Collection var10 = var7.getRangeMarkers(255, var9);
//     org.jfree.chart.util.RectangleEdge var11 = var7.getRangeAxisEdge();
//     double var12 = var7.getRangeCrosshairValue();
//     org.jfree.chart.plot.SeriesRenderingOrder var13 = var7.getSeriesRenderingOrder();
//     var0.setSeriesRenderingOrder(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var1 = var0.getTickMarkStroke();
    var0.setInverted(false);
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.StrokeMap var4 = new org.jfree.chart.StrokeMap();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot(var5);
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var6.setAggregatedItemsPaint((java.awt.Paint)var10);
//     boolean var12 = var4.equals((java.lang.Object)var10);
//     int var13 = var10.getAlpha();
//     java.awt.image.ColorModel var14 = null;
//     java.awt.Rectangle var15 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var21 = null;
//     var19.setTickLabelFont((java.lang.Comparable)"", var21);
//     java.awt.Font var24 = var19.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("ThreadContext", var24);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     org.jfree.chart.LegendItemCollection var32 = null;
//     var31.setFixedLegendItems(var32);
//     var31.setRangeCrosshairVisible(true);
//     var31.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var38 = var31.getDomainAxisLocation(10);
//     boolean var39 = var31.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
//     org.jfree.chart.LegendItemCollection var45 = null;
//     var44.setFixedLegendItems(var45);
//     var44.setRangeCrosshairVisible(true);
//     var44.configureDomainAxes();
//     org.jfree.chart.plot.Plot var50 = var44.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var52 = var51.getAxisLinePaint();
//     var44.setBackgroundPaint(var52);
//     var31.setRangeCrosshairPaint(var52);
//     var26.setBackgroundPaint(var52);
//     java.awt.geom.Rectangle2D var56 = var26.getBounds();
//     java.awt.geom.AffineTransform var57 = null;
//     java.awt.RenderingHints var58 = null;
//     java.awt.PaintContext var59 = var10.createContext(var14, var15, var56, var57, var58);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var62 = null;
//     org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot(var60, var61, var62);
//     org.jfree.data.xy.XYDataset var64 = var63.getDataset();
//     int var65 = var63.getBackgroundImageAlignment();
//     java.lang.Object var66 = var63.clone();
//     org.jfree.chart.axis.ValueAxis var67 = var63.getAxis();
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var69 = var68.getTickMarkStroke();
//     var63.setRadiusGridlineStroke(var69);
//     java.awt.Paint var71 = null;
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot(var72, var73, var74);
//     org.jfree.data.xy.XYDataset var76 = var75.getDataset();
//     java.awt.Stroke var77 = null;
//     var75.setRadiusGridlineStroke(var77);
//     org.jfree.chart.LegendItemCollection var79 = var75.getLegendItems();
//     java.awt.Stroke var80 = var75.getAngleGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var82 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var10, var69, var71, var80, 0.5f);
//     org.jfree.chart.util.Layer var83 = null;
//     boolean var84 = var0.removeRangeMarker(100, (org.jfree.chart.plot.Marker)var82, var83);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getUpperMargin();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var7.setRangeCrosshairVisible(true);
    var7.configureDomainAxes();
    org.jfree.chart.plot.Plot var13 = var7.getRootPlot();
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    var0.setNegativeArrowVisible(false);
    boolean var17 = var0.isTickLabelsVisible();
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDefaultAutoRange(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("{0}", var1, (-1.0f), 10.0f, var4);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 10.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "ChartEntity: tooltip = "};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
//     org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
//     org.jfree.chart.ui.Library[] var2 = var0.getLibraries();
//     org.jfree.chart.ui.Library var3 = null;
//     var0.addLibrary(var3);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    var5.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var12 = var5.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var13 = var5.getDrawingSupplier();
    java.awt.Stroke var14 = var5.getDomainGridlineStroke();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.ChartRenderingInfo var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var20 = var15.createBufferedImage(0, 10, 0, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     org.jfree.chart.LegendItemCollection var16 = null;
//     var15.setFixedLegendItems(var16);
//     var15.setRangeCrosshairVisible(true);
//     var15.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
//     boolean var23 = var15.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     var28.setRangeCrosshairVisible(true);
//     java.awt.Paint var33 = var28.getNoDataMessagePaint();
//     var15.setRangeCrosshairPaint(var33);
//     org.jfree.chart.LegendItemSource[] var35 = new org.jfree.chart.LegendItemSource[] { var15};
//     var10.setSources(var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    var0.addOptionalLibrary("ThreadContext");
    var0.setInfo("UnitType.ABSOLUTE");
    var0.setInfo("Multiple Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    var0.setDomainCrosshairValue(2.00000001d);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var0.setFixedRangeAxisSpace(var13, false);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var21 = null;
    var19.setTickLabelFont((java.lang.Comparable)"", var21);
    java.awt.Font var24 = var19.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("ThreadContext", var24);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
    double var27 = var26.getHeight();
    java.awt.Font var28 = var26.getFont();
    var0.setNoDataMessageFont(var28);
    org.jfree.chart.plot.Marker var30 = null;
    org.jfree.chart.util.Layer var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var30, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getUpperMargin();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var7.setRangeCrosshairVisible(true);
    var7.configureDomainAxes();
    org.jfree.chart.plot.Plot var13 = var7.getRootPlot();
    boolean var14 = var0.hasListener((java.util.EventListener)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(4.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.StrokeMap var1 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(0, 10, 10);
    var3.setAggregatedItemsPaint((java.awt.Paint)var7);
    boolean var9 = var1.equals((java.lang.Object)var7);
    int var10 = var7.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = null;
    var16.setTickLabelFont((java.lang.Comparable)"", var18);
    java.awt.Font var21 = var16.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("ThreadContext", var21);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var21);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation(10);
    boolean var36 = var28.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    var41.setRangeCrosshairVisible(true);
    var41.configureDomainAxes();
    org.jfree.chart.plot.Plot var47 = var41.getRootPlot();
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var49 = var48.getAxisLinePaint();
    var41.setBackgroundPaint(var49);
    var28.setRangeCrosshairPaint(var49);
    var23.setBackgroundPaint(var49);
    java.awt.geom.Rectangle2D var53 = var23.getBounds();
    java.awt.geom.AffineTransform var54 = null;
    java.awt.RenderingHints var55 = null;
    java.awt.PaintContext var56 = var7.createContext(var11, var12, var53, var54, var55);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.renderer.PolarItemRenderer var59 = null;
    org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
    org.jfree.data.xy.XYDataset var61 = var60.getDataset();
    int var62 = var60.getBackgroundImageAlignment();
    java.lang.Object var63 = var60.clone();
    org.jfree.chart.axis.ValueAxis var64 = var60.getAxis();
    org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var66 = var65.getTickMarkStroke();
    var60.setRadiusGridlineStroke(var66);
    java.awt.Paint var68 = null;
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.PolarItemRenderer var71 = null;
    org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
    org.jfree.data.xy.XYDataset var73 = var72.getDataset();
    java.awt.Stroke var74 = null;
    var72.setRadiusGridlineStroke(var74);
    org.jfree.chart.LegendItemCollection var76 = var72.getLegendItems();
    java.awt.Stroke var77 = var72.getAngleGridlineStroke();
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var7, var66, var68, var77, 0.5f);
    org.jfree.chart.util.RectangleAnchor var80 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var79.setLabelAnchor(var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.ABSOLUTE", "Category Plot", var3);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    int var6 = var0.getDomainAxisCount();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    org.jfree.chart.LegendItemCollection var12 = null;
    var11.setFixedLegendItems(var12);
    var11.setRangeCrosshairVisible(true);
    var11.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
    var0.setRangeAxisLocation(var18, false);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    java.awt.geom.Point2D var24 = null;
    var0.zoomRangeAxes((-1.0d), Double.POSITIVE_INFINITY, var23, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     boolean var12 = var4.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     java.awt.Paint var22 = var17.getNoDataMessagePaint();
//     var4.setRangeCrosshairPaint(var22);
//     var4.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var4.addChangeListener(var26);
//     int var28 = var4.getDomainAxisCount();
//     org.jfree.chart.axis.AxisLocation var30 = var4.getRangeAxisLocation((-16774646));
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var34 = var33.getAxisLinePaint();
//     var33.setLabelURL("Multiple Pie Plot");
//     var33.resizeRange(0.05d, 0.0d);
//     org.jfree.data.category.CategoryDataset var40 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
//     org.jfree.chart.LegendItemCollection var45 = null;
//     var44.setFixedLegendItems(var45);
//     var44.setRangeCrosshairVisible(true);
//     var33.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var31, var32, (org.jfree.chart.axis.ValueAxis)var33, var50);
//     boolean var52 = var51.isRangeCrosshairLockedOnData();
//     org.jfree.chart.plot.PlotOrientation var53 = var51.getOrientation();
//     org.jfree.chart.util.RectangleEdge var54 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var30, var53);
//     
//     // Checks the contract:  equals-hashcode on var17 and var44
//     assertTrue("Contract failed: equals-hashcode on var17 and var44", var17.equals(var44) ? var17.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var17
//     assertTrue("Contract failed: equals-hashcode on var44 and var17", var44.equals(var17) ? var44.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(byte)0);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var2 = var0.getLibraries();
    var0.setLicenceName("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var12, var13, var14);
    org.jfree.data.xy.XYDataset var16 = var15.getDataset();
    int var17 = var15.getBackgroundImageAlignment();
    java.lang.Object var18 = var15.clone();
    org.jfree.chart.axis.ValueAxis var19 = var15.getAxis();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var15.setRadiusGridlineStroke(var21);
    java.awt.Stroke var23 = var15.getAngleGridlineStroke();
    var5.setRangeCrosshairStroke(var23);
    org.jfree.chart.axis.AxisLocation var26 = var5.getDomainAxisLocation(255);
    org.jfree.chart.axis.AxisLocation var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setRangeAxisLocation(var27, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.AxisLocation var13 = var11.getRangeAxisLocation(0);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var14, var15, var16);
    org.jfree.data.xy.XYDataset var18 = var17.getDataset();
    java.awt.Stroke var19 = null;
    var17.setRadiusGridlineStroke(var19);
    org.jfree.chart.LegendItemCollection var21 = var17.getLegendItems();
    org.jfree.chart.util.RectangleInsets var22 = new org.jfree.chart.util.RectangleInsets();
    boolean var23 = var21.equals((java.lang.Object)var22);
    var11.setFixedLegendItems(var21);
    org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var26 = null;
    var25.rendererChanged(var26);
    int var28 = var25.getBackgroundImageAlignment();
    org.jfree.chart.event.PlotChangeEvent var29 = null;
    var25.notifyListeners(var29);
    boolean var31 = var21.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.axis.AxisSpace var14 = var4.getFixedRangeAxisSpace();
//     org.jfree.chart.StrokeMap var16 = new org.jfree.chart.StrokeMap();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot(var17);
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var18.setAggregatedItemsPaint((java.awt.Paint)var22);
//     boolean var24 = var16.equals((java.lang.Object)var22);
//     int var25 = var22.getAlpha();
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var33 = null;
//     var31.setTickLabelFont((java.lang.Comparable)"", var33);
//     java.awt.Font var36 = var31.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("ThreadContext", var36);
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var36);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     org.jfree.chart.LegendItemCollection var44 = null;
//     var43.setFixedLegendItems(var44);
//     var43.setRangeCrosshairVisible(true);
//     var43.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var50 = var43.getDomainAxisLocation(10);
//     boolean var51 = var43.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     org.jfree.chart.LegendItemCollection var57 = null;
//     var56.setFixedLegendItems(var57);
//     var56.setRangeCrosshairVisible(true);
//     var56.configureDomainAxes();
//     org.jfree.chart.plot.Plot var62 = var56.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var64 = var63.getAxisLinePaint();
//     var56.setBackgroundPaint(var64);
//     var43.setRangeCrosshairPaint(var64);
//     var38.setBackgroundPaint(var64);
//     java.awt.geom.Rectangle2D var68 = var38.getBounds();
//     java.awt.geom.AffineTransform var69 = null;
//     java.awt.RenderingHints var70 = null;
//     java.awt.PaintContext var71 = var22.createContext(var26, var27, var68, var69, var70);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot(var72, var73, var74);
//     org.jfree.data.xy.XYDataset var76 = var75.getDataset();
//     int var77 = var75.getBackgroundImageAlignment();
//     java.lang.Object var78 = var75.clone();
//     org.jfree.chart.axis.ValueAxis var79 = var75.getAxis();
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var81 = var80.getTickMarkStroke();
//     var75.setRadiusGridlineStroke(var81);
//     java.awt.Paint var83 = null;
//     org.jfree.data.xy.XYDataset var84 = null;
//     org.jfree.chart.axis.ValueAxis var85 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var86 = null;
//     org.jfree.chart.plot.PolarPlot var87 = new org.jfree.chart.plot.PolarPlot(var84, var85, var86);
//     org.jfree.data.xy.XYDataset var88 = var87.getDataset();
//     java.awt.Stroke var89 = null;
//     var87.setRadiusGridlineStroke(var89);
//     org.jfree.chart.LegendItemCollection var91 = var87.getLegendItems();
//     java.awt.Stroke var92 = var87.getAngleGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var94 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var22, var81, var83, var92, 0.5f);
//     org.jfree.chart.util.RectangleInsets var95 = var94.getLabelOffset();
//     org.jfree.chart.util.Layer var96 = null;
//     boolean var97 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var94, var96);
//     
//     // Checks the contract:  equals-hashcode on var4 and var56
//     assertTrue("Contract failed: equals-hashcode on var4 and var56", var4.equals(var56) ? var4.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var4
//     assertTrue("Contract failed: equals-hashcode on var56 and var4", var56.equals(var4) ? var56.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var62
//     assertTrue("Contract failed: equals-hashcode on var10 and var62", var10.equals(var62) ? var10.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var10
//     assertTrue("Contract failed: equals-hashcode on var62 and var10", var62.equals(var10) ? var62.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.StrokeMap var1 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(0, 10, 10);
    var3.setAggregatedItemsPaint((java.awt.Paint)var7);
    boolean var9 = var1.equals((java.lang.Object)var7);
    int var10 = var7.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = null;
    var16.setTickLabelFont((java.lang.Comparable)"", var18);
    java.awt.Font var21 = var16.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("ThreadContext", var21);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var21);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation(10);
    boolean var36 = var28.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    var41.setRangeCrosshairVisible(true);
    var41.configureDomainAxes();
    org.jfree.chart.plot.Plot var47 = var41.getRootPlot();
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var49 = var48.getAxisLinePaint();
    var41.setBackgroundPaint(var49);
    var28.setRangeCrosshairPaint(var49);
    var23.setBackgroundPaint(var49);
    java.awt.geom.Rectangle2D var53 = var23.getBounds();
    java.awt.geom.AffineTransform var54 = null;
    java.awt.RenderingHints var55 = null;
    java.awt.PaintContext var56 = var7.createContext(var11, var12, var53, var54, var55);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.renderer.PolarItemRenderer var59 = null;
    org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
    org.jfree.data.xy.XYDataset var61 = var60.getDataset();
    int var62 = var60.getBackgroundImageAlignment();
    java.lang.Object var63 = var60.clone();
    org.jfree.chart.axis.ValueAxis var64 = var60.getAxis();
    org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var66 = var65.getTickMarkStroke();
    var60.setRadiusGridlineStroke(var66);
    java.awt.Paint var68 = null;
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.PolarItemRenderer var71 = null;
    org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
    org.jfree.data.xy.XYDataset var73 = var72.getDataset();
    java.awt.Stroke var74 = null;
    var72.setRadiusGridlineStroke(var74);
    org.jfree.chart.LegendItemCollection var76 = var72.getLegendItems();
    java.awt.Stroke var77 = var72.getAngleGridlineStroke();
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var7, var66, var68, var77, 0.5f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var79.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
//     boolean var18 = var4.equals((java.lang.Object)100.0d);
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var21 = var20.getAxisLinePaint();
//     double var22 = var20.getUpperMargin();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.LegendItemCollection var28 = null;
//     var27.setFixedLegendItems(var28);
//     var27.setRangeCrosshairVisible(true);
//     var27.configureDomainAxes();
//     org.jfree.chart.plot.Plot var33 = var27.getRootPlot();
//     boolean var34 = var20.hasListener((java.util.EventListener)var33);
//     var20.setNegativeArrowVisible(false);
//     boolean var37 = var20.isTickLabelsVisible();
//     var20.setLowerBound((-1.0d));
//     var4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var20, false);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var4.", var27.equals(var4) == var4.equals(var27));
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("{0}", var1, var2);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, Double.POSITIVE_INFINITY, 0.0d, (-1), (java.lang.Comparable)(short)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    var0.clear();

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    int var13 = var11.getIndexOf(var12);
    java.awt.Paint var14 = null;
    var11.setRangeTickBandPaint(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.chart.ChartColor[r=0,g=10,b=10]", var1, 0.0f, 0.5f, var4, 4.5125d, var6);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 0.2d, 100.0f, 0.0f);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    boolean var11 = var0.isNegativeArrowVisible();
    var0.setAutoRangeMinimumSize(1.0E-8d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("UnitType.ABSOLUTE");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getRangeGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomRangeAxes(0.0d, var7, var8);
//     org.jfree.chart.plot.Marker var10 = null;
//     boolean var11 = var4.removeDomainMarker(var10);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    org.jfree.data.general.PieDataset var2 = null;
    java.lang.String var4 = var1.generateSectionLabel(var2, (java.lang.Comparable)0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 18.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 8.025d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var3 = null;
//     var1.setTickLabelFont((java.lang.Comparable)"", var3);
//     java.awt.Font var6 = null;
//     var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
//     var1.configure();
//     var1.setUpperMargin(0.05d);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.StrokeMap var15 = new org.jfree.chart.StrokeMap();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
//     org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var17.setAggregatedItemsPaint((java.awt.Paint)var21);
//     boolean var23 = var15.equals((java.lang.Object)var21);
//     int var24 = var21.getAlpha();
//     java.awt.image.ColorModel var25 = null;
//     java.awt.Rectangle var26 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var32 = null;
//     var30.setTickLabelFont((java.lang.Comparable)"", var32);
//     java.awt.Font var35 = var30.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("ThreadContext", var35);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("", var35);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     org.jfree.chart.LegendItemCollection var43 = null;
//     var42.setFixedLegendItems(var43);
//     var42.setRangeCrosshairVisible(true);
//     var42.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var49 = var42.getDomainAxisLocation(10);
//     boolean var50 = var42.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     org.jfree.chart.LegendItemCollection var56 = null;
//     var55.setFixedLegendItems(var56);
//     var55.setRangeCrosshairVisible(true);
//     var55.configureDomainAxes();
//     org.jfree.chart.plot.Plot var61 = var55.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var63 = var62.getAxisLinePaint();
//     var55.setBackgroundPaint(var63);
//     var42.setRangeCrosshairPaint(var63);
//     var37.setBackgroundPaint(var63);
//     java.awt.geom.Rectangle2D var67 = var37.getBounds();
//     java.awt.geom.AffineTransform var68 = null;
//     java.awt.RenderingHints var69 = null;
//     java.awt.PaintContext var70 = var21.createContext(var25, var26, var67, var68, var69);
//     org.jfree.data.category.CategoryDataset var71 = null;
//     org.jfree.chart.axis.CategoryAxis var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var74 = null;
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot(var71, var72, var73, var74);
//     org.jfree.chart.LegendItemCollection var76 = null;
//     var75.setFixedLegendItems(var76);
//     var75.setRangeCrosshairVisible(true);
//     java.awt.Paint var80 = var75.getNoDataMessagePaint();
//     var75.setAnchorValue(100.0d);
//     org.jfree.data.category.CategoryDataset var83 = null;
//     org.jfree.chart.axis.CategoryAxis var84 = null;
//     org.jfree.chart.axis.ValueAxis var85 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var86 = null;
//     org.jfree.chart.plot.CategoryPlot var87 = new org.jfree.chart.plot.CategoryPlot(var83, var84, var85, var86);
//     org.jfree.chart.LegendItemCollection var88 = null;
//     var87.setFixedLegendItems(var88);
//     var87.setRangeCrosshairVisible(true);
//     var87.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var94 = var87.getDomainAxisLocation(10);
//     var75.setDomainAxisLocation(var94);
//     org.jfree.chart.util.RectangleEdge var96 = var75.getDomainAxisEdge();
//     double var97 = var1.getCategorySeriesMiddle((java.lang.Comparable)10, (java.lang.Comparable)"Category Plot", var13, 4.5125d, var67, var96);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var4.zoomRangeAxes(0.025d, var14, var15, false);
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var4.rendererChanged(var18);
    org.jfree.data.category.CategoryDataset var21 = var4.getDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    java.util.List var3 = var0.getAnnotations();
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRendererForDataset(var6);
    java.awt.Paint var9 = var0.getQuadrantPaint(0);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setRangeCrosshairVisible(true);
    var15.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
    boolean var23 = var15.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    java.awt.Paint var33 = var28.getNoDataMessagePaint();
    var15.setRangeCrosshairPaint(var33);
    var15.setDomainGridlinesVisible(true);
    org.jfree.chart.event.PlotChangeListener var37 = null;
    var15.addChangeListener(var37);
    int var39 = var15.getDomainAxisCount();
    org.jfree.chart.axis.AxisLocation var41 = var15.getRangeAxisLocation((-16774646));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var41, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 8.025d, false);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.00000001d, 4.0d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     int var5 = var3.getBackgroundImageAlignment();
//     java.lang.Object var6 = var3.clone();
//     org.jfree.chart.axis.ValueAxis var7 = var3.getAxis();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var9 = var8.getTickMarkStroke();
//     var3.setRadiusGridlineStroke(var9);
//     java.awt.Paint var11 = var3.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var3.zoomRangeAxes(0.0d, var13, var14, true);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 0.0d, 10, (java.lang.Comparable)10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     org.jfree.chart.LegendItemCollection var7 = null;
//     var6.setFixedLegendItems(var7);
//     var6.setRangeCrosshairVisible(true);
//     java.awt.Paint var11 = var6.getNoDataMessagePaint();
//     boolean var12 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     java.text.NumberFormat var15 = var13.getNumberFormat();
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     var21.setRangeCrosshairVisible(true);
//     java.awt.Paint var26 = var21.getNoDataMessagePaint();
//     boolean var27 = var16.equals((java.lang.Object)var21);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var16.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var28);
//     java.text.NumberFormat var30 = var28.getNumberFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE", var15, var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var6
//     assertTrue("Contract failed: equals-hashcode on var21 and var6", var21.equals(var6) ? var21.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var28
//     assertTrue("Contract failed: equals-hashcode on var13 and var28", var13.equals(var28) ? var13.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var13
//     assertTrue("Contract failed: equals-hashcode on var28 and var13", var28.equals(var13) ? var28.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
    java.text.AttributedString var3 = null;
    var1.setAttributedLabel(4, var3);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Font var2 = var1.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    var8.setRangeCrosshairVisible(true);
    var8.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var16 = var8.getDrawingSupplier();
    java.awt.Stroke var17 = var8.getDomainGridlineStroke();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", (org.jfree.chart.plot.Plot)var8);
    java.awt.RenderingHints var19 = var18.getRenderingHints();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataExtractOrder(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    org.jfree.data.xy.XYDataset var15 = var14.getDataset();
    int var16 = var14.getBackgroundImageAlignment();
    java.lang.Object var17 = var14.clone();
    org.jfree.chart.axis.ValueAxis var18 = var14.getAxis();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var20 = var19.getTickMarkStroke();
    var14.setRadiusGridlineStroke(var20);
    boolean var22 = var10.equals((java.lang.Object)var20);
    var0.setRangeGridlineStroke(var20);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var0.setDomainCrosshairPaint(var25);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.PolarItemRenderer var29 = null;
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
    org.jfree.data.xy.XYDataset var31 = var30.getDataset();
    int var32 = var30.getBackgroundImageAlignment();
    org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
    var0.setFixedLegendItems(var33);
    org.jfree.chart.plot.DatasetRenderingOrder var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 0.0f, 10.0f, 18.0d, 10.0f, 100.0f);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    java.awt.Stroke var2 = var1.getBorderStroke();
    java.awt.image.BufferedImage var5 = var1.createBufferedImage(255, 255);
    int var6 = var1.getSubtitleCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var7 = var1.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = null;
    var2.setTickLabelFont((java.lang.Comparable)"", var4);
    java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var13 = null;
    var11.setTickLabelFont((java.lang.Comparable)"", var13);
    java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
    var2.setTickLabelFont(var16);
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", var16);
    float var21 = var20.getBaselineOffset();
    java.awt.Font var22 = var20.getFont();
    java.lang.String var23 = var20.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Multiple Pie Plot"+ "'", var23.equals("Multiple Pie Plot"));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    var0.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = var14.getPieChart();
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
    boolean var18 = var15.equals((java.lang.Object)var16);
    var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    org.jfree.chart.util.Rotation var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    java.awt.Stroke var2 = var1.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var5 = var1.createBufferedImage((-16774646), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    java.awt.Stroke var13 = var4.getDomainGridlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var15 = var4.removeAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var4 = var3.getPieChart();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
//     boolean var7 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var11 = null;
//     var9.setTickLabelFont((java.lang.Comparable)"", var11);
//     var9.setFixedDimension(10.0d);
//     var9.setTickMarkOutsideLength(1.0f);
//     java.awt.Stroke var17 = var9.getAxisLineStroke();
//     var4.setBorderStroke(var17);
//     var0.setPieChart(var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeGridlinePaint();
    org.jfree.chart.LegendItemCollection var6 = var4.getFixedLegendItems();
    org.jfree.chart.StrokeMap var9 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 10, 10);
    var11.setAggregatedItemsPaint((java.awt.Paint)var15);
    boolean var17 = var9.equals((java.lang.Object)var15);
    int var18 = var15.getAlpha();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var26 = null;
    var24.setTickLabelFont((java.lang.Comparable)"", var26);
    java.awt.Font var29 = var24.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("ThreadContext", var29);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var29);
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
    org.jfree.chart.LegendItemCollection var37 = null;
    var36.setFixedLegendItems(var37);
    var36.setRangeCrosshairVisible(true);
    var36.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var43 = var36.getDomainAxisLocation(10);
    boolean var44 = var36.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
    org.jfree.chart.LegendItemCollection var50 = null;
    var49.setFixedLegendItems(var50);
    var49.setRangeCrosshairVisible(true);
    var49.configureDomainAxes();
    org.jfree.chart.plot.Plot var55 = var49.getRootPlot();
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var57 = var56.getAxisLinePaint();
    var49.setBackgroundPaint(var57);
    var36.setRangeCrosshairPaint(var57);
    var31.setBackgroundPaint(var57);
    java.awt.geom.Rectangle2D var61 = var31.getBounds();
    java.awt.geom.AffineTransform var62 = null;
    java.awt.RenderingHints var63 = null;
    java.awt.PaintContext var64 = var15.createContext(var19, var20, var61, var62, var63);
    org.jfree.data.xy.XYDataset var65 = null;
    org.jfree.chart.axis.ValueAxis var66 = null;
    org.jfree.chart.renderer.PolarItemRenderer var67 = null;
    org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot(var65, var66, var67);
    org.jfree.data.xy.XYDataset var69 = var68.getDataset();
    int var70 = var68.getBackgroundImageAlignment();
    java.lang.Object var71 = var68.clone();
    org.jfree.chart.axis.ValueAxis var72 = var68.getAxis();
    org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var74 = var73.getTickMarkStroke();
    var68.setRadiusGridlineStroke(var74);
    java.awt.Paint var76 = null;
    org.jfree.data.xy.XYDataset var77 = null;
    org.jfree.chart.axis.ValueAxis var78 = null;
    org.jfree.chart.renderer.PolarItemRenderer var79 = null;
    org.jfree.chart.plot.PolarPlot var80 = new org.jfree.chart.plot.PolarPlot(var77, var78, var79);
    org.jfree.data.xy.XYDataset var81 = var80.getDataset();
    java.awt.Stroke var82 = null;
    var80.setRadiusGridlineStroke(var82);
    org.jfree.chart.LegendItemCollection var84 = var80.getLegendItems();
    java.awt.Stroke var85 = var80.getAngleGridlineStroke();
    org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var15, var74, var76, var85, 0.5f);
    java.awt.Stroke var88 = var87.getStroke();
    org.jfree.chart.util.Layer var89 = null;
    var4.addRangeMarker(15, (org.jfree.chart.plot.Marker)var87, var89);
    org.jfree.chart.util.RectangleAnchor var91 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var87.setLabelAnchor(var91);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    org.jfree.chart.util.Size2D var7 = var2.calculateConstrainedSize(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
    org.jfree.data.xy.XYDataset var12 = var11.getDataset();
    java.awt.Stroke var13 = null;
    var11.setRadiusGridlineStroke(var13);
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var11.rendererChanged(var15);
    org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
    boolean var18 = var6.equals((java.lang.Object)var17);
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Rectangle2D var22 = org.jfree.chart.util.RectangleAnchor.createRectangle(var6, Double.POSITIVE_INFINITY, (-1.0d), var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
    java.awt.Paint[] var17 = null;
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    var22.setRangeCrosshairVisible(true);
    var22.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation(10);
    boolean var30 = var22.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
    org.jfree.chart.LegendItemCollection var36 = null;
    var35.setFixedLegendItems(var36);
    var35.setRangeCrosshairVisible(true);
    var35.configureDomainAxes();
    org.jfree.chart.plot.Plot var41 = var35.getRootPlot();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var43 = var42.getAxisLinePaint();
    var35.setBackgroundPaint(var43);
    var22.setRangeCrosshairPaint(var43);
    java.awt.Paint[] var46 = new java.awt.Paint[] { var43};
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot(var47);
    org.jfree.chart.ChartColor var52 = new org.jfree.chart.ChartColor(0, 10, 10);
    var48.setAggregatedItemsPaint((java.awt.Paint)var52);
    java.awt.Paint[] var54 = new java.awt.Paint[] { var52};
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var56 = var55.getTickMarkStroke();
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var60 = null;
    java.util.Collection var61 = var58.getRangeMarkers(255, var60);
    org.jfree.chart.util.RectangleEdge var62 = var58.getRangeAxisEdge();
    double var63 = var58.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var68 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.PolarItemRenderer var71 = null;
    org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
    org.jfree.data.xy.XYDataset var73 = var72.getDataset();
    int var74 = var72.getBackgroundImageAlignment();
    java.lang.Object var75 = var72.clone();
    org.jfree.chart.axis.ValueAxis var76 = var72.getAxis();
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var78 = var77.getTickMarkStroke();
    var72.setRadiusGridlineStroke(var78);
    boolean var80 = var68.equals((java.lang.Object)var78);
    var58.setRangeGridlineStroke(var78);
    java.awt.Stroke[] var82 = new java.awt.Stroke[] { var78};
    org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var84 = var83.getAxisLinePaint();
    double var85 = var83.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var86 = null;
    org.jfree.chart.axis.CategoryAxis var87 = null;
    org.jfree.chart.axis.ValueAxis var88 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var89 = null;
    org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot(var86, var87, var88, var89);
    org.jfree.chart.LegendItemCollection var91 = null;
    var90.setFixedLegendItems(var91);
    var83.addChangeListener((org.jfree.chart.event.AxisChangeListener)var90);
    java.awt.Shape var94 = var83.getLeftArrow();
    java.awt.Shape[] var95 = new java.awt.Shape[] { var94};
    org.jfree.chart.plot.DefaultDrawingSupplier var96 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var46, var54, var57, var82, var95);
    var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var96);
    java.awt.Shape var98 = var96.getNextShape();
    java.lang.Object var99 = var96.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     boolean var1 = var0.isCircular();
//     java.awt.Paint var2 = var0.getLabelOutlinePaint();
//     org.jfree.chart.ui.BasicProjectInfo var3 = new org.jfree.chart.ui.BasicProjectInfo();
//     org.jfree.chart.ui.Library[] var4 = var3.getOptionalLibraries();
//     var3.setLicenceName("hi!");
//     boolean var7 = var0.equals((java.lang.Object)"hi!");
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var10 = var9.getAxisLinePaint();
//     double var11 = var9.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     java.awt.Shape var20 = var9.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var27 = null;
//     var25.setTickLabelFont((java.lang.Comparable)"", var27);
//     java.awt.Font var30 = var25.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("ThreadContext", var30);
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("", var30);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     org.jfree.chart.LegendItemCollection var38 = null;
//     var37.setFixedLegendItems(var38);
//     var37.setRangeCrosshairVisible(true);
//     var37.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var44 = var37.getDomainAxisLocation(10);
//     boolean var45 = var37.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.LegendItemCollection var51 = null;
//     var50.setFixedLegendItems(var51);
//     var50.setRangeCrosshairVisible(true);
//     var50.configureDomainAxes();
//     org.jfree.chart.plot.Plot var56 = var50.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var58 = var57.getAxisLinePaint();
//     var50.setBackgroundPaint(var58);
//     var37.setRangeCrosshairPaint(var58);
//     var32.setBackgroundPaint(var58);
//     java.awt.geom.Rectangle2D var62 = var32.getBounds();
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var65 = null;
//     java.util.Collection var66 = var63.getRangeMarkers(255, var65);
//     org.jfree.chart.util.RectangleEdge var67 = var63.getRangeAxisEdge();
//     double var68 = var9.java2DToValue(1.0E-8d, var62, var67);
//     org.jfree.chart.plot.RingPlot var69 = new org.jfree.chart.plot.RingPlot();
//     boolean var70 = var69.isCircular();
//     java.awt.Stroke var72 = var69.getSectionOutlineStroke((java.lang.Comparable)1.0E-8d);
//     double var73 = var69.getInnerSeparatorExtension();
//     org.jfree.chart.LegendItemCollection var74 = var69.getLegendItems();
//     java.awt.Paint var75 = var69.getLabelPaint();
//     java.lang.Integer var76 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     org.jfree.chart.plot.PiePlotState var78 = var0.initialise(var8, var62, (org.jfree.chart.plot.PiePlot)var69, var76, var77);
//     
//     // Checks the contract:  equals-hashcode on var0 and var69
//     assertTrue("Contract failed: equals-hashcode on var0 and var69", var0.equals(var69) ? var0.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var0
//     assertTrue("Contract failed: equals-hashcode on var69 and var0", var69.equals(var0) ? var69.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    float[] var4 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(255, 100, 255, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var10 = var5.getRootPlot();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     java.awt.Paint var12 = var11.getItemPaint();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     var17.configureDomainAxes();
//     org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var25 = var24.getAxisLinePaint();
//     var17.setBackgroundPaint(var25);
//     org.jfree.chart.event.PlotChangeEvent var27 = null;
//     var17.notifyListeners(var27);
//     org.jfree.chart.axis.AxisLocation var29 = var17.getRangeAxisLocation();
//     java.awt.Stroke var30 = var17.getRangeGridlineStroke();
//     var17.setAnchorValue(0.0d, false);
//     var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)var17);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     org.jfree.chart.LegendItemCollection var40 = null;
//     var39.setFixedLegendItems(var40);
//     var39.setRangeCrosshairVisible(true);
//     var39.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var46 = var39.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var47 = var39.getDrawingSupplier();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var39.zoomRangeAxes(0.025d, var49, var50, false);
//     org.jfree.chart.LegendItemSource[] var53 = new org.jfree.chart.LegendItemSource[] { var39};
//     var11.setSources(var53);
//     
//     // Checks the contract:  equals-hashcode on var5 and var39
//     assertTrue("Contract failed: equals-hashcode on var5 and var39", var5.equals(var39) ? var5.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var5
//     assertTrue("Contract failed: equals-hashcode on var39 and var5", var39.equals(var5) ? var39.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, Double.POSITIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    int var2 = var1.size();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var9 = null;
    var7.setTickLabelFont((java.lang.Comparable)"", var9);
    java.awt.Font var12 = var7.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("ThreadContext", var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var12);
    java.lang.Object var15 = var14.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set((-16774646), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     boolean var1 = var0.isCircular();
//     java.awt.Paint var2 = var0.getLabelOutlinePaint();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var7.setFixedLegendItems(var8);
//     var7.setRangeCrosshairVisible(true);
//     var7.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var14 = var7.getDomainAxisLocation(10);
//     boolean var15 = var7.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     org.jfree.chart.LegendItemCollection var21 = null;
//     var20.setFixedLegendItems(var21);
//     var20.setRangeCrosshairVisible(true);
//     java.awt.Paint var25 = var20.getNoDataMessagePaint();
//     var7.setRangeCrosshairPaint(var25);
//     var7.setDomainGridlinesVisible(true);
//     var0.setParent((org.jfree.chart.plot.Plot)var7);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     var34.setRangeCrosshairVisible(true);
//     var34.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var42 = var34.getDrawingSupplier();
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var34.getRangeMarkers(var43);
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var34.setFixedDomainAxisSpace(var45);
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
//     org.jfree.chart.LegendItemCollection var52 = null;
//     var51.setFixedLegendItems(var52);
//     var51.setRangeCrosshairVisible(true);
//     var51.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var58 = var51.getDomainAxisLocation(10);
//     boolean var59 = var51.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var60 = null;
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var60, var61, var62, var63);
//     org.jfree.chart.LegendItemCollection var65 = null;
//     var64.setFixedLegendItems(var65);
//     var64.setRangeCrosshairVisible(true);
//     java.awt.Paint var69 = var64.getNoDataMessagePaint();
//     var51.setRangeCrosshairPaint(var69);
//     var51.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.PlotChangeListener var73 = null;
//     var51.addChangeListener(var73);
//     int var75 = var51.getDomainAxisCount();
//     org.jfree.chart.axis.AxisLocation var77 = var51.getRangeAxisLocation((-16774646));
//     var34.setRangeAxisLocation(var77);
//     int var79 = var34.getDomainAxisCount();
//     org.jfree.chart.axis.AxisLocation var80 = var34.getDomainAxisLocation();
//     var7.setDomainAxisLocation(var80);
//     
//     // Checks the contract:  equals-hashcode on var7 and var51
//     assertTrue("Contract failed: equals-hashcode on var7 and var51", var7.equals(var51) ? var7.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var64
//     assertTrue("Contract failed: equals-hashcode on var20 and var64", var20.equals(var64) ? var20.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var7
//     assertTrue("Contract failed: equals-hashcode on var51 and var7", var51.equals(var7) ? var51.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var20
//     assertTrue("Contract failed: equals-hashcode on var64 and var20", var64.equals(var20) ? var64.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    java.awt.Paint var7 = var6.getPaint();
    var0.setDomainCrosshairPaint(var7);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var0.setFixedDomainAxisSpace(var9);
    org.jfree.chart.util.RectangleInsets var11 = var0.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
    java.awt.Stroke var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeCrosshairStroke(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var3 = var2.getAxisLinePaint();
    var2.setLabelURL("Multiple Pie Plot");
    var2.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var13.setFixedLegendItems(var14);
    var13.setRangeCrosshairVisible(true);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var19);
    boolean var21 = var20.isRangeCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var24.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var28.setVisible(false);
    boolean var32 = var28.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var28, var33);
    var28.configure();
    var28.setPositiveArrowVisible(false);
    var20.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    java.awt.Paint var45 = var44.getPaint();
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var20.setQuadrantPaint((-16774646), var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, (-1.0d), 0.5f, 0.0f);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.StrokeMap var16 = new org.jfree.chart.StrokeMap();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot(var17);
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var18.setAggregatedItemsPaint((java.awt.Paint)var22);
//     boolean var24 = var16.equals((java.lang.Object)var22);
//     int var25 = var22.getAlpha();
//     java.awt.image.ColorModel var26 = null;
//     java.awt.Rectangle var27 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var33 = null;
//     var31.setTickLabelFont((java.lang.Comparable)"", var33);
//     java.awt.Font var36 = var31.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("ThreadContext", var36);
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var36);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     org.jfree.chart.LegendItemCollection var44 = null;
//     var43.setFixedLegendItems(var44);
//     var43.setRangeCrosshairVisible(true);
//     var43.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var50 = var43.getDomainAxisLocation(10);
//     boolean var51 = var43.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     org.jfree.chart.LegendItemCollection var57 = null;
//     var56.setFixedLegendItems(var57);
//     var56.setRangeCrosshairVisible(true);
//     var56.configureDomainAxes();
//     org.jfree.chart.plot.Plot var62 = var56.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var64 = var63.getAxisLinePaint();
//     var56.setBackgroundPaint(var64);
//     var43.setRangeCrosshairPaint(var64);
//     var38.setBackgroundPaint(var64);
//     java.awt.geom.Rectangle2D var68 = var38.getBounds();
//     java.awt.geom.AffineTransform var69 = null;
//     java.awt.RenderingHints var70 = null;
//     java.awt.PaintContext var71 = var22.createContext(var26, var27, var68, var69, var70);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot(var72, var73, var74);
//     org.jfree.data.xy.XYDataset var76 = var75.getDataset();
//     int var77 = var75.getBackgroundImageAlignment();
//     java.lang.Object var78 = var75.clone();
//     org.jfree.chart.axis.ValueAxis var79 = var75.getAxis();
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var81 = var80.getTickMarkStroke();
//     var75.setRadiusGridlineStroke(var81);
//     java.awt.Paint var83 = null;
//     org.jfree.data.xy.XYDataset var84 = null;
//     org.jfree.chart.axis.ValueAxis var85 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var86 = null;
//     org.jfree.chart.plot.PolarPlot var87 = new org.jfree.chart.plot.PolarPlot(var84, var85, var86);
//     org.jfree.data.xy.XYDataset var88 = var87.getDataset();
//     java.awt.Stroke var89 = null;
//     var87.setRadiusGridlineStroke(var89);
//     org.jfree.chart.LegendItemCollection var91 = var87.getLegendItems();
//     java.awt.Stroke var92 = var87.getAngleGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var94 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var22, var81, var83, var92, 0.5f);
//     java.awt.Paint var95 = var94.getPaint();
//     org.jfree.chart.util.Layer var96 = null;
//     var4.addRangeMarker(0, (org.jfree.chart.plot.Marker)var94, var96);
//     
//     // Checks the contract:  equals-hashcode on var4 and var56
//     assertTrue("Contract failed: equals-hashcode on var4 and var56", var4.equals(var56) ? var4.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var4
//     assertTrue("Contract failed: equals-hashcode on var56 and var4", var56.equals(var4) ? var56.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var62
//     assertTrue("Contract failed: equals-hashcode on var10 and var62", var10.equals(var62) ? var10.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var10
//     assertTrue("Contract failed: equals-hashcode on var62 and var10", var62.equals(var10) ? var62.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    double var2 = var0.getContentXOffset();
    java.awt.Graphics2D var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var7 = var0.arrange(var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var12, var13, var14);
    org.jfree.data.xy.XYDataset var16 = var15.getDataset();
    int var17 = var15.getBackgroundImageAlignment();
    java.lang.Object var18 = var15.clone();
    org.jfree.chart.axis.ValueAxis var19 = var15.getAxis();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var15.setRadiusGridlineStroke(var21);
    java.awt.Stroke var23 = var15.getAngleGridlineStroke();
    var5.setRangeCrosshairStroke(var23);
    org.jfree.chart.axis.AxisLocation var26 = var5.getDomainAxisLocation(255);
    var5.setRangeCrosshairValue(0.2d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getLabelLinkStroke();
    java.awt.Paint var3 = var0.getSectionOutlinePaint((java.lang.Comparable)0);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot(var4);
    org.jfree.chart.ChartColor var9 = new org.jfree.chart.ChartColor(0, 10, 10);
    var5.setAggregatedItemsPaint((java.awt.Paint)var9);
    java.lang.String var11 = var9.toString();
    var0.setSeparatorPaint((java.awt.Paint)var9);
    int var13 = var9.getGreen();
    int var14 = var9.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=10]"+ "'", var11.equals("org.jfree.chart.ChartColor[r=0,g=10,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainCrosshairStroke(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
    boolean var18 = var4.equals((java.lang.Object)100.0d);
    org.jfree.chart.util.RectangleEdge var20 = var4.getDomainAxisEdge((-1));
    java.lang.String var21 = var20.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleEdge.TOP"+ "'", var21.equals("RectangleEdge.TOP"));

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     int var5 = var3.getBackgroundImageAlignment();
//     double var6 = var3.getMaxRadius();
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Stroke var3 = var0.getSectionOutlineStroke((java.lang.Comparable)1.0E-8d);
    double var4 = var0.getInnerSeparatorExtension();
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    boolean var6 = var0.getSeparatorsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setRangeCrosshairVisible(true);
    var15.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
    boolean var23 = var15.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.plot.Plot var34 = var28.getRootPlot();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    var28.setBackgroundPaint(var36);
    var15.setRangeCrosshairPaint(var36);
    var10.setBackgroundPaint(var36);
    var10.setWidth(0.05d);
    double var42 = var10.getHeight();
    org.jfree.chart.util.VerticalAlignment var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setVerticalAlignment(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    var1.setPieWRadius(18.0d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var10 = null;
    var8.setTickLabelFont((java.lang.Comparable)"", var10);
    java.awt.Font var13 = var8.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var19 = null;
    var17.setTickLabelFont((java.lang.Comparable)"", var19);
    java.awt.Font var22 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("ThreadContext", var22);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
    var8.setTickLabelFont(var22);
    var3.setNoDataMessageFont(var22);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    var3.handleClick(15, 15, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
//     org.jfree.data.Range var4 = org.jfree.data.Range.shift(var0, 2.00000001d);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     java.awt.Stroke var2 = var1.getBorderStroke();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     var1.draw(var3, var4, var5);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
    boolean var9 = var7.equals((java.lang.Object)var8);
    double var11 = var8.calculateTopInset(4.5125d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var16.setRangeCrosshairVisible(true);
//     var16.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var24 = var16.getDrawingSupplier();
//     var4.setDrawingSupplier(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setRangeCrosshairVisible(true);
    var15.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
    boolean var23 = var15.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.plot.Plot var34 = var28.getRootPlot();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    var28.setBackgroundPaint(var36);
    var15.setRangeCrosshairPaint(var36);
    var10.setBackgroundPaint(var36);
    java.awt.geom.Rectangle2D var40 = var10.getBounds();
    org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var42, var43, var44, var45);
    org.jfree.chart.LegendItemCollection var47 = null;
    var46.setFixedLegendItems(var47);
    var46.setRangeCrosshairVisible(true);
    java.awt.Paint var51 = var46.getNoDataMessagePaint();
    boolean var52 = var41.equals((java.lang.Object)var46);
    var41.setLabelLinkMargin(100.0d);
    org.jfree.chart.plot.MultiplePiePlot var55 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var56 = var55.getPieChart();
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var58 = var57.getFixedLegendItems();
    boolean var59 = var56.equals((java.lang.Object)var57);
    var41.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var56);
    var56.setBorderVisible(false);
    var10.addChangeListener((org.jfree.chart.event.TitleChangeListener)var56);
    org.jfree.chart.ui.BasicProjectInfo var65 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var66 = var65.getOptionalLibraries();
    org.jfree.chart.ui.BasicProjectInfo var67 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var68 = var67.getOptionalLibraries();
    var67.setLicenceName("hi!");
    var65.addLibrary((org.jfree.chart.ui.Library)var67);
    org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("Category Plot");
    double var74 = var73.getWidth();
    org.jfree.chart.util.HorizontalAlignment var75 = var73.getHorizontalAlignment();
    boolean var76 = var67.equals((java.lang.Object)var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var56.addSubtitle(100, (org.jfree.chart.title.Title)var73);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("0,0,-2,-2,2,-2,2,-2", var1, var2);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var3 = var2.getAxisLinePaint();
//     double var4 = var2.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     java.awt.Shape var13 = var2.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var20 = null;
//     var18.setTickLabelFont((java.lang.Comparable)"", var20);
//     java.awt.Font var23 = var18.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("ThreadContext", var23);
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var23);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     org.jfree.chart.LegendItemCollection var31 = null;
//     var30.setFixedLegendItems(var31);
//     var30.setRangeCrosshairVisible(true);
//     var30.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var37 = var30.getDomainAxisLocation(10);
//     boolean var38 = var30.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     org.jfree.chart.LegendItemCollection var44 = null;
//     var43.setFixedLegendItems(var44);
//     var43.setRangeCrosshairVisible(true);
//     var43.configureDomainAxes();
//     org.jfree.chart.plot.Plot var49 = var43.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var51 = var50.getAxisLinePaint();
//     var43.setBackgroundPaint(var51);
//     var30.setRangeCrosshairPaint(var51);
//     var25.setBackgroundPaint(var51);
//     java.awt.geom.Rectangle2D var55 = var25.getBounds();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var58 = null;
//     java.util.Collection var59 = var56.getRangeMarkers(255, var58);
//     org.jfree.chart.util.RectangleEdge var60 = var56.getRangeAxisEdge();
//     double var61 = var2.java2DToValue(1.0E-8d, var55, var60);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var63 = var62.getDomainCrosshairPaint();
//     boolean var64 = var62.isDomainCrosshairLockedOnData();
//     java.util.List var65 = var62.getAnnotations();
//     var0.drawRangeTickBands(var1, var55, var65);
//     
//     // Checks the contract:  equals-hashcode on var0 and var56
//     assertTrue("Contract failed: equals-hashcode on var0 and var56", var0.equals(var56) ? var0.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var62
//     assertTrue("Contract failed: equals-hashcode on var0 and var62", var0.equals(var62) ? var0.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var0
//     assertTrue("Contract failed: equals-hashcode on var56 and var0", var56.equals(var0) ? var56.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var62
//     assertTrue("Contract failed: equals-hashcode on var56 and var62", var56.equals(var62) ? var56.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var0
//     assertTrue("Contract failed: equals-hashcode on var62 and var0", var62.equals(var0) ? var62.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var56
//     assertTrue("Contract failed: equals-hashcode on var62 and var56", var62.equals(var56) ? var62.hashCode() == var56.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    var0.setLabelURL("Multiple Pie Plot");
    var0.resizeRange(0.05d, 0.0d);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var12 = null;
    var10.setTickLabelFont((java.lang.Comparable)"", var12);
    java.awt.Font var15 = var10.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("ThreadContext", var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    var22.setRangeCrosshairVisible(true);
    var22.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation(10);
    boolean var30 = var22.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
    org.jfree.chart.LegendItemCollection var36 = null;
    var35.setFixedLegendItems(var36);
    var35.setRangeCrosshairVisible(true);
    var35.configureDomainAxes();
    org.jfree.chart.plot.Plot var41 = var35.getRootPlot();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var43 = var42.getAxisLinePaint();
    var35.setBackgroundPaint(var43);
    var22.setRangeCrosshairPaint(var43);
    var17.setBackgroundPaint(var43);
    java.awt.geom.Rectangle2D var47 = var17.getBounds();
    var0.setUpArrow((java.awt.Shape)var47);
    var0.setRange(0.025d, Double.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, (-1.0f), 100.0f, var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    var0.draw(var6, (-1.0f), 0.0f, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    org.jfree.chart.util.Size2D var7 = var2.calculateConstrainedSize(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot(var8, var9, var10);
    org.jfree.data.xy.XYDataset var12 = var11.getDataset();
    java.awt.Stroke var13 = null;
    var11.setRadiusGridlineStroke(var13);
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var11.rendererChanged(var15);
    org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
    boolean var18 = var6.equals((java.lang.Object)var17);
    var6.setWidth(0.36000000179999997d);
    var6.setWidth(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var10 = var5.getRootPlot();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    java.awt.Paint var12 = var11.getItemPaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var17.setBackgroundPaint(var25);
    org.jfree.chart.event.PlotChangeEvent var27 = null;
    var17.notifyListeners(var27);
    org.jfree.chart.axis.AxisLocation var29 = var17.getRangeAxisLocation();
    java.awt.Stroke var30 = var17.getRangeGridlineStroke();
    var17.setAnchorValue(0.0d, false);
    var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)var17);
    org.jfree.chart.util.RectangleAnchor var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setLegendItemGraphicAnchor(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.AxisLocation var13 = var11.getRangeAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.StrokeMap var1 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot(var2);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(0, 10, 10);
    var3.setAggregatedItemsPaint((java.awt.Paint)var7);
    boolean var9 = var1.equals((java.lang.Object)var7);
    int var10 = var7.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var18 = null;
    var16.setTickLabelFont((java.lang.Comparable)"", var18);
    java.awt.Font var21 = var16.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("ThreadContext", var21);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var21);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation(10);
    boolean var36 = var28.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    var41.setRangeCrosshairVisible(true);
    var41.configureDomainAxes();
    org.jfree.chart.plot.Plot var47 = var41.getRootPlot();
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var49 = var48.getAxisLinePaint();
    var41.setBackgroundPaint(var49);
    var28.setRangeCrosshairPaint(var49);
    var23.setBackgroundPaint(var49);
    java.awt.geom.Rectangle2D var53 = var23.getBounds();
    java.awt.geom.AffineTransform var54 = null;
    java.awt.RenderingHints var55 = null;
    java.awt.PaintContext var56 = var7.createContext(var11, var12, var53, var54, var55);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.renderer.PolarItemRenderer var59 = null;
    org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
    org.jfree.data.xy.XYDataset var61 = var60.getDataset();
    int var62 = var60.getBackgroundImageAlignment();
    java.lang.Object var63 = var60.clone();
    org.jfree.chart.axis.ValueAxis var64 = var60.getAxis();
    org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var66 = var65.getTickMarkStroke();
    var60.setRadiusGridlineStroke(var66);
    java.awt.Paint var68 = null;
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.PolarItemRenderer var71 = null;
    org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
    org.jfree.data.xy.XYDataset var73 = var72.getDataset();
    java.awt.Stroke var74 = null;
    var72.setRadiusGridlineStroke(var74);
    org.jfree.chart.LegendItemCollection var76 = var72.getLegendItems();
    java.awt.Stroke var77 = var72.getAngleGridlineStroke();
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var7, var66, var68, var77, 0.5f);
    java.awt.Paint var80 = var79.getPaint();
    org.jfree.chart.text.TextAnchor var81 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var79.setLabelTextAnchor(var81);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = null;
    var2.setTickLabelFont((java.lang.Comparable)"", var4);
    java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var13 = null;
    var11.setTickLabelFont((java.lang.Comparable)"", var13);
    java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
    var2.setTickLabelFont(var16);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    var24.setRangeCrosshairVisible(true);
    var24.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var31 = var24.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var32 = var24.getDrawingSupplier();
    java.awt.Stroke var33 = var24.getDomainGridlineStroke();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var24, false);
    org.jfree.chart.ui.BasicProjectInfo var37 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var38 = var37.getOptionalLibraries();
    org.jfree.chart.ui.BasicProjectInfo var39 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var40 = var39.getOptionalLibraries();
    var39.setLicenceName("hi!");
    var37.addLibrary((org.jfree.chart.ui.Library)var39);
    org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("Category Plot");
    double var46 = var45.getWidth();
    org.jfree.chart.util.HorizontalAlignment var47 = var45.getHorizontalAlignment();
    boolean var48 = var39.equals((java.lang.Object)var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var35.addSubtitle(1, (org.jfree.chart.title.Title)var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var17.setBackgroundPaint(var25);
    var4.setRangeCrosshairPaint(var25);
    var4.configureRangeAxes();
    org.jfree.chart.axis.ValueAxis var29 = var4.getRangeAxis();
    var4.setBackgroundImageAlignment((-16774646));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    double var11 = var10.getHeight();
    java.awt.Font var12 = var10.getFont();
    double var13 = var10.getWidth();
    java.lang.String var14 = var10.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.TOP", var1, 10.0f, 0.0f, var4, 1.0E-8d, var6);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
    org.jfree.chart.LegendItemCollection var8 = null;
    var7.setFixedLegendItems(var8);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    java.awt.Shape var11 = var0.getLeftArrow();
    var0.setAutoTickUnitSelection(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     var0.clear();
//     org.jfree.chart.block.FlowArrangement var2 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var4, var7);
//     java.lang.Object var9 = var3.clone();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var13 = var12.getAxisLinePaint();
//     var12.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     var16.setVisible(false);
//     boolean var20 = var16.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var21);
//     boolean var23 = var22.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var24 = var22.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var26 = var25.getAxisLinePaint();
//     double var27 = var25.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     org.jfree.chart.LegendItemCollection var33 = null;
//     var32.setFixedLegendItems(var33);
//     var25.addChangeListener((org.jfree.chart.event.AxisChangeListener)var32);
//     java.awt.Shape var36 = var25.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var43 = null;
//     var41.setTickLabelFont((java.lang.Comparable)"", var43);
//     java.awt.Font var46 = var41.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("ThreadContext", var46);
//     org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("", var46);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     org.jfree.chart.LegendItemCollection var54 = null;
//     var53.setFixedLegendItems(var54);
//     var53.setRangeCrosshairVisible(true);
//     var53.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var60 = var53.getDomainAxisLocation(10);
//     boolean var61 = var53.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var62 = null;
//     org.jfree.chart.axis.CategoryAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
//     org.jfree.chart.LegendItemCollection var67 = null;
//     var66.setFixedLegendItems(var67);
//     var66.setRangeCrosshairVisible(true);
//     var66.configureDomainAxes();
//     org.jfree.chart.plot.Plot var72 = var66.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var74 = var73.getAxisLinePaint();
//     var66.setBackgroundPaint(var74);
//     var53.setRangeCrosshairPaint(var74);
//     var48.setBackgroundPaint(var74);
//     java.awt.geom.Rectangle2D var78 = var48.getBounds();
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var81 = null;
//     java.util.Collection var82 = var79.getRangeMarkers(255, var81);
//     org.jfree.chart.util.RectangleEdge var83 = var79.getRangeAxisEdge();
//     double var84 = var25.java2DToValue(1.0E-8d, var78, var83);
//     org.jfree.chart.util.LengthAdjustmentType var85 = null;
//     org.jfree.chart.util.LengthAdjustmentType var86 = null;
//     java.awt.geom.Rectangle2D var87 = var24.createAdjustedRectangle(var78, var85, var86);
//     var3.draw(var10, var87);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);
    org.jfree.chart.event.PlotChangeEvent var3 = null;
    var0.notifyListeners(var3);
    java.lang.String var5 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "WMAP_Plot"+ "'", var5.equals("WMAP_Plot"));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    var0.setAutoRange(false);
    var0.setAxisLineVisible(false);
    boolean var7 = var0.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var10 = var5.getRootPlot();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
//     java.awt.Paint var12 = var11.getItemPaint();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     var17.configureDomainAxes();
//     org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var25 = var24.getAxisLinePaint();
//     var17.setBackgroundPaint(var25);
//     org.jfree.chart.event.PlotChangeEvent var27 = null;
//     var17.notifyListeners(var27);
//     org.jfree.chart.axis.AxisLocation var29 = var17.getRangeAxisLocation();
//     java.awt.Stroke var30 = var17.getRangeGridlineStroke();
//     var17.setAnchorValue(0.0d, false);
//     var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)var17);
//     java.awt.Paint var35 = var11.getItemPaint();
//     java.awt.Font var36 = var11.getItemFont();
//     var11.setPadding(100.0d, 0.0d, 18.0d, 8.025d);
//     org.jfree.chart.util.RectangleInsets var42 = var11.getItemLabelPadding();
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot();
//     boolean var44 = var43.isCircular();
//     var43.setSectionDepth(100.0d);
//     double var47 = var43.getStartAngle();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var52 = null;
//     var50.setTickLabelFont((java.lang.Comparable)"", var52);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     java.awt.Paint var59 = var58.getRangeGridlinePaint();
//     var50.setTickLabelPaint(var59);
//     var43.setSectionOutlinePaint((java.lang.Comparable)0, var59);
//     org.jfree.data.category.CategoryDataset var62 = null;
//     org.jfree.chart.axis.CategoryAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
//     org.jfree.chart.LegendItemCollection var67 = null;
//     var66.setFixedLegendItems(var67);
//     var66.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     java.awt.geom.Point2D var74 = null;
//     var66.zoomDomainAxes((-1.0d), 0.0d, var73, var74);
//     boolean var76 = var66.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     java.awt.geom.Point2D var80 = null;
//     var66.zoomRangeAxes(0.025d, 100.0d, var79, var80);
//     java.awt.Paint var82 = var66.getRangeCrosshairPaint();
//     boolean var83 = var43.equals((java.lang.Object)var66);
//     org.jfree.chart.util.RectangleInsets var84 = var43.getSimpleLabelOffset();
//     double var86 = var84.calculateBottomInset(100.0d);
//     var11.setLegendItemGraphicPadding(var84);
//     
//     // Checks the contract:  equals-hashcode on var5 and var66
//     assertTrue("Contract failed: equals-hashcode on var5 and var66", var5.equals(var66) ? var5.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var5
//     assertTrue("Contract failed: equals-hashcode on var66 and var5", var66.equals(var5) ? var66.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    var0.setLabelURL("Multiple Pie Plot");
    var0.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    org.jfree.chart.LegendItemCollection var12 = null;
    var11.setFixedLegendItems(var12);
    var11.setRangeCrosshairVisible(true);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.String var18 = var17.getPlotType();
    java.awt.Image var19 = var17.getBackgroundImage();
    var11.setParent((org.jfree.chart.plot.Plot)var17);
    java.awt.Paint var21 = var17.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setPieChart(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Multiple Pie Plot"+ "'", var18.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = null;
    var2.setTickLabelFont((java.lang.Comparable)"", var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    java.awt.Paint var11 = var10.getRangeGridlinePaint();
    var2.setTickLabelPaint(var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var14 = var13.getAxisLinePaint();
    var13.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var13, var17);
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    var24.setRangeCrosshairVisible(true);
    java.awt.Paint var29 = var24.getNoDataMessagePaint();
    boolean var30 = var19.equals((java.lang.Object)var24);
    var19.setLabelLinkMargin(100.0d);
    java.awt.Paint var33 = var19.getOutlinePaint();
    java.awt.Paint var34 = var19.getLabelShadowPaint();
    var18.setRangeGridlinePaint(var34);
    var18.setAnchorValue(4.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var4.zoomDomainAxes(100.0d, var15, var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var4.drawBackgroundImage(var18, var19);
//     java.awt.Stroke var21 = var4.getRangeGridlineStroke();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var24 = var23.getAxisLinePaint();
//     var23.setLabelURL("Multiple Pie Plot");
//     var23.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var35 = null;
//     var33.setTickLabelFont((java.lang.Comparable)"", var35);
//     java.awt.Font var38 = var33.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("ThreadContext", var38);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var38);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     org.jfree.chart.LegendItemCollection var46 = null;
//     var45.setFixedLegendItems(var46);
//     var45.setRangeCrosshairVisible(true);
//     var45.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var52 = var45.getDomainAxisLocation(10);
//     boolean var53 = var45.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     org.jfree.chart.LegendItemCollection var59 = null;
//     var58.setFixedLegendItems(var59);
//     var58.setRangeCrosshairVisible(true);
//     var58.configureDomainAxes();
//     org.jfree.chart.plot.Plot var64 = var58.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var66 = var65.getAxisLinePaint();
//     var58.setBackgroundPaint(var66);
//     var45.setRangeCrosshairPaint(var66);
//     var40.setBackgroundPaint(var66);
//     java.awt.geom.Rectangle2D var70 = var40.getBounds();
//     var23.setUpArrow((java.awt.Shape)var70);
//     var4.drawBackground(var22, var70);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    var4.setAnchorValue(100.0d);
    org.jfree.chart.util.RectangleEdge var18 = var4.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var19 = var4.getRangeAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    var4.setRenderer(var20, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var3 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = var4.getDataset();
//     int var6 = var4.getBackgroundImageAlignment();
//     var4.setAngleGridlinesVisible(true);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("0,0,-2,-2,2,-2,2,-2", (org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var4.zoomRangeAxes(18.0d, var11, var12);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    int var5 = var3.getBackgroundImageAlignment();
    java.lang.Object var6 = var3.clone();
    org.jfree.chart.axis.ValueAxis var7 = var3.getAxis();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var9 = var8.getTickMarkStroke();
    var3.setRadiusGridlineStroke(var9);
    org.jfree.data.xy.XYDataset var11 = var3.getDataset();
    float var12 = var3.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "XY Plot", "{0}");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = var4.getFixedLegendItems();
    java.lang.Object var15 = var4.clone();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var18.setLabelAngle(1.0d);
    var4.setDomainAxis(0, var18, true);
    org.jfree.chart.axis.CategoryAxis var24 = var4.getDomainAxis(1);
    org.jfree.chart.axis.CategoryAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainGridlinePosition(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     var0.clear();
//     org.jfree.chart.block.FlowArrangement var2 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var4, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var13 = null;
//     var11.setTickLabelFont((java.lang.Comparable)"", var13);
//     java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var22 = null;
//     var20.setTickLabelFont((java.lang.Comparable)"", var22);
//     java.awt.Font var25 = var20.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("ThreadContext", var25);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("", var25);
//     var11.setTickLabelFont(var25);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var32 = var31.getAxisLinePaint();
//     var31.setLabelURL("Multiple Pie Plot");
//     var31.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var43 = null;
//     var41.setTickLabelFont((java.lang.Comparable)"", var43);
//     java.awt.Font var46 = var41.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("ThreadContext", var46);
//     org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("", var46);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     org.jfree.chart.LegendItemCollection var54 = null;
//     var53.setFixedLegendItems(var54);
//     var53.setRangeCrosshairVisible(true);
//     var53.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var60 = var53.getDomainAxisLocation(10);
//     boolean var61 = var53.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var62 = null;
//     org.jfree.chart.axis.CategoryAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
//     org.jfree.chart.LegendItemCollection var67 = null;
//     var66.setFixedLegendItems(var67);
//     var66.setRangeCrosshairVisible(true);
//     var66.configureDomainAxes();
//     org.jfree.chart.plot.Plot var72 = var66.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var74 = var73.getAxisLinePaint();
//     var66.setBackgroundPaint(var74);
//     var53.setRangeCrosshairPaint(var74);
//     var48.setBackgroundPaint(var74);
//     java.awt.geom.Rectangle2D var78 = var48.getBounds();
//     var31.setUpArrow((java.awt.Shape)var78);
//     org.jfree.chart.plot.XYPlot var80 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var81 = var80.getDomainCrosshairPaint();
//     boolean var82 = var80.isDomainCrosshairLockedOnData();
//     java.util.List var83 = var80.getAnnotations();
//     org.jfree.chart.util.RectangleEdge var84 = var80.getDomainAxisEdge();
//     double var85 = var11.getCategoryStart(100, 10, var78, var84);
//     var3.draw(var9, var78);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    java.lang.String var1 = var0.getVersion();
    org.jfree.chart.ui.Library[] var2 = var0.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     java.awt.Paint var7 = var6.getPaint();
//     var0.setDomainCrosshairPaint(var7);
//     var0.clearRangeAxes();
//     boolean var10 = var0.isDomainZoomable();
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     java.awt.Paint var16 = var15.getPaint();
//     var0.setRangeCrosshairPaint(var16);
//     
//     // Checks the contract:  equals-hashcode on var6 and var15
//     assertTrue("Contract failed: equals-hashcode on var6 and var15", var6.equals(var15) ? var6.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.lang.String var1 = var0.getPlotType();
//     java.awt.Image var2 = var0.getBackgroundImage();
//     org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var9 = null;
//     var7.setTickLabelFont((java.lang.Comparable)"", var9);
//     java.awt.Font var12 = var7.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("ThreadContext", var12);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var12);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
//     org.jfree.chart.LegendItemCollection var20 = null;
//     var19.setFixedLegendItems(var20);
//     var19.setRangeCrosshairVisible(true);
//     var19.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var26 = var19.getDomainAxisLocation(10);
//     boolean var27 = var19.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     org.jfree.chart.LegendItemCollection var33 = null;
//     var32.setFixedLegendItems(var33);
//     var32.setRangeCrosshairVisible(true);
//     var32.configureDomainAxes();
//     org.jfree.chart.plot.Plot var38 = var32.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var40 = var39.getAxisLinePaint();
//     var32.setBackgroundPaint(var40);
//     var19.setRangeCrosshairPaint(var40);
//     var14.setBackgroundPaint(var40);
//     java.awt.geom.Rectangle2D var44 = var14.getBounds();
//     org.jfree.chart.plot.RingPlot var45 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.LegendItemCollection var51 = null;
//     var50.setFixedLegendItems(var51);
//     var50.setRangeCrosshairVisible(true);
//     java.awt.Paint var55 = var50.getNoDataMessagePaint();
//     boolean var56 = var45.equals((java.lang.Object)var50);
//     var45.setLabelLinkMargin(100.0d);
//     org.jfree.chart.plot.MultiplePiePlot var59 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var60 = var59.getPieChart();
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var62 = var61.getFixedLegendItems();
//     boolean var63 = var60.equals((java.lang.Object)var61);
//     var45.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var60);
//     var60.setBorderVisible(false);
//     var14.addChangeListener((org.jfree.chart.event.TitleChangeListener)var60);
//     var0.setPieChart(var60);
//     
//     // Checks the contract:  equals-hashcode on var0 and var59
//     assertTrue("Contract failed: equals-hashcode on var0 and var59", var0.equals(var59) ? var0.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var0
//     assertTrue("Contract failed: equals-hashcode on var59 and var0", var59.equals(var0) ? var59.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var3.rendererChanged(var7);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var3.zoomDomainAxes(10.0d, 0.0d, var11, var12);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = var14.getPieChart();
    java.awt.Stroke var16 = var15.getBorderStroke();
    var3.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    java.awt.Stroke var18 = null;
    var15.setBorderStroke(var18);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var22 = var21.getAxisLinePaint();
    var21.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    var25.setVisible(false);
    boolean var29 = var25.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setTextAntiAlias((java.lang.Object)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var1.setAggregatedItemsPaint((java.awt.Paint)var5);
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
//     org.jfree.chart.LegendItemCollection var13 = null;
//     var12.setFixedLegendItems(var13);
//     var12.setRangeCrosshairVisible(true);
//     java.awt.Paint var17 = var12.getNoDataMessagePaint();
//     boolean var18 = var7.equals((java.lang.Object)var12);
//     var7.setLabelLinkMargin(100.0d);
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var22 = var21.getPieChart();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var24 = var23.getFixedLegendItems();
//     boolean var25 = var22.equals((java.lang.Object)var23);
//     var7.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var22);
//     var22.setBorderVisible(false);
//     var1.setPieChart(var22);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     var22.handleClick(1, 15, var32);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    boolean var14 = var4.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isRangeCrosshairLockedOnData();
    var0.setDomainCrosshairValue(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 2.00000001d};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    var0.setSectionDepth(100.0d);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    boolean var6 = var0.isCircular();
    java.awt.Paint var7 = var0.getLabelBackgroundPaint();
    org.jfree.chart.labels.PieToolTipGenerator var8 = null;
    var0.setToolTipGenerator(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var6 = null;
    var4.setTickLabelFont((java.lang.Comparable)"", var6);
    java.awt.Font var9 = var4.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("ThreadContext", var9);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var9);
    var11.setPadding(1.0E-8d, 0.0d, 0.0d, 10.0d);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    var21.setRangeCrosshairVisible(true);
    var21.configureDomainAxes();
    org.jfree.chart.plot.Plot var27 = var21.getRootPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var29 = var28.getAxisLinePaint();
    var21.setBackgroundPaint(var29);
    org.jfree.chart.event.PlotChangeEvent var31 = null;
    var21.notifyListeners(var31);
    var21.setAnchorValue(100.0d);
    var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)100.0d);
    org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var36);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var43 = null;
    var41.setTickLabelFont((java.lang.Comparable)"", var43);
    java.awt.Font var46 = var41.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("ThreadContext", var46);
    org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("", var46);
    double var49 = var48.getHeight();
    java.awt.Font var50 = var48.getFont();
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var53 = null;
    org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(var53, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var56 = var55.getHeightConstraintType();
    org.jfree.data.Range var58 = null;
    org.jfree.data.Range var59 = null;
    org.jfree.chart.block.RectangleConstraint var61 = new org.jfree.chart.block.RectangleConstraint(var59, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var62 = var61.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint(10.0d, var52, var56, 0.2d, var58, var62);
    var37.add((org.jfree.chart.block.Block)var48, (java.lang.Object)0.2d);
    java.awt.Graphics2D var65 = null;
    org.jfree.chart.block.RectangleConstraint var68 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var69 = var68.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var71 = var69.toFixedHeight(0.025d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var72 = var0.arrange(var37, var65, var69);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var4.zoomRangeAxes(1.05d, var8, var9);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    var1.setTitle("ThreadContext");
    org.jfree.chart.event.ChartChangeListener var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addChangeListener(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var1 = var0.getTickMarkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(18.0d, 1.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    java.awt.Font var6 = null;
    var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
    var1.configure();
    var1.setCategoryMargin(0.05d);
    double var11 = var1.getCategoryMargin();
    org.jfree.chart.ChartColor var16 = new org.jfree.chart.ChartColor(0, 10, 10);
    var1.setTickLabelPaint((java.lang.Comparable)(-1.0d), (java.awt.Paint)var16);
    float[] var21 = new float[] { 100.0f, 1.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var22 = var16.getRGBComponents(var21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainGridlinesVisible();
    var11.setDomainZeroBaselineVisible(false);
    java.awt.Paint var15 = var11.getRangeCrosshairPaint();
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
    org.jfree.chart.LegendItemCollection var21 = null;
    var20.setFixedLegendItems(var21);
    var20.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var25 = var20.getRootPlot();
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
    org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var28 = var27.getLabelLinkStroke();
    java.awt.Paint var30 = var27.getSectionOutlinePaint((java.lang.Comparable)0);
    java.awt.Paint var31 = var27.getLabelPaint();
    var26.setBackgroundPaint(var31);
    java.awt.Paint var33 = var26.getItemPaint();
    var11.setRangeZeroBaselinePaint(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     java.awt.Paint var11 = var10.getItemPaint();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getLegendItemGraphicPadding();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     var17.setRangeCrosshairVisible(true);
//     java.awt.Paint var22 = var17.getNoDataMessagePaint();
//     org.jfree.chart.LegendItemSource[] var23 = new org.jfree.chart.LegendItemSource[] { var17};
//     var10.setSources(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setFixedDimension(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    var1.setMaximumCategoryLabelWidthRatio(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
//     boolean var4 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var8 = null;
//     var6.setTickLabelFont((java.lang.Comparable)"", var8);
//     var6.setFixedDimension(10.0d);
//     var6.setTickMarkOutsideLength(1.0f);
//     java.awt.Stroke var14 = var6.getAxisLineStroke();
//     var1.setBorderStroke(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var18 = var17.getAxisLinePaint();
//     double var19 = var17.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var24.setFixedLegendItems(var25);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
//     java.awt.Shape var28 = var17.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var35 = null;
//     var33.setTickLabelFont((java.lang.Comparable)"", var35);
//     java.awt.Font var38 = var33.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("ThreadContext", var38);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var38);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     org.jfree.chart.LegendItemCollection var46 = null;
//     var45.setFixedLegendItems(var46);
//     var45.setRangeCrosshairVisible(true);
//     var45.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var52 = var45.getDomainAxisLocation(10);
//     boolean var53 = var45.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     org.jfree.chart.LegendItemCollection var59 = null;
//     var58.setFixedLegendItems(var59);
//     var58.setRangeCrosshairVisible(true);
//     var58.configureDomainAxes();
//     org.jfree.chart.plot.Plot var64 = var58.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var66 = var65.getAxisLinePaint();
//     var58.setBackgroundPaint(var66);
//     var45.setRangeCrosshairPaint(var66);
//     var40.setBackgroundPaint(var66);
//     java.awt.geom.Rectangle2D var70 = var40.getBounds();
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var73 = null;
//     java.util.Collection var74 = var71.getRangeMarkers(255, var73);
//     org.jfree.chart.util.RectangleEdge var75 = var71.getRangeAxisEdge();
//     double var76 = var17.java2DToValue(1.0E-8d, var70, var75);
//     java.awt.geom.Point2D var77 = null;
//     org.jfree.chart.ChartRenderingInfo var78 = null;
//     var1.draw(var16, var70, var77, var78);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
//     boolean var18 = var4.equals((java.lang.Object)100.0d);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var21 = var20.getAxisLinePaint();
//     double var22 = var20.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.LegendItemCollection var28 = null;
//     var27.setFixedLegendItems(var28);
//     var20.addChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
//     java.awt.Shape var31 = var20.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var38 = null;
//     var36.setTickLabelFont((java.lang.Comparable)"", var38);
//     java.awt.Font var41 = var36.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("ThreadContext", var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var41);
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var55 = var48.getDomainAxisLocation(10);
//     boolean var56 = var48.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     var61.setRangeCrosshairVisible(true);
//     var61.configureDomainAxes();
//     org.jfree.chart.plot.Plot var67 = var61.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var69 = var68.getAxisLinePaint();
//     var61.setBackgroundPaint(var69);
//     var48.setRangeCrosshairPaint(var69);
//     var43.setBackgroundPaint(var69);
//     java.awt.geom.Rectangle2D var73 = var43.getBounds();
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var76 = null;
//     java.util.Collection var77 = var74.getRangeMarkers(255, var76);
//     org.jfree.chart.util.RectangleEdge var78 = var74.getRangeAxisEdge();
//     double var79 = var20.java2DToValue(1.0E-8d, var73, var78);
//     var4.drawBackground(var19, var73);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     java.awt.Stroke var2 = var1.getBorderStroke();
//     java.awt.image.BufferedImage var5 = var1.createBufferedImage(255, 255);
//     int var6 = var1.getSubtitleCount();
//     java.lang.Object var7 = var1.clone();
//     java.lang.Object var8 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.StrokeMap var4 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot(var5);
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(0, 10, 10);
    var6.setAggregatedItemsPaint((java.awt.Paint)var10);
    boolean var12 = var4.equals((java.lang.Object)var10);
    int var13 = var10.getRGB();
    int var14 = var10.getAlpha();
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(0.0d, 0.05d, 4.0d, Double.POSITIVE_INFINITY, (java.awt.Paint)var10);
    float[] var16 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var17 = var10.getComponents(var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-16774646));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainCrosshairPaint();
//     boolean var2 = var0.isDomainCrosshairLockedOnData();
//     java.util.List var3 = var0.getAnnotations();
//     org.jfree.chart.util.RectangleEdge var4 = var0.getDomainAxisEdge();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = var8.getDataset();
//     java.awt.Stroke var10 = null;
//     var8.setRadiusGridlineStroke(var10);
//     org.jfree.chart.LegendItemCollection var12 = var8.getLegendItems();
//     java.awt.Stroke var13 = var8.getAngleGridlineStroke();
//     var0.setRangeZeroBaselineStroke(var13);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var17 = null;
//     java.util.Collection var18 = var15.getRangeMarkers(255, var17);
//     org.jfree.chart.util.RectangleEdge var19 = var15.getRangeAxisEdge();
//     double var20 = var15.getRangeCrosshairValue();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var26, var27, var28);
//     org.jfree.data.xy.XYDataset var30 = var29.getDataset();
//     int var31 = var29.getBackgroundImageAlignment();
//     java.lang.Object var32 = var29.clone();
//     org.jfree.chart.axis.ValueAxis var33 = var29.getAxis();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var35 = var34.getTickMarkStroke();
//     var29.setRadiusGridlineStroke(var35);
//     boolean var37 = var25.equals((java.lang.Object)var35);
//     var15.setRangeGridlineStroke(var35);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var40 = var39.getAxisLinePaint();
//     var15.setDomainCrosshairPaint(var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
//     org.jfree.data.xy.XYDataset var46 = var45.getDataset();
//     int var47 = var45.getBackgroundImageAlignment();
//     org.jfree.chart.LegendItemCollection var48 = var45.getLegendItems();
//     var15.setFixedLegendItems(var48);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var51 = var50.getAxisLinePaint();
//     double var52 = var50.getAutoRangeMinimumSize();
//     java.awt.Shape var53 = var50.getDownArrow();
//     java.text.NumberFormat var54 = null;
//     var50.setNumberFormatOverride(var54);
//     org.jfree.chart.axis.ValueAxis[] var56 = new org.jfree.chart.axis.ValueAxis[] { var50};
//     var15.setRangeAxes(var56);
//     var0.setDomainAxes(var56);
//     
//     // Checks the contract:  equals-hashcode on var12 and var48
//     assertTrue("Contract failed: equals-hashcode on var12 and var48", var12.equals(var48) ? var12.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var12
//     assertTrue("Contract failed: equals-hashcode on var48 and var12", var48.equals(var12) ? var48.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomRangeAxes(0.0d, var7, var8);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.zoomRangeAxes(4.0d, 0.2d, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    java.awt.Shape var3 = var0.getDownArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var3, "");
    java.lang.String var6 = var5.toString();
    java.lang.String var7 = var5.toString();
    java.awt.Shape var8 = var5.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = "+ "'", var6.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "ChartEntity: tooltip = "+ "'", var7.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    java.awt.Paint var11 = var10.getItemPaint();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var17 = null;
    var15.setTickLabelFont((java.lang.Comparable)"", var17);
    java.awt.Font var20 = var15.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("ThreadContext", var20);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var20);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var26 = null;
    var24.setTickLabelFont((java.lang.Comparable)"", var26);
    java.awt.Font var29 = var24.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var35 = null;
    var33.setTickLabelFont((java.lang.Comparable)"", var35);
    java.awt.Font var38 = var33.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("ThreadContext", var38);
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var38);
    var24.setTickLabelFont(var38);
    var22.setFont(var38);
    var10.setItemFont(var38);
    org.jfree.chart.LegendItemSource[] var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setSources(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryAnchor var1 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     var9.setRangeCrosshairVisible(true);
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var16 = var9.getDomainAxisLocation(10);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var17, var18, var19);
//     org.jfree.data.xy.XYDataset var21 = var20.getDataset();
//     java.awt.Stroke var22 = null;
//     var20.setRadiusGridlineStroke(var22);
//     org.jfree.chart.event.RendererChangeEvent var24 = null;
//     var20.rendererChanged(var24);
//     org.jfree.chart.plot.PlotOrientation var26 = var20.getOrientation();
//     org.jfree.chart.util.RectangleEdge var27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var16, var26);
//     double var28 = var0.getCategoryJava2DCoordinate(var1, (-16774646), 10, var4, var27);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     int var6 = var0.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
//     var0.setRangeAxisLocation(var18, false);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var23 = var22.getAxisLinePaint();
//     var22.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     var26.setVisible(false);
//     boolean var30 = var26.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var31);
//     var26.configure();
//     var26.setVisible(true);
//     int var36 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var26);
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     org.jfree.chart.LegendItemCollection var43 = null;
//     var42.setFixedLegendItems(var43);
//     var42.setRangeCrosshairVisible(true);
//     java.awt.Paint var47 = var42.getNoDataMessagePaint();
//     boolean var48 = var37.equals((java.lang.Object)var42);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var54 = var53.getAxisLinePaint();
//     org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 10.0d, 0.0d, var54);
//     var37.setOutlinePaint(var54);
//     var0.setDomainTickBandPaint(var54);
//     
//     // Checks the contract:  equals-hashcode on var11 and var42
//     assertTrue("Contract failed: equals-hashcode on var11 and var42", var11.equals(var42) ? var11.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var11
//     assertTrue("Contract failed: equals-hashcode on var42 and var11", var42.equals(var11) ? var42.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    var0.setSectionDepth(100.0d);
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var0.setURLGenerator(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var5 = null;
//     var3.setTickLabelFont((java.lang.Comparable)"", var5);
//     java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
//     boolean var13 = var12.isCircular();
//     var12.setSectionDepth(100.0d);
//     double var16 = var12.getStartAngle();
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var21 = null;
//     var19.setTickLabelFont((java.lang.Comparable)"", var21);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     java.awt.Paint var28 = var27.getRangeGridlinePaint();
//     var19.setTickLabelPaint(var28);
//     var12.setSectionOutlinePaint((java.lang.Comparable)0, var28);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var35.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     java.awt.geom.Point2D var43 = null;
//     var35.zoomDomainAxes((-1.0d), 0.0d, var42, var43);
//     boolean var45 = var35.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var35.zoomRangeAxes(0.025d, 100.0d, var48, var49);
//     java.awt.Paint var51 = var35.getRangeCrosshairPaint();
//     boolean var52 = var12.equals((java.lang.Object)var35);
//     org.jfree.chart.util.RectangleInsets var53 = var12.getSimpleLabelOffset();
//     var10.setPadding(var53);
//     double var56 = var53.trimHeight(4.5125d);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     var61.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var66 = var61.getRootPlot();
//     org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     java.awt.Paint var68 = var67.getItemPaint();
//     boolean var69 = var53.equals((java.lang.Object)var67);
//     
//     // Checks the contract:  equals-hashcode on var35 and var61
//     assertTrue("Contract failed: equals-hashcode on var35 and var61", var35.equals(var61) ? var35.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var35
//     assertTrue("Contract failed: equals-hashcode on var61 and var35", var61.equals(var35) ? var61.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var11 = var10.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1, var5, 0.2d, var7, var11);
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     int var6 = var0.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
//     var0.setRangeAxisLocation(var18, false);
//     boolean var21 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var22, var23, var24);
//     org.jfree.data.xy.XYDataset var26 = var25.getDataset();
//     java.awt.Stroke var27 = null;
//     var25.setRadiusGridlineStroke(var27);
//     org.jfree.chart.LegendItemCollection var29 = var25.getLegendItems();
//     org.jfree.chart.event.RendererChangeEvent var30 = null;
//     var25.rendererChanged(var30);
//     org.jfree.chart.text.TextBlock var32 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.TextBlockAnchor var36 = null;
//     var32.draw(var33, (-1.0f), 100.0f, var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.text.TextBlockAnchor var41 = null;
//     var32.draw(var38, 1.0f, 0.0f, var41, 0.5f, (-1.0f), 0.0d);
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var49 = null;
//     java.util.Collection var50 = var47.getRangeMarkers(255, var49);
//     org.jfree.chart.util.RectangleEdge var51 = var47.getRangeAxisEdge();
//     double var52 = var47.getRangeCrosshairValue();
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Point2D var55 = null;
//     var47.zoomRangeAxes(1.0d, var54, var55, false);
//     var47.setDomainCrosshairValue(2.00000001d);
//     org.jfree.chart.axis.AxisSpace var60 = null;
//     var47.setFixedRangeAxisSpace(var60, false);
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var68 = null;
//     var66.setTickLabelFont((java.lang.Comparable)"", var68);
//     java.awt.Font var71 = var66.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("ThreadContext", var71);
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("", var71);
//     double var74 = var73.getHeight();
//     java.awt.Font var75 = var73.getFont();
//     var47.setNoDataMessageFont(var75);
//     org.jfree.chart.axis.CategoryAxis var78 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.data.category.CategoryDataset var79 = null;
//     org.jfree.chart.axis.CategoryAxis var80 = null;
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var82 = null;
//     org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot(var79, var80, var81, var82);
//     org.jfree.chart.LegendItemCollection var84 = null;
//     var83.setFixedLegendItems(var84);
//     var83.setRangeCrosshairVisible(true);
//     java.awt.Paint var88 = var83.getNoDataMessagePaint();
//     var78.setLabelPaint(var88);
//     var32.addLine("hi!", var75, var88);
//     var25.setAngleLabelPaint(var88);
//     var0.setDomainGridlinePaint(var88);
//     
//     // Checks the contract:  equals-hashcode on var11 and var83
//     assertTrue("Contract failed: equals-hashcode on var11 and var83", var11.equals(var83) ? var11.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var11
//     assertTrue("Contract failed: equals-hashcode on var83 and var11", var83.equals(var11) ? var83.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var3.handleClick(10, 15, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = var14.getDataset();
//     java.awt.Stroke var16 = null;
//     var14.setRadiusGridlineStroke(var16);
//     org.jfree.chart.LegendItemCollection var18 = var14.getLegendItems();
//     java.awt.Stroke var19 = var14.getAngleGridlineStroke();
//     var3.setRadiusGridlineStroke(var19);
//     int var21 = var3.getSeriesCount();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var23 = var22.getTickMarkStroke();
//     var22.setInverted(false);
//     var22.setAutoTickUnitSelection(true, false);
//     var22.setLabelAngle(2.00000001d);
//     org.jfree.data.Range var31 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var32, var33, var34);
//     org.jfree.data.xy.XYDataset var36 = var35.getDataset();
//     int var37 = var35.getBackgroundImageAlignment();
//     var35.setRadiusGridlinesVisible(true);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var42 = var41.getAxisLinePaint();
//     double var43 = var41.getUpperMargin();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.plot.Plot var54 = var48.getRootPlot();
//     boolean var55 = var41.hasListener((java.util.EventListener)var54);
//     org.jfree.chart.renderer.PolarItemRenderer var56 = null;
//     org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var40, (org.jfree.chart.axis.ValueAxis)var41, var56);
//     org.jfree.chart.ChartColor var61 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var57.setRadiusGridlinePaint((java.awt.Paint)var61);
//     var35.setAngleGridlinePaint((java.awt.Paint)var61);
//     int var64 = var61.getRed();
//     int var65 = var61.getGreen();
//     var3.setAngleGridlinePaint((java.awt.Paint)var61);
//     
//     // Checks the contract:  equals-hashcode on var3 and var35
//     assertTrue("Contract failed: equals-hashcode on var3 and var35", var3.equals(var35) ? var3.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var3
//     assertTrue("Contract failed: equals-hashcode on var35 and var3", var35.equals(var3) ? var35.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = var4.getFixedLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.mapDatasetToRangeAxis((-16774646), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
//     org.jfree.chart.util.Layer var8 = null;
//     java.util.Collection var9 = var0.getDomainMarkers(0, var8);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var12 = null;
//     java.util.Collection var13 = var10.getRangeMarkers(255, var12);
//     org.jfree.chart.util.RectangleEdge var14 = var10.getRangeAxisEdge();
//     double var15 = var10.getRangeCrosshairValue();
//     int var16 = var10.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     var21.setRangeCrosshairVisible(true);
//     var21.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var28 = var21.getDomainAxisLocation(10);
//     var10.setRangeAxisLocation(var28, false);
//     var0.setRangeAxisLocation(var28, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    java.awt.Paint var22 = var17.getNoDataMessagePaint();
    var4.setRangeCrosshairPaint(var22);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.event.PlotChangeListener var26 = null;
    var4.addChangeListener(var26);
    int var28 = var4.getDomainAxisCount();
    org.jfree.chart.axis.AxisLocation var30 = var4.getRangeAxisLocation((-16774646));
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var34 = var33.toUnconstrainedWidth();
    org.jfree.chart.util.Size2D var37 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    org.jfree.chart.util.Size2D var38 = var33.calculateConstrainedSize(var37);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.PolarItemRenderer var41 = null;
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var39, var40, var41);
    org.jfree.data.xy.XYDataset var43 = var42.getDataset();
    java.awt.Stroke var44 = null;
    var42.setRadiusGridlineStroke(var44);
    org.jfree.chart.event.RendererChangeEvent var46 = null;
    var42.rendererChanged(var46);
    org.jfree.chart.plot.PlotOrientation var48 = var42.getOrientation();
    boolean var49 = var37.equals((java.lang.Object)var48);
    org.jfree.chart.util.RectangleEdge var50 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var30, var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    java.lang.Object var11 = var10.clone();
    var10.setID("XY Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    java.lang.String var2 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    var1.setVisible(false);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var5 = var4.getTickMarkStroke();
    var4.setInverted(false);
    var4.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     boolean var1 = var0.isCircular();
//     java.awt.Paint var2 = var0.getLabelOutlinePaint();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var7.setFixedLegendItems(var8);
//     var7.setRangeCrosshairVisible(true);
//     var7.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var14 = var7.getDomainAxisLocation(10);
//     boolean var15 = var7.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     org.jfree.chart.LegendItemCollection var21 = null;
//     var20.setFixedLegendItems(var21);
//     var20.setRangeCrosshairVisible(true);
//     java.awt.Paint var25 = var20.getNoDataMessagePaint();
//     var7.setRangeCrosshairPaint(var25);
//     var7.setDomainGridlinesVisible(true);
//     var0.setParent((org.jfree.chart.plot.Plot)var7);
//     boolean var30 = var0.getLabelLinksVisible();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var35.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var40 = var35.getRootPlot();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     java.awt.Paint var42 = var41.getItemPaint();
//     org.jfree.chart.util.RectangleInsets var43 = var41.getLegendItemGraphicPadding();
//     var0.setLabelPadding(var43);
//     
//     // Checks the contract:  equals-hashcode on var20 and var35
//     assertTrue("Contract failed: equals-hashcode on var20 and var35", var20.equals(var35) ? var20.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var20
//     assertTrue("Contract failed: equals-hashcode on var35 and var20", var35.equals(var20) ? var35.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    java.awt.Paint var22 = var17.getNoDataMessagePaint();
    var4.setRangeCrosshairPaint(var22);
    var4.setDomainGridlinesVisible(true);
    java.awt.Paint var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeCrosshairPaint(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     java.awt.Font var2 = var1.getNoDataMessageFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var5 = var4.getAxisLinePaint();
//     double var6 = var4.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     java.awt.Shape var15 = var4.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var22 = null;
//     var20.setTickLabelFont((java.lang.Comparable)"", var22);
//     java.awt.Font var25 = var20.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("ThreadContext", var25);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("", var25);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
//     org.jfree.chart.LegendItemCollection var33 = null;
//     var32.setFixedLegendItems(var33);
//     var32.setRangeCrosshairVisible(true);
//     var32.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var39 = var32.getDomainAxisLocation(10);
//     boolean var40 = var32.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     org.jfree.chart.LegendItemCollection var46 = null;
//     var45.setFixedLegendItems(var46);
//     var45.setRangeCrosshairVisible(true);
//     var45.configureDomainAxes();
//     org.jfree.chart.plot.Plot var51 = var45.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var53 = var52.getAxisLinePaint();
//     var45.setBackgroundPaint(var53);
//     var32.setRangeCrosshairPaint(var53);
//     var27.setBackgroundPaint(var53);
//     java.awt.geom.Rectangle2D var57 = var27.getBounds();
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var60 = null;
//     java.util.Collection var61 = var58.getRangeMarkers(255, var60);
//     org.jfree.chart.util.RectangleEdge var62 = var58.getRangeAxisEdge();
//     double var63 = var4.java2DToValue(1.0E-8d, var57, var62);
//     java.awt.geom.Point2D var64 = null;
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var1.draw(var3, var57, var64, var65, var66);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     int var6 = var0.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
//     var0.setRangeAxisLocation(var18, false);
//     org.jfree.chart.axis.ValueAxis var22 = var0.getDomainAxis(0);
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     var0.drawBackground(var23, var24);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    java.awt.Paint var11 = var10.getItemPaint();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var17 = null;
    var15.setTickLabelFont((java.lang.Comparable)"", var17);
    java.awt.Font var20 = var15.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("ThreadContext", var20);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var20);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var26 = null;
    var24.setTickLabelFont((java.lang.Comparable)"", var26);
    java.awt.Font var29 = var24.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var35 = null;
    var33.setTickLabelFont((java.lang.Comparable)"", var35);
    java.awt.Font var38 = var33.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("ThreadContext", var38);
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var38);
    var24.setTickLabelFont(var38);
    var22.setFont(var38);
    var10.setItemFont(var38);
    org.jfree.chart.util.RectangleInsets var44 = var10.getLegendItemGraphicPadding();
    double var46 = var44.calculateBottomOutset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var12, var13, var14);
    org.jfree.data.xy.XYDataset var16 = var15.getDataset();
    int var17 = var15.getBackgroundImageAlignment();
    java.lang.Object var18 = var15.clone();
    org.jfree.chart.axis.ValueAxis var19 = var15.getAxis();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var15.setRadiusGridlineStroke(var21);
    java.awt.Stroke var23 = var15.getAngleGridlineStroke();
    var5.setRangeCrosshairStroke(var23);
    org.jfree.chart.axis.AxisLocation var26 = var5.getDomainAxisLocation(255);
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
    org.jfree.chart.LegendItemCollection var32 = null;
    var31.setFixedLegendItems(var32);
    var31.setRangeCrosshairVisible(true);
    var31.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var38 = var31.getDomainAxisLocation(10);
    var5.setDomainAxisLocation(var38, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var2);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot(var1);
    org.jfree.chart.ChartColor var6 = new org.jfree.chart.ChartColor(0, 10, 10);
    var2.setAggregatedItemsPaint((java.awt.Paint)var6);
    boolean var8 = var0.equals((java.lang.Object)var6);
    float[] var10 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var6.getColorComponents(var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("Category Plot", "ChartEntity: tooltip = ", "Pie Plot", "ThreadContext");

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    java.util.List var3 = var0.getAnnotations();
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var6 = var0.getDomainAxisForDataset((-16774646));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     int var5 = var3.getBackgroundImageAlignment();
//     var3.setRadiusGridlinesVisible(true);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var10 = var9.getAxisLinePaint();
//     double var11 = var9.getUpperMargin();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var16.setRangeCrosshairVisible(true);
//     var16.configureDomainAxes();
//     org.jfree.chart.plot.Plot var22 = var16.getRootPlot();
//     boolean var23 = var9.hasListener((java.util.EventListener)var22);
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     org.jfree.chart.ChartColor var29 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var25.setRadiusGridlinePaint((java.awt.Paint)var29);
//     var3.setAngleGridlinePaint((java.awt.Paint)var29);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var3.zoomDomainAxes(0.025d, var33, var34, false);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var3.zoomDomainAxes(0.2d, var38, var39, true);
//     boolean var42 = var3.isDomainZoomable();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var3.zoomRangeAxes(0.05d, 90.0d, var45, var46);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.Plot var10 = var5.getRootPlot();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    java.awt.Paint var12 = var11.getItemPaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    var17.configureDomainAxes();
    org.jfree.chart.plot.Plot var23 = var17.getRootPlot();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var17.setBackgroundPaint(var25);
    org.jfree.chart.event.PlotChangeEvent var27 = null;
    var17.notifyListeners(var27);
    org.jfree.chart.axis.AxisLocation var29 = var17.getRangeAxisLocation();
    java.awt.Stroke var30 = var17.getRangeGridlineStroke();
    var17.setAnchorValue(0.0d, false);
    var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)var17);
    java.awt.Paint var35 = var11.getItemPaint();
    java.awt.Font var36 = var11.getItemFont();
    org.jfree.chart.util.RectangleEdge var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setLegendItemGraphicEdge(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, (-1.0f), 100.0f, var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    var0.draw(var6, 0.5f, 0.5f, var9, 0.0f, (-1.0f), 4.0d);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
    org.jfree.data.xy.XYDataset var19 = var18.getDataset();
    int var20 = var18.getBackgroundImageAlignment();
    var18.setAngleGridlinesVisible(true);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("0,0,-2,-2,2,-2,2,-2", (org.jfree.chart.plot.Plot)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 15);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainCrosshairPaint();
//     boolean var2 = var0.isDomainCrosshairLockedOnData();
//     java.util.List var3 = var0.getAnnotations();
//     var0.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var7 = var6.getPieChart();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
//     boolean var10 = var7.equals((java.lang.Object)var8);
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var7, (-1), 15);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot(var14);
//     org.jfree.chart.ChartColor var19 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var15.setAggregatedItemsPaint((java.awt.Paint)var19);
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     var26.setRangeCrosshairVisible(true);
//     java.awt.Paint var31 = var26.getNoDataMessagePaint();
//     boolean var32 = var21.equals((java.lang.Object)var26);
//     var21.setLabelLinkMargin(100.0d);
//     org.jfree.chart.plot.MultiplePiePlot var35 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var36 = var35.getPieChart();
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var38 = var37.getFixedLegendItems();
//     boolean var39 = var36.equals((java.lang.Object)var37);
//     var21.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var36);
//     var36.setBorderVisible(false);
//     var15.setPieChart(var36);
//     var13.setChart(var36);
//     
//     // Checks the contract:  equals-hashcode on var8 and var37
//     assertTrue("Contract failed: equals-hashcode on var8 and var37", var8.equals(var37) ? var8.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var8
//     assertTrue("Contract failed: equals-hashcode on var37 and var8", var37.equals(var8) ? var37.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var36
//     assertTrue("Contract failed: equals-hashcode on var7 and var36", var7.equals(var36) ? var7.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var7
//     assertTrue("Contract failed: equals-hashcode on var36 and var7", var36.equals(var7) ? var36.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Pie Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
    java.awt.Paint[] var17 = null;
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    var22.setRangeCrosshairVisible(true);
    var22.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation(10);
    boolean var30 = var22.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
    org.jfree.chart.LegendItemCollection var36 = null;
    var35.setFixedLegendItems(var36);
    var35.setRangeCrosshairVisible(true);
    var35.configureDomainAxes();
    org.jfree.chart.plot.Plot var41 = var35.getRootPlot();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var43 = var42.getAxisLinePaint();
    var35.setBackgroundPaint(var43);
    var22.setRangeCrosshairPaint(var43);
    java.awt.Paint[] var46 = new java.awt.Paint[] { var43};
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot(var47);
    org.jfree.chart.ChartColor var52 = new org.jfree.chart.ChartColor(0, 10, 10);
    var48.setAggregatedItemsPaint((java.awt.Paint)var52);
    java.awt.Paint[] var54 = new java.awt.Paint[] { var52};
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var56 = var55.getTickMarkStroke();
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var60 = null;
    java.util.Collection var61 = var58.getRangeMarkers(255, var60);
    org.jfree.chart.util.RectangleEdge var62 = var58.getRangeAxisEdge();
    double var63 = var58.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var68 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.PolarItemRenderer var71 = null;
    org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
    org.jfree.data.xy.XYDataset var73 = var72.getDataset();
    int var74 = var72.getBackgroundImageAlignment();
    java.lang.Object var75 = var72.clone();
    org.jfree.chart.axis.ValueAxis var76 = var72.getAxis();
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var78 = var77.getTickMarkStroke();
    var72.setRadiusGridlineStroke(var78);
    boolean var80 = var68.equals((java.lang.Object)var78);
    var58.setRangeGridlineStroke(var78);
    java.awt.Stroke[] var82 = new java.awt.Stroke[] { var78};
    org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var84 = var83.getAxisLinePaint();
    double var85 = var83.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var86 = null;
    org.jfree.chart.axis.CategoryAxis var87 = null;
    org.jfree.chart.axis.ValueAxis var88 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var89 = null;
    org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot(var86, var87, var88, var89);
    org.jfree.chart.LegendItemCollection var91 = null;
    var90.setFixedLegendItems(var91);
    var83.addChangeListener((org.jfree.chart.event.AxisChangeListener)var90);
    java.awt.Shape var94 = var83.getLeftArrow();
    java.awt.Shape[] var95 = new java.awt.Shape[] { var94};
    org.jfree.chart.plot.DefaultDrawingSupplier var96 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var46, var54, var57, var82, var95);
    var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var96);
    boolean var98 = var4.isRangeCrosshairLockedOnData();
    org.jfree.chart.LegendItemCollection var99 = var4.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Category Plot", var1, var3);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    java.awt.Stroke var2 = var1.getBorderStroke();
    java.awt.image.BufferedImage var5 = var1.createBufferedImage(255, 255);
    java.util.List var6 = var1.getSubtitles();
    org.jfree.chart.event.ChartChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    var4.setAnchorValue(100.0d);
    org.jfree.chart.util.RectangleEdge var18 = var4.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var19 = var4.getRangeAxisLocation();
    org.jfree.chart.plot.CategoryMarker var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    org.jfree.chart.ui.BasicProjectInfo var2 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var3 = var2.getOptionalLibraries();
    var2.setLicenceName("hi!");
    var0.addLibrary((org.jfree.chart.ui.Library)var2);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("Category Plot");
    double var9 = var8.getWidth();
    org.jfree.chart.util.HorizontalAlignment var10 = var8.getHorizontalAlignment();
    boolean var11 = var2.equals((java.lang.Object)var8);
    org.jfree.chart.ui.Library[] var12 = var2.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, 15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var5.configure();
    var5.setPositiveArrowVisible(false);
    var5.setTickMarksVisible(false);
    double var17 = var5.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     java.awt.Paint var12 = var11.getPaint();
//     var5.setDomainCrosshairPaint(var12);
//     var5.clearRangeAxes();
//     boolean var15 = var5.isDomainZoomable();
//     boolean var16 = var4.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var4 = null;
//     var2.setTickLabelFont((java.lang.Comparable)"", var4);
//     java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var13 = null;
//     var11.setTickLabelFont((java.lang.Comparable)"", var13);
//     java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
//     var2.setTickLabelFont(var16);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var24.setFixedLegendItems(var25);
//     var24.setRangeCrosshairVisible(true);
//     var24.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var31 = var24.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var32 = var24.getDrawingSupplier();
//     java.awt.Stroke var33 = var24.getDomainGridlineStroke();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var24, false);
//     var35.setNotify(true);
//     boolean var38 = var35.isBorderVisible();
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     var35.handleClick(1, 10, var41);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var2 = var1.getAxisLinePaint();
//     var1.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.setVisible(false);
//     boolean var9 = var5.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     boolean var12 = var11.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var13 = var11.getAxisOffset();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var16 = var15.getAxisLinePaint();
//     var15.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var19.setVisible(false);
//     boolean var23 = var19.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     boolean var26 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var29 = var28.getAxisLinePaint();
//     double var30 = var28.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var28.addChangeListener((org.jfree.chart.event.AxisChangeListener)var35);
//     java.awt.Shape var39 = var28.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var46 = null;
//     var44.setTickLabelFont((java.lang.Comparable)"", var46);
//     java.awt.Font var49 = var44.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("ThreadContext", var49);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("", var49);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     org.jfree.chart.LegendItemCollection var57 = null;
//     var56.setFixedLegendItems(var57);
//     var56.setRangeCrosshairVisible(true);
//     var56.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var63 = var56.getDomainAxisLocation(10);
//     boolean var64 = var56.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var65 = null;
//     org.jfree.chart.axis.CategoryAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var65, var66, var67, var68);
//     org.jfree.chart.LegendItemCollection var70 = null;
//     var69.setFixedLegendItems(var70);
//     var69.setRangeCrosshairVisible(true);
//     var69.configureDomainAxes();
//     org.jfree.chart.plot.Plot var75 = var69.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var77 = var76.getAxisLinePaint();
//     var69.setBackgroundPaint(var77);
//     var56.setRangeCrosshairPaint(var77);
//     var51.setBackgroundPaint(var77);
//     java.awt.geom.Rectangle2D var81 = var51.getBounds();
//     org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var84 = null;
//     java.util.Collection var85 = var82.getRangeMarkers(255, var84);
//     org.jfree.chart.util.RectangleEdge var86 = var82.getRangeAxisEdge();
//     double var87 = var28.java2DToValue(1.0E-8d, var81, var86);
//     org.jfree.chart.util.LengthAdjustmentType var88 = null;
//     org.jfree.chart.util.LengthAdjustmentType var89 = null;
//     java.awt.geom.Rectangle2D var90 = var27.createAdjustedRectangle(var81, var88, var89);
//     var13.trim(var81);
//     
//     // Checks the contract:  equals-hashcode on var11 and var25
//     assertTrue("Contract failed: equals-hashcode on var11 and var25", var11.equals(var25) ? var11.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var11
//     assertTrue("Contract failed: equals-hashcode on var25 and var11", var25.equals(var11) ? var25.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    var0.mapDatasetToRangeAxis(15, 0);
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    var0.setDomainCrosshairValue(0.2d, true);
    var0.setRangeZeroBaselineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     var0.clear();
//     org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     var9.setRangeCrosshairVisible(true);
//     java.awt.Paint var14 = var9.getNoDataMessagePaint();
//     boolean var15 = var4.equals((java.lang.Object)var9);
//     var4.setLabelLinkMargin(100.0d);
//     boolean var18 = var4.getSeparatorsVisible();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var22 = var21.getAxisLinePaint();
//     var21.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     var25.setVisible(false);
//     boolean var29 = var25.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     boolean var32 = var31.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var35 = var34.getAxisLinePaint();
//     double var36 = var34.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     org.jfree.chart.LegendItemCollection var42 = null;
//     var41.setFixedLegendItems(var42);
//     var34.addChangeListener((org.jfree.chart.event.AxisChangeListener)var41);
//     java.awt.Shape var45 = var34.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var52 = null;
//     var50.setTickLabelFont((java.lang.Comparable)"", var52);
//     java.awt.Font var55 = var50.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("ThreadContext", var55);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("", var55);
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
//     org.jfree.chart.LegendItemCollection var63 = null;
//     var62.setFixedLegendItems(var63);
//     var62.setRangeCrosshairVisible(true);
//     var62.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var69 = var62.getDomainAxisLocation(10);
//     boolean var70 = var62.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var71 = null;
//     org.jfree.chart.axis.CategoryAxis var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var74 = null;
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot(var71, var72, var73, var74);
//     org.jfree.chart.LegendItemCollection var76 = null;
//     var75.setFixedLegendItems(var76);
//     var75.setRangeCrosshairVisible(true);
//     var75.configureDomainAxes();
//     org.jfree.chart.plot.Plot var81 = var75.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var83 = var82.getAxisLinePaint();
//     var75.setBackgroundPaint(var83);
//     var62.setRangeCrosshairPaint(var83);
//     var57.setBackgroundPaint(var83);
//     java.awt.geom.Rectangle2D var87 = var57.getBounds();
//     org.jfree.chart.plot.XYPlot var88 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var90 = null;
//     java.util.Collection var91 = var88.getRangeMarkers(255, var90);
//     org.jfree.chart.util.RectangleEdge var92 = var88.getRangeAxisEdge();
//     double var93 = var34.java2DToValue(1.0E-8d, var87, var92);
//     org.jfree.chart.util.LengthAdjustmentType var94 = null;
//     org.jfree.chart.util.LengthAdjustmentType var95 = null;
//     java.awt.geom.Rectangle2D var96 = var33.createAdjustedRectangle(var87, var94, var95);
//     var4.drawBackgroundImage(var19, var87);
//     var2.draw(var3, var87);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     boolean var1 = var0.isCircular();
//     var0.setSectionDepth(100.0d);
//     double var4 = var0.getStartAngle();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var9 = null;
//     var7.setTickLabelFont((java.lang.Comparable)"", var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     java.awt.Paint var16 = var15.getRangeGridlinePaint();
//     var7.setTickLabelPaint(var16);
//     var0.setSectionOutlinePaint((java.lang.Comparable)0, var16);
//     java.lang.String var19 = var0.getPlotType();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var22 = var21.getAxisLinePaint();
//     double var23 = var21.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     java.awt.Shape var32 = var21.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var39 = null;
//     var37.setTickLabelFont((java.lang.Comparable)"", var39);
//     java.awt.Font var42 = var37.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var43 = new org.jfree.chart.text.TextFragment("ThreadContext", var42);
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("", var42);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     org.jfree.chart.LegendItemCollection var50 = null;
//     var49.setFixedLegendItems(var50);
//     var49.setRangeCrosshairVisible(true);
//     var49.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var56 = var49.getDomainAxisLocation(10);
//     boolean var57 = var49.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
//     org.jfree.chart.LegendItemCollection var63 = null;
//     var62.setFixedLegendItems(var63);
//     var62.setRangeCrosshairVisible(true);
//     var62.configureDomainAxes();
//     org.jfree.chart.plot.Plot var68 = var62.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var70 = var69.getAxisLinePaint();
//     var62.setBackgroundPaint(var70);
//     var49.setRangeCrosshairPaint(var70);
//     var44.setBackgroundPaint(var70);
//     java.awt.geom.Rectangle2D var74 = var44.getBounds();
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var77 = null;
//     java.util.Collection var78 = var75.getRangeMarkers(255, var77);
//     org.jfree.chart.util.RectangleEdge var79 = var75.getRangeAxisEdge();
//     double var80 = var21.java2DToValue(1.0E-8d, var74, var79);
//     java.awt.geom.Point2D var81 = null;
//     org.jfree.chart.plot.PlotState var82 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     var0.draw(var20, var74, var81, var82, var83);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var4.axisChanged(var14);
    org.jfree.chart.plot.CategoryMarker var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((-16774646), var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", var1, 4.0d, 0.0f, (-1.0f));
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Paint var2 = var0.getLabelOutlinePaint();
    org.jfree.chart.ui.BasicProjectInfo var3 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getOptionalLibraries();
    var3.setLicenceName("hi!");
    boolean var7 = var0.equals((java.lang.Object)"hi!");
    org.jfree.chart.urls.PieURLGenerator var8 = var0.getLegendLabelURLGenerator();
    java.awt.Stroke var9 = var0.getLabelOutlineStroke();
    var0.setShadowYOffset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setVisible(false);
    java.awt.Paint var3 = var0.getTickLabelPaint();
    java.text.NumberFormat var4 = null;
    var0.setNumberFormatOverride(var4);
    org.jfree.data.RangeType var6 = var0.getRangeType();
    org.jfree.chart.plot.Plot var7 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var8 = null;
//     var6.setTickLabelFont((java.lang.Comparable)"", var8);
//     java.awt.Font var11 = var6.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var17 = null;
//     var15.setTickLabelFont((java.lang.Comparable)"", var17);
//     java.awt.Font var20 = var15.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("ThreadContext", var20);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var20);
//     var6.setTickLabelFont(var20);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var27 = var26.getAxisLinePaint();
//     var26.setLabelURL("Multiple Pie Plot");
//     var26.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var38 = null;
//     var36.setTickLabelFont((java.lang.Comparable)"", var38);
//     java.awt.Font var41 = var36.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("ThreadContext", var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var41);
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var55 = var48.getDomainAxisLocation(10);
//     boolean var56 = var48.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     var61.setRangeCrosshairVisible(true);
//     var61.configureDomainAxes();
//     org.jfree.chart.plot.Plot var67 = var61.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var69 = var68.getAxisLinePaint();
//     var61.setBackgroundPaint(var69);
//     var48.setRangeCrosshairPaint(var69);
//     var43.setBackgroundPaint(var69);
//     java.awt.geom.Rectangle2D var73 = var43.getBounds();
//     var26.setUpArrow((java.awt.Shape)var73);
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var76 = var75.getDomainCrosshairPaint();
//     boolean var77 = var75.isDomainCrosshairLockedOnData();
//     java.util.List var78 = var75.getAnnotations();
//     org.jfree.chart.util.RectangleEdge var79 = var75.getDomainAxisEdge();
//     double var80 = var6.getCategoryStart(100, 10, var73, var79);
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var82 = var81.getDomainCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var84 = var81.getRangeAxisEdge(100);
//     org.jfree.chart.axis.NumberAxis var85 = new org.jfree.chart.axis.NumberAxis();
//     var85.setVisible(false);
//     boolean var89 = var85.equals((java.lang.Object)1);
//     java.awt.Shape var90 = var85.getLeftArrow();
//     boolean var91 = var84.equals((java.lang.Object)var90);
//     double var92 = var1.getCategoryJava2DCoordinate(var2, 0, 0, var73, var84);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
    boolean var9 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.util.UnitType var10 = var8.getUnitType();
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var8.createInsetRectangle(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.PlotOrientation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getRangeGridlinePaint();
//     org.jfree.chart.LegendItemCollection var6 = var4.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.plot.Plot var17 = var11.getRootPlot();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var21 = var20.getAxisLinePaint();
//     var20.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var24.setVisible(false);
//     boolean var28 = var24.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainGridlinesVisible();
//     var30.setDomainZeroBaselineVisible(false);
//     java.awt.Paint var34 = var30.getRangeCrosshairPaint();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     java.awt.Paint var40 = var39.getRangeGridlinePaint();
//     java.lang.String var41 = var39.getPlotType();
//     org.jfree.chart.axis.AxisLocation var42 = var39.getRangeAxisLocation();
//     var30.setDomainAxisLocation(var42);
//     var11.setRangeAxisLocation(0, var42, true);
//     var4.setRangeAxisLocation(var42);
//     
//     // Checks the contract:  equals-hashcode on var4 and var39
//     assertTrue("Contract failed: equals-hashcode on var4 and var39", var4.equals(var39) ? var4.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var4
//     assertTrue("Contract failed: equals-hashcode on var39 and var4", var39.equals(var4) ? var39.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var4.getRangeMarkers(var13);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var4.setFixedDomainAxisSpace(var15);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    var21.setRangeCrosshairVisible(true);
    var21.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var28 = var21.getDomainAxisLocation(10);
    boolean var29 = var21.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
    org.jfree.chart.LegendItemCollection var35 = null;
    var34.setFixedLegendItems(var35);
    var34.setRangeCrosshairVisible(true);
    java.awt.Paint var39 = var34.getNoDataMessagePaint();
    var21.setRangeCrosshairPaint(var39);
    var21.setDomainGridlinesVisible(true);
    org.jfree.chart.event.PlotChangeListener var43 = null;
    var21.addChangeListener(var43);
    int var45 = var21.getDomainAxisCount();
    org.jfree.chart.axis.AxisLocation var47 = var21.getRangeAxisLocation((-16774646));
    var4.setRangeAxisLocation(var47);
    var4.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var52 = var4.getDomainAxis(0);
    org.jfree.data.category.CategoryDataset var53 = var4.getDataset();
    java.lang.Object var54 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     org.jfree.chart.plot.PlotState var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.draw(var1, var2, var3, var4, var5);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     java.awt.Stroke var8 = var3.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var3.zoomRangeAxes(4.5125d, var10, var11);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    var3.handleClick(10, 15, var9);
    org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    var11.draw(var12, (-1.0f), 100.0f, var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    var11.draw(var17, 1.0f, 0.0f, var20, 0.5f, (-1.0f), 0.0d);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var26.getRangeMarkers(255, var28);
    org.jfree.chart.util.RectangleEdge var30 = var26.getRangeAxisEdge();
    double var31 = var26.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var26.zoomRangeAxes(1.0d, var33, var34, false);
    var26.setDomainCrosshairValue(2.00000001d);
    org.jfree.chart.axis.AxisSpace var39 = null;
    var26.setFixedRangeAxisSpace(var39, false);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var47 = null;
    var45.setTickLabelFont((java.lang.Comparable)"", var47);
    java.awt.Font var50 = var45.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("ThreadContext", var50);
    org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle("", var50);
    double var53 = var52.getHeight();
    java.awt.Font var54 = var52.getFont();
    var26.setNoDataMessageFont(var54);
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.data.category.CategoryDataset var58 = null;
    org.jfree.chart.axis.CategoryAxis var59 = null;
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
    org.jfree.chart.LegendItemCollection var63 = null;
    var62.setFixedLegendItems(var63);
    var62.setRangeCrosshairVisible(true);
    java.awt.Paint var67 = var62.getNoDataMessagePaint();
    var57.setLabelPaint(var67);
    var11.addLine("hi!", var54, var67);
    var3.setRadiusGridlinePaint(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    var0.setSectionDepth(100.0d);
    double var4 = var0.getStartAngle();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var9 = null;
    var7.setTickLabelFont((java.lang.Comparable)"", var9);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    java.awt.Paint var16 = var15.getRangeGridlinePaint();
    var7.setTickLabelPaint(var16);
    var0.setSectionOutlinePaint((java.lang.Comparable)0, var16);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    org.jfree.chart.LegendItemCollection var24 = null;
    var23.setFixedLegendItems(var24);
    var23.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    java.awt.geom.Point2D var31 = null;
    var23.zoomDomainAxes((-1.0d), 0.0d, var30, var31);
    boolean var33 = var23.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    java.awt.geom.Point2D var37 = null;
    var23.zoomRangeAxes(0.025d, 100.0d, var36, var37);
    java.awt.Paint var39 = var23.getRangeCrosshairPaint();
    boolean var40 = var0.equals((java.lang.Object)var23);
    org.jfree.chart.util.RectangleInsets var41 = var0.getSimpleLabelOffset();
    org.jfree.chart.urls.PieURLGenerator var42 = var0.getURLGenerator();
    float var43 = var0.getBackgroundImageAlpha();
    java.lang.Comparable var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var45 = var0.getSectionPaint(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.5f);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var12 = var11.getLabelLinkStroke();
//     java.awt.Paint var14 = var11.getSectionOutlinePaint((java.lang.Comparable)0);
//     java.awt.Paint var15 = var11.getLabelPaint();
//     var10.setBackgroundPaint(var15);
//     java.awt.Paint var17 = var10.getItemPaint();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var21 = var20.getAxisLinePaint();
//     var20.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var24.setVisible(false);
//     boolean var28 = var24.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var34 = var33.getAxisLinePaint();
//     double var35 = var33.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     org.jfree.chart.LegendItemCollection var41 = null;
//     var40.setFixedLegendItems(var41);
//     var33.addChangeListener((org.jfree.chart.event.AxisChangeListener)var40);
//     java.awt.Shape var44 = var33.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var51 = null;
//     var49.setTickLabelFont((java.lang.Comparable)"", var51);
//     java.awt.Font var54 = var49.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var55 = new org.jfree.chart.text.TextFragment("ThreadContext", var54);
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("", var54);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     var61.setRangeCrosshairVisible(true);
//     var61.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var68 = var61.getDomainAxisLocation(10);
//     boolean var69 = var61.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var70 = null;
//     org.jfree.chart.axis.CategoryAxis var71 = null;
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var73 = null;
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var70, var71, var72, var73);
//     org.jfree.chart.LegendItemCollection var75 = null;
//     var74.setFixedLegendItems(var75);
//     var74.setRangeCrosshairVisible(true);
//     var74.configureDomainAxes();
//     org.jfree.chart.plot.Plot var80 = var74.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var81 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var82 = var81.getAxisLinePaint();
//     var74.setBackgroundPaint(var82);
//     var61.setRangeCrosshairPaint(var82);
//     var56.setBackgroundPaint(var82);
//     java.awt.geom.Rectangle2D var86 = var56.getBounds();
//     org.jfree.chart.plot.XYPlot var87 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var89 = null;
//     java.util.Collection var90 = var87.getRangeMarkers(255, var89);
//     org.jfree.chart.util.RectangleEdge var91 = var87.getRangeAxisEdge();
//     double var92 = var33.java2DToValue(1.0E-8d, var86, var91);
//     org.jfree.chart.util.LengthAdjustmentType var93 = null;
//     org.jfree.chart.util.LengthAdjustmentType var94 = null;
//     java.awt.geom.Rectangle2D var95 = var32.createAdjustedRectangle(var86, var93, var94);
//     var10.draw(var18, var86);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     var5.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var12 = var5.getDomainAxisLocation(10);
//     boolean var13 = var5.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var18.setFixedLegendItems(var19);
//     var18.setRangeCrosshairVisible(true);
//     var18.configureDomainAxes();
//     org.jfree.chart.plot.Plot var24 = var18.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var26 = var25.getAxisLinePaint();
//     var18.setBackgroundPaint(var26);
//     var5.setRangeCrosshairPaint(var26);
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var26};
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot(var30);
//     org.jfree.chart.ChartColor var35 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var31.setAggregatedItemsPaint((java.awt.Paint)var35);
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var35};
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var39 = var38.getTickMarkStroke();
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var41.getRangeMarkers(255, var43);
//     org.jfree.chart.util.RectangleEdge var45 = var41.getRangeAxisEdge();
//     double var46 = var41.getRangeCrosshairValue();
//     org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var54 = null;
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot(var52, var53, var54);
//     org.jfree.data.xy.XYDataset var56 = var55.getDataset();
//     int var57 = var55.getBackgroundImageAlignment();
//     java.lang.Object var58 = var55.clone();
//     org.jfree.chart.axis.ValueAxis var59 = var55.getAxis();
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var61 = var60.getTickMarkStroke();
//     var55.setRadiusGridlineStroke(var61);
//     boolean var63 = var51.equals((java.lang.Object)var61);
//     var41.setRangeGridlineStroke(var61);
//     java.awt.Stroke[] var65 = new java.awt.Stroke[] { var61};
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var67 = var66.getAxisLinePaint();
//     double var68 = var66.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var69 = null;
//     org.jfree.chart.axis.CategoryAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var69, var70, var71, var72);
//     org.jfree.chart.LegendItemCollection var74 = null;
//     var73.setFixedLegendItems(var74);
//     var66.addChangeListener((org.jfree.chart.event.AxisChangeListener)var73);
//     java.awt.Shape var77 = var66.getLeftArrow();
//     java.awt.Shape[] var78 = new java.awt.Shape[] { var77};
//     org.jfree.chart.plot.DefaultDrawingSupplier var79 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var29, var37, var40, var65, var78);
//     java.awt.Paint var80 = var79.getNextOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis var83 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var85 = null;
//     var83.setTickLabelFont((java.lang.Comparable)"", var85);
//     java.awt.Font var88 = var83.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var89 = new org.jfree.chart.text.TextFragment("ThreadContext", var88);
//     org.jfree.data.xy.XYDataset var90 = null;
//     org.jfree.chart.axis.ValueAxis var91 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var92 = null;
//     org.jfree.chart.plot.PolarPlot var93 = new org.jfree.chart.plot.PolarPlot(var90, var91, var92);
//     org.jfree.data.xy.XYDataset var94 = var93.getDataset();
//     int var95 = var93.getBackgroundImageAlignment();
//     java.lang.Object var96 = var93.clone();
//     boolean var97 = var89.equals(var96);
//     boolean var98 = var79.equals(var96);
//     
//     // Checks the contract:  equals-hashcode on var58 and var96
//     assertTrue("Contract failed: equals-hashcode on var58 and var96", var58.equals(var96) ? var58.hashCode() == var96.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var96 and var58
//     assertTrue("Contract failed: equals-hashcode on var96 and var58", var96.equals(var58) ? var96.hashCode() == var58.hashCode() : true);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    var3.setRenderer(var4);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var7 = null;
//     var5.setTickLabelFont((java.lang.Comparable)"", var7);
//     java.awt.Font var10 = var5.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("ThreadContext", var10);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var10);
//     double var13 = var12.getHeight();
//     java.awt.Font var14 = var12.getFont();
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var17 = null;
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, (-1.0d));
//     org.jfree.chart.block.LengthConstraintType var20 = var19.getHeightConstraintType();
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var23 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, (-1.0d));
//     org.jfree.chart.block.LengthConstraintType var26 = var25.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(10.0d, var16, var20, 0.2d, var22, var26);
//     var1.add((org.jfree.chart.block.Block)var12, (java.lang.Object)0.2d);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var34 = null;
//     var32.setTickLabelFont((java.lang.Comparable)"", var34);
//     java.awt.Font var37 = var32.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("ThreadContext", var37);
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("", var37);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var43 = null;
//     var41.setTickLabelFont((java.lang.Comparable)"", var43);
//     java.awt.Font var46 = var41.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var52 = null;
//     var50.setTickLabelFont((java.lang.Comparable)"", var52);
//     java.awt.Font var55 = var50.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("ThreadContext", var55);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("", var55);
//     var41.setTickLabelFont(var55);
//     var39.setFont(var55);
//     var1.add((org.jfree.chart.block.Block)var39, (java.lang.Object)'a');
//     org.jfree.chart.block.FlowArrangement var62 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var63 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var62);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var65 = var64.getFont();
//     double var66 = var64.getContentXOffset();
//     org.jfree.chart.block.BlockFrame var67 = var64.getFrame();
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var70 = null;
//     java.util.Collection var71 = var68.getRangeMarkers(255, var70);
//     org.jfree.chart.util.RectangleEdge var72 = var68.getRangeAxisEdge();
//     double var73 = var68.getRangeCrosshairValue();
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     java.awt.geom.Point2D var76 = null;
//     var68.zoomRangeAxes(1.0d, var75, var76, false);
//     var68.setDomainCrosshairValue(2.00000001d, false);
//     org.jfree.data.xy.XYDataset var83 = var68.getDataset(10);
//     org.jfree.chart.util.RectangleEdge var84 = var68.getRangeAxisEdge();
//     var62.add((org.jfree.chart.block.Block)var64, (java.lang.Object)var68);
//     boolean var86 = var39.equals((java.lang.Object)var68);
//     
//     // Checks the contract:  equals-hashcode on var0 and var62
//     assertTrue("Contract failed: equals-hashcode on var0 and var62", var0.equals(var62) ? var0.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var0
//     assertTrue("Contract failed: equals-hashcode on var62 and var0", var62.equals(var0) ? var62.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var3.rendererChanged(var7);
    org.jfree.chart.plot.PlotOrientation var9 = var3.getOrientation();
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "PlotOrientation.HORIZONTAL"+ "'", var10.equals("PlotOrientation.HORIZONTAL"));

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(0, var8);
    java.util.List var10 = var0.getAnnotations();
    org.jfree.chart.util.RectangleEdge var12 = var0.getDomainAxisEdge(10);
    boolean var13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var12);
    boolean var14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.ChartColor[r=0,g=10,b=10]");
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = var4.getFixedLegendItems();
    org.jfree.chart.plot.DatasetRenderingOrder var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDatasetRenderingOrder(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100.0f);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var1 = var0.getAxisLinePaint();
//     double var2 = var0.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot(var3, var4, var5, var6);
//     org.jfree.chart.LegendItemCollection var8 = null;
//     var7.setFixedLegendItems(var8);
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     java.awt.Shape var11 = var0.getLeftArrow();
//     org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets();
//     java.lang.String var13 = var12.toString();
//     double var15 = var12.calculateLeftInset(0.025d);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var18 = var17.getAxisLinePaint();
//     var17.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     var21.setVisible(false);
//     boolean var25 = var21.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var26);
//     boolean var28 = var27.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var29 = var27.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var31 = var30.getAxisLinePaint();
//     double var32 = var30.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     org.jfree.chart.LegendItemCollection var38 = null;
//     var37.setFixedLegendItems(var38);
//     var30.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     java.awt.Shape var41 = var30.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var48 = null;
//     var46.setTickLabelFont((java.lang.Comparable)"", var48);
//     java.awt.Font var51 = var46.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("ThreadContext", var51);
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("", var51);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     org.jfree.chart.LegendItemCollection var59 = null;
//     var58.setFixedLegendItems(var59);
//     var58.setRangeCrosshairVisible(true);
//     var58.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var65 = var58.getDomainAxisLocation(10);
//     boolean var66 = var58.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var67 = null;
//     org.jfree.chart.axis.CategoryAxis var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var67, var68, var69, var70);
//     org.jfree.chart.LegendItemCollection var72 = null;
//     var71.setFixedLegendItems(var72);
//     var71.setRangeCrosshairVisible(true);
//     var71.configureDomainAxes();
//     org.jfree.chart.plot.Plot var77 = var71.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var79 = var78.getAxisLinePaint();
//     var71.setBackgroundPaint(var79);
//     var58.setRangeCrosshairPaint(var79);
//     var53.setBackgroundPaint(var79);
//     java.awt.geom.Rectangle2D var83 = var53.getBounds();
//     org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var86 = null;
//     java.util.Collection var87 = var84.getRangeMarkers(255, var86);
//     org.jfree.chart.util.RectangleEdge var88 = var84.getRangeAxisEdge();
//     double var89 = var30.java2DToValue(1.0E-8d, var83, var88);
//     org.jfree.chart.util.LengthAdjustmentType var90 = null;
//     org.jfree.chart.util.LengthAdjustmentType var91 = null;
//     java.awt.geom.Rectangle2D var92 = var29.createAdjustedRectangle(var83, var90, var91);
//     java.awt.geom.Rectangle2D var95 = var12.createInsetRectangle(var92, true, true);
//     var0.setLeftArrow((java.awt.Shape)var92);
//     
//     // Checks the contract:  equals-hashcode on var7 and var37
//     assertTrue("Contract failed: equals-hashcode on var7 and var37", var7.equals(var37) ? var7.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var7
//     assertTrue("Contract failed: equals-hashcode on var37 and var7", var37.equals(var7) ? var37.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var10 = null;
    var8.setTickLabelFont((java.lang.Comparable)"", var10);
    java.awt.Font var13 = var8.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var19 = null;
    var17.setTickLabelFont((java.lang.Comparable)"", var19);
    java.awt.Font var22 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("ThreadContext", var22);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
    var8.setTickLabelFont(var22);
    var3.setNoDataMessageFont(var22);
    org.jfree.data.general.DatasetChangeEvent var27 = null;
    var3.datasetChanged(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    var1.setFixedDimension(10.0d);
    var1.setTickMarkOutsideLength(1.0f);
    java.awt.Stroke var9 = var1.getAxisLineStroke();
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var11.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var15.setVisible(false);
    boolean var19 = var15.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var20);
    boolean var22 = var21.isDomainGridlinesVisible();
    var21.setDomainZeroBaselineVisible(false);
    java.awt.Paint var25 = var21.getRangeCrosshairPaint();
    var1.setLabelPaint(var25);
    java.awt.Font var28 = var1.getTickLabelFont((java.lang.Comparable)(byte)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(8.025d, 10.0d);
    org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 8.025d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var5);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var5, 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var11 = var10.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1, var5, 0.2d, var7, var11);
    org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    java.lang.Object var16 = var15.clone();
    org.jfree.chart.util.Size2D var17 = var12.calculateConstrainedSize(var15);
    org.jfree.chart.block.RectangleConstraint var19 = var12.toFixedHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     var0.setRenderer(0, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var10 = var9.getAxisLinePaint();
//     var9.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     var13.setVisible(false);
//     boolean var17 = var13.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     boolean var20 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var23 = var22.getAxisLinePaint();
//     double var24 = var22.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
//     org.jfree.chart.LegendItemCollection var30 = null;
//     var29.setFixedLegendItems(var30);
//     var22.addChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
//     java.awt.Shape var33 = var22.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var40 = null;
//     var38.setTickLabelFont((java.lang.Comparable)"", var40);
//     java.awt.Font var43 = var38.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var44 = new org.jfree.chart.text.TextFragment("ThreadContext", var43);
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("", var43);
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.LegendItemCollection var51 = null;
//     var50.setFixedLegendItems(var51);
//     var50.setRangeCrosshairVisible(true);
//     var50.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var57 = var50.getDomainAxisLocation(10);
//     boolean var58 = var50.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var59 = null;
//     org.jfree.chart.axis.CategoryAxis var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var59, var60, var61, var62);
//     org.jfree.chart.LegendItemCollection var64 = null;
//     var63.setFixedLegendItems(var64);
//     var63.setRangeCrosshairVisible(true);
//     var63.configureDomainAxes();
//     org.jfree.chart.plot.Plot var69 = var63.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var71 = var70.getAxisLinePaint();
//     var63.setBackgroundPaint(var71);
//     var50.setRangeCrosshairPaint(var71);
//     var45.setBackgroundPaint(var71);
//     java.awt.geom.Rectangle2D var75 = var45.getBounds();
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var78 = null;
//     java.util.Collection var79 = var76.getRangeMarkers(255, var78);
//     org.jfree.chart.util.RectangleEdge var80 = var76.getRangeAxisEdge();
//     double var81 = var22.java2DToValue(1.0E-8d, var75, var80);
//     org.jfree.chart.util.LengthAdjustmentType var82 = null;
//     org.jfree.chart.util.LengthAdjustmentType var83 = null;
//     java.awt.geom.Rectangle2D var84 = var21.createAdjustedRectangle(var75, var82, var83);
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     org.jfree.chart.plot.CrosshairState var87 = null;
//     boolean var88 = var0.render(var7, var75, 0, var86, var87);
//     
//     // Checks the contract:  equals-hashcode on var0 and var76
//     assertTrue("Contract failed: equals-hashcode on var0 and var76", var0.equals(var76) ? var0.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var0
//     assertTrue("Contract failed: equals-hashcode on var76 and var0", var76.equals(var0) ? var76.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     var4.configureDomainAxes();
//     org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var12 = var11.getAxisLinePaint();
//     var4.setBackgroundPaint(var12);
//     org.jfree.chart.event.PlotChangeEvent var14 = null;
//     var4.notifyListeners(var14);
//     org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
//     java.awt.Paint[] var17 = null;
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
//     org.jfree.chart.LegendItemCollection var23 = null;
//     var22.setFixedLegendItems(var23);
//     var22.setRangeCrosshairVisible(true);
//     var22.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation(10);
//     boolean var30 = var22.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     var35.setRangeCrosshairVisible(true);
//     var35.configureDomainAxes();
//     org.jfree.chart.plot.Plot var41 = var35.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var43 = var42.getAxisLinePaint();
//     var35.setBackgroundPaint(var43);
//     var22.setRangeCrosshairPaint(var43);
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var43};
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot(var47);
//     org.jfree.chart.ChartColor var52 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var48.setAggregatedItemsPaint((java.awt.Paint)var52);
//     java.awt.Paint[] var54 = new java.awt.Paint[] { var52};
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var56 = var55.getTickMarkStroke();
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var60 = null;
//     java.util.Collection var61 = var58.getRangeMarkers(255, var60);
//     org.jfree.chart.util.RectangleEdge var62 = var58.getRangeAxisEdge();
//     double var63 = var58.getRangeCrosshairValue();
//     org.jfree.chart.block.BlockBorder var68 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var71 = null;
//     org.jfree.chart.plot.PolarPlot var72 = new org.jfree.chart.plot.PolarPlot(var69, var70, var71);
//     org.jfree.data.xy.XYDataset var73 = var72.getDataset();
//     int var74 = var72.getBackgroundImageAlignment();
//     java.lang.Object var75 = var72.clone();
//     org.jfree.chart.axis.ValueAxis var76 = var72.getAxis();
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var78 = var77.getTickMarkStroke();
//     var72.setRadiusGridlineStroke(var78);
//     boolean var80 = var68.equals((java.lang.Object)var78);
//     var58.setRangeGridlineStroke(var78);
//     java.awt.Stroke[] var82 = new java.awt.Stroke[] { var78};
//     org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var84 = var83.getAxisLinePaint();
//     double var85 = var83.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var86 = null;
//     org.jfree.chart.axis.CategoryAxis var87 = null;
//     org.jfree.chart.axis.ValueAxis var88 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var89 = null;
//     org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot(var86, var87, var88, var89);
//     org.jfree.chart.LegendItemCollection var91 = null;
//     var90.setFixedLegendItems(var91);
//     var83.addChangeListener((org.jfree.chart.event.AxisChangeListener)var90);
//     java.awt.Shape var94 = var83.getLeftArrow();
//     java.awt.Shape[] var95 = new java.awt.Shape[] { var94};
//     org.jfree.chart.plot.DefaultDrawingSupplier var96 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var46, var54, var57, var82, var95);
//     var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var96);
//     var4.zoom(2.0d);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    var0.setLabelURL("Multiple Pie Plot");
    var0.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    org.jfree.chart.LegendItemCollection var12 = null;
    var11.setFixedLegendItems(var12);
    var11.setRangeCrosshairVisible(true);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    java.awt.Stroke var17 = var11.getDomainGridlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var14 = null;
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot(var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = var15.getDataset();
//     int var17 = var15.getBackgroundImageAlignment();
//     var15.setRadiusGridlinesVisible(true);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var22 = var21.getAxisLinePaint();
//     double var23 = var21.getUpperMargin();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     var28.setRangeCrosshairVisible(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.plot.Plot var34 = var28.getRootPlot();
//     boolean var35 = var21.hasListener((java.util.EventListener)var34);
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, var36);
//     org.jfree.chart.ChartColor var41 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var37.setRadiusGridlinePaint((java.awt.Paint)var41);
//     var15.setAngleGridlinePaint((java.awt.Paint)var41);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var15.zoomDomainAxes(0.025d, var45, var46, false);
//     org.jfree.chart.axis.TickUnit var49 = var15.getAngleTickUnit();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var51 = var50.getTickMarkStroke();
//     var0.setSectionOutlineStroke((java.lang.Comparable)var49, var51);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setVisible(false);
    boolean var4 = var0.equals((java.lang.Object)1);
    java.text.NumberFormat var5 = var0.getNumberFormatOverride();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var8 = var7.getAxisLinePaint();
    var7.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var11.setVisible(false);
    boolean var15 = var11.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var11.configure();
    var11.setPositiveArrowVisible(false);
    org.jfree.data.RangeType var21 = var11.getRangeType();
    var0.setRangeType(var21);
    var0.setLabelToolTip("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    var4.setAnchorValue(100.0d);
    org.jfree.chart.util.RectangleEdge var18 = var4.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var19 = var4.getRangeAxisLocation();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var20, var21, var22);
    org.jfree.data.xy.XYDataset var24 = var23.getDataset();
    int var25 = var23.getBackgroundImageAlignment();
    java.lang.Object var26 = var23.clone();
    org.jfree.chart.axis.ValueAxis var27 = var23.getAxis();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var29 = var28.getTickMarkStroke();
    var23.setRadiusGridlineStroke(var29);
    java.awt.Paint var31 = var23.getBackgroundPaint();
    var23.clearCornerTextItems();
    org.jfree.chart.plot.PlotOrientation var33 = var23.getOrientation();
    org.jfree.chart.util.RectangleEdge var34 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var19, var33);
    boolean var35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    var0.setSectionDepth(100.0d);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.awt.Paint var6 = var0.getLabelShadowPaint();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = var10.getDataset();
    int var12 = var10.getBackgroundImageAlignment();
    var10.setRadiusGridlinesVisible(true);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var17 = var16.getAxisLinePaint();
    double var18 = var16.getUpperMargin();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    org.jfree.chart.LegendItemCollection var24 = null;
    var23.setFixedLegendItems(var24);
    var23.setRangeCrosshairVisible(true);
    var23.configureDomainAxes();
    org.jfree.chart.plot.Plot var29 = var23.getRootPlot();
    boolean var30 = var16.hasListener((java.util.EventListener)var29);
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, var31);
    org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(0, 10, 10);
    var32.setRadiusGridlinePaint((java.awt.Paint)var36);
    var10.setAngleGridlinePaint((java.awt.Paint)var36);
    int var39 = var36.getRed();
    int var40 = var36.getGreen();
    var0.setLabelShadowPaint((java.awt.Paint)var36);
    org.jfree.chart.text.TextBlock var42 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.text.TextBlockAnchor var46 = null;
    var42.draw(var43, (-1.0f), 100.0f, var46);
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.text.TextBlockAnchor var51 = null;
    var42.draw(var48, 1.0f, 0.0f, var51, 0.5f, (-1.0f), 0.0d);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.renderer.PolarItemRenderer var59 = null;
    org.jfree.chart.plot.PolarPlot var60 = new org.jfree.chart.plot.PolarPlot(var57, var58, var59);
    org.jfree.data.xy.XYDataset var61 = var60.getDataset();
    int var62 = var60.getBackgroundImageAlignment();
    org.jfree.chart.LegendItemCollection var63 = var60.getLegendItems();
    org.jfree.chart.plot.PlotRenderingInfo var65 = null;
    java.awt.geom.Point2D var66 = null;
    var60.zoomDomainAxes(10.0d, var65, var66);
    java.awt.Font var68 = var60.getAngleLabelFont();
    org.jfree.chart.plot.RingPlot var69 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var70 = var69.getLabelLinkStroke();
    java.awt.Paint var72 = var69.getSectionOutlinePaint((java.lang.Comparable)0);
    org.jfree.data.category.CategoryDataset var73 = null;
    org.jfree.chart.plot.MultiplePiePlot var74 = new org.jfree.chart.plot.MultiplePiePlot(var73);
    org.jfree.chart.ChartColor var78 = new org.jfree.chart.ChartColor(0, 10, 10);
    var74.setAggregatedItemsPaint((java.awt.Paint)var78);
    java.lang.String var80 = var78.toString();
    var69.setSeparatorPaint((java.awt.Paint)var78);
    var42.addLine("Category Plot", var68, (java.awt.Paint)var78);
    float[] var83 = null;
    float[] var84 = var78.getRGBColorComponents(var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var85 = var36.getRGBComponents(var84);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=10]"+ "'", var80.equals("org.jfree.chart.ChartColor[r=0,g=10,b=10]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    var0.clear();
    var0.clear();
    var0.clear();

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    var0.clear();
    org.jfree.chart.block.FlowArrangement var2 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var4, var7);
    double var9 = var8.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);
    org.jfree.data.general.WaferMapDataset var3 = null;
    var0.setDataset(var3);
    org.jfree.data.general.WaferMapDataset var5 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    var17.setRangeCrosshairVisible(true);
    java.awt.Paint var22 = var17.getNoDataMessagePaint();
    var4.setRangeCrosshairPaint(var22);
    org.jfree.chart.event.MarkerChangeEvent var24 = null;
    var4.markerChanged(var24);
    int var26 = var4.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 15);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = var0.getPieChart();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
//     boolean var4 = var1.equals((java.lang.Object)var2);
//     var1.setNotify(false);
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var8 = var7.getPieChart();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getFixedLegendItems();
//     boolean var11 = var8.equals((java.lang.Object)var9);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var15 = null;
//     var13.setTickLabelFont((java.lang.Comparable)"", var15);
//     var13.setFixedDimension(10.0d);
//     var13.setTickMarkOutsideLength(1.0f);
//     java.awt.Stroke var21 = var13.getAxisLineStroke();
//     var8.setBorderStroke(var21);
//     var1.setBorderStroke(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var7 = var6.getPieChart();
    java.awt.Stroke var8 = var7.getBorderStroke();
    java.awt.image.BufferedImage var11 = var7.createBufferedImage(255, 255);
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("Pie Plot", "WMAP_Plot", "hi!", (java.awt.Image)var11, "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("Polar Plot", "XY Plot", "Multiple Pie Plot", (java.awt.Image)var11, "", "", "0,0,-2,-2,2,-2,2,-2");
    java.lang.String var20 = var19.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "0,0,-2,-2,2,-2,2,-2"+ "'", var20.equals("0,0,-2,-2,2,-2,2,-2"));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Paint var2 = var0.getLabelOutlinePaint();
    org.jfree.chart.ui.BasicProjectInfo var3 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getOptionalLibraries();
    var3.setLicenceName("hi!");
    boolean var7 = var0.equals((java.lang.Object)"hi!");
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    int var9 = var8.getItemCount();
    int var10 = var8.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    var10.setPadding(1.0E-8d, 0.0d, 0.0d, 10.0d);
    org.jfree.chart.util.RectangleEdge var16 = var10.getPosition();
    org.jfree.chart.event.TitleChangeEvent var17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var10);
    org.jfree.chart.title.Title var18 = var17.getTitle();
    org.jfree.chart.JFreeChart var19 = var17.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var6 = null;
    var4.setTickLabelFont((java.lang.Comparable)"", var6);
    java.awt.Font var9 = var4.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("ThreadContext", var9);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var9);
    var11.setPadding(1.0E-8d, 0.0d, 0.0d, 10.0d);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    var21.setRangeCrosshairVisible(true);
    var21.configureDomainAxes();
    org.jfree.chart.plot.Plot var27 = var21.getRootPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var29 = var28.getAxisLinePaint();
    var21.setBackgroundPaint(var29);
    org.jfree.chart.event.PlotChangeEvent var31 = null;
    var21.notifyListeners(var31);
    var21.setAnchorValue(100.0d);
    var0.add((org.jfree.chart.block.Block)var11, (java.lang.Object)100.0d);
    var0.clear();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeGridlinePaint();
    org.jfree.chart.LegendItemCollection var6 = var4.getFixedLegendItems();
    org.jfree.chart.StrokeMap var9 = new org.jfree.chart.StrokeMap();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 10, 10);
    var11.setAggregatedItemsPaint((java.awt.Paint)var15);
    boolean var17 = var9.equals((java.lang.Object)var15);
    int var18 = var15.getAlpha();
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var26 = null;
    var24.setTickLabelFont((java.lang.Comparable)"", var26);
    java.awt.Font var29 = var24.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("ThreadContext", var29);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var29);
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
    org.jfree.chart.LegendItemCollection var37 = null;
    var36.setFixedLegendItems(var37);
    var36.setRangeCrosshairVisible(true);
    var36.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var43 = var36.getDomainAxisLocation(10);
    boolean var44 = var36.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
    org.jfree.chart.LegendItemCollection var50 = null;
    var49.setFixedLegendItems(var50);
    var49.setRangeCrosshairVisible(true);
    var49.configureDomainAxes();
    org.jfree.chart.plot.Plot var55 = var49.getRootPlot();
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var57 = var56.getAxisLinePaint();
    var49.setBackgroundPaint(var57);
    var36.setRangeCrosshairPaint(var57);
    var31.setBackgroundPaint(var57);
    java.awt.geom.Rectangle2D var61 = var31.getBounds();
    java.awt.geom.AffineTransform var62 = null;
    java.awt.RenderingHints var63 = null;
    java.awt.PaintContext var64 = var15.createContext(var19, var20, var61, var62, var63);
    org.jfree.data.xy.XYDataset var65 = null;
    org.jfree.chart.axis.ValueAxis var66 = null;
    org.jfree.chart.renderer.PolarItemRenderer var67 = null;
    org.jfree.chart.plot.PolarPlot var68 = new org.jfree.chart.plot.PolarPlot(var65, var66, var67);
    org.jfree.data.xy.XYDataset var69 = var68.getDataset();
    int var70 = var68.getBackgroundImageAlignment();
    java.lang.Object var71 = var68.clone();
    org.jfree.chart.axis.ValueAxis var72 = var68.getAxis();
    org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var74 = var73.getTickMarkStroke();
    var68.setRadiusGridlineStroke(var74);
    java.awt.Paint var76 = null;
    org.jfree.data.xy.XYDataset var77 = null;
    org.jfree.chart.axis.ValueAxis var78 = null;
    org.jfree.chart.renderer.PolarItemRenderer var79 = null;
    org.jfree.chart.plot.PolarPlot var80 = new org.jfree.chart.plot.PolarPlot(var77, var78, var79);
    org.jfree.data.xy.XYDataset var81 = var80.getDataset();
    java.awt.Stroke var82 = null;
    var80.setRadiusGridlineStroke(var82);
    org.jfree.chart.LegendItemCollection var84 = var80.getLegendItems();
    java.awt.Stroke var85 = var80.getAngleGridlineStroke();
    org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var15, var74, var76, var85, 0.5f);
    java.awt.Stroke var88 = var87.getStroke();
    org.jfree.chart.util.Layer var89 = null;
    var4.addRangeMarker(15, (org.jfree.chart.plot.Marker)var87, var89);
    java.awt.Stroke var91 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeCrosshairStroke(var91);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    var0.setLabelLinkMargin(100.0d);
    org.jfree.data.general.PieDataset var14 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(0.025d, (-1.0d));
    var2.setWidth(0.05d);
    java.lang.Object var5 = var2.clone();
    var2.setWidth(2.888d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    var5.setRangeCrosshairVisible(true);
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var17 = var16.getAxisLinePaint();
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 10.0d, 0.0d, var17);
    var0.setOutlinePaint(var17);
    org.jfree.chart.labels.PieToolTipGenerator var20 = var0.getToolTipGenerator();
    org.jfree.chart.util.Rotation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    var15.setRangeCrosshairVisible(true);
    var15.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(10);
    boolean var23 = var15.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    var28.setRangeCrosshairVisible(true);
    var28.configureDomainAxes();
    org.jfree.chart.plot.Plot var34 = var28.getRootPlot();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    var28.setBackgroundPaint(var36);
    var15.setRangeCrosshairPaint(var36);
    var10.setBackgroundPaint(var36);
    java.awt.Paint var40 = var10.getPaint();
    double var41 = var10.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.axis.AxisLocation var16 = var4.getRangeAxisLocation();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    var22.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var22.zoomDomainAxes((-1.0d), 0.0d, var29, var30);
    org.jfree.chart.LegendItemCollection var32 = var22.getFixedLegendItems();
    java.lang.Object var33 = var22.clone();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var36.setLabelAngle(1.0d);
    var22.setDomainAxis(0, var36, true);
    var4.setDomainAxis(100, var36, false);
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.PolarItemRenderer var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot(var43, var44, var45);
    org.jfree.data.xy.XYDataset var47 = var46.getDataset();
    java.awt.Stroke var48 = null;
    var46.setRadiusGridlineStroke(var48);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    var46.handleClick(10, 15, var52);
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var54, var55, var56);
    org.jfree.data.xy.XYDataset var58 = var57.getDataset();
    java.awt.Stroke var59 = null;
    var57.setRadiusGridlineStroke(var59);
    org.jfree.chart.LegendItemCollection var61 = var57.getLegendItems();
    java.awt.Stroke var62 = var57.getAngleGridlineStroke();
    var46.setRadiusGridlineStroke(var62);
    var4.setRangeCrosshairStroke(var62);
    org.jfree.chart.axis.AxisLocation var66 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(0, var66);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var3);
//     java.util.ResourceBundle.Control var5 = null;
//     java.util.ResourceBundle var6 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", var1, var3, var5);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var2 = var1.getAxisLinePaint();
//     var1.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var5.setVisible(false);
//     boolean var9 = var5.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     int var13 = var11.getIndexOf(var12);
//     boolean var14 = var11.isRangeZeroBaselineVisible();
//     org.jfree.chart.axis.AxisSpace var15 = var11.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var17 = var16.getAxisLinePaint();
//     var16.setLabelURL("Multiple Pie Plot");
//     var16.resizeRange(0.05d, 0.0d);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.LegendItemCollection var28 = null;
//     var27.setFixedLegendItems(var28);
//     var27.setRangeCrosshairVisible(true);
//     var16.addChangeListener((org.jfree.chart.event.AxisChangeListener)var27);
//     int var33 = var11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var16);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var35, var36, var37, var38);
//     org.jfree.chart.LegendItemCollection var40 = null;
//     var39.setFixedLegendItems(var40);
//     var39.setRangeCrosshairVisible(true);
//     var39.configureDomainAxes();
//     org.jfree.chart.plot.Plot var45 = var39.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var47 = var46.getAxisLinePaint();
//     var39.setBackgroundPaint(var47);
//     org.jfree.chart.event.PlotChangeEvent var49 = null;
//     var39.notifyListeners(var49);
//     var39.setAnchorValue(100.0d);
//     org.jfree.chart.util.RectangleEdge var53 = var39.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var54 = var39.getRangeAxisLocation();
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var55, var56, var57, var58);
//     org.jfree.chart.LegendItemCollection var60 = null;
//     var59.setFixedLegendItems(var60);
//     var59.setRangeCrosshairVisible(true);
//     var59.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var66 = var59.getDomainAxisLocation(10);
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var69 = null;
//     org.jfree.chart.plot.PolarPlot var70 = new org.jfree.chart.plot.PolarPlot(var67, var68, var69);
//     org.jfree.data.xy.XYDataset var71 = var70.getDataset();
//     java.awt.Stroke var72 = null;
//     var70.setRadiusGridlineStroke(var72);
//     org.jfree.chart.event.RendererChangeEvent var74 = null;
//     var70.rendererChanged(var74);
//     org.jfree.chart.plot.PlotOrientation var76 = var70.getOrientation();
//     org.jfree.chart.util.RectangleEdge var77 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var66, var76);
//     org.jfree.chart.util.RectangleEdge var78 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var54, var76);
//     var11.setRangeAxisLocation(0, var54);
//     
//     // Checks the contract:  equals-hashcode on var27 and var59
//     assertTrue("Contract failed: equals-hashcode on var27 and var59", var27.equals(var59) ? var27.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var27
//     assertTrue("Contract failed: equals-hashcode on var59 and var27", var59.equals(var27) ? var59.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    double var11 = var10.getHeight();
    java.awt.Font var12 = var10.getFont();
    double var13 = var10.getWidth();
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = var14.getPieChart();
    java.awt.Stroke var16 = var15.getBorderStroke();
    var10.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var18 = var15.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.axis.AxisLocation var16 = var4.getRangeAxisLocation();
    java.awt.Stroke var17 = var4.getRangeGridlineStroke();
    var4.setAnchorValue(0.0d, false);
    boolean var21 = var4.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     java.awt.Paint var9 = var4.getNoDataMessagePaint();
//     var4.setAnchorValue(100.0d);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.LegendItemCollection var17 = null;
//     var16.setFixedLegendItems(var17);
//     var16.setRangeCrosshairVisible(true);
//     var16.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation(10);
//     var4.setDomainAxisLocation(var23);
//     org.jfree.chart.util.RectangleEdge var25 = var4.getDomainAxisEdge();
//     java.awt.Stroke var26 = var4.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var27, var28, var29, var30);
//     org.jfree.chart.LegendItemCollection var32 = null;
//     var31.setFixedLegendItems(var32);
//     var31.setRangeCrosshairVisible(true);
//     var31.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var38 = var31.getDomainAxisLocation(10);
//     boolean var39 = var31.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     org.jfree.chart.axis.CategoryAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
//     org.jfree.chart.LegendItemCollection var45 = null;
//     var44.setFixedLegendItems(var45);
//     var44.setRangeCrosshairVisible(true);
//     java.awt.Paint var49 = var44.getNoDataMessagePaint();
//     var31.setRangeCrosshairPaint(var49);
//     var31.setDomainGridlinesVisible(true);
//     int var53 = var31.getWeight();
//     java.awt.Paint var54 = var31.getOutlinePaint();
//     var4.setRangeCrosshairPaint(var54);
//     
//     // Checks the contract:  equals-hashcode on var16 and var44
//     assertTrue("Contract failed: equals-hashcode on var16 and var44", var16.equals(var44) ? var16.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var16
//     assertTrue("Contract failed: equals-hashcode on var44 and var16", var44.equals(var16) ? var44.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.data.category.CategoryDataset var14 = null;
    var4.setDataset(255, var14);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    var16.setVisible(false);
    boolean var20 = var16.equals((java.lang.Object)1);
    java.text.NumberFormat var21 = var16.getNumberFormatOverride();
    var16.setLowerBound(10.0d);
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var26.getRangeMarkers(255, var28);
    org.jfree.chart.util.RectangleEdge var30 = var26.getRangeAxisEdge();
    double var31 = var26.getRangeCrosshairValue();
    int var32 = var26.getDomainAxisCount();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
    org.jfree.chart.LegendItemCollection var38 = null;
    var37.setFixedLegendItems(var38);
    var37.setRangeCrosshairVisible(true);
    var37.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var44 = var37.getDomainAxisLocation(10);
    var26.setRangeAxisLocation(var44, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation((-1), var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var3.rendererChanged(var7);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var3.zoomDomainAxes(10.0d, 0.0d, var11, var12);
    boolean var14 = var3.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     int var6 = var0.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
//     var0.setRangeAxisLocation(var18, false);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var23 = var22.getAxisLinePaint();
//     var22.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     var26.setVisible(false);
//     boolean var30 = var26.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var31);
//     var26.configure();
//     var26.setVisible(true);
//     int var36 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var26);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var40 = var39.getAxisLinePaint();
//     var39.setLabelURL("Multiple Pie Plot");
//     var39.resizeRange(0.05d, 0.0d);
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.LegendItemCollection var51 = null;
//     var50.setFixedLegendItems(var51);
//     var50.setRangeCrosshairVisible(true);
//     var39.addChangeListener((org.jfree.chart.event.AxisChangeListener)var50);
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var37, var38, (org.jfree.chart.axis.ValueAxis)var39, var56);
//     org.jfree.data.Range var58 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var39);
//     
//     // Checks the contract:  equals-hashcode on var11 and var50
//     assertTrue("Contract failed: equals-hashcode on var11 and var50", var11.equals(var50) ? var11.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var11
//     assertTrue("Contract failed: equals-hashcode on var50 and var11", var50.equals(var11) ? var50.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), 100.0d);
//     var4.clear();
//     org.jfree.chart.block.Block var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.LegendItemCollection var12 = null;
//     var11.setFixedLegendItems(var12);
//     var11.setRangeCrosshairVisible(true);
//     var11.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var19 = var11.getDrawingSupplier();
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var11.getRangeMarkers(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var11.setFixedDomainAxisSpace(var22);
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     var28.setRangeCrosshairVisible(true);
//     var28.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var35 = var28.getDomainAxisLocation(10);
//     boolean var36 = var28.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
//     org.jfree.chart.LegendItemCollection var42 = null;
//     var41.setFixedLegendItems(var42);
//     var41.setRangeCrosshairVisible(true);
//     java.awt.Paint var46 = var41.getNoDataMessagePaint();
//     var28.setRangeCrosshairPaint(var46);
//     var28.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.PlotChangeListener var50 = null;
//     var28.addChangeListener(var50);
//     int var52 = var28.getDomainAxisCount();
//     org.jfree.chart.axis.AxisLocation var54 = var28.getRangeAxisLocation((-16774646));
//     var11.setRangeAxisLocation(var54);
//     int var56 = var11.getDomainAxisCount();
//     org.jfree.chart.axis.AxisLocation var57 = var11.getDomainAxisLocation();
//     org.jfree.chart.util.HorizontalAlignment var58 = null;
//     org.jfree.chart.util.VerticalAlignment var59 = null;
//     org.jfree.chart.block.FlowArrangement var62 = new org.jfree.chart.block.FlowArrangement(var58, var59, (-1.0d), 100.0d);
//     org.jfree.chart.block.FlowArrangement var63 = new org.jfree.chart.block.FlowArrangement();
//     var63.clear();
//     var63.clear();
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11, (org.jfree.chart.block.Arrangement)var62, (org.jfree.chart.block.Arrangement)var63);
//     var4.add(var6, (java.lang.Object)var11);
//     
//     // Checks the contract:  equals-hashcode on var4 and var62
//     assertTrue("Contract failed: equals-hashcode on var4 and var62", var4.equals(var62) ? var4.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var4
//     assertTrue("Contract failed: equals-hashcode on var62 and var4", var62.equals(var4) ? var62.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    double var3 = var1.getAutoRangeMinimumSize();
    var1.setAutoRange(false);
    org.jfree.data.RangeType var6 = var1.getRangeType();
    boolean var7 = var1.isTickLabelsVisible();
    boolean var8 = var1.getAutoRangeStickyZero();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var10 = var9.getAxisLinePaint();
    double var11 = var9.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    java.awt.Shape var20 = var9.getLeftArrow();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var9, var21);
    var9.resizeRange(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var12 = var11.getLabelLinkStroke();
//     java.awt.Paint var14 = var11.getSectionOutlinePaint((java.lang.Comparable)0);
//     java.awt.Paint var15 = var11.getLabelPaint();
//     var10.setBackgroundPaint(var15);
//     org.jfree.chart.util.RectangleAnchor var17 = var10.getLegendItemGraphicAnchor();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var23 = null;
//     var21.setTickLabelFont((java.lang.Comparable)"", var23);
//     java.awt.Font var26 = var21.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("ThreadContext", var26);
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var26);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot();
//     boolean var31 = var30.isCircular();
//     var30.setSectionDepth(100.0d);
//     double var34 = var30.getStartAngle();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var39 = null;
//     var37.setTickLabelFont((java.lang.Comparable)"", var39);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     java.awt.Paint var46 = var45.getRangeGridlinePaint();
//     var37.setTickLabelPaint(var46);
//     var30.setSectionOutlinePaint((java.lang.Comparable)0, var46);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
//     org.jfree.chart.LegendItemCollection var54 = null;
//     var53.setFixedLegendItems(var54);
//     var53.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Point2D var61 = null;
//     var53.zoomDomainAxes((-1.0d), 0.0d, var60, var61);
//     boolean var63 = var53.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     java.awt.geom.Point2D var67 = null;
//     var53.zoomRangeAxes(0.025d, 100.0d, var66, var67);
//     java.awt.Paint var69 = var53.getRangeCrosshairPaint();
//     boolean var70 = var30.equals((java.lang.Object)var53);
//     org.jfree.chart.util.RectangleInsets var71 = var30.getSimpleLabelOffset();
//     var28.setPadding(var71);
//     double var74 = var71.trimHeight(4.5125d);
//     var10.setItemLabelPadding(var71);
//     
//     // Checks the contract:  equals-hashcode on var4 and var53
//     assertTrue("Contract failed: equals-hashcode on var4 and var53", var4.equals(var53) ? var4.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var4
//     assertTrue("Contract failed: equals-hashcode on var53 and var4", var53.equals(var4) ? var53.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    java.lang.Object var1 = var0.clone();
    java.text.AttributedString var3 = var0.getAttributedLabel(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(8.025d, 4.00000001d, 0.36000000179999997d, 4.0d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    var0.mapDatasetToRangeAxis(15, 0);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = var10.getDataset();
    int var12 = var10.getBackgroundImageAlignment();
    var10.setRadiusGridlinesVisible(true);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var17 = var16.getAxisLinePaint();
    double var18 = var16.getUpperMargin();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    org.jfree.chart.LegendItemCollection var24 = null;
    var23.setFixedLegendItems(var24);
    var23.setRangeCrosshairVisible(true);
    var23.configureDomainAxes();
    org.jfree.chart.plot.Plot var29 = var23.getRootPlot();
    boolean var30 = var16.hasListener((java.util.EventListener)var29);
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, var31);
    org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(0, 10, 10);
    var32.setRadiusGridlinePaint((java.awt.Paint)var36);
    var10.setAngleGridlinePaint((java.awt.Paint)var36);
    int var39 = var36.getRed();
    int var40 = var36.getGreen();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(4, (java.awt.Paint)var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 10);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setFixedDimension(10.0d);
    var2.setTickLabelsVisible(true);
    java.awt.Font var7 = var2.getTickLabelFont();
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("PlotOrientation.HORIZONTAL", var7, var8, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    var0.setSectionDepth(100.0d);
    float var4 = var0.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    var0.clear();
    var0.clear();
    java.awt.Paint var4 = var0.getPaint((java.lang.Comparable)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var3 = var2.getAxisLinePaint();
    var2.setLabelURL("Multiple Pie Plot");
    var2.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var13.setFixedLegendItems(var14);
    var13.setRangeCrosshairVisible(true);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var19);
    int var21 = var20.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    var0.setDomainCrosshairValue(2.00000001d);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var0.setFixedRangeAxisSpace(var13, false);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var21 = null;
    var19.setTickLabelFont((java.lang.Comparable)"", var21);
    java.awt.Font var24 = var19.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("ThreadContext", var24);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
    double var27 = var26.getHeight();
    java.awt.Font var28 = var26.getFont();
    var0.setNoDataMessageFont(var28);
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    java.awt.geom.Point2D var32 = null;
    var0.zoomRangeAxes(4.0d, var31, var32, true);
    org.jfree.data.xy.XYDataset var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataset((-16774646), var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setVisible(false);
    boolean var4 = var0.equals((java.lang.Object)1);
    java.text.NumberFormat var5 = var0.getNumberFormatOverride();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var8 = var7.getAxisLinePaint();
    var7.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var11.setVisible(false);
    boolean var15 = var11.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
    var11.configure();
    var11.setPositiveArrowVisible(false);
    org.jfree.data.RangeType var21 = var11.getRangeType();
    var0.setRangeType(var21);
    boolean var23 = var0.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     org.jfree.chart.event.RendererChangeEvent var8 = null;
//     var3.rendererChanged(var8);
//     boolean var11 = var3.equals((java.lang.Object)100);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var3.zoomDomainAxes(0.0d, var13, var14);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getDomainCrosshairPaint();
//     var16.setDomainTickBandPaint(var19);
//     var3.setAngleGridlinePaint(var19);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Point2D var25 = null;
//     var3.zoomRangeAxes(1.0d, 10.0d, var24, var25);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    var1.setFixedDimension(10.0d);
    var1.setTickMarkOutsideLength(1.0f);
    var1.setCategoryMargin(0.2d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.data.category.CategoryDataset var14 = null;
    var4.setDataset(255, var14);
    java.lang.Object var16 = var4.clone();
    org.jfree.chart.plot.CategoryMarker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((-1), var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var11.getRangeMarkers(255, var13);
    org.jfree.chart.util.RectangleEdge var15 = var11.getRangeAxisEdge();
    double var16 = var11.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot(var22, var23, var24);
    org.jfree.data.xy.XYDataset var26 = var25.getDataset();
    int var27 = var25.getBackgroundImageAlignment();
    java.lang.Object var28 = var25.clone();
    org.jfree.chart.axis.ValueAxis var29 = var25.getAxis();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var31 = var30.getTickMarkStroke();
    var25.setRadiusGridlineStroke(var31);
    boolean var33 = var21.equals((java.lang.Object)var31);
    var11.setRangeGridlineStroke(var31);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    var11.setDomainCrosshairPaint(var36);
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.ValueAxis var39 = var38.getRangeAxis();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var43 = null;
    var41.setTickLabelFont((java.lang.Comparable)"", var43);
    var41.setFixedDimension(10.0d);
    var41.setTickMarkOutsideLength(1.0f);
    java.awt.Stroke var49 = var41.getAxisLineStroke();
    var38.setRangeGridlineStroke(var49);
    var11.setRangeCrosshairStroke(var49);
    org.jfree.chart.axis.AxisLocation var53 = var11.getDomainAxisLocation(255);
    var4.setRangeAxisLocation(255, var53);
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
    org.jfree.chart.LegendItemCollection var62 = null;
    var61.setFixedLegendItems(var62);
    var61.setRangeCrosshairVisible(true);
    java.awt.Paint var66 = var61.getNoDataMessagePaint();
    var56.setLabelPaint(var66);
    org.jfree.chart.axis.CategoryAxis[] var68 = new org.jfree.chart.axis.CategoryAxis[] { var56};
    var4.setDomainAxes(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 2.888d, 1.0f, 0.0f);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.ChartColor[r=0,g=10,b=10]");
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var4 = var3.getAxisLinePaint();
//     var3.setLabelURL("Multiple Pie Plot");
//     var3.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var15 = null;
//     var13.setTickLabelFont((java.lang.Comparable)"", var15);
//     java.awt.Font var18 = var13.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("ThreadContext", var18);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var18);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     org.jfree.chart.LegendItemCollection var26 = null;
//     var25.setFixedLegendItems(var26);
//     var25.setRangeCrosshairVisible(true);
//     var25.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var32 = var25.getDomainAxisLocation(10);
//     boolean var33 = var25.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var34, var35, var36, var37);
//     org.jfree.chart.LegendItemCollection var39 = null;
//     var38.setFixedLegendItems(var39);
//     var38.setRangeCrosshairVisible(true);
//     var38.configureDomainAxes();
//     org.jfree.chart.plot.Plot var44 = var38.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var46 = var45.getAxisLinePaint();
//     var38.setBackgroundPaint(var46);
//     var25.setRangeCrosshairPaint(var46);
//     var20.setBackgroundPaint(var46);
//     java.awt.geom.Rectangle2D var50 = var20.getBounds();
//     var3.setUpArrow((java.awt.Shape)var50);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     org.jfree.chart.LegendItemCollection var57 = null;
//     var56.setFixedLegendItems(var57);
//     var56.setRangeCrosshairVisible(true);
//     var56.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var63 = var56.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var64 = var56.getDrawingSupplier();
//     org.jfree.chart.block.BlockBorder var69 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
//     boolean var70 = var56.equals((java.lang.Object)100.0d);
//     org.jfree.chart.util.RectangleEdge var72 = var56.getDomainAxisEdge((-1));
//     double var73 = var1.valueToJava2D(100.0d, var50, var72);
//     java.lang.Object var74 = var1.clone();
//     org.jfree.chart.axis.DateTickUnit var75 = null;
//     java.util.Date var76 = var1.calculateHighestVisibleTickValue(var75);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var3.rendererChanged(var7);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var3.zoomDomainAxes(10.0d, 0.0d, var11, var12);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = var14.getPieChart();
    java.awt.Stroke var16 = var15.getBorderStroke();
    var3.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    java.awt.Image var18 = var15.getBackgroundImage();
    var15.setAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.data.xy.XYDataset var4 = var3.getDataset();
//     java.awt.Stroke var5 = null;
//     var3.setRadiusGridlineStroke(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var10 = null;
//     var8.setTickLabelFont((java.lang.Comparable)"", var10);
//     java.awt.Font var13 = var8.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var19 = null;
//     var17.setTickLabelFont((java.lang.Comparable)"", var19);
//     java.awt.Font var22 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("ThreadContext", var22);
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
//     var8.setTickLabelFont(var22);
//     var3.setNoDataMessageFont(var22);
//     java.lang.String var27 = var3.getPlotType();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var31 = var30.getAxisLinePaint();
//     double var32 = var30.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
//     org.jfree.chart.LegendItemCollection var38 = null;
//     var37.setFixedLegendItems(var38);
//     var30.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     java.awt.Shape var41 = var30.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var48 = null;
//     var46.setTickLabelFont((java.lang.Comparable)"", var48);
//     java.awt.Font var51 = var46.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("ThreadContext", var51);
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("", var51);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var54, var55, var56, var57);
//     org.jfree.chart.LegendItemCollection var59 = null;
//     var58.setFixedLegendItems(var59);
//     var58.setRangeCrosshairVisible(true);
//     var58.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var65 = var58.getDomainAxisLocation(10);
//     boolean var66 = var58.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var67 = null;
//     org.jfree.chart.axis.CategoryAxis var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var67, var68, var69, var70);
//     org.jfree.chart.LegendItemCollection var72 = null;
//     var71.setFixedLegendItems(var72);
//     var71.setRangeCrosshairVisible(true);
//     var71.configureDomainAxes();
//     org.jfree.chart.plot.Plot var77 = var71.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var79 = var78.getAxisLinePaint();
//     var71.setBackgroundPaint(var79);
//     var58.setRangeCrosshairPaint(var79);
//     var53.setBackgroundPaint(var79);
//     java.awt.geom.Rectangle2D var83 = var53.getBounds();
//     org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var86 = null;
//     java.util.Collection var87 = var84.getRangeMarkers(255, var86);
//     org.jfree.chart.util.RectangleEdge var88 = var84.getRangeAxisEdge();
//     double var89 = var30.java2DToValue(1.0E-8d, var83, var88);
//     java.awt.Point var90 = var3.translateValueThetaRadiusToJava2D(0.0d, 3.00000001d, var83);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var3 = null;
//     java.util.Collection var4 = var1.getRangeMarkers(255, var3);
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     var1.setRenderer(0, var6);
//     java.lang.Object var8 = null;
//     boolean var9 = var1.equals(var8);
//     org.jfree.chart.plot.DatasetRenderingOrder var10 = var1.getDatasetRenderingOrder();
//     var0.setDatasetRenderingOrder(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var4.zoomRangeAxes((-1.0d), var15, var16);
    org.jfree.chart.util.RectangleEdge var18 = var4.getDomainAxisEdge();
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    var24.setRangeCrosshairVisible(true);
    java.awt.Paint var29 = var24.getNoDataMessagePaint();
    boolean var30 = var19.equals((java.lang.Object)var24);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var36 = var35.getAxisLinePaint();
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 10.0d, 0.0d, var36);
    var19.setOutlinePaint(var36);
    var4.setRangeGridlinePaint(var36);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var4.setFixedRangeAxisSpace(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
    org.jfree.chart.LegendItemCollection var7 = null;
    var6.setFixedLegendItems(var7);
    var6.setRangeCrosshairVisible(true);
    java.awt.Paint var11 = var6.getNoDataMessagePaint();
    boolean var12 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
    java.text.NumberFormat var15 = var13.getNumberFormat();
    java.text.NumberFormat var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    var0.setLabelURL("Multiple Pie Plot");
    var0.resizeRange(0.05d, 0.0d);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var12 = null;
    var10.setTickLabelFont((java.lang.Comparable)"", var12);
    java.awt.Font var15 = var10.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("ThreadContext", var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    var22.setRangeCrosshairVisible(true);
    var22.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var29 = var22.getDomainAxisLocation(10);
    boolean var30 = var22.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var31, var32, var33, var34);
    org.jfree.chart.LegendItemCollection var36 = null;
    var35.setFixedLegendItems(var36);
    var35.setRangeCrosshairVisible(true);
    var35.configureDomainAxes();
    org.jfree.chart.plot.Plot var41 = var35.getRootPlot();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var43 = var42.getAxisLinePaint();
    var35.setBackgroundPaint(var43);
    var22.setRangeCrosshairPaint(var43);
    var17.setBackgroundPaint(var43);
    java.awt.geom.Rectangle2D var47 = var17.getBounds();
    var0.setUpArrow((java.awt.Shape)var47);
    var0.setRange(0.025d, Double.POSITIVE_INFINITY);
    var0.setAutoRangeIncludesZero(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.ChartColor[r=0,g=10,b=10]");
    var1.setRange(0.025d, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(10.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var3.getRangeMarkers(255, var5);
    org.jfree.chart.util.RectangleEdge var7 = var3.getRangeAxisEdge();
    double var8 = var3.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var14, var15, var16);
    org.jfree.data.xy.XYDataset var18 = var17.getDataset();
    int var19 = var17.getBackgroundImageAlignment();
    java.lang.Object var20 = var17.clone();
    org.jfree.chart.axis.ValueAxis var21 = var17.getAxis();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var23 = var22.getTickMarkStroke();
    var17.setRadiusGridlineStroke(var23);
    boolean var25 = var13.equals((java.lang.Object)var23);
    var3.setRangeGridlineStroke(var23);
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var28 = var27.getAxisLinePaint();
    var3.setDomainCrosshairPaint(var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.PolarItemRenderer var32 = null;
    org.jfree.chart.plot.PolarPlot var33 = new org.jfree.chart.plot.PolarPlot(var30, var31, var32);
    org.jfree.data.xy.XYDataset var34 = var33.getDataset();
    int var35 = var33.getBackgroundImageAlignment();
    org.jfree.chart.LegendItemCollection var36 = var33.getLegendItems();
    var3.setFixedLegendItems(var36);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var39 = var38.getAxisLinePaint();
    double var40 = var38.getAutoRangeMinimumSize();
    java.awt.Shape var41 = var38.getDownArrow();
    java.text.NumberFormat var42 = null;
    var38.setNumberFormatOverride(var42);
    org.jfree.chart.axis.ValueAxis[] var44 = new org.jfree.chart.axis.ValueAxis[] { var38};
    var3.setRangeAxes(var44);
    var0.setDomainAxes(var44);
    org.jfree.chart.annotations.XYAnnotation var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var48 = var0.removeAnnotation(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    double var3 = var1.getUpperMargin();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    var8.setRangeCrosshairVisible(true);
    var8.configureDomainAxes();
    org.jfree.chart.plot.Plot var14 = var8.getRootPlot();
    boolean var15 = var1.hasListener((java.util.EventListener)var14);
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     var5.setRangeCrosshairVisible(true);
//     java.awt.Paint var10 = var5.getNoDataMessagePaint();
//     boolean var11 = var0.equals((java.lang.Object)var5);
//     var0.setLabelLinkMargin(100.0d);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var15 = var14.getPieChart();
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
//     boolean var18 = var15.equals((java.lang.Object)var16);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
//     var0.setIgnoreZeroValues(false);
//     java.lang.Object var22 = var0.clone();
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.ChartColor[r=0,g=10,b=10]");
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var27 = var26.getAxisLinePaint();
//     var26.setLabelURL("Multiple Pie Plot");
//     var26.resizeRange(0.05d, 0.0d);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var38 = null;
//     var36.setTickLabelFont((java.lang.Comparable)"", var38);
//     java.awt.Font var41 = var36.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("ThreadContext", var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var41);
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     var48.setRangeCrosshairVisible(true);
//     var48.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var55 = var48.getDomainAxisLocation(10);
//     boolean var56 = var48.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     var61.setRangeCrosshairVisible(true);
//     var61.configureDomainAxes();
//     org.jfree.chart.plot.Plot var67 = var61.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var69 = var68.getAxisLinePaint();
//     var61.setBackgroundPaint(var69);
//     var48.setRangeCrosshairPaint(var69);
//     var43.setBackgroundPaint(var69);
//     java.awt.geom.Rectangle2D var73 = var43.getBounds();
//     var26.setUpArrow((java.awt.Shape)var73);
//     org.jfree.data.category.CategoryDataset var75 = null;
//     org.jfree.chart.axis.CategoryAxis var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var78 = null;
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot(var75, var76, var77, var78);
//     org.jfree.chart.LegendItemCollection var80 = null;
//     var79.setFixedLegendItems(var80);
//     var79.setRangeCrosshairVisible(true);
//     var79.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var86 = var79.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var87 = var79.getDrawingSupplier();
//     org.jfree.chart.block.BlockBorder var92 = new org.jfree.chart.block.BlockBorder(100.0d, 1.0d, 100.0d, 100.0d);
//     boolean var93 = var79.equals((java.lang.Object)100.0d);
//     org.jfree.chart.util.RectangleEdge var95 = var79.getDomainAxisEdge((-1));
//     double var96 = var24.valueToJava2D(100.0d, var73, var95);
//     java.lang.Object var97 = var24.clone();
//     java.util.Date var98 = var24.getMinimumDate();
//     java.awt.Paint var99 = var0.getSectionPaint((java.lang.Comparable)var98);
//     
//     // Checks the contract:  equals-hashcode on var5 and var79
//     assertTrue("Contract failed: equals-hashcode on var5 and var79", var5.equals(var79) ? var5.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var5
//     assertTrue("Contract failed: equals-hashcode on var79 and var5", var79.equals(var5) ? var79.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     double var5 = var0.getRangeCrosshairValue();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var9 = var8.getAxisLinePaint();
//     var8.setLabelURL("Multiple Pie Plot");
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     var12.setVisible(false);
//     boolean var16 = var12.equals((java.lang.Object)1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var17);
//     boolean var19 = var18.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleInsets var20 = var18.getAxisOffset();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var22 = var21.getAxisLinePaint();
//     double var23 = var21.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     java.awt.Shape var32 = var21.getLeftArrow();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var39 = null;
//     var37.setTickLabelFont((java.lang.Comparable)"", var39);
//     java.awt.Font var42 = var37.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var43 = new org.jfree.chart.text.TextFragment("ThreadContext", var42);
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("", var42);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     org.jfree.chart.LegendItemCollection var50 = null;
//     var49.setFixedLegendItems(var50);
//     var49.setRangeCrosshairVisible(true);
//     var49.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var56 = var49.getDomainAxisLocation(10);
//     boolean var57 = var49.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
//     org.jfree.chart.LegendItemCollection var63 = null;
//     var62.setFixedLegendItems(var63);
//     var62.setRangeCrosshairVisible(true);
//     var62.configureDomainAxes();
//     org.jfree.chart.plot.Plot var68 = var62.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var70 = var69.getAxisLinePaint();
//     var62.setBackgroundPaint(var70);
//     var49.setRangeCrosshairPaint(var70);
//     var44.setBackgroundPaint(var70);
//     java.awt.geom.Rectangle2D var74 = var44.getBounds();
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var77 = null;
//     java.util.Collection var78 = var75.getRangeMarkers(255, var77);
//     org.jfree.chart.util.RectangleEdge var79 = var75.getRangeAxisEdge();
//     double var80 = var21.java2DToValue(1.0E-8d, var74, var79);
//     org.jfree.chart.util.LengthAdjustmentType var81 = null;
//     org.jfree.chart.util.LengthAdjustmentType var82 = null;
//     java.awt.geom.Rectangle2D var83 = var20.createAdjustedRectangle(var74, var81, var82);
//     org.jfree.chart.plot.PlotRenderingInfo var84 = null;
//     var0.drawAnnotations(var6, var83, var84);
//     
//     // Checks the contract:  equals-hashcode on var0 and var75
//     assertTrue("Contract failed: equals-hashcode on var0 and var75", var0.equals(var75) ? var0.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var0
//     assertTrue("Contract failed: equals-hashcode on var75 and var0", var75.equals(var0) ? var75.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    double var2 = var0.getAutoRangeMinimumSize();
    java.awt.Shape var3 = var0.getDownArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var3, "");
    java.lang.String var6 = var5.toString();
    var5.setURLText("");
    java.lang.String var9 = var5.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = "+ "'", var6.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "poly"+ "'", var9.equals("poly"));

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = null;
    var3.setRadiusGridlineStroke(var5);
    org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
    boolean var9 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.util.UnitType var10 = var8.getUnitType();
    java.lang.Object var11 = null;
    boolean var12 = var8.equals(var11);
    double var14 = var8.calculateLeftInset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Polar Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.axis.AxisLocation var16 = var4.getRangeAxisLocation();
    java.awt.Stroke var17 = var4.getRangeGridlineStroke();
    org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.String var19 = var18.getPlotType();
    java.awt.Image var20 = var18.getBackgroundImage();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot(var21, var22, var23);
    org.jfree.data.xy.XYDataset var25 = var24.getDataset();
    java.awt.Stroke var26 = null;
    var24.setRadiusGridlineStroke(var26);
    org.jfree.chart.LegendItemCollection var28 = var24.getLegendItems();
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets();
    boolean var30 = var28.equals((java.lang.Object)var29);
    org.jfree.chart.util.UnitType var31 = var29.getUnitType();
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
    org.jfree.chart.LegendItemCollection var37 = null;
    var36.setFixedLegendItems(var37);
    var36.setRangeCrosshairVisible(true);
    java.awt.Paint var41 = var36.getNoDataMessagePaint();
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(var29, var41);
    boolean var43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)var41);
    var4.setRangeGridlinePaint(var41);
    org.jfree.data.category.CategoryDataset var46 = var4.getDataset(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Multiple Pie Plot"+ "'", var19.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var3 = var2.getAxisLinePaint();
    var2.setLabelURL("Multiple Pie Plot");
    var2.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var13.setFixedLegendItems(var14);
    var13.setRangeCrosshairVisible(true);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var19);
    boolean var21 = var20.isRangeCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var24.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var28.setVisible(false);
    boolean var32 = var28.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var28, var33);
    var28.configure();
    var28.setPositiveArrowVisible(false);
    var20.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var28);
    var28.setLabel("Range[1.0,8.025]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    boolean var14 = var4.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    java.awt.geom.Point2D var18 = null;
    var4.zoomRangeAxes(0.025d, 100.0d, var17, var18);
    java.awt.Paint var20 = var4.getRangeCrosshairPaint();
    var4.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var4 = null;
//     var2.setTickLabelFont((java.lang.Comparable)"", var4);
//     java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var13 = null;
//     var11.setTickLabelFont((java.lang.Comparable)"", var13);
//     java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
//     var2.setTickLabelFont(var16);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var24.setFixedLegendItems(var25);
//     var24.setRangeCrosshairVisible(true);
//     var24.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var31 = var24.getDomainAxisLocation(10);
//     org.jfree.chart.plot.DrawingSupplier var32 = var24.getDrawingSupplier();
//     java.awt.Stroke var33 = var24.getDomainGridlineStroke();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var24, false);
//     var35.setNotify(true);
//     boolean var38 = var35.isBorderVisible();
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     java.awt.image.BufferedImage var42 = var35.createBufferedImage(15, 100, var41);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Stroke var3 = var0.getSectionOutlineStroke((java.lang.Comparable)1.0E-8d);
    double var4 = var0.getInnerSeparatorExtension();
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    java.awt.Stroke var7 = var0.getSectionOutlineStroke((java.lang.Comparable)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var11.setLabelURL("Multiple Pie Plot");
    org.jfree.data.Range var17 = new org.jfree.data.Range(1.0d, 8.025d);
    boolean var19 = var17.contains(0.025d);
    var11.setRangeWithMargins(var17);
    org.jfree.chart.axis.ValueAxis[] var21 = new org.jfree.chart.axis.ValueAxis[] { var11};
    var0.setDomainAxes(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var24 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var23};
    var0.setRenderers(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var27 = var0.getQuadrantPaint(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    var0.setDomainCrosshairValue(2.00000001d, false);
    org.jfree.data.xy.XYDataset var15 = var0.getDataset(10);
    var0.clearRangeAxes();
    java.awt.Stroke var17 = var0.getDomainGridlineStroke();
    java.util.List var18 = var0.getAnnotations();
    org.jfree.chart.axis.ValueAxis var19 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    var10.setPadding(1.0E-8d, 0.0d, 0.0d, 10.0d);
    org.jfree.chart.util.RectangleEdge var16 = var10.getPosition();
    org.jfree.chart.event.TitleChangeEvent var17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var10);
    org.jfree.chart.title.Title var18 = var17.getTitle();
    org.jfree.chart.title.Title var19 = var17.getTitle();
    java.lang.Object var20 = var17.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    var2.setBackgroundImageAlignment((-16774646));
    java.lang.Object var5 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     org.jfree.chart.LegendItemCollection var15 = null;
//     var14.setFixedLegendItems(var15);
//     var14.setRangeCrosshairVisible(true);
//     var14.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var21 = var14.getDomainAxisLocation(10);
//     var4.setDomainAxisLocation(10, var21);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var4.", var14.equals(var4) == var4.equals(var14));
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var4.getRendererForDataset(var9);
//     org.jfree.chart.axis.CategoryAxis var12 = var4.getDomainAxisForDataset(10);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var4.handleClick(1, 0, var15);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var4 = var3.getTickMarkStroke();
    var0.put((java.lang.Comparable)(byte)10, var4);
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    var12.setRangeCrosshairVisible(true);
    java.awt.Paint var17 = var12.getNoDataMessagePaint();
    boolean var18 = var7.equals((java.lang.Object)var12);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var7.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var19);
    java.awt.Paint var21 = var7.getLabelOutlinePaint();
    java.awt.Stroke var22 = var7.getBaseSectionOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.put((java.lang.Comparable)"LengthConstraintType.FIXED", var22);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    boolean var12 = var4.isDomainZoomable();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot(var13, var14, var15);
    org.jfree.data.xy.XYDataset var17 = var16.getDataset();
    java.awt.Stroke var18 = null;
    var16.setRadiusGridlineStroke(var18);
    org.jfree.chart.LegendItemCollection var20 = var16.getLegendItems();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets();
    boolean var22 = var20.equals((java.lang.Object)var21);
    var4.setFixedLegendItems(var20);
    var4.mapDatasetToDomainAxis(255, 10);
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var29.setMaximumCategoryLabelWidthRatio((-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxis((-1), var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeGridlinePaint();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var6, var7, var8);
    org.jfree.data.xy.XYDataset var10 = var9.getDataset();
    int var11 = var9.getBackgroundImageAlignment();
    java.lang.Object var12 = var9.clone();
    org.jfree.chart.axis.ValueAxis var13 = var9.getAxis();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var15 = var14.getTickMarkStroke();
    var9.setRadiusGridlineStroke(var15);
    var4.setRangeGridlineStroke(var15);
    boolean var18 = var4.isRangeCrosshairVisible();
    java.lang.Object var19 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var3 = null;
    var1.setTickLabelFont((java.lang.Comparable)"", var3);
    java.awt.Font var6 = null;
    var1.setTickLabelFont((java.lang.Comparable)(short)10, var6);
    var1.configure();
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var11 = var10.getAxisLinePaint();
    var10.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    var14.setVisible(false);
    boolean var18 = var14.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
    boolean var21 = var20.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleInsets var22 = var20.getAxisOffset();
    double var24 = var22.extendWidth(0.025d);
    var1.setTickLabelInsets(var22);
    double var26 = var1.getUpperMargin();
    float var27 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 8.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0f);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(1.0d, (-1.0d), 10.0d, 1.0d);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot(var11, var12, var13);
    org.jfree.data.xy.XYDataset var15 = var14.getDataset();
    int var16 = var14.getBackgroundImageAlignment();
    java.lang.Object var17 = var14.clone();
    org.jfree.chart.axis.ValueAxis var18 = var14.getAxis();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Stroke var20 = var19.getTickMarkStroke();
    var14.setRadiusGridlineStroke(var20);
    boolean var22 = var10.equals((java.lang.Object)var20);
    var0.setRangeGridlineStroke(var20);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var0.setDomainCrosshairPaint(var25);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.PolarItemRenderer var29 = null;
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var27, var28, var29);
    org.jfree.data.xy.XYDataset var31 = var30.getDataset();
    int var32 = var30.getBackgroundImageAlignment();
    org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
    var0.setFixedLegendItems(var33);
    java.util.Iterator var35 = var33.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var3);
//     java.util.ResourceBundle.Control var5 = null;
//     java.util.ResourceBundle var6 = java.util.ResourceBundle.getBundle("Category Plot", var1, var3, var5);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = null;
    var2.setTickLabelFont((java.lang.Comparable)"", var4);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    java.awt.Paint var11 = var10.getRangeGridlinePaint();
    var2.setTickLabelPaint(var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var14 = var13.getAxisLinePaint();
    var13.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var13, var17);
    var2.setCategoryLabelPositionOffset(10);
    var2.setAxisLineVisible(true);
    java.lang.Comparable var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var24 = var2.getTickLabelFont(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainCrosshairPaint();
    boolean var2 = var0.isDomainCrosshairLockedOnData();
    var0.mapDatasetToRangeAxis(15, 0);
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    var0.configureRangeAxes();
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(1.0d, var7, var8, false);
    var0.setDomainCrosshairValue(2.00000001d);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var0.setFixedRangeAxisSpace(var13, false);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var21 = null;
    var19.setTickLabelFont((java.lang.Comparable)"", var21);
    java.awt.Font var24 = var19.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("ThreadContext", var24);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
    double var27 = var26.getHeight();
    java.awt.Font var28 = var26.getFont();
    var0.setNoDataMessageFont(var28);
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var31, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("ThreadContext");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.awt.Color var1 = java.awt.Color.getColor("XY Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var7 = null;
    var5.setTickLabelFont((java.lang.Comparable)"", var7);
    java.awt.Font var10 = var5.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("ThreadContext", var10);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var10);
    double var13 = var12.getHeight();
    java.awt.Font var14 = var12.getFont();
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var17 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var20 = var19.getHeightConstraintType();
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var23 = null;
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var26 = var25.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(10.0d, var16, var20, 0.2d, var22, var26);
    var1.add((org.jfree.chart.block.Block)var12, (java.lang.Object)0.2d);
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var34 = null;
    var32.setTickLabelFont((java.lang.Comparable)"", var34);
    java.awt.Font var37 = var32.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("ThreadContext", var37);
    org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("", var37);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var43 = null;
    var41.setTickLabelFont((java.lang.Comparable)"", var43);
    java.awt.Font var46 = var41.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var52 = null;
    var50.setTickLabelFont((java.lang.Comparable)"", var52);
    java.awt.Font var55 = var50.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("ThreadContext", var55);
    org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("", var55);
    var41.setTickLabelFont(var55);
    var39.setFont(var55);
    var1.add((org.jfree.chart.block.Block)var39, (java.lang.Object)'a');
    java.lang.String var62 = var39.getText();
    java.awt.Graphics2D var63 = null;
    org.jfree.chart.block.RectangleConstraint var66 = new org.jfree.chart.block.RectangleConstraint(8.025d, 10.0d);
    org.jfree.data.Range var69 = new org.jfree.data.Range(1.0d, 8.025d);
    org.jfree.chart.block.RectangleConstraint var70 = var66.toRangeHeight(var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var71 = var39.arrange(var63, var66);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + ""+ "'", var62.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("XY Plot", var1, 1.0d, 1.0f, 0.0f);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    double var3 = var1.getAutoRangeMinimumSize();
    var1.setAutoRange(false);
    org.jfree.data.RangeType var6 = var1.getRangeType();
    boolean var7 = var1.isTickLabelsVisible();
    boolean var8 = var1.getAutoRangeStickyZero();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var10 = var9.getAxisLinePaint();
    double var11 = var9.getAutoRangeMinimumSize();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    java.awt.Shape var20 = var9.getLeftArrow();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var9, var21);
    var9.setAutoRangeMinimumSize(90.0d);
    double var25 = var9.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-44.55d));

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlockAnchor var4 = null;
//     var0.draw(var1, (-1.0f), 100.0f, var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.text.TextBlockAnchor var9 = null;
//     var0.draw(var6, 1.0f, 0.0f, var9, 0.5f, (-1.0f), 0.0d);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot(var15, var16, var17);
//     org.jfree.data.xy.XYDataset var19 = var18.getDataset();
//     int var20 = var18.getBackgroundImageAlignment();
//     org.jfree.chart.LegendItemCollection var21 = var18.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     java.awt.geom.Point2D var24 = null;
//     var18.zoomDomainAxes(10.0d, var23, var24);
//     java.awt.Font var26 = var18.getAngleLabelFont();
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var28 = var27.getLabelLinkStroke();
//     java.awt.Paint var30 = var27.getSectionOutlinePaint((java.lang.Comparable)0);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.plot.MultiplePiePlot var32 = new org.jfree.chart.plot.MultiplePiePlot(var31);
//     org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var32.setAggregatedItemsPaint((java.awt.Paint)var36);
//     java.lang.String var38 = var36.toString();
//     var27.setSeparatorPaint((java.awt.Paint)var36);
//     var0.addLine("Category Plot", var26, (java.awt.Paint)var36);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var44 = null;
//     java.awt.Shape var48 = var0.calculateBounds(var41, 0.5f, 0.5f, var44, 1.0f, 100.0f, 0.36000000179999997d);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.plot.Plot var10 = var4.getRootPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var12 = var11.getAxisLinePaint();
    var4.setBackgroundPaint(var12);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var4.notifyListeners(var14);
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge();
    org.jfree.data.category.CategoryDataset var17 = null;
    var4.setDataset(var17);
    org.jfree.chart.axis.AxisSpace var19 = var4.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = var4.getFixedLegendItems();
    java.lang.Object var15 = var4.clone();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var18.setLabelAngle(1.0d);
    var4.setDomainAxis(0, var18, true);
    org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var24 = var23.getPieChart();
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var26 = var25.getFixedLegendItems();
    boolean var27 = var24.equals((java.lang.Object)var25);
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var31 = null;
    var29.setTickLabelFont((java.lang.Comparable)"", var31);
    var29.setFixedDimension(10.0d);
    var29.setTickMarkOutsideLength(1.0f);
    java.awt.Stroke var37 = var29.getAxisLineStroke();
    var24.setBorderStroke(var37);
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
    org.jfree.chart.LegendItemCollection var44 = null;
    var43.setFixedLegendItems(var44);
    var43.setRangeCrosshairVisible(true);
    var43.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var50 = var43.getDomainAxisLocation(10);
    boolean var51 = var43.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var52 = null;
    org.jfree.chart.axis.CategoryAxis var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
    org.jfree.chart.LegendItemCollection var57 = null;
    var56.setFixedLegendItems(var57);
    var56.setRangeCrosshairVisible(true);
    var56.configureDomainAxes();
    org.jfree.chart.plot.Plot var62 = var56.getRootPlot();
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var64 = var63.getAxisLinePaint();
    var56.setBackgroundPaint(var64);
    var43.setRangeCrosshairPaint(var64);
    var24.setBorderPaint(var64);
    org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var73 = null;
    var71.setTickLabelFont((java.lang.Comparable)"", var73);
    java.awt.Font var76 = var71.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("ThreadContext", var76);
    org.jfree.chart.title.TextTitle var78 = new org.jfree.chart.title.TextTitle("", var76);
    var78.setPadding(1.0E-8d, 0.0d, 0.0d, 10.0d);
    org.jfree.chart.util.RectangleEdge var84 = var78.getPosition();
    org.jfree.chart.event.TitleChangeEvent var85 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var78);
    var24.titleChanged(var85);
    org.jfree.chart.plot.MultiplePiePlot var87 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var88 = var87.getPieChart();
    var88.setTitle("ThreadContext");
    var85.setChart(var88);
    var4.addChangeListener((org.jfree.chart.event.PlotChangeListener)var88);
    org.jfree.chart.title.LegendTitle var93 = var88.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var5 = null;
    var3.setTickLabelFont((java.lang.Comparable)"", var5);
    java.awt.Font var8 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("ThreadContext", var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var8);
    double var11 = var10.getHeight();
    java.awt.Font var12 = var10.getFont();
    double var13 = var10.getWidth();
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = var14.getPieChart();
    java.awt.Stroke var16 = var15.getBorderStroke();
    var10.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var15);
    org.jfree.chart.event.ChartChangeListener var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addChangeListener(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = var0.getPieChart();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    boolean var4 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var8 = null;
    var6.setTickLabelFont((java.lang.Comparable)"", var8);
    var6.setFixedDimension(10.0d);
    var6.setTickMarkOutsideLength(1.0f);
    java.awt.Stroke var14 = var6.getAxisLineStroke();
    var1.setBorderStroke(var14);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
    org.jfree.chart.LegendItemCollection var21 = null;
    var20.setFixedLegendItems(var21);
    var20.setRangeCrosshairVisible(true);
    var20.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var27 = var20.getDomainAxisLocation(10);
    boolean var28 = var20.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
    org.jfree.chart.LegendItemCollection var34 = null;
    var33.setFixedLegendItems(var34);
    var33.setRangeCrosshairVisible(true);
    var33.configureDomainAxes();
    org.jfree.chart.plot.Plot var39 = var33.getRootPlot();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var41 = var40.getAxisLinePaint();
    var33.setBackgroundPaint(var41);
    var20.setRangeCrosshairPaint(var41);
    var1.setBorderPaint(var41);
    org.jfree.chart.event.ChartProgressListener var45 = null;
    var1.addProgressListener(var45);
    var1.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomDomainAxes((-1.0d), 0.0d, var11, var12);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var4.zoomDomainAxes(100.0d, var15, var16);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var4.drawBackgroundImage(var18, var19);
    java.lang.String var21 = var4.getPlotType();
    org.jfree.chart.event.MarkerChangeEvent var22 = null;
    var4.markerChanged(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Category Plot"+ "'", var21.equals("Category Plot"));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var3 = var2.getAxisLinePaint();
    var2.setLabelURL("Multiple Pie Plot");
    var2.resizeRange(0.05d, 0.0d);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var13.setFixedLegendItems(var14);
    var13.setRangeCrosshairVisible(true);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var19);
    boolean var21 = var20.isRangeCrosshairLockedOnData();
    org.jfree.chart.annotations.XYAnnotation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var23 = var20.removeAnnotation(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(255, var2);
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(0, var8);
    var0.setWeight(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var4 = null;
    var2.setTickLabelFont((java.lang.Comparable)"", var4);
    java.awt.Font var7 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Font var13 = null;
    var11.setTickLabelFont((java.lang.Comparable)"", var13);
    java.awt.Font var16 = var11.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("ThreadContext", var16);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
    var2.setTickLabelFont(var16);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    var24.setRangeCrosshairVisible(true);
    var24.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var31 = var24.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var32 = var24.getDrawingSupplier();
    java.awt.Stroke var33 = var24.getDomainGridlineStroke();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var24, false);
    org.jfree.chart.annotations.CategoryAnnotation var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var37 = var24.removeAnnotation(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getRangeMarkers(255, var2);
//     var0.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.StrokeMap var7 = new org.jfree.chart.StrokeMap();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot(var8);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(0, 10, 10);
//     var9.setAggregatedItemsPaint((java.awt.Paint)var13);
//     boolean var15 = var7.equals((java.lang.Object)var13);
//     int var16 = var13.getAlpha();
//     java.awt.image.ColorModel var17 = null;
//     java.awt.Rectangle var18 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Font var24 = null;
//     var22.setTickLabelFont((java.lang.Comparable)"", var24);
//     java.awt.Font var27 = var22.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("ThreadContext", var27);
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("", var27);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     var34.setRangeCrosshairVisible(true);
//     var34.configureDomainAxes();
//     org.jfree.chart.axis.AxisLocation var41 = var34.getDomainAxisLocation(10);
//     boolean var42 = var34.isDomainZoomable();
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var43, var44, var45, var46);
//     org.jfree.chart.LegendItemCollection var48 = null;
//     var47.setFixedLegendItems(var48);
//     var47.setRangeCrosshairVisible(true);
//     var47.configureDomainAxes();
//     org.jfree.chart.plot.Plot var53 = var47.getRootPlot();
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Paint var55 = var54.getAxisLinePaint();
//     var47.setBackgroundPaint(var55);
//     var34.setRangeCrosshairPaint(var55);
//     var29.setBackgroundPaint(var55);
//     java.awt.geom.Rectangle2D var59 = var29.getBounds();
//     java.awt.geom.AffineTransform var60 = null;
//     java.awt.RenderingHints var61 = null;
//     java.awt.PaintContext var62 = var13.createContext(var17, var18, var59, var60, var61);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var65 = null;
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot(var63, var64, var65);
//     org.jfree.data.xy.XYDataset var67 = var66.getDataset();
//     int var68 = var66.getBackgroundImageAlignment();
//     java.lang.Object var69 = var66.clone();
//     org.jfree.chart.axis.ValueAxis var70 = var66.getAxis();
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Stroke var72 = var71.getTickMarkStroke();
//     var66.setRadiusGridlineStroke(var72);
//     java.awt.Paint var74 = null;
//     org.jfree.data.xy.XYDataset var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var77 = null;
//     org.jfree.chart.plot.PolarPlot var78 = new org.jfree.chart.plot.PolarPlot(var75, var76, var77);
//     org.jfree.data.xy.XYDataset var79 = var78.getDataset();
//     java.awt.Stroke var80 = null;
//     var78.setRadiusGridlineStroke(var80);
//     org.jfree.chart.LegendItemCollection var82 = var78.getLegendItems();
//     java.awt.Stroke var83 = var78.getAngleGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint)var13, var72, var74, var83, 0.5f);
//     java.awt.Paint var86 = var85.getPaint();
//     java.awt.Paint var87 = var85.getLabelPaint();
//     org.jfree.chart.util.Layer var88 = null;
//     boolean var89 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var85, var88);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    var4.setRangeCrosshairVisible(true);
    var4.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var11 = var4.getDomainAxisLocation(10);
    org.jfree.chart.plot.DrawingSupplier var12 = var4.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var4.zoomRangeAxes(0.025d, var14, var15, false);
    org.jfree.chart.axis.AxisLocation var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-16774646), var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setLabelURL("Multiple Pie Plot");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    var5.setVisible(false);
    boolean var9 = var5.equals((java.lang.Object)1);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainGridlinesVisible();
    var11.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var11.setFixedDomainAxisSpace(var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.isCircular();
    java.awt.Paint var2 = var0.getLabelOutlinePaint();
    org.jfree.chart.ui.BasicProjectInfo var3 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getOptionalLibraries();
    var3.setLicenceName("hi!");
    boolean var7 = var0.equals((java.lang.Object)"hi!");
    org.jfree.chart.urls.PieURLGenerator var8 = var0.getLegendLabelURLGenerator();
    java.awt.Stroke var9 = var0.getLabelOutlineStroke();
    double var10 = var0.getStartAngle();
    org.jfree.chart.urls.PieURLGenerator var11 = var0.getLegendLabelURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

}
