
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 0.0f, (-1.0f), var4);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(-1.0d), var1, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, 100.0d, 100.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.axis.Axis var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, (-1.0f), 1.0d, 1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)100L);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 1.0d, false);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.block.Arrangement var1 = null;
    org.jfree.chart.block.Arrangement var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 100.0f, 10.0f);
    java.awt.Paint var13 = null;
    java.awt.Paint var15 = null;
    java.awt.Stroke var16 = null;
    java.awt.Shape var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Paint var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "hi!", "", false, var7, true, var13, true, var15, var16, false, var18, var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)'a');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(1, (-1), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 1.0d, var2);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Paint var7 = null;
    java.awt.Stroke var8 = null;
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem(var0, "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "", "", var6, var7, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var3 = var2.getRowRenderingOrder();
//     var0.setColumnRenderingOrder(var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", var1);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Range[100.0,100.0]", var1, 0.0f, 0.0f, var4, 1.0d, 0.0f, 10.0f);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.util.SortOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 100);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1, 10.0f, 100.0f, var4, 100.0d, var6);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var3 = var0.removeAnnotation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 1.0f, 100, var5);
    org.jfree.chart.text.TextLine var7 = null;
    var6.addLine(var7);
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLineAlignment(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker((-1.0d), var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 1.0f, 100, var5);
    java.awt.Font var8 = null;
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addLine("", var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), (-1.0f), var4);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!", var1);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setNoDataMessage("");
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100.0d};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     java.awt.Paint var2 = null;
//     var0.setOutlinePaint(var2);
//     var0.zoom(10.0d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var2 = var0.createOutsetRectangle(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setItemPaint(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), (-1.0d), var2);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     org.jfree.chart.plot.PlotState var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.draw(var1, var2, var3, var4, var5);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    java.util.List var2 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var2);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "hi!", var3);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)100L, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var4 = null;
//     org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 100.0d);
//     java.lang.String var7 = var6.toString();
//     var3.setDefaultAutoRange(var6);
//     double var9 = var3.getUpperMargin();
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeGridline(var1, var2, (org.jfree.chart.axis.ValueAxis)var3, var10, 0.0d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    var0.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlinePaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, Double.NaN, false);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(true);
    java.awt.Paint var3 = null;
    var0.setOutlinePaint(var3);
    org.jfree.chart.block.Arrangement var5 = null;
    org.jfree.chart.block.Arrangement var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var6, var9);
    java.awt.Paint var11 = null;
    java.awt.Stroke var12 = null;
    java.awt.Paint var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem(var0, "", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "", var9, var11, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    float var2 = var0.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.95f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.awt.Color var1 = java.awt.Color.getColor("Range[100.0,100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    var4.setInverted(true);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 100.0d, 100.0f, 10.0f);
    var4.setRightArrow(var16);
    java.awt.Paint var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Paint var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem(var0, "Range[100.0,100.0]", "Range[100.0,100.0]", "HorizontalAlignment.CENTER", var16, var18, var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    var0.setInverted(true);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 100.0f, 10.0f);
    var0.setRightArrow(var12);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    java.lang.String var17 = var16.toString();
    var0.setRangeWithMargins(var16);
    double var19 = var16.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Range[100.0,100.0]"+ "'", var17.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", var3);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var6 = var5.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var5.setDomainAxisLocation(1, var8, true);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var5.addChangeListener(var11);
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var5.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     var5.clearRangeMarkers();
//     org.jfree.chart.LegendItemCollection var16 = var5.getFixedLegendItems();
//     java.awt.geom.Rectangle2D var17 = null;
//     var0.drawBackground(var4, var5, var17);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("HorizontalAlignment.CENTER", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.draw(var3, var4);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    var0.setLowerBound(10.0d);
    var0.setAxisLineVisible(false);
    org.jfree.chart.axis.NumberTickUnit var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var7 = var5.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var5.getLegendItemLabelGenerator();
    java.awt.Paint var11 = var5.getItemPaint(0, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-16777216), var11, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    var0.setInverted(true);
    double var6 = var0.getUpperMargin();
    java.awt.Shape var7 = var0.getLeftArrow();
    org.jfree.chart.util.RectangleInsets var8 = var0.getLabelInsets();
    double var9 = var0.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 10.0f);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     float var4 = var1.calculateBaselineOffset(var2, var3);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("HorizontalAlignment.CENTER", var1, 100.0f, 0.0f, 100.0d, 0.95f, (-1.0f));
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     java.awt.Shape var2 = var0.getUpArrow();
//     double var3 = var0.getLowerBound();
//     var0.setInverted(true);
//     double var6 = var0.getUpperMargin();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var10 = var9.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var12 = null;
//     var9.setDomainAxisLocation(1, var12, true);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var9.addChangeListener(var15);
//     org.jfree.chart.plot.DatasetRenderingOrder var17 = var9.getDatasetRenderingOrder();
//     double var18 = var9.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var19 = null;
//     var9.axisChanged(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var9.getRangeAxisEdge();
//     double var22 = var0.valueToJava2D(100.0d, var8, var21);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(100);
    int var4 = var0.indexOf((java.lang.Object)Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "RectangleAnchor.CENTER"};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    float[] var5 = new float[] { 1.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB((-1), 1, 0, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
    org.jfree.chart.block.BlockContainer var11 = null;
    var9.setWrapper(var11);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.clearDomainMarkers((-1));
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var22 = var20.equals((java.lang.Object)(short)1);
    var13.setAxisOffset(var20);
    var9.setLegendItemGraphicPadding(var20);
    java.awt.geom.Rectangle2D var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var28 = var20.createOutsetRectangle(var25, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers((-1));
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryMarker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", var1, 0.0d, 10.0f, 0.95f);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 0.0d);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    java.awt.Font var4 = var0.getSeriesItemLabelFont(15);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.LengthConstraintType var6 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    boolean var13 = var10.equals((java.lang.Object)(byte)100);
    boolean var15 = var10.contains(1.0d);
    double var16 = var10.getUpperBound();
    org.jfree.chart.block.LengthConstraintType var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var5, var6, 10.0d, var10, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[100.0,100.0]"+ "'", var11.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var13 = var12.getLabelFont();
    var9.setItemFont(var13);
    org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleInsets var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setItemLabelPadding(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", var1, var2);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     double var3 = var2.getFixedAutoRange();
//     java.awt.Shape var4 = var2.getUpArrow();
//     double var5 = var2.getLowerBound();
//     var2.setInverted(true);
//     double var8 = var2.getUpperMargin();
//     java.awt.Shape var9 = var2.getLeftArrow();
//     java.awt.GradientPaint var10 = var0.transform(var1, var9);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
    java.lang.String var5 = var4.toString();
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-1.0d), (java.lang.Object)var4);
    double var8 = var4.constrain((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Range[100.0,100.0]"+ "'", var5.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var9 = var7.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var10 = var7.getGradientPaintTransformer();
    java.awt.Stroke var11 = var7.getBaseStroke();
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var14 = var12.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    double var17 = var16.getFixedAutoRange();
    java.awt.Shape var18 = var16.getUpArrow();
    double var19 = var16.getLowerBound();
    java.awt.Stroke var20 = var16.getTickMarkStroke();
    var12.setSeriesStroke(0, var20, false);
    java.awt.Stroke var24 = var12.getSeriesStroke((-16777216));
    java.awt.Paint var25 = var12.getBaseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem(var0, "Range[100.0,100.0]", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "RectangleAnchor.CENTER", var6, var11, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var22 = var20.equals((java.lang.Object)(short)1);
//     var13.setAxisOffset(var20);
//     var9.setLegendItemGraphicPadding(var20);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var27 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var28 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var29 = var28.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var30 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var27, var28);
//     java.lang.Object var31 = var9.draw(var25, var26, (java.lang.Object)var27);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
    java.lang.String var15 = var14.toString();
    var11.setDefaultAutoRange(var14);
    double var17 = var11.getUpperMargin();
    java.awt.Paint var18 = var11.getAxisLinePaint();
    var9.setBackgroundPaint(var18);
    java.awt.Paint var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setItemPaint(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Range[100.0,100.0]"+ "'", var15.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var7 = var6.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var9 = null;
//     var6.setDomainAxisLocation(1, var9, true);
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var6.addChangeListener(var12);
//     org.jfree.chart.plot.DatasetRenderingOrder var14 = var6.getDatasetRenderingOrder();
//     double var15 = var6.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var16 = null;
//     var6.axisChanged(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var6.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.axis.AxisState var20 = var0.draw(var2, 1.0d, var4, var5, var18, var19);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var0.getDomainMarkers(100, var10);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var14 = var13.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var13.zoomDomainAxes((-1.0d), var16, var17);
//     org.jfree.chart.axis.AxisLocation var20 = var13.getDomainAxisLocation(15);
//     var0.setRangeAxisLocation(15, var20);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleEdge var10 = var0.getDomainAxisEdge();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var13 = var11.getSeriesVisible(15);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11, false);
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var9.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("", var4);
//     org.jfree.chart.text.TextFragment var6 = null;
//     var5.addFragment(var6);
//     var0.addLine(var5);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     java.awt.Shape var16 = var0.calculateBounds(var9, 1.0f, 100.0f, var12, 100.0f, 0.95f, 0.05d);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setNoDataMessage("");
    var0.clearDomainMarkers((-1));
    org.jfree.chart.plot.CategoryMarker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-16777216), var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     java.lang.String var15 = var14.toString();
//     var11.setDefaultAutoRange(var14);
//     double var17 = var11.getUpperMargin();
//     java.awt.Paint var18 = var11.getAxisLinePaint();
//     var9.setBackgroundPaint(var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var21 = var20.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setDomainAxisLocation(1, var23, true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var20.addChangeListener(var26);
//     org.jfree.chart.plot.DatasetRenderingOrder var28 = var20.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     org.jfree.chart.util.RectangleEdge var30 = var20.getDomainAxisEdge();
//     var9.setLegendItemGraphicEdge(var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     java.lang.String var15 = var14.toString();
//     var11.setDefaultAutoRange(var14);
//     double var17 = var11.getUpperMargin();
//     java.awt.Paint var18 = var11.getAxisLinePaint();
//     var9.setBackgroundPaint(var18);
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var18};
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     double var24 = var23.getFixedAutoRange();
//     java.awt.Shape var25 = var23.getUpArrow();
//     double var26 = var23.getLowerBound();
//     var23.setInverted(true);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 100.0d, 100.0f, 10.0f);
//     var23.setRightArrow(var35);
//     boolean var37 = var22.equals((java.lang.Object)var23);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var39 = var38.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var38.setDomainAxisLocation(1, var41, true);
//     org.jfree.chart.event.PlotChangeListener var44 = null;
//     var38.addChangeListener(var44);
//     org.jfree.chart.plot.DatasetRenderingOrder var46 = var38.getDatasetRenderingOrder();
//     double var47 = var38.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var48 = null;
//     var38.axisChanged(var48);
//     org.jfree.chart.util.RectangleEdge var50 = var38.getRangeAxisEdge();
//     java.awt.Paint var51 = var38.getRangeCrosshairPaint();
//     var23.setLabelPaint(var51);
//     java.awt.Paint[] var53 = new java.awt.Paint[] { var51};
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var56 = var54.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var57 = var54.getLegendItemLabelGenerator();
//     java.awt.Paint var58 = var54.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     var59.clearDomainMarkers((-1));
//     var59.setBackgroundAlpha(0.0f);
//     boolean var64 = var54.hasListener((java.util.EventListener)var59);
//     org.jfree.chart.labels.CategoryToolTipGenerator var67 = var54.getToolTipGenerator(10, 15);
//     java.awt.Paint var69 = var54.lookupSeriesPaint(100);
//     java.awt.Paint[] var70 = new java.awt.Paint[] { var69};
//     org.jfree.chart.renderer.category.BarRenderer var71 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var73 = var71.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var74 = var71.getGradientPaintTransformer();
//     java.awt.Stroke var75 = var71.getBaseStroke();
//     java.awt.Stroke[] var76 = new java.awt.Stroke[] { var75};
//     org.jfree.chart.renderer.category.BarRenderer var77 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var79 = var77.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var81 = new org.jfree.chart.axis.NumberAxis();
//     double var82 = var81.getFixedAutoRange();
//     java.awt.Shape var83 = var81.getUpArrow();
//     double var84 = var81.getLowerBound();
//     java.awt.Stroke var85 = var81.getTickMarkStroke();
//     var77.setSeriesStroke(0, var85, false);
//     java.awt.Stroke[] var88 = new java.awt.Stroke[] { var85};
//     java.awt.Shape[] var89 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var90 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var53, var70, var76, var88, var89);
//     
//     // Checks the contract:  equals-hashcode on var0 and var38
//     assertTrue("Contract failed: equals-hashcode on var0 and var38", var0.equals(var38) ? var0.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var0
//     assertTrue("Contract failed: equals-hashcode on var38 and var0", var38.equals(var0) ? var38.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var77.", var54.equals(var77) == var77.equals(var54));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var71 and var77.", var71.equals(var77) == var77.equals(var71));
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getCategoryAnchor();
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var2);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var0.getBaseToolTipGenerator();
    var0.setSeriesItemLabelsVisible(0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var8 = var6.toFixedWidth((-1.0d));
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var3, var8);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    boolean var5 = var0.isItemLabelVisible(15, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     double var9 = var0.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var0.axisChanged(var10);
//     org.jfree.chart.util.RectangleEdge var12 = var0.getRangeAxisEdge();
//     org.jfree.chart.plot.Marker var13 = null;
//     org.jfree.chart.util.Layer var14 = null;
//     var0.addRangeMarker(var13, var14);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.KeyedObjects var2 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var4 = var2.getObject((java.lang.Comparable)(byte)1);
//     boolean var5 = var0.equals((java.lang.Object)var2);
//     java.lang.Object var6 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var14 = var13.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var16 = null;
//     var13.setDomainAxisLocation(1, var16, true);
//     org.jfree.chart.event.PlotChangeListener var19 = null;
//     var13.addChangeListener(var19);
//     org.jfree.chart.plot.DatasetRenderingOrder var21 = var13.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.util.RectangleEdge var23 = var13.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var13.setFixedDomainAxisSpace(var24);
//     org.jfree.chart.LegendItemSource[] var26 = new org.jfree.chart.LegendItemSource[] { var13};
//     var9.setSources(var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     double var9 = var0.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var0.axisChanged(var10);
//     org.jfree.chart.util.RectangleEdge var12 = var0.getRangeAxisEdge();
//     java.awt.Paint var13 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var0.zoomRangeAxes(100.0d, var15, var16);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var20 = var19.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomDomainAxes((-1.0d), var22, var23);
//     org.jfree.chart.axis.AxisLocation var26 = var19.getDomainAxisLocation(15);
//     var0.setRangeAxisLocation(1, var26, false);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     var0.add(1.0d, 0.0d, (java.lang.Comparable)true, (java.lang.Comparable)1L);
//     org.jfree.data.KeyToGroupMap var6 = null;
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var6);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    double var6 = var0.getUpperMargin();
    org.jfree.data.Range var7 = var0.getRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     java.awt.Shape var2 = var0.getUpArrow();
//     var0.configure();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var7 = var6.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var9 = null;
//     var6.setDomainAxisLocation(1, var9, true);
//     org.jfree.chart.event.PlotChangeListener var12 = null;
//     var6.addChangeListener(var12);
//     org.jfree.chart.plot.DatasetRenderingOrder var14 = var6.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     org.jfree.chart.LegendItemSource[] var16 = var15.getSources();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var19 = var18.getLabelFont();
//     var15.setItemFont(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var15.getLegendItemGraphicEdge();
//     double var22 = var0.java2DToValue(0.0d, var5, var21);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    java.awt.Font var4 = var0.getSeriesItemLabelFont(15);
    java.lang.Boolean var6 = var0.getSeriesItemLabelsVisible(0);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var10 = var8.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var11 = var8.getGradientPaintTransformer();
    java.awt.Stroke var12 = var8.getBaseStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-16777216), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp((-1.0d));

  }

//  public void test139() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    var4.setInverted(true);
    double var10 = var4.getUpperMargin();
    java.awt.Shape var11 = var4.getLeftArrow();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var14, var17);
    org.jfree.chart.entity.AxisLabelEntity var21 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var14, "", "HorizontalAlignment.CENTER");
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var24 = var22.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    double var27 = var26.getFixedAutoRange();
    java.awt.Shape var28 = var26.getUpArrow();
    double var29 = var26.getLowerBound();
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesStroke(0, var30, false);
    java.awt.Stroke var34 = var22.getSeriesStroke((-16777216));
    java.awt.Paint var35 = var22.getBaseFillPaint();
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var38 = var36.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    double var41 = var40.getFixedAutoRange();
    java.awt.Shape var42 = var40.getUpArrow();
    double var43 = var40.getLowerBound();
    java.awt.Stroke var44 = var40.getTickMarkStroke();
    var36.setSeriesStroke(0, var44, false);
    org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var53 = var51.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    double var56 = var55.getFixedAutoRange();
    java.awt.Shape var57 = var55.getUpArrow();
    double var58 = var55.getLowerBound();
    java.awt.Stroke var59 = var55.getTickMarkStroke();
    var51.setSeriesStroke(0, var59, false);
    java.awt.Stroke var63 = var51.getSeriesStroke((-16777216));
    org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var66 = var64.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var67 = var64.getLegendItemLabelGenerator();
    java.awt.Paint var68 = var64.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
    var69.clearDomainMarkers((-1));
    var69.setBackgroundAlpha(0.0f);
    boolean var74 = var64.hasListener((java.util.EventListener)var69);
    org.jfree.chart.labels.CategoryToolTipGenerator var77 = var64.getToolTipGenerator(10, 15);
    java.awt.Paint var79 = var64.lookupSeriesPaint(100);
    var51.setBaseOutlinePaint(var79);
    org.jfree.chart.block.BlockBorder var81 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.05d, var79);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem(var0, "", "hi!", "Range[100.0,100.0]", var14, var35, var44, var79);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
    int var7 = var6.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var0.add(1.0d, 0.0d, (java.lang.Comparable)true, (java.lang.Comparable)1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getRowKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(10.0d, (-1.0d), var3, var4);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 100.0d);
    java.lang.String var10 = var9.toString();
    var6.setDefaultAutoRange(var9);
    var6.setTickLabelsVisible(true);
    org.jfree.chart.util.RectangleInsets var14 = var6.getTickLabelInsets();
    var0.setInsets(var14, false);
    java.awt.geom.Rectangle2D var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var18 = var14.createInsetRectangle(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Range[100.0,100.0]"+ "'", var10.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects var2 = new org.jfree.data.KeyedObjects();
    java.lang.Object var4 = var2.getObject((java.lang.Comparable)(byte)1);
    boolean var5 = var0.equals((java.lang.Object)var2);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var0.generateLabel((org.jfree.data.category.CategoryDataset)var6, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var8 = var7.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var10 = null;
//     var7.setDomainAxisLocation(1, var10, true);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var7.addChangeListener(var13);
//     org.jfree.chart.plot.DatasetRenderingOrder var15 = var7.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
//     var7.clearRangeMarkers();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var19 = var18.getDataset();
//     boolean var20 = var18.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var21 = var18.getDrawingSupplier();
//     var7.setDrawingSupplier(var21);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var25 = var0.initialise(var5, var6, var7, 10, var24);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     boolean var2 = var0.isOutlineVisible();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var0.drawBackground(var3, var4);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.clearRangeMarkers();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var12 = var11.getDataset();
    boolean var13 = var11.isOutlineVisible();
    org.jfree.chart.plot.DrawingSupplier var14 = var11.getDrawingSupplier();
    var0.setDrawingSupplier(var14);
    org.jfree.chart.event.MarkerChangeEvent var16 = null;
    var0.markerChanged(var16);
    var0.mapDatasetToRangeAxis(1, (-1));
    int var21 = var0.getDatasetCount();
    var0.setDrawSharedDomainAxis(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     var0.clearRangeMarkers();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var12 = var11.getDataset();
//     boolean var13 = var11.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var14 = var11.getDrawingSupplier();
//     var0.setDrawingSupplier(var14);
//     org.jfree.chart.event.MarkerChangeEvent var16 = null;
//     var0.markerChanged(var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var0.drawOutline(var18, var19);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    java.util.List var2 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getMeanValue(10, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 'a'};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers((-1));
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var9 = var7.equals((java.lang.Object)(short)1);
    var0.setAxisOffset(var7);
    double var12 = var7.extendHeight(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 111.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 0);
    java.lang.Comparable var5 = null;
    var0.add((java.lang.Number)100.0d, (java.lang.Number)1, var5, (java.lang.Comparable)10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getColumnKey((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var7 = var5.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    double var10 = var9.getFixedAutoRange();
    java.awt.Shape var11 = var9.getUpArrow();
    double var12 = var9.getLowerBound();
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesStroke(0, var13, false);
    java.awt.Stroke var17 = var5.getSeriesStroke((-16777216));
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = var18.getLegendItemLabelGenerator();
    java.awt.Paint var22 = var18.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers((-1));
    var23.setBackgroundAlpha(0.0f);
    boolean var28 = var18.hasListener((java.util.EventListener)var23);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = var18.getToolTipGenerator(10, 15);
    java.awt.Paint var33 = var18.lookupSeriesPaint(100);
    var5.setBaseOutlinePaint(var33);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.05d, var33);
    java.awt.Paint var36 = var35.getPaint();
    java.awt.Stroke var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker((-1.0d), var36, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     var0.setUpperMargin(0.05d);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var8 = var7.getDataset();
//     java.awt.Paint var9 = null;
//     var7.setOutlinePaint(var9);
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var17 = var15.equals((java.lang.Object)(short)1);
//     java.lang.String var18 = var15.toString();
//     var7.setInsets(var15);
//     org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var26 = var24.equals((java.lang.Object)(short)1);
//     java.lang.String var27 = var24.toString();
//     var7.setInsets(var24, true);
//     org.jfree.chart.util.RectangleEdge var30 = var7.getDomainAxisEdge();
//     double var31 = var0.getCategoryStart(0, (-16777216), var6, var30);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     double var3 = var2.getFixedAutoRange();
//     java.awt.Shape var4 = var2.getUpArrow();
//     double var5 = var2.getLowerBound();
//     var2.setInverted(true);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 100.0f, 10.0f);
//     var2.setRightArrow(var14);
//     boolean var16 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var18 = var17.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var17.setDomainAxisLocation(1, var20, true);
//     org.jfree.chart.event.PlotChangeListener var23 = null;
//     var17.addChangeListener(var23);
//     org.jfree.chart.plot.DatasetRenderingOrder var25 = var17.getDatasetRenderingOrder();
//     double var26 = var17.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var27 = null;
//     var17.axisChanged(var27);
//     org.jfree.chart.util.RectangleEdge var29 = var17.getRangeAxisEdge();
//     java.awt.Paint var30 = var17.getRangeCrosshairPaint();
//     var2.setLabelPaint(var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var34 = var33.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var36 = null;
//     var33.setDomainAxisLocation(1, var36, true);
//     org.jfree.chart.event.PlotChangeListener var39 = null;
//     var33.addChangeListener(var39);
//     org.jfree.chart.plot.DatasetRenderingOrder var41 = var33.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     var33.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var44 = var33.getDomainGridlinePosition();
//     org.jfree.chart.plot.PlotOrientation var45 = var33.getOrientation();
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var48 = var47.getDataset();
//     boolean var49 = var47.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var51 = var47.getRangeAxisEdge(0);
//     org.jfree.chart.axis.AxisSpace var52 = null;
//     org.jfree.chart.axis.AxisSpace var53 = var2.reserveSpace(var32, (org.jfree.chart.plot.Plot)var33, var46, var51, var52);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.BOTTOM", "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", var3);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var13 = var12.getLabelFont();
//     var9.setItemFont(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
//     java.awt.Font var17 = null;
//     java.awt.Paint var18 = null;
//     org.jfree.chart.text.TextMeasurer var21 = null;
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var18, 1.0f, 100, var21);
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getLineAlignment();
//     java.lang.String var24 = var23.toString();
//     var9.setHorizontalAlignment(var23);
//     var9.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var35 = var9.arrange(var31, var34);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var39 = var38.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var38.setDomainAxisLocation(1, var41, true);
//     org.jfree.chart.event.PlotChangeListener var44 = null;
//     var38.addChangeListener(var44);
//     org.jfree.chart.plot.DatasetRenderingOrder var46 = var38.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     java.awt.Paint var48 = var47.getBackgroundPaint();
//     java.awt.Paint var49 = var47.getBackgroundPaint();
//     org.jfree.chart.axis.CategoryLabelPosition var50 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var51 = var50.getCategoryAnchor();
//     java.lang.String var52 = var51.toString();
//     var47.setLegendItemGraphicLocation(var51);
//     java.awt.geom.Rectangle2D var54 = org.jfree.chart.util.RectangleAnchor.createRectangle(var35, (-1.0d), 0.0d, var51);
//     
//     // Checks the contract:  equals-hashcode on var0 and var38
//     assertTrue("Contract failed: equals-hashcode on var0 and var38", var0.equals(var38) ? var0.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var0
//     assertTrue("Contract failed: equals-hashcode on var38 and var0", var38.equals(var0) ? var38.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var6 = var5.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var5.setDomainAxisLocation(1, var8, true);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var5.addChangeListener(var11);
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var5.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.LegendItemSource[] var15 = var14.getSources();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var18 = var17.getLabelFont();
//     var14.setItemFont(var18);
//     org.jfree.chart.util.RectangleEdge var20 = var14.getLegendItemGraphicEdge();
//     double var21 = var0.getCategoryStart(1, 0, var4, var20);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     double var3 = var2.getFixedAutoRange();
//     java.awt.Shape var4 = var2.getUpArrow();
//     double var5 = var2.getLowerBound();
//     var2.setInverted(true);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 100.0f, 10.0f);
//     var2.setRightArrow(var14);
//     boolean var16 = var1.equals((java.lang.Object)var2);
//     boolean var17 = var1.isNegativeArrowVisible();
//     org.jfree.chart.axis.NumberTickUnit var19 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     var1.setTickUnit(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var23 = var22.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var22.setDomainAxisLocation(1, var25, true);
//     org.jfree.chart.event.PlotChangeListener var28 = null;
//     var22.addChangeListener(var28);
//     org.jfree.chart.plot.DatasetRenderingOrder var30 = var22.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     var22.clearRangeMarkers();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var34 = var33.getDataset();
//     boolean var35 = var33.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var36 = var33.getDrawingSupplier();
//     var22.setDrawingSupplier(var36);
//     org.jfree.chart.event.MarkerChangeEvent var38 = null;
//     var22.markerChanged(var38);
//     var22.mapDatasetToRangeAxis(1, (-1));
//     int var43 = var22.getDatasetCount();
//     org.jfree.chart.axis.AxisSpace var44 = var22.getFixedDomainAxisSpace();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var47 = var46.getDataset();
//     java.awt.Paint var48 = null;
//     var46.setOutlinePaint(var48);
//     var46.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotOrientation var52 = var46.getOrientation();
//     var46.setBackgroundAlpha(1.0f);
//     org.jfree.chart.util.RectangleEdge var56 = var46.getDomainAxisEdge(0);
//     org.jfree.chart.axis.AxisSpace var57 = null;
//     org.jfree.chart.axis.AxisSpace var58 = var1.reserveSpace(var21, (org.jfree.chart.plot.Plot)var22, var45, var56, var57);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 10.0f, 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-131));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setFixedDimension(0.0d);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    double var9 = var8.getFixedAutoRange();
    java.awt.Shape var10 = var8.getUpArrow();
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, var10, "RectangleAnchor.CENTER", "");
    java.awt.Paint var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 100.0d);
    java.lang.String var19 = var18.toString();
    var15.setDefaultAutoRange(var18);
    var15.setTickLabelsVisible(true);
    org.jfree.chart.util.RectangleInsets var23 = var15.getTickLabelInsets();
    boolean var24 = var15.isTickLabelsVisible();
    java.awt.Stroke var25 = var15.getAxisLineStroke();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var28 = var26.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var29 = var26.getGradientPaintTransformer();
    var26.setAutoPopulateSeriesShape(false);
    java.awt.Paint var33 = var26.lookupSeriesOutlinePaint(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "ThreadContext", var10, var14, var25, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Range[100.0,100.0]"+ "'", var19.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.util.RectangleAnchor var11 = var9.getLegendItemGraphicAnchor();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var13 = var12.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var12.setDomainAxisLocation(1, var15, true);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var12.addChangeListener(var18);
//     org.jfree.chart.plot.DatasetRenderingOrder var20 = var12.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.LegendItemSource[] var22 = var21.getSources();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var25 = var24.getLabelFont();
//     var21.setItemFont(var25);
//     org.jfree.chart.util.RectangleEdge var27 = var21.getLegendItemGraphicEdge();
//     java.awt.Font var29 = null;
//     java.awt.Paint var30 = null;
//     org.jfree.chart.text.TextMeasurer var33 = null;
//     org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, var30, 1.0f, 100, var33);
//     org.jfree.chart.util.HorizontalAlignment var35 = var34.getLineAlignment();
//     java.lang.String var36 = var35.toString();
//     var21.setHorizontalAlignment(var35);
//     var9.setHorizontalAlignment(var35);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     var0.setMaximumCategoryLabelWidthRatio(0.0f);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.axis.AxisState var5 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var8 = var7.getDataset();
//     boolean var9 = var7.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var11 = var7.getRangeAxisEdge(0);
//     java.util.List var12 = var0.refreshTicks(var4, var5, var6, var11);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    java.awt.Stroke var4 = var0.getBaseStroke();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-131), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    double var9 = var0.getRangeCrosshairValue();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var0.axisChanged(var10);
    org.jfree.chart.util.RectangleEdge var12 = var0.getRangeAxisEdge();
    var0.setForegroundAlpha(1.0f);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var0.getRangeMarkers((-16777216), var16);
    var0.setBackgroundImageAlignment((-131));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    double var4 = var3.getFixedAutoRange();
    java.awt.Shape var5 = var3.getUpArrow();
    double var6 = var3.getLowerBound();
    var3.setInverted(true);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
    var3.setRightArrow(var15);
    boolean var17 = var2.equals((java.lang.Object)var3);
    boolean var18 = var2.isNegativeArrowVisible();
    boolean var19 = var0.equals((java.lang.Object)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = var0.get((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(111.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesStroke(0, var8, false);
    java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
    java.awt.Paint var13 = var0.getBaseFillPaint();
    boolean var14 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 100.0d);
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    double var11 = var10.getCentralValue();
    boolean var12 = var0.equals((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(111.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1, var2);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("DatasetRenderingOrder.REVERSE");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var7 = var5.toFixedWidth((-1.0d));
//     java.lang.String var8 = var7.toString();
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var2, var7);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     boolean var2 = var0.isOutlineVisible();
//     int var3 = var0.getBackgroundImageAlignment();
//     org.jfree.chart.plot.Marker var5 = null;
//     org.jfree.chart.util.Layer var6 = null;
//     var0.addRangeMarker(15, var5, var6);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 10.0d);
    java.lang.Number var3 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.util.RectangleAnchor var11 = var9.getLegendItemGraphicAnchor();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var13 = var12.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var12.setDomainAxisLocation(1, var15, true);
//     org.jfree.chart.event.PlotChangeListener var18 = null;
//     var12.addChangeListener(var18);
//     org.jfree.chart.plot.DatasetRenderingOrder var20 = var12.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
//     org.jfree.chart.LegendItemSource[] var22 = var21.getSources();
//     org.jfree.chart.block.BlockContainer var23 = null;
//     var21.setWrapper(var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var34 = var32.equals((java.lang.Object)(short)1);
//     var25.setAxisOffset(var32);
//     var21.setLegendItemGraphicPadding(var32);
//     java.awt.Paint var37 = var21.getBackgroundPaint();
//     java.awt.Font var39 = null;
//     java.awt.Paint var40 = null;
//     org.jfree.chart.text.TextMeasurer var43 = null;
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var39, var40, 1.0f, 100, var43);
//     org.jfree.chart.util.HorizontalAlignment var45 = var44.getLineAlignment();
//     java.lang.String var46 = var45.toString();
//     var21.setHorizontalAlignment(var45);
//     var9.setHorizontalAlignment(var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var13 = var12.getLabelFont();
//     var9.setItemFont(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
//     java.awt.Font var17 = null;
//     java.awt.Paint var18 = null;
//     org.jfree.chart.text.TextMeasurer var21 = null;
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var18, 1.0f, 100, var21);
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getLineAlignment();
//     java.lang.String var24 = var23.toString();
//     var9.setHorizontalAlignment(var23);
//     var9.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var35 = var9.arrange(var31, var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var37 = var36.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var36.setDomainAxisLocation(1, var39, true);
//     org.jfree.chart.event.PlotChangeListener var42 = null;
//     var36.addChangeListener(var42);
//     org.jfree.chart.plot.DatasetRenderingOrder var44 = var36.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
//     org.jfree.chart.LegendItemSource[] var46 = var45.getSources();
//     org.jfree.chart.util.RectangleAnchor var47 = var45.getLegendItemGraphicAnchor();
//     boolean var48 = var35.equals((java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    var0.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    double var3 = var2.getFixedAutoRange();
    java.awt.Shape var4 = var2.getUpArrow();
    var0.setShape(0, var4);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-16777216), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var0.axisChanged(var2);
    org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var6 = var5.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var4, var5);
    org.jfree.chart.text.TextBlockAnchor var8 = var5.getLabelAnchor();
    boolean var9 = var0.equals((java.lang.Object)var5);
    float var10 = var5.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.95f);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var9 = var8.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var11 = null;
    var8.setDomainAxisLocation(1, var11, true);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var8.addChangeListener(var14);
    org.jfree.chart.plot.DatasetRenderingOrder var16 = var8.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    java.awt.Paint var18 = var17.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var20 = null;
    org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 100.0d);
    java.lang.String var23 = var22.toString();
    var19.setDefaultAutoRange(var22);
    double var25 = var19.getUpperMargin();
    java.awt.Paint var26 = var19.getAxisLinePaint();
    var17.setBackgroundPaint(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Range[100.0,100.0]"+ "'", var23.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, (-1.0d), 111.0d);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     double var5 = var4.getFixedAutoRange();
//     java.awt.Shape var6 = var4.getUpArrow();
//     double var7 = var4.getLowerBound();
//     java.awt.Stroke var8 = var4.getTickMarkStroke();
//     var0.setSeriesStroke(0, var8, false);
//     java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
//     java.awt.Paint var13 = var0.getBaseFillPaint();
//     java.lang.Boolean var15 = var0.getSeriesCreateEntities((-1));
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     var18.setUpperMargin(0.05d);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     double var23 = var22.getFixedAutoRange();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var25 = var24.getDataset();
//     boolean var26 = var24.isOutlineVisible();
//     org.jfree.chart.event.PlotChangeListener var27 = null;
//     var24.addChangeListener(var27);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var30 = var29.getDataset();
//     java.awt.Paint var31 = null;
//     var29.setOutlinePaint(var31);
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var39 = var37.equals((java.lang.Object)(short)1);
//     java.lang.String var40 = var37.toString();
//     var29.setInsets(var37);
//     var24.setInsets(var37);
//     var22.setTickLabelInsets(var37);
//     org.jfree.chart.util.Layer var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     var0.drawAnnotations(var16, var17, var18, (org.jfree.chart.axis.ValueAxis)var22, var44, var45);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
    java.awt.Font var13 = var12.getFont();
    var0.setBaseItemLabelFont(var13);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = var0.getSeriesToolTipGenerator(100);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-131), var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 0);
    java.lang.Comparable var5 = null;
    var0.add((java.lang.Number)100.0d, (java.lang.Number)1, var5, (java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var8.zoomDomainAxes((-1.0d), var11, var12);
    org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation(15);
    boolean var16 = var0.hasListener((java.util.EventListener)var8);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, 0);
    org.jfree.data.general.DatasetGroup var20 = var17.getGroup();
    var0.setGroup(var20);
    java.lang.Object var22 = var20.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    var0.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
    org.jfree.data.general.DatasetChangeEvent var4 = null;
    var0.datasetChanged(var4);
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    double var7 = var0.getMaximumBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("Range[100.0,100.0]");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var3 = var2.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var5 = null;
//     var2.setDomainAxisLocation(1, var5, true);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var2.addChangeListener(var8);
//     org.jfree.chart.plot.DatasetRenderingOrder var10 = var2.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     var2.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var13 = var2.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var18 = var17.getDataset();
//     java.awt.Paint var19 = null;
//     var17.setOutlinePaint(var19);
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var27 = var25.equals((java.lang.Object)(short)1);
//     java.lang.String var28 = var25.toString();
//     var17.setInsets(var25);
//     org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var36 = var34.equals((java.lang.Object)(short)1);
//     java.lang.String var37 = var34.toString();
//     var17.setInsets(var34, true);
//     org.jfree.chart.util.RectangleEdge var40 = var17.getDomainAxisEdge();
//     double var41 = var1.getCategoryJava2DCoordinate(var13, 0, 15, var16, var40);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.plot.Marker var11 = null;
//     var5.addRangeMarker(var11);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    java.awt.Shape var0 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var3);
    var3.validateObject();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 100.0d);
    java.lang.String var10 = var9.toString();
    var6.setDefaultAutoRange(var9);
    double var12 = var6.getUpperMargin();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 100.0d);
    java.lang.String var16 = var15.toString();
    boolean var18 = var15.equals((java.lang.Object)(byte)100);
    boolean var20 = var15.contains(1.0d);
    var6.setRangeWithMargins(var15, false, false);
    org.jfree.chart.axis.NumberTickUnit var25 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    var6.setTickUnit(var25);
    double var27 = var25.getSize();
    java.lang.String var28 = var25.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var30 = new org.jfree.chart.entity.CategoryItemEntity(var0, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", (org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)var28, (java.lang.Comparable)"");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Range[100.0,100.0]"+ "'", var10.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Range[100.0,100.0]"+ "'", var16.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "[size=-1]"+ "'", var28.equals("[size=-1]"));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    java.awt.Paint var2 = null;
    var0.setOutlinePaint(var2);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis();
    boolean var7 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    var0.setLowerMargin(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("Range[100.0,100.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     float var4 = var1.calculateBaselineOffset(var2, var3);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var6 = var0.getItemPaint(0, 100);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var9 = var7.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var10 = var7.getGradientPaintTransformer();
    var0.setGradientPaintTransformer(var10);
    boolean var12 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.annotations.CategoryAnnotation var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var2 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var4 = var3.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var6 = null;
//     var3.setDomainAxisLocation(1, var6, true);
//     org.jfree.chart.event.PlotChangeListener var9 = null;
//     var3.addChangeListener(var9);
//     org.jfree.chart.plot.DatasetRenderingOrder var11 = var3.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     org.jfree.chart.util.RectangleEdge var13 = var3.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var14 = var2.getLabelPosition(var13);
//     org.jfree.chart.axis.CategoryLabelPosition var15 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var16 = var15.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleEdge var28 = var18.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var29 = var17.getLabelPosition(var28);
//     org.jfree.chart.axis.CategoryLabelPositions var30 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var14, var15, var29);
//     
//     // Checks the contract:  equals-hashcode on var3 and var18
//     assertTrue("Contract failed: equals-hashcode on var3 and var18", var3.equals(var18) ? var3.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var3
//     assertTrue("Contract failed: equals-hashcode on var18 and var3", var18.equals(var3) ? var18.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
    var5.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
    double var8 = var5.getContentXOffset();
    boolean var9 = var5.isEmpty();
    java.util.List var10 = var5.getBlocks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var10);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    boolean var2 = var0.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge(0);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var6 = var5.getDataset();
    var5.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
    org.jfree.data.general.DatasetChangeEvent var9 = null;
    var5.datasetChanged(var9);
    int var11 = var5.getWeight();
    java.awt.Stroke var12 = var5.getOutlineStroke();
    var0.setRangeGridlineStroke(var12);
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getDomainMarkers(var2);
//     java.awt.Stroke var4 = var0.getOutlineStroke();
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker((-16777216), var6, var7);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     double var5 = var4.getFixedAutoRange();
//     java.awt.Shape var6 = var4.getUpArrow();
//     double var7 = var4.getLowerBound();
//     java.awt.Stroke var8 = var4.getTickMarkStroke();
//     var0.setSeriesStroke(0, var8, false);
//     java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
//     java.awt.Paint var13 = var0.getBaseFillPaint();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var16 = var15.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var15.setDomainAxisLocation(1, var18, true);
//     org.jfree.chart.event.PlotChangeListener var21 = null;
//     var15.addChangeListener(var21);
//     org.jfree.chart.plot.DatasetRenderingOrder var23 = var15.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var25 = var24.getBackgroundPaint();
//     java.awt.Paint var26 = var24.getItemPaint();
//     var0.setBaseOutlinePaint(var26);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var39 = var37.equals((java.lang.Object)(short)1);
//     var30.setAxisOffset(var37);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var43 = var0.initialise(var28, var29, var30, (-131), var42);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    var0.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getStdDevValue(255, (-131));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "hi!", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "");
    java.lang.String var5 = var4.getName();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var7 = var6.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var6.setDomainAxisLocation(1, var9, true);
    org.jfree.chart.event.PlotChangeListener var12 = null;
    var6.addChangeListener(var12);
    org.jfree.chart.plot.DatasetRenderingOrder var14 = var6.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
    org.jfree.chart.LegendItemSource[] var16 = var15.getSources();
    org.jfree.chart.util.RectangleAnchor var17 = var15.getLegendItemGraphicAnchor();
    boolean var18 = var4.equals((java.lang.Object)var17);
    java.lang.String var19 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     var0.clearRangeMarkers();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var12 = var11.getDataset();
//     boolean var13 = var11.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var14 = var11.getDrawingSupplier();
//     var0.setDrawingSupplier(var14);
//     org.jfree.chart.event.MarkerChangeEvent var16 = null;
//     var0.markerChanged(var16);
//     java.awt.Paint var18 = var0.getNoDataMessagePaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var20 = var19.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomDomainAxes((-1.0d), var22, var23);
//     org.jfree.chart.axis.AxisLocation var26 = var19.getDomainAxisLocation(15);
//     org.jfree.chart.axis.AxisLocation var27 = org.jfree.chart.axis.AxisLocation.getOpposite(var26);
//     var0.setRangeAxisLocation(var27);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     java.lang.String var15 = var14.toString();
//     var11.setDefaultAutoRange(var14);
//     double var17 = var11.getUpperMargin();
//     java.awt.Paint var18 = var11.getAxisLinePaint();
//     var9.setBackgroundPaint(var18);
//     org.jfree.chart.event.TitleChangeEvent var20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var9);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var22 = var21.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var21.setDomainAxisLocation(1, var24, true);
//     org.jfree.chart.event.PlotChangeListener var27 = null;
//     var21.addChangeListener(var27);
//     org.jfree.chart.plot.DatasetRenderingOrder var29 = var21.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21);
//     var30.setWidth(100.0d);
//     boolean var33 = var9.equals((java.lang.Object)var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
// 
//   }

//  public void test216() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    double var2 = var1.getMax();
    var1.cursorDown(111.0d);
    var1.setCursor(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(100);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers((-1));
    var4.setBackgroundAlpha(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.set((-16777216), (java.lang.Object)0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes((-1.0d), var3, var4);
    java.awt.Paint var6 = var0.getNoDataMessagePaint();
    java.awt.Image var7 = null;
    var0.setBackgroundImage(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     java.awt.Paint var2 = null;
//     var0.setOutlinePaint(var2);
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var10 = var8.equals((java.lang.Object)(short)1);
//     java.lang.String var11 = var8.toString();
//     var0.setInsets(var8);
//     org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var19 = var17.equals((java.lang.Object)(short)1);
//     java.lang.String var20 = var17.toString();
//     var0.setInsets(var17, true);
//     org.jfree.chart.util.RectangleEdge var23 = var0.getDomainAxisEdge();
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var0.drawBackground(var24, var25);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesStroke(0, var8, false);
    java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
    java.awt.Paint var13 = var0.getBaseFillPaint();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var16 = var15.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var15.setDomainAxisLocation(1, var18, true);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var15.addChangeListener(var21);
    org.jfree.chart.plot.DatasetRenderingOrder var23 = var15.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    java.awt.Paint var25 = var24.getBackgroundPaint();
    java.awt.Paint var26 = var24.getItemPaint();
    var0.setBaseOutlinePaint(var26);
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(0.0d, 0.05d, 10.0d, (-1.0d));
    java.awt.Paint var34 = var33.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.setAutoRange(false);
//     var0.setAxisLineVisible(true);
//     var0.setAxisLineVisible(true);
//     java.lang.String var7 = var0.getLabelURL();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var14 = var12.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     double var17 = var16.getFixedAutoRange();
//     java.awt.Shape var18 = var16.getUpArrow();
//     double var19 = var16.getLowerBound();
//     java.awt.Stroke var20 = var16.getTickMarkStroke();
//     var12.setSeriesStroke(0, var20, false);
//     java.awt.Stroke var24 = var12.getSeriesStroke((-16777216));
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var27 = var25.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var25.getLegendItemLabelGenerator();
//     java.awt.Paint var29 = var25.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearDomainMarkers((-1));
//     var30.setBackgroundAlpha(0.0f);
//     boolean var35 = var25.hasListener((java.util.EventListener)var30);
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var25.getToolTipGenerator(10, 15);
//     java.awt.Paint var40 = var25.lookupSeriesPaint(100);
//     var12.setBaseOutlinePaint(var40);
//     org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.05d, var40);
//     java.awt.Paint var43 = var42.getPaint();
//     var0.setAxisLinePaint(var43);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var47 = var45.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var48 = var45.getGradientPaintTransformer();
//     java.awt.Stroke var49 = var45.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     double var52 = var51.getFixedAutoRange();
//     java.awt.Shape var53 = var51.getUpArrow();
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var56, 100.0d, 100.0f, 10.0f);
//     boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var53, var56);
//     var45.setSeriesShape(15, var56);
//     var0.setRightArrow(var56);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var45.", var25.equals(var45) == var45.equals(var25));
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setNoDataMessage("");
//     var0.setForegroundAlpha(100.0f);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker(15, var6, var7);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 100.0f, 10.0f);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var0, var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var13 = var12.getLabelFont();
    var9.setItemFont(var13);
    org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
    java.awt.Font var17 = null;
    java.awt.Paint var18 = null;
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var18, 1.0f, 100, var21);
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getLineAlignment();
    java.lang.String var24 = var23.toString();
    var9.setHorizontalAlignment(var23);
    var9.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    org.jfree.chart.util.Size2D var35 = var9.arrange(var31, var34);
    org.jfree.data.Range var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var37 = var34.toRangeWidth(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var24.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
    java.lang.String var15 = var14.toString();
    var11.setDefaultAutoRange(var14);
    double var17 = var11.getUpperMargin();
    java.awt.Paint var18 = var11.getAxisLinePaint();
    var9.setBackgroundPaint(var18);
    org.jfree.chart.event.TitleChangeEvent var20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var9);
    org.jfree.chart.title.Title var21 = var20.getTitle();
    java.awt.geom.Rectangle2D var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setBounds(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Range[100.0,100.0]"+ "'", var15.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.Paint var11 = var9.getBackgroundPaint();
    org.jfree.chart.axis.CategoryLabelPosition var12 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var13 = var12.getCategoryAnchor();
    java.lang.String var14 = var13.toString();
    var9.setLegendItemGraphicLocation(var13);
    org.jfree.chart.axis.CategoryLabelPositions var16 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var17 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var18 = var17.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var16, var17);
    org.jfree.chart.text.TextBlockAnchor var20 = var17.getLabelAnchor();
    java.lang.String var21 = var20.toString();
    org.jfree.chart.axis.CategoryLabelWidthType var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition(var13, var20, var22, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleAnchor.CENTER"+ "'", var14.equals("RectangleAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER"+ "'", var21.equals("TextBlockAnchor.BOTTOM_CENTER"));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    boolean var3 = var0.containsKey("Range[100.0,100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     var4.draw(var5, var6, var7, var8);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.05d, (-1.0d));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var17 = var15.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var18 = var15.getLegendItemLabelGenerator();
    java.awt.Paint var19 = var15.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.clearDomainMarkers((-1));
    var20.setBackgroundAlpha(0.0f);
    boolean var25 = var15.hasListener((java.util.EventListener)var20);
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = var15.getToolTipGenerator(10, 15);
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = var15.getBaseToolTipGenerator();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.setRangeCrosshairVisible(true);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var34 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var36 = null;
    var33.setDomainAxisLocation(1, var36, true);
    org.jfree.chart.event.PlotChangeListener var39 = null;
    var33.addChangeListener(var39);
    org.jfree.chart.plot.DatasetRenderingOrder var41 = var33.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    var33.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAnchor var44 = var33.getDomainGridlinePosition();
    var30.setDomainGridlinePosition(var44);
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var47 = var46.getDataset();
    boolean var48 = var46.isOutlineVisible();
    int var49 = var46.getBackgroundImageAlignment();
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
    double var51 = var50.getFixedAutoRange();
    java.awt.Shape var52 = var50.getUpArrow();
    double var53 = var50.getLowerBound();
    java.awt.Stroke var54 = var50.getTickMarkStroke();
    var46.setRangeCrosshairStroke(var54);
    var30.setOutlineStroke(var54);
    var15.setBaseOutlineStroke(var54, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-16777216), var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     double var2 = var1.getFixedAutoRange();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     var1.setAutoRange(false);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.Plot var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.axis.AxisState var14 = new org.jfree.chart.axis.AxisState();
//     boolean var15 = var9.equals((java.lang.Object)var14);
//     org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleEdge var28 = var18.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var29 = var17.getLabelPosition(var28);
//     var14.moveCursor(0.05d, var28);
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     org.jfree.chart.axis.AxisSpace var32 = var1.reserveSpace(var6, var7, var8, var28, var31);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    double var6 = var0.getUpperMargin();
    org.jfree.data.Range var7 = var0.getRange();
    var0.setLabelToolTip("HorizontalAlignment.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 100.0f, 10.0f);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var5, var12);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var18 = var15.getItemOutlinePaint(0, 0);
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var22 = var20.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = var20.getLegendItemLabelGenerator();
    java.awt.Paint var24 = var20.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.clearDomainMarkers((-1));
    var25.setBackgroundAlpha(0.0f);
    boolean var30 = var20.hasListener((java.util.EventListener)var25);
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = var20.getToolTipGenerator(10, 15);
    java.awt.Paint var35 = var20.lookupSeriesPaint(100);
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var38 = var36.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    double var41 = var40.getFixedAutoRange();
    java.awt.Shape var42 = var40.getUpArrow();
    double var43 = var40.getLowerBound();
    java.awt.Stroke var44 = var40.getTickMarkStroke();
    var36.setSeriesStroke(0, var44, false);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, 100.0d, 100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var57 = var55.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis();
    double var60 = var59.getFixedAutoRange();
    java.awt.Shape var61 = var59.getUpArrow();
    double var62 = var59.getLowerBound();
    java.awt.Stroke var63 = var59.getTickMarkStroke();
    var55.setSeriesStroke(0, var63, false);
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var71 = var70.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var73 = null;
    var70.setDomainAxisLocation(1, var73, true);
    org.jfree.chart.event.PlotChangeListener var76 = null;
    var70.addChangeListener(var76);
    org.jfree.chart.plot.DatasetRenderingOrder var78 = var70.getDatasetRenderingOrder();
    double var79 = var70.getRangeCrosshairValue();
    org.jfree.chart.event.AxisChangeEvent var80 = null;
    var70.axisChanged(var80);
    org.jfree.chart.util.RectangleEdge var82 = var70.getRangeAxisEdge();
    java.awt.Paint var83 = var70.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var84 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 100.0d, (-1.0d), var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem(var0, "RectangleAnchor.CENTER", "RectangleEdge.BOTTOM", "hi!", true, var12, true, var18, false, var35, var44, false, var50, var63, var83);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    double var3 = var2.getFixedAutoRange();
    java.awt.Shape var4 = var2.getUpArrow();
    double var5 = var2.getLowerBound();
    var2.setInverted(true);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 100.0f, 10.0f);
    var2.setRightArrow(var14);
    boolean var16 = var1.equals((java.lang.Object)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeWithMargins(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var9 = var8.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var11 = null;
    var8.setDomainAxisLocation(1, var11, true);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var8.addChangeListener(var14);
    org.jfree.chart.plot.DatasetRenderingOrder var16 = var8.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    org.jfree.chart.LegendItemSource[] var18 = var17.getSources();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var21 = var20.getLabelFont();
    var17.setItemFont(var21);
    org.jfree.chart.util.RectangleEdge var23 = var17.getLegendItemGraphicEdge();
    java.awt.Font var25 = null;
    java.awt.Paint var26 = null;
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, var26, 1.0f, 100, var29);
    org.jfree.chart.util.HorizontalAlignment var31 = var30.getLineAlignment();
    java.lang.String var32 = var31.toString();
    var17.setHorizontalAlignment(var31);
    var17.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    org.jfree.chart.util.Size2D var43 = var17.arrange(var39, var42);
    var43.setHeight(1.0d);
    org.jfree.chart.util.Size2D var46 = var6.calculateConstrainedSize(var43);
    java.lang.String var47 = var46.toString();
    var46.setWidth(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var32.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Size2D[width=0.0, height=100.0]"+ "'", var47.equals("Size2D[width=0.0, height=100.0]"));

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var2 = var1.getFont();
//     java.lang.Object var3 = var1.clone();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var6 = var5.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var5.setDomainAxisLocation(1, var8, true);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var5.addChangeListener(var11);
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var5.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.LegendItemSource[] var15 = var14.getSources();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var18 = var17.getLabelFont();
//     var14.setItemFont(var18);
//     org.jfree.chart.util.RectangleEdge var20 = var14.getLegendItemGraphicEdge();
//     java.awt.Font var22 = null;
//     java.awt.Paint var23 = null;
//     org.jfree.chart.text.TextMeasurer var26 = null;
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var23, 1.0f, 100, var26);
//     org.jfree.chart.util.HorizontalAlignment var28 = var27.getLineAlignment();
//     java.lang.String var29 = var28.toString();
//     var14.setHorizontalAlignment(var28);
//     var14.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var40 = var14.arrange(var36, var39);
//     org.jfree.chart.util.Size2D var41 = var1.arrange(var4, var39);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.KeyToGroupMap var2 = null;
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var2);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var5 = var4.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var4.setDomainAxisLocation(1, var7, true);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var4.addChangeListener(var10);
    org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.LegendItemSource[] var14 = var13.getSources();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var17 = var16.getLabelFont();
    var13.setItemFont(var17);
    org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var17);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", var17);
    double var21 = var20.getContentYOffset();
    java.lang.String var22 = var20.getToolTipText();
    boolean var23 = var0.equals((java.lang.Object)var20);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var24);
    boolean var26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var24);
    org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var29 = var0.generateLabel((org.jfree.data.category.CategoryDataset)var24, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var5.markerChanged(var11);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
    var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var20 = var17.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.clearRangeMarkers();
    org.jfree.data.general.DatasetGroup var11 = var0.getDatasetGroup();
    org.jfree.chart.axis.CategoryAxis var12 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var6 = var5.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var5.setDomainAxisLocation(1, var8, true);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var5.addChangeListener(var11);
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var5.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.LegendItemSource[] var15 = var14.getSources();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var18 = var17.getLabelFont();
//     var14.setItemFont(var18);
//     org.jfree.chart.util.RectangleInsets var20 = var14.getLegendItemGraphicPadding();
//     var4.setPadding(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    var0.setVisible(true);
    var0.setFixedAutoRange(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var22 = var20.equals((java.lang.Object)(short)1);
//     var13.setAxisOffset(var20);
//     var9.setLegendItemGraphicPadding(var20);
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets();
//     double var27 = var25.calculateLeftOutset((-1.0d));
//     double var29 = var25.calculateTopInset(111.0d);
//     var9.setItemLabelPadding(var25);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var36 = var35.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var39 = var38.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var41 = null;
//     var38.setDomainAxisLocation(1, var41, true);
//     org.jfree.chart.event.PlotChangeListener var44 = null;
//     var38.addChangeListener(var44);
//     org.jfree.chart.plot.DatasetRenderingOrder var46 = var38.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     org.jfree.chart.LegendItemSource[] var48 = var47.getSources();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var51 = var50.getLabelFont();
//     var47.setItemFont(var51);
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var51);
//     var35.setTickLabelFont(var51);
//     var33.setTickLabelFont(var51);
//     java.lang.Object var56 = var9.draw(var31, var32, (java.lang.Object)var51);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    double var6 = var0.getUpperMargin();
    org.jfree.data.Range var7 = var0.getRange();
    double var8 = var7.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
    java.awt.Font var2 = var1.getFont();
    java.lang.Object var3 = var1.clone();
    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var6 = var4.getOptionalLibraries();
    boolean var7 = var1.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-1.0d), (java.lang.Object)var4);
//     java.lang.Object var7 = null;
//     var6.setObject(var7);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var10 = var9.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var12 = null;
//     var9.setDomainAxisLocation(1, var12, true);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var9.addChangeListener(var15);
//     org.jfree.chart.plot.DatasetRenderingOrder var17 = var9.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.LegendItemSource[] var19 = var18.getSources();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var22 = var21.getLabelFont();
//     var18.setItemFont(var22);
//     org.jfree.chart.util.RectangleEdge var24 = var18.getLegendItemGraphicEdge();
//     java.awt.Font var26 = null;
//     java.awt.Paint var27 = null;
//     org.jfree.chart.text.TextMeasurer var30 = null;
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var27, 1.0f, 100, var30);
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getLineAlignment();
//     java.lang.String var33 = var32.toString();
//     var18.setHorizontalAlignment(var32);
//     var18.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var44 = var18.arrange(var40, var43);
//     boolean var45 = var6.equals((java.lang.Object)var18);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     double var49 = var48.getFixedAutoRange();
//     java.awt.Shape var50 = var48.getUpArrow();
//     double var51 = var48.getLowerBound();
//     var48.setInverted(true);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var56, 100.0d, 100.0f, 10.0f);
//     var48.setRightArrow(var60);
//     boolean var62 = var47.equals((java.lang.Object)var48);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var64 = var63.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var66 = null;
//     var63.setDomainAxisLocation(1, var66, true);
//     org.jfree.chart.event.PlotChangeListener var69 = null;
//     var63.addChangeListener(var69);
//     org.jfree.chart.plot.DatasetRenderingOrder var71 = var63.getDatasetRenderingOrder();
//     double var72 = var63.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var73 = null;
//     var63.axisChanged(var73);
//     org.jfree.chart.util.RectangleEdge var75 = var63.getRangeAxisEdge();
//     java.awt.Paint var76 = var63.getRangeCrosshairPaint();
//     var48.setLabelPaint(var76);
//     var6.setObject((java.lang.Object)var48);
//     
//     // Checks the contract:  equals-hashcode on var9 and var63
//     assertTrue("Contract failed: equals-hashcode on var9 and var63", var9.equals(var63) ? var9.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var9
//     assertTrue("Contract failed: equals-hashcode on var63 and var9", var63.equals(var9) ? var63.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator(10);
//     boolean var3 = var0.getAutoPopulateSeriesPaint();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     double var7 = var6.getUpperMargin();
//     var6.setUpperMargin(0.05d);
//     int var10 = var6.getMaximumCategoryLabelLines();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     double var12 = var11.getFixedAutoRange();
//     java.awt.Shape var13 = var11.getUpArrow();
//     double var14 = var11.getLowerBound();
//     var11.setInverted(true);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 100.0f, 10.0f);
//     var11.setRightArrow(var23);
//     org.jfree.data.Range var25 = null;
//     org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 100.0d);
//     java.lang.String var28 = var27.toString();
//     var11.setRangeWithMargins(var27);
//     org.jfree.data.Range var30 = null;
//     org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 100.0d);
//     java.lang.String var33 = var32.toString();
//     boolean var35 = var32.equals((java.lang.Object)(byte)100);
//     double var37 = var32.constrain(10.0d);
//     var11.setRange(var32, false, false);
//     org.jfree.chart.util.Layer var41 = null;
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     var0.drawAnnotations(var4, var5, var6, (org.jfree.chart.axis.ValueAxis)var11, var41, var43);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     var0.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     org.jfree.data.general.DatasetChangeEvent var4 = null;
//     var0.datasetChanged(var4);
//     int var6 = var0.getWeight();
//     java.awt.Stroke var7 = var0.getOutlineStroke();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackground(var8, var9);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("DatasetRenderingOrder.REVERSE");

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var13 = var12.getLabelFont();
    var9.setItemFont(var13);
    org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
    java.awt.Font var17 = null;
    java.awt.Paint var18 = null;
    org.jfree.chart.text.TextMeasurer var21 = null;
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var18, 1.0f, 100, var21);
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getLineAlignment();
    java.lang.String var24 = var23.toString();
    var9.setHorizontalAlignment(var23);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var27 = var26.getDataset();
    boolean var28 = var26.isOutlineVisible();
    org.jfree.chart.plot.DrawingSupplier var29 = var26.getDrawingSupplier();
    var26.setRangeCrosshairLockedOnData(false);
    var26.setRangeCrosshairValue((-1.0d), true);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var26.getRangeMarkers(15, var36);
    boolean var38 = var23.equals((java.lang.Object)var26);
    java.util.List var39 = var26.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var24.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.util.RectangleEdge var10 = var0.getDomainAxisEdge();
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var13 = var11.getSeriesVisible(15);
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11, false);
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var19 = var18.getDataset();
//     var18.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     org.jfree.chart.util.Layer var22 = null;
//     java.util.Collection var23 = var18.getRangeMarkers(var22);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var27 = var11.initialise(var16, var17, var18, 255, var26);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var5.markerChanged(var11);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
    var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addDomainMarker(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var4 = var3.getDataset();
    java.awt.Paint var5 = null;
    var3.setOutlinePaint(var5);
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var13 = var11.equals((java.lang.Object)(short)1);
    java.lang.String var14 = var11.toString();
    var3.setInsets(var11);
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var22 = var20.equals((java.lang.Object)(short)1);
    java.lang.String var23 = var20.toString();
    var3.setInsets(var20, true);
    org.jfree.chart.util.RectangleEdge var26 = var3.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var27 = var2.getLabelPosition(var26);
    org.jfree.chart.text.TextAnchor var28 = var27.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var30 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var32 = var31.getDataset();
    java.awt.Paint var33 = null;
    var31.setOutlinePaint(var33);
    org.jfree.chart.util.RectangleInsets var39 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var41 = var39.equals((java.lang.Object)(short)1);
    java.lang.String var42 = var39.toString();
    var31.setInsets(var39);
    org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var50 = var48.equals((java.lang.Object)(short)1);
    java.lang.String var51 = var48.toString();
    var31.setInsets(var48, true);
    org.jfree.chart.util.RectangleEdge var54 = var31.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var55 = var30.getLabelPosition(var54);
    org.jfree.chart.text.TextAnchor var56 = var55.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var58 = new org.jfree.chart.labels.ItemLabelPosition(var0, var28, var56, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var14.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var23.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var42.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var51.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     org.jfree.chart.event.PlotChangeListener var2 = null;
//     var0.removeChangeListener(var2);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var5 = var4.getDataset();
//     boolean var6 = var4.isOutlineVisible();
//     java.awt.Paint var7 = var4.getRangeGridlinePaint();
//     var0.setRangeGridlinePaint(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     double var3 = var2.getFixedAutoRange();
//     java.awt.Shape var4 = var2.getUpArrow();
//     double var5 = var2.getLowerBound();
//     var2.setInverted(true);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 100.0f, 10.0f);
//     var2.setRightArrow(var14);
//     boolean var16 = var1.equals((java.lang.Object)var2);
//     boolean var17 = var1.isNegativeArrowVisible();
//     org.jfree.chart.axis.NumberTickUnit var19 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     var1.setTickUnit(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var23 = var22.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var22.setDomainAxisLocation(1, var25, true);
//     org.jfree.chart.event.PlotChangeListener var28 = null;
//     var22.addChangeListener(var28);
//     org.jfree.chart.plot.DatasetRenderingOrder var30 = var22.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     var22.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var33 = var22.getDomainGridlinePosition();
//     org.jfree.chart.plot.PlotOrientation var34 = var22.getOrientation();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     int var36 = var22.getDomainAxisIndex(var35);
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var38 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var40 = var39.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var42 = null;
//     var39.setDomainAxisLocation(1, var42, true);
//     org.jfree.chart.event.PlotChangeListener var45 = null;
//     var39.addChangeListener(var45);
//     org.jfree.chart.plot.DatasetRenderingOrder var47 = var39.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.util.RectangleEdge var49 = var39.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var50 = var38.getLabelPosition(var49);
//     java.lang.String var51 = var49.toString();
//     org.jfree.chart.axis.AxisSpace var52 = null;
//     org.jfree.chart.axis.AxisSpace var53 = var1.reserveSpace(var21, (org.jfree.chart.plot.Plot)var22, var37, var49, var52);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes((-1.0d), var3, var4);
//     org.jfree.chart.plot.Marker var6 = null;
//     var0.addRangeMarker(var6);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
//     var4.setNotify(true);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var9 = var8.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var11 = null;
//     var8.setDomainAxisLocation(1, var11, true);
//     org.jfree.chart.event.PlotChangeListener var14 = null;
//     var8.addChangeListener(var14);
//     org.jfree.chart.plot.DatasetRenderingOrder var16 = var8.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     var8.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var19 = var8.getDomainGridlinePosition();
//     org.jfree.chart.plot.PlotOrientation var20 = var8.getOrientation();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     int var22 = var8.getDomainAxisIndex(var21);
//     java.awt.Font var23 = var8.getNoDataMessageFont();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     double var25 = var24.getFixedAutoRange();
//     java.awt.Shape var26 = var24.getUpArrow();
//     double var27 = var24.getLowerBound();
//     var24.setInverted(true);
//     double var30 = var24.getUpperMargin();
//     java.awt.Shape var31 = var24.getLeftArrow();
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 100.0d);
//     java.lang.String var35 = var34.toString();
//     var24.setRange(var34);
//     java.awt.Paint var37 = var24.getLabelPaint();
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", var23, var37);
//     var4.setBackgroundPaint(var37);
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var42 = var40.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var43 = var40.getLegendItemLabelGenerator();
//     java.awt.Paint var44 = var40.getBaseOutlinePaint();
//     java.awt.Paint var45 = var40.getBaseOutlinePaint();
//     java.awt.Font var47 = var40.getSeriesItemLabelFont(0);
//     org.jfree.chart.labels.CategoryToolTipGenerator var48 = null;
//     var40.setBaseToolTipGenerator(var48, true);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     double var54 = var53.getFixedAutoRange();
//     java.awt.Shape var55 = var53.getUpArrow();
//     double var56 = var53.getLowerBound();
//     var53.setInverted(true);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.rotateShape(var61, 100.0d, 100.0f, 10.0f);
//     var53.setRightArrow(var65);
//     boolean var67 = var52.equals((java.lang.Object)var53);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var69 = var68.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var71 = null;
//     var68.setDomainAxisLocation(1, var71, true);
//     org.jfree.chart.event.PlotChangeListener var74 = null;
//     var68.addChangeListener(var74);
//     org.jfree.chart.plot.DatasetRenderingOrder var76 = var68.getDatasetRenderingOrder();
//     double var77 = var68.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var78 = null;
//     var68.axisChanged(var78);
//     org.jfree.chart.util.RectangleEdge var80 = var68.getRangeAxisEdge();
//     java.awt.Paint var81 = var68.getRangeCrosshairPaint();
//     var53.setLabelPaint(var81);
//     var40.setBaseFillPaint(var81, true);
//     var4.setBackgroundPaint(var81);
//     
//     // Checks the contract:  equals-hashcode on var1 and var68
//     assertTrue("Contract failed: equals-hashcode on var1 and var68", var1.equals(var68) ? var1.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var1
//     assertTrue("Contract failed: equals-hashcode on var68 and var1", var68.equals(var1) ? var68.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers((-1));
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    double var6 = var5.getFixedAutoRange();
    java.awt.Shape var7 = var5.getUpArrow();
    double var8 = var5.getLowerBound();
    var5.setInverted(true);
    double var11 = var5.getUpperMargin();
    java.awt.Shape var12 = var5.getLeftArrow();
    org.jfree.chart.util.RectangleInsets var13 = var5.getLabelInsets();
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setRangeAxes(var14);
    float var16 = var0.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.5f);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     var0.setUpperMargin(0.05d);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var8 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var10 = var9.getDataset();
//     java.awt.Paint var11 = null;
//     var9.setOutlinePaint(var11);
//     org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var19 = var17.equals((java.lang.Object)(short)1);
//     java.lang.String var20 = var17.toString();
//     var9.setInsets(var17);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var28 = var26.equals((java.lang.Object)(short)1);
//     java.lang.String var29 = var26.toString();
//     var9.setInsets(var26, true);
//     org.jfree.chart.util.RectangleEdge var32 = var9.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var33 = var8.getLabelPosition(var32);
//     double var34 = var0.getCategoryEnd(255, 0, var6, var32);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var0.axisChanged(var2);
    org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var6 = var5.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var4, var5);
    org.jfree.chart.text.TextBlockAnchor var8 = var5.getLabelAnchor();
    boolean var9 = var0.equals((java.lang.Object)var5);
    java.awt.Paint var10 = var0.getOutlinePaint();
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    var0.setInverted(true);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 100.0f, 10.0f);
    var0.setRightArrow(var12);
    boolean var14 = var0.getAutoRangeIncludesZero();
    org.jfree.chart.axis.TickUnitSource var15 = null;
    var0.setStandardTickUnits(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
//     var4.setNotify(true);
//     java.util.List var7 = var4.getSubtitles();
//     java.awt.RenderingHints var8 = null;
//     var4.setRenderingHints(var8);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
    var0.setInverted(false);
    var0.setAutoRange(false);
    var0.setTickMarkOutsideLength(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     double var5 = var4.getUpperMargin();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     double var9 = var6.getLowerBound();
//     var6.setInverted(true);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 100.0f, 10.0f);
//     var6.setRightArrow(var18);
//     var6.setVerticalTickLabels(true);
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator(10);
//     org.jfree.chart.labels.ItemLabelPosition var25 = new org.jfree.chart.labels.ItemLabelPosition();
//     var22.setPositiveItemLabelPositionFallback(var25);
//     var22.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var35 = var33.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var36 = var33.getLegendItemLabelGenerator();
//     java.awt.Paint var37 = var33.getBaseOutlinePaint();
//     org.jfree.chart.axis.AxisState var38 = new org.jfree.chart.axis.AxisState();
//     boolean var39 = var33.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.CategoryLabelPositions var41 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var43 = var42.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var42.setDomainAxisLocation(1, var45, true);
//     org.jfree.chart.event.PlotChangeListener var48 = null;
//     var42.addChangeListener(var48);
//     org.jfree.chart.plot.DatasetRenderingOrder var50 = var42.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42);
//     org.jfree.chart.util.RectangleEdge var52 = var42.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var53 = var41.getLabelPosition(var52);
//     var38.moveCursor(0.05d, var52);
//     double var55 = var4.getCategoryMiddle((-1), 10, var32, var52);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var13 = var12.getFont();
//     var0.setBaseItemLabelFont(var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.plot.CategoryMarker var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var0.drawDomainMarker(var15, var16, var17, var18, var19);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    double var5 = var4.getUpperMargin();
    var0.setDomainAxis(10, var4);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var0.axisChanged(var7);
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxis(0);
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesStroke(0, var8, false);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    var12.draw(var13, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var17 = var16.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var16.setDomainAxisLocation(1, var19, true);
    org.jfree.chart.event.PlotChangeListener var22 = null;
    var16.addChangeListener(var22);
    org.jfree.chart.plot.DatasetRenderingOrder var24 = var16.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    java.awt.Paint var26 = var25.getBackgroundPaint();
    var25.setWidth(10.0d);
    java.awt.Font var29 = var25.getItemFont();
    var12.setFont(var29);
    java.awt.Paint var31 = var12.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    boolean var2 = var0.isOutlineVisible();
    org.jfree.chart.event.PlotChangeListener var3 = null;
    var0.addChangeListener(var3);
    var0.setBackgroundAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     int var4 = var3.getGreen();
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
//     java.awt.color.ColorSpace var6 = null;
//     float[] var10 = new float[] { 1.0f, 0.0f, 0.0f};
//     float[] var11 = var3.getColorComponents(var6, var10);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var2 = var1.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4, true);
//     org.jfree.chart.event.PlotChangeListener var7 = null;
//     var1.addChangeListener(var7);
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Paint var12 = var10.getBackgroundPaint();
//     org.jfree.chart.axis.CategoryLabelPosition var13 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var14 = var13.getCategoryAnchor();
//     java.lang.String var15 = var14.toString();
//     var10.setLegendItemGraphicLocation(var14);
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var14);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleEdge.BOTTOM", var1);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes((-1.0d), var3, var4);
//     org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation(15);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
//     org.jfree.chart.axis.AxisLocation var9 = var7.getOpposite();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setRangeCrosshairVisible(true);
//     java.awt.Paint var13 = null;
//     var10.setOutlinePaint(var13);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var10.addChangeListener(var15);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var19 = var18.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Point2D var22 = null;
//     var18.zoomDomainAxes((-1.0d), var21, var22);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getDomainAxisLocation(15);
//     var10.setRangeAxisLocation(1, var25, false);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var29 = var28.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var28.setDomainAxisLocation(1, var31, true);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var28.addChangeListener(var34);
//     org.jfree.chart.plot.DatasetRenderingOrder var36 = var28.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     var28.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var39 = var28.getDomainGridlinePosition();
//     org.jfree.chart.plot.PlotOrientation var40 = var28.getOrientation();
//     org.jfree.chart.util.RectangleEdge var41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var25, var40);
//     org.jfree.chart.util.RectangleEdge var42 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var9, var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     java.awt.Shape var2 = var0.getUpArrow();
//     org.jfree.chart.JFreeChart var3 = null;
//     org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
//     var0.setInverted(false);
//     var0.setAutoRange(false);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var16 = var15.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var15.setDomainAxisLocation(1, var18, true);
//     org.jfree.chart.event.PlotChangeListener var21 = null;
//     var15.addChangeListener(var21);
//     org.jfree.chart.plot.DatasetRenderingOrder var23 = var15.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.util.RectangleEdge var25 = var15.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     org.jfree.chart.axis.AxisState var28 = var0.draw(var11, 0.0d, var13, var14, var25, var27);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", var1);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
    java.lang.String var5 = var4.toString();
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-1.0d), (java.lang.Object)var4);
    java.lang.Object var7 = null;
    var6.setObject(var7);
    java.lang.Comparable var9 = var6.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Range[100.0,100.0]"+ "'", var5.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, 0);
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var2, var3, 10.0d, (-131));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var5.markerChanged(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
//     var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
//     boolean var19 = var17.isBorderVisible();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearDomainMarkers((-1));
//     var20.setBackgroundAlpha(0.0f);
//     org.jfree.chart.event.PlotChangeEvent var25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.event.ChartChangeEventType var26 = null;
//     var25.setType(var26);
//     var17.plotChanged(var25);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var9 = var4.createBufferedImage(1, 100, 0, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    var0.setAutoPopulateSeriesShape(false);
    java.awt.Paint var7 = var0.lookupSeriesOutlinePaint(100);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var0.setBaseItemLabelGenerator(var8, true);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var14 = var12.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var15 = var12.getGradientPaintTransformer();
    var12.setAutoPopulateSeriesShape(false);
    java.awt.Paint var19 = var12.lookupSeriesOutlinePaint(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
    java.awt.Shape var7 = var0.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 2.0f);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    java.awt.geom.Point2D var4 = null;
    var0.zoomDomainAxes(10.0d, (-1.0d), var3, var4);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 100.0d);
    java.lang.String var10 = var9.toString();
    var6.setDefaultAutoRange(var9);
    var6.setTickLabelsVisible(true);
    org.jfree.chart.util.RectangleInsets var14 = var6.getTickLabelInsets();
    var0.setInsets(var14, false);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Range[100.0,100.0]"+ "'", var10.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("", var3);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var4.calculateDimensions(var7);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.util.Size2D var6 = var1.arrange(var2, var5);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.Paint var11 = var9.getBackgroundPaint();
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setItemFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesStroke(0, var8, false);
    java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
    java.awt.Paint var13 = var0.getBaseFillPaint();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.clearDomainMarkers((-1));
    var15.setBackgroundAlpha(0.0f);
    org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    java.lang.String var21 = var20.toString();
    org.jfree.chart.plot.Plot var22 = var20.getPlot();
    boolean var23 = var0.hasListener((java.util.EventListener)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var6 = var4.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var7 = var4.getGradientPaintTransformer();
    java.awt.Stroke var8 = var4.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    double var11 = var10.getFixedAutoRange();
    java.awt.Shape var12 = var10.getUpArrow();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 100.0d, 100.0f, 10.0f);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var12, var15);
    var4.setSeriesShape(15, var15);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var23 = var22.getDataset();
    boolean var24 = var22.isOutlineVisible();
    java.awt.Paint var25 = var22.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem(var0, "HorizontalAlignment.CENTER", "DatasetRenderingOrder.REVERSE", "NOID", var15, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var5.markerChanged(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
//     var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
//     boolean var19 = var17.isBorderVisible();
//     org.jfree.chart.plot.CategoryPlot var20 = var17.getCategoryPlot();
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     var17.handleClick(10, 255, var23);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var6 = new float[] { 1.0f};
//     float[] var7 = var3.getColorComponents(var4, var6);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var3 = var2.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var5 = null;
    var2.setDomainAxisLocation(1, var5, true);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var2.addChangeListener(var8);
    org.jfree.chart.plot.DatasetRenderingOrder var10 = var2.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
    org.jfree.chart.LegendItemSource[] var12 = var11.getSources();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var15 = var14.getLabelFont();
    var11.setItemFont(var15);
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var15);
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", var15);
    double var19 = var18.getContentYOffset();
    java.lang.Object var20 = var18.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("", var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.labels.ItemLabelPosition var8 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var9 = var8.getAngle();
//     org.jfree.chart.text.TextAnchor var10 = var8.getRotationAnchor();
//     var4.draw(var5, 1.0f, 1.0f, var10, 10.0f, 10.0f, 100.0d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var3 = var1.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getGradientPaintTransformer();
    var1.setAutoPopulateSeriesShape(false);
    java.awt.Paint var8 = var1.lookupSeriesOutlinePaint(100);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
    java.awt.Paint var13 = var9.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers((-1));
    var14.setBackgroundAlpha(0.0f);
    boolean var19 = var9.hasListener((java.util.EventListener)var14);
    org.jfree.chart.event.MarkerChangeEvent var20 = null;
    var14.markerChanged(var20);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var23);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    boolean var28 = var26.isBorderVisible();
    java.awt.Stroke var29 = var26.getBorderStroke();
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var8, var29);
    org.jfree.chart.util.LengthAdjustmentType var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setLabelOffsetType(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     boolean var2 = var0.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var5 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var4.setDomainAxisLocation(1, var7, true);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var4.addChangeListener(var10);
//     org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     var4.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var15 = var4.getDomainGridlinePosition();
//     var4.clearAnnotations();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var18 = var17.getDataset();
//     boolean var19 = var17.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var20 = var17.getDrawingSupplier();
//     var4.setDrawingSupplier(var20);
//     var0.setDrawingSupplier(var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var20
//     assertTrue("Contract failed: equals-hashcode on var3 and var20", var3.equals(var20) ? var3.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var3
//     assertTrue("Contract failed: equals-hashcode on var20 and var3", var20.equals(var3) ? var20.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    double var6 = var5.getFixedAutoRange();
    java.awt.Shape var7 = var5.getUpArrow();
    double var8 = var5.getLowerBound();
    var5.setInverted(true);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 100.0f, 10.0f);
    var5.setRightArrow(var17);
    var1.setSeriesShape(0, var17);
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(byte)1, var17, "", "HorizontalAlignment.CENTER");
    java.lang.Comparable var23 = var22.getKey();
    java.lang.Comparable var24 = var22.getKey();
    java.lang.String var25 = var22.getURLText();
    java.lang.String var26 = var22.getShapeCoords();
    java.lang.String var27 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (byte)1+ "'", var23.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (byte)1+ "'", var24.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var25.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52"+ "'", var26.equals("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "CategoryLabelEntity: category=1, tooltip=, url=HorizontalAlignment.CENTER"+ "'", var27.equals("CategoryLabelEntity: category=1, tooltip=, url=HorizontalAlignment.CENTER"));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("", var4);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 100.0d, 100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var19 = var17.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = var17.getLegendItemLabelGenerator();
//     java.awt.Paint var21 = var17.getBaseOutlinePaint();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER", var16, var21);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("[size=-1]", var4, var21);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var28 = var26.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     double var31 = var30.getFixedAutoRange();
//     java.awt.Shape var32 = var30.getUpArrow();
//     double var33 = var30.getLowerBound();
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesStroke(0, var34, false);
//     java.awt.Stroke var38 = var26.getSeriesStroke((-16777216));
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var41 = var39.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var42 = var39.getLegendItemLabelGenerator();
//     java.awt.Paint var43 = var39.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.clearDomainMarkers((-1));
//     var44.setBackgroundAlpha(0.0f);
//     boolean var49 = var39.hasListener((java.util.EventListener)var44);
//     org.jfree.chart.labels.CategoryToolTipGenerator var52 = var39.getToolTipGenerator(10, 15);
//     java.awt.Paint var54 = var39.lookupSeriesPaint(100);
//     var26.setBaseOutlinePaint(var54);
//     java.lang.Object var56 = var23.draw(var24, var25, (java.lang.Object)var54);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(100);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var4 = var3.getRowRenderingOrder();
    org.jfree.data.general.DatasetGroup var5 = var3.getDatasetGroup();
    int var6 = var0.indexOf((java.lang.Object)var3);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
    java.awt.Paint var10 = null;
    var8.setOutlinePaint(var10);
    org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var18 = var16.equals((java.lang.Object)(short)1);
    java.lang.String var19 = var16.toString();
    var8.setInsets(var16);
    org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var27 = var25.equals((java.lang.Object)(short)1);
    java.lang.String var28 = var25.toString();
    var8.setInsets(var25, true);
    var0.set(0, (java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var19.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var28.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var5 = var3.lookupSeriesShape((-16777216));
//     java.awt.Font var7 = var3.getSeriesItemLabelFont(15);
//     java.lang.Boolean var9 = var3.getSeriesItemLabelsVisible(0);
//     var3.setBaseSeriesVisible(false);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var13 = var12.getDataset();
//     boolean var14 = var12.isOutlineVisible();
//     org.jfree.chart.util.RectangleEdge var16 = var12.getRangeAxisEdge(0);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var18 = var17.getDataset();
//     var17.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var17.datasetChanged(var21);
//     int var23 = var17.getWeight();
//     java.awt.Stroke var24 = var17.getOutlineStroke();
//     var12.setRangeGridlineStroke(var24);
//     var3.setBaseOutlineStroke(var24);
//     var0.setStroke(255, var24);
//     java.lang.Object var28 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var28.", var1.equals(var28) == var28.equals(var1));
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(true);
//     java.awt.Paint var3 = null;
//     var0.setOutlinePaint(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var8.zoomDomainAxes((-1.0d), var11, var12);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation(15);
//     var0.setRangeAxisLocation(1, var15, false);
//     org.jfree.chart.axis.AxisLocation var18 = org.jfree.chart.axis.AxisLocation.getOpposite(var15);
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     int var23 = var22.getGreen();
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var22);
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var22};
//     java.awt.Paint[] var26 = null;
//     org.jfree.chart.util.ObjectList var27 = new org.jfree.chart.util.ObjectList();
//     java.lang.Object var29 = var27.get(100);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var31 = var30.getRowRenderingOrder();
//     org.jfree.data.general.DatasetGroup var32 = var30.getDatasetGroup();
//     int var33 = var27.indexOf((java.lang.Object)var30);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var35 = var34.getRowRenderingOrder();
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var34.getDomainMarkers(var36);
//     java.awt.Stroke var38 = var34.getOutlineStroke();
//     var30.setDomainGridlineStroke(var38);
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var38};
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     double var42 = var41.getFixedAutoRange();
//     java.awt.Shape var43 = var41.getUpArrow();
//     double var44 = var41.getLowerBound();
//     java.awt.Stroke var45 = var41.getTickMarkStroke();
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setFixedDimension(0.0d);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     double var52 = var51.getFixedAutoRange();
//     java.awt.Shape var53 = var51.getUpArrow();
//     org.jfree.chart.entity.AxisLabelEntity var56 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var48, var53, "RectangleAnchor.CENTER", "");
//     java.awt.Shape[] var57 = new java.awt.Shape[] { var53};
//     org.jfree.chart.plot.DefaultDrawingSupplier var58 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var26, var40, var46, var57);
//     java.awt.Stroke var59 = var58.getNextOutlineStroke();
//     boolean var60 = var18.equals((java.lang.Object)var59);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAnchor var11 = var0.getDomainGridlinePosition();
    org.jfree.chart.plot.PlotOrientation var12 = var0.getOrientation();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    int var14 = var0.getDomainAxisIndex(var13);
    java.awt.Font var15 = var0.getNoDataMessageFont();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisLocation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setPositiveItemLabelPositionFallback(var3);
    java.awt.Paint var6 = var0.getSeriesFillPaint(1);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var11 = var10.getDataset();
    java.awt.Paint var12 = null;
    var10.setOutlinePaint(var12);
    var10.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var16 = var10.getDomainAxis();
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var10.getDomainMarkers(var17);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
    double var24 = var23.getUpperMargin();
    var19.setDomainAxis(10, var23);
    var23.setUpperMargin(0.0d);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    double var29 = var28.getFixedAutoRange();
    java.awt.Shape var30 = var28.getUpArrow();
    double var31 = var28.getLowerBound();
    java.awt.Stroke var32 = var28.getTickMarkStroke();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var34 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var33);
    boolean var35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.data.Range var36 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var33);
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
    double var38 = var37.getUpperMargin();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    double var40 = var39.getFixedAutoRange();
    java.awt.Shape var41 = var39.getUpArrow();
    double var42 = var39.getLowerBound();
    var39.setInverted(true);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, 100.0d, 100.0f, 10.0f);
    var39.setRightArrow(var51);
    var39.setVerticalTickLabels(true);
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var57 = var55.getSeriesURLGenerator(10);
    org.jfree.chart.labels.ItemLabelPosition var58 = new org.jfree.chart.labels.ItemLabelPosition();
    var55.setPositiveItemLabelPositionFallback(var58);
    var55.setAutoPopulateSeriesOutlineStroke(true);
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var7, var8, var9, var10, var23, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.data.category.CategoryDataset)var33, 10, 0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var2 = var1.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4, true);
//     org.jfree.chart.event.PlotChangeListener var7 = null;
//     var1.addChangeListener(var7);
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Paint var12 = var10.getItemPaint();
//     boolean var13 = var0.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var16 = var14.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var14.getLegendItemLabelGenerator();
//     java.awt.Paint var18 = var14.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearDomainMarkers((-1));
//     var19.setBackgroundAlpha(0.0f);
//     boolean var24 = var14.hasListener((java.util.EventListener)var19);
//     org.jfree.chart.event.MarkerChangeEvent var25 = null;
//     var19.markerChanged(var25);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var28);
//     var19.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var31);
//     boolean var33 = var31.isBorderVisible();
//     org.jfree.chart.plot.CategoryPlot var34 = var31.getCategoryPlot();
//     var10.addChangeListener((org.jfree.chart.event.TitleChangeListener)var31);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var34
//     assertTrue("Contract failed: equals-hashcode on var1 and var34", var1.equals(var34) ? var1.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var1
//     assertTrue("Contract failed: equals-hashcode on var34 and var1", var34.equals(var1) ? var34.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
    java.lang.String var5 = var4.toString();
    var1.setDefaultAutoRange(var4);
    double var7 = var1.getUpperMargin();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    boolean var13 = var10.equals((java.lang.Object)(byte)100);
    boolean var15 = var10.contains(1.0d);
    var1.setRangeWithMargins(var10, false, false);
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 100.0d);
    java.lang.String var25 = var24.toString();
    var21.setDefaultAutoRange(var24);
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var24, Double.NaN);
    org.jfree.chart.block.LengthConstraintType var29 = var28.getWidthConstraintType();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    double var32 = var31.getFixedAutoRange();
    java.awt.Shape var33 = var31.getUpArrow();
    double var34 = var31.getLowerBound();
    var31.setInverted(true);
    double var37 = var31.getUpperMargin();
    java.awt.Shape var38 = var31.getLeftArrow();
    org.jfree.data.Range var39 = null;
    org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, 100.0d);
    java.lang.String var42 = var41.toString();
    var31.setRange(var41);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var45 = null;
    org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 100.0d);
    java.lang.String var48 = var47.toString();
    var44.setDefaultAutoRange(var47);
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(var47, Double.NaN);
    org.jfree.chart.block.LengthConstraintType var52 = var51.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(0.0d, var20, var29, 109.0d, var41, var52);
    java.lang.String var54 = var53.toString();
    org.jfree.data.Range var55 = var53.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var56 = var53.toUnconstrainedWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Range[100.0,100.0]"+ "'", var5.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[100.0,100.0]"+ "'", var11.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Range[100.0,100.0]"+ "'", var25.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "Range[100.0,100.0]"+ "'", var42.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "Range[100.0,100.0]"+ "'", var48.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=109.0]"+ "'", var54.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=109.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var22 = var20.equals((java.lang.Object)(short)1);
//     var13.setAxisOffset(var20);
//     var9.setLegendItemGraphicPadding(var20);
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var31 = var29.equals((java.lang.Object)(short)1);
//     double var32 = var29.getBottom();
//     var9.setItemLabelPadding(var29);
//     double var34 = var29.getTop();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var36 = var35.getRowRenderingOrder();
//     org.jfree.chart.event.AxisChangeEvent var37 = null;
//     var35.axisChanged(var37);
//     org.jfree.chart.axis.CategoryLabelPositions var39 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var40 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var41 = var40.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var39, var40);
//     org.jfree.chart.text.TextBlockAnchor var43 = var40.getLabelAnchor();
//     boolean var44 = var35.equals((java.lang.Object)var40);
//     java.awt.Paint var45 = var35.getOutlinePaint();
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var29, var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var5.markerChanged(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
//     var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
//     boolean var19 = var17.isBorderVisible();
//     org.jfree.chart.plot.CategoryPlot var20 = var17.getCategoryPlot();
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(0.05d, 0.0d, (-1.0d), (-1.0d));
//     double var26 = var25.getBottom();
//     var17.setPadding(var25);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.clearDomainMarkers((-1));
//     var28.setBackgroundAlpha(0.0f);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     double var34 = var33.getFixedAutoRange();
//     java.awt.Shape var35 = var33.getUpArrow();
//     double var36 = var33.getLowerBound();
//     var33.setInverted(true);
//     double var39 = var33.getUpperMargin();
//     java.awt.Shape var40 = var33.getLeftArrow();
//     org.jfree.chart.util.RectangleInsets var41 = var33.getLabelInsets();
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var33};
//     var28.setRangeAxes(var42);
//     org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var46 = var44.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var47 = var44.getLegendItemLabelGenerator();
//     java.awt.Paint var48 = var44.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers((-1));
//     var49.setBackgroundAlpha(0.0f);
//     boolean var54 = var44.hasListener((java.util.EventListener)var49);
//     org.jfree.chart.event.MarkerChangeEvent var55 = null;
//     var49.markerChanged(var55);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     var58.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var58);
//     var49.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var61);
//     java.awt.image.BufferedImage var65 = var61.createBufferedImage(255, 10);
//     var28.setBackgroundImage((java.awt.Image)var65);
//     var17.setBackgroundImage((java.awt.Image)var65);
//     
//     // Checks the contract:  equals-hashcode on var3 and var47
//     assertTrue("Contract failed: equals-hashcode on var3 and var47", var3.equals(var47) ? var3.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var3
//     assertTrue("Contract failed: equals-hashcode on var47 and var3", var47.equals(var3) ? var47.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var49
//     assertTrue("Contract failed: equals-hashcode on var5 and var49", var5.equals(var49) ? var5.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var58
//     assertTrue("Contract failed: equals-hashcode on var14 and var58", var14.equals(var58) ? var14.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var58
//     assertTrue("Contract failed: equals-hashcode on var20 and var58", var20.equals(var58) ? var20.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var5
//     assertTrue("Contract failed: equals-hashcode on var49 and var5", var49.equals(var5) ? var49.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var14
//     assertTrue("Contract failed: equals-hashcode on var58 and var14", var58.equals(var14) ? var58.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var20
//     assertTrue("Contract failed: equals-hashcode on var58 and var20", var58.equals(var20) ? var58.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    java.lang.String var2 = var1.toString();
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var5 = var4.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var6 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var3, var4);
    org.jfree.chart.text.TextBlockAnchor var7 = var4.getLabelAnchor();
    java.lang.Object var8 = null;
    boolean var9 = var7.equals(var8);
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var15 = var14.getDataset();
    java.awt.Paint var16 = null;
    var14.setOutlinePaint(var16);
    org.jfree.chart.util.RectangleInsets var22 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var24 = var22.equals((java.lang.Object)(short)1);
    java.lang.String var25 = var22.toString();
    var14.setInsets(var22);
    org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var33 = var31.equals((java.lang.Object)(short)1);
    java.lang.String var34 = var31.toString();
    var14.setInsets(var31, true);
    org.jfree.chart.util.RectangleEdge var37 = var14.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var38 = var13.getLabelPosition(var37);
    org.jfree.chart.text.TextAnchor var39 = var38.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelPosition var40 = new org.jfree.chart.labels.ItemLabelPosition();
    double var41 = var40.getAngle();
    org.jfree.chart.text.TextAnchor var42 = var40.getRotationAnchor();
    org.jfree.chart.axis.NumberTick var44 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "", var39, var42, Double.NaN);
    org.jfree.chart.axis.CategoryLabelWidthType var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var48 = new org.jfree.chart.axis.CategoryLabelPosition(var1, var7, var42, 2.0d, var46, 0.95f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleAnchor.CENTER"+ "'", var2.equals("RectangleAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var25.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var34.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 0);
    org.jfree.data.general.DatasetGroup var3 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getMeanValue((-131), 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    float var1 = var0.getWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.95f);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)(byte)1);
    java.lang.Object var4 = var0.getObject((java.lang.Comparable)(-1.0f));
    java.lang.Comparable var6 = var0.getKey((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getSubplotInfo((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    boolean var4 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    var7.setDefaultAutoRange(var10);
    double var13 = var7.getUpperMargin();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    java.lang.String var17 = var16.toString();
    boolean var19 = var16.equals((java.lang.Object)(byte)100);
    boolean var21 = var16.contains(1.0d);
    var7.setRangeWithMargins(var16, false, false);
    java.awt.geom.Rectangle2D var25 = null;
    var0.drawRangeGridline(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var25, 1.0d);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var30 = var28.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var31 = var28.getGradientPaintTransformer();
    java.awt.Stroke var32 = var28.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    double var35 = var34.getFixedAutoRange();
    java.awt.Shape var36 = var34.getUpArrow();
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var39, 100.0d, 100.0f, 10.0f);
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var36, var39);
    var28.setSeriesShape(15, var39);
    org.jfree.chart.labels.ItemLabelPosition var48 = var28.getNegativeItemLabelPosition((-16777216), 0);
    var0.setNegativeItemLabelPositionFallback(var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var50 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var48);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[100.0,100.0]"+ "'", var11.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Range[100.0,100.0]"+ "'", var17.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    var0.setLowerBound(10.0d);
    var0.setAxisLineVisible(false);
    boolean var6 = var0.isAutoRange();
    var0.zoomRange(2.0d, 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var5 = var4.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var4.setDomainAxisLocation(1, var7, true);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var4.addChangeListener(var10);
    org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.LegendItemSource[] var14 = var13.getSources();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var17 = var16.getLabelFont();
    var13.setItemFont(var17);
    org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var17);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", var17);
    double var21 = var20.getContentYOffset();
    boolean var22 = var1.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    java.awt.Paint var15 = var0.lookupSeriesPaint(100);
    org.jfree.chart.urls.CategoryURLGenerator var17 = var0.getSeriesURLGenerator(10);
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getNegativeItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setTickMarkInsideLength(1.0f);
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 100.0d);
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 100.0d);
    var1.setRange(var8);
    float var10 = var1.getTickMarkInsideLength();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0f);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     var6.setAutoRange(false);
//     var6.setAxisLineVisible(true);
//     var6.setAxisLineVisible(true);
//     java.lang.String var13 = var6.getLabelURL();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var14);
//     boolean var16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var14);
//     org.jfree.data.Range var17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var14);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     org.jfree.chart.util.RectangleEdge var28 = var18.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var18.setFixedDomainAxisSpace(var29);
//     org.jfree.chart.axis.ValueAxis var32 = var18.getRangeAxis(0);
//     var14.addChangeListener((org.jfree.data.general.DatasetChangeListener)var18);
//     var0.drawItem(var1, var2, var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.data.category.CategoryDataset)var14, 1, 255, 100);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     java.lang.String var15 = var14.toString();
//     var11.setDefaultAutoRange(var14);
//     double var17 = var11.getUpperMargin();
//     java.awt.Paint var18 = var11.getAxisLinePaint();
//     var9.setBackgroundPaint(var18);
//     org.jfree.chart.event.TitleChangeEvent var20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var9);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var24 = var23.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var23.setDomainAxisLocation(1, var26, true);
//     org.jfree.chart.event.PlotChangeListener var29 = null;
//     var23.addChangeListener(var29);
//     org.jfree.chart.plot.DatasetRenderingOrder var31 = var23.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     var23.clearRangeMarkers();
//     org.jfree.chart.LegendItemCollection var34 = var23.getFixedLegendItems();
//     java.lang.Object var35 = var9.draw(var21, var22, (java.lang.Object)var23);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ui.Library var9 = new org.jfree.chart.ui.Library("", "hi!", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "");
    java.lang.String var10 = var9.getName();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAntiAlias((java.lang.Object)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var5 = var4.getAngle();
//     org.jfree.chart.text.TextAnchor var6 = var4.getRotationAnchor();
//     java.awt.geom.Rectangle2D var7 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, 10.0f, 0.0f, var6);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    float[] var4 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = var3.getComponents(var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.clearRangeMarkers();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var12 = var11.getDataset();
    boolean var13 = var11.isOutlineVisible();
    org.jfree.chart.plot.DrawingSupplier var14 = var11.getDrawingSupplier();
    var0.setDrawingSupplier(var14);
    org.jfree.chart.event.MarkerChangeEvent var16 = null;
    var0.markerChanged(var16);
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var20 = var18.lookupSeriesShape((-16777216));
    java.awt.Font var22 = var18.getSeriesItemLabelFont(15);
    java.lang.Boolean var24 = var18.getSeriesItemLabelsVisible(0);
    var18.setBaseSeriesVisible(false);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var28 = var27.getDataset();
    boolean var29 = var27.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var31 = var27.getRangeAxisEdge(0);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var33 = var32.getDataset();
    var32.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
    org.jfree.data.general.DatasetChangeEvent var36 = null;
    var32.datasetChanged(var36);
    int var38 = var32.getWeight();
    java.awt.Stroke var39 = var32.getOutlineStroke();
    var27.setRangeGridlineStroke(var39);
    var18.setBaseOutlineStroke(var39);
    var0.setRangeCrosshairStroke(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = var0.getBaseToolTipGenerator();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.setRangeCrosshairVisible(true);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     var18.clearRangeMarkers();
//     org.jfree.chart.axis.CategoryAnchor var29 = var18.getDomainGridlinePosition();
//     var15.setDomainGridlinePosition(var29);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var32 = var31.getDataset();
//     boolean var33 = var31.isOutlineVisible();
//     int var34 = var31.getBackgroundImageAlignment();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     double var36 = var35.getFixedAutoRange();
//     java.awt.Shape var37 = var35.getUpArrow();
//     double var38 = var35.getLowerBound();
//     java.awt.Stroke var39 = var35.getTickMarkStroke();
//     var31.setRangeCrosshairStroke(var39);
//     var15.setOutlineStroke(var39);
//     var0.setBaseOutlineStroke(var39, true);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var47 = var45.lookupSeriesShape((-16777216));
//     java.awt.Font var49 = var45.getSeriesItemLabelFont(15);
//     org.jfree.chart.labels.ItemLabelPosition var52 = var45.getNegativeItemLabelPosition(0, (-16777216));
//     var0.setSeriesPositiveItemLabelPosition(10, var52, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var45 and var0.", var45.equals(var0) == var0.equals(var45));
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 100.0d);
    java.lang.String var8 = var7.toString();
    var4.setDefaultAutoRange(var7);
    double var10 = var4.getUpperMargin();
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 100.0d);
    java.lang.String var14 = var13.toString();
    boolean var16 = var13.equals((java.lang.Object)(byte)100);
    boolean var18 = var13.contains(1.0d);
    var4.setRangeWithMargins(var13, false, false);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    var4.setTickUnit(var23);
    double var25 = var23.getSize();
    java.lang.String var26 = var23.toString();
    java.awt.Color var30 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    int var31 = var30.getGreen();
    int var32 = var23.compareTo((java.lang.Object)var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var33 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 109.0d, 100.0d, 100, (java.lang.Comparable)var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Range[100.0,100.0]"+ "'", var8.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Range[100.0,100.0]"+ "'", var14.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "[size=-1]"+ "'", var26.equals("[size=-1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     var5.setUpperMargin(0.05d);
//     var5.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     double var11 = var10.getFixedAutoRange();
//     java.awt.Shape var12 = var10.getUpArrow();
//     double var13 = var10.getLowerBound();
//     var10.setInverted(true);
//     double var16 = var10.getUpperMargin();
//     java.awt.Shape var17 = var10.getLeftArrow();
//     org.jfree.chart.util.RectangleInsets var18 = var10.getLabelInsets();
//     org.jfree.chart.util.Layer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var21 = var20.getDataset();
//     java.awt.Paint var22 = null;
//     var20.setOutlinePaint(var22);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var30 = var28.equals((java.lang.Object)(short)1);
//     java.lang.String var31 = var28.toString();
//     var20.setInsets(var28);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Point2D var37 = null;
//     var20.zoomRangeAxes(100.0d, 1.0d, var36, var37);
//     java.awt.geom.Rectangle2D var39 = var36.getPlotArea();
//     var0.drawAnnotations(var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var10, var19, var36);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var4 = var2.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearDomainMarkers((-1));
    var7.setBackgroundAlpha(0.0f);
    boolean var12 = var2.hasListener((java.util.EventListener)var7);
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
    java.awt.Font var15 = var14.getFont();
    var2.setBaseItemLabelFont(var15);
    org.jfree.chart.labels.CategoryToolTipGenerator var18 = var2.getSeriesToolTipGenerator(100);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = var2.getLegendItemLabelGenerator();
    boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.block.CenterArrangement var1 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var2);
    java.util.List var4 = var2.getColumnKeys();
    org.jfree.chart.title.LegendItemBlockContainer var6 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, (org.jfree.data.general.Dataset)var2, (java.lang.Comparable)10L);
    java.lang.String var7 = var6.getToolTipText();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var12 = var0.arrange((org.jfree.chart.block.BlockContainer)var6, var8, var11);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("NOID", var1);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var39 = var34.arrange(var35, var38);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var42 = var41.getDataset();
//     java.awt.Paint var43 = null;
//     var41.setOutlinePaint(var43);
//     org.jfree.chart.util.RectangleInsets var49 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var51 = var49.equals((java.lang.Object)(short)1);
//     java.lang.String var52 = var49.toString();
//     var41.setInsets(var49);
//     org.jfree.chart.ChartRenderingInfo var56 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var57 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
//     java.awt.geom.Point2D var58 = null;
//     var41.zoomRangeAxes(100.0d, 1.0d, var57, var58);
//     java.awt.geom.Rectangle2D var60 = var57.getDataArea();
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var63 = var61.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var64 = var61.getLegendItemLabelGenerator();
//     java.awt.Paint var67 = var61.getItemPaint(0, 100);
//     org.jfree.chart.renderer.category.BarRenderer var68 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var70 = var68.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var71 = var68.getGradientPaintTransformer();
//     var61.setGradientPaintTransformer(var71);
//     boolean var73 = var61.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var74 = var34.draw(var40, var60, (java.lang.Object)var73);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setFixedDimension(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    org.jfree.chart.entity.AxisLabelEntity var9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var6, "RectangleAnchor.CENTER", "");
    var1.setLowerMargin(10.0d);
    java.lang.String var12 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 100.0d);
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    double var11 = var10.getCentralValue();
    boolean var12 = var0.equals((java.lang.Object)var10);
    var0.setPositiveArrowVisible(false);
    double var15 = var0.getUpperBound();
    var0.setNegativeArrowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    int var4 = var3.getGreen();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
    float[] var6 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var1 = var0.clone();
//     int var2 = var0.getItemCount();
//     java.lang.Object var3 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 1.0d, 100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Font var6 = null;
//     java.awt.Paint var7 = null;
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var7, 1.0f, 100, var10);
//     org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var16 = var15.getLabelFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     java.lang.Object var18 = null;
//     boolean var19 = var17.equals(var18);
//     var11.addLine(var17);
//     org.jfree.chart.axis.CategoryLabelPositions var21 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var22 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var23 = var22.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var21, var22);
//     org.jfree.chart.text.TextBlockAnchor var25 = var22.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     java.awt.Paint var32 = null;
//     var30.setOutlinePaint(var32);
//     org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var40 = var38.equals((java.lang.Object)(short)1);
//     java.lang.String var41 = var38.toString();
//     var30.setInsets(var38);
//     org.jfree.chart.util.RectangleInsets var47 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var49 = var47.equals((java.lang.Object)(short)1);
//     java.lang.String var50 = var47.toString();
//     var30.setInsets(var47, true);
//     org.jfree.chart.util.RectangleEdge var53 = var30.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var54 = var29.getLabelPosition(var53);
//     org.jfree.chart.text.TextAnchor var55 = var54.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var56 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var57 = var56.getAngle();
//     org.jfree.chart.text.TextAnchor var58 = var56.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var60 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "", var55, var58, Double.NaN);
//     org.jfree.chart.axis.CategoryTick var62 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)0L, var11, var25, var58, Double.NaN);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelEntity: category=1, tooltip=, url=HorizontalAlignment.CENTER", var1, 0.0f, 1.0f, var58, 0.05d, 0.0f, (-1.0f));
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     java.awt.Paint var2 = null;
//     var0.setOutlinePaint(var2);
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var10 = var8.equals((java.lang.Object)(short)1);
//     java.lang.String var11 = var8.toString();
//     var0.setInsets(var8);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Point2D var17 = null;
//     var0.zoomRangeAxes(100.0d, 1.0d, var16, var17);
//     java.awt.geom.Rectangle2D var19 = var16.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var21 = var20.getDataset();
//     java.awt.Paint var22 = null;
//     var20.setOutlinePaint(var22);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var30 = var28.equals((java.lang.Object)(short)1);
//     java.lang.String var31 = var28.toString();
//     var20.setInsets(var28);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Point2D var37 = null;
//     var20.zoomRangeAxes(100.0d, 1.0d, var36, var37);
//     java.awt.geom.Rectangle2D var39 = var36.getDataArea();
//     var16.addSubplotInfo(var36);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("HorizontalAlignment.CENTER");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    var0.setUpperMargin(0.05d);
    var0.clearCategoryLabelToolTips();
    java.lang.Comparable var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var6 = var0.getTickLabelPaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(10.0d, 10.0d);
    org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
    java.lang.Object var5 = var3.getObject((java.lang.Comparable)(byte)1);
    boolean var6 = var2.equals((java.lang.Object)var3);
    boolean var8 = var2.equals((java.lang.Object)(byte)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleEdge.BOTTOM");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    java.awt.Paint var2 = null;
    var0.setOutlinePaint(var2);
    org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
    boolean var10 = var8.equals((java.lang.Object)(short)1);
    java.lang.String var11 = var8.toString();
    var0.setInsets(var8);
    org.jfree.chart.ChartRenderingInfo var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
    java.awt.geom.Point2D var17 = null;
    var0.zoomRangeAxes(100.0d, 1.0d, var16, var17);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var11.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartChangeEventType.GENERAL", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var1);
//     java.util.List var3 = var1.getColumnKeys();
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     
//     // Checks the contract:  equals-hashcode on var6 and var7
//     assertTrue("Contract failed: equals-hashcode on var6 and var7", var6.equals(var7) ? var6.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var6
//     assertTrue("Contract failed: equals-hashcode on var7 and var6", var7.equals(var6) ? var7.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     java.awt.Paint var2 = null;
//     var0.setOutlinePaint(var2);
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var10 = var8.equals((java.lang.Object)(short)1);
//     java.lang.String var11 = var8.toString();
//     var0.setInsets(var8);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Point2D var17 = null;
//     var0.zoomRangeAxes(100.0d, 1.0d, var16, var17);
//     java.awt.geom.Rectangle2D var19 = var16.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var21 = var20.getDataset();
//     java.awt.Paint var22 = null;
//     var20.setOutlinePaint(var22);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var30 = var28.equals((java.lang.Object)(short)1);
//     java.lang.String var31 = var28.toString();
//     var20.setInsets(var28);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Point2D var37 = null;
//     var20.zoomRangeAxes(100.0d, 1.0d, var36, var37);
//     java.awt.geom.Rectangle2D var39 = var36.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var42 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var39, "", "hi!");
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.contains(var19, var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var36
//     assertTrue("Contract failed: equals-hashcode on var16 and var36", var16.equals(var36) ? var16.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var16
//     assertTrue("Contract failed: equals-hashcode on var36 and var16", var36.equals(var16) ? var36.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.util.Layer var2 = null;
//     java.util.Collection var3 = var0.getDomainMarkers(var2);
//     var0.zoom(111.0d);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var5 = var4.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var4.setDomainAxisLocation(1, var7, true);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var4.addChangeListener(var10);
    org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var14 = var13.getBackgroundPaint();
    var13.setWidth(10.0d);
    java.awt.Font var17 = var13.getItemFont();
    var0.setFont(var17);
    java.awt.Paint var19 = var0.getBackgroundPaint();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.data.Range var24 = var23.getWidthRange();
    java.lang.String var25 = var23.toString();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    double var27 = var26.getFixedAutoRange();
    java.awt.Shape var28 = var26.getUpArrow();
    double var29 = var26.getLowerBound();
    var26.setInverted(true);
    double var32 = var26.getUpperMargin();
    java.awt.Shape var33 = var26.getLeftArrow();
    org.jfree.data.Range var34 = null;
    org.jfree.data.Range var36 = org.jfree.data.Range.expandToInclude(var34, 100.0d);
    java.lang.String var37 = var36.toString();
    var26.setRange(var36);
    org.jfree.chart.block.RectangleConstraint var39 = var23.toRangeHeight(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var40 = var0.arrange(var20, var23);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"+ "'", var25.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "Range[100.0,100.0]"+ "'", var37.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     var34.setLineVisible(true);
//     org.jfree.chart.ui.Library var41 = new org.jfree.chart.ui.Library("", "hi!", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", "");
//     java.lang.String var42 = var41.getName();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var44 = var43.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var46 = null;
//     var43.setDomainAxisLocation(1, var46, true);
//     org.jfree.chart.event.PlotChangeListener var49 = null;
//     var43.addChangeListener(var49);
//     org.jfree.chart.plot.DatasetRenderingOrder var51 = var43.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var43);
//     org.jfree.chart.LegendItemSource[] var53 = var52.getSources();
//     org.jfree.chart.util.RectangleAnchor var54 = var52.getLegendItemGraphicAnchor();
//     boolean var55 = var41.equals((java.lang.Object)var54);
//     var34.setShapeLocation(var54);
//     
//     // Checks the contract:  equals-hashcode on var30 and var43
//     assertTrue("Contract failed: equals-hashcode on var30 and var43", var30.equals(var43) ? var30.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var30
//     assertTrue("Contract failed: equals-hashcode on var43 and var30", var43.equals(var30) ? var43.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.GENERAL", "Range[100.0,100.0]", var3);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    double var6 = var5.getFixedAutoRange();
    java.awt.Shape var7 = var5.getUpArrow();
    double var8 = var5.getLowerBound();
    var5.setInverted(true);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 100.0f, 10.0f);
    var5.setRightArrow(var17);
    var1.setSeriesShape(0, var17);
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(byte)1, var17, "", "HorizontalAlignment.CENTER");
    java.lang.Comparable var23 = var22.getKey();
    java.lang.Comparable var24 = var22.getKey();
    java.lang.String var25 = var22.getURLText();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    double var27 = var26.getFixedAutoRange();
    java.awt.Shape var28 = var26.getUpArrow();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 100.0d, 100.0f, 10.0f);
    boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var28, var31);
    var22.setArea(var28);
    org.jfree.data.category.CategoryDataset var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var43 = new org.jfree.chart.entity.CategoryItemEntity(var28, "CategoryLabelEntity: category=1, tooltip=, url=HorizontalAlignment.CENTER", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", var40, (java.lang.Comparable)false, (java.lang.Comparable)100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (byte)1+ "'", var23.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (byte)1+ "'", var24.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var25.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    boolean var6 = org.jfree.chart.util.ShapeUtilities.equal(var2, var5);
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var7, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var5.markerChanged(var11);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
    var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
    boolean var19 = var17.isBorderVisible();
    org.jfree.chart.plot.CategoryPlot var20 = var17.getCategoryPlot();
    org.jfree.chart.ChartRenderingInfo var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var24 = var17.createBufferedImage((-1), 0, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]", var3);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.NaN, 10.0d, var2);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=109.0]");

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    double var2 = var1.getAngle();
    org.jfree.chart.text.TextAnchor var3 = var1.getRotationAnchor();
    org.jfree.chart.axis.AxisState var5 = new org.jfree.chart.axis.AxisState(1.0d);
    double var6 = var5.getCursor();
    var5.cursorUp((-1.0d));
    boolean var9 = var3.equals((java.lang.Object)(-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator(10);
    var0.setBaseCreateEntities(false);
    java.awt.Paint var6 = var0.getSeriesOutlinePaint(0);
    var0.setMinimumBarLength(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    double var2 = var1.getFixedAutoRange();
    java.awt.Shape var3 = var1.getUpArrow();
    double var4 = var1.getLowerBound();
    var1.setInverted(true);
    double var7 = var1.getUpperMargin();
    java.awt.Shape var8 = var1.getLeftArrow();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 100.0d);
    java.lang.String var12 = var11.toString();
    var1.setRange(var11);
    org.jfree.data.Range var14 = org.jfree.data.Range.combine(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Range[100.0,100.0]"+ "'", var12.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var5 = var0.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var7);
    double var9 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var3 = var1.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var4 = var1.getGradientPaintTransformer();
//     var1.setAutoPopulateSeriesShape(false);
//     java.awt.Paint var8 = var1.lookupSeriesOutlinePaint(100);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     var14.setBackgroundAlpha(0.0f);
//     boolean var19 = var9.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var14.markerChanged(var20);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var23);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     boolean var28 = var26.isBorderVisible();
//     java.awt.Stroke var29 = var26.getBorderStroke();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var8, var29);
//     java.awt.Stroke var31 = var30.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var32 = var30.getLabelOffsetType();
//     org.jfree.data.Range var34 = null;
//     org.jfree.data.Range var36 = org.jfree.data.Range.expandToInclude(var34, 100.0d);
//     org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var36, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(0.0d, var36);
//     org.jfree.chart.block.RectangleConstraint var40 = var39.toUnconstrainedHeight();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var42 = var41.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var44 = null;
//     var41.setDomainAxisLocation(1, var44, true);
//     org.jfree.chart.event.PlotChangeListener var47 = null;
//     var41.addChangeListener(var47);
//     org.jfree.chart.plot.DatasetRenderingOrder var49 = var41.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
//     org.jfree.chart.LegendItemSource[] var51 = var50.getSources();
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var54 = var53.getLabelFont();
//     var50.setItemFont(var54);
//     org.jfree.chart.util.RectangleEdge var56 = var50.getLegendItemGraphicEdge();
//     java.awt.Font var58 = null;
//     java.awt.Paint var59 = null;
//     org.jfree.chart.text.TextMeasurer var62 = null;
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, var59, 1.0f, 100, var62);
//     org.jfree.chart.util.HorizontalAlignment var64 = var63.getLineAlignment();
//     java.lang.String var65 = var64.toString();
//     var50.setHorizontalAlignment(var64);
//     var50.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var76 = var50.arrange(var72, var75);
//     var76.setHeight(1.0d);
//     org.jfree.chart.util.Size2D var79 = var39.calculateConstrainedSize(var76);
//     java.lang.String var80 = var79.toString();
//     boolean var81 = var32.equals((java.lang.Object)var80);
//     
//     // Checks the contract:  equals-hashcode on var23 and var41
//     assertTrue("Contract failed: equals-hashcode on var23 and var41", var23.equals(var41) ? var23.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var23
//     assertTrue("Contract failed: equals-hashcode on var41 and var23", var41.equals(var23) ? var41.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 1.0f, 100, var5);
//     org.jfree.chart.util.HorizontalAlignment var7 = var6.getLineAlignment();
//     org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var7.equals((java.lang.Object)var9);
//     java.lang.Object var12 = var9.clone();
//     
//     // Checks the contract:  equals-hashcode on var10 and var12
//     assertTrue("Contract failed: equals-hashcode on var10 and var12", var10.equals(var12) ? var10.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var10
//     assertTrue("Contract failed: equals-hashcode on var12 and var10", var12.equals(var10) ? var12.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RangeType.FULL", var1, 1.0f, 2.0f, 1.0d, 10.0f, 0.0f);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var4 = var3.getLabelFont();
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("", var4);
    org.jfree.chart.text.TextFragment var6 = null;
    var5.addFragment(var6);
    var0.addLine(var5);
    org.jfree.chart.text.TextLine var9 = var0.getLastLine();
    org.jfree.chart.util.StandardGradientPaintTransformer var10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var11 = var10.clone();
    boolean var12 = var9.equals(var11);
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("Range[100.0,100.0]");
    var9.addFragment(var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    double var21 = var20.getUpperMargin();
    var16.setDomainAxis(10, var20);
    org.jfree.chart.event.AxisChangeEvent var23 = null;
    var16.axisChanged(var23);
    org.jfree.chart.axis.CategoryAxis var26 = var16.getDomainAxis(0);
    boolean var27 = var14.equals((java.lang.Object)var16);
    org.jfree.chart.block.Arrangement var28 = null;
    org.jfree.chart.block.CenterArrangement var29 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var31 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var30);
    java.util.List var32 = var30.getColumnKeys();
    org.jfree.chart.title.LegendItemBlockContainer var34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var29, (org.jfree.data.general.Dataset)var30, (java.lang.Comparable)10L);
    org.jfree.chart.block.BlockContainer var35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, var28, (org.jfree.chart.block.Arrangement)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setNoDataMessage("");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     double var6 = var5.getFixedAutoRange();
//     java.awt.Shape var7 = var5.getUpArrow();
//     double var8 = var5.getLowerBound();
//     var5.setInverted(true);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 100.0f, 10.0f);
//     var5.setRightArrow(var17);
//     boolean var19 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var21 = var20.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setDomainAxisLocation(1, var23, true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var20.addChangeListener(var26);
//     org.jfree.chart.plot.DatasetRenderingOrder var28 = var20.getDatasetRenderingOrder();
//     double var29 = var20.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var20.axisChanged(var30);
//     org.jfree.chart.util.RectangleEdge var32 = var20.getRangeAxisEdge();
//     java.awt.Paint var33 = var20.getRangeCrosshairPaint();
//     var5.setLabelPaint(var33);
//     var0.setRangeGridlinePaint(var33);
//     var0.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setRangeCrosshairVisible(true);
//     java.awt.Paint var42 = null;
//     var39.setOutlinePaint(var42);
//     org.jfree.chart.event.PlotChangeListener var44 = null;
//     var39.addChangeListener(var44);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var48 = var47.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Point2D var51 = null;
//     var47.zoomDomainAxes((-1.0d), var50, var51);
//     org.jfree.chart.axis.AxisLocation var54 = var47.getDomainAxisLocation(15);
//     var39.setRangeAxisLocation(1, var54, false);
//     var0.setRangeAxisLocation(1, var54, true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var47
//     assertTrue("Contract failed: equals-hashcode on var20 and var47", var20.equals(var47) ? var20.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var20
//     assertTrue("Contract failed: equals-hashcode on var47 and var20", var47.equals(var20) ? var47.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    java.awt.Stroke var4 = var0.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    double var7 = var6.getFixedAutoRange();
    java.awt.Shape var8 = var6.getUpArrow();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
    var0.setSeriesShape(15, var11);
    org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    double var22 = var21.getFixedAutoRange();
    java.awt.Shape var23 = var21.getUpArrow();
    double var24 = var21.getLowerBound();
    var21.setInverted(true);
    double var27 = var21.getUpperMargin();
    java.awt.Shape var28 = var21.getLeftArrow();
    boolean var29 = var20.equals((java.lang.Object)var28);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
    boolean var32 = var30.isOutlineVisible();
    java.awt.Paint var33 = var30.getRangeGridlinePaint();
    org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    org.jfree.chart.util.Size2D var39 = var34.arrange(var35, var38);
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var42 = null;
    org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 100.0d);
    java.lang.String var45 = var44.toString();
    var41.setDefaultAutoRange(var44);
    org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var44, Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var49 = var34.arrange(var40, var48);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "Range[100.0,100.0]"+ "'", var45.equals("Range[100.0,100.0]"));

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var13 = var12.getLabelFont();
//     var9.setItemFont(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var9.getLegendItemGraphicEdge();
//     org.jfree.chart.util.HorizontalAlignment var16 = var9.getHorizontalAlignment();
//     java.awt.geom.Rectangle2D var17 = var9.getBounds();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     double var27 = var18.getRangeCrosshairValue();
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var18.getDomainMarkers(var28);
//     org.jfree.chart.util.RectangleEdge var31 = var18.getDomainAxisEdge((-131));
//     double var32 = org.jfree.chart.util.RectangleEdge.coordinate(var17, var31);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-131), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("NOID", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RangeType.FULL", var1);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 100.0d);
    java.lang.String var5 = var4.toString();
    var1.setDefaultAutoRange(var4);
    double var7 = var1.getUpperMargin();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    boolean var13 = var10.equals((java.lang.Object)(byte)100);
    boolean var15 = var10.contains(1.0d);
    var1.setRangeWithMargins(var10, false, false);
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    var1.setTickUnit(var20);
    double var22 = var20.getSize();
    java.lang.String var23 = var20.toString();
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    int var28 = var27.getGreen();
    int var29 = var20.compareTo((java.lang.Object)var27);
    var0.add((org.jfree.chart.axis.TickUnit)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var32 = var0.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Range[100.0,100.0]"+ "'", var5.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[100.0,100.0]"+ "'", var11.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "[size=-1]"+ "'", var23.equals("[size=-1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
    org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    org.jfree.chart.block.BlockContainer var9 = null;
    java.awt.Graphics2D var10 = null;
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(10.0d, var12);
    org.jfree.data.Range var16 = var15.getWidthRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var0.arrange(var9, var10, var15);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     double var6 = var5.getFixedAutoRange();
//     java.awt.Shape var7 = var5.getUpArrow();
//     double var8 = var5.getLowerBound();
//     var5.setInverted(true);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 100.0f, 10.0f);
//     var5.setRightArrow(var17);
//     var1.setSeriesShape(0, var17);
//     java.awt.Font var22 = var1.getItemLabelFont(0, (-16777216));
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("RectangleAnchor.CENTER", var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var25 = var23.calculateDimensions(var24);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var3 = var1.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var4 = var1.getGradientPaintTransformer();
//     var1.setAutoPopulateSeriesShape(false);
//     java.awt.Paint var8 = var1.lookupSeriesOutlinePaint(100);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     var14.setBackgroundAlpha(0.0f);
//     boolean var19 = var9.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var14.markerChanged(var20);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var23);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     boolean var28 = var26.isBorderVisible();
//     java.awt.Stroke var29 = var26.getBorderStroke();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var8, var29);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     java.awt.Font var32 = var30.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var34 = var33.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var36 = null;
//     var33.setDomainAxisLocation(1, var36, true);
//     org.jfree.chart.event.PlotChangeListener var39 = null;
//     var33.addChangeListener(var39);
//     org.jfree.chart.plot.DatasetRenderingOrder var41 = var33.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
//     org.jfree.chart.LegendItemSource[] var43 = var42.getSources();
//     org.jfree.chart.util.RectangleAnchor var44 = var42.getLegendItemGraphicAnchor();
//     var30.setLabelAnchor(var44);
//     
//     // Checks the contract:  equals-hashcode on var23 and var33
//     assertTrue("Contract failed: equals-hashcode on var23 and var33", var23.equals(var33) ? var23.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var23
//     assertTrue("Contract failed: equals-hashcode on var33 and var23", var33.equals(var23) ? var33.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var0.add(1.0d, 0.0d, (java.lang.Comparable)true, (java.lang.Comparable)1L);
    int var7 = var0.getRowIndex((java.lang.Comparable)(short)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var1);
//     java.util.List var3 = var1.getColumnKeys();
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     var5.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
//     double var8 = var5.getContentXOffset();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var11 = var10.getDataset();
//     java.awt.Paint var12 = null;
//     var10.setOutlinePaint(var12);
//     org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var20 = var18.equals((java.lang.Object)(short)1);
//     java.lang.String var21 = var18.toString();
//     var10.setInsets(var18);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Point2D var27 = null;
//     var10.zoomRangeAxes(100.0d, 1.0d, var26, var27);
//     java.awt.geom.Rectangle2D var29 = var26.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var32 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var29, "", "hi!");
//     org.jfree.data.Range var33 = null;
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 100.0d);
//     java.lang.String var36 = var35.toString();
//     boolean var38 = var35.equals((java.lang.Object)(byte)100);
//     org.jfree.data.Range var39 = null;
//     org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, 100.0d);
//     org.jfree.data.Range var43 = org.jfree.data.Range.expandToInclude(var41, 100.0d);
//     org.jfree.data.Range var44 = org.jfree.data.Range.combine(var35, var41);
//     java.lang.Object var45 = var5.draw(var9, var29, (java.lang.Object)var35);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var13 = var11.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var11.getLegendItemLabelGenerator();
//     java.awt.Paint var15 = var11.getBaseOutlinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER", var10, var15);
//     boolean var17 = var16.isShapeVisible();
//     org.jfree.chart.util.GradientPaintTransformer var18 = var16.getFillPaintTransformer();
//     boolean var19 = var16.isShapeVisible();
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 100.0d, 100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var33 = var31.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = var31.getLegendItemLabelGenerator();
//     java.awt.Paint var35 = var31.getBaseOutlinePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER", var30, var35);
//     boolean var37 = var36.isShapeVisible();
//     org.jfree.chart.util.GradientPaintTransformer var38 = var36.getFillPaintTransformer();
//     var16.setFillPaintTransformer(var38);
//     
//     // Checks the contract:  equals-hashcode on var14 and var34
//     assertTrue("Contract failed: equals-hashcode on var14 and var34", var14.equals(var34) ? var14.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var14
//     assertTrue("Contract failed: equals-hashcode on var34 and var14", var34.equals(var14) ? var34.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Category Plot", var1);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(true);
//     java.awt.Paint var3 = null;
//     var0.setOutlinePaint(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var8.zoomDomainAxes((-1.0d), var11, var12);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getDomainAxisLocation(15);
//     var0.setRangeAxisLocation(1, var15, false);
//     org.jfree.chart.axis.ValueAxis var19 = var0.getRangeAxisForDataset((-1));
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(2.0d);
//     org.jfree.chart.util.Layer var23 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var22, var23);
//     java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     double var30 = var29.getFixedAutoRange();
//     java.awt.Shape var31 = var29.getUpArrow();
//     org.jfree.chart.JFreeChart var32 = null;
//     org.jfree.chart.event.ChartProgressEvent var35 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var29, var32, 0, 100);
//     var29.setInverted(false);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var38, 0);
//     java.lang.Comparable var43 = null;
//     var38.add((java.lang.Number)100.0d, (java.lang.Number)1, var43, (java.lang.Comparable)10L);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var47 = var46.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var46.zoomDomainAxes((-1.0d), var49, var50);
//     org.jfree.chart.axis.AxisLocation var53 = var46.getDomainAxisLocation(15);
//     boolean var54 = var38.hasListener((java.util.EventListener)var46);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var55 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var55, 0);
//     org.jfree.data.general.DatasetGroup var58 = var55.getGroup();
//     var38.setGroup(var58);
//     org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var38);
//     var29.setRangeWithMargins(var60);
//     boolean var62 = var28.equals((java.lang.Object)var29);
//     var22.setLabelPaint((java.awt.Paint)var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var46
//     assertTrue("Contract failed: equals-hashcode on var8 and var46", var8.equals(var46) ? var8.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var8
//     assertTrue("Contract failed: equals-hashcode on var46 and var8", var46.equals(var8) ? var46.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    java.awt.Font var4 = var0.getSeriesItemLabelFont(15);
    java.lang.Boolean var6 = var0.getSeriesItemLabelsVisible(0);
    var0.setBaseSeriesVisible(false);
    java.awt.Stroke var11 = var0.getItemOutlineStroke(0, 1);
    org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition();
    var0.setBaseNegativeItemLabelPosition(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(Double.NaN, 0.0d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     java.awt.Shape var2 = var0.getUpArrow();
//     org.jfree.chart.JFreeChart var3 = null;
//     org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
//     java.awt.Paint var10 = null;
//     var8.setOutlinePaint(var10);
//     org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var18 = var16.equals((java.lang.Object)(short)1);
//     java.lang.String var19 = var16.toString();
//     var8.setInsets(var16);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Point2D var25 = null;
//     var8.zoomRangeAxes(100.0d, 1.0d, var24, var25);
//     java.awt.geom.Rectangle2D var27 = var24.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var30 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var27, "", "hi!");
//     org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var34 = var33.getDataset();
//     java.awt.Paint var35 = null;
//     var33.setOutlinePaint(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var43 = var41.equals((java.lang.Object)(short)1);
//     java.lang.String var44 = var41.toString();
//     var33.setInsets(var41);
//     org.jfree.chart.util.RectangleInsets var50 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var52 = var50.equals((java.lang.Object)(short)1);
//     java.lang.String var53 = var50.toString();
//     var33.setInsets(var50, true);
//     org.jfree.chart.util.RectangleEdge var56 = var33.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var57 = var32.getLabelPosition(var56);
//     double var58 = var0.lengthToJava2D(Double.NaN, var27, var56);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var5 = var4.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var4.setDomainAxisLocation(1, var7, true);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var4.addChangeListener(var10);
//     org.jfree.chart.plot.DatasetRenderingOrder var12 = var4.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     var13.setWidth(10.0d);
//     java.awt.Font var17 = var13.getItemFont();
//     var0.setFont(var17);
//     java.awt.Paint var19 = var0.getPaint();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var0.draw(var20, var21);
//     var0.setText("RangeType.FULL");
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var27 = var26.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var26.setDomainAxisLocation(1, var29, true);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var26.addChangeListener(var32);
//     org.jfree.chart.plot.DatasetRenderingOrder var34 = var26.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
//     org.jfree.chart.LegendItemSource[] var36 = var35.getSources();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var39 = var38.getLabelFont();
//     var35.setItemFont(var39);
//     org.jfree.chart.util.RectangleEdge var41 = var35.getLegendItemGraphicEdge();
//     org.jfree.chart.util.HorizontalAlignment var42 = var35.getHorizontalAlignment();
//     java.awt.geom.Rectangle2D var43 = var35.getBounds();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 100.0d);
//     java.lang.String var48 = var47.toString();
//     var44.setDefaultAutoRange(var47);
//     double var50 = var44.getUpperMargin();
//     java.awt.Paint var51 = var44.getAxisLinePaint();
//     var44.setRange((-1.0d), 0.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var55 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var56 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var57 = var56.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var58 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var55, var56);
//     org.jfree.chart.axis.CategoryLabelPosition var59 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var60 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var55, var59);
//     boolean var61 = var44.equals((java.lang.Object)var55);
//     java.lang.Object var62 = var0.draw(var25, var43, (java.lang.Object)var61);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var5.markerChanged(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var14);
//     var5.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var17);
//     boolean var19 = var17.isBorderVisible();
//     java.awt.Stroke var20 = var17.getBorderStroke();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var22 = var21.getDataset();
//     boolean var23 = var21.isOutlineVisible();
//     org.jfree.chart.plot.DrawingSupplier var24 = var21.getDrawingSupplier();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var27 = var25.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var25.getLegendItemLabelGenerator();
//     java.awt.Paint var29 = var25.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearDomainMarkers((-1));
//     var30.setBackgroundAlpha(0.0f);
//     boolean var35 = var25.hasListener((java.util.EventListener)var30);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var30.markerChanged(var36);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var39);
//     var30.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var42);
//     java.awt.image.BufferedImage var46 = var42.createBufferedImage(255, 10);
//     var21.setBackgroundImage((java.awt.Image)var46);
//     var17.setBackgroundImage((java.awt.Image)var46);
//     
//     // Checks the contract:  equals-hashcode on var3 and var28
//     assertTrue("Contract failed: equals-hashcode on var3 and var28", var3.equals(var28) ? var3.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var3
//     assertTrue("Contract failed: equals-hashcode on var28 and var3", var28.equals(var3) ? var28.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var30
//     assertTrue("Contract failed: equals-hashcode on var5 and var30", var5.equals(var30) ? var5.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var39
//     assertTrue("Contract failed: equals-hashcode on var14 and var39", var14.equals(var39) ? var14.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var5
//     assertTrue("Contract failed: equals-hashcode on var30 and var5", var30.equals(var5) ? var30.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var14
//     assertTrue("Contract failed: equals-hashcode on var39 and var14", var39.equals(var14) ? var39.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers((-1));
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    double var6 = var5.getFixedAutoRange();
    java.awt.Shape var7 = var5.getUpArrow();
    double var8 = var5.getLowerBound();
    var5.setInverted(true);
    double var11 = var5.getUpperMargin();
    java.awt.Shape var12 = var5.getLeftArrow();
    org.jfree.chart.util.RectangleInsets var13 = var5.getLabelInsets();
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setRangeAxes(var14);
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var0.removeAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    double var9 = var0.getRangeCrosshairValue();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var0.axisChanged(var10);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("Range[100.0,100.0]");
    org.jfree.chart.axis.CategoryAxis[] var14 = new org.jfree.chart.axis.CategoryAxis[] { var13};
    var0.setDomainAxes(var14);
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var1.getLegendItemLabelGenerator();
//     java.awt.Paint var5 = var1.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers((-1));
//     var6.setBackgroundAlpha(0.0f);
//     boolean var11 = var1.hasListener((java.util.EventListener)var6);
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var14 = var13.getFont();
//     var1.setBaseItemLabelFont(var14);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     double var17 = var16.getFixedAutoRange();
//     java.awt.Shape var18 = var16.getUpArrow();
//     double var19 = var16.getLowerBound();
//     var16.setInverted(true);
//     double var22 = var16.getUpperMargin();
//     java.awt.Shape var23 = var16.getLeftArrow();
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 100.0d);
//     java.lang.String var27 = var26.toString();
//     var16.setRange(var26);
//     java.awt.Paint var29 = var16.getLabelPaint();
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", var14, var29);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var35 = var34.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var37 = null;
//     var34.setDomainAxisLocation(1, var37, true);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var34.addChangeListener(var40);
//     org.jfree.chart.plot.DatasetRenderingOrder var42 = var34.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.LegendItemSource[] var44 = var43.getSources();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var47 = var46.getLabelFont();
//     var43.setItemFont(var47);
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("", var47);
//     java.lang.String var50 = var49.getText();
//     java.awt.Font var51 = var49.getFont();
//     org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var54 = var52.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     double var57 = var56.getFixedAutoRange();
//     java.awt.Shape var58 = var56.getUpArrow();
//     double var59 = var56.getLowerBound();
//     java.awt.Stroke var60 = var56.getTickMarkStroke();
//     var52.setSeriesStroke(0, var60, false);
//     java.awt.Stroke var64 = var52.getSeriesStroke((-16777216));
//     java.awt.Paint var65 = var52.getBaseFillPaint();
//     org.jfree.chart.text.TextFragment var67 = new org.jfree.chart.text.TextFragment("NOID", var51, var65, 1.0f);
//     java.awt.Color var71 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     int var72 = var71.getGreen();
//     org.jfree.chart.block.BlockBorder var73 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var71);
//     java.awt.Color var74 = var71.brighter();
//     var30.addLine("Size2D[width=0.0, height=100.0]", var51, (java.awt.Paint)var71);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var52.", var1.equals(var52) == var52.equals(var1));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    var0.setInverted(true);
    double var6 = var0.getUpperMargin();
    java.awt.Shape var7 = var0.getLeftArrow();
    org.jfree.chart.util.RectangleInsets var8 = var0.getLabelInsets();
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var8.createInsetRectangle(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var13 = var11.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var11.getLegendItemLabelGenerator();
    java.awt.Paint var15 = var11.getBaseOutlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER", var10, var15);
    boolean var17 = var16.isShapeVisible();
    org.jfree.chart.util.GradientPaintTransformer var18 = var16.getFillPaintTransformer();
    boolean var19 = var16.isShapeVisible();
    boolean var20 = var16.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     java.awt.Font var2 = null;
//     java.awt.Paint var3 = null;
//     org.jfree.chart.text.TextMeasurer var6 = null;
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 1.0f, 100, var6);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var12 = var11.getLabelFont();
//     org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("", var12);
//     java.lang.Object var14 = null;
//     boolean var15 = var13.equals(var14);
//     var7.addLine(var13);
//     org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var18 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var19 = var18.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var17, var18);
//     org.jfree.chart.text.TextBlockAnchor var21 = var18.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var27 = var26.getDataset();
//     java.awt.Paint var28 = null;
//     var26.setOutlinePaint(var28);
//     org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var36 = var34.equals((java.lang.Object)(short)1);
//     java.lang.String var37 = var34.toString();
//     var26.setInsets(var34);
//     org.jfree.chart.util.RectangleInsets var43 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var45 = var43.equals((java.lang.Object)(short)1);
//     java.lang.String var46 = var43.toString();
//     var26.setInsets(var43, true);
//     org.jfree.chart.util.RectangleEdge var49 = var26.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var50 = var25.getLabelPosition(var49);
//     org.jfree.chart.text.TextAnchor var51 = var50.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var52 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var53 = var52.getAngle();
//     org.jfree.chart.text.TextAnchor var54 = var52.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var56 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "", var51, var54, Double.NaN);
//     org.jfree.chart.axis.CategoryTick var58 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)0L, var7, var21, var54, Double.NaN);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var62 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var63 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var64 = var63.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var65 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var62, var63);
//     org.jfree.chart.text.TextBlockAnchor var66 = var63.getLabelAnchor();
//     java.lang.String var67 = var66.toString();
//     java.awt.Shape var71 = var7.calculateBounds(var59, 100.0f, 0.0f, var66, 0.0f, 100.0f, 109.0d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    var0.setInverted(true);
    double var6 = var0.getUpperMargin();
    java.awt.Shape var7 = var0.getLeftArrow();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    int var6 = var5.getGreen();
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", var1, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var2 = var1.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4, true);
//     org.jfree.chart.event.PlotChangeListener var7 = null;
//     var1.addChangeListener(var7);
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     java.awt.Paint var12 = var10.getItemPaint();
//     boolean var13 = var0.equals((java.lang.Object)var10);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var15);
//     var15.validateObject();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var19 = var18.getDataset();
//     boolean var20 = var18.isOutlineVisible();
//     int var21 = var18.getBackgroundImageAlignment();
//     var15.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var18);
//     int var23 = var18.getRangeAxisCount();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setTickMarkInsideLength(1.0f);
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 100.0d);
//     org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 100.0d);
//     var25.setRange(var32);
//     float var34 = var25.getTickMarkInsideLength();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var36 = null;
//     org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var36, 100.0d);
//     java.lang.String var39 = var38.toString();
//     var35.setDefaultAutoRange(var38);
//     var35.setTickLabelsVisible(true);
//     org.jfree.chart.util.RectangleInsets var43 = var35.getTickLabelInsets();
//     boolean var44 = var35.isTickLabelsVisible();
//     boolean var45 = var35.isPositiveArrowVisible();
//     java.awt.Font var46 = var35.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var48 = var47.getDataset();
//     java.awt.Paint var49 = null;
//     var47.setOutlinePaint(var49);
//     org.jfree.chart.util.RectangleInsets var55 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var57 = var55.equals((java.lang.Object)(short)1);
//     java.lang.String var58 = var55.toString();
//     var47.setInsets(var55);
//     org.jfree.chart.ChartRenderingInfo var62 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var63 = new org.jfree.chart.plot.PlotRenderingInfo(var62);
//     java.awt.geom.Point2D var64 = null;
//     var47.zoomRangeAxes(100.0d, 1.0d, var63, var64);
//     java.awt.geom.Rectangle2D var66 = var63.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var69 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var66, "", "hi!");
//     var35.setDownArrow((java.awt.Shape)var66);
//     var0.drawRangeGridline(var14, var18, (org.jfree.chart.axis.ValueAxis)var25, var66, (-1.0d));
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    java.util.List var3 = var1.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers((-1));
    var4.setBackgroundAlpha(0.0f);
    org.jfree.chart.event.PlotChangeEvent var9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.axis.ValueAxis var10 = null;
    int var11 = var4.getRangeAxisIndex(var10);
    var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    java.lang.Number var15 = var1.getValue((java.lang.Comparable)10L, (java.lang.Comparable)true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var0.generateLabel((org.jfree.data.category.CategoryDataset)var1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    int var7 = var0.getColumnCount();
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.axis.AxisState var5 = new org.jfree.chart.axis.AxisState();
    boolean var6 = var0.equals((java.lang.Object)var5);
    var5.cursorUp(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var9 = var8.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var11 = null;
    var8.setDomainAxisLocation(1, var11, true);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var8.addChangeListener(var14);
    org.jfree.chart.plot.DatasetRenderingOrder var16 = var8.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    org.jfree.chart.LegendItemSource[] var18 = var17.getSources();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var21 = var20.getLabelFont();
    var17.setItemFont(var21);
    org.jfree.chart.util.RectangleEdge var23 = var17.getLegendItemGraphicEdge();
    java.awt.Font var25 = null;
    java.awt.Paint var26 = null;
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, var26, 1.0f, 100, var29);
    org.jfree.chart.util.HorizontalAlignment var31 = var30.getLineAlignment();
    java.lang.String var32 = var31.toString();
    var17.setHorizontalAlignment(var31);
    var17.setMargin(0.0d, 1.0d, Double.NaN, 100.0d);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    org.jfree.chart.util.Size2D var43 = var17.arrange(var39, var42);
    var43.setHeight(1.0d);
    org.jfree.chart.util.Size2D var46 = var6.calculateConstrainedSize(var43);
    org.jfree.chart.block.LengthConstraintType var47 = var6.getHeightConstraintType();
    org.jfree.chart.block.LengthConstraintType var48 = var6.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var32.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     java.awt.Font var2 = null;
//     java.awt.Paint var3 = null;
//     org.jfree.chart.text.TextMeasurer var6 = null;
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 1.0f, 100, var6);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var12 = var11.getLabelFont();
//     org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("", var12);
//     java.lang.Object var14 = null;
//     boolean var15 = var13.equals(var14);
//     var7.addLine(var13);
//     org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var18 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var19 = var18.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var17, var18);
//     org.jfree.chart.text.TextBlockAnchor var21 = var18.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var27 = var26.getDataset();
//     java.awt.Paint var28 = null;
//     var26.setOutlinePaint(var28);
//     org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var36 = var34.equals((java.lang.Object)(short)1);
//     java.lang.String var37 = var34.toString();
//     var26.setInsets(var34);
//     org.jfree.chart.util.RectangleInsets var43 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var45 = var43.equals((java.lang.Object)(short)1);
//     java.lang.String var46 = var43.toString();
//     var26.setInsets(var43, true);
//     org.jfree.chart.util.RectangleEdge var49 = var26.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var50 = var25.getLabelPosition(var49);
//     org.jfree.chart.text.TextAnchor var51 = var50.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var52 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var53 = var52.getAngle();
//     org.jfree.chart.text.TextAnchor var54 = var52.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var56 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)0, "", var51, var54, Double.NaN);
//     org.jfree.chart.axis.CategoryTick var58 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)0L, var7, var21, var54, Double.NaN);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var62 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var63 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var64 = var63.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var65 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var62, var63);
//     org.jfree.chart.text.TextBlockAnchor var66 = var63.getLabelAnchor();
//     java.lang.Object var67 = null;
//     boolean var68 = var66.equals(var67);
//     java.awt.Shape var72 = var7.calculateBounds(var59, 1.0f, 0.95f, var66, 0.0f, 0.0f, 111.0d);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    boolean var2 = var0.isOutlineVisible();
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    var0.setDataset(var5);
    var0.setAnchorValue(111.0d, true);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var11 = var10.getDataset();
    java.awt.Paint var12 = null;
    var10.setOutlinePaint(var12);
    var10.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.PlotOrientation var16 = var10.getOrientation();
    java.lang.Object var17 = null;
    boolean var18 = var16.equals(var17);
    var0.setOrientation(var16);
    org.jfree.chart.ui.BasicProjectInfo var20 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var21 = var20.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var22 = var20.getOptionalLibraries();
    boolean var23 = var16.equals((java.lang.Object)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setNoDataMessage("");
    var6.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.AxisSpace var11 = var6.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var13 = var12.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var15 = null;
    var12.setDomainAxisLocation(1, var15, true);
    org.jfree.chart.event.PlotChangeListener var18 = null;
    var12.addChangeListener(var18);
    org.jfree.chart.plot.DatasetRenderingOrder var20 = var12.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12);
    var12.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAnchor var23 = var12.getDomainGridlinePosition();
    var12.clearAnnotations();
    java.awt.Stroke var25 = var12.getDomainGridlineStroke();
    var6.setRangeGridlineStroke(var25);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var28 = var27.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var30 = null;
    var27.setDomainAxisLocation(1, var30, true);
    org.jfree.chart.event.PlotChangeListener var33 = null;
    var27.addChangeListener(var33);
    org.jfree.chart.plot.DatasetRenderingOrder var35 = var27.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
    org.jfree.chart.util.RectangleEdge var37 = var27.getDomainAxisEdge();
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var40 = var38.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var41 = var38.getGradientPaintTransformer();
    boolean var42 = var38.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = null;
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var46 = null;
    org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 100.0d);
    java.lang.String var49 = var48.toString();
    var45.setDefaultAutoRange(var48);
    double var51 = var45.getUpperMargin();
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 100.0d);
    java.lang.String var55 = var54.toString();
    boolean var57 = var54.equals((java.lang.Object)(byte)100);
    boolean var59 = var54.contains(1.0d);
    var45.setRangeWithMargins(var54, false, false);
    java.awt.geom.Rectangle2D var63 = null;
    var38.drawRangeGridline(var43, var44, (org.jfree.chart.axis.ValueAxis)var45, var63, 1.0d);
    org.jfree.chart.renderer.category.BarRenderer var66 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var68 = var66.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var69 = var66.getGradientPaintTransformer();
    java.awt.Stroke var70 = var66.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis();
    double var73 = var72.getFixedAutoRange();
    java.awt.Shape var74 = var72.getUpArrow();
    java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.rotateShape(var77, 100.0d, 100.0f, 10.0f);
    boolean var82 = org.jfree.chart.util.ShapeUtilities.equal(var74, var77);
    var66.setSeriesShape(15, var77);
    org.jfree.chart.labels.ItemLabelPosition var86 = var66.getNegativeItemLabelPosition((-16777216), 0);
    var38.setNegativeItemLabelPositionFallback(var86);
    java.awt.Paint var90 = var38.getItemPaint(255, (-131));
    boolean var91 = var37.equals((java.lang.Object)var90);
    org.jfree.chart.LegendItem var92 = new org.jfree.chart.LegendItem("", "Size2D[width=0.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "VerticalAlignment.CENTER", var5, var25, var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "Range[100.0,100.0]"+ "'", var49.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "Range[100.0,100.0]"+ "'", var55.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    double var6 = var5.getFixedAutoRange();
    java.awt.Shape var7 = var5.getUpArrow();
    double var8 = var5.getLowerBound();
    java.awt.Stroke var9 = var5.getTickMarkStroke();
    var1.setSeriesStroke(0, var9, false);
    java.awt.Stroke var13 = var1.getSeriesStroke((-16777216));
    java.awt.Paint var14 = var1.getBaseFillPaint();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = var1.getLegendItemLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var17 = var16.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var19 = null;
    var16.setDomainAxisLocation(1, var19, true);
    org.jfree.chart.event.PlotChangeListener var22 = null;
    var16.addChangeListener(var22);
    org.jfree.chart.plot.DatasetRenderingOrder var24 = var16.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    java.awt.Paint var26 = var25.getBackgroundPaint();
    java.awt.Paint var27 = var25.getItemPaint();
    var1.setBaseOutlinePaint(var27);
    var0.setBaseItemLabelPaint(var27, false);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var0.setBaseURLGenerator(var31, true);
    java.awt.Shape var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var34, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.util.Iterator var1 = var0.iterator();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var4 = var2.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     double var9 = var6.getLowerBound();
//     java.awt.Stroke var10 = var6.getTickMarkStroke();
//     var2.setSeriesStroke(0, var10, false);
//     java.awt.Stroke var14 = var2.getSeriesStroke((-16777216));
//     org.jfree.chart.LegendItemCollection var15 = var2.getLegendItems();
//     var0.addAll(var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getShapeLocation();
//     java.awt.Paint var36 = var34.getOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var40 = var39.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var42 = null;
//     var39.setDomainAxisLocation(1, var42, true);
//     org.jfree.chart.event.PlotChangeListener var45 = null;
//     var39.addChangeListener(var45);
//     org.jfree.chart.plot.DatasetRenderingOrder var47 = var39.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.LegendItemSource[] var49 = var48.getSources();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var52 = var51.getLabelFont();
//     var48.setItemFont(var52);
//     org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var52);
//     java.lang.String var55 = var54.getText();
//     java.awt.Font var56 = var54.getFont();
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var59 = var57.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis();
//     double var62 = var61.getFixedAutoRange();
//     java.awt.Shape var63 = var61.getUpArrow();
//     double var64 = var61.getLowerBound();
//     java.awt.Stroke var65 = var61.getTickMarkStroke();
//     var57.setSeriesStroke(0, var65, false);
//     java.awt.Stroke var69 = var57.getSeriesStroke((-16777216));
//     java.awt.Paint var70 = var57.getBaseFillPaint();
//     org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("NOID", var56, var70, 1.0f);
//     var34.setOutlinePaint(var70);
//     
//     // Checks the contract:  equals-hashcode on var30 and var39
//     assertTrue("Contract failed: equals-hashcode on var30 and var39", var30.equals(var39) ? var30.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var30
//     assertTrue("Contract failed: equals-hashcode on var39 and var30", var39.equals(var30) ? var39.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     double var4 = var3.getFixedAutoRange();
//     java.awt.Shape var5 = var3.getUpArrow();
//     var1.setShape(0, var5);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 0.0d, 2.0f, 0.0f);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     java.awt.Shape var2 = var0.getUpArrow();
//     org.jfree.chart.JFreeChart var3 = null;
//     org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
//     var0.setInverted(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var11 = var10.getDataset();
//     java.awt.Paint var12 = null;
//     var10.setOutlinePaint(var12);
//     org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var20 = var18.equals((java.lang.Object)(short)1);
//     java.lang.String var21 = var18.toString();
//     var10.setInsets(var18);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Point2D var27 = null;
//     var10.zoomRangeAxes(100.0d, 1.0d, var26, var27);
//     java.awt.geom.Rectangle2D var29 = var26.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var32 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var29, "", "hi!");
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     var33.setAutoRange(false);
//     var33.setVisible(false);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var40 = var39.getDataset();
//     java.awt.Paint var41 = null;
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.util.RectangleInsets var47 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var49 = var47.equals((java.lang.Object)(short)1);
//     java.lang.String var50 = var47.toString();
//     var39.setInsets(var47);
//     org.jfree.chart.ChartRenderingInfo var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var55 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
//     java.awt.geom.Point2D var56 = null;
//     var39.zoomRangeAxes(100.0d, 1.0d, var55, var56);
//     java.awt.geom.Rectangle2D var58 = var55.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var61 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var58, "", "hi!");
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var63 = var62.getDataset();
//     java.awt.Paint var64 = null;
//     var62.setOutlinePaint(var64);
//     var62.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.PlotOrientation var68 = var62.getOrientation();
//     var62.setBackgroundAlpha(1.0f);
//     org.jfree.chart.util.RectangleEdge var72 = var62.getDomainAxisEdge(0);
//     double var73 = var33.valueToJava2D(10.0d, var58, var72);
//     double var74 = var0.java2DToValue(0.0d, var29, var72);
//     
//     // Checks the contract:  equals-hashcode on var10 and var39
//     assertTrue("Contract failed: equals-hashcode on var10 and var39", var10.equals(var39) ? var10.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var10
//     assertTrue("Contract failed: equals-hashcode on var39 and var10", var39.equals(var10) ? var39.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var55
//     assertTrue("Contract failed: equals-hashcode on var26 and var55", var26.equals(var55) ? var26.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var26
//     assertTrue("Contract failed: equals-hashcode on var55 and var26", var55.equals(var26) ? var55.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var61
//     assertTrue("Contract failed: equals-hashcode on var32 and var61", var32.equals(var61) ? var32.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var32
//     assertTrue("Contract failed: equals-hashcode on var61 and var32", var61.equals(var32) ? var61.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 1.0f, 100, var5);
    org.jfree.chart.util.HorizontalAlignment var7 = var6.getLineAlignment();
    java.lang.String var8 = var7.toString();
    java.lang.String var9 = var7.toString();
    java.lang.String var10 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var8.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var9.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var10.equals("HorizontalAlignment.CENTER"));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    java.awt.Stroke var4 = var0.getBaseStroke();
    org.jfree.chart.util.GradientPaintTransformer var5 = var0.getGradientPaintTransformer();
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    boolean var2 = var0.isOutlineVisible();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var6 = var4.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var4.getLegendItemLabelGenerator();
    java.awt.Paint var8 = var4.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers((-1));
    var9.setBackgroundAlpha(0.0f);
    boolean var14 = var4.hasListener((java.util.EventListener)var9);
    org.jfree.chart.event.MarkerChangeEvent var15 = null;
    var9.markerChanged(var15);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.clearDomainMarkers((-1));
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var18);
    var9.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
    java.awt.image.BufferedImage var25 = var21.createBufferedImage(255, 10);
    var0.setBackgroundImage((java.awt.Image)var25);
    org.jfree.chart.axis.AxisLocation var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-16777216), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("DatasetRenderingOrder.REVERSE");
    var1.setURLText("Range[100.0,100.0]");

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var3 = var2.getDataset();
//     boolean var4 = var2.isOutlineVisible();
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var2.addChangeListener(var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var8 = var7.getDataset();
//     java.awt.Paint var9 = null;
//     var7.setOutlinePaint(var9);
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var17 = var15.equals((java.lang.Object)(short)1);
//     java.lang.String var18 = var15.toString();
//     var7.setInsets(var15);
//     var2.setInsets(var15);
//     var0.setTickLabelInsets(var15);
//     double var23 = var15.trimHeight(Double.NaN);
//     double var25 = var15.trimWidth(10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"+ "'", var18.equals("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 8.0d);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getShapeLocation();
//     java.awt.Paint var36 = var34.getOutlinePaint();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var39 = null;
//     org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, 100.0d);
//     java.lang.String var42 = var41.toString();
//     var38.setDefaultAutoRange(var41);
//     var38.setTickLabelsVisible(true);
//     org.jfree.chart.util.RectangleInsets var46 = var38.getTickLabelInsets();
//     boolean var47 = var38.isTickLabelsVisible();
//     boolean var48 = var38.isPositiveArrowVisible();
//     java.awt.Font var49 = var38.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var51 = var50.getDataset();
//     java.awt.Paint var52 = null;
//     var50.setOutlinePaint(var52);
//     org.jfree.chart.util.RectangleInsets var58 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var60 = var58.equals((java.lang.Object)(short)1);
//     java.lang.String var61 = var58.toString();
//     var50.setInsets(var58);
//     org.jfree.chart.ChartRenderingInfo var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = new org.jfree.chart.plot.PlotRenderingInfo(var65);
//     java.awt.geom.Point2D var67 = null;
//     var50.zoomRangeAxes(100.0d, 1.0d, var66, var67);
//     java.awt.geom.Rectangle2D var69 = var66.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var72 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var69, "", "hi!");
//     var38.setDownArrow((java.awt.Shape)var69);
//     var34.draw(var37, var69);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var2 = var1.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
    org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var6 = var5.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var4, var5);
    org.jfree.chart.text.TextBlockAnchor var8 = var5.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var3, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Category Plot", var1);
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     boolean var2 = var0.isOutlineVisible();
//     java.awt.Paint var3 = var0.getRangeGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomDomainAxes(0.0d, 10.0d, var6, var7);
//     java.awt.Paint var9 = var0.getDomainGridlinePaint();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var12 = var11.getDataset();
//     java.awt.Paint var13 = null;
//     var11.setOutlinePaint(var13);
//     org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var21 = var19.equals((java.lang.Object)(short)1);
//     java.lang.String var22 = var19.toString();
//     var11.setInsets(var19);
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Point2D var28 = null;
//     var11.zoomRangeAxes(100.0d, 1.0d, var27, var28);
//     java.awt.geom.Rectangle2D var30 = var27.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var33 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var30, "", "hi!");
//     var0.drawOutline(var10, var30);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var3 = var1.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var4 = var1.getGradientPaintTransformer();
//     var1.setAutoPopulateSeriesShape(false);
//     java.awt.Paint var8 = var1.lookupSeriesOutlinePaint(100);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     var14.setBackgroundAlpha(0.0f);
//     boolean var19 = var9.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var14.markerChanged(var20);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var23);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     boolean var28 = var26.isBorderVisible();
//     java.awt.Stroke var29 = var26.getBorderStroke();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var8, var29);
//     java.awt.Stroke var31 = var30.getStroke();
//     java.lang.Object var32 = var30.clone();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var34 = var33.getDataset();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var33.zoomDomainAxes((-1.0d), var36, var37);
//     java.awt.Paint var39 = var33.getNoDataMessagePaint();
//     boolean var40 = var30.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var23 and var33
//     assertTrue("Contract failed: equals-hashcode on var23 and var33", var23.equals(var33) ? var23.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var23
//     assertTrue("Contract failed: equals-hashcode on var33 and var23", var33.equals(var23) ? var33.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleEdge var10 = var0.getDomainAxisEdge();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var13 = var11.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var14 = var11.getGradientPaintTransformer();
    boolean var15 = var11.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = null;
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 100.0d);
    java.lang.String var22 = var21.toString();
    var18.setDefaultAutoRange(var21);
    double var24 = var18.getUpperMargin();
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 100.0d);
    java.lang.String var28 = var27.toString();
    boolean var30 = var27.equals((java.lang.Object)(byte)100);
    boolean var32 = var27.contains(1.0d);
    var18.setRangeWithMargins(var27, false, false);
    java.awt.geom.Rectangle2D var36 = null;
    var11.drawRangeGridline(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var36, 1.0d);
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var41 = var39.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var42 = var39.getGradientPaintTransformer();
    java.awt.Stroke var43 = var39.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    double var46 = var45.getFixedAutoRange();
    java.awt.Shape var47 = var45.getUpArrow();
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, 100.0d, 100.0f, 10.0f);
    boolean var55 = org.jfree.chart.util.ShapeUtilities.equal(var47, var50);
    var39.setSeriesShape(15, var50);
    org.jfree.chart.labels.ItemLabelPosition var59 = var39.getNegativeItemLabelPosition((-16777216), 0);
    var11.setNegativeItemLabelPositionFallback(var59);
    java.awt.Paint var63 = var11.getItemPaint(255, (-131));
    boolean var64 = var10.equals((java.lang.Object)var63);
    boolean var65 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Range[100.0,100.0]"+ "'", var22.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Range[100.0,100.0]"+ "'", var28.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     var0.setAutoPopulateSeriesShape(false);
//     java.awt.Paint var7 = var0.lookupSeriesOutlinePaint(100);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.setNoDataMessage("");
//     var9.setForegroundAlpha(100.0f);
//     boolean var14 = var9.getDrawSharedDomainAxis();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var16 = var15.getDataset();
//     java.awt.Paint var17 = null;
//     var15.setOutlinePaint(var17);
//     org.jfree.chart.util.RectangleInsets var23 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var25 = var23.equals((java.lang.Object)(short)1);
//     java.lang.String var26 = var23.toString();
//     var15.setInsets(var23);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Point2D var32 = null;
//     var15.zoomRangeAxes(100.0d, 1.0d, var31, var32);
//     java.awt.geom.Rectangle2D var34 = var31.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var37 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var34, "", "hi!");
//     var0.drawOutline(var8, var9, var34);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var6 = var0.getItemPaint(0, 100);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var9 = var7.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var10 = var7.getGradientPaintTransformer();
    var0.setGradientPaintTransformer(var10);
    boolean var12 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Paint var14 = var0.lookupSeriesPaint((-131));
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    double var2 = var1.getMax();
    org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
    java.lang.Object var4 = var3.clone();
    java.util.List var5 = var3.getKeys();
    var1.setTicks(var5);
    var1.cursorDown(111.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.LegendItem var7 = var0.getLegendItem(10, (-1));
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getToolTipGenerator((-16777216), 10);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = var0.getSeriesToolTipGenerator(0);
    double var13 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", var1);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    java.awt.Stroke var4 = var0.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    double var7 = var6.getFixedAutoRange();
    java.awt.Shape var8 = var6.getUpArrow();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
    var0.setSeriesShape(15, var11);
    org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    double var22 = var21.getFixedAutoRange();
    java.awt.Shape var23 = var21.getUpArrow();
    double var24 = var21.getLowerBound();
    var21.setInverted(true);
    double var27 = var21.getUpperMargin();
    java.awt.Shape var28 = var21.getLeftArrow();
    boolean var29 = var20.equals((java.lang.Object)var28);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
    boolean var32 = var30.isOutlineVisible();
    java.awt.Paint var33 = var30.getRangeGridlinePaint();
    org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
    org.jfree.chart.util.Size2D var39 = var34.arrange(var35, var38);
    java.awt.Stroke var40 = var34.getLineStroke();
    org.jfree.chart.util.GradientPaintTransformer var41 = var34.getFillPaintTransformer();
    boolean var42 = var34.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator(10);
    var0.setBaseCreateEntities(false);
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var0.notifyListeners(var5);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getItemLabelGenerator(15, 0);
    java.awt.Paint var12 = var0.getItemOutlinePaint(100, (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var3 = var1.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var4 = var1.getGradientPaintTransformer();
//     var1.setAutoPopulateSeriesShape(false);
//     java.awt.Paint var8 = var1.lookupSeriesOutlinePaint(100);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var11 = var9.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = var9.getLegendItemLabelGenerator();
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers((-1));
//     var14.setBackgroundAlpha(0.0f);
//     boolean var19 = var9.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var14.markerChanged(var20);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var23);
//     var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     boolean var28 = var26.isBorderVisible();
//     java.awt.Stroke var29 = var26.getBorderStroke();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, var8, var29);
//     java.awt.Stroke var31 = var30.getStroke();
//     org.jfree.chart.util.LengthAdjustmentType var32 = var30.getLabelOffsetType();
//     java.awt.Font var33 = var30.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var35 = var34.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var37 = null;
//     var34.setDomainAxisLocation(1, var37, true);
//     org.jfree.chart.event.PlotChangeListener var40 = null;
//     var34.addChangeListener(var40);
//     org.jfree.chart.plot.DatasetRenderingOrder var42 = var34.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     var43.setWidth(10.0d);
//     java.awt.Paint var47 = var43.getItemPaint();
//     var30.setLabelPaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var23 and var34
//     assertTrue("Contract failed: equals-hashcode on var23 and var34", var23.equals(var34) ? var23.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var23
//     assertTrue("Contract failed: equals-hashcode on var34 and var23", var34.equals(var23) ? var34.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var38 = var36.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = var36.getLegendItemLabelGenerator();
//     java.awt.Paint var40 = var36.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.clearDomainMarkers((-1));
//     var41.setBackgroundAlpha(0.0f);
//     boolean var46 = var36.hasListener((java.util.EventListener)var41);
//     org.jfree.chart.event.MarkerChangeEvent var47 = null;
//     var41.markerChanged(var47);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var50);
//     var41.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var53);
//     boolean var55 = var53.isBorderVisible();
//     org.jfree.chart.plot.CategoryPlot var56 = var53.getCategoryPlot();
//     org.jfree.chart.util.RectangleInsets var61 = new org.jfree.chart.util.RectangleInsets(0.05d, 0.0d, (-1.0d), (-1.0d));
//     double var62 = var61.getBottom();
//     var53.setPadding(var61);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var65 = var64.getDataset();
//     java.awt.Paint var66 = null;
//     var64.setOutlinePaint(var66);
//     org.jfree.chart.util.RectangleInsets var72 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var74 = var72.equals((java.lang.Object)(short)1);
//     java.lang.String var75 = var72.toString();
//     var64.setInsets(var72);
//     org.jfree.chart.ChartRenderingInfo var79 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var80 = new org.jfree.chart.plot.PlotRenderingInfo(var79);
//     java.awt.geom.Point2D var81 = null;
//     var64.zoomRangeAxes(100.0d, 1.0d, var80, var81);
//     java.awt.geom.Rectangle2D var83 = var80.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var86 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var83, "", "hi!");
//     java.awt.geom.Rectangle2D var87 = var61.createInsetRectangle(var83);
//     var34.draw(var35, var83);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    boolean var4 = var0.getExpandToFitSpace();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 100.0d);
    java.lang.String var10 = var9.toString();
    var6.setDefaultAutoRange(var9);
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(var9, Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var14 = var0.arrange(var5, var13);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Range[100.0,100.0]"+ "'", var10.equals("Range[100.0,100.0]"));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    var0.validateObject();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var4 = var3.getDataset();
    boolean var5 = var3.isOutlineVisible();
    int var6 = var3.getBackgroundImageAlignment();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    int var8 = var3.getRangeAxisCount();
    var3.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var15 = var14.getLabelFont();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var18 = var17.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var20 = null;
    var17.setDomainAxisLocation(1, var20, true);
    org.jfree.chart.event.PlotChangeListener var23 = null;
    var17.addChangeListener(var23);
    org.jfree.chart.plot.DatasetRenderingOrder var25 = var17.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
    org.jfree.chart.LegendItemSource[] var27 = var26.getSources();
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Font var30 = var29.getLabelFont();
    var26.setItemFont(var30);
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var30);
    var14.setTickLabelFont(var30);
    var12.setTickLabelFont(var30);
    var12.setCategoryMargin(109.0d);
    double var37 = var12.getUpperMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setDomainAxis((-16777216), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.05d);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var22 = var20.equals((java.lang.Object)(short)1);
//     var13.setAxisOffset(var20);
//     var9.setLegendItemGraphicPadding(var20);
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var31 = var29.equals((java.lang.Object)(short)1);
//     double var32 = var29.getBottom();
//     var9.setItemLabelPadding(var29);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearDomainMarkers((-1));
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("RectangleEdge.BOTTOM", (org.jfree.chart.plot.Plot)var35);
//     var38.setNotify(true);
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 100.0d);
//     java.lang.String var15 = var14.toString();
//     var11.setDefaultAutoRange(var14);
//     double var17 = var11.getUpperMargin();
//     java.awt.Paint var18 = var11.getAxisLinePaint();
//     var9.setBackgroundPaint(var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var21 = var20.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setDomainAxisLocation(1, var23, true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var20.addChangeListener(var26);
//     org.jfree.chart.plot.DatasetRenderingOrder var28 = var20.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     org.jfree.chart.LegendItemSource[] var30 = var29.getSources();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var33 = var32.getLabelFont();
//     var29.setItemFont(var33);
//     org.jfree.chart.util.RectangleEdge var35 = var29.getLegendItemGraphicEdge();
//     java.awt.Font var37 = null;
//     java.awt.Paint var38 = null;
//     org.jfree.chart.text.TextMeasurer var41 = null;
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, var38, 1.0f, 100, var41);
//     org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
//     java.lang.String var44 = var43.toString();
//     var29.setHorizontalAlignment(var43);
//     var9.setHorizontalAlignment(var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRange(false);
    var0.setAxisLineVisible(true);
    var0.setAxisLineVisible(true);
    java.lang.String var7 = var0.getLabelURL();
    var0.setTickMarkOutsideLength(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     java.awt.Stroke var4 = var0.getBaseStroke();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     double var7 = var6.getFixedAutoRange();
//     java.awt.Shape var8 = var6.getUpArrow();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 100.0f, 10.0f);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var11);
//     var0.setSeriesShape(15, var11);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getNegativeItemLabelPosition((-16777216), 0);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     double var22 = var21.getFixedAutoRange();
//     java.awt.Shape var23 = var21.getUpArrow();
//     double var24 = var21.getLowerBound();
//     var21.setInverted(true);
//     double var27 = var21.getUpperMargin();
//     java.awt.Shape var28 = var21.getLeftArrow();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var31 = var30.getDataset();
//     boolean var32 = var30.isOutlineVisible();
//     java.awt.Paint var33 = var30.getRangeGridlinePaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic(var28, var33);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, 0.05d);
//     org.jfree.chart.util.Size2D var39 = var34.arrange(var35, var38);
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var42 = var40.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var43 = var40.getGradientPaintTransformer();
//     java.awt.Stroke var44 = var40.getBaseStroke();
//     var34.setLineStroke(var44);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var0.", var40.equals(var0) == var0.equals(var40));
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var0.getBaseToolTipGenerator();
    java.awt.Paint var16 = var0.getSeriesPaint(15);
    java.awt.Paint var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var17, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "poly", "RangeType.FULL", "TextBlockAnchor.BOTTOM_CENTER");

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "Range[100.0,100.0]", var3);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers((-1));
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.event.PlotChangeEvent var5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var6 = null;
    int var7 = var0.getRangeAxisIndex(var6);
    org.jfree.chart.axis.AxisLocation var9 = var0.getDomainAxisLocation(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
//     org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var4);
//     org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var9 = var8.getDataset();
//     java.awt.Paint var10 = null;
//     var8.setOutlinePaint(var10);
//     org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var18 = var16.equals((java.lang.Object)(short)1);
//     java.lang.String var19 = var16.toString();
//     var8.setInsets(var16);
//     org.jfree.chart.util.RectangleInsets var25 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var27 = var25.equals((java.lang.Object)(short)1);
//     java.lang.String var28 = var25.toString();
//     var8.setInsets(var25, true);
//     org.jfree.chart.util.RectangleEdge var31 = var8.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var32 = var7.getLabelPosition(var31);
//     boolean var33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var31);
//     org.jfree.chart.axis.CategoryLabelPosition var34 = var5.getLabelPosition(var31);
//     org.jfree.chart.axis.CategoryLabelPositions var36 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var38 = var37.getDataset();
//     java.awt.Paint var39 = null;
//     var37.setOutlinePaint(var39);
//     org.jfree.chart.util.RectangleInsets var45 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var47 = var45.equals((java.lang.Object)(short)1);
//     java.lang.String var48 = var45.toString();
//     var37.setInsets(var45);
//     org.jfree.chart.util.RectangleInsets var54 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var56 = var54.equals((java.lang.Object)(short)1);
//     java.lang.String var57 = var54.toString();
//     var37.setInsets(var54, true);
//     org.jfree.chart.util.RectangleEdge var60 = var37.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var61 = var36.getLabelPosition(var60);
//     org.jfree.chart.text.TextAnchor var62 = var61.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var63 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var5, var61);
//     
//     // Checks the contract:  equals-hashcode on var8 and var37
//     assertTrue("Contract failed: equals-hashcode on var8 and var37", var8.equals(var37) ? var8.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var8
//     assertTrue("Contract failed: equals-hashcode on var37 and var8", var37.equals(var8) ? var37.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, (-1.0f), 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.CategoryAxis var3 = var0.getDomainAxis();
    double var4 = var0.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     double var3 = var2.getFixedAutoRange();
//     java.awt.Shape var4 = var2.getUpArrow();
//     var0.setShape(0, var4);
//     org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var4, "hi!");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var8 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var9 = null;
//     java.lang.String var10 = var7.getImageMapAreaTag(var8, var9);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers((-1));
//     var5.setBackgroundAlpha(0.0f);
//     boolean var10 = var0.hasListener((java.util.EventListener)var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = var0.getBaseToolTipGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var0.getNegativeItemLabelPositionFallback();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var18 = var17.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var17.setDomainAxisLocation(1, var20, true);
//     org.jfree.chart.event.PlotChangeListener var23 = null;
//     var17.addChangeListener(var23);
//     org.jfree.chart.plot.DatasetRenderingOrder var25 = var17.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers((-1));
//     org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var35 = var33.equals((java.lang.Object)(short)1);
//     var26.setAxisOffset(var33);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var38 = var37.getDataset();
//     java.awt.Paint var39 = null;
//     var37.setOutlinePaint(var39);
//     org.jfree.chart.util.RectangleInsets var45 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var47 = var45.equals((java.lang.Object)(short)1);
//     java.lang.String var48 = var45.toString();
//     var37.setInsets(var45);
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     java.awt.geom.Point2D var54 = null;
//     var37.zoomRangeAxes(100.0d, 1.0d, var53, var54);
//     java.awt.geom.Rectangle2D var56 = var53.getDataArea();
//     java.awt.geom.Rectangle2D var59 = var33.createInsetRectangle(var56, true, false);
//     var0.drawOutline(var16, var17, var59);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.5f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 0);
//     java.lang.Number var5 = var0.getStdDevValue((java.lang.Comparable)"6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", (java.lang.Comparable)"HorizontalAlignment.CENTER");
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 109.0d);
//     double var9 = var0.getRangeLowerBound(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRange(false);
    var0.setAxisLineVisible(true);
    var0.setAxisLineVisible(true);
    java.lang.String var7 = var0.getLabelURL();
    boolean var8 = var0.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var2 = var1.getDataset();
//     var1.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var1.getRangeMarkers(var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var8 = var7.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var10 = null;
//     var7.setDomainAxisLocation(1, var10, true);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var7.addChangeListener(var13);
//     org.jfree.chart.plot.DatasetRenderingOrder var15 = var7.getDatasetRenderingOrder();
//     double var16 = var7.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var7.axisChanged(var17);
//     org.jfree.chart.util.RectangleEdge var19 = var7.getRangeAxisEdge();
//     java.awt.Paint var20 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.util.SortOrder var21 = var7.getColumnRenderingOrder();
//     var1.setColumnRenderingOrder(var21);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("poly", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
//     int var28 = var27.getGreen();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var31 = null;
//     org.jfree.chart.util.ObjectList var32 = new org.jfree.chart.util.ObjectList();
//     java.lang.Object var34 = var32.get(100);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var36 = var35.getRowRenderingOrder();
//     org.jfree.data.general.DatasetGroup var37 = var35.getDatasetGroup();
//     int var38 = var32.indexOf((java.lang.Object)var35);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var40 = var39.getRowRenderingOrder();
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var39.getDomainMarkers(var41);
//     java.awt.Stroke var43 = var39.getOutlineStroke();
//     var35.setDomainGridlineStroke(var43);
//     java.awt.Stroke[] var45 = new java.awt.Stroke[] { var43};
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     double var47 = var46.getFixedAutoRange();
//     java.awt.Shape var48 = var46.getUpArrow();
//     double var49 = var46.getLowerBound();
//     java.awt.Stroke var50 = var46.getTickMarkStroke();
//     java.awt.Stroke[] var51 = new java.awt.Stroke[] { var50};
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var53.setFixedDimension(0.0d);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     double var57 = var56.getFixedAutoRange();
//     java.awt.Shape var58 = var56.getUpArrow();
//     org.jfree.chart.entity.AxisLabelEntity var61 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var53, var58, "RectangleAnchor.CENTER", "");
//     java.awt.Shape[] var62 = new java.awt.Shape[] { var58};
//     org.jfree.chart.plot.DefaultDrawingSupplier var63 = new org.jfree.chart.plot.DefaultDrawingSupplier(var30, var31, var45, var51, var62);
//     java.awt.Paint var64 = var63.getNextFillPaint();
//     var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var63);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var7
//     assertTrue("Contract failed: equals-hashcode on var39 and var7", var39.equals(var7) ? var39.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-16777216));
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     java.util.List var6 = var0.getRowKeys();
//     org.jfree.data.KeyToGroupMap var7 = null;
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var7);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var2 = var1.getDataset();
    var1.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var1.getRangeMarkers(var5);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var8 = var7.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var7.setDomainAxisLocation(1, var10, true);
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var7.addChangeListener(var13);
    org.jfree.chart.plot.DatasetRenderingOrder var15 = var7.getDatasetRenderingOrder();
    double var16 = var7.getRangeCrosshairValue();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var7.axisChanged(var17);
    org.jfree.chart.util.RectangleEdge var19 = var7.getRangeAxisEdge();
    java.awt.Paint var20 = var7.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var21 = var7.getColumnRenderingOrder();
    var1.setColumnRenderingOrder(var21);
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("poly", (org.jfree.chart.plot.Plot)var1);
    java.util.List var24 = var23.getSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)0.05d, (java.lang.Number)10);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    int var4 = var3.getGreen();
    int var5 = var3.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 125);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 10.0f, 0.95f);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    int var10 = var3.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 125);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("DatasetRenderingOrder.REVERSE", var1, var2, var3);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     double var1 = var0.getLowerClip();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var4 = var2.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
//     java.awt.Paint var6 = var2.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.clearDomainMarkers((-1));
//     var7.setBackgroundAlpha(0.0f);
//     boolean var12 = var2.hasListener((java.util.EventListener)var7);
//     org.jfree.chart.labels.CategoryToolTipGenerator var15 = var2.getToolTipGenerator(10, 15);
//     org.jfree.chart.labels.CategoryToolTipGenerator var16 = var2.getBaseToolTipGenerator();
//     org.jfree.chart.labels.CategoryToolTipGenerator var18 = var2.getSeriesToolTipGenerator(0);
//     var2.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Stroke var22 = var2.lookupSeriesOutlineStroke((-16777216));
//     var0.setErrorIndicatorStroke(var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var26 = var25.getDataset();
//     java.awt.Paint var27 = null;
//     var25.setOutlinePaint(var27);
//     org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var35 = var33.equals((java.lang.Object)(short)1);
//     java.lang.String var36 = var33.toString();
//     var25.setInsets(var33);
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Point2D var42 = null;
//     var25.zoomRangeAxes(100.0d, 1.0d, var41, var42);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var44 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var41);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var46 = var45.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var45.setDomainAxisLocation(1, var48, true);
//     org.jfree.chart.event.PlotChangeListener var51 = null;
//     var45.addChangeListener(var51);
//     org.jfree.chart.plot.DatasetRenderingOrder var53 = var45.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     org.jfree.chart.LegendItemSource[] var55 = var54.getSources();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var58 = var57.getLabelFont();
//     var54.setItemFont(var58);
//     org.jfree.chart.util.RectangleEdge var60 = var54.getLegendItemGraphicEdge();
//     org.jfree.chart.util.HorizontalAlignment var61 = var54.getHorizontalAlignment();
//     java.awt.geom.Rectangle2D var62 = var54.getBounds();
//     org.jfree.chart.plot.CategoryPlot var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
//     double var65 = var64.getUpperMargin();
//     java.awt.Font var67 = var64.getTickLabelFont((java.lang.Comparable)"HorizontalAlignment.CENTER");
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     double var69 = var68.getFixedAutoRange();
//     java.awt.Shape var70 = var68.getUpArrow();
//     double var71 = var68.getLowerBound();
//     java.awt.Stroke var72 = var68.getTickMarkStroke();
//     var68.setTickLabelsVisible(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var75 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var76 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var75);
//     var75.validateObject();
//     double var79 = var75.getRangeUpperBound(false);
//     org.jfree.data.general.PieDataset var81 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var75, 0);
//     java.util.List var82 = var75.getRowKeys();
//     var0.drawItem(var24, var44, var62, var63, var64, (org.jfree.chart.axis.ValueAxis)var68, (org.jfree.data.category.CategoryDataset)var75, 4, 0, 15);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3, true);
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var0.addChangeListener(var6);
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleEdge var10 = var0.getDomainAxisEdge();
    org.jfree.chart.axis.AxisSpace var11 = null;
    var0.setFixedDomainAxisSpace(var11);
    var0.clearRangeMarkers();
    var0.setWeight(1);
    org.jfree.chart.axis.AxisSpace var16 = var0.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.05d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.axis.AxisState var5 = new org.jfree.chart.axis.AxisState();
    boolean var6 = var0.equals((java.lang.Object)var5);
    java.util.List var7 = var5.getTicks();
    double var8 = var5.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var0.add(1.0d, 0.0d, (java.lang.Comparable)true, (java.lang.Comparable)1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var1 = var0.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3, true);
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var0.addChangeListener(var6);
//     org.jfree.chart.plot.DatasetRenderingOrder var8 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.LegendItemSource[] var10 = var9.getSources();
//     org.jfree.chart.block.BlockContainer var11 = null;
//     var9.setWrapper(var11);
//     var9.setPadding((-1.0d), 100.0d, (-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var19 = var18.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var18.addChangeListener(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18);
//     java.awt.Paint var28 = var27.getBackgroundPaint();
//     org.jfree.chart.block.BlockFrame var29 = var27.getFrame();
//     org.jfree.chart.util.VerticalAlignment var30 = var27.getVerticalAlignment();
//     java.lang.String var31 = var30.toString();
//     var9.setVerticalAlignment(var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
//     var0.setNoDataMessage("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     org.jfree.data.general.DatasetChangeEvent var4 = null;
//     var0.datasetChanged(var4);
//     int var6 = var0.getWeight();
//     java.awt.Stroke var7 = var0.getOutlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var10 = var8.getSeriesVisible(15);
//     org.jfree.chart.util.GradientPaintTransformer var11 = var8.getGradientPaintTransformer();
//     var8.setAutoPopulateSeriesShape(false);
//     int var14 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var16.getSeriesURLGenerator(10);
//     org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition();
//     var16.setPositiveItemLabelPositionFallback(var19);
//     var16.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var26 = var24.getSeriesURLGenerator(10);
//     var24.setBaseCreateEntities(false);
//     java.awt.Paint var30 = var24.getSeriesOutlinePaint(0);
//     java.awt.Paint var33 = var24.getItemFillPaint(0, (-131));
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     var34.setAutoRange(false);
//     var34.setAxisLineVisible(true);
//     var34.setAxisLineVisible(true);
//     java.lang.String var41 = var34.getLabelURL();
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var48 = var46.lookupSeriesShape((-16777216));
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
//     double var51 = var50.getFixedAutoRange();
//     java.awt.Shape var52 = var50.getUpArrow();
//     double var53 = var50.getLowerBound();
//     java.awt.Stroke var54 = var50.getTickMarkStroke();
//     var46.setSeriesStroke(0, var54, false);
//     java.awt.Stroke var58 = var46.getSeriesStroke((-16777216));
//     org.jfree.chart.renderer.category.BarRenderer var59 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Shape var61 = var59.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var62 = var59.getLegendItemLabelGenerator();
//     java.awt.Paint var63 = var59.getBaseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.clearDomainMarkers((-1));
//     var64.setBackgroundAlpha(0.0f);
//     boolean var69 = var59.hasListener((java.util.EventListener)var64);
//     org.jfree.chart.labels.CategoryToolTipGenerator var72 = var59.getToolTipGenerator(10, 15);
//     java.awt.Paint var74 = var59.lookupSeriesPaint(100);
//     var46.setBaseOutlinePaint(var74);
//     org.jfree.chart.block.BlockBorder var76 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.05d, var74);
//     java.awt.Paint var77 = var76.getPaint();
//     var34.setAxisLinePaint(var77);
//     var24.setBaseFillPaint(var77);
//     var16.setSeriesItemLabelPaint(15, var77, true);
//     var8.setSeriesOutlinePaint(15, var77);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var59 and var8.", var59.equals(var8) == var8.equals(var59));
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    java.awt.Font var4 = var0.getSeriesItemLabelFont(15);
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getNegativeItemLabelPosition(0, (-16777216));
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getSeriesItemLabelGenerator((-1));
    java.awt.Paint var11 = var0.getSeriesFillPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setLabelToolTip("");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    var4.setInverted(true);
    double var10 = var4.getUpperMargin();
    java.awt.Shape var11 = var4.getLeftArrow();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var14, var17);
    org.jfree.chart.entity.AxisLabelEntity var21 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, var14, "", "HorizontalAlignment.CENTER");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    double var23 = var22.getFixedAutoRange();
    java.awt.Shape var24 = var22.getUpArrow();
    double var25 = var22.getLowerBound();
    var22.setInverted(true);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 100.0d, 100.0f, 10.0f);
    var22.setRightArrow(var34);
    org.jfree.chart.util.RectangleInsets var36 = var22.getTickLabelInsets();
    double var37 = var22.getLabelAngle();
    java.awt.Shape var38 = var22.getLeftArrow();
    var21.setArea(var38);
    var1.setRightArrow(var38);
    java.awt.Shape var41 = var1.getRightArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     double[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "CategoryLabelWidthType.RANGE", var2);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.SortOrder var2 = var1.getRowRenderingOrder();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4, true);
    org.jfree.chart.event.PlotChangeListener var7 = null;
    var1.addChangeListener(var7);
    org.jfree.chart.plot.DatasetRenderingOrder var9 = var1.getDatasetRenderingOrder();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.util.RectangleEdge var11 = var1.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var12 = var0.getLabelPosition(var11);
    boolean var13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickMarksVisible(true);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 100.0d);
    java.lang.String var4 = var3.toString();
    var0.setDefaultAutoRange(var3);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    double var7 = var6.getFixedAutoRange();
    var6.setLowerBound(10.0d);
    boolean var10 = var3.equals((java.lang.Object)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Range[100.0,100.0]"+ "'", var4.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var3 = var1.lookupSeriesShape((-16777216));
    java.awt.Font var5 = var1.getSeriesItemLabelFont(15);
    java.lang.Boolean var7 = var1.getSeriesItemLabelsVisible(0);
    org.jfree.chart.labels.ItemLabelPosition var8 = var1.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.ItemLabelPosition var11 = var1.getPositiveItemLabelPosition(15, 0);
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var13 = new org.jfree.chart.labels.ItemLabelPosition(var0, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Font var3 = var1.getFont();
//     var1.setURLText("RectangleInsets[t=100.0,l=1.0,b=10.0,r=1.0]");
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(10.0d, var8);
//     org.jfree.data.Range var12 = var11.getWidthRange();
//     org.jfree.chart.util.Size2D var13 = var1.arrange(var6, var11);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    double var5 = var4.getFixedAutoRange();
    java.awt.Shape var6 = var4.getUpArrow();
    double var7 = var4.getLowerBound();
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesStroke(0, var8, false);
    java.awt.Stroke var12 = var0.getSeriesStroke((-16777216));
    java.awt.Paint var13 = var0.getBaseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getGPL();
    java.lang.String var2 = var0.getGPL();

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    double var3 = var0.getLowerBound();
    double var4 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 100.0d);
    java.lang.String var6 = var5.toString();
    var2.setDefaultAutoRange(var5);
    var2.setTickLabelsVisible(true);
    org.jfree.chart.util.RectangleInsets var10 = var2.getTickLabelInsets();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var17 = var15.lookupSeriesShape((-16777216));
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    double var20 = var19.getFixedAutoRange();
    java.awt.Shape var21 = var19.getUpArrow();
    double var22 = var19.getLowerBound();
    java.awt.Stroke var23 = var19.getTickMarkStroke();
    var15.setSeriesStroke(0, var23, false);
    java.awt.Stroke var27 = var15.getSeriesStroke((-16777216));
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var30 = var28.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = var28.getLegendItemLabelGenerator();
    java.awt.Paint var32 = var28.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.clearDomainMarkers((-1));
    var33.setBackgroundAlpha(0.0f);
    boolean var38 = var28.hasListener((java.util.EventListener)var33);
    org.jfree.chart.labels.CategoryToolTipGenerator var41 = var28.getToolTipGenerator(10, 15);
    java.awt.Paint var43 = var28.lookupSeriesPaint(100);
    var15.setBaseOutlinePaint(var43);
    org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.05d, var43);
    java.awt.Paint var46 = var45.getPaint();
    org.jfree.chart.util.RectangleInsets var47 = var45.getInsets();
    java.awt.Paint var48 = var45.getPaint();
    var2.setTickMarkPaint(var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.GENERAL", var1, var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Range[100.0,100.0]"+ "'", var6.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    boolean var4 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    var7.setDefaultAutoRange(var10);
    double var13 = var7.getUpperMargin();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 100.0d);
    java.lang.String var17 = var16.toString();
    boolean var19 = var16.equals((java.lang.Object)(byte)100);
    boolean var21 = var16.contains(1.0d);
    var7.setRangeWithMargins(var16, false, false);
    java.awt.geom.Rectangle2D var25 = null;
    var0.drawRangeGridline(var5, var6, (org.jfree.chart.axis.ValueAxis)var7, var25, 1.0d);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var30 = var28.getSeriesVisible(15);
    org.jfree.chart.util.GradientPaintTransformer var31 = var28.getGradientPaintTransformer();
    java.awt.Stroke var32 = var28.getBaseStroke();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    double var35 = var34.getFixedAutoRange();
    java.awt.Shape var36 = var34.getUpArrow();
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var39, 100.0d, 100.0f, 10.0f);
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var36, var39);
    var28.setSeriesShape(15, var39);
    org.jfree.chart.labels.ItemLabelPosition var48 = var28.getNegativeItemLabelPosition((-16777216), 0);
    var0.setNegativeItemLabelPositionFallback(var48);
    java.awt.Stroke var51 = var0.getSeriesStroke(255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777216), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Range[100.0,100.0]"+ "'", var11.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Range[100.0,100.0]"+ "'", var17.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var4 = var2.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearDomainMarkers((-1));
    var7.setBackgroundAlpha(0.0f);
    boolean var12 = var2.hasListener((java.util.EventListener)var7);
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
    java.awt.Font var15 = var14.getFont();
    var2.setBaseItemLabelFont(var15);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    double var18 = var17.getFixedAutoRange();
    java.awt.Shape var19 = var17.getUpArrow();
    double var20 = var17.getLowerBound();
    var17.setInverted(true);
    double var23 = var17.getUpperMargin();
    java.awt.Shape var24 = var17.getLeftArrow();
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 100.0d);
    java.lang.String var28 = var27.toString();
    var17.setRange(var27);
    java.awt.Paint var30 = var17.getLabelPaint();
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", var15, var30);
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", var15, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Range[100.0,100.0]"+ "'", var28.equals("Range[100.0,100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var5 = var0.getSeriesItemLabelPaint(0);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
    boolean var10 = var6.equals((java.lang.Object)0.95f);
    java.lang.Object var11 = var6.clone();
    var6.add((java.lang.Number)15, (java.lang.Number)0.5f, (java.lang.Comparable)255, (java.lang.Comparable)0.05d);
    org.jfree.data.Range var17 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    java.awt.Paint var20 = var0.getItemOutlinePaint(100, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + Double.NaN+ "'", var8.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var13 = var11.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var11.getLegendItemLabelGenerator();
    java.awt.Paint var15 = var11.getBaseOutlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("6,53,7,50,7,50,7,50,10,51,9,51,10,51,9,53,9,53,9,53,6,53,7,52,7,52", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER", var10, var15);
    boolean var17 = var16.isShapeVisible();
    org.jfree.chart.util.GradientPaintTransformer var18 = var16.getFillPaintTransformer();
    boolean var19 = var16.isShapeVisible();
    java.awt.Paint var20 = var16.getFillPaint();
    java.lang.String var21 = var16.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleEdge.BOTTOM"+ "'", var21.equals("RectangleEdge.BOTTOM"));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = var0.getDataset();
    boolean var2 = var0.isOutlineVisible();
    float var3 = var0.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0f);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers((-1));
    var5.setBackgroundAlpha(0.0f);
    boolean var10 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getToolTipGenerator(10, 15);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var15 = var0.getNegativeItemLabelPositionFallback();
    boolean var16 = var0.getIncludeBaseInRange();
    java.awt.Paint var18 = var0.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.ItemLabelPosition var19 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.annotations.CategoryAnnotation var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var6 = var5.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var5.setDomainAxisLocation(1, var8, true);
//     org.jfree.chart.event.PlotChangeListener var11 = null;
//     var5.addChangeListener(var11);
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var5.getDatasetRenderingOrder();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     org.jfree.chart.LegendItemSource[] var15 = var14.getSources();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Font var18 = var17.getLabelFont();
//     var14.setItemFont(var18);
//     org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("", var18);
//     var2.setTickLabelFont(var18);
//     var0.setTickLabelFont(var18);
//     var0.setCategoryMargin(109.0d);
//     java.lang.String var26 = var0.getCategoryLabelToolTip((java.lang.Comparable)(-1));
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var30 = null;
//     org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 100.0d);
//     java.lang.String var33 = var32.toString();
//     var29.setDefaultAutoRange(var32);
//     var29.setTickLabelsVisible(true);
//     org.jfree.chart.util.RectangleInsets var37 = var29.getTickLabelInsets();
//     boolean var38 = var29.isTickLabelsVisible();
//     boolean var39 = var29.isPositiveArrowVisible();
//     java.awt.Font var40 = var29.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var42 = var41.getDataset();
//     java.awt.Paint var43 = null;
//     var41.setOutlinePaint(var43);
//     org.jfree.chart.util.RectangleInsets var49 = new org.jfree.chart.util.RectangleInsets(100.0d, 1.0d, 10.0d, 1.0d);
//     boolean var51 = var49.equals((java.lang.Object)(short)1);
//     java.lang.String var52 = var49.toString();
//     var41.setInsets(var49);
//     org.jfree.chart.ChartRenderingInfo var56 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var57 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
//     java.awt.geom.Point2D var58 = null;
//     var41.zoomRangeAxes(100.0d, 1.0d, var57, var58);
//     java.awt.geom.Rectangle2D var60 = var57.getDataArea();
//     org.jfree.chart.entity.TickLabelEntity var63 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape)var60, "", "hi!");
//     var29.setDownArrow((java.awt.Shape)var60);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.SortOrder var66 = var65.getRowRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var68 = null;
//     var65.setDomainAxisLocation(1, var68, true);
//     org.jfree.chart.event.PlotChangeListener var71 = null;
//     var65.addChangeListener(var71);
//     org.jfree.chart.plot.DatasetRenderingOrder var73 = var65.getDatasetRenderingOrder();
//     double var74 = var65.getRangeCrosshairValue();
//     org.jfree.chart.event.AxisChangeEvent var75 = null;
//     var65.axisChanged(var75);
//     org.jfree.chart.util.RectangleEdge var77 = var65.getRangeAxisEdge();
//     double var78 = var0.getCategoryEnd(1, 255, var60, var77);
//     
//     // Checks the contract:  equals-hashcode on var5 and var65
//     assertTrue("Contract failed: equals-hashcode on var5 and var65", var5.equals(var65) ? var5.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var5
//     assertTrue("Contract failed: equals-hashcode on var65 and var5", var65.equals(var5) ? var65.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedAutoRange();
    java.awt.Shape var2 = var0.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 100);
    var0.setInverted(false);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var9, 0);
    java.lang.Comparable var14 = null;
    var9.add((java.lang.Number)100.0d, (java.lang.Number)1, var14, (java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var18 = var17.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var17.zoomDomainAxes((-1.0d), var20, var21);
    org.jfree.chart.axis.AxisLocation var24 = var17.getDomainAxisLocation(15);
    boolean var25 = var9.hasListener((java.util.EventListener)var17);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 0);
    org.jfree.data.general.DatasetGroup var29 = var26.getGroup();
    var9.setGroup(var29);
    org.jfree.data.Range var31 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    var0.setRangeWithMargins(var31);
    var0.resizeRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

}
