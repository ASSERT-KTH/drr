
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 1.0d, true);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(1, var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1.0f, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 0.0f, var5);
    org.jfree.chart.text.TextBlockAnchor var7 = null;
    org.jfree.chart.text.TextAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)100, var6, var7, var8, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, var4);
    java.awt.Font var7 = null;
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addLine("", var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    var0.clear();

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     java.util.Date var3 = var1.calculateLowestVisibleTickValue(var2);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var4 = var3.getMaximumDate();
//     var0.addBaseTimelineException(var4);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Paint var0 = null;
    java.awt.Paint var1 = null;
    boolean var2 = org.jfree.chart.util.PaintUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    float[] var5 = new float[] { 0.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(10, 1, 0, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    java.text.DateFormat var9 = null;
    org.jfree.chart.axis.DateTickUnit var10 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var11 = new org.jfree.chart.entity.CategoryItemEntity(var0, "hi!", "hi!", var3, (java.lang.Comparable)0.0f, (java.lang.Comparable)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 10.0d, 0, (java.lang.Comparable)10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseFillPaint(var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (byte)100};
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var4 = var3.getMaximumDate();
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { var4};
//     java.lang.Number[] var6 = null;
//     java.lang.Number[][] var7 = new java.lang.Number[][] { var6};
//     java.lang.Number[] var8 = null;
//     java.lang.Number[][] var9 = new java.lang.Number[][] { var8};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var5, var7, var9);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.labels.ItemLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.Point var4 = var0.translateValueThetaRadiusToJava2D(1.0d, 0.05d, var3);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     java.util.Date var4 = var3.getStart();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4, var5);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-435));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var8 = var6.removeAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var5 = var2.getItemOutlineStroke((-1), 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 1.0f, 0.2d, 10.0f, 100.0f);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var8 = var6.getRangeAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.AxisState var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    java.util.List var6 = var1.refreshTicks(var2, var3, var4, var5);
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var8);
    var1.setRange((org.jfree.data.Range)var8);
    java.awt.Font var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    org.jfree.chart.plot.Marker var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var2.drawDomainGridline(var3, var4, var5, (-1.0d));
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var4 = var0.createInsetRectangle(var1, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "", "", "");
    java.lang.String var8 = var7.getLicenceText();
    var7.setLicenceName("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var5 = var4.getAngleGridlinePaint();
    var0.setBaseOutlinePaint(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     org.jfree.chart.plot.PlotState var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var0.draw(var2, var3, var4, var5, var6);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("1969");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var3 = var2.getAngleGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var4 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var5 = var2.getItemOutlineStroke((-1), 100);
    double var6 = var2.getItemMargin();
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getAngleLabelPaint();
    var2.setBaseFillPaint(var9, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getAngleLabelPaint();
    var0.setBaseFillPaint(var7, false);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-16777216), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var4 = null;
    var1.setMarkerBand(var4);
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     var6.addRangeMarker(var7, var8);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var14 = var11.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var16 = var15.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var15.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var20 = var19.getAngleGridlinePaint();
//     var15.setBasePaint(var20);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var10, var14, var20);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var33 = var30.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var35 = var34.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var37 = var34.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var39 = var38.getAngleGridlinePaint();
//     var34.setBasePaint(var39);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var29, var33, var39);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var52 = var49.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var54 = var53.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var56 = var53.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var58 = var57.getAngleGridlinePaint();
//     var53.setBasePaint(var58);
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var48, var52, var58);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("", "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var10, var33, var58);
//     
//     // Checks the contract:  equals-hashcode on var19 and var38
//     assertTrue("Contract failed: equals-hashcode on var19 and var38", var19.equals(var38) ? var19.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var57
//     assertTrue("Contract failed: equals-hashcode on var19 and var57", var19.equals(var57) ? var19.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var19
//     assertTrue("Contract failed: equals-hashcode on var38 and var19", var38.equals(var19) ? var38.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var57
//     assertTrue("Contract failed: equals-hashcode on var38 and var57", var38.equals(var57) ? var38.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var19
//     assertTrue("Contract failed: equals-hashcode on var57 and var19", var57.equals(var19) ? var57.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var38
//     assertTrue("Contract failed: equals-hashcode on var57 and var38", var57.equals(var38) ? var57.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var41
//     assertTrue("Contract failed: equals-hashcode on var22 and var41", var22.equals(var41) ? var22.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var60
//     assertTrue("Contract failed: equals-hashcode on var22 and var60", var22.equals(var60) ? var22.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var22
//     assertTrue("Contract failed: equals-hashcode on var41 and var22", var41.equals(var22) ? var41.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var60
//     assertTrue("Contract failed: equals-hashcode on var41 and var60", var41.equals(var60) ? var41.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var22
//     assertTrue("Contract failed: equals-hashcode on var60 and var22", var60.equals(var22) ? var60.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var41
//     assertTrue("Contract failed: equals-hashcode on var60 and var41", var60.equals(var41) ? var60.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    double var4 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, (-1.0f), 0.0f, var5, 10.0f, 0.0f, 100.0d);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    var10.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var13 = null;
    var10.setMarkerBand(var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap();
    int var18 = var16.getGroupIndex((java.lang.Comparable)0.0d);
    int var20 = var16.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var15, var16);
    org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var5, var6, var7, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.data.category.CategoryDataset)var15, (-1), 0, 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, (-1.0f), 0.0d, 1.0f, 100.0f);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var2 = var0.createOutsetRectangle(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     long var2 = var0.getStartTime();
//     org.jfree.chart.axis.SegmentedTimeline var6 = new org.jfree.chart.axis.SegmentedTimeline((-2208960000000L), 0, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setBaseTimeline(var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2208960000000L));
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var14 = var11.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var16 = var15.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var15.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var20 = var19.getAngleGridlinePaint();
//     var15.setBasePaint(var20);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var10, var14, var20);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var26 = var23.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var28 = var27.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var30 = var27.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var32 = var31.getAngleGridlinePaint();
//     var27.setBasePaint(var32);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", var10, var26, var32);
//     
//     // Checks the contract:  equals-hashcode on var19 and var31
//     assertTrue("Contract failed: equals-hashcode on var19 and var31", var19.equals(var31) ? var19.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var19
//     assertTrue("Contract failed: equals-hashcode on var31 and var19", var31.equals(var19) ? var31.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 0.0f, var5);
    org.jfree.chart.text.TextBlockAnchor var7 = null;
    org.jfree.chart.text.TextAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)true, var6, var7, var8, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 1);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var2.equals("org.jfree.data.UnknownKeyException: "));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    double var15 = var12.getLabelAngle();
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawItem(var3, var4, var5, var6, var7, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.data.category.CategoryDataset)var16, 1, (-1), 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var3 = var2.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var7 = var6.getAngleGridlinePaint();
//     var2.setBasePaint(var7);
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var7, (-1.0f), 0, var11);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.UnknownKeyException: ", var1, (-1.0f), 1.0f, var4, 0.05d, 0.0f, 100.0f);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
//     java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
//     double var7 = var0.getUpperClip();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.LegendItemCollection var21 = var14.getLegendItems();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var25 = var22.getItemLabelPaint(10, 1);
//     var22.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = var34.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var36 = null;
//     var34.setFixedDomainAxisSpace(var36);
//     var34.setDomainCrosshairValue(100.0d);
//     boolean var40 = var34.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var44 = var41.getItemLabelPaint(10, 1);
//     var34.setDomainTickBandPaint(var44);
//     var22.addChangeListener((org.jfree.chart.event.RendererChangeListener)var34);
//     java.awt.Stroke var47 = var34.getOutlineStroke();
//     var14.setRangeZeroBaselineStroke(var47);
//     
//     // Checks the contract:  equals-hashcode on var14 and var34
//     assertTrue("Contract failed: equals-hashcode on var14 and var34", var14.equals(var34) ? var14.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var14
//     assertTrue("Contract failed: equals-hashcode on var34 and var14", var34.equals(var14) ? var34.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var7 = var4.getItemLabelPaint(10, 1);
//     var4.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = var16.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var18 = null;
//     var16.setFixedDomainAxisSpace(var18);
//     var16.setDomainCrosshairValue(100.0d);
//     boolean var22 = var16.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var26 = var23.getItemLabelPaint(10, 1);
//     var16.setDomainTickBandPaint(var26);
//     var4.addChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     org.jfree.chart.util.RectangleEdge var30 = var16.getRangeAxisEdge((-1));
//     double var31 = var1.java2DToValue(1.0E-8d, var3, var30);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(1.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 1.0E-8d, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-16777216), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var6.setDrawingSupplier(var12);
    org.jfree.chart.plot.Marker var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setAutoRangeStickyZero(false);
//     var1.setAxisLineVisible(false);
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var7 = var6.clone();
//     java.awt.Paint var8 = var6.getAngleLabelPaint();
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var15.setFixedDomainAxisSpace(var17);
//     java.awt.Paint var19 = var15.getRangeGridlinePaint();
//     var6.setRadiusGridlinePaint(var19);
//     var1.setPlot((org.jfree.chart.plot.Plot)var6);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var27 = var24.getItemLabelPaint(10, 1);
//     var24.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.axis.ValueAxis)var34, var35);
//     org.jfree.chart.axis.ValueAxis var37 = var36.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     var36.setFixedDomainAxisSpace(var38);
//     var36.setDomainCrosshairValue(100.0d);
//     boolean var42 = var36.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var46 = var43.getItemLabelPaint(10, 1);
//     var36.setDomainTickBandPaint(var46);
//     var24.addChangeListener((org.jfree.chart.event.RendererChangeListener)var36);
//     org.jfree.chart.util.RectangleEdge var50 = var36.getRangeAxisEdge((-1));
//     double var51 = var1.valueToJava2D(1.0E-8d, var23, var50);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    var12.setDomainCrosshairValue(100.0d);
    boolean var18 = var12.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var19.getItemLabelPaint(10, 1);
    var12.setDomainTickBandPaint(var22);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    var0.setBase(10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-435), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     var2.setAutoPopulateSeriesStroke(true);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var7 = new org.jfree.data.KeyToGroupMap();
//     int var9 = var7.getGroupIndex((java.lang.Comparable)0.0d);
//     int var11 = var7.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, var7);
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     var15.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     java.awt.geom.Rectangle2D var22 = null;
//     var2.drawDomainGridline(var5, var21, var22, 1.0E-8d);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getAngleLabelPaint();
//     var0.zoom(0.2d);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    double var3 = var2.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var5 = var2.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var7 = var6.getAngleGridlinePaint();
    var2.setBasePaint(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     var4.setInverted(false);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var15.setFixedDomainAxisSpace(var17);
//     var15.setDomainCrosshairValue(100.0d);
//     org.jfree.chart.plot.DrawingSupplier var21 = null;
//     var15.setDrawingSupplier(var21);
//     boolean var23 = var4.hasListener((java.util.EventListener)var15);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.plot.CategoryMarker var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addDomainMarker(10, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var3 = var2.clone();
    java.awt.Paint var4 = var2.getAngleLabelPaint();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var10);
    org.jfree.chart.axis.ValueAxis var12 = var11.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var11.setFixedDomainAxisSpace(var13);
    java.awt.Paint var15 = var11.getRangeGridlinePaint();
    var2.setRadiusGridlinePaint(var15);
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var20 = var17.getItemLabelPaint(10, 1);
    var17.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var28);
    org.jfree.chart.axis.ValueAxis var30 = var29.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var31 = null;
    var29.setFixedDomainAxisSpace(var31);
    var29.setDomainCrosshairValue(100.0d);
    boolean var35 = var29.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var39 = var36.getItemLabelPaint(10, 1);
    var29.setDomainTickBandPaint(var39);
    var17.addChangeListener((org.jfree.chart.event.RendererChangeListener)var29);
    org.jfree.chart.util.RectangleEdge var43 = var29.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var44 = org.jfree.chart.util.RectangleEdge.opposite(var43);
    org.jfree.chart.util.HorizontalAlignment var45 = null;
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var47, (org.jfree.chart.axis.ValueAxis)var49, (org.jfree.chart.axis.ValueAxis)var51, var52);
    org.jfree.chart.axis.ValueAxis var54 = var53.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var55 = null;
    var53.setFixedDomainAxisSpace(var55);
    var53.setDomainCrosshairValue(100.0d);
    boolean var59 = var53.isRangeZeroBaselineVisible();
    org.jfree.chart.util.RectangleInsets var60 = new org.jfree.chart.util.RectangleInsets();
    var53.setAxisOffset(var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("1/1/69", var1, var15, var43, var45, var46, var60);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var8 = var5.getItemOutlineStroke((-1), 100);
    double var9 = var5.getItemMargin();
    java.awt.Shape var10 = var5.getBaseShape();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    var5.setSeriesShape(10, var13, false);
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var18 = var17.clone();
    java.awt.Paint var19 = var17.getAngleLabelPaint();
    java.awt.Paint var21 = null;
    org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var23 = var22.clone();
    java.awt.Stroke var24 = var22.getOutlineStroke();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var31 = var28.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = null;
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.axis.AxisState var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    java.util.List var43 = var38.refreshTicks(var39, var40, var41, var42);
    org.jfree.chart.plot.Marker var44 = null;
    java.awt.geom.Rectangle2D var45 = null;
    var34.drawRangeMarker(var35, var36, (org.jfree.chart.axis.ValueAxis)var38, var44, var45);
    java.awt.Paint var47 = var34.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var51 = var48.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = null;
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var59 = null;
    org.jfree.chart.axis.AxisState var60 = null;
    java.awt.geom.Rectangle2D var61 = null;
    org.jfree.chart.util.RectangleEdge var62 = null;
    java.util.List var63 = var58.refreshTicks(var59, var60, var61, var62);
    org.jfree.chart.plot.Marker var64 = null;
    java.awt.geom.Rectangle2D var65 = null;
    var54.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var58, var64, var65);
    java.awt.Paint var67 = var54.getWallPaint();
    java.awt.Color var69 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var70 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var47, var51, var67, (java.awt.Paint)var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem(var0, "hi!", "12/31/69", "", false, var13, true, var19, false, var21, var24, true, var27, var31, (java.awt.Paint)var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var0.getValue(10, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var1 = var0.toString();
    double var3 = var0.calculateLeftInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.AxisState var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     java.util.List var11 = var6.refreshTicks(var7, var8, var9, var10);
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var12, var13);
//     java.awt.Paint var15 = var2.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var19 = var16.getItemLabelPaint(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = null;
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.axis.AxisState var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     java.util.List var31 = var26.refreshTicks(var27, var28, var29, var30);
//     org.jfree.chart.plot.Marker var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var22.drawRangeMarker(var23, var24, (org.jfree.chart.axis.ValueAxis)var26, var32, var33);
//     java.awt.Paint var35 = var22.getWallPaint();
//     java.awt.Color var37 = java.awt.Color.decode("1969");
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var38 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var15, var19, var35, (java.awt.Paint)var37);
//     java.awt.color.ColorSpace var39 = null;
//     float[] var40 = new float[] { };
//     float[] var41 = var37.getColorComponents(var39, var40);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.text.DateFormat var17 = null;
//     org.jfree.chart.axis.DateTickUnit var18 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var17);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var21 = var20.getMaximumDate();
//     java.lang.String var22 = var18.dateToString(var21);
//     org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var12, (java.lang.Comparable)var21);
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-16777216), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = var0.getDataset();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var12 = var9.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var14 = var13.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var16 = var13.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var18 = var17.getAngleGridlinePaint();
//     var13.setBasePaint(var18);
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var8, var12, var18);
//     var0.setAngleGridlineStroke(var12);
//     boolean var22 = var0.isRangeZoomable();
//     var0.zoom(0.0d);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-1));
//     org.jfree.chart.block.ColumnArrangement var3 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var5 = new org.jfree.data.KeyToGroupMap();
//     int var7 = var5.getGroupIndex((java.lang.Comparable)0.0d);
//     int var9 = var5.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var4, var5);
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var3, (org.jfree.data.general.Dataset)var4, (java.lang.Comparable)10L);
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var3, (org.jfree.chart.block.Arrangement)var15);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
//     java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
//     double var7 = var0.getUpperClip();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.LegendItemCollection var21 = var14.getLegendItems();
//     org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var23 = var22.getSegmentsIncludedSize();
//     long var24 = var22.getStartTime();
//     long var25 = var22.getSegmentsGroupSize();
//     boolean var26 = var21.equals((java.lang.Object)var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.LegendItem var28 = var21.get(100);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 604800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var25);
    var15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var22, false);
    org.jfree.chart.plot.CategoryMarker var29 = null;
    org.jfree.chart.util.Layer var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addDomainMarker(var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(1577894400001L, (-435), 0);
//     org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var5 = var4.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var8 = var7.getMaximumDate();
//     long var9 = var4.toTimelineValue(var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.setBaseTimeline(var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1577894400001L);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "hi!", "1969");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     float var4 = var1.calculateBaselineOffset(var2, var3);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
    org.jfree.chart.axis.AxisLocation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setDomainAxisLocation(var22, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    java.awt.Stroke var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setDomainGridlineStroke(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    double var7 = var0.getUpperClip();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-1), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     double var3 = var1.getFixedAutoRange();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var9 = var6.getItemLabelPaint(10, 1);
//     var6.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = var18.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var18.setFixedDomainAxisSpace(var20);
//     var18.setDomainCrosshairValue(100.0d);
//     boolean var24 = var18.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var28 = var25.getItemLabelPaint(10, 1);
//     var18.setDomainTickBandPaint(var28);
//     var6.addChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
//     org.jfree.chart.util.RectangleEdge var32 = var18.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var33 = org.jfree.chart.util.RectangleEdge.opposite(var32);
//     double var34 = var1.lengthToJava2D(1.0E-8d, var5, var33);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     java.awt.Color var11 = java.awt.Color.decode("1969");
//     var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var6.zoomDomainAxes(1.0E-8d, 0.05d, var15, var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     java.awt.geom.Point2D var20 = null;
//     org.jfree.chart.plot.PlotState var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     var6.draw(var18, var19, var20, var21, var22);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem(var0, "1/1/69", "First", "9-January-1900", var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(1577894400001L, 432000000L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("1/1/69");

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove((-16775247));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0.0f);
    java.lang.Comparable var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var6.setDrawingSupplier(var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
    var16.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var19 = null;
    var16.setMarkerBand(var19);
    var6.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var16, false);
    org.jfree.chart.axis.NumberTickUnit var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setTickUnit(var23, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var2);
    java.lang.String var4 = var2.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var2.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "9-January-1900"+ "'", var4.equals("9-January-1900"));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue((java.lang.Comparable)"12/31/69", (java.lang.Comparable)604800000L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Paint var10 = var6.getRangeGridlinePaint();
    java.awt.Graphics2D var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
    int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
    int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
    java.util.List var20 = var13.getColumnKeys();
    var6.drawDomainTickBands(var11, var12, var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var22 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var20);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var25);
    var15.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var22, false);
    org.jfree.chart.axis.NumberTickUnit var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setTickUnit(var29, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("1969", var1, var2, var3);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     java.lang.String var12 = var11.getID();
//     var11.setWidth(1.0E-8d);
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var17 = new org.jfree.data.KeyToGroupMap();
//     int var19 = var17.getGroupIndex((java.lang.Comparable)0.0d);
//     int var21 = var17.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, var17);
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var15, (org.jfree.data.general.Dataset)var16, (java.lang.Comparable)10L);
//     java.lang.String var27 = var26.getID();
//     var26.setWidth(1.0E-8d);
//     org.jfree.chart.block.LineBorder var30 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var31 = var30.getPaint();
//     var26.setFrame((org.jfree.chart.block.BlockFrame)var30);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var37, var38);
//     org.jfree.chart.axis.ValueAxis var40 = var39.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var41 = null;
//     var39.setFixedDomainAxisSpace(var41);
//     var39.setDomainCrosshairValue(100.0d);
//     boolean var45 = var39.isRangeZeroBaselineVisible();
//     org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets();
//     var39.setAxisOffset(var46);
//     var11.add((org.jfree.chart.block.Block)var26, (java.lang.Object)var46);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-1));
//     int var3 = var0.getRowCount();
//     java.awt.Paint[] var5 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var7 = var6.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var6.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var11 = var10.getAngleGridlinePaint();
//     var6.setBasePaint(var11);
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var11};
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var17 = var14.getItemOutlineStroke((-1), 100);
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var22 = var19.getItemOutlineStroke((-1), 100);
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     java.awt.Shape[] var27 = new java.awt.Shape[] { var26};
//     org.jfree.chart.plot.DefaultDrawingSupplier var28 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var13, var18, var23, var27);
//     java.awt.Stroke var29 = var28.getNextOutlineStroke();
//     var0.setSeriesOutlineStroke(10, var29, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var0.", var14.equals(var0) == var0.equals(var14));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
    var2.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var9.getItemLabelPaint(10, 1);
    var2.setSeriesPaint(1, var12);
    org.jfree.chart.labels.ItemLabelPosition var14 = var2.getBasePositiveItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var14, false);
    org.jfree.chart.labels.ItemLabelAnchor var17 = var14.getItemLabelAnchor();
    org.jfree.chart.text.TextAnchor var18 = null;
    org.jfree.chart.text.TextAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var21 = new org.jfree.chart.labels.ItemLabelPosition(var17, var18, var19, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.AxisState var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     java.util.List var11 = var6.refreshTicks(var7, var8, var9, var10);
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var12, var13);
//     java.awt.Paint var15 = var2.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var19 = var16.getItemLabelPaint(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = null;
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.axis.AxisState var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     java.util.List var31 = var26.refreshTicks(var27, var28, var29, var30);
//     org.jfree.chart.plot.Marker var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var22.drawRangeMarker(var23, var24, (org.jfree.chart.axis.ValueAxis)var26, var32, var33);
//     java.awt.Paint var35 = var22.getWallPaint();
//     java.awt.Color var37 = java.awt.Color.decode("1969");
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var38 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var15, var19, var35, (java.awt.Paint)var37);
//     java.awt.Paint var39 = var38.getNegativeBarPaint();
//     java.awt.Graphics2D var40 = null;
//     org.jfree.data.category.DefaultCategoryDataset var41 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var42 = new org.jfree.data.KeyToGroupMap();
//     int var44 = var42.getGroupIndex((java.lang.Comparable)0.0d);
//     int var46 = var42.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var41, var42);
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("");
//     var50.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var41, var48, (org.jfree.chart.axis.ValueAxis)var50, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var58 = var57.isDrawBarOutline();
//     int var59 = var56.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     var56.setRangeCrosshairValue(10.0d, false);
//     java.awt.geom.Rectangle2D var63 = null;
//     var38.drawDomainGridline(var40, var56, var63, 10.0d);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getAngleLabelPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(0.2d, var4, var5);
//     double var7 = var0.getMaxRadius();
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("1969", var1, 10.0f, 10.0f, var4, 1.0E-8d, var6);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
    org.jfree.chart.axis.AxisLocation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeAxisLocation(var22, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var4 = var3.getMaximumDate();
//     long var5 = var0.toTimelineValue(var4);
//     long var6 = var0.getSegmentSize();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 86400000L);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    boolean var16 = var14.getBaseShapesFilled();
    boolean var17 = var14.getUseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesLinesVisible((-435), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("9-January-1900", var1, var2, var3);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
    org.jfree.chart.axis.AxisSpace var22 = var15.getFixedDomainAxisSpace();
    org.jfree.chart.axis.AxisLocation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeAxisLocation(var23, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var10 = var7.getItemLabelPaint(10, 1);
    var0.setSeriesPaint(1, var10);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.urls.CategoryURLGenerator var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-435), var14, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.clearRangeMarkers(0);
    org.jfree.chart.axis.AxisLocation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setDomainAxisLocation((-16775247), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    var1.configure();
    boolean var5 = var1.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    int var9 = var1.getRowIndex((java.lang.Comparable)0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var12 = var0.generateToolTip((org.jfree.data.category.CategoryDataset)var1, (-16777216), (-16775247));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var2 = var1.getDataset();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var13 = var10.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var15 = var14.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var14.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var19 = var18.getAngleGridlinePaint();
//     var14.setBasePaint(var19);
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var9, var13, var19);
//     var1.setAngleGridlineStroke(var13);
//     java.awt.Font var23 = var1.getAngleLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = null;
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.AxisState var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     java.util.List var35 = var30.refreshTicks(var31, var32, var33, var34);
//     org.jfree.chart.plot.Marker var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     var26.drawRangeMarker(var27, var28, (org.jfree.chart.axis.ValueAxis)var30, var36, var37);
//     java.awt.Paint var39 = var26.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var43 = var40.getItemLabelPaint(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = null;
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.AxisState var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     java.util.List var55 = var50.refreshTicks(var51, var52, var53, var54);
//     org.jfree.chart.plot.Marker var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     var46.drawRangeMarker(var47, var48, (org.jfree.chart.axis.ValueAxis)var50, var56, var57);
//     java.awt.Paint var59 = var46.getWallPaint();
//     java.awt.Color var61 = java.awt.Color.decode("1969");
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var62 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var39, var43, var59, (java.awt.Paint)var61);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.text.G2TextMeasurer var66 = new org.jfree.chart.text.G2TextMeasurer(var65);
//     org.jfree.chart.text.TextBlock var67 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var23, var39, (-1.0f), 0, (org.jfree.chart.text.TextMeasurer)var66);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("1969", var1, 1.0f, 1.0f, 1.0E-8d, (-1.0f), 10.0f);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
//     var0.setFrame(var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxisForDataset(100);
    org.jfree.chart.plot.Plot var21 = var15.getRootPlot();
    org.jfree.chart.util.SortOrder var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRowRenderingOrder(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
//     java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
//     double var7 = var0.getUpperClip();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var26);
//     org.jfree.chart.axis.ValueAxis var28 = var27.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var27.setFixedDomainAxisSpace(var29);
//     java.awt.Color var32 = java.awt.Color.decode("1969");
//     var27.setRangeZeroBaselinePaint((java.awt.Paint)var32);
//     var14.setDomainTickBandPaint((java.awt.Paint)var32);
//     var14.zoom(0.0d);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     var14.drawBackground(var37, var38);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 10);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
    int var6 = var4.getGroupIndex((java.lang.Comparable)0.0d);
    int var8 = var4.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var3, var4);
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var3, (-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 1.0d);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var14 = var11.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var18 = var15.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var20 = var19.getAngleGridlinePaint();
    var15.setBasePaint(var20);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var10, var14, var20);
    var2.setSeriesStroke(0, var14);
    boolean var24 = var2.getRenderAsPercentages();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setArea(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesBarWidth((-16775247), 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     long var4 = var3.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1969L);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("1/1/69", var1, 1.0f, 0.0f, var4, 100.0d, 1.0f, 0.0f);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     var4.setTickMarksVisible(false);
//     java.awt.Paint var9 = var4.getTickLabelPaint();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var12 = var11.getMaximumDate();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(var12);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var17 = new org.jfree.data.KeyToGroupMap();
//     int var19 = var17.getGroupIndex((java.lang.Comparable)0.0d);
//     int var21 = var17.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, var17);
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     var25.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
//     org.jfree.chart.event.RendererChangeEvent var32 = null;
//     var31.rendererChanged(var32);
//     var31.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var36 = var31.getDomainAxisEdge();
//     double var37 = var4.dateToJava2D(var12, var15, var36);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     java.text.DateFormat var16 = null;
//     org.jfree.chart.axis.DateTickUnit var17 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var16);
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var20 = var19.getMaximumDate();
//     java.lang.String var21 = var17.dateToString(var20);
//     org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var23 = var22.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var26 = var25.getMaximumDate();
//     long var27 = var22.toTimelineValue(var26);
//     org.jfree.data.time.SimpleTimePeriod var28 = new org.jfree.data.time.SimpleTimePeriod(var20, var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.removeRow((java.lang.Comparable)var26);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "12/31/69"+ "'", var21.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1577894400001L);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
    java.lang.String var12 = var11.getID();
    java.awt.Graphics2D var13 = null;
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var11.arrange(var13, var16);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var13.refreshTicks(var14, var15, var16, var17);
    org.jfree.chart.plot.Marker var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    var9.drawRangeMarker(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var19, var20);
    java.awt.Paint var22 = var9.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var26 = var23.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.AxisState var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    java.util.List var38 = var33.refreshTicks(var34, var35, var36, var37);
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var29.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, var39, var40);
    java.awt.Paint var42 = var29.getWallPaint();
    java.awt.Color var44 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var22, var26, var42, (java.awt.Paint)var44);
    var0.setBaseOutlinePaint(var42);
    org.jfree.data.category.CategoryDataset var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var48 = var0.findRangeBounds(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.NaN, 3.0d, var2);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
    var2.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    boolean var20 = var14.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
    var14.setDomainTickBandPaint(var24);
    var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
    boolean var30 = var1.equals((java.lang.Object)var28);
    java.lang.Number var32 = var0.getQ3Value((java.lang.Comparable)var30, (java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.statistics.BoxAndWhiskerItem var35 = var0.getItem(1, (-435));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "", "", "");
//     java.lang.String var8 = var7.getLicenceText();
//     java.lang.String var9 = var7.getLicenceText();
//     org.jfree.chart.ui.Library var10 = null;
//     var7.addLibrary(var10);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var6.setDrawingSupplier(var12);
    boolean var14 = var6.isDomainZeroBaselineVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var15 = var6.clone();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Paint var10 = var6.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var6.markerChanged(var11);
    var6.setDomainCrosshairVisible(true);
    java.awt.Image var15 = var6.getBackgroundImage();
    org.jfree.chart.axis.AxisLocation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRangeAxisLocation((-1), var17, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.awt.Font var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var10 = null;
    var8.setFixedDomainAxisSpace(var10);
    java.awt.Color var13 = java.awt.Color.decode("1969");
    var8.setRangeZeroBaselinePaint((java.awt.Paint)var13);
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var13, 0.0f, var16);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLineAlignment(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
    org.jfree.chart.axis.AxisSpace var22 = var15.getFixedDomainAxisSpace();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var28);
    double var30 = var27.getLabelAngle();
    boolean var31 = var15.equals((java.lang.Object)var27);
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
    double var35 = var34.getUpperMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeAxis((-16775247), (org.jfree.chart.axis.ValueAxis)var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Color var2 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var3 = var2.getGreen();
    java.awt.Color var4 = var2.darker();
    float[] var6 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var2.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("1969", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     org.jfree.chart.plot.DrawingSupplier var12 = null;
//     var6.setDrawingSupplier(var12);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var6.handleClick(0, 0, var16);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var6.setFixedRangeAxisSpace(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setEndType(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getEndValue(100, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var15.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    var18.setUpperMargin(1.0d);
    org.jfree.chart.axis.CategoryLabelPositions var22 = var18.getCategoryLabelPositions();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var28);
    org.jfree.chart.axis.ValueAxis var30 = var29.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var31 = null;
    var29.setFixedDomainAxisSpace(var31);
    java.awt.Color var34 = java.awt.Color.decode("1969");
    var29.setRangeZeroBaselinePaint((java.awt.Paint)var34);
    boolean var36 = var29.isRangeZoomable();
    java.awt.Image var37 = var29.getBackgroundImage();
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = var29.getRenderer();
    var29.setDomainCrosshairValue((-1.0d));
    boolean var41 = var18.equals((java.lang.Object)var29);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = var29.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsGroupSize();
//     java.text.DateFormat var6 = null;
//     org.jfree.chart.axis.DateTickUnit var7 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var6);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var10 = var9.getMaximumDate();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var10);
//     java.util.Date var12 = var11.getStart();
//     java.lang.String var13 = var7.dateToString(var12);
//     var0.addBaseTimelineException(var12);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var7);
    java.lang.String var9 = var7.toString();
    boolean var10 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
    org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var13);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var17);
    java.lang.String var19 = var17.toString();
    boolean var20 = var13.isOnOrAfter((org.jfree.data.time.SerialDate)var17);
    boolean var21 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addYears((-435), (org.jfree.data.time.SerialDate)var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "9-January-1900"+ "'", var9.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "9-January-1900"+ "'", var19.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(100.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     java.lang.Number var18 = null;
//     org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var21 = new org.jfree.data.KeyToGroupMap();
//     int var23 = var21.getGroupIndex((java.lang.Comparable)0.0d);
//     int var25 = var21.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var20, var21);
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     var29.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
//     var35.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var39 = var35.getCategoriesForAxis(var38);
//     org.jfree.data.statistics.BoxAndWhiskerItem var40 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)10.0d, (java.lang.Number)0L, (java.lang.Number)(byte)0, (java.lang.Number)1.0E-8d, (java.lang.Number)(byte)1, (java.lang.Number)0, var18, (java.lang.Number)432000000L, var39);
//     boolean var41 = var0.equals((java.lang.Object)0);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    boolean var16 = var14.getBaseShapesFilled();
    boolean var17 = var14.getUseFillPaint();
    boolean var20 = var14.getItemShapeVisible((-435), (-16775247));
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    double var23 = var22.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var25 = var22.getSeriesURLGenerator(0);
    java.awt.Stroke var28 = var22.getItemOutlineStroke(0, (-435));
    double var29 = var22.getUpperClip();
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.axis.ValueAxis)var34, var35);
    org.jfree.chart.axis.ValueAxis var37 = var36.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var38 = null;
    var36.setFixedDomainAxisSpace(var38);
    var36.setDomainCrosshairValue(100.0d);
    var22.addChangeListener((org.jfree.chart.event.RendererChangeListener)var36);
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.Range var45 = var36.getDataRange((org.jfree.chart.axis.ValueAxis)var44);
    java.awt.Stroke var46 = var36.getRangeZeroBaselineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesOutlineStroke((-16777216), var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    org.jfree.chart.event.MarkerChangeEvent var2 = null;
    var0.markerChanged(var2);
    var0.setRadiusGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    var2.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBasePositiveItemLabelPosition(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.setDrawSharedDomainAxis(true);
//     org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var21 = new org.jfree.data.KeyToGroupMap();
//     int var23 = var21.getGroupIndex((java.lang.Comparable)0.0d);
//     int var25 = var21.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var20, var21);
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     var29.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var37 = var36.isDrawBarOutline();
//     int var38 = var35.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     org.jfree.chart.axis.CategoryAxis var40 = var35.getDomainAxisForDataset(100);
//     org.jfree.chart.plot.DatasetRenderingOrder var41 = var35.getDatasetRenderingOrder();
//     var15.setDatasetRenderingOrder(var41);
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0E-8d);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     var10.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.event.RendererChangeEvent var17 = null;
//     var16.rendererChanged(var17);
//     var16.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var21.draw(var22, var23);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var15.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.util.List var19 = var15.getCategoriesForAxis(var18);
    var18.setUpperMargin(1.0d);
    org.jfree.chart.axis.CategoryLabelPositions var22 = var18.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    java.util.List var7 = var0.getColumnKeys();
    int var9 = var0.getRowIndex((java.lang.Comparable)(byte)10);
    org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var17 = var16.isDrawBarOutline();
//     int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
//     org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxisForDataset(100);
//     var15.setRangeCrosshairVisible(false);
//     org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var24 = new org.jfree.data.KeyToGroupMap();
//     int var26 = var24.getGroupIndex((java.lang.Comparable)0.0d);
//     int var28 = var24.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var23, var24);
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
//     var32.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.event.RendererChangeEvent var39 = null;
//     var38.rendererChanged(var39);
//     var38.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var44 = var38.getDomainAxisEdge(10);
//     org.jfree.chart.axis.AxisSpace var45 = var38.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var47 = var46.getDataset();
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var58 = var55.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var59 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var60 = var59.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var62 = var59.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var64 = var63.getAngleGridlinePaint();
//     var59.setBasePaint(var64);
//     org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var54, var58, var64);
//     var46.setAngleGridlineStroke(var58);
//     var38.setRangeCrosshairStroke(var58);
//     org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var71 = null;
//     org.jfree.chart.axis.AxisState var72 = null;
//     java.awt.geom.Rectangle2D var73 = null;
//     org.jfree.chart.util.RectangleEdge var74 = null;
//     java.util.List var75 = var70.refreshTicks(var71, var72, var73, var74);
//     org.jfree.chart.axis.ValueAxis[] var76 = new org.jfree.chart.axis.ValueAxis[] { var70};
//     var38.setRangeAxes(var76);
//     var15.setRangeAxes(var76);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.getSeriesPaint(0);
    int var3 = var0.getColumnCount();
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var5 = new org.jfree.data.KeyToGroupMap();
    int var7 = var5.getGroupIndex((java.lang.Comparable)0.0d);
    int var9 = var5.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var4, var5);
    java.util.List var11 = var4.getColumnKeys();
    int var13 = var4.getRowIndex((java.lang.Comparable)(byte)10);
    org.jfree.data.Range var14 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    java.lang.Comparable var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setValue((java.lang.Number)0, var16, (java.lang.Comparable)"org.jfree.data.UnknownKeyException: ");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("12/31/69", "", var3);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    boolean var12 = var6.isRangeZeroBaselineVisible();
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
    var6.setAxisOffset(var13);
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var18 = var13.createInsetRectangle(var15, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setAutoRangeStickyZero(false);
//     var1.setAxisLineVisible(false);
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var7 = var6.clone();
//     java.awt.Paint var8 = var6.getAngleLabelPaint();
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var15.setFixedDomainAxisSpace(var17);
//     java.awt.Paint var19 = var15.getRangeGridlinePaint();
//     var6.setRadiusGridlinePaint(var19);
//     var1.setPlot((org.jfree.chart.plot.Plot)var6);
//     var6.zoom(0.0d);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var5);
    double var7 = var6.getSeriesRunningTotal();
    org.jfree.chart.plot.PlotRenderingInfo var8 = var6.getInfo();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var17, var18);
    double var20 = var17.getLabelAngle();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var23 = var22.getMaximumDate();
    org.jfree.data.time.Year var24 = new org.jfree.data.time.Year(var23);
    java.util.Date var25 = var24.getStart();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var17.dateToJava2D(var25, var26, var27);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var29 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var34 = var31.getItemLabelPaint(10, 1);
    var31.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
    org.jfree.chart.axis.ValueAxis var44 = var43.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var45 = null;
    var43.setFixedDomainAxisSpace(var45);
    var43.setDomainCrosshairValue(100.0d);
    boolean var49 = var43.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var53 = var50.getItemLabelPaint(10, 1);
    var43.setDomainTickBandPaint(var53);
    var31.addChangeListener((org.jfree.chart.event.RendererChangeListener)var43);
    org.jfree.chart.util.RectangleEdge var57 = var43.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var58 = org.jfree.chart.util.RectangleEdge.opposite(var57);
    boolean var59 = var30.equals((java.lang.Object)var57);
    java.lang.Number var61 = var29.getQ3Value((java.lang.Comparable)var59, (java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var6, var9, var10, var12, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.data.category.CategoryDataset)var29, 10, 1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    boolean var12 = var6.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var16 = var13.getItemLabelPaint(10, 1);
    var6.setDomainTickBandPaint(var16);
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainCrosshairPaint(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("black", var1, var2);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var28);
    org.jfree.chart.axis.ValueAxis var30 = var29.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var31 = null;
    var29.setFixedDomainAxisSpace(var31);
    var29.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var35 = null;
    var29.setDrawingSupplier(var35);
    boolean var37 = var29.isDomainZeroBaselineVisible();
    java.awt.Paint var38 = var29.getRangeTickBandPaint();
    org.jfree.chart.util.RectangleInsets var39 = var29.getAxisOffset();
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    boolean var41 = var40.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.addSubtitle((-16777216), (org.jfree.chart.title.Title)var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var4 = var1.getItemLabelPaint(10, 1);
//     var1.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var12);
//     org.jfree.chart.axis.ValueAxis var14 = var13.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var13.setFixedDomainAxisSpace(var15);
//     var13.setDomainCrosshairValue(100.0d);
//     boolean var19 = var13.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var23 = var20.getItemLabelPaint(10, 1);
//     var13.setDomainTickBandPaint(var23);
//     var1.addChangeListener((org.jfree.chart.event.RendererChangeListener)var13);
//     org.jfree.chart.util.RectangleEdge var27 = var13.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var28 = org.jfree.chart.util.RectangleEdge.opposite(var27);
//     boolean var29 = var0.equals((java.lang.Object)var27);
//     java.util.Calendar var30 = null;
//     long var31 = var0.getLastMillisecond(var30);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = var18.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var18.setFixedDomainAxisSpace(var20);
//     var18.setDomainCrosshairValue(100.0d);
//     boolean var24 = var18.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var28 = var25.getItemLabelPaint(10, 1);
//     var18.setDomainTickBandPaint(var28);
//     var6.setOutlinePaint(var28);
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var34 = var31.getItemLabelPaint(10, 1);
//     var31.setMinimumBarLength(10.0d);
//     java.awt.Paint var37 = var31.getBaseFillPaint();
//     var6.setDomainZeroBaselinePaint(var37);
//     java.awt.Graphics2D var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     var6.drawBackground(var39, var40);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var10 = var8.getSeriesPaint(0);
    java.awt.Font var11 = var8.getBaseItemLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var15 = var12.getItemOutlineStroke((-1), 100);
    var12.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = null;
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var25.refreshTicks(var26, var27, var28, var29);
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var21.drawRangeMarker(var22, var23, (org.jfree.chart.axis.ValueAxis)var25, var31, var32);
    java.awt.Paint var34 = var21.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var38 = var35.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = null;
    org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.axis.AxisState var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    java.util.List var50 = var45.refreshTicks(var46, var47, var48, var49);
    org.jfree.chart.plot.Marker var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    var41.drawRangeMarker(var42, var43, (org.jfree.chart.axis.ValueAxis)var45, var51, var52);
    java.awt.Paint var54 = var41.getWallPaint();
    java.awt.Color var56 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var57 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var34, var38, var54, (java.awt.Paint)var56);
    var12.setBaseOutlinePaint(var54);
    org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("", var11, var54, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-435), var54, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var6);
    java.lang.String var8 = var6.toString();
    boolean var9 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var11);
    org.jfree.chart.block.RectangleConstraint var13 = var12.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.compareTo((java.lang.Object)var13);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "9-January-1900"+ "'", var8.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.chart.axis.DateTickUnit var6 = new org.jfree.chart.axis.DateTickUnit(0, (-16775247));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var7 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, (-1.0d), (-435), (java.lang.Comparable)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    float[] var4 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB((-16775247), 10, 0, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("black", "9-January-1900", var3);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    var0.setSeriesShape(10, var8, false);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
    int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
    int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
    java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
    java.lang.Comparable var21 = null;
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
    org.jfree.chart.axis.ValueAxis var29 = var28.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var30 = null;
    var28.setFixedDomainAxisSpace(var30);
    java.awt.Paint var32 = var28.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var33 = null;
    var28.markerChanged(var33);
    var28.setDomainCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
    var41.setTickMarksVisible(false);
    int var46 = var28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var41);
    var41.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.DateTickUnit var51 = new org.jfree.chart.axis.DateTickUnit(0, 10);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var57);
    double var59 = var56.getLabelAngle();
    boolean var60 = var51.equals((java.lang.Object)var56);
    var41.setTickUnit(var51);
    org.jfree.chart.entity.CategoryItemEntity var62 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var13, var21, (java.lang.Comparable)var51);
    java.awt.Font var64 = null;
    java.awt.Paint var65 = null;
    org.jfree.chart.text.TextMeasurer var67 = null;
    org.jfree.chart.text.TextBlock var68 = org.jfree.chart.text.TextUtilities.createTextBlock("", var64, var65, 0.0f, var67);
    java.awt.Graphics2D var69 = null;
    org.jfree.chart.util.Size2D var70 = var68.calculateDimensions(var69);
    org.jfree.chart.text.TextLine var71 = var68.getLastLine();
    org.jfree.chart.text.TextBlockAnchor var72 = null;
    org.jfree.chart.text.TextAnchor var73 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var75 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)var51, var68, var72, var73, (-7.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var6.setDrawingSupplier(var12);
    boolean var14 = var6.isDomainZeroBaselineVisible();
    java.awt.Paint var15 = var6.getRangeTickBandPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var22 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var23 = var22.getGreen();
    java.awt.Color var24 = var22.darker();
    var19.setWallPaint((java.awt.Paint)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setQuadrantPaint(10, (java.awt.Paint)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.renderer.PolarItemRenderer var1 = null;
//     var0.setRenderer(var1);
//     org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
//     org.jfree.chart.axis.DateTickUnit var6 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var12);
//     double var14 = var11.getLabelAngle();
//     boolean var15 = var6.equals((java.lang.Object)var11);
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.chart.axis.DateTickUnit var19 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var25);
//     double var27 = var24.getLabelAngle();
//     boolean var28 = var19.equals((java.lang.Object)var24);
//     int var29 = var19.getCount();
//     java.util.Date var30 = var11.calculateLowestVisibleTickValue(var19);
//     
//     // Checks the contract:  equals-hashcode on var13 and var26
//     assertTrue("Contract failed: equals-hashcode on var13 and var26", var13.equals(var26) ? var13.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var13
//     assertTrue("Contract failed: equals-hashcode on var26 and var13", var26.equals(var13) ? var26.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
    org.jfree.data.Range var29 = var26.getRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setTextAntiAlias((java.lang.Object)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Font var9 = null;
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var14, var15);
    org.jfree.chart.axis.ValueAxis var17 = var16.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var18 = null;
    var16.setFixedDomainAxisSpace(var18);
    java.awt.Color var21 = java.awt.Color.decode("1969");
    var16.setRangeZeroBaselinePaint((java.awt.Paint)var21);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var21, 0.0f, var24);
    var0.setBaseFillPaint((java.awt.Paint)var21);
    boolean var28 = var21.equals((java.lang.Object)(short)10);
    float[] var30 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var31 = var21.getColorComponents(var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var5 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var6 = var5.getGreen();
    java.awt.Color var7 = var5.darker();
    var2.setWallPaint((java.awt.Paint)var7);
    java.awt.Paint var11 = var2.getItemLabelPaint((-435), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var8.refreshTicks(var9, var10, var11, var12);
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var4.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var14, var15);
    java.awt.Paint var17 = var4.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var21 = var18.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var28.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.plot.Marker var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var24.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var34, var35);
    java.awt.Paint var37 = var24.getWallPaint();
    java.awt.Color var39 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var17, var21, var37, (java.awt.Paint)var39);
    int var41 = var39.getRGB();
    java.awt.Color var42 = var39.brighter();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    java.awt.Paint[] var44 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
    double var46 = var45.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var48 = var45.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var50 = var49.getAngleGridlinePaint();
    var45.setBasePaint(var50);
    java.awt.Paint[] var52 = new java.awt.Paint[] { var50};
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var56 = var53.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var61 = var58.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var62 = new java.awt.Stroke[] { var61};
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var66 = new java.awt.Shape[] { var65};
    org.jfree.chart.plot.DefaultDrawingSupplier var67 = new org.jfree.chart.plot.DefaultDrawingSupplier(var44, var52, var57, var62, var66);
    java.awt.Stroke var68 = var67.getNextOutlineStroke();
    var43.setOutlineStroke(var68);
    java.awt.Paint var70 = var43.getFillPaint();
    var43.setShapeFilled(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var5 = new org.jfree.data.KeyToGroupMap();
    int var7 = var5.getGroupIndex((java.lang.Comparable)0.0d);
    int var9 = var5.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var4, var5);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    var13.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.event.RendererChangeEvent var20 = null;
    var19.rendererChanged(var20);
    var19.clearRangeMarkers(0);
    org.jfree.chart.axis.ValueAxis var25 = var19.getRangeAxis(1);
    java.util.List var26 = var19.getAnnotations();
    org.jfree.data.category.DefaultCategoryDataset var27 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var28 = new org.jfree.data.KeyToGroupMap();
    int var30 = var28.getGroupIndex((java.lang.Comparable)0.0d);
    int var32 = var28.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var27, var28);
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("");
    var36.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    var42.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.util.List var46 = var42.getCategoriesForAxis(var45);
    var45.setUpperMargin(1.0d);
    org.jfree.chart.axis.CategoryLabelPositions var49 = var45.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var52 = var51.getMaximumDate();
    boolean var53 = var51.isPositiveArrowVisible();
    org.jfree.data.category.DefaultCategoryDataset var54 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var55 = new org.jfree.data.KeyToGroupMap();
    int var57 = var55.getGroupIndex((java.lang.Comparable)0.0d);
    int var59 = var55.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var54, var55);
    org.jfree.chart.axis.CategoryAxis var61 = null;
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
    var63.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var54, var61, (org.jfree.chart.axis.ValueAxis)var63, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var3, var19, var45, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.data.category.CategoryDataset)var54, 0, (-16775247), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var7);
    java.lang.String var9 = var7.toString();
    boolean var10 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-435), (org.jfree.data.time.SerialDate)var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "9-January-1900"+ "'", var9.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    boolean var3 = var1.isPositiveArrowVisible();
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setEndType(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var13.refreshTicks(var14, var15, var16, var17);
    org.jfree.chart.plot.Marker var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    var9.drawRangeMarker(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var19, var20);
    java.awt.Paint var22 = var9.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var26 = var23.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.AxisState var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    java.util.List var38 = var33.refreshTicks(var34, var35, var36, var37);
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var29.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, var39, var40);
    java.awt.Paint var42 = var29.getWallPaint();
    java.awt.Color var44 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var22, var26, var42, (java.awt.Paint)var44);
    var0.setBaseOutlinePaint(var42);
    org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var50 = var47.getItemOutlineStroke((-1), 100);
    var0.setBaseStroke(var50);
    double var52 = var0.getBase();
    java.awt.Graphics2D var53 = null;
    org.jfree.data.category.DefaultCategoryDataset var54 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var55 = new org.jfree.data.KeyToGroupMap();
    int var57 = var55.getGroupIndex((java.lang.Comparable)0.0d);
    int var59 = var55.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var54, var55);
    org.jfree.chart.axis.CategoryAxis var61 = null;
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
    var63.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var54, var61, (org.jfree.chart.axis.ValueAxis)var63, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
    var69.clearRangeAxes();
    org.jfree.data.xy.XYDataset var71 = null;
    org.jfree.chart.axis.NumberAxis3D var73 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var75 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
    org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var71, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.chart.axis.ValueAxis)var75, var76);
    org.jfree.chart.axis.ValueAxis var78 = var77.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var79 = null;
    var77.setFixedDomainAxisSpace(var79);
    java.awt.Paint var81 = var77.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var82 = null;
    var77.markerChanged(var82);
    var77.setDomainCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var86 = null;
    org.jfree.chart.axis.NumberAxis3D var88 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var90 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var91 = null;
    org.jfree.chart.plot.XYPlot var92 = new org.jfree.chart.plot.XYPlot(var86, (org.jfree.chart.axis.ValueAxis)var88, (org.jfree.chart.axis.ValueAxis)var90, var91);
    var90.setTickMarksVisible(false);
    int var95 = var77.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var90);
    org.jfree.chart.plot.CategoryMarker var97 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1.05d);
    java.awt.geom.Rectangle2D var98 = null;
    var0.drawRangeMarker(var53, var69, (org.jfree.chart.axis.ValueAxis)var90, (org.jfree.chart.plot.Marker)var97, var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == (-1));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
    org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var5 = var3.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var6 = var3.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.compareTo((java.lang.Object)var6);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var6 = var3.getItemOutlineStroke((-1), 100);
    double var7 = var3.getItemMargin();
    java.awt.Shape var8 = var3.getBaseShape();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    var3.setSeriesShape(10, var11, false);
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var17 = new org.jfree.data.KeyToGroupMap();
    int var19 = var17.getGroupIndex((java.lang.Comparable)0.0d);
    int var21 = var17.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var16, var17);
    java.lang.Number var23 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var16);
    java.lang.Comparable var24 = null;
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = var31.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var33 = null;
    var31.setFixedDomainAxisSpace(var33);
    java.awt.Paint var35 = var31.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var31.markerChanged(var36);
    var31.setDomainCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.axis.ValueAxis)var44, var45);
    var44.setTickMarksVisible(false);
    int var49 = var31.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var44);
    var44.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.DateTickUnit var54 = new org.jfree.chart.axis.DateTickUnit(0, 10);
    org.jfree.data.xy.XYDataset var55 = null;
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var55, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.axis.ValueAxis)var59, var60);
    double var62 = var59.getLabelAngle();
    boolean var63 = var54.equals((java.lang.Object)var59);
    var44.setTickUnit(var54);
    org.jfree.chart.entity.CategoryItemEntity var65 = new org.jfree.chart.entity.CategoryItemEntity(var11, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var16, var24, (java.lang.Comparable)var54);
    var16.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var68 = var0.generateColumnLabel((org.jfree.data.category.CategoryDataset)var16, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var4 = var1.getItemLabelPaint(10, 1);
//     boolean var5 = var1.getAutoPopulateSeriesStroke();
//     java.lang.Object var6 = var1.clone();
//     boolean var7 = var0.equals(var6);
//     org.jfree.data.category.DefaultCategoryDataset var8 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var9 = new org.jfree.data.KeyToGroupMap();
//     int var11 = var9.getGroupIndex((java.lang.Comparable)0.0d);
//     int var13 = var9.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var8, var9);
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     var17.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.event.RendererChangeEvent var24 = null;
//     var23.rendererChanged(var24);
//     var23.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var28 = var23.getFixedLegendItems();
//     org.jfree.chart.axis.CategoryAnchor var29 = var23.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var34 = new org.jfree.data.KeyToGroupMap();
//     int var36 = var34.getGroupIndex((java.lang.Comparable)0.0d);
//     int var38 = var34.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var33, var34);
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     var42.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var47);
//     org.jfree.chart.event.RendererChangeEvent var49 = null;
//     var48.rendererChanged(var49);
//     var48.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var54 = var48.getDomainAxisEdge(10);
//     double var55 = var0.getCategoryJava2DCoordinate(var29, 2, 10, var32, var54);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    boolean var3 = var2.getUseFillPaint();
    var2.setUseOutlinePaint(false);
    java.lang.Object var6 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     double var7 = var4.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var10 = var9.getMaximumDate();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var10);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var14.getItemLabelPaint(10, 1);
//     var14.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var25);
//     org.jfree.chart.axis.ValueAxis var27 = var26.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var26.setFixedDomainAxisSpace(var28);
//     var26.setDomainCrosshairValue(100.0d);
//     boolean var32 = var26.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var36 = var33.getItemLabelPaint(10, 1);
//     var26.setDomainTickBandPaint(var36);
//     var14.addChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     org.jfree.chart.util.RectangleEdge var40 = var26.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var41 = org.jfree.chart.util.RectangleEdge.opposite(var40);
//     double var42 = var4.dateToJava2D(var10, var13, var40);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getNegativeItemLabelPositionFallback();
    double var7 = var0.getMaximumBarWidth();
    var0.setSeriesItemLabelsVisible(0, true);
    java.awt.Stroke var13 = var0.getItemStroke(1, 100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     boolean var20 = var14.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
//     var14.setDomainTickBandPaint(var24);
//     var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
//     boolean var30 = var1.equals((java.lang.Object)var28);
//     java.lang.Number var32 = var0.getQ3Value((java.lang.Comparable)var30, (java.lang.Comparable)'a');
//     double var34 = var0.getRangeLowerBound(true);
//     java.lang.Object var35 = var0.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setAutoRangeStickyZero(false);
//     var1.setAxisLineVisible(false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var13 = var10.getItemLabelPaint(10, 1);
//     var10.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var20, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var22.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var22.setFixedDomainAxisSpace(var24);
//     var22.setDomainCrosshairValue(100.0d);
//     boolean var28 = var22.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var32 = var29.getItemLabelPaint(10, 1);
//     var22.setDomainTickBandPaint(var32);
//     var10.addChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
//     org.jfree.chart.util.RectangleEdge var36 = var22.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var37 = org.jfree.chart.util.RectangleEdge.opposite(var36);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     org.jfree.chart.axis.AxisState var39 = var1.draw(var6, 0.2d, var8, var9, var36, var38);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
    var2.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    boolean var20 = var14.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
    var14.setDomainTickBandPaint(var24);
    var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
    boolean var30 = var1.equals((java.lang.Object)var28);
    java.lang.Number var32 = var0.getQ3Value((java.lang.Comparable)var30, (java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var34 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    boolean var1 = var0.isDrawLines();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-16775247), var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    java.awt.Shape var8 = null;
    var0.setSeriesShape(10, var8);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var11 = new org.jfree.data.KeyToGroupMap();
    int var13 = var11.getGroupIndex((java.lang.Comparable)0.0d);
    int var15 = var11.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var10, var11);
    java.util.List var17 = var10.getColumnKeys();
    int var19 = var10.getRowIndex((java.lang.Comparable)(byte)10);
    org.jfree.data.Range var20 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var10);
    int var21 = var10.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var24 = var10.getValue((-1), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", var3);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var15.handleClick((-435), (-16775247), var24);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    double var7 = var0.getUpperClip();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.Range var23 = var14.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
    java.awt.Stroke var24 = var14.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setDomainAxisLocation((-16777216), var26, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    var0.removeColumn(var1);
    java.lang.Object var5 = var0.getObject((java.lang.Comparable)(-1.0d), (java.lang.Comparable)true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-435), 100, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    boolean var3 = var2.getBaseShapesVisible();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var8 = var5.getItemOutlineStroke((-1), 100);
    var5.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.axis.AxisState var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    java.util.List var23 = var18.refreshTicks(var19, var20, var21, var22);
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var14.drawRangeMarker(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, var24, var25);
    java.awt.Paint var27 = var14.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var31 = var28.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = null;
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.axis.AxisState var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    java.util.List var43 = var38.refreshTicks(var39, var40, var41, var42);
    org.jfree.chart.plot.Marker var44 = null;
    java.awt.geom.Rectangle2D var45 = null;
    var34.drawRangeMarker(var35, var36, (org.jfree.chart.axis.ValueAxis)var38, var44, var45);
    java.awt.Paint var47 = var34.getWallPaint();
    java.awt.Color var49 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var50 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var27, var31, var47, (java.awt.Paint)var49);
    var5.setBaseOutlinePaint(var47);
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var55 = var52.getItemOutlineStroke((-1), 100);
    var5.setBaseStroke(var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var55, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
//     org.jfree.chart.axis.AxisSpace var22 = var15.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var24 = var23.getDataset();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var35 = var32.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var37 = var36.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var36.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var41 = var40.getAngleGridlinePaint();
//     var36.setBasePaint(var41);
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var31, var35, var41);
//     var23.setAngleGridlineStroke(var35);
//     var15.setRangeCrosshairStroke(var35);
//     java.awt.Color var49 = java.awt.Color.getColor("1/1/69", (-16777216));
//     int var50 = var49.getGreen();
//     java.awt.Color var51 = var49.darker();
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var57);
//     org.jfree.chart.axis.ValueAxis var59 = var58.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var60 = null;
//     var58.setFixedDomainAxisSpace(var60);
//     java.awt.Color var63 = java.awt.Color.decode("1969");
//     var58.setRangeZeroBaselinePaint((java.awt.Paint)var63);
//     boolean var65 = var58.isRangeCrosshairLockedOnData();
//     java.awt.Stroke var66 = var58.getDomainCrosshairStroke();
//     org.jfree.chart.LegendItemCollection var67 = new org.jfree.chart.LegendItemCollection();
//     var58.setFixedLegendItems(var67);
//     var58.setBackgroundAlpha(10.0f);
//     org.jfree.chart.plot.PolarPlot var71 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var72 = var71.getDataset();
//     java.awt.Shape var79 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var80 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var83 = var80.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var84 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var85 = var84.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var87 = var84.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var88 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var89 = var88.getAngleGridlinePaint();
//     var84.setBasePaint(var89);
//     org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var79, var83, var89);
//     var71.setAngleGridlineStroke(var83);
//     var58.setDomainCrosshairStroke(var83);
//     org.jfree.chart.plot.CategoryMarker var94 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var51, var83);
//     org.jfree.chart.event.MarkerChangeListener var95 = null;
//     var94.removeChangeListener(var95);
//     org.jfree.chart.util.Layer var97 = null;
//     var15.addRangeMarker((org.jfree.chart.plot.Marker)var94, var97);
//     
//     // Checks the contract:  equals-hashcode on var23 and var71
//     assertTrue("Contract failed: equals-hashcode on var23 and var71", var23.equals(var71) ? var23.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var88
//     assertTrue("Contract failed: equals-hashcode on var40 and var88", var40.equals(var88) ? var40.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var23
//     assertTrue("Contract failed: equals-hashcode on var71 and var23", var71.equals(var23) ? var71.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var40
//     assertTrue("Contract failed: equals-hashcode on var88 and var40", var88.equals(var40) ? var88.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var91
//     assertTrue("Contract failed: equals-hashcode on var43 and var91", var43.equals(var91) ? var43.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var43
//     assertTrue("Contract failed: equals-hashcode on var91 and var43", var91.equals(var43) ? var91.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    java.lang.Comparable var3 = null;
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var7 = var4.getItemOutlineStroke((-1), 100);
    double var8 = var4.getItemMargin();
    java.awt.Shape var9 = var4.getBaseShape();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    var4.setSeriesShape(10, var12, false);
    org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var18 = new org.jfree.data.KeyToGroupMap();
    int var20 = var18.getGroupIndex((java.lang.Comparable)0.0d);
    int var22 = var18.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var17, var18);
    java.lang.Number var24 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var17);
    java.lang.Comparable var25 = null;
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var31);
    org.jfree.chart.axis.ValueAxis var33 = var32.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var34 = null;
    var32.setFixedDomainAxisSpace(var34);
    java.awt.Paint var36 = var32.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var32.markerChanged(var37);
    var32.setDomainCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var41, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.axis.ValueAxis)var45, var46);
    var45.setTickMarksVisible(false);
    int var50 = var32.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
    var45.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.DateTickUnit var55 = new org.jfree.chart.axis.DateTickUnit(0, 10);
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var60, var61);
    double var63 = var60.getLabelAngle();
    boolean var64 = var55.equals((java.lang.Object)var60);
    var45.setTickUnit(var55);
    org.jfree.chart.entity.CategoryItemEntity var66 = new org.jfree.chart.entity.CategoryItemEntity(var12, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var17, var25, (java.lang.Comparable)var55);
    java.lang.Comparable var67 = var66.getColumnKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var68 = var0.getValue(var3, var67);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-16777216), (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getAngleLabelPaint();
    var0.setBaseFillPaint(var7, false);
    boolean var10 = var0.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setAnchorValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    boolean var10 = var7.intersects(1.0d, 0.05d);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    double var13 = var11.constrain(1.0d);
    org.jfree.data.Range var14 = org.jfree.data.Range.combine(var7, (org.jfree.data.Range)var11);
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, 1.0E-8d);
    org.jfree.chart.block.LengthConstraintType var17 = null;
    org.jfree.data.category.DefaultCategoryDataset var19 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var20 = new org.jfree.data.KeyToGroupMap();
    int var22 = var20.getGroupIndex((java.lang.Comparable)0.0d);
    int var24 = var20.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var19, var20);
    boolean var28 = var25.intersects(1.0d, 0.05d);
    org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var30);
    double var32 = var31.getHeight();
    org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var34);
    boolean var38 = var34.intersects(0.0d, 10.0d);
    boolean var41 = var34.intersects(0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var44 = var43.getMaximumDate();
    var43.setTickMarkInsideLength(1.0f);
    boolean var47 = var43.isVisible();
    boolean var48 = var34.equals((java.lang.Object)var47);
    org.jfree.chart.block.RectangleConstraint var49 = var31.toRangeHeight((org.jfree.data.Range)var34);
    org.jfree.chart.block.LengthConstraintType var50 = var49.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(0.05d, var14, var17, 0.2d, var25, var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Comparable var1 = null;
    var0.removeColumn(var1);
    int var3 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getRowKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    org.jfree.data.general.SeriesChangeEvent var3 = null;
    var0.seriesChanged(var3);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var7 = var6.getMaximumDate();
    org.jfree.chart.axis.SegmentedTimeline var8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    var6.setTimeline((org.jfree.chart.axis.Timeline)var8);
    org.jfree.chart.axis.DateTickUnit var10 = var6.getTickUnit();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var0.getValue((java.lang.Comparable)var10, (java.lang.Comparable)0.2d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    var0.setSeriesShape(10, var8, false);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
    int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
    int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
    java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
    java.lang.Comparable var21 = null;
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
    org.jfree.chart.axis.ValueAxis var29 = var28.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var30 = null;
    var28.setFixedDomainAxisSpace(var30);
    java.awt.Paint var32 = var28.getRangeGridlinePaint();
    org.jfree.chart.event.MarkerChangeEvent var33 = null;
    var28.markerChanged(var33);
    var28.setDomainCrosshairVisible(true);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
    var41.setTickMarksVisible(false);
    int var46 = var28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var41);
    var41.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.DateTickUnit var51 = new org.jfree.chart.axis.DateTickUnit(0, 10);
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var57);
    double var59 = var56.getLabelAngle();
    boolean var60 = var51.equals((java.lang.Object)var56);
    var41.setTickUnit(var51);
    org.jfree.chart.entity.CategoryItemEntity var62 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var13, var21, (java.lang.Comparable)var51);
    var13.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var65 = var13.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-435), (-16777216), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     org.jfree.chart.plot.DrawingSupplier var12 = null;
//     var6.setDrawingSupplier(var12);
//     boolean var14 = var6.isDomainZeroBaselineVisible();
//     java.awt.Paint var15 = var6.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleInsets var16 = var6.getAxisOffset();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var21 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var22 = new org.jfree.data.KeyToGroupMap();
//     int var24 = var22.getGroupIndex((java.lang.Comparable)0.0d);
//     int var26 = var22.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var21, var22);
//     org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var20, (org.jfree.data.general.Dataset)var21, (java.lang.Comparable)10L);
//     java.lang.String var32 = var31.getID();
//     var31.setWidth(1.0E-8d);
//     var31.setURLText("DateTickMarkPosition.START");
//     java.lang.Object var37 = var17.draw(var18, var19, (java.lang.Object)var31);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getMinimumArcAngleToDraw();
//     java.awt.Paint var13 = var11.getShadowPaint();
//     org.jfree.data.category.DefaultCategoryDataset var14 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var15 = new org.jfree.data.KeyToGroupMap();
//     int var17 = var15.getGroupIndex((java.lang.Comparable)0.0d);
//     int var19 = var15.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var14, var15);
//     var14.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var14, (-1));
//     var11.setDataset(var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var15
//     assertTrue("Contract failed: equals-hashcode on var1 and var15", var1.equals(var15) ? var1.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var1
//     assertTrue("Contract failed: equals-hashcode on var15 and var1", var15.equals(var1) ? var15.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var12 = var0.generateColumnLabel((org.jfree.data.category.CategoryDataset)var1, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.UnknownKeyException: ");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAxisLinePaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    boolean var3 = var2.getUseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesCreateEntities((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(255, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.awt.Color var3 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var4 = var3.getGreen();
    java.awt.Color var5 = var3.darker();
    java.awt.Paint[] var6 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    double var8 = var7.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var7.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var12 = var11.getAngleGridlinePaint();
    var7.setBasePaint(var12);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var18 = var15.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var20.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
    org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var14, var19, var24, var28);
    java.awt.Stroke var30 = var29.getNextOutlineStroke();
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var35, var36);
    org.jfree.chart.axis.ValueAxis var38 = var37.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var39 = null;
    var37.setFixedDomainAxisSpace(var39);
    java.awt.Paint var41 = var37.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var45 = var42.getItemOutlineStroke((-1), 100);
    var42.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.ItemLabelPosition var48 = var42.getNegativeItemLabelPositionFallback();
    double var49 = var42.getMaximumBarWidth();
    var42.setSeriesItemLabelsVisible(0, true);
    java.awt.Stroke var55 = var42.getItemStroke(1, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)Double.NaN, (java.awt.Paint)var3, var30, var41, var55, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var1 = var0.getMinIcon();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var6 = var3.getItemLabelPaint(10, 1);
//     var3.setMinimumBarLength(10.0d);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var13 = var10.getItemLabelPaint(10, 1);
//     var3.setSeriesPaint(1, var13);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var3.getBasePositiveItemLabelPosition();
//     var0.setSeriesNegativeItemLabelPosition(0, var15);
//     var0.setDrawLines(false);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     boolean var20 = var19.isDrawLines();
//     javax.swing.Icon var21 = var19.getObjectIcon();
//     javax.swing.Icon var22 = var19.getMinIcon();
//     var0.setMinIcon(var22);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var6);
    java.lang.String var8 = var6.toString();
    boolean var9 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var12);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var16);
    java.lang.String var18 = var16.toString();
    boolean var19 = var12.isOnOrAfter((org.jfree.data.time.SerialDate)var16);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var22);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var26);
    java.lang.String var28 = var26.toString();
    boolean var29 = var22.isOnOrAfter((org.jfree.data.time.SerialDate)var26);
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var32);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var36);
    java.lang.String var38 = var36.toString();
    boolean var39 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var36);
    boolean var40 = var22.isOnOrAfter((org.jfree.data.time.SerialDate)var32);
    boolean var41 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var32);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var44);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var48);
    java.lang.String var50 = var48.toString();
    boolean var51 = var44.isOnOrAfter((org.jfree.data.time.SerialDate)var48);
    boolean var53 = var2.isInRange((org.jfree.data.time.SerialDate)var32, (org.jfree.data.time.SerialDate)var44, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var55 = var2.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "9-January-1900"+ "'", var8.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "9-January-1900"+ "'", var18.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "9-January-1900"+ "'", var28.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "9-January-1900"+ "'", var38.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "9-January-1900"+ "'", var50.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("December 2014", "December 2014", var3);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var3 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getValue(255, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     java.awt.Paint var10 = var6.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var6.markerChanged(var11);
//     var6.setDomainCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var20);
//     var19.setTickMarksVisible(false);
//     int var24 = var6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var19);
//     var19.setTickMarkInsideLength(1.0f);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var35 = var32.getItemLabelPaint(10, 1);
//     var32.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = var44.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var46 = null;
//     var44.setFixedDomainAxisSpace(var46);
//     var44.setDomainCrosshairValue(100.0d);
//     boolean var50 = var44.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var54 = var51.getItemLabelPaint(10, 1);
//     var44.setDomainTickBandPaint(var54);
//     var32.addChangeListener((org.jfree.chart.event.RendererChangeListener)var44);
//     org.jfree.chart.util.RectangleEdge var58 = var44.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var59 = org.jfree.chart.util.RectangleEdge.opposite(var58);
//     boolean var60 = var31.equals((java.lang.Object)var58);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.axis.AxisState var62 = var19.draw(var27, 10.0d, var29, var30, var58, var61);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Paint var10 = var6.getRangeGridlinePaint();
    java.awt.Graphics2D var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
    int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
    int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
    java.util.List var20 = var13.getColumnKeys();
    var6.drawDomainTickBands(var11, var12, var20);
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Point2D var25 = null;
    var6.zoomRangeAxes(0.0d, 100.0d, var24, var25);
    org.jfree.data.xy.XYDataset var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDataset((-435), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    boolean var3 = var1.isPositiveArrowVisible();
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var7 = var4.getItemOutlineStroke((-1), 100);
    double var8 = var4.getItemMargin();
    java.awt.Shape var9 = var4.getBaseShape();
    org.jfree.chart.entity.LegendItemEntity var10 = new org.jfree.chart.entity.LegendItemEntity(var9);
    var1.setDownArrow(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4068935));

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getAngleLabelPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomDomainAxes(0.2d, var4, var5);
//     java.lang.Object var7 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    var21.clearSubtitles();
    org.jfree.chart.title.TextTitle var23 = var21.getTitle();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.block.RectangleConstraint var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var26 = var23.arrange(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var3 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getValue(0, (-16777216));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
//     org.jfree.chart.axis.AxisSpace var22 = var15.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var24 = var23.getDataset();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var35 = var32.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var37 = var36.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var36.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var41 = var40.getAngleGridlinePaint();
//     var36.setBasePaint(var41);
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var31, var35, var41);
//     var23.setAngleGridlineStroke(var35);
//     var15.setRangeCrosshairStroke(var35);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.axis.AxisState var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     java.util.List var52 = var47.refreshTicks(var48, var49, var50, var51);
//     org.jfree.chart.axis.ValueAxis[] var53 = new org.jfree.chart.axis.ValueAxis[] { var47};
//     var15.setRangeAxes(var53);
//     org.jfree.data.category.DefaultCategoryDataset var55 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var56 = new org.jfree.data.KeyToGroupMap();
//     int var58 = var56.getGroupIndex((java.lang.Comparable)0.0d);
//     int var60 = var56.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var61 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var55, var56);
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("");
//     var64.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var55, var62, (org.jfree.chart.axis.ValueAxis)var64, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
//     org.jfree.chart.event.RendererChangeEvent var71 = null;
//     var70.rendererChanged(var71);
//     org.jfree.chart.util.RectangleInsets var73 = new org.jfree.chart.util.RectangleInsets();
//     java.lang.String var74 = var73.toString();
//     var70.setAxisOffset(var73);
//     var15.setInsets(var73);
//     
//     // Checks the contract:  equals-hashcode on var1 and var56
//     assertTrue("Contract failed: equals-hashcode on var1 and var56", var1.equals(var56) ? var1.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var1
//     assertTrue("Contract failed: equals-hashcode on var56 and var1", var56.equals(var1) ? var56.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
//     double var13 = var10.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var16 = var15.getMaximumDate();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var16);
//     java.util.Date var18 = var17.getStart();
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var10.dateToJava2D(var18, var19, var20);
//     java.lang.String var22 = var5.dateToString(var18);
//     java.util.Date var23 = null;
//     java.lang.String var24 = var5.dateToString(var23);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     java.lang.String var4 = var3.toString();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getFirstMillisecond(var5);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var8.refreshTicks(var9, var10, var11, var12);
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var4.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var14, var15);
    java.awt.Paint var17 = var4.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var21 = var18.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var28.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.plot.Marker var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var24.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var34, var35);
    java.awt.Paint var37 = var24.getWallPaint();
    java.awt.Color var39 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var17, var21, var37, (java.awt.Paint)var39);
    int var41 = var39.getRGB();
    java.awt.Color var42 = var39.brighter();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    var43.setPadding((-1.0d), (-1.0d), 0.05d, 1.0d);
    org.jfree.data.xy.XYDataset var49 = null;
    org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
    org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var49, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.axis.ValueAxis)var53, var54);
    org.jfree.chart.util.RectangleInsets var56 = var53.getLabelInsets();
    double var58 = var56.calculateBottomInset(0.0d);
    double var60 = var56.trimWidth((-1.0d));
    var43.setMargin(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-7.0d));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    org.jfree.chart.entity.LegendItemEntity var6 = new org.jfree.chart.entity.LegendItemEntity(var5);
    org.jfree.data.general.Dataset var7 = var6.getDataset();
    var6.setSeriesKey((java.lang.Comparable)1.0d);
    java.lang.String var10 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "LegendItemEntity: seriesKey=1.0, dataset=null"+ "'", var10.equals("LegendItemEntity: seriesKey=1.0, dataset=null"));

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = var0.getDataset();
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var7);
//     org.jfree.chart.axis.ValueAxis var9 = var8.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var8.setFixedDomainAxisSpace(var10);
//     java.awt.Color var13 = java.awt.Color.decode("1969");
//     var8.setRangeZeroBaselinePaint((java.awt.Paint)var13);
//     boolean var15 = var8.isRangeCrosshairLockedOnData();
//     java.awt.Stroke var16 = var8.getDomainCrosshairStroke();
//     var0.setAngleGridlineStroke(var16);
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = null;
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.axis.AxisState var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     java.util.List var29 = var24.refreshTicks(var25, var26, var27, var28);
//     org.jfree.chart.plot.Marker var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     var20.drawRangeMarker(var21, var22, (org.jfree.chart.axis.ValueAxis)var24, var30, var31);
//     java.awt.Paint var33 = var20.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var37 = var34.getItemLabelPaint(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = null;
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.axis.AxisState var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     java.util.List var49 = var44.refreshTicks(var45, var46, var47, var48);
//     org.jfree.chart.plot.Marker var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var40.drawRangeMarker(var41, var42, (org.jfree.chart.axis.ValueAxis)var44, var50, var51);
//     java.awt.Paint var53 = var40.getWallPaint();
//     java.awt.Color var55 = java.awt.Color.decode("1969");
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var56 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var33, var37, var53, (java.awt.Paint)var55);
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var60 = var57.getItemOutlineStroke((-1), 100);
//     var57.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.plot.CategoryPlot var63 = var57.getPlot();
//     boolean var64 = var57.getBaseSeriesVisibleInLegend();
//     java.awt.Font var66 = null;
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.NumberAxis3D var69 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var67, (org.jfree.chart.axis.ValueAxis)var69, (org.jfree.chart.axis.ValueAxis)var71, var72);
//     org.jfree.chart.axis.ValueAxis var74 = var73.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var75 = null;
//     var73.setFixedDomainAxisSpace(var75);
//     java.awt.Color var78 = java.awt.Color.decode("1969");
//     var73.setRangeZeroBaselinePaint((java.awt.Paint)var78);
//     org.jfree.chart.text.TextMeasurer var81 = null;
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("", var66, (java.awt.Paint)var78, 0.0f, var81);
//     var57.setBaseFillPaint((java.awt.Paint)var78);
//     boolean var85 = var78.equals((java.lang.Object)(short)10);
//     org.jfree.chart.block.BlockBorder var86 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var78);
//     var56.setBaseItemLabelPaint((java.awt.Paint)var78);
//     var0.setAngleGridlinePaint((java.awt.Paint)var78);
//     
//     // Checks the contract:  equals-hashcode on var8 and var73
//     assertTrue("Contract failed: equals-hashcode on var8 and var73", var8.equals(var73) ? var8.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var8
//     assertTrue("Contract failed: equals-hashcode on var73 and var8", var73.equals(var8) ? var73.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("9-January-1900", var1, var2);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 100.0d, (-1.0d), 0.0d);
    double var5 = var4.getBottom();
    double var7 = var4.calculateBottomInset(1.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    boolean var16 = var14.getBaseShapesFilled();
    boolean var17 = var14.getUseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesShapesVisible((-16775247), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    org.jfree.data.general.SeriesChangeEvent var3 = null;
    var0.seriesChanged(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getStartValue(255, (-435));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var3 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getRowKey((-16775247));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var6.refreshTicks(var7, var8, var9, var10);
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var12, var13);
    java.awt.Paint var15 = var2.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var19 = var16.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = null;
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.axis.AxisState var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    java.util.List var31 = var26.refreshTicks(var27, var28, var29, var30);
    org.jfree.chart.plot.Marker var32 = null;
    java.awt.geom.Rectangle2D var33 = null;
    var22.drawRangeMarker(var23, var24, (org.jfree.chart.axis.ValueAxis)var26, var32, var33);
    java.awt.Paint var35 = var22.getWallPaint();
    java.awt.Color var37 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var38 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var15, var19, var35, (java.awt.Paint)var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var38.setSeriesVisibleInLegend((-16775247), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
//     org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var6 = var5.clone();
//     java.awt.Stroke var7 = var5.getOutlineStroke();
//     var1.setAxisLineStroke(var7);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var16);
//     org.jfree.chart.axis.ValueAxis var18 = var17.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var19 = null;
//     var17.setFixedDomainAxisSpace(var19);
//     java.awt.Paint var21 = var17.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var22 = null;
//     var17.markerChanged(var22);
//     int var24 = var17.getSeriesCount();
//     org.jfree.chart.util.RectangleEdge var26 = var17.getRangeAxisEdge(100);
//     double var27 = var1.java2DToValue(0.5d, var10, var26);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2, (-435), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    java.awt.Color var1 = java.awt.Color.getColor("1/1/69");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var15 = var12.getItemLabelPaint(10, 1);
//     var11.setLabelOutlinePaint(var15);
//     var11.setLabelLinksVisible(false);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     org.jfree.chart.plot.PlotState var22 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var23 = var22.getSharedAxisStates();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var11.draw(var19, var20, var21, var22, var24);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxisForDataset(100);
    org.jfree.chart.plot.DatasetRenderingOrder var21 = var15.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisSpace var22 = var15.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisSpace var23 = var15.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    int var22 = var21.getSubtitleCount();
    float var23 = var21.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisState var24 = new org.jfree.chart.axis.AxisState();
    var24.cursorDown(10.0d);
    var24.setCursor((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setTextAntiAlias((java.lang.Object)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
//     java.util.Date var4 = var3.getStart();
//     long var5 = var3.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-31507200000L));
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var5 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var6 = var5.getGreen();
    java.awt.Color var7 = var5.darker();
    var2.setWallPaint((java.awt.Paint)var7);
    org.jfree.chart.plot.CategoryPlot var9 = var2.getPlot();
    java.awt.Paint var10 = var2.getWallPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     var15.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var19 = var15.getCategoriesForAxis(var18);
//     var18.setUpperMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var22 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var30 = var27.getItemLabelPaint(10, 1);
//     var27.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var37, var38);
//     org.jfree.chart.axis.ValueAxis var40 = var39.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var41 = null;
//     var39.setFixedDomainAxisSpace(var41);
//     var39.setDomainCrosshairValue(100.0d);
//     boolean var45 = var39.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var49 = var46.getItemLabelPaint(10, 1);
//     var39.setDomainTickBandPaint(var49);
//     var27.addChangeListener((org.jfree.chart.event.RendererChangeListener)var39);
//     org.jfree.chart.util.RectangleEdge var53 = var39.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var54 = org.jfree.chart.util.RectangleEdge.opposite(var53);
//     boolean var55 = var26.equals((java.lang.Object)var53);
//     double var56 = var18.getCategoryJava2DCoordinate(var22, 1, (-16777216), var25, var53);
//     java.text.DateFormat var61 = null;
//     org.jfree.chart.axis.DateTickUnit var62 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var61);
//     org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var65 = var64.getMaximumDate();
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year(var65);
//     java.util.Date var67 = var66.getStart();
//     java.lang.String var68 = var62.dateToString(var67);
//     var18.removeCategoryLabelToolTip((java.lang.Comparable)var68);
//     int var70 = var18.getMaximumCategoryLabelLines();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var68 + "' != '" + "1/1/69"+ "'", var68.equals("1/1/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.UnknownKeyException: ");

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     java.lang.String var1 = var0.toString();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     java.awt.Paint var8 = var2.getBaseFillPaint();
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(var0, var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var9.draw(var10, var11);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setFixedDimension(1.0d);
    org.jfree.chart.axis.DateTickMarkPosition var4 = var1.getTickMarkPosition();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = null;
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var13.refreshTicks(var14, var15, var16, var17);
    org.jfree.chart.plot.Marker var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    var9.drawRangeMarker(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var19, var20);
    java.awt.Paint var22 = var9.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var26 = var23.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.AxisState var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    java.util.List var38 = var33.refreshTicks(var34, var35, var36, var37);
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var29.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, var39, var40);
    java.awt.Paint var42 = var29.getWallPaint();
    java.awt.Color var44 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var45 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var22, var26, var42, (java.awt.Paint)var44);
    int var46 = var44.getRGB();
    java.awt.Color var47 = var44.brighter();
    org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic(var6, (java.awt.Paint)var44);
    java.awt.Paint[] var49 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    double var51 = var50.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var53 = var50.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var55 = var54.getAngleGridlinePaint();
    var50.setBasePaint(var55);
    java.awt.Paint[] var57 = new java.awt.Paint[] { var55};
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var61 = var58.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var62 = new java.awt.Stroke[] { var61};
    org.jfree.chart.renderer.category.BarRenderer var63 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var66 = var63.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var67 = new java.awt.Stroke[] { var66};
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var71 = new java.awt.Shape[] { var70};
    org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var49, var57, var62, var67, var71);
    java.awt.Stroke var73 = var72.getNextOutlineStroke();
    var48.setOutlineStroke(var73);
    java.awt.Paint var75 = var48.getFillPaint();
    boolean var76 = var4.equals((java.lang.Object)var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.05d, 0.5d, 0.05d, 0.5d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var1 = var0.toString();
    double var3 = var0.calculateTopOutset(0.0d);
    double var5 = var0.calculateLeftOutset(0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     var15.clearRangeAxes();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(10);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var19);
//     java.lang.String var21 = var19.toString();
//     boolean var22 = var15.equals((java.lang.Object)var19);
//     java.awt.Paint var23 = var15.getRangeGridlinePaint();
//     org.jfree.data.category.DefaultCategoryDataset var24 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var25 = new org.jfree.data.KeyToGroupMap();
//     int var27 = var25.getGroupIndex((java.lang.Comparable)0.0d);
//     int var29 = var25.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var24, var25);
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
//     var33.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.event.RendererChangeEvent var40 = null;
//     var39.rendererChanged(var40);
//     var39.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var44 = var39.getFixedLegendItems();
//     org.jfree.chart.axis.CategoryAnchor var45 = var39.getDomainGridlinePosition();
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var47 = var46.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var49 = var46.getSeriesURLGenerator(0);
//     java.awt.Stroke var52 = var46.getItemOutlineStroke(0, (-435));
//     double var53 = var46.getUpperClip();
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var54, (org.jfree.chart.axis.ValueAxis)var56, (org.jfree.chart.axis.ValueAxis)var58, var59);
//     org.jfree.chart.axis.ValueAxis var61 = var60.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var62 = null;
//     var60.setFixedDomainAxisSpace(var62);
//     var60.setDomainCrosshairValue(100.0d);
//     var46.addChangeListener((org.jfree.chart.event.RendererChangeListener)var60);
//     org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.data.Range var69 = var60.getDataRange((org.jfree.chart.axis.ValueAxis)var68);
//     java.awt.Stroke var70 = var60.getRangeZeroBaselineStroke();
//     org.jfree.chart.axis.NumberAxis3D var72 = new org.jfree.chart.axis.NumberAxis3D("");
//     var72.setAutoRangeStickyZero(false);
//     org.jfree.chart.util.RectangleInsets var75 = new org.jfree.chart.util.RectangleInsets();
//     var72.setLabelInsets(var75);
//     org.jfree.chart.axis.NumberTickUnit var77 = var72.getTickUnit();
//     var60.setDomainAxis((org.jfree.chart.axis.ValueAxis)var72);
//     boolean var79 = var45.equals((java.lang.Object)var72);
//     org.jfree.chart.block.BlockBorder var84 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleInsets var85 = var84.getInsets();
//     boolean var86 = var45.equals((java.lang.Object)var85);
//     var15.setDomainGridlinePosition(var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
//     java.util.List var5 = var3.getExceptionSegments();
//     long var7 = var3.toTimelineValue(0L);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var10 = var9.getMaximumDate();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var10);
//     long var12 = var3.getTime(var10);
//     org.jfree.data.gantt.TaskSeriesCollection var13 = new org.jfree.data.gantt.TaskSeriesCollection();
//     int var15 = var13.getRowIndex((java.lang.Comparable)(short)(-1));
//     java.util.List var16 = var13.getColumnKeys();
//     java.util.List var17 = var13.getColumnKeys();
//     var3.setExceptionSegments(var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       boolean var21 = var3.containsDomainRange(1577894400000L, 432000000L);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1577894400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("12/31/69", "9-January-1900", "12/31/69");
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var6 = var4.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var7 = var4.getColumnKeys();
    java.util.List var8 = var4.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var3.generateURL((org.jfree.data.category.CategoryDataset)var4, 0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    double var7 = var0.getUpperClip();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.Range var23 = var14.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
    java.awt.Stroke var24 = var14.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
    var26.setAutoRangeStickyZero(false);
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets();
    var26.setLabelInsets(var29);
    org.jfree.chart.axis.NumberTickUnit var31 = var26.getTickUnit();
    var14.setDomainAxis((org.jfree.chart.axis.ValueAxis)var26);
    org.jfree.chart.axis.DateTickUnit var35 = new org.jfree.chart.axis.DateTickUnit(0, 10);
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var40, var41);
    double var43 = var40.getLabelAngle();
    boolean var44 = var35.equals((java.lang.Object)var40);
    int var45 = var14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var40);
    org.jfree.chart.axis.AxisSpace var46 = var14.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var7);
    org.jfree.chart.util.RectangleInsets var9 = var6.getLabelInsets();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var12 = var11.getMaximumDate();
    var11.setVerticalTickLabels(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, var15);
    org.jfree.chart.axis.AxisLocation var18 = var16.getDomainAxisLocation(0);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var22 = var21.getMaximumDate();
    var21.zoomRange(0.0d, 1.0d);
    org.jfree.data.category.DefaultCategoryDataset var26 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var27 = new org.jfree.data.KeyToGroupMap();
    int var29 = var27.getGroupIndex((java.lang.Comparable)0.0d);
    int var31 = var27.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26, var27);
    var21.setRange(var32);
    var21.setLabel("hi!");
    boolean var36 = var19.equals((java.lang.Object)"hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     long var2 = var0.getStartTime();
//     var0.addBaseTimelineExclusions(100L, 1577894400000L);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("1969", var1);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    double var2 = var1.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var1.getSeriesURLGenerator(0);
    java.awt.Stroke var7 = var1.getItemOutlineStroke(0, (-435));
    double var8 = var1.getUpperClip();
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var15.setFixedDomainAxisSpace(var17);
    var15.setDomainCrosshairValue(100.0d);
    var1.addChangeListener((org.jfree.chart.event.RendererChangeListener)var15);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.Range var24 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var23);
    java.awt.Stroke var25 = var15.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
    var27.setAutoRangeStickyZero(false);
    org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets();
    var27.setLabelInsets(var30);
    org.jfree.chart.axis.NumberTickUnit var32 = var27.getTickUnit();
    var15.setDomainAxis((org.jfree.chart.axis.ValueAxis)var27);
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var27, var34);
    boolean var36 = var35.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var15 = var12.getItemLabelPaint(10, 1);
//     var11.setLabelOutlinePaint(var15);
//     java.awt.Paint var17 = var11.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var18 = var11.getLegendItems();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var22 = var19.getItemOutlineStroke((-1), 100);
//     double var23 = var19.getItemMargin();
//     java.awt.Shape var24 = var19.getBaseShape();
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     var19.setSeriesShape(10, var27, false);
//     org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var33 = new org.jfree.data.KeyToGroupMap();
//     int var35 = var33.getGroupIndex((java.lang.Comparable)0.0d);
//     int var37 = var33.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var32, var33);
//     java.lang.Number var39 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var32);
//     java.lang.Comparable var40 = null;
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var41, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.axis.ValueAxis)var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = var47.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var49 = null;
//     var47.setFixedDomainAxisSpace(var49);
//     java.awt.Paint var51 = var47.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var52 = null;
//     var47.markerChanged(var52);
//     var47.setDomainCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var60, var61);
//     var60.setTickMarksVisible(false);
//     int var65 = var47.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var60);
//     var60.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.DateTickUnit var70 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var71 = null;
//     org.jfree.chart.axis.NumberAxis3D var73 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var75 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var71, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.chart.axis.ValueAxis)var75, var76);
//     double var78 = var75.getLabelAngle();
//     boolean var79 = var70.equals((java.lang.Object)var75);
//     var60.setTickUnit(var70);
//     org.jfree.chart.entity.CategoryItemEntity var81 = new org.jfree.chart.entity.CategoryItemEntity(var27, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var32, var40, (java.lang.Comparable)var70);
//     java.lang.Comparable var82 = var81.getColumnKey();
//     var11.setExplodePercent(var82, (-1.0d));
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var19.", var12.equals(var19) == var19.equals(var12));
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var0.getBaseItemLabelGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-4068935), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getAngleLabelPaint();
    var0.setBaseFillPaint(var7, false);
    var0.setAutoPopulateSeriesStroke(true);
    java.awt.Paint var13 = var0.lookupSeriesOutlinePaint(1);
    var0.setBaseItemLabelsVisible(false, true);
    org.jfree.chart.plot.DrawingSupplier var17 = var0.getDrawingSupplier();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var0.setBaseItemLabelGenerator(var18, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var6 = var3.getItemLabelPaint(10, 1);
    var3.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var15.setFixedDomainAxisSpace(var17);
    var15.setDomainCrosshairValue(100.0d);
    boolean var21 = var15.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var25 = var22.getItemLabelPaint(10, 1);
    var15.setDomainTickBandPaint(var25);
    var3.addChangeListener((org.jfree.chart.event.RendererChangeListener)var15);
    org.jfree.chart.util.RectangleEdge var29 = var15.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    org.jfree.chart.axis.CategoryLabelPosition var31 = var2.getLabelPosition(var29);
    org.jfree.chart.text.TextAnchor var32 = var31.getRotationAnchor();
    org.jfree.chart.text.TextBlockAnchor var33 = var31.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var34 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var7);
    java.lang.String var9 = var7.toString();
    boolean var10 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-435), (org.jfree.data.time.SerialDate)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "9-January-1900"+ "'", var9.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    var4.setUpArrow(var11);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-16777216), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    var1.setAxisLineVisible(false);
    var1.setTickMarkOutsideLength(100.0f);
    java.text.NumberFormat var8 = var1.getNumberFormatOverride();
    org.jfree.chart.util.RectangleInsets var9 = var1.getLabelInsets();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.LengthAdjustmentType var11 = null;
    org.jfree.chart.util.LengthAdjustmentType var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var13 = var9.createAdjustedRectangle(var10, var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    double var7 = var0.getUpperClip();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedDomainAxisSpace(var16);
    var14.setDomainCrosshairValue(100.0d);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = var27.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var29 = null;
    var27.setFixedDomainAxisSpace(var29);
    java.awt.Color var32 = java.awt.Color.decode("1969");
    var27.setRangeZeroBaselinePaint((java.awt.Paint)var32);
    var14.setDomainTickBandPaint((java.awt.Paint)var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var36 = var14.getRangeAxisForDataset(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
//     java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
//     java.awt.Shape var8 = null;
//     var0.setSeriesShape(10, var8);
//     org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var11 = new org.jfree.data.KeyToGroupMap();
//     int var13 = var11.getGroupIndex((java.lang.Comparable)0.0d);
//     int var15 = var11.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var10, var11);
//     java.util.List var17 = var10.getColumnKeys();
//     int var19 = var10.getRowIndex((java.lang.Comparable)(byte)10);
//     org.jfree.data.Range var20 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var10);
//     org.jfree.chart.urls.CategoryURLGenerator var23 = var0.getURLGenerator((-16777216), 1);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var29, var30);
//     org.jfree.chart.axis.ValueAxis var32 = var31.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var33 = null;
//     var31.setFixedDomainAxisSpace(var33);
//     var31.setDomainCrosshairValue(100.0d);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = var43.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var43.setFixedDomainAxisSpace(var45);
//     var43.setDomainCrosshairValue(100.0d);
//     boolean var49 = var43.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var53 = var50.getItemLabelPaint(10, 1);
//     var43.setDomainTickBandPaint(var53);
//     var31.setOutlinePaint(var53);
//     var0.setSeriesPaint(100, var53);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var50 and var0.", var50.equals(var0) == var0.equals(var50));
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    double var2 = var1.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var1.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var6 = var5.getAngleGridlinePaint();
    var1.setBasePaint(var6);
    java.awt.Paint[] var8 = new java.awt.Paint[] { var6};
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var12 = var9.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var17 = var14.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var8, var13, var18, var22);
    java.awt.Shape var24 = var23.getNextShape();
    org.jfree.chart.util.RectangleAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, var25, 90.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("black");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var1 = var0.getAngleGridlinePaint();
//     var0.zoom(1.0E-5d);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     boolean var20 = var14.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
//     var14.setDomainTickBandPaint(var24);
//     var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
//     boolean var30 = var1.equals((java.lang.Object)var28);
//     java.lang.Number var32 = var0.getQ3Value((java.lang.Comparable)var30, (java.lang.Comparable)'a');
//     double var34 = var0.getRangeLowerBound(true);
//     java.lang.Number var41 = null;
//     org.jfree.data.category.DefaultCategoryDataset var43 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var44 = new org.jfree.data.KeyToGroupMap();
//     int var46 = var44.getGroupIndex((java.lang.Comparable)0.0d);
//     int var48 = var44.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var43, var44);
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("");
//     var52.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var43, var50, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     var58.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var62 = var58.getCategoriesForAxis(var61);
//     org.jfree.data.statistics.BoxAndWhiskerItem var63 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)10.0d, (java.lang.Number)0L, (java.lang.Number)(byte)0, (java.lang.Number)1.0E-8d, (java.lang.Number)(byte)1, (java.lang.Number)0, var41, (java.lang.Number)432000000L, var62);
//     java.lang.Comparable var64 = null;
//     java.lang.Comparable var65 = null;
//     var0.add(var63, var64, var65);
//     java.lang.Comparable var68 = null;
//     java.lang.Number var69 = var0.getMinOutlier((java.lang.Comparable)0.2d, var68);
//     java.text.DateFormat var75 = null;
//     org.jfree.chart.axis.DateTickUnit var76 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var75);
//     org.jfree.chart.axis.DateAxis var78 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var79 = var78.getMaximumDate();
//     java.lang.String var80 = var76.dateToString(var79);
//     org.jfree.chart.axis.SegmentedTimeline var81 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var82 = var81.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var84 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var85 = var84.getMaximumDate();
//     long var86 = var81.toTimelineValue(var85);
//     org.jfree.data.time.SimpleTimePeriod var87 = new org.jfree.data.time.SimpleTimePeriod(var79, var85);
//     org.jfree.data.time.SimpleTimePeriod var90 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
//     java.util.Date var91 = var90.getEnd();
//     int var92 = var87.compareTo((java.lang.Object)var90);
//     java.lang.Number var93 = var0.getQ1Value((java.lang.Comparable)2, (java.lang.Comparable)var92);
//     org.jfree.data.Range var95 = var0.getRangeBounds(false);
//     
//     // Checks the contract:  var95.equals(var95)
//     assertTrue("Contract failed: var95.equals(var95)", var95.equals(var95));
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var9.getItemLabelPaint(10, 1);
//     var2.setSeriesPaint(1, var12);
//     org.jfree.chart.labels.ItemLabelPosition var14 = var2.getBasePositiveItemLabelPosition();
//     var0.setBasePositiveItemLabelPosition(var14, false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var21 = var20.getDataset();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var32 = var29.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var34 = var33.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var36 = var33.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var38 = var37.getAngleGridlinePaint();
//     var33.setBasePaint(var38);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var28, var32, var38);
//     var20.setAngleGridlineStroke(var32);
//     java.awt.Font var42 = var20.getAngleLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = null;
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.AxisState var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     java.util.List var54 = var49.refreshTicks(var50, var51, var52, var53);
//     org.jfree.chart.plot.Marker var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     var45.drawRangeMarker(var46, var47, (org.jfree.chart.axis.ValueAxis)var49, var55, var56);
//     java.awt.Paint var58 = var45.getWallPaint();
//     org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("December 2014", var42, var58, 100.0f);
//     var0.setSeriesPaint(1, var58, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var0.", var29.equals(var0) == var0.equals(var29));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object[][] var1 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var3 = var0.getStringArray("org.jfree.data.UnknownKeyException: ");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(10);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getPercentComplete((java.lang.Comparable)432000000L, (java.lang.Comparable)var6, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var1 = var0.getSegmentsIncludedSize();
    var0.addException(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 432000000L);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    var1.setAxisLineVisible(false);
    var1.setTickMarkOutsideLength(100.0f);
    var1.setTickMarkOutsideLength(0.0f);
    var1.setVerticalTickLabels(true);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var1 = var0.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    var12.setDomainCrosshairValue(100.0d);
    boolean var18 = var12.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var19.getItemLabelPaint(10, 1);
    var12.setDomainTickBandPaint(var22);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    org.jfree.chart.axis.AxisSpace var25 = var12.getFixedRangeAxisSpace();
    var12.setBackgroundAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getPercentComplete(1, (-4068935));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    java.awt.Color var3 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var4 = var3.getGreen();
    java.awt.Color var5 = var3.darker();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    java.awt.Color var17 = java.awt.Color.decode("1969");
    var12.setRangeZeroBaselinePaint((java.awt.Paint)var17);
    boolean var19 = var12.isRangeCrosshairLockedOnData();
    java.awt.Stroke var20 = var12.getDomainCrosshairStroke();
    org.jfree.chart.LegendItemCollection var21 = new org.jfree.chart.LegendItemCollection();
    var12.setFixedLegendItems(var21);
    var12.setBackgroundAlpha(10.0f);
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var26 = var25.getDataset();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var37 = var34.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var41 = var38.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var43 = var42.getAngleGridlinePaint();
    var38.setBasePaint(var43);
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var33, var37, var43);
    var25.setAngleGridlineStroke(var37);
    var12.setDomainCrosshairStroke(var37);
    org.jfree.chart.plot.CategoryMarker var48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var37);
    java.awt.Paint var49 = var48.getPaint();
    org.jfree.chart.axis.CategoryLabelPositions var51 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var55 = var52.getItemLabelPaint(10, 1);
    var52.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.axis.ValueAxis)var62, var63);
    org.jfree.chart.axis.ValueAxis var65 = var64.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var66 = null;
    var64.setFixedDomainAxisSpace(var66);
    var64.setDomainCrosshairValue(100.0d);
    boolean var70 = var64.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var71 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var74 = var71.getItemLabelPaint(10, 1);
    var64.setDomainTickBandPaint(var74);
    var52.addChangeListener((org.jfree.chart.event.RendererChangeListener)var64);
    org.jfree.chart.util.RectangleEdge var78 = var64.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var79 = org.jfree.chart.util.RectangleEdge.opposite(var78);
    org.jfree.chart.axis.CategoryLabelPosition var80 = var51.getLabelPosition(var78);
    org.jfree.chart.text.TextAnchor var81 = var80.getRotationAnchor();
    var48.setLabelTextAnchor(var81);
    org.jfree.data.xy.XYDataset var83 = null;
    org.jfree.chart.axis.NumberAxis3D var85 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var87 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var88 = null;
    org.jfree.chart.plot.XYPlot var89 = new org.jfree.chart.plot.XYPlot(var83, (org.jfree.chart.axis.ValueAxis)var85, (org.jfree.chart.axis.ValueAxis)var87, var88);
    org.jfree.chart.axis.ValueAxis var90 = var89.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var91 = null;
    var89.setFixedDomainAxisSpace(var91);
    var89.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var95 = null;
    var89.setDrawingSupplier(var95);
    java.awt.Stroke var97 = var89.getDomainCrosshairStroke();
    var48.setOutlineStroke(var97);
    boolean var99 = var48.getDrawAsLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var5 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var6 = var5.getGreen();
    java.awt.Color var7 = var5.darker();
    var2.setWallPaint((java.awt.Paint)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var15.refreshTicks(var16, var17, var18, var19);
    org.jfree.chart.plot.Marker var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    var11.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var21, var22);
    java.awt.Paint var24 = var11.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var28 = var25.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = null;
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.axis.AxisState var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    java.util.List var40 = var35.refreshTicks(var36, var37, var38, var39);
    org.jfree.chart.plot.Marker var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    var31.drawRangeMarker(var32, var33, (org.jfree.chart.axis.ValueAxis)var35, var41, var42);
    java.awt.Paint var44 = var31.getWallPaint();
    java.awt.Color var46 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var47 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var24, var28, var44, (java.awt.Paint)var46);
    java.awt.Paint var48 = var47.getNegativeBarPaint();
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var52 = var49.getItemLabelPaint(10, 1);
    var49.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var59 = var56.getItemLabelPaint(10, 1);
    var49.setSeriesPaint(1, var59);
    org.jfree.chart.block.LineBorder var61 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var62 = var61.getPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var63 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint)var7, var48, var59, var62);
    float[] var66 = new float[] { 10.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var67 = var7.getRGBColorComponents(var66);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.clearRangeMarkers(0);
    org.jfree.chart.axis.ValueAxis var21 = var15.getRangeAxisForDataset(0);
    var21.resizeRange((-7.0d), 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    var6.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "", "", "");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    java.lang.String var9 = var7.getInfo();
    var7.setLicenceText("WMAP_Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     java.lang.String var1 = var0.toString();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     java.awt.Paint var8 = var2.getBaseFillPaint();
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(var0, var8);
//     double var11 = var0.calculateRightInset(0.0d);
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.trim(var12);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getMinimumArcAngleToDraw();
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var16 = var13.getItemOutlineStroke((-1), 100);
//     double var17 = var13.getItemMargin();
//     java.awt.Shape var18 = var13.getBaseShape();
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     var13.setSeriesShape(10, var21, false);
//     org.jfree.data.category.DefaultCategoryDataset var26 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var27 = new org.jfree.data.KeyToGroupMap();
//     int var29 = var27.getGroupIndex((java.lang.Comparable)0.0d);
//     int var31 = var27.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26, var27);
//     java.lang.Number var33 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var26);
//     java.lang.Comparable var34 = null;
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var39, var40);
//     org.jfree.chart.axis.ValueAxis var42 = var41.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var43 = null;
//     var41.setFixedDomainAxisSpace(var43);
//     java.awt.Paint var45 = var41.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var46 = null;
//     var41.markerChanged(var46);
//     var41.setDomainCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var50, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.axis.ValueAxis)var54, var55);
//     var54.setTickMarksVisible(false);
//     int var59 = var41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var54);
//     var54.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.DateTickUnit var64 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.NumberAxis3D var67 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var69 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var70 = null;
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.axis.ValueAxis)var69, var70);
//     double var72 = var69.getLabelAngle();
//     boolean var73 = var64.equals((java.lang.Object)var69);
//     var54.setTickUnit(var64);
//     org.jfree.chart.entity.CategoryItemEntity var75 = new org.jfree.chart.entity.CategoryItemEntity(var21, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var26, var34, (java.lang.Comparable)var64);
//     int var76 = var64.getCount();
//     java.awt.Paint var77 = var11.getSectionOutlinePaint((java.lang.Comparable)var64);
//     
//     // Checks the contract:  equals-hashcode on var1 and var27
//     assertTrue("Contract failed: equals-hashcode on var1 and var27", var1.equals(var27) ? var1.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var1
//     assertTrue("Contract failed: equals-hashcode on var27 and var1", var27.equals(var1) ? var27.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var5 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var6 = var5.getGreen();
    java.awt.Color var7 = var5.darker();
    var2.setWallPaint((java.awt.Paint)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = null;
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var15.refreshTicks(var16, var17, var18, var19);
    org.jfree.chart.plot.Marker var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    var11.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var21, var22);
    java.awt.Paint var24 = var11.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var28 = var25.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = null;
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.axis.AxisState var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    java.util.List var40 = var35.refreshTicks(var36, var37, var38, var39);
    org.jfree.chart.plot.Marker var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    var31.drawRangeMarker(var32, var33, (org.jfree.chart.axis.ValueAxis)var35, var41, var42);
    java.awt.Paint var44 = var31.getWallPaint();
    java.awt.Color var46 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var47 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var24, var28, var44, (java.awt.Paint)var46);
    java.awt.Paint var48 = var47.getNegativeBarPaint();
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var52 = var49.getItemLabelPaint(10, 1);
    var49.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var59 = var56.getItemLabelPaint(10, 1);
    var49.setSeriesPaint(1, var59);
    org.jfree.chart.block.LineBorder var61 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var62 = var61.getPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var63 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint)var7, var48, var59, var62);
    java.lang.String var64 = org.jfree.chart.util.PaintUtilities.colorToString(var7);
    float[] var67 = new float[] { 0.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var68 = var7.getRGBColorComponents(var67);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + "black"+ "'", var64.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.AxisState var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    java.util.List var14 = var9.refreshTicks(var10, var11, var12, var13);
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var5.drawRangeMarker(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var15, var16);
    java.awt.Paint var18 = var5.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var19.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = null;
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.axis.AxisState var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    java.util.List var34 = var29.refreshTicks(var30, var31, var32, var33);
    org.jfree.chart.plot.Marker var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    var25.drawRangeMarker(var26, var27, (org.jfree.chart.axis.ValueAxis)var29, var35, var36);
    java.awt.Paint var38 = var25.getWallPaint();
    java.awt.Color var40 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var41 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var18, var22, var38, (java.awt.Paint)var40);
    java.awt.Paint var42 = var41.getNegativeBarPaint();
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.axis.ValueAxis)var47, var48);
    org.jfree.chart.axis.ValueAxis var50 = var49.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var51 = null;
    var49.setFixedDomainAxisSpace(var51);
    java.awt.Paint var53 = var49.getRangeGridlinePaint();
    var41.setLastBarPaint(var53);
    java.awt.Paint var55 = var41.getFirstBarPaint();
    org.jfree.chart.util.GradientPaintTransformer var56 = var41.getGradientPaintTransformer();
    boolean var57 = var41.getBaseSeriesVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var58 = var2.compareTo((java.lang.Object)var41);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     boolean var18 = var14.getItemLineVisible(1, (-435));
//     var14.setSeriesItemLabelsVisible(100, false);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var24 = new org.jfree.data.KeyToGroupMap();
//     int var26 = var24.getGroupIndex((java.lang.Comparable)0.0d);
//     int var28 = var24.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var23, var24);
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
//     var32.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.event.RendererChangeEvent var39 = null;
//     var38.rendererChanged(var39);
//     var38.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.LegendItemCollection var43 = var38.getFixedLegendItems();
//     org.jfree.chart.axis.CategoryAnchor var44 = var38.getDomainGridlinePosition();
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var48 = var45.getItemOutlineStroke((-1), 100);
//     var45.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.plot.CategoryPlot var51 = var45.getPlot();
//     java.awt.Stroke var53 = var45.lookupSeriesStroke((-16775247));
//     var38.setRangeGridlineStroke(var53);
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.axis.CategoryAxis[] var57 = new org.jfree.chart.axis.CategoryAxis[] { var56};
//     var38.setDomainAxes(var57);
//     java.awt.geom.Rectangle2D var59 = null;
//     var14.drawDomainGridline(var22, var38, var59, 100.0d);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var4 = null;
    var1.setMarkerBand(var4);
    var1.setAutoRangeStickyZero(true);
    java.lang.Object var8 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.0d), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    int var22 = var21.getSubtitleCount();
    java.awt.Paint var23 = var21.getBorderPaint();
    org.jfree.chart.util.RectangleInsets var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setPadding(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     org.jfree.chart.plot.PlotState var5 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.draw(var2, var3, var4, var5, var6);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesLinesVisible((-435), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getAngleLabelPaint();
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var8);
//     org.jfree.chart.axis.ValueAxis var10 = var9.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var11 = null;
//     var9.setFixedDomainAxisSpace(var11);
//     java.awt.Paint var13 = var9.getRangeGridlinePaint();
//     var0.setRadiusGridlinePaint(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var0.zoomRangeAxes(1.05d, 0.2d, var17, var18);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
    var2.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var9.getItemLabelPaint(10, 1);
    var2.setSeriesPaint(1, var12);
    org.jfree.chart.labels.ItemLabelPosition var14 = var2.getBasePositiveItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var14, false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.LegendItem var20 = var0.getLegendItem(255, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range((-1.0d), (-100.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    boolean var13 = var6.isRangeCrosshairLockedOnData();
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.zoomRangeAxes(100.0d, 1.05d, var16, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorDown(10.0d);
    var0.setCursor((-1.0d));
    var0.cursorUp((-1.0d));
    var0.setMax(1.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.urls.StandardCategoryURLGenerator var5 = new org.jfree.chart.urls.StandardCategoryURLGenerator("12/31/69", "9-January-1900", "12/31/69");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-460), (org.jfree.chart.urls.CategoryURLGenerator)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths();
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var1, (java.lang.Comparable[])var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var8.refreshTicks(var9, var10, var11, var12);
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var4.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var14, var15);
    java.awt.Paint var17 = var4.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var21 = var18.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var28.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.plot.Marker var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var24.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var34, var35);
    java.awt.Paint var37 = var24.getWallPaint();
    java.awt.Color var39 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var17, var21, var37, (java.awt.Paint)var39);
    int var41 = var39.getRGB();
    java.awt.Color var42 = var39.brighter();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    var43.setPadding((-1.0d), (-1.0d), 0.05d, 1.0d);
    java.awt.Graphics2D var49 = null;
    org.jfree.data.time.DateRange var51 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var51);
    double var53 = var52.getHeight();
    org.jfree.data.time.DateRange var55 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var55);
    boolean var59 = var55.intersects(0.0d, 10.0d);
    boolean var62 = var55.intersects(0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var65 = var64.getMaximumDate();
    var64.setTickMarkInsideLength(1.0f);
    boolean var68 = var64.isVisible();
    boolean var69 = var55.equals((java.lang.Object)var68);
    org.jfree.chart.block.RectangleConstraint var70 = var52.toRangeHeight((org.jfree.data.Range)var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var71 = var43.arrange(var49, var52);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("1/1/69", var1, 0.0f, 100.0f, (-7.0d), 0.0f, 0.5f);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    int var2 = var0.size();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    var4.setAutoRangeStickyZero(false);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets();
    var4.setLabelInsets(var7);
    org.jfree.chart.axis.NumberTickUnit var9 = var4.getTickUnit();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var10 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    java.awt.Color var3 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var4 = var3.getGreen();
    java.awt.Color var5 = var3.darker();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    java.awt.Color var17 = java.awt.Color.decode("1969");
    var12.setRangeZeroBaselinePaint((java.awt.Paint)var17);
    boolean var19 = var12.isRangeCrosshairLockedOnData();
    java.awt.Stroke var20 = var12.getDomainCrosshairStroke();
    org.jfree.chart.LegendItemCollection var21 = new org.jfree.chart.LegendItemCollection();
    var12.setFixedLegendItems(var21);
    var12.setBackgroundAlpha(10.0f);
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var26 = var25.getDataset();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var37 = var34.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var41 = var38.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var43 = var42.getAngleGridlinePaint();
    var38.setBasePaint(var43);
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var33, var37, var43);
    var25.setAngleGridlineStroke(var37);
    var12.setDomainCrosshairStroke(var37);
    org.jfree.chart.plot.CategoryMarker var48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var37);
    java.awt.Paint var49 = var48.getPaint();
    org.jfree.chart.axis.CategoryLabelPositions var51 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var55 = var52.getItemLabelPaint(10, 1);
    var52.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.axis.ValueAxis)var62, var63);
    org.jfree.chart.axis.ValueAxis var65 = var64.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var66 = null;
    var64.setFixedDomainAxisSpace(var66);
    var64.setDomainCrosshairValue(100.0d);
    boolean var70 = var64.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var71 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var74 = var71.getItemLabelPaint(10, 1);
    var64.setDomainTickBandPaint(var74);
    var52.addChangeListener((org.jfree.chart.event.RendererChangeListener)var64);
    org.jfree.chart.util.RectangleEdge var78 = var64.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var79 = org.jfree.chart.util.RectangleEdge.opposite(var78);
    org.jfree.chart.axis.CategoryLabelPosition var80 = var51.getLabelPosition(var78);
    org.jfree.chart.text.TextAnchor var81 = var80.getRotationAnchor();
    var48.setLabelTextAnchor(var81);
    org.jfree.chart.event.MarkerChangeListener var83 = null;
    var48.removeChangeListener(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     var4.setTickMarksVisible(false);
//     java.text.DateFormat var13 = null;
//     org.jfree.chart.axis.DateTickUnit var14 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var13);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var17 = var16.getMaximumDate();
//     java.lang.String var18 = var14.dateToString(var17);
//     var4.setTickUnit(var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setLowerMargin((-100.0d));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "12/31/69"+ "'", var18.equals("12/31/69"));
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.clearRangeMarkers(0);
//     org.jfree.chart.axis.ValueAxis var21 = var15.getRangeAxis(1);
//     org.jfree.data.category.DefaultCategoryDataset var22 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var23 = new org.jfree.data.KeyToGroupMap();
//     int var25 = var23.getGroupIndex((java.lang.Comparable)0.0d);
//     int var27 = var23.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var22, var23);
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("");
//     var31.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var29, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     var37.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var41 = var37.getCategoriesForAxis(var40);
//     var40.setUpperMargin(1.0d);
//     var15.setDomainAxis(var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(4.0d, 3.0d);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsGroupSize();
//     long var2 = var0.getStartTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 604800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2208960000000L));
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.entity.EntityCollection var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var28 = var21.createBufferedImage(0, 2014, 100.0d, (-1.0d), var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)0.0f);
//     org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)10L);
//     java.lang.String var12 = var11.getID();
//     java.lang.String var13 = var11.getID();
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var18 = new org.jfree.data.KeyToGroupMap();
//     int var20 = var18.getGroupIndex((java.lang.Comparable)0.0d);
//     int var22 = var18.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var17, var18);
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     var26.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
//     org.jfree.chart.event.RendererChangeEvent var33 = null;
//     var32.rendererChanged(var33);
//     var32.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var32);
//     var37.clearSubtitles();
//     org.jfree.chart.title.TextTitle var39 = var37.getTitle();
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     java.awt.Paint[] var42 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var44 = var43.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var46 = var43.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var48 = var47.getAngleGridlinePaint();
//     var43.setBasePaint(var48);
//     java.awt.Paint[] var50 = new java.awt.Paint[] { var48};
//     org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var54 = var51.getItemOutlineStroke((-1), 100);
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var59 = var56.getItemOutlineStroke((-1), 100);
//     java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     java.awt.Shape[] var64 = new java.awt.Shape[] { var63};
//     org.jfree.chart.plot.DefaultDrawingSupplier var65 = new org.jfree.chart.plot.DefaultDrawingSupplier(var42, var50, var55, var60, var64);
//     java.awt.Shape var66 = var65.getNextShape();
//     java.lang.Object var67 = var39.draw(var40, var41, (java.lang.Object)var66);
//     java.lang.Object var68 = var39.clone();
//     java.lang.Object var69 = var11.draw(var14, var15, (java.lang.Object)var39);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    boolean var16 = var14.getBaseShapesFilled();
    boolean var17 = var14.getUseFillPaint();
    boolean var20 = var14.getItemShapeVisible((-435), (-16775247));
    java.awt.Font var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setBaseItemLabelFont(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    org.jfree.data.general.SeriesChangeEvent var3 = null;
    var0.seriesChanged(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getPercentComplete(10, (-435), 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.util.RectangleInsets var7 = var4.getLabelInsets();
//     double var9 = var7.calculateBottomInset(0.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Color var15 = java.awt.Color.getColor("1/1/69", (-16777216));
//     int var16 = var15.getGreen();
//     java.awt.Color var17 = var15.darker();
//     var12.setWallPaint((java.awt.Paint)var17);
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var7, (java.awt.Paint)var17);
//     java.awt.geom.Rectangle2D var20 = null;
//     var7.trim(var20);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setFixedDimension(1.0d);
    var1.setAutoTickUnitSelection(true, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(0.05d, (-100.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
//     java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
//     java.awt.Shape var8 = null;
//     var0.setSeriesShape(10, var8);
//     org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var11 = new org.jfree.data.KeyToGroupMap();
//     int var13 = var11.getGroupIndex((java.lang.Comparable)0.0d);
//     int var15 = var11.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var10, var11);
//     java.util.List var17 = var10.getColumnKeys();
//     int var19 = var10.getRowIndex((java.lang.Comparable)(byte)10);
//     org.jfree.data.Range var20 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var10);
//     int var21 = var10.getRowCount();
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var10, (-100.0d));
//     org.jfree.data.category.DefaultCategoryDataset var24 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var25 = new org.jfree.data.KeyToGroupMap();
//     int var27 = var25.getGroupIndex((java.lang.Comparable)0.0d);
//     int var29 = var25.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var24, var25);
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
//     var33.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     var39.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var43 = var39.getCategoriesForAxis(var42);
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
//     var45.setAutoRangeStickyZero(false);
//     var45.setAxisLineVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var53 = var50.getItemOutlineStroke((-1), 100);
//     var50.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.labels.ItemLabelPosition var56 = var50.getNegativeItemLabelPositionFallback();
//     double var57 = var50.getMaximumBarWidth();
//     var50.setSeriesItemLabelsVisible(0, true);
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var42, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var50.", var0.equals(var50) == var50.equals(var0));
//     
//     // Checks the contract:  equals-hashcode on var11 and var25
//     assertTrue("Contract failed: equals-hashcode on var11 and var25", var11.equals(var25) ? var11.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var11
//     assertTrue("Contract failed: equals-hashcode on var25 and var11", var25.equals(var11) ? var25.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var9 = var6.getItemLabelPaint(10, 1);
    boolean var10 = var6.getAutoPopulateSeriesStroke();
    java.lang.Object var11 = var6.clone();
    java.awt.Paint var12 = var6.getBaseOutlinePaint();
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("1969", "org.jfree.data.UnknownKeyException: ", "org.jfree.data.UnknownKeyException: ", "1969", var5, var12);
    boolean var14 = var13.isShapeFilled();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getBase();
    var15.setItemMargin(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var22 = var19.getItemOutlineStroke((-1), 100);
    double var23 = var19.getItemMargin();
    java.awt.Shape var24 = var19.getBaseShape();
    org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity(var24);
    org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var24, "1969");
    var15.setBaseShape(var24);
    boolean var29 = var13.equals((java.lang.Object)var15);
    var15.setBase(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     boolean var20 = var14.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
//     var14.setDomainTickBandPaint(var24);
//     var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
//     boolean var30 = var1.equals((java.lang.Object)var28);
//     java.lang.Number var32 = var0.getQ3Value((java.lang.Comparable)var30, (java.lang.Comparable)'a');
//     double var34 = var0.getRangeLowerBound(true);
//     java.lang.Number var41 = null;
//     org.jfree.data.category.DefaultCategoryDataset var43 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var44 = new org.jfree.data.KeyToGroupMap();
//     int var46 = var44.getGroupIndex((java.lang.Comparable)0.0d);
//     int var48 = var44.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var43, var44);
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("");
//     var52.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var43, var50, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     var58.clearRangeAxes();
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.util.List var62 = var58.getCategoriesForAxis(var61);
//     org.jfree.data.statistics.BoxAndWhiskerItem var63 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)10.0d, (java.lang.Number)0L, (java.lang.Number)(byte)0, (java.lang.Number)1.0E-8d, (java.lang.Number)(byte)1, (java.lang.Number)0, var41, (java.lang.Number)432000000L, var62);
//     java.lang.Comparable var64 = null;
//     java.lang.Comparable var65 = null;
//     var0.add(var63, var64, var65);
//     java.lang.Comparable var68 = null;
//     java.lang.Number var69 = var0.getMinOutlier((java.lang.Comparable)0.2d, var68);
//     java.text.DateFormat var75 = null;
//     org.jfree.chart.axis.DateTickUnit var76 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var75);
//     org.jfree.chart.axis.DateAxis var78 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var79 = var78.getMaximumDate();
//     java.lang.String var80 = var76.dateToString(var79);
//     org.jfree.chart.axis.SegmentedTimeline var81 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var82 = var81.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var84 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var85 = var84.getMaximumDate();
//     long var86 = var81.toTimelineValue(var85);
//     org.jfree.data.time.SimpleTimePeriod var87 = new org.jfree.data.time.SimpleTimePeriod(var79, var85);
//     org.jfree.data.time.SimpleTimePeriod var90 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
//     java.util.Date var91 = var90.getEnd();
//     int var92 = var87.compareTo((java.lang.Object)var90);
//     java.lang.Number var93 = var0.getQ1Value((java.lang.Comparable)2, (java.lang.Comparable)var92);
//     org.jfree.data.Range var95 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
//     java.util.List var96 = var0.getColumnKeys();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var80 + "' != '" + "12/31/69"+ "'", var80.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.lang.String var7 = var6.getURLText();
    java.lang.String var8 = var6.getURLText();
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var9 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var10 = null;
    java.lang.String var11 = var6.getImageMapAreaTag(var9, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.2d, 100.0d, var3);
    java.lang.String var5 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var5.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-1));
    int var3 = var0.getRowCount();
    java.awt.Paint var4 = var0.getBaseItemLabelPaint();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var9 = var6.getItemOutlineStroke((-1), 100);
    double var10 = var6.getItemMargin();
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var12 = var11.clone();
    java.awt.Paint var13 = var11.getAngleLabelPaint();
    var6.setBaseFillPaint(var13, false);
    var6.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.labels.ItemLabelPosition var20 = var6.getNegativeItemLabelPosition(0, 0);
    var0.setSeriesPositiveItemLabelPosition(0, var20, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    var6.setRangeCrosshairValue(0.2d);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    var6.setRenderer(var9);
    var6.clearDomainMarkers();

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("1/1/69", var1, var2, var3);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     boolean var12 = var6.isRangeZeroBaselineVisible();
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
//     var6.setAxisOffset(var13);
//     java.awt.geom.Rectangle2D var15 = null;
//     var13.trim(var15);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    boolean var12 = var6.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var16 = var13.getItemLabelPaint(10, 1);
    var6.setDomainTickBandPaint(var16);
    org.jfree.chart.axis.ValueAxis var18 = var6.getRangeAxis();
    var6.setDomainZeroBaselineVisible(true);
    org.jfree.data.xy.XYDataset var21 = null;
    var6.setDataset(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-1));
    boolean var3 = var0.getAutoPopulateSeriesFillPaint();
    boolean var4 = var0.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
//     double var4 = var0.getItemMargin();
//     java.awt.Shape var5 = var0.getBaseShape();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     var0.setSeriesShape(10, var8, false);
//     org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
//     int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
//     int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
//     java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
//     java.lang.Comparable var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
//     org.jfree.chart.axis.ValueAxis var29 = var28.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var28.setFixedDomainAxisSpace(var30);
//     java.awt.Paint var32 = var28.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var33 = null;
//     var28.markerChanged(var33);
//     var28.setDomainCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
//     var41.setTickMarksVisible(false);
//     int var46 = var28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var41);
//     var41.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.DateTickUnit var51 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var57);
//     double var59 = var56.getLabelAngle();
//     boolean var60 = var51.equals((java.lang.Object)var56);
//     var41.setTickUnit(var51);
//     org.jfree.chart.entity.CategoryItemEntity var62 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var13, var21, (java.lang.Comparable)var51);
//     org.jfree.data.category.DefaultCategoryDataset var64 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var65 = new org.jfree.data.KeyToGroupMap();
//     int var67 = var65.getGroupIndex((java.lang.Comparable)0.0d);
//     int var69 = var65.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var64, var65);
//     org.jfree.chart.axis.CategoryAxis var71 = null;
//     org.jfree.chart.axis.DateAxis var73 = new org.jfree.chart.axis.DateAxis("");
//     var73.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var78 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var64, var71, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.chart.renderer.category.CategoryItemRenderer)var78);
//     org.jfree.chart.event.RendererChangeEvent var80 = null;
//     var79.rendererChanged(var80);
//     var79.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var84 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var79);
//     var84.clearSubtitles();
//     org.jfree.chart.title.TextTitle var86 = var84.getTitle();
//     var84.setAntiAlias(true);
//     org.jfree.chart.event.ChartProgressEvent var91 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var8, var84, 255, 0);
//     
//     // Checks the contract:  equals-hashcode on var14 and var65
//     assertTrue("Contract failed: equals-hashcode on var14 and var65", var14.equals(var65) ? var14.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var14
//     assertTrue("Contract failed: equals-hashcode on var65 and var14", var65.equals(var14) ? var65.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.data.UnknownKeyException: ");
    org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var3 = new org.jfree.data.KeyToGroupMap();
    int var5 = var3.getGroupIndex((java.lang.Comparable)0.0d);
    int var7 = var3.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var2, var3);
    var2.removeColumn((java.lang.Comparable)(-1.0f));
    int var11 = var2.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var2, (-16775247));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var6 = var3.getItemLabelPaint(10, 1);
    var3.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var15.setFixedDomainAxisSpace(var17);
    var15.setDomainCrosshairValue(100.0d);
    boolean var21 = var15.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var25 = var22.getItemLabelPaint(10, 1);
    var15.setDomainTickBandPaint(var25);
    var3.addChangeListener((org.jfree.chart.event.RendererChangeListener)var15);
    org.jfree.chart.util.RectangleEdge var29 = var15.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    org.jfree.chart.axis.CategoryLabelPosition var31 = var2.getLabelPosition(var29);
    org.jfree.chart.text.TextAnchor var32 = var31.getRotationAnchor();
    org.jfree.chart.text.TextBlockAnchor var33 = var31.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var35 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var39 = var36.getItemLabelPaint(10, 1);
    var36.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var42, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.axis.ValueAxis)var46, var47);
    org.jfree.chart.axis.ValueAxis var49 = var48.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var50 = null;
    var48.setFixedDomainAxisSpace(var50);
    var48.setDomainCrosshairValue(100.0d);
    boolean var54 = var48.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var58 = var55.getItemLabelPaint(10, 1);
    var48.setDomainTickBandPaint(var58);
    var36.addChangeListener((org.jfree.chart.event.RendererChangeListener)var48);
    org.jfree.chart.util.RectangleEdge var62 = var48.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var63 = org.jfree.chart.util.RectangleEdge.opposite(var62);
    org.jfree.chart.axis.CategoryLabelPosition var64 = var35.getLabelPosition(var62);
    org.jfree.chart.text.TextAnchor var65 = var64.getRotationAnchor();
    java.lang.String var66 = var65.toString();
    org.jfree.chart.axis.CategoryLabelWidthType var68 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var70 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var33, var65, 0.2d, var68, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + "TextAnchor.TOP_LEFT"+ "'", var66.equals("TextAnchor.TOP_LEFT"));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    var12.setDomainCrosshairValue(100.0d);
    boolean var18 = var12.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var19.getItemLabelPaint(10, 1);
    var12.setDomainTickBandPaint(var22);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    java.awt.Stroke var25 = var12.getOutlineStroke();
    org.jfree.chart.axis.AxisSpace var26 = null;
    var12.setFixedDomainAxisSpace(var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var33);
    org.jfree.chart.axis.ValueAxis var35 = var34.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var36 = null;
    var34.setFixedDomainAxisSpace(var36);
    java.awt.Color var39 = java.awt.Color.decode("1969");
    var34.setRangeZeroBaselinePaint((java.awt.Paint)var39);
    boolean var41 = var34.isRangeCrosshairLockedOnData();
    java.awt.Stroke var42 = var34.getDomainCrosshairStroke();
    org.jfree.chart.LegendItemCollection var43 = new org.jfree.chart.LegendItemCollection();
    var34.setFixedLegendItems(var43);
    var12.setFixedLegendItems(var43);
    boolean var46 = var12.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var1);
    double var3 = var2.getHeight();
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var5);
    boolean var9 = var5.intersects(0.0d, 10.0d);
    boolean var12 = var5.intersects(0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var15 = var14.getMaximumDate();
    var14.setTickMarkInsideLength(1.0f);
    boolean var18 = var14.isVisible();
    boolean var19 = var5.equals((java.lang.Object)var18);
    org.jfree.chart.block.RectangleConstraint var20 = var2.toRangeHeight((org.jfree.data.Range)var5);
    org.jfree.chart.block.LengthConstraintType var21 = var20.getWidthConstraintType();
    org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var23);
    double var25 = var24.getHeight();
    org.jfree.data.time.DateRange var27 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var27);
    boolean var31 = var27.intersects(0.0d, 10.0d);
    boolean var34 = var27.intersects(0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var37 = var36.getMaximumDate();
    var36.setTickMarkInsideLength(1.0f);
    boolean var40 = var36.isVisible();
    boolean var41 = var27.equals((java.lang.Object)var40);
    org.jfree.chart.block.RectangleConstraint var42 = var24.toRangeHeight((org.jfree.data.Range)var27);
    org.jfree.chart.block.LengthConstraintType var43 = var42.getWidthConstraintType();
    boolean var44 = var21.equals((java.lang.Object)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(604800000L, (-435), 0);
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var6 = var5.getMaximumDate();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var6);
//     java.util.Date var8 = var7.getStart();
//     long var9 = var3.toTimelineValue(var8);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
//     double var13 = var10.getLabelAngle();
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var16 = var15.getMaximumDate();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var16);
//     java.util.Date var18 = var17.getStart();
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var10.dateToJava2D(var18, var19, var20);
//     java.lang.String var22 = var5.dateToString(var18);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var18);
//     java.util.Calendar var24 = null;
//     long var25 = var23.getLastMillisecond(var24);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var3 = new org.jfree.data.KeyToGroupMap();
    int var5 = var3.getGroupIndex((java.lang.Comparable)0.0d);
    int var7 = var3.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var2, var3);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
    var11.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var17.rendererChanged(var18);
    var17.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var17);
    var22.clearSubtitles();
    org.jfree.chart.title.TextTitle var24 = var22.getTitle();
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    java.awt.Paint[] var27 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    double var29 = var28.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var31 = var28.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var33 = var32.getAngleGridlinePaint();
    var28.setBasePaint(var33);
    java.awt.Paint[] var35 = new java.awt.Paint[] { var33};
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var39 = var36.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var44 = var41.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var45 = new java.awt.Stroke[] { var44};
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
    org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var35, var40, var45, var49);
    java.awt.Shape var51 = var50.getNextShape();
    java.lang.Object var52 = var24.draw(var25, var26, (java.lang.Object)var51);
    java.awt.Paint var53 = var24.getBackgroundPaint();
    org.jfree.data.category.DefaultCategoryDataset var54 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var55 = new org.jfree.data.KeyToGroupMap();
    int var57 = var55.getGroupIndex((java.lang.Comparable)0.0d);
    int var59 = var55.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var54, var55);
    org.jfree.chart.axis.CategoryAxis var61 = null;
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
    var63.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var54, var61, (org.jfree.chart.axis.ValueAxis)var63, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
    var69.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var72 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.util.List var73 = var69.getCategoriesForAxis(var72);
    var72.setUpperMargin(1.0d);
    org.jfree.chart.axis.CategoryLabelPositions var76 = var72.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.BarRenderer var78 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var81 = var78.getItemLabelPaint(10, 1);
    boolean var82 = var78.getAutoPopulateSeriesStroke();
    java.lang.Object var83 = var78.clone();
    boolean var84 = var77.equals(var83);
    org.jfree.chart.axis.CategoryLabelPositions var85 = var77.getCategoryLabelPositions();
    var72.setCategoryLabelPositions(var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var24, (java.lang.Object)var72);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var5 = var4.getMaximumDate();
    var4.setVerticalTickLabels(false);
    java.text.DateFormat var12 = null;
    org.jfree.chart.axis.DateTickUnit var13 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var12);
    java.util.Date var14 = var4.calculateLowestVisibleTickValue(var13);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var18 = var16.getSeriesPaint(0);
    java.awt.Font var19 = var16.getBaseItemLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var20.getItemOutlineStroke((-1), 100);
    var20.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var29 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.AxisState var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    java.util.List var38 = var33.refreshTicks(var34, var35, var36, var37);
    org.jfree.chart.plot.Marker var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var29.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, var39, var40);
    java.awt.Paint var42 = var29.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var46 = var43.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = null;
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var54 = null;
    org.jfree.chart.axis.AxisState var55 = null;
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    java.util.List var58 = var53.refreshTicks(var54, var55, var56, var57);
    org.jfree.chart.plot.Marker var59 = null;
    java.awt.geom.Rectangle2D var60 = null;
    var49.drawRangeMarker(var50, var51, (org.jfree.chart.axis.ValueAxis)var53, var59, var60);
    java.awt.Paint var62 = var49.getWallPaint();
    java.awt.Color var64 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var65 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var42, var46, var62, (java.awt.Paint)var64);
    var20.setBaseOutlinePaint(var62);
    org.jfree.chart.text.TextFragment var68 = new org.jfree.chart.text.TextFragment("", var19, var62, 10.0f);
    java.awt.Font var69 = var68.getFont();
    var2.setTickLabelFont((java.lang.Comparable)var14, var69);
    org.jfree.chart.title.TextTitle var71 = new org.jfree.chart.title.TextTitle("XY Plot", var69);
    java.lang.Object var72 = var71.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var4 = null;
    var1.setMarkerBand(var4);
    var1.setAutoRangeStickyZero(true);
    var1.setLowerBound(0.0d);
    var1.setUpperMargin(0.0d);
    boolean var12 = var1.getAutoRangeIncludesZero();
    var1.setLowerBound(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var6);
//     org.jfree.chart.util.RectangleInsets var8 = var5.getLabelInsets();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var11 = var10.getMaximumDate();
//     var10.setVerticalTickLabels(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var10, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(0);
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var19 = var18.getDataset();
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var30 = var27.getItemOutlineStroke((-1), 100);
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var32 = var31.getBase();
//     org.jfree.chart.urls.CategoryURLGenerator var34 = var31.getSeriesURLGenerator(0);
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var36 = var35.getAngleGridlinePaint();
//     var31.setBasePaint(var36);
//     org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var26, var30, var36);
//     var18.setAngleGridlineStroke(var30);
//     java.awt.Font var40 = var18.getAngleLabelFont();
//     var18.setForegroundAlpha(1.0f);
//     boolean var43 = var17.equals((java.lang.Object)var18);
//     org.jfree.chart.renderer.PolarItemRenderer var44 = null;
//     var18.setRenderer(var44);
//     var18.zoom(1.0d);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    var21.setBackgroundImageAlignment(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var24 = var21.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var0.getItemLabelPaint(10, 1);
    var0.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    var12.setDomainCrosshairValue(100.0d);
    boolean var18 = var12.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var19.getItemLabelPaint(10, 1);
    var12.setDomainTickBandPaint(var22);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    java.awt.Stroke var25 = var12.getOutlineStroke();
    java.awt.geom.Point2D var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setQuadrantOrigin(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var4 = new org.jfree.data.KeyToGroupMap();
//     int var6 = var4.getGroupIndex((java.lang.Comparable)0.0d);
//     int var8 = var4.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var3, var4);
//     boolean var12 = var9.intersects(1.0d, 0.05d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
//     double var15 = var13.constrain(1.0d);
//     org.jfree.data.Range var16 = org.jfree.data.Range.combine(var9, (org.jfree.data.Range)var13);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 1.0E-8d);
//     org.jfree.chart.block.RectangleConstraint var20 = var18.toFixedWidth(10.0d);
//     org.jfree.chart.util.Size2D var21 = var1.arrange(var2, var18);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var0, (java.lang.Comparable[])var2, var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    double var3 = var1.getFixedAutoRange();
    java.awt.Color var6 = java.awt.Color.getColor("1/1/69", (-16777216));
    java.awt.image.ColorModel var7 = null;
    java.awt.Rectangle var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    java.awt.geom.AffineTransform var10 = null;
    java.awt.RenderingHints var11 = null;
    java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(10.0d, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.awt.Image var4 = null;
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var4, "", "", "");
    org.jfree.chart.ui.Library[] var9 = var8.getOptionalLibraries();
    java.lang.String var10 = var8.getInfo();
    boolean var11 = var0.equals((java.lang.Object)var10);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4068457));

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
//     var2.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = var14.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var14.setFixedDomainAxisSpace(var16);
//     var14.setDomainCrosshairValue(100.0d);
//     boolean var20 = var14.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var24 = var21.getItemLabelPaint(10, 1);
//     var14.setDomainTickBandPaint(var24);
//     var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var14);
//     org.jfree.chart.util.RectangleEdge var28 = var14.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.util.RectangleEdge.opposite(var28);
//     org.jfree.chart.axis.CategoryLabelPosition var30 = var1.getLabelPosition(var28);
//     org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var36 = var33.getItemLabelPaint(10, 1);
//     var33.setMinimumBarLength(10.0d);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.axis.ValueAxis)var43, var44);
//     org.jfree.chart.axis.ValueAxis var46 = var45.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var45.setFixedDomainAxisSpace(var47);
//     var45.setDomainCrosshairValue(100.0d);
//     boolean var51 = var45.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var55 = var52.getItemLabelPaint(10, 1);
//     var45.setDomainTickBandPaint(var55);
//     var33.addChangeListener((org.jfree.chart.event.RendererChangeListener)var45);
//     org.jfree.chart.util.RectangleEdge var59 = var45.getRangeAxisEdge((-1));
//     org.jfree.chart.util.RectangleEdge var60 = org.jfree.chart.util.RectangleEdge.opposite(var59);
//     org.jfree.chart.axis.CategoryLabelPosition var61 = var32.getLabelPosition(var59);
//     org.jfree.chart.text.TextAnchor var62 = var61.getRotationAnchor();
//     org.jfree.chart.text.TextBlockAnchor var63 = var61.getLabelAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var64 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var61);
//     
//     // Checks the contract:  equals-hashcode on var14 and var45
//     assertTrue("Contract failed: equals-hashcode on var14 and var45", var14.equals(var45) ? var14.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var14
//     assertTrue("Contract failed: equals-hashcode on var45 and var14", var45.equals(var14) ? var45.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var6.refreshTicks(var7, var8, var9, var10);
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var12, var13);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var19, var20);
    org.jfree.chart.axis.ValueAxis var22 = var21.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var23 = null;
    var21.setFixedDomainAxisSpace(var23);
    java.awt.Color var26 = java.awt.Color.decode("1969");
    var21.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    var2.setWallPaint((java.awt.Paint)var26);
    org.jfree.chart.labels.CategoryItemLabelGenerator var29 = null;
    var2.setBaseItemLabelGenerator(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var4);
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var8 = var7.getMaximumDate();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year(var8);
//     java.util.Date var10 = var9.getStart();
//     java.lang.String var11 = var5.dateToString(var10);
//     java.lang.Comparable[] var12 = new java.lang.Comparable[] { var10};
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var17, var18);
//     var17.setTickMarksVisible(false);
//     java.text.DateFormat var26 = null;
//     org.jfree.chart.axis.DateTickUnit var27 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var26);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var30 = var29.getMaximumDate();
//     java.lang.String var31 = var27.dateToString(var30);
//     var17.setTickUnit(var27);
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var35 = var34.getMaximumDate();
//     var34.setVerticalTickLabels(false);
//     java.text.DateFormat var42 = null;
//     org.jfree.chart.axis.DateTickUnit var43 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var42);
//     java.util.Date var44 = var34.calculateLowestVisibleTickValue(var43);
//     java.util.Date var45 = var17.calculateHighestVisibleTickValue(var43);
//     java.lang.Comparable[] var46 = new java.lang.Comparable[] { var45};
//     double[] var47 = null;
//     double[][] var48 = new double[][] { var47};
//     org.jfree.data.category.CategoryDataset var49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var12, var46, var48);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    var2.setUseFillPaint(false);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    boolean var12 = var6.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var16 = var13.getItemLabelPaint(10, 1);
    var6.setDomainTickBandPaint(var16);
    java.awt.Stroke var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainCrosshairStroke(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
    var3.addException(10L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     var9.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var15.rendererChanged(var16);
//     var15.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.util.RectangleEdge var20 = var15.getDomainAxisEdge();
//     org.jfree.chart.plot.DatasetRenderingOrder var21 = var15.getDatasetRenderingOrder();
//     org.jfree.data.category.DefaultCategoryDataset var22 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var23 = new org.jfree.data.KeyToGroupMap();
//     int var25 = var23.getGroupIndex((java.lang.Comparable)0.0d);
//     int var27 = var23.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var22, var23);
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("");
//     var31.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var29, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     org.jfree.chart.event.RendererChangeEvent var38 = null;
//     var37.rendererChanged(var38);
//     var37.setDrawSharedDomainAxis(true);
//     java.awt.Graphics2D var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     boolean var46 = var37.render(var42, var43, 0, var45);
//     var37.mapDatasetToDomainAxis(0, (-16775247));
//     java.lang.Object var50 = var37.clone();
//     boolean var51 = var21.equals((java.lang.Object)var37);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var6 = var3.getItemLabelPaint(10, 1);
    var3.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = var15.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var15.setFixedDomainAxisSpace(var17);
    var15.setDomainCrosshairValue(100.0d);
    boolean var21 = var15.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var25 = var22.getItemLabelPaint(10, 1);
    var15.setDomainTickBandPaint(var25);
    var3.addChangeListener((org.jfree.chart.event.RendererChangeListener)var15);
    org.jfree.chart.util.RectangleEdge var29 = var15.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var30 = org.jfree.chart.util.RectangleEdge.opposite(var29);
    org.jfree.chart.axis.CategoryLabelPosition var31 = var2.getLabelPosition(var29);
    org.jfree.chart.text.TextAnchor var32 = var31.getRotationAnchor();
    org.jfree.chart.text.TextBlockAnchor var33 = var31.getLabelAnchor();
    java.lang.Object var34 = null;
    boolean var35 = var33.equals(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var36 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var8.refreshTicks(var9, var10, var11, var12);
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var4.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var14, var15);
    java.awt.Paint var17 = var4.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var21 = var18.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = null;
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var28.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.plot.Marker var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var24.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var34, var35);
    java.awt.Paint var37 = var24.getWallPaint();
    java.awt.Color var39 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var17, var21, var37, (java.awt.Paint)var39);
    int var41 = var39.getRGB();
    java.awt.Color var42 = var39.brighter();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var1, (java.awt.Paint)var39);
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var47 = var44.getItemOutlineStroke((-1), 100);
    var44.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var50 = var44.getPlot();
    java.awt.Stroke var52 = var44.lookupSeriesStroke((-16775247));
    var43.setLineStroke(var52);
    java.awt.Graphics2D var54 = null;
    org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var56);
    double var58 = var57.getHeight();
    org.jfree.data.time.DateRange var60 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var61 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var60);
    boolean var64 = var60.intersects(0.0d, 10.0d);
    boolean var67 = var60.intersects(0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var69 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var70 = var69.getMaximumDate();
    var69.setTickMarkInsideLength(1.0f);
    boolean var73 = var69.isVisible();
    boolean var74 = var60.equals((java.lang.Object)var73);
    org.jfree.chart.block.RectangleConstraint var75 = var57.toRangeHeight((org.jfree.data.Range)var60);
    org.jfree.chart.block.LengthConstraintType var76 = var75.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var77 = var43.arrange(var54, var75);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-16775247));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    org.jfree.chart.plot.DrawingSupplier var12 = null;
    var6.setDrawingSupplier(var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D("");
    var16.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var19 = null;
    var16.setMarkerBand(var19);
    var6.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var16, false);
    var6.setDomainCrosshairValue(3.0d, false);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var31);
    org.jfree.chart.axis.ValueAxis var33 = var32.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var34 = null;
    var32.setFixedDomainAxisSpace(var34);
    var32.setDomainCrosshairValue(100.0d);
    boolean var38 = var32.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var42 = var39.getItemLabelPaint(10, 1);
    var32.setDomainTickBandPaint(var42);
    org.jfree.chart.util.RectangleInsets var44 = var32.getAxisOffset();
    var6.setInsets(var44);
    double var47 = var44.extendHeight(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0E-8d);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, 0.0d, var2);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var10 = var0.getRowKey((-4068935));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
//     long var5 = var3.getSegmentSize();
//     java.text.DateFormat var10 = null;
//     org.jfree.chart.axis.DateTickUnit var11 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var10);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var14 = var13.getMaximumDate();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year(var14);
//     java.util.Date var16 = var15.getStart();
//     java.lang.String var17 = var11.dateToString(var16);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var22 = var21.getMaximumDate();
//     var21.setVerticalTickLabels(false);
//     java.text.DateFormat var29 = null;
//     org.jfree.chart.axis.DateTickUnit var30 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var29);
//     java.util.Date var31 = var21.calculateLowestVisibleTickValue(var30);
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var35 = var33.getSeriesPaint(0);
//     java.awt.Font var36 = var33.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var40 = var37.getItemOutlineStroke((-1), 100);
//     var37.setBaseCreateEntities(false, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = null;
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.AxisState var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     java.util.List var55 = var50.refreshTicks(var51, var52, var53, var54);
//     org.jfree.chart.plot.Marker var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     var46.drawRangeMarker(var47, var48, (org.jfree.chart.axis.ValueAxis)var50, var56, var57);
//     java.awt.Paint var59 = var46.getWallPaint();
//     org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var63 = var60.getItemLabelPaint(10, 1);
//     org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = null;
//     org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis("");
//     java.awt.Graphics2D var71 = null;
//     org.jfree.chart.axis.AxisState var72 = null;
//     java.awt.geom.Rectangle2D var73 = null;
//     org.jfree.chart.util.RectangleEdge var74 = null;
//     java.util.List var75 = var70.refreshTicks(var71, var72, var73, var74);
//     org.jfree.chart.plot.Marker var76 = null;
//     java.awt.geom.Rectangle2D var77 = null;
//     var66.drawRangeMarker(var67, var68, (org.jfree.chart.axis.ValueAxis)var70, var76, var77);
//     java.awt.Paint var79 = var66.getWallPaint();
//     java.awt.Color var81 = java.awt.Color.decode("1969");
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var82 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var59, var63, var79, (java.awt.Paint)var81);
//     var37.setBaseOutlinePaint(var79);
//     org.jfree.chart.text.TextFragment var85 = new org.jfree.chart.text.TextFragment("", var36, var79, 10.0f);
//     java.awt.Font var86 = var85.getFont();
//     var19.setTickLabelFont((java.lang.Comparable)var31, var86);
//     org.jfree.data.time.DateRange var88 = new org.jfree.data.time.DateRange(var16, var31);
//     var3.addException(var16);
//     org.jfree.data.time.Year var90 = new org.jfree.data.time.Year(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "1/1/69"+ "'", var17.equals("1/1/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
//     double var4 = var0.getItemMargin();
//     java.awt.Shape var5 = var0.getBaseShape();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     var0.setSeriesShape(10, var8, false);
//     org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
//     int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
//     int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
//     java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
//     java.lang.Comparable var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
//     org.jfree.chart.axis.ValueAxis var29 = var28.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var28.setFixedDomainAxisSpace(var30);
//     java.awt.Paint var32 = var28.getRangeGridlinePaint();
//     org.jfree.chart.event.MarkerChangeEvent var33 = null;
//     var28.markerChanged(var33);
//     var28.setDomainCrosshairVisible(true);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var42);
//     var41.setTickMarksVisible(false);
//     int var46 = var28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var41);
//     var41.setTickMarkInsideLength(1.0f);
//     org.jfree.chart.axis.DateTickUnit var51 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var56, var57);
//     double var59 = var56.getLabelAngle();
//     boolean var60 = var51.equals((java.lang.Object)var56);
//     var41.setTickUnit(var51);
//     org.jfree.chart.entity.CategoryItemEntity var62 = new org.jfree.chart.entity.CategoryItemEntity(var8, "hi!", "1/1/69", (org.jfree.data.category.CategoryDataset)var13, var21, (java.lang.Comparable)var51);
//     org.jfree.data.category.DefaultCategoryDataset var63 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var64 = new org.jfree.data.KeyToGroupMap();
//     int var66 = var64.getGroupIndex((java.lang.Comparable)0.0d);
//     int var68 = var64.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var69 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var63, var64);
//     var63.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var73 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var63, (-1));
//     org.jfree.chart.plot.RingPlot var74 = new org.jfree.chart.plot.RingPlot(var73);
//     org.jfree.chart.renderer.category.BarRenderer var75 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var78 = var75.getItemLabelPaint(10, 1);
//     var74.setLabelOutlinePaint(var78);
//     java.awt.Paint var80 = var74.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var81 = var74.getLegendItems();
//     var74.setOuterSeparatorExtension(0.05d);
//     boolean var84 = var62.equals((java.lang.Object)var74);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var75 and var0.", var75.equals(var0) == var0.equals(var75));
//     
//     // Checks the contract:  equals-hashcode on var14 and var64
//     assertTrue("Contract failed: equals-hashcode on var14 and var64", var14.equals(var64) ? var14.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var14
//     assertTrue("Contract failed: equals-hashcode on var64 and var14", var64.equals(var14) ? var64.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var6.handleClick(1, 2014, var14);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     java.awt.Paint var10 = var6.getRangeGridlinePaint();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var14 = new org.jfree.data.KeyToGroupMap();
//     int var16 = var14.getGroupIndex((java.lang.Comparable)0.0d);
//     int var18 = var14.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13, var14);
//     java.util.List var20 = var13.getColumnKeys();
//     var6.drawDomainTickBands(var11, var12, var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
//     var26.setTickMarksVisible(false);
//     java.text.DateFormat var35 = null;
//     org.jfree.chart.axis.DateTickUnit var36 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var35);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var39 = var38.getMaximumDate();
//     java.lang.String var40 = var36.dateToString(var39);
//     var26.setTickUnit(var36);
//     var26.setAutoTickUnitSelection(false);
//     org.jfree.data.Range var44 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var26);
//     java.awt.Color var47 = java.awt.Color.getColor("1/1/69", (-16777216));
//     int var48 = var47.getGreen();
//     java.awt.Color var49 = var47.darker();
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     java.awt.geom.AffineTransform var53 = null;
//     org.jfree.data.category.DefaultCategoryDataset var55 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var56 = new org.jfree.data.KeyToGroupMap();
//     int var58 = var56.getGroupIndex((java.lang.Comparable)0.0d);
//     int var60 = var56.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var61 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var55, var56);
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("");
//     var64.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var55, var62, (org.jfree.chart.axis.ValueAxis)var64, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
//     org.jfree.chart.event.RendererChangeEvent var71 = null;
//     var70.rendererChanged(var71);
//     var70.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var70);
//     var75.clearSubtitles();
//     org.jfree.chart.title.TextTitle var77 = var75.getTitle();
//     var75.setAntiAlias(true);
//     java.awt.RenderingHints var80 = var75.getRenderingHints();
//     java.awt.PaintContext var81 = var49.createContext(var50, var51, var52, var53, var80);
//     var6.setRangeGridlinePaint((java.awt.Paint)var49);
//     
//     // Checks the contract:  equals-hashcode on var14 and var56
//     assertTrue("Contract failed: equals-hashcode on var14 and var56", var14.equals(var56) ? var14.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var14
//     assertTrue("Contract failed: equals-hashcode on var56 and var14", var56.equals(var14) ? var56.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
//     java.util.List var5 = var3.getExceptionSegments();
//     long var7 = var3.toTimelineValue(0L);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var10 = var9.getMaximumDate();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var10);
//     long var12 = var3.getTime(var10);
//     int var13 = var3.getGroupSegmentCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1577894400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 7);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var6.refreshTicks(var7, var8, var9, var10);
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var2.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var12, var13);
    var6.centerRange(0.2d);
    var6.setInverted(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)0.5d);
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var2);
    int var4 = var2.getGroupCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 1.0f, 0, var5);
    java.util.List var7 = var6.getLines();
    java.util.List var8 = var6.getLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Comparable var2 = var0.getKey(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-4068935));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 2.0d, var2);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    java.awt.Color var3 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var4 = var3.getGreen();
    java.awt.Color var5 = var3.darker();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    org.jfree.chart.axis.ValueAxis var13 = var12.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var14 = null;
    var12.setFixedDomainAxisSpace(var14);
    java.awt.Color var17 = java.awt.Color.decode("1969");
    var12.setRangeZeroBaselinePaint((java.awt.Paint)var17);
    boolean var19 = var12.isRangeCrosshairLockedOnData();
    java.awt.Stroke var20 = var12.getDomainCrosshairStroke();
    org.jfree.chart.LegendItemCollection var21 = new org.jfree.chart.LegendItemCollection();
    var12.setFixedLegendItems(var21);
    var12.setBackgroundAlpha(10.0f);
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var26 = var25.getDataset();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var37 = var34.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var41 = var38.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var43 = var42.getAngleGridlinePaint();
    var38.setBasePaint(var43);
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var33, var37, var43);
    var25.setAngleGridlineStroke(var37);
    var12.setDomainCrosshairStroke(var37);
    org.jfree.chart.plot.CategoryMarker var48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(byte)10, (java.awt.Paint)var5, var37);
    java.awt.Paint var49 = var48.getPaint();
    org.jfree.chart.axis.CategoryLabelPositions var51 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var55 = var52.getItemLabelPaint(10, 1);
    var52.setMinimumBarLength(10.0d);
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.axis.ValueAxis)var62, var63);
    org.jfree.chart.axis.ValueAxis var65 = var64.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var66 = null;
    var64.setFixedDomainAxisSpace(var66);
    var64.setDomainCrosshairValue(100.0d);
    boolean var70 = var64.isRangeZeroBaselineVisible();
    org.jfree.chart.renderer.category.BarRenderer var71 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var74 = var71.getItemLabelPaint(10, 1);
    var64.setDomainTickBandPaint(var74);
    var52.addChangeListener((org.jfree.chart.event.RendererChangeListener)var64);
    org.jfree.chart.util.RectangleEdge var78 = var64.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var79 = org.jfree.chart.util.RectangleEdge.opposite(var78);
    org.jfree.chart.axis.CategoryLabelPosition var80 = var51.getLabelPosition(var78);
    org.jfree.chart.text.TextAnchor var81 = var80.getRotationAnchor();
    var48.setLabelTextAnchor(var81);
    org.jfree.chart.util.RectangleInsets var83 = var48.getLabelOffset();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var84 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    java.awt.Stroke var85 = var84.getGroupStroke();
    var48.setStroke(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     double var3 = var1.getFixedAutoRange();
//     java.awt.Color var6 = java.awt.Color.getColor("1/1/69", (-16777216));
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.AffineTransform var10 = null;
//     java.awt.RenderingHints var11 = null;
//     java.awt.PaintContext var12 = var6.createContext(var7, var8, var9, var10, var11);
//     var1.setTickLabelPaint((java.awt.Paint)var6);
//     org.jfree.chart.axis.DateTickUnit var14 = null;
//     java.util.Date var15 = var1.calculateHighestVisibleTickValue(var14);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    double var2 = var1.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var1.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var6 = var5.getAngleGridlinePaint();
    var1.setBasePaint(var6);
    java.awt.Paint[] var8 = new java.awt.Paint[] { var6};
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var12 = var9.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var17 = var14.getItemOutlineStroke((-1), 100);
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var8, var13, var18, var22);
    java.awt.Shape var24 = var23.getNextShape();
    java.awt.Paint var25 = var23.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = var1.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var3);
//     java.util.Date var6 = var3.getDate(10L);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var6, var7);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    int var2 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.get((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
    int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
    int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    var10.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var16.rendererChanged(var17);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
    int var22 = var21.getSubtitleCount();
    float var23 = var21.getBackgroundImageAlpha();
    org.jfree.chart.entity.EntityCollection var28 = null;
    org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo(var28);
    org.jfree.chart.entity.EntityCollection var30 = var29.getEntityCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var31 = var21.createBufferedImage(0, (-435), 4.0d, 0.0d, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var6.zoomDomainAxes(1.0E-8d, 0.05d, var15, var16);
    var6.setRangeCrosshairValue(90.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var6.setFixedDomainAxisSpace(var8);
//     var6.setDomainCrosshairValue(100.0d);
//     org.jfree.chart.plot.DrawingSupplier var12 = null;
//     var6.setDrawingSupplier(var12);
//     boolean var14 = var6.isDomainZeroBaselineVisible();
//     java.awt.Paint var15 = var6.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleInsets var16 = var6.getAxisOffset();
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6);
//     boolean var18 = var17.getNotify();
//     org.jfree.chart.util.HorizontalAlignment var19 = var17.getHorizontalAlignment();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var24 = var23.getMaximumDate();
//     org.jfree.chart.axis.SegmentedTimeline var25 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var23.setTimeline((org.jfree.chart.axis.Timeline)var25);
//     java.util.Date var28 = var25.getDate(10L);
//     java.lang.Object var29 = var17.draw(var20, var21, (java.lang.Object)10L);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var2 = var0.calculateLeftOutset(0.0d);
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.trim(var3);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     var10.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.event.RendererChangeEvent var17 = null;
//     var16.rendererChanged(var17);
//     var16.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
//     int var22 = var21.getSubtitleCount();
//     java.awt.Paint var23 = var21.getBorderPaint();
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var28, var29);
//     org.jfree.chart.axis.ValueAxis var31 = var30.getDomainAxis();
//     org.jfree.chart.axis.ValueAxis var33 = var30.getRangeAxis(0);
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var30.setDomainAxisLocation(1, var35, true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var39 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var38};
//     var30.setRenderers(var39);
//     org.jfree.data.category.DefaultCategoryDataset var41 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var42 = new org.jfree.data.KeyToGroupMap();
//     int var44 = var42.getGroupIndex((java.lang.Comparable)0.0d);
//     int var46 = var42.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var41, var42);
//     var41.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var41, (-1));
//     org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
//     double var53 = var52.getMinimumArcAngleToDraw();
//     org.jfree.chart.renderer.category.AreaRenderer var54 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.LegendItem var57 = var54.getLegendItem((-1), (-16775247));
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
//     var60.setAutoRangeStickyZero(false);
//     org.jfree.chart.axis.MarkerAxisBand var63 = null;
//     var60.setMarkerBand(var63);
//     var60.setAutoRangeStickyZero(true);
//     var60.setLowerBound(0.0d);
//     java.awt.Stroke var69 = var60.getTickMarkStroke();
//     var54.setSeriesStroke(255, var69, true);
//     var52.setBaseSectionOutlineStroke(var69);
//     var30.setDomainZeroBaselineStroke(var69);
//     var21.setBorderStroke(var69);
//     
//     // Checks the contract:  equals-hashcode on var2 and var42
//     assertTrue("Contract failed: equals-hashcode on var2 and var42", var2.equals(var42) ? var2.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var2
//     assertTrue("Contract failed: equals-hashcode on var42 and var2", var42.equals(var2) ? var42.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    double var4 = var0.getItemMargin();
    java.awt.Shape var5 = var0.getBaseShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.lang.String var7 = var6.getURLText();
    java.lang.String var8 = var6.getURLText();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var9.getItemLabelPaint(10, 1);
    var9.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var19 = var16.getItemLabelPaint(10, 1);
    var9.setSeriesPaint(1, var19);
    boolean var21 = var6.equals((java.lang.Object)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(0, 2);
//     java.lang.String var4 = var2.valueToString(4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "12/31/69"+ "'", var4.equals("12/31/69"));
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    boolean var13 = var6.isRangeZoomable();
    java.awt.Image var14 = var6.getBackgroundImage();
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = var6.getRenderer();
    var6.setDomainCrosshairValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var18 = var6.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap();
//     int var4 = var2.getGroupIndex((java.lang.Comparable)0.0d);
//     int var6 = var2.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var1, var2);
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     var10.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.event.RendererChangeEvent var17 = null;
//     var16.rendererChanged(var17);
//     var16.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var16);
//     int var22 = var21.getSubtitleCount();
//     org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var24 = new org.jfree.data.KeyToGroupMap();
//     int var26 = var24.getGroupIndex((java.lang.Comparable)0.0d);
//     int var28 = var24.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var23, var24);
//     var23.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var23, (-1));
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
//     org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var38 = var35.getItemLabelPaint(10, 1);
//     var34.setLabelOutlinePaint(var38);
//     java.awt.Paint var40 = var34.getLabelOutlinePaint();
//     var21.setBorderPaint(var40);
//     
//     // Checks the contract:  equals-hashcode on var2 and var24
//     assertTrue("Contract failed: equals-hashcode on var2 and var24", var2.equals(var24) ? var2.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var2
//     assertTrue("Contract failed: equals-hashcode on var24 and var2", var24.equals(var2) ? var24.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var4 = var3.getMaximumDate();
    var3.setVerticalTickLabels(false);
    java.text.DateFormat var11 = null;
    org.jfree.chart.axis.DateTickUnit var12 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var11);
    java.util.Date var13 = var3.calculateLowestVisibleTickValue(var12);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var17 = var15.getSeriesPaint(0);
    java.awt.Font var18 = var15.getBaseItemLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var22 = var19.getItemOutlineStroke((-1), 100);
    var19.setBaseCreateEntities(false, false);
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.axis.AxisState var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    java.util.List var37 = var32.refreshTicks(var33, var34, var35, var36);
    org.jfree.chart.plot.Marker var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    var28.drawRangeMarker(var29, var30, (org.jfree.chart.axis.ValueAxis)var32, var38, var39);
    java.awt.Paint var41 = var28.getWallPaint();
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var45 = var42.getItemLabelPaint(10, 1);
    org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = null;
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("");
    java.awt.Graphics2D var53 = null;
    org.jfree.chart.axis.AxisState var54 = null;
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    java.util.List var57 = var52.refreshTicks(var53, var54, var55, var56);
    org.jfree.chart.plot.Marker var58 = null;
    java.awt.geom.Rectangle2D var59 = null;
    var48.drawRangeMarker(var49, var50, (org.jfree.chart.axis.ValueAxis)var52, var58, var59);
    java.awt.Paint var61 = var48.getWallPaint();
    java.awt.Color var63 = java.awt.Color.decode("1969");
    org.jfree.chart.renderer.category.WaterfallBarRenderer var64 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var41, var45, var61, (java.awt.Paint)var63);
    var19.setBaseOutlinePaint(var61);
    org.jfree.chart.text.TextFragment var67 = new org.jfree.chart.text.TextFragment("", var18, var61, 10.0f);
    java.awt.Font var68 = var67.getFont();
    var1.setTickLabelFont((java.lang.Comparable)var13, var68);
    org.jfree.data.category.DefaultCategoryDataset var70 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var71 = new org.jfree.data.KeyToGroupMap();
    int var73 = var71.getGroupIndex((java.lang.Comparable)0.0d);
    int var75 = var71.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var76 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var70, var71);
    var70.removeColumn((java.lang.Comparable)(-1.0f));
    org.jfree.data.general.PieDataset var80 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var70, (-1));
    org.jfree.chart.plot.RingPlot var81 = new org.jfree.chart.plot.RingPlot(var80);
    org.jfree.chart.renderer.category.BarRenderer var82 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var85 = var82.getItemLabelPaint(10, 1);
    var81.setLabelOutlinePaint(var85);
    var1.setTickLabelPaint(var85);
    double var88 = var1.getUpperMargin();
    double var89 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.05d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    java.text.AttributedString var0 = null;
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    var6.setUpArrow(var13);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D(10.0d, 0.0d);
    java.awt.Color var21 = java.awt.Color.getColor("1/1/69", (-16777216));
    int var22 = var21.getGreen();
    java.awt.Color var23 = var21.darker();
    var18.setWallPaint((java.awt.Paint)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem(var0, "December 2014", "XY Plot", "12/31/69", var15, (java.awt.Paint)var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    java.util.List var3 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getPercentComplete((-1), (-4068457));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    boolean var2 = var0.getGenerateEntities();
    double var3 = var0.getTranslateX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets();
    var1.setLabelInsets(var4);
    double var7 = var4.extendHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue((java.lang.Comparable)604800000L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
    java.util.Date var4 = var3.getEnd();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var10);
    double var12 = var9.getLabelAngle();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var15 = var14.getMaximumDate();
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var15);
    java.util.Date var17 = var16.getStart();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var9.dateToJava2D(var17, var18, var19);
    org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var22 = new org.jfree.data.gantt.Task("XY Plot", var4, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    java.awt.Color var11 = java.awt.Color.decode("1969");
    var6.setRangeZeroBaselinePaint((java.awt.Paint)var11);
    boolean var13 = var6.isRangeCrosshairLockedOnData();
    var6.setNoDataMessage("hi!");
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var6.getRangeMarkers((-1), var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "", "", "");
    java.lang.String var8 = var7.getName();
    var7.setCopyright("December 2014");
    org.jfree.chart.axis.AxisCollection var11 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var12 = var11.getAxesAtTop();
    java.util.List var13 = var11.getAxesAtTop();
    var7.setContributors(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    int var2 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getCeilingTickUnit(100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    boolean var3 = var2.getBaseShapesVisible();
    java.lang.Boolean var5 = var2.getSeriesCreateEntities((-16777216));
    boolean var6 = var2.getBaseLinesVisible();
    boolean var9 = var2.getItemShapeFilled((-16775247), (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("12/31/69", "1969", "DateTickMarkPosition.START", "12/31/69", "DateTickMarkPosition.START");
    java.lang.String var6 = var5.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "12/31/69"+ "'", var6.equals("12/31/69"));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    double var8 = var7.getAutoRangeMinimumSize();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var10 = var9.toString();
    var7.setLabelInsets(var9);
    var7.resizeRange(90.0d, 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 4.0d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-2208960000000L), (-16775247), (-16777216));
    long var4 = var3.getStartTime();
    long var5 = var3.getSegmentSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2208960000000L));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setAutoRangeStickyZero(false);
    org.jfree.data.RangeType var4 = var1.getRangeType();
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, (-1.0f), 1.0f);
    int var9 = var8.getGreen();
    boolean var10 = var4.equals((java.lang.Object)var8);
    java.lang.String var11 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RangeType.FULL"+ "'", var11.equals("RangeType.FULL"));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var3 = var0.getItemOutlineStroke((-1), 100);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.plot.CategoryPlot var6 = var0.getPlot();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    boolean var10 = var0.getItemCreateEntity(10, 1);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var15 = var12.getItemOutlineStroke((-1), 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-435), var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.PolarItemRenderer var1 = null;
    var0.setRenderer(var1);
    org.jfree.chart.LegendItemCollection var3 = var0.getLegendItems();
    java.lang.Object var4 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var2.getItemLabelPaint(10, 1);
    var2.setMinimumBarLength(10.0d);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var9.getItemLabelPaint(10, 1);
    var2.setSeriesPaint(1, var12);
    org.jfree.chart.labels.ItemLabelPosition var14 = var2.getBasePositiveItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var14, false);
    org.jfree.chart.labels.ItemLabelAnchor var17 = var14.getItemLabelAnchor();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var21 = var18.getSeriesURLGenerator(0);
    java.awt.Stroke var24 = var18.getItemOutlineStroke(0, (-435));
    double var25 = var18.getUpperClip();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var31);
    org.jfree.chart.axis.ValueAxis var33 = var32.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var34 = null;
    var32.setFixedDomainAxisSpace(var34);
    var32.setDomainCrosshairValue(100.0d);
    var18.addChangeListener((org.jfree.chart.event.RendererChangeListener)var32);
    org.jfree.chart.labels.ItemLabelPosition var39 = var18.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
    double var41 = var40.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var43 = var40.getSeriesURLGenerator(0);
    java.awt.Stroke var46 = var40.getItemOutlineStroke(0, (-435));
    java.awt.Shape var48 = null;
    var40.setSeriesShape(10, var48);
    org.jfree.data.category.DefaultCategoryDataset var50 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var51 = new org.jfree.data.KeyToGroupMap();
    int var53 = var51.getGroupIndex((java.lang.Comparable)0.0d);
    int var55 = var51.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var50, var51);
    java.util.List var57 = var50.getColumnKeys();
    int var59 = var50.getRowIndex((java.lang.Comparable)(byte)10);
    org.jfree.data.Range var60 = var40.findRangeBounds((org.jfree.data.category.CategoryDataset)var50);
    org.jfree.data.Range var61 = var18.findRangeBounds((org.jfree.data.category.CategoryDataset)var50);
    boolean var62 = var17.equals((java.lang.Object)var18);
    org.jfree.chart.plot.PlotRenderingInfo var63 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var64 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var63);
    double var65 = var64.getSeriesRunningTotal();
    boolean var66 = var17.equals((java.lang.Object)var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getMinimumArcAngleToDraw();
//     java.awt.Paint var13 = var11.getShadowPaint();
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var17 = var14.getItemOutlineStroke((-1), 100);
//     var14.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.plot.CategoryPlot var20 = var14.getPlot();
//     boolean var21 = var14.getBaseSeriesVisibleInLegend();
//     java.awt.Font var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var28, var29);
//     org.jfree.chart.axis.ValueAxis var31 = var30.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var32 = null;
//     var30.setFixedDomainAxisSpace(var32);
//     java.awt.Color var35 = java.awt.Color.decode("1969");
//     var30.setRangeZeroBaselinePaint((java.awt.Paint)var35);
//     org.jfree.chart.text.TextMeasurer var38 = null;
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var35, 0.0f, var38);
//     var14.setBaseFillPaint((java.awt.Paint)var35);
//     boolean var42 = var35.equals((java.lang.Object)(short)10);
//     var11.setShadowPaint((java.awt.Paint)var35);
//     double var44 = var11.getShadowYOffset();
//     org.jfree.chart.labels.PieSectionLabelGenerator var45 = var11.getLegendLabelGenerator();
//     org.jfree.data.category.DefaultCategoryDataset var47 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var48 = new org.jfree.data.KeyToGroupMap();
//     int var50 = var48.getGroupIndex((java.lang.Comparable)0.0d);
//     int var52 = var48.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var47, var48);
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
//     var56.setFixedDimension(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var47, var54, (org.jfree.chart.axis.ValueAxis)var56, (org.jfree.chart.renderer.category.CategoryItemRenderer)var61);
//     org.jfree.chart.event.RendererChangeEvent var63 = null;
//     var62.rendererChanged(var63);
//     var62.setDrawSharedDomainAxis(true);
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var62);
//     var67.clearSubtitles();
//     org.jfree.chart.title.TextTitle var69 = var67.getTitle();
//     var67.setNotify(false);
//     var11.addChangeListener((org.jfree.chart.event.PlotChangeListener)var67);
//     
//     // Checks the contract:  equals-hashcode on var1 and var48
//     assertTrue("Contract failed: equals-hashcode on var1 and var48", var1.equals(var48) ? var1.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var1
//     assertTrue("Contract failed: equals-hashcode on var48 and var1", var48.equals(var1) ? var48.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = var6.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    var6.setDomainCrosshairValue(100.0d);
    boolean var12 = var6.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var6.setFixedDomainAxisSpace(var13);
    int var15 = var6.getWeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var17 = var6.getDomainAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setDrawSharedDomainAxis(true);
    java.awt.Graphics2D var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    boolean var24 = var15.render(var20, var21, 0, var23);
    var15.mapDatasetToDomainAxis(0, (-16775247));
    java.lang.Object var28 = var15.clone();
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var35, var36);
    org.jfree.chart.util.RectangleInsets var38 = var35.getLabelInsets();
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var41 = var40.getMaximumDate();
    var40.setVerticalTickLabels(false);
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var40, var44);
    org.jfree.chart.axis.AxisLocation var47 = var45.getDomainAxisLocation(0);
    org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var49 = var48.getDataset();
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var60 = var57.getItemOutlineStroke((-1), 100);
    org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
    double var62 = var61.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var64 = var61.getSeriesURLGenerator(0);
    org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot();
    java.awt.Paint var66 = var65.getAngleGridlinePaint();
    var61.setBasePaint(var66);
    org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("", "1969", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var56, var60, var66);
    var48.setAngleGridlineStroke(var60);
    java.awt.Font var70 = var48.getAngleLabelFont();
    var48.setForegroundAlpha(1.0f);
    boolean var73 = var47.equals((java.lang.Object)var48);
    org.jfree.chart.axis.AxisLocation var74 = org.jfree.chart.axis.AxisLocation.getOpposite(var47);
    org.jfree.chart.axis.AxisLocation var75 = org.jfree.chart.axis.AxisLocation.getOpposite(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeAxisLocation((-460), var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getBase();
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getSeriesURLGenerator(0);
    java.awt.Stroke var6 = var0.getItemOutlineStroke(0, (-435));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-4068935), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var17 = var16.isDrawBarOutline();
    int var18 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    var15.setRangeCrosshairValue(10.0d, false);
    org.jfree.chart.annotations.CategoryAnnotation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var23 = var15.removeAnnotation(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var2 = var0.getRowIndex((java.lang.Comparable)(short)(-1));
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var7 = new org.jfree.data.KeyToGroupMap();
    int var9 = var7.getGroupIndex((java.lang.Comparable)0.0d);
    int var11 = var7.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6, var7);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    var15.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.event.RendererChangeEvent var22 = null;
    var21.rendererChanged(var22);
    var21.setDrawSharedDomainAxis(true);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot)var21);
    float var27 = var26.getBackgroundImageAlpha();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setPieChart(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.5f);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
//     int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
//     int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
//     var0.removeColumn((java.lang.Comparable)(-1.0f));
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getMinimumArcAngleToDraw();
//     java.awt.Paint var13 = var11.getShadowPaint();
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var17 = var14.getItemOutlineStroke((-1), 100);
//     var14.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.plot.CategoryPlot var20 = var14.getPlot();
//     boolean var21 = var14.getBaseSeriesVisibleInLegend();
//     java.awt.Font var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var28, var29);
//     org.jfree.chart.axis.ValueAxis var31 = var30.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var32 = null;
//     var30.setFixedDomainAxisSpace(var32);
//     java.awt.Color var35 = java.awt.Color.decode("1969");
//     var30.setRangeZeroBaselinePaint((java.awt.Paint)var35);
//     org.jfree.chart.text.TextMeasurer var38 = null;
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var35, 0.0f, var38);
//     var14.setBaseFillPaint((java.awt.Paint)var35);
//     boolean var42 = var35.equals((java.lang.Object)(short)10);
//     var11.setShadowPaint((java.awt.Paint)var35);
//     double var44 = var11.getShadowYOffset();
//     var11.setSectionDepth((-1.0d));
//     java.lang.String var47 = var11.getPlotType();
//     org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.data.KeyToGroupMap var49 = new org.jfree.data.KeyToGroupMap();
//     int var51 = var49.getGroupIndex((java.lang.Comparable)0.0d);
//     int var53 = var49.getGroupIndex((java.lang.Comparable)(-435));
//     org.jfree.data.Range var54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var48, var49);
//     org.jfree.data.general.PieDataset var56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var48, (java.lang.Comparable)0.0f);
//     var11.setDataset(var56);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var1 = var0.getLegendItemToolTipGenerator();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCompletePaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     long var2 = var0.getStartTime();
//     long var3 = var0.getStartTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2208960000000L));
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(1, (-1), 0, 0, var4);
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var8 = var7.getMaximumDate();
//     java.lang.String var9 = var5.dateToString(var8);
//     org.jfree.chart.axis.SegmentedTimeline var10 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var11 = var10.getSegmentsIncludedSize();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var14 = var13.getMaximumDate();
//     long var15 = var10.toTimelineValue(var14);
//     org.jfree.data.time.SimpleTimePeriod var16 = new org.jfree.data.time.SimpleTimePeriod(var8, var14);
//     org.jfree.data.time.SimpleTimePeriod var19 = new org.jfree.data.time.SimpleTimePeriod((-2208960000000L), 0L);
//     java.util.Date var20 = var19.getEnd();
//     int var21 = var16.compareTo((java.lang.Object)var19);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var27);
//     org.jfree.chart.axis.ValueAxis var29 = var28.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var30 = null;
//     var28.setFixedDomainAxisSpace(var30);
//     var28.setDomainCrosshairValue(100.0d);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var38, var39);
//     org.jfree.chart.axis.ValueAxis var41 = var40.getDomainAxis();
//     org.jfree.chart.axis.AxisSpace var42 = null;
//     var40.setFixedDomainAxisSpace(var42);
//     var40.setDomainCrosshairValue(100.0d);
//     boolean var46 = var40.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var50 = var47.getItemLabelPaint(10, 1);
//     var40.setDomainTickBandPaint(var50);
//     var28.setOutlinePaint(var50);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var53 = var16.compareTo((java.lang.Object)var50);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "12/31/69"+ "'", var9.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 432000000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1577894400001L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    var9.setFixedDimension(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var15.rendererChanged(var16);
    var15.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var21 = var15.getDomainAxisEdge(10);
    org.jfree.chart.axis.AxisSpace var22 = var15.getFixedDomainAxisSpace();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var28);
    double var30 = var27.getLabelAngle();
    boolean var31 = var15.equals((java.lang.Object)var27);
    var15.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.data.Range var36 = var15.getDataRange(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var7);
    org.jfree.chart.axis.ValueAxis var9 = var8.getDomainAxis();
    org.jfree.chart.axis.ValueAxis var11 = var8.getRangeAxis(0);
    org.jfree.chart.axis.AxisLocation var13 = null;
    var8.setDomainAxisLocation(1, var13, true);
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var16};
    var8.setRenderers(var17);
    org.jfree.data.category.DefaultCategoryDataset var19 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var20 = new org.jfree.data.KeyToGroupMap();
    int var22 = var20.getGroupIndex((java.lang.Comparable)0.0d);
    int var24 = var20.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var19, var20);
    var19.removeColumn((java.lang.Comparable)(-1.0f));
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var19, (-1));
    org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
    double var31 = var30.getMinimumArcAngleToDraw();
    org.jfree.chart.renderer.category.AreaRenderer var32 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.LegendItem var35 = var32.getLegendItem((-1), (-16775247));
    org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
    var38.setAutoRangeStickyZero(false);
    org.jfree.chart.axis.MarkerAxisBand var41 = null;
    var38.setMarkerBand(var41);
    var38.setAutoRangeStickyZero(true);
    var38.setLowerBound(0.0d);
    java.awt.Stroke var47 = var38.getTickMarkStroke();
    var32.setSeriesStroke(255, var47, true);
    var30.setBaseSectionOutlineStroke(var47);
    var8.setDomainZeroBaselineStroke(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setStroke((-4068457), var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.lang.String var2 = var1.getPlotType();
//     org.jfree.chart.LegendItemCollection var3 = var1.getLegendItems();
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 3.0d, 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap();
    int var3 = var1.getGroupIndex((java.lang.Comparable)0.0d);
    int var5 = var1.getGroupIndex((java.lang.Comparable)(-435));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
    var0.removeColumn((java.lang.Comparable)(-1.0f));
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (-1));
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    double var12 = var11.getMinimumArcAngleToDraw();
    java.awt.Paint var13 = var11.getBaseSectionOutlinePaint();
    var11.setLabelGap(90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

}
