
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 1.0d, var2);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), 0.0f, 0.0f);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test19() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
//
//
//    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var0);
//
//  }
//
  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 0.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(byte)10);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (-1.0d), var2);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), (-1.0d), var2);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, (-1.0f));
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Paint var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, (-1.0d), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, (-1.0d), var2);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, (-1.0d), 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, (-1.0d), var2);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 1.0d, 100.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, (-1.0d), 10.0f, 100.0f);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var15, (-1.0d), 0.0f, 0.0f);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 0.0d, var2);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(-1.0f));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", var1);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 0.0d, var2);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.io.ObjectOutputStream var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var16, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 10.0d, var2);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = null;
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = null;
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, (-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", var1);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    org.jfree.chart.util.RectangleAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, var16, 1.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), (-1.0f), 0.0f);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 100.0d, 10.0f, 0.0f);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 10.0d, var2);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var4, 1.0d, (-1.0f), 10.0f);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, var21, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var11, var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var21 = null;
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var19, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    var0.setShape(100, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 0.0d, var2);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, 100.0d, var2);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.0d, 0.0f, 0.0f);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, 10.0f);
    org.jfree.chart.util.RectangleAnchor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var11, 100.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(-1.0f));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, (-1.0f));
    java.lang.Object var7 = new java.lang.Object();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)100.0f, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 1.0d, 100.0f, (-1.0f));
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 0.0d, var2);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var9, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 10.0d, var2);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var11, var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var21 = null;
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var19, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    var0.setShape(100, var15);
    org.jfree.chart.util.RectangleAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, var25, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 10.0f);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     java.awt.Shape var4 = var1.getShape(100);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var1.setShape(10, var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 100.0d, (-1.0f), 0.0f);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.lang.Class var2 = null;
    java.net.URL var3 = org.jfree.chart.util.ObjectUtilities.getResource("", var2);
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0, (java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    org.jfree.chart.util.RectangleAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var16, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var9, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = null;
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = null;
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var15, var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var33, var37);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var43 = null;
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var41, var43);
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var15, var41);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var3, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)'#');
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var7 = var5.getShape(0);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var5.equals(var9);
//     java.lang.Object var11 = var5.clone();
//     boolean var12 = var0.equals((java.lang.Object)var5);
//     var0.clear();
//     org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
//     var14.clear();
//     java.awt.Shape var17 = var14.getShape(100);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var14.setShape(10, var21);
//     boolean var23 = var0.equals((java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var14
//     assertTrue("Contract failed: equals-hashcode on var8 and var14", var8.equals(var14) ? var8.hashCode() == var14.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var14.", var0.equals(var14) == var14.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var14.", var5.equals(var14) == var14.equals(var5));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var14.", var8.equals(var14) == var14.equals(var8));
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, (-1.0d), 100.0f, 100.0f);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 10.0d, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 10.0d, var2);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)' ');
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
//     var0.setShape(100, var6);
//     org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var15 = var13.getShape(0);
//     java.lang.Object var16 = var13.clone();
//     var13.clear();
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 1.0d, var2);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, (-1.0d));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 1.0d, 0.0f, 10.0f);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 0.0d, 1.0f, (-1.0f));
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var3, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var3, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.RectangleAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var4, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var0.setShape(10, var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    java.io.ObjectOutputStream var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     boolean var7 = var5.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     var8.clear();
//     boolean var11 = var5.equals((java.lang.Object)var8);
//     java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)var5);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var17 = null;
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
//     boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 0.0f, (-1.0f));
//     boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var16, var31);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var31, 100.0d, 100.0d);
//     var5.setShape(0, var35);
//     
//     // Checks the contract:  equals-hashcode on var8 and var5
//     assertTrue("Contract failed: equals-hashcode on var8 and var5", var8.equals(var5) ? var8.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var5.", var8.equals(var5) == var5.equals(var8));
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 10.0d, 0.0f, (-1.0f));
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.util.RectangleAnchor var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, var10, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     var0.setShape(10, var5);
//     java.lang.Class var12 = null;
//     java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var12);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
//     boolean var15 = var0.equals((java.lang.Object)var13);
//     org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
//     var16.clear();
//     var16.clear();
//     java.awt.Shape var20 = var16.getShape(1);
//     boolean var22 = var16.equals((java.lang.Object)(-1));
//     boolean var23 = var0.equals((java.lang.Object)(-1));
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var0.", var16.equals(var0) == var0.equals(var16));
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 1.0d, var2);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var9 = null;
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
//     var0.setShape(0, var15);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     var21.clear();
//     var21.clear();
//     java.lang.Object var24 = var21.clone();
//     boolean var26 = var21.equals((java.lang.Object)(byte)0);
//     var21.clear();
//     var21.clear();
//     var21.clear();
//     java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
//     boolean var31 = var0.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     var3.setShape(100, var9);
//     boolean var16 = var0.equals((java.lang.Object)var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var5);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 10.0d, 0.0f, (-1.0f));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 10.0d, 0.0f, 1.0f);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)100L);
    java.awt.Shape var6 = null;
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var10, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 0.0f, (-1.0f));
    boolean var21 = var0.equals((java.lang.Object)100.0d);
    java.awt.Shape var23 = var0.getShape(0);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var28, var32);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    java.awt.Shape var38 = null;
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var36, var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
//     var1.setShape(100, var7);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 1.0d, 1.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var16, 100.0d, 100.0f, (-1.0f));
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 1.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 10.0d, 10.0f, (-1.0f));
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 10.0d, 100.0f, 100.0f);
    org.jfree.chart.util.RectangleAnchor var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, var24, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 10.0f, (-1.0f));
    org.jfree.chart.util.RectangleAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, var16, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = var0.getShape(1);
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var9 = null;
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var9, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, (-1.0d));
    java.io.ObjectOutputStream var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 100.0f, 100.0f);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = null;
//     var0.setShape(10, var4);
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var8 = var6.getShape(0);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var6.equals(var10);
//     java.lang.Object var12 = var6.clone();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var16 = var6.equals((java.lang.Object)var15);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 0.0d, 100.0f, 1.0f);
//     java.awt.Shape var21 = null;
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var25, var29);
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, (-1.0d));
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var15, var25);
//     boolean var40 = var0.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 0.0d, 1.0f, 10.0f);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 1.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 0.0d, 100.0f, 0.0f);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(short)1);
    int var3 = var0.size();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var6);
    var0.clear();
    java.lang.Object var9 = null;
    boolean var10 = var0.equals(var9);
    java.lang.Object var11 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var0, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 10.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     boolean var8 = var6.equals((java.lang.Object)(byte)10);
//     java.lang.Object var9 = var6.clone();
//     java.lang.Object var10 = var6.clone();
//     java.lang.Object var11 = var6.clone();
//     org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var14 = var12.getShape(0);
//     org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var12.equals(var16);
//     java.lang.Object var18 = var12.clone();
//     boolean var19 = var6.equals(var18);
//     boolean var20 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     var21.clear();
//     var21.clear();
//     java.awt.Shape var25 = var21.getShape(1);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
//     var21.setShape(0, var28);
//     boolean var30 = var0.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var21
//     assertTrue("Contract failed: equals-hashcode on var6 and var21", var6.equals(var21) ? var6.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var21
//     assertTrue("Contract failed: equals-hashcode on var12 and var21", var12.equals(var21) ? var12.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var21
//     assertTrue("Contract failed: equals-hashcode on var15 and var21", var15.equals(var21) ? var15.hashCode() == var21.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var21.", var0.equals(var21) == var21.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var21.", var6.equals(var21) == var21.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var21.", var12.equals(var21) == var21.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var21.", var15.equals(var21) == var21.equals(var15));
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     int var3 = var0.size();
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     var4.clear();
//     var4.clear();
//     java.awt.Shape var8 = var4.getShape(1);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     java.awt.Shape var13 = null;
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
//     boolean var15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)var14);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, (-1.0d), (-1.0f), 0.0f);
//     var4.setShape(0, var19);
//     boolean var25 = var0.equals((java.lang.Object)var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var0.setShape(10, var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 100.0d, var2);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     var3.setShape(100, var9);
//     boolean var16 = var0.equals((java.lang.Object)var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 10.0d, 100.0d);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 1.0d, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 1.0d, 100.0f, (-1.0f));
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var3, var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 1.0d, 100.0f, 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var19, 100.0d, 0.0f, (-1.0f));
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 10.0d, 100.0f, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     int var4 = var1.size();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     var1.setShape(10, var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 100.0d, 0.0f, (-1.0f));
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 100.0f, 10.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, (-1.0d), (-1.0f), 0.0f);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var18, var25);
    org.jfree.chart.util.RectangleAnchor var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, var27, 10.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var15 = null;
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, (-1.0d));
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    org.jfree.chart.util.RectangleAnchor var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, var34, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var1.equals(var5);
//     java.lang.Object var7 = var1.clone();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var11 = var1.equals((java.lang.Object)var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 0.0d, 100.0f, 1.0f);
//     java.awt.Shape var16 = null;
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
//     boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, (-1.0d));
//     boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var10, var20);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var10, (-1.0d), 100.0f, (-1.0f));
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     boolean var5 = var3.equals((java.lang.Object)(short)1);
//     int var6 = var3.size();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var3.setShape(0, var9);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     boolean var12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, (-1.0f), 10.0f);
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var0.setShape(10, var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    org.jfree.chart.util.RectangleAnchor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, var11, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
    org.jfree.chart.util.RectangleAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var5, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     java.awt.Shape var11 = var8.getShape(100);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var8.setShape(10, var15);
//     boolean var17 = var0.equals((java.lang.Object)var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var8.", var3.equals(var8) == var8.equals(var3));
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var0.setShape(10, var7);
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var9, 100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    java.lang.Object var27 = null;
    boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, 0.0d, var2);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = null;
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, (-1.0d));
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 1.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, (-1.0d), 10.0f, 0.0f);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, (-1.0d), 0.0d);
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, var9, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 10.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var20, 0.0d, 100.0f, (-1.0f));
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, (-1.0d), 1.0f, 0.0f);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.0d), 100.0d, var2);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     java.lang.Object var8 = var0.clone();
//     java.awt.Shape var10 = null;
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var10, var14);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 0.0f, (-1.0f));
//     var0.setShape(10, var14);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(short)1);
    int var3 = var0.size();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var6);
    var0.clear();
    java.lang.Object var9 = null;
    boolean var10 = var0.equals(var9);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 100.0f, 10.0f);
    org.jfree.chart.util.RectangleAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, var19, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    var0.setShape(0, var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    var11.clear();
    var11.clear();
    java.awt.Shape var15 = var11.getShape(1);
    boolean var17 = var11.equals((java.lang.Object)' ');
    java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
    java.lang.Object var19 = var11.clone();
    int var20 = var11.size();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 0.0d, (-1.0d));
    var11.setShape(10, var26);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var10, var26);
    boolean var29 = var0.equals((java.lang.Object)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, (-1.0d), 0.0d);
    var0.setShape(10, var12);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 1.0d, 10.0f, 0.0f);
    org.jfree.chart.util.RectangleAnchor var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, var21, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    org.jfree.chart.util.RectangleAnchor var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, var23, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, (-1.0f), 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var11 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var15 = var13.getShape(0);
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var17 = var16.clone();
    boolean var18 = var13.equals(var17);
    java.awt.Shape var20 = var13.getShape((-1));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var25 = var13.equals((java.lang.Object)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(short)1);
    int var3 = var0.size();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
    java.io.ObjectOutputStream var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var8, var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var10 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleAnchor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, var11, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 0.0d, (-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, 10.0f, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
    org.jfree.chart.util.RectangleAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var5, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     var0.clear();
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.awt.Shape var6 = var0.getShape(1);
//     var0.clear();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     java.lang.Object var10 = var8.clone();
//     var8.clear();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var8.setShape(100, var15);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 100.0d, 0.0d);
//     boolean var20 = var0.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, (-1.0f), 0.0f);
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var7, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape((-1));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
    var0.setShape(10, var25);
    var0.clear();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var31 = var29.getShape(0);
    org.jfree.chart.util.ShapeList var32 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var33 = var32.clone();
    boolean var34 = var29.equals(var33);
    java.lang.Object var35 = var29.clone();
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var39 = var29.equals((java.lang.Object)var38);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var43, 100.0d, 100.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 100.0f, 100.0f);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     java.awt.Shape var7 = var3.getShape(1);
//     boolean var9 = var3.equals((java.lang.Object)' ');
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
//     java.lang.Object var11 = var3.clone();
//     int var12 = var3.size();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 0.0d, (-1.0d));
//     var3.setShape(10, var18);
//     boolean var20 = var0.equals((java.lang.Object)10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     boolean var6 = var0.equals((java.lang.Object)(-1));
//     java.awt.Shape var8 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var11 = var9.getShape(0);
//     java.lang.Object var12 = var9.clone();
//     boolean var13 = var0.equals(var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 100.0d, (-1.0f), 10.0f);
//     var0.setShape(100, var16);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape((-1));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
    var0.setShape(10, var25);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 10.0d, 100.0d);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 1.0d, 100.0d);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 0.0d, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var4, 10.0d, 10.0f, 10.0f);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
//     var0.setShape(100, var6);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 1.0d, 1.0d);
//     org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var17 = var16.clone();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 1.0d, 100.0f, (-1.0f));
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var20, var27);
//     boolean var29 = var16.equals((java.lang.Object)var27);
//     boolean var30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var29);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var0.", var16.equals(var0) == var0.equals(var16));
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var0, var3);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 10.0f, 100.0f);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var3, var11);
    org.jfree.chart.util.RectangleAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, var13, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     var0.clear();
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     int var5 = var0.size();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 100.0f, 10.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 10.0d, 100.0d);
//     var0.setShape(0, var17);
//     java.lang.Object var22 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var22.", var1.equals(var22) == var22.equals(var1));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var22.", var2.equals(var22) == var22.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var22.", var4.equals(var22) == var22.equals(var4));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 10.0d, 100.0d);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 1.0d, 100.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 0.0d, 0.0f, 100.0f);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
//     org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
//     var17.clear();
//     java.awt.Shape var20 = var17.getShape(100);
//     int var21 = var17.size();
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var26, var30);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
//     java.awt.Shape var36 = null;
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var34, var36);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 10.0d, 10.0f, 100.0f);
//     var17.setShape(1, var34);
//     boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var15, var34);
//     var0.setShape(0, var34);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var17.", var3.equals(var17) == var17.equals(var3));
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var1, var4);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 1.0d, 10.0f, 100.0f);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var4, var12);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var4, (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.io.ObjectOutputStream var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var17 = var15.getShape(0);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    var15.setShape(10, var20);
    boolean var27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = var0.clone();
//     boolean var5 = var0.equals((java.lang.Object)100L);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var9 = null;
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 0.0f, (-1.0f));
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var8, var23);
//     var0.setShape(1, var23);
//     var0.clear();
//     org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var30 = var28.getShape(0);
//     org.jfree.chart.util.ShapeList var31 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var32 = var31.clone();
//     boolean var33 = var28.equals(var32);
//     java.lang.Object var34 = var28.clone();
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var38 = var28.equals((java.lang.Object)var37);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape(var37, 0.0d, 100.0f, 1.0f);
//     var0.setShape(11, var37);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var0.", var28.equals(var0) == var0.equals(var28));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var0.", var31.equals(var0) == var0.equals(var31));
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 100.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 10.0f, 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 10.0d, 0.0f, 100.0f);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, (-1.0d), 1.0f, (-1.0f));
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10, (java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, 0.0d, 100.0f, 100.0f);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var8);
//     java.lang.Object var12 = null;
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal(var12, (java.lang.Object)var19);
//     var0.setShape(10, var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.0d, 1.0f, 10.0f);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     var6.clear();
//     var6.clear();
//     java.lang.Object var9 = var6.clone();
//     boolean var11 = var6.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var13 = var6.getShape((-1));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     boolean var17 = var6.equals((java.lang.Object)var15);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 1.0d, 10.0f, (-1.0f));
//     var0.setShape(100, var15);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 1.0f, (-1.0f));
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    var0.setShape(100, var6);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 1.0d, 1.0d);
    org.jfree.chart.util.RectangleAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, var16, 1.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), 10.0d);
    java.io.ObjectOutputStream var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var52, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var6 = var0.equals((java.lang.Object)var5);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var5, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var8 = var7.clone();
    java.lang.Object var9 = var7.clone();
    java.awt.Shape var11 = var7.getShape(10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 1.0d, 100.0f, (-1.0f));
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var15, var22);
    var7.setShape(10, var15);
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    var25.clear();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
    var25.setShape(100, var31);
    boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var15, (java.lang.Object)var31);
    var0.setShape(0, var31);
    java.io.ObjectOutputStream var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var31, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.lang.Object var10 = var0.clone();
    var0.clear();
    var0.clear();
    int var13 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    var0.setShape(1, var7);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     var1.clear();
//     var1.clear();
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var7 = var5.getShape(0);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var5.equals(var9);
//     java.awt.Shape var12 = var5.getShape((-1));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     boolean var17 = var5.equals((java.lang.Object)var15);
//     boolean var18 = var1.equals((java.lang.Object)var15);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var15, 0.0d, 0.0f, 0.0f);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, (-1.0f), 10.0f);
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var6, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var9 = null;
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
//     var0.setShape(0, var15);
//     java.awt.Shape var22 = var0.getShape(10);
//     org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
//     var23.clear();
//     var23.clear();
//     java.lang.Object var26 = var23.clone();
//     boolean var28 = var23.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var30 = var23.getShape((-1));
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
//     boolean var34 = var23.equals((java.lang.Object)var32);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 1.0d, 10.0f, (-1.0f));
//     boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10, (java.lang.Object)var38);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var0.", var23.equals(var0) == var0.equals(var23));
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     var0.setShape(0, var9);
//     java.lang.Object var16 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var16.", var3.equals(var16) == var16.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var16.", var4.equals(var16) == var16.equals(var4));
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 1.0d, var2);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var15 = null;
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, (-1.0d));
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    org.jfree.chart.util.RectangleAnchor var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, var34, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, var9, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape(100);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     boolean var11 = var9.equals((java.lang.Object)(byte)10);
//     java.lang.Object var12 = var9.clone();
//     java.lang.Object var13 = var9.clone();
//     int var14 = var9.size();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = var9.equals((java.lang.Object)var16);
//     var0.setShape(0, var16);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    var4.clear();
    var4.clear();
    java.lang.Object var7 = var4.clone();
    boolean var9 = var4.equals((java.lang.Object)(byte)0);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var15 = var4.equals((java.lang.Object)var13);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var3, var13);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 1.0f, (-1.0f));
    java.io.ObjectOutputStream var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var20, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, (-1.0f), 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var7, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, (-1.0d));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 0.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    var0.setShape(10, var5);
    java.io.ObjectOutputStream var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var5, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 100.0d, 0.0f, 1.0f);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, (-1.0f));
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 1.0f, 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 10.0d, 10.0f, 10.0f);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var2, var12);
    java.io.ObjectOutputStream var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var12, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var6, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     var5.clear();
//     var5.clear();
//     java.lang.Object var8 = var5.clone();
//     boolean var10 = var5.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var12 = var5.getShape((-1));
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     boolean var16 = var5.equals((java.lang.Object)var14);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var4, var14);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var4, 10.0d, 10.0f, 0.0f);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     int var6 = var0.size();
//     java.lang.Object var7 = var0.clone();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     var0.setShape(100, var11);
//     java.lang.Object var14 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var14
//     assertTrue("Contract failed: equals-hashcode on var7 and var14", var7.equals(var14) ? var7.hashCode() == var14.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var14.", var3.equals(var14) == var14.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var14.", var7.equals(var14) == var14.equals(var7));
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    var0.clear();
    int var7 = var0.size();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
//     var0.setShape(10, var8);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var19 = var18.clone();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 1.0d, 100.0f, (-1.0f));
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var22, var29);
//     boolean var31 = var18.equals((java.lang.Object)var29);
//     java.awt.Shape var33 = var18.getShape(0);
//     java.awt.Shape var35 = var18.getShape(1);
//     java.lang.Object var36 = var18.clone();
//     boolean var37 = var0.equals((java.lang.Object)var18);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var0.", var18.equals(var0) == var0.equals(var18));
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var6 = var4.getShape(0);
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var4.equals(var8);
//     java.awt.Shape var11 = var4.getShape((-1));
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     boolean var16 = var4.equals((java.lang.Object)var14);
//     boolean var17 = var0.equals((java.lang.Object)var14);
//     java.lang.Object var18 = null;
//     boolean var19 = var0.equals(var18);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     var21.clear();
//     var21.clear();
//     java.awt.Shape var25 = var21.getShape(1);
//     boolean var27 = var21.equals((java.lang.Object)' ');
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     var21.setShape(100, var30);
//     var0.setShape(100, var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var21.", var4.equals(var21) == var21.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var21.", var7.equals(var21) == var21.equals(var7));
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     var0.setShape(10, var11);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var7);
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 100.0f, 10.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, (-1.0d), (-1.0f), 0.0f);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var18, var25);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var18, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.RectangleAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, var4, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    java.lang.Object var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.io.ObjectOutputStream var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)1.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
//     boolean var24 = var22.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
//     var25.clear();
//     var25.clear();
//     boolean var28 = var22.equals((java.lang.Object)var25);
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)var28);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var21, 10.0d, 0.0f, 100.0f);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-1.0d), 10.0f, 1.0f);
//     boolean var15 = var0.equals((java.lang.Object)10.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var0.setShape(10, var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    java.lang.Object var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var7);
    org.jfree.chart.util.RectangleAnchor var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var10, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var17 = null;
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var17, var30);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var17, var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var11, var43);
    java.io.ObjectOutputStream var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var43, var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     java.awt.Shape var5 = null;
//     var1.setShape(10, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     boolean var11 = var1.equals((java.lang.Object)var10);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var10, (-1.0d), 10.0f, (-1.0f));
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), 10.0d);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    org.jfree.chart.util.RectangleAnchor var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var53, var54, 10.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var24);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, 1.0d, 0.0f, (-1.0f));
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var17, var24);
    java.io.ObjectOutputStream var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var17, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = var0.getShape(1);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    var8.clear();
    java.awt.Shape var11 = var8.getShape(100);
    java.lang.Object var12 = null;
    boolean var13 = var8.equals(var12);
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal(var7, (java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     var0.setShape(0, var9);
//     java.lang.Object var16 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var16.", var3.equals(var16) == var16.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var16.", var4.equals(var16) == var16.equals(var4));
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, (-1.0d));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var10, var15);
    java.io.ObjectOutputStream var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var10, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     boolean var3 = var1.equals((java.lang.Object)(short)1);
//     int var4 = var1.size();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var1.setShape(0, var7);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 0.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var12, (-1.0d), 0.0f, (-1.0f));
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    java.lang.Object var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.io.ObjectOutputStream var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     int var3 = var0.size();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     var0.setShape(10, var7);
//     java.lang.Object var9 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var9.", var1.equals(var9) == var9.equals(var1));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var9.", var2.equals(var9) == var9.equals(var2));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    var0.setShape(100, var6);
    org.jfree.chart.util.RectangleAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var13, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.lang.Class var5 = null;
//     java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
//     boolean var7 = var0.equals((java.lang.Object)var5);
//     java.lang.Object var8 = null;
//     boolean var9 = var0.equals(var8);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, (-1.0d), 0.0d);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 0.0d, 1.0d);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, (-1.0d), 10.0d);
//     org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var26 = var25.clone();
//     java.lang.Object var27 = var25.clone();
//     var25.clear();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var25.setShape(100, var32);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var32, 100.0d, 0.0d);
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var24, var32);
//     boolean var38 = var0.equals((java.lang.Object)var32);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var25.", var0.equals(var25) == var25.equals(var0));
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    var16.clear();
    java.awt.Shape var19 = var16.getShape(100);
    java.lang.Object var20 = null;
    boolean var21 = var16.equals(var20);
    java.lang.Object var22 = var16.clone();
    java.lang.Object var23 = var16.clone();
    boolean var24 = var0.equals((java.lang.Object)var16);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
//     var1.setShape(100, var7);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 1.0d, 1.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), (-1.0f), 10.0f);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     boolean var3 = var1.equals((java.lang.Object)(short)1);
//     int var4 = var1.size();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var1.setShape(0, var7);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 0.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 100.0d, 10.0f, 100.0f);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    java.awt.Shape var7 = var0.getShape(10);
    java.awt.Shape var9 = var0.getShape(100);
    java.awt.Shape var11 = var0.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     java.lang.Object var6 = var0.clone();
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var8 = var7.clone();
//     java.lang.Object var9 = var7.clone();
//     var7.clear();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var7.setShape(100, var14);
//     java.awt.Shape var17 = var7.getShape(1);
//     boolean var18 = var0.equals((java.lang.Object)var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var7.", var0.equals(var7) == var7.equals(var0));
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    org.jfree.chart.util.RectangleAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var8, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     var5.clear();
//     var5.clear();
//     java.awt.Shape var9 = var5.getShape(1);
//     boolean var11 = var5.equals((java.lang.Object)' ');
//     java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     java.lang.Object var13 = var5.clone();
//     int var14 = var5.size();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
//     var5.setShape(10, var20);
//     boolean var22 = var0.equals((java.lang.Object)10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var5.", var0.equals(var5) == var5.equals(var0));
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     boolean var6 = var0.equals((java.lang.Object)' ');
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     var0.setShape(100, var9);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     var11.clear();
//     var11.clear();
//     java.lang.Object var14 = var11.clone();
//     boolean var16 = var11.equals((java.lang.Object)(byte)0);
//     var11.clear();
//     var11.clear();
//     var11.clear();
//     java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
//     var11.clear();
//     java.lang.Object var22 = var11.clone();
//     boolean var23 = var0.equals(var22);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var2, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, (-1.0d), 1.0f, 10.0f);
    java.io.ObjectOutputStream var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
    var0.setShape(0, var15);
    java.awt.Shape var22 = var0.getShape(10);
    java.awt.Shape var24 = var0.getShape(0);
    java.awt.Shape var26 = var0.getShape(1);
    java.lang.Object var27 = var0.clone();
    java.awt.Shape var29 = var0.getShape(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    java.awt.Shape var10 = var7.getShape(100);
    int var11 = var7.size();
    boolean var12 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var13 = null;
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
    boolean var31 = var0.equals((java.lang.Object)var30);
    int var32 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, (-1.0f), 10.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 0.0d, 0.0f, 10.0f);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 1.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.awt.Shape var8 = null;
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, (-1.0d));
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var32);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 1.0d, 0.0f, (-1.0f));
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var25, var32);
    var0.setShape(11, var25);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, 1.0d, 100.0f, (-1.0f));
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var44, var51);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.rotateShape(var44, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var56, 1.0d, 100.0f, 0.0f);
    var0.setShape(0, var60);
    java.lang.Object var62 = null;
    boolean var63 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0, var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var3 = null;
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 0.0f, (-1.0f));
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var2, var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 100.0d, 100.0d);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, (-1.0d), 100.0f, 0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var28, 1.0d, 100.0f, 1.0f);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 100.0f, (-1.0f));
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var14);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var7, var17);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 10.0d, 1.0d);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var17, var27);
    boolean var29 = var0.equals((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, (-1.0d), 0.0d);
    var0.setShape(10, var12);
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    java.io.ObjectOutputStream var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var12, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 1.0d, 10.0f, 100.0f);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     var4.clear();
//     java.awt.Shape var7 = var4.getShape(100);
//     int var8 = var4.size();
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var23 = null;
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var21, var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 10.0d, 10.0f, 100.0f);
//     var4.setShape(1, var21);
//     boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var0, var17);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, (-1.0d));
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    java.awt.Shape var7 = var0.getShape(10);
    java.awt.Shape var9 = var0.getShape(100);
    java.lang.Object var10 = var0.clone();
    java.awt.Shape var12 = var0.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    int var5 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    boolean var15 = var10.equals(var14);
    java.awt.Shape var17 = var10.getShape((-1));
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = var10.equals((java.lang.Object)var20);
    boolean var23 = var0.equals((java.lang.Object)var20);
    java.awt.Shape var25 = var0.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (-1.0f));
//     var0.setShape(1, var10);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var7 = var6.clone();
//     java.lang.Object var8 = var6.clone();
//     var6.clear();
//     boolean var10 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     boolean var13 = var11.equals((java.lang.Object)(byte)10);
//     java.lang.Object var14 = var11.clone();
//     java.lang.Object var15 = var11.clone();
//     java.lang.Object var16 = var11.clone();
//     boolean var17 = var6.equals((java.lang.Object)var11);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     var18.clear();
//     java.awt.Shape var21 = var18.getShape(100);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var18.setShape(10, var25);
//     org.jfree.chart.util.ShapeList var27 = new org.jfree.chart.util.ShapeList();
//     var27.clear();
//     java.awt.Shape var30 = var27.getShape(100);
//     int var31 = var27.size();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var27.setShape(0, var34);
//     boolean var36 = var18.equals((java.lang.Object)var34);
//     boolean var37 = var11.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var18.", var0.equals(var18) == var18.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var27.", var0.equals(var27) == var27.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var18.", var6.equals(var18) == var18.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var27.", var6.equals(var27) == var27.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var18.", var11.equals(var18) == var18.equals(var11));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var27.", var11.equals(var27) == var27.equals(var11));
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
//     var0.setShape(0, var6);
//     java.lang.Object var8 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var8.", var2.equals(var8) == var8.equals(var2));
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    int var29 = var0.size();
    java.lang.Object var30 = null;
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     boolean var9 = var7.equals((java.lang.Object)(byte)10);
//     java.lang.Object var10 = var7.clone();
//     java.lang.Object var11 = var7.clone();
//     java.lang.Object var12 = var7.clone();
//     org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var14 = var13.clone();
//     java.lang.Object var15 = var13.clone();
//     var13.clear();
//     boolean var17 = var7.equals((java.lang.Object)var13);
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var7);
//     org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
//     boolean var21 = var19.equals((java.lang.Object)(short)1);
//     int var22 = var19.size();
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var19.setShape(0, var25);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, (-1.0d), 0.0f, 10.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
//     boolean var32 = var7.equals((java.lang.Object)var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var19
//     assertTrue("Contract failed: equals-hashcode on var7 and var19", var7.equals(var19) ? var7.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var19
//     assertTrue("Contract failed: equals-hashcode on var13 and var19", var13.equals(var19) ? var13.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var19.", var0.equals(var19) == var19.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var19.", var3.equals(var19) == var19.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var19.", var7.equals(var19) == var19.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var19.", var13.equals(var19) == var19.equals(var13));
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    var6.clear();
    boolean var10 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    boolean var13 = var11.equals((java.lang.Object)(byte)10);
    java.lang.Object var14 = var11.clone();
    java.lang.Object var15 = var11.clone();
    java.lang.Object var16 = var11.clone();
    boolean var17 = var6.equals((java.lang.Object)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     java.lang.Object var4 = var1.clone();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var7 = var1.equals((java.lang.Object)var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 0.0d, 1.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, (-1.0d), 10.0f, 0.0f);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 100.0d, var2);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    org.jfree.chart.util.RectangleAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, var15, 10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 10.0d, 100.0f, 100.0f);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape((-1));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
    var0.setShape(10, var25);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var25, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 10.0f, 100.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 1.0d, 100.0f, 100.0f);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    int var4 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     var1.setShape(10, var6);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, 1.0d, 10.0f, 100.0f);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)100.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    org.jfree.chart.util.RectangleAnchor var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var9, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = var5.getShape(0);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = var8.clone();
    boolean var10 = var5.equals(var9);
    java.lang.Object var11 = var5.clone();
    boolean var12 = var0.equals((java.lang.Object)var5);
    int var13 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, (-1.0d), (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     int var4 = var0.size();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var0.setShape(0, var7);
//     int var9 = var0.size();
//     java.lang.Object var10 = var0.clone();
//     org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
//     boolean var14 = var12.equals((java.lang.Object)(byte)10);
//     java.lang.Object var15 = var12.clone();
//     java.lang.Object var16 = var12.clone();
//     var12.clear();
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var19 = var18.clone();
//     java.lang.Object var20 = var18.clone();
//     var18.clear();
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
//     boolean var27 = var18.equals((java.lang.Object)var26);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
//     boolean var32 = var18.equals((java.lang.Object)var31);
//     boolean var33 = var12.equals((java.lang.Object)var31);
//     var0.setShape(100, var31);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var0.", var18.equals(var0) == var0.equals(var18));
//     
//     // Checks the contract:  equals-hashcode on var15 and var10
//     assertTrue("Contract failed: equals-hashcode on var15 and var10", var15.equals(var10) ? var15.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var10
//     assertTrue("Contract failed: equals-hashcode on var16 and var10", var16.equals(var10) ? var16.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var10
//     assertTrue("Contract failed: equals-hashcode on var19 and var10", var19.equals(var10) ? var19.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var10
//     assertTrue("Contract failed: equals-hashcode on var20 and var10", var20.equals(var10) ? var20.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var10
//     assertTrue("Contract failed: equals-hashcode on var22 and var10", var22.equals(var10) ? var22.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var10.", var15.equals(var10) == var10.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var10.", var16.equals(var10) == var10.equals(var16));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var10.", var19.equals(var10) == var10.equals(var19));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var10.", var20.equals(var10) == var10.equals(var20));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var10.", var22.equals(var10) == var10.equals(var22));
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape(100);
    java.awt.Shape var9 = var0.getShape((-1));
    int var10 = var0.size();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     java.lang.Object var10 = var8.clone();
//     java.awt.Shape var12 = var8.getShape(10);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 1.0d, 100.0f, (-1.0f));
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var23);
//     var8.setShape(10, var16);
//     org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
//     var26.clear();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
//     var26.setShape(100, var32);
//     boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)var32);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var41 = var0.equals((java.lang.Object)var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var26.", var0.equals(var26) == var26.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var8.", var3.equals(var8) == var8.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var26.", var3.equals(var26) == var26.equals(var3));
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 0.0f, (-1.0f));
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var7, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var8);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var13, var15);
//     var0.setShape(100, var15);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, 1.0d, var2);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var9 = null;
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
//     var0.setShape(0, var15);
//     java.awt.Shape var22 = var0.getShape(10);
//     java.awt.Shape var24 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
//     var25.clear();
//     java.awt.Shape var28 = var25.getShape(100);
//     int var29 = var25.size();
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var42);
//     java.awt.Shape var44 = null;
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var38, var42);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var42, 10.0d, 10.0f, 100.0f);
//     var25.setShape(1, var42);
//     var25.clear();
//     java.lang.Object var53 = var25.clone();
//     java.lang.Object var54 = var25.clone();
//     java.lang.Object var55 = var25.clone();
//     boolean var56 = var0.equals(var55);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var0.", var25.equals(var0) == var0.equals(var25));
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var0.setShape(0, var6);
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(100);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//     boolean var7 = var1.equals((java.lang.Object)(-1.0f));
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     var1.setShape(1, var11);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var11, 100.0d, 10.0f, 0.0f);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var10 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)1.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var22, 0.0d, 10.0f, 100.0f);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.lang.Class var5 = null;
//     java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
//     boolean var7 = var0.equals((java.lang.Object)var5);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)100.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 1.0d, 100.0f, 10.0f);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var12, var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setShape((-1), var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     java.lang.Object var4 = var1.clone();
//     java.awt.Shape var6 = var1.getShape(10);
//     java.lang.Object var7 = var1.clone();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var10 = var1.equals((java.lang.Object)var9);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var9, (-1.0d), 0.0f, 0.0f);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    java.lang.Object var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    boolean var3 = var1.equals((java.lang.Object)(short)1);
    int var4 = var1.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var1.setShape(0, var7);
    var1.clear();
    java.lang.Object var10 = null;
    boolean var11 = var1.equals(var10);
    boolean var12 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    boolean var4 = var2.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    boolean var8 = var2.equals((java.lang.Object)var5);
    int var9 = var2.size();
    java.lang.Object var10 = var2.clone();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var2);
    java.lang.Object var12 = var2.clone();
    int var13 = var2.size();
    int var14 = var2.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     var0.setShape(10, var5);
//     java.lang.Class var12 = null;
//     java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var12);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
//     boolean var15 = var0.equals((java.lang.Object)var13);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 1.0d, 100.0f, (-1.0f));
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var20, var27);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var20, var30);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, (-1.0d), 1.0f, 10.0f);
//     boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var30);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var40, var44);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var48);
//     java.awt.Shape var50 = null;
//     boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var48, var50);
//     boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var44, var48);
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var56 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var44, (java.lang.Object)1.0f);
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.clone(var44);
//     java.lang.Object var58 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var57);
//     boolean var59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var36, (java.lang.Object)var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    var2.clear();
    var2.clear();
    java.awt.Shape var6 = var2.getShape(1);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var9 = var7.getShape(0);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var11 = var10.clone();
    boolean var12 = var7.equals(var11);
    java.lang.Object var13 = var7.clone();
    boolean var14 = var2.equals((java.lang.Object)var7);
    var2.clear();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var2);
    java.awt.Shape var18 = var2.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var0, var3);
    org.jfree.chart.util.RectangleAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, var5, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     int var5 = var0.size();
//     java.awt.Shape var7 = var0.getShape(1);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     var8.clear();
//     java.awt.Shape var12 = var8.getShape(1);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     java.awt.Shape var17 = null;
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var15, var17);
//     boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var18);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, (-1.0d), (-1.0f), 0.0f);
//     var8.setShape(0, var23);
//     java.awt.Shape var30 = var8.getShape(10);
//     java.awt.Shape var32 = var8.getShape(0);
//     boolean var33 = var0.equals((java.lang.Object)0);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.lang.Object var13 = var0.clone();
    var0.clear();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, 0.0d, (-1.0d));
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var26, var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    org.jfree.chart.util.ShapeList var41 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var42 = var41.clone();
    java.lang.Object var43 = var41.clone();
    java.awt.Shape var45 = var41.getShape(10);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.rotateShape(var52, 1.0d, 100.0f, (-1.0f));
    boolean var57 = org.jfree.chart.util.ShapeUtilities.equal(var49, var56);
    var41.setShape(10, var49);
    org.jfree.chart.util.ShapeList var59 = new org.jfree.chart.util.ShapeList();
    var59.clear();
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.clone(var64);
    java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.clone(var68);
    boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var65, var69);
    var59.setShape(100, var65);
    boolean var72 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var49, (java.lang.Object)var65);
    boolean var73 = org.jfree.chart.util.ShapeUtilities.equal(var39, var65);
    java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    boolean var77 = org.jfree.chart.util.ShapeUtilities.equal(var39, var76);
    boolean var78 = org.jfree.chart.util.ShapeUtilities.equal(var31, var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var76);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 100.0f, (-1.0f));
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var14);
//     boolean var16 = var3.equals((java.lang.Object)var14);
//     java.awt.Shape var18 = var3.getShape((-1));
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, (-1.0d), 0.0d);
//     var3.setShape(10, var28);
//     boolean var30 = var0.equals((java.lang.Object)var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    int var9 = var0.size();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, (-1.0f), 10.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 10.0d, 10.0f, 0.0f);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    java.lang.Object var0 = null;
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var4 = var2.getShape(0);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     var2.setShape(10, var7);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var1, var7);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, 1.0f, 1.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, (-1.0d), (-1.0f), 10.0f);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 1.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, 10.0d, 1.0f, 1.0f);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)100.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)var10);
    org.jfree.chart.util.RectangleAnchor var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, var12, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    boolean var3 = var1.equals((java.lang.Object)(short)1);
    int var4 = var1.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var1.setShape(0, var7);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 0.0f, 10.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     boolean var10 = var8.equals((java.lang.Object)(byte)10);
//     java.lang.Object var11 = var8.clone();
//     java.lang.Object var12 = var8.clone();
//     int var13 = var8.size();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     boolean var17 = var8.equals((java.lang.Object)var15);
//     var0.setShape(0, var15);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var0.setShape(0, var6);
    org.jfree.chart.util.RectangleAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var8, 100.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = var0.getShape((-1));
    int var9 = var0.size();
    java.awt.Shape var10 = null;
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var10, var14);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 10.0d, 10.0d);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = var0.equals((java.lang.Object)var28);
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, (-1.0d));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 0.0d, 0.0f, (-1.0f));
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
    boolean var17 = var0.equals((java.lang.Object)var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    var0.setShape(0, var20);
    java.awt.Shape var25 = var0.getShape(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.lang.Object var3 = var0.clone();
    int var4 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    java.lang.Object var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)100.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var10 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var9);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    org.jfree.chart.util.RectangleAnchor var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, var12, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var7);
    int var9 = var0.size();
    java.lang.Object var10 = var0.clone();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     var6.clear();
//     var6.clear();
//     java.lang.Object var9 = var6.clone();
//     boolean var11 = var6.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var13 = var6.getShape((-1));
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var6);
//     int var15 = var6.size();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var20 = null;
//     boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var18, var20);
//     boolean var22 = var6.equals((java.lang.Object)var21);
//     org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
//     var23.clear();
//     java.awt.Shape var26 = var23.getShape(100);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var23.setShape(10, var30);
//     org.jfree.chart.util.ShapeList var32 = new org.jfree.chart.util.ShapeList();
//     var32.clear();
//     java.awt.Shape var35 = var32.getShape(100);
//     int var36 = var32.size();
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var32.setShape(0, var39);
//     boolean var41 = var23.equals((java.lang.Object)var39);
//     boolean var42 = var6.equals((java.lang.Object)var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var23
//     assertTrue("Contract failed: equals-hashcode on var0 and var23", var0.equals(var23) ? var0.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var32
//     assertTrue("Contract failed: equals-hashcode on var0 and var32", var0.equals(var32) ? var0.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var32
//     assertTrue("Contract failed: equals-hashcode on var3 and var32", var3.equals(var32) ? var3.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var23.", var0.equals(var23) == var23.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var32.", var0.equals(var32) == var32.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var23.", var3.equals(var23) == var23.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var32.", var3.equals(var32) == var32.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var23.", var6.equals(var23) == var23.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var32.", var6.equals(var32) == var32.equals(var6));
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = var0.clone();
//     boolean var5 = var0.equals((java.lang.Object)(byte)0);
//     var0.clear();
//     var0.clear();
//     var0.clear();
//     int var9 = var0.size();
//     org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var11 = var10.clone();
//     java.lang.Object var12 = var10.clone();
//     int var13 = var10.size();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     var10.setShape(10, var17);
//     boolean var19 = var0.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var10.", var0.equals(var10) == var10.equals(var0));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    java.awt.Shape var10 = var0.getShape(10);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, (-1.0d), 1.0f, (-1.0f));
    boolean var19 = var0.equals((java.lang.Object)(-1.0d));
    java.awt.Shape var21 = null;
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var21, var24);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 1.0d, 10.0f, 100.0f);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var24, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
//     boolean var17 = var0.equals((java.lang.Object)var16);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     var18.clear();
//     var18.clear();
//     java.awt.Shape var22 = var18.getShape(1);
//     boolean var24 = var18.equals((java.lang.Object)' ');
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     var18.setShape(100, var27);
//     boolean var29 = var0.equals((java.lang.Object)var27);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var18.", var0.equals(var18) == var18.equals(var0));
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = var0.equals((java.lang.Object)var13);
    java.lang.Object var15 = var0.clone();
    java.awt.Shape var17 = var0.getShape(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var0, var3);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 10.0f, 100.0f);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var3, var11);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 100.0d, 0.0f, (-1.0f));
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 1.0d, 100.0f, (-1.0f));
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var3, var10);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 0.0f, (-1.0f));
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, (-1.0d), 0.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var23, 10.0d, 0.0f, 10.0f);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = var0.clone();
//     boolean var5 = var0.equals((java.lang.Object)(byte)0);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = var0.getShape((-1));
//     var0.clear();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 10.0d, 100.0f, 100.0f);
//     var0.setShape(0, var15);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     var21.clear();
//     var21.clear();
//     java.awt.Shape var25 = var21.getShape(1);
//     boolean var27 = var21.equals((java.lang.Object)' ');
//     java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
//     java.lang.Object var29 = var21.clone();
//     java.lang.Object var30 = null;
//     boolean var31 = var21.equals(var30);
//     boolean var32 = var0.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
    boolean var17 = var0.equals((java.lang.Object)var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    var0.setShape(0, var20);
    java.awt.Shape var25 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
    var26.clear();
    var26.clear();
    java.awt.Shape var30 = var26.getShape(1);
    boolean var32 = var26.equals((java.lang.Object)(-1));
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    java.awt.Shape var47 = null;
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var45, var47);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var41, var45);
    var26.setShape(100, var41);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 10.0d, 1.0f, 0.0f);
    boolean var55 = org.jfree.chart.util.ShapeUtilities.equal(var25, var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, (-1.0d), var2);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, (-1.0d), 0.0d);
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, (-1.0d), 100.0f, 100.0f);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var3, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var6 = var4.getShape(0);
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var8 = var7.clone();
//     boolean var9 = var4.equals(var8);
//     java.awt.Shape var11 = var4.getShape((-1));
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     boolean var16 = var4.equals((java.lang.Object)var14);
//     boolean var17 = var0.equals((java.lang.Object)var14);
//     java.lang.Object var18 = null;
//     boolean var19 = var0.equals(var18);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 1.0d, 100.0f, 10.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 0.0d, (-1.0d));
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var31, var36);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var40, var44);
//     org.jfree.chart.util.ShapeList var46 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var47 = var46.clone();
//     java.lang.Object var48 = var46.clone();
//     java.awt.Shape var50 = var46.getShape(10);
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.rotateShape(var57, 1.0d, 100.0f, (-1.0f));
//     boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var54, var61);
//     var46.setShape(10, var54);
//     org.jfree.chart.util.ShapeList var64 = new org.jfree.chart.util.ShapeList();
//     var64.clear();
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.clone(var69);
//     java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.clone(var73);
//     boolean var75 = org.jfree.chart.util.ShapeUtilities.equal(var70, var74);
//     var64.setShape(100, var70);
//     boolean var77 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var54, (java.lang.Object)var70);
//     boolean var78 = org.jfree.chart.util.ShapeUtilities.equal(var44, var70);
//     java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
//     boolean var82 = org.jfree.chart.util.ShapeUtilities.equal(var44, var81);
//     boolean var83 = org.jfree.chart.util.ShapeUtilities.equal(var36, var81);
//     var0.setShape(0, var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var46
//     assertTrue("Contract failed: equals-hashcode on var4 and var46", var4.equals(var46) ? var4.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var64
//     assertTrue("Contract failed: equals-hashcode on var4 and var64", var4.equals(var64) ? var4.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var46
//     assertTrue("Contract failed: equals-hashcode on var7 and var46", var7.equals(var46) ? var7.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var64
//     assertTrue("Contract failed: equals-hashcode on var7 and var64", var7.equals(var64) ? var7.hashCode() == var64.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var46.", var4.equals(var46) == var46.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var64.", var4.equals(var64) == var64.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var46.", var7.equals(var46) == var46.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var64.", var7.equals(var64) == var64.equals(var7));
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 10.0d, 100.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 0.0d, 10.0f, 1.0f);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = null;
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
    var0.setShape(0, var15);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = null;
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var27, var31);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var23, var27);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var27, 100.0d, 0.0f, (-1.0f));
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var22, var37);
    boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0, (java.lang.Object)var22);
    java.io.ObjectOutputStream var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var22, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.io.ObjectOutputStream var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     var1.clear();
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = var1.equals((java.lang.Object)var9);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var9, 0.0d, 1.0f, (-1.0f));
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     java.awt.Shape var9 = var0.getShape(100);
//     java.lang.Object var10 = var0.clone();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     java.awt.Shape var25 = null;
//     boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var23, var25);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 10.0d, 10.0f, 100.0f);
//     var0.setShape(1, var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.awt.Shape var14 = var0.getShape(0);
    var0.clear();
    java.awt.Shape var17 = var0.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 1.0d, 100.0f, (-1.0f));
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var5, var12);
//     boolean var14 = var1.equals((java.lang.Object)var12);
//     java.awt.Shape var16 = var1.getShape((-1));
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, (-1.0d), 0.0d);
//     var1.setShape(10, var26);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var26, 100.0d, 0.0f, 0.0f);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var15 = null;
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var13, var15);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var1, var18);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 10.0d, (-1.0f), 10.0f);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.awt.Shape var14 = var0.getShape(0);
//     var0.clear();
//     boolean var17 = var0.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var19 = null;
//     var0.setShape(1, var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.awt.Shape var8 = null;
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, (-1.0d));
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var32);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 1.0d, 0.0f, (-1.0f));
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var25, var32);
    var0.setShape(11, var25);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, 1.0d, 100.0f, (-1.0f));
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var44, var51);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.rotateShape(var44, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var56, 1.0d, 100.0f, 0.0f);
    var0.setShape(0, var60);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    java.awt.Shape var6 = null;
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var9 = var7.getShape(0);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var11 = var10.clone();
    boolean var12 = var7.equals(var11);
    java.lang.Object var13 = var7.clone();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var17 = var7.equals((java.lang.Object)var16);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 100.0f, 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, (-1.0d), (-1.0f), 0.0f);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var25, var32);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 10.0d, 0.0d);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var6, var25);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var1, var6);
    java.io.ObjectOutputStream var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 0.0f, (-1.0f));
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var2, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var28 = null;
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var26, var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var0, var26);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 0.0d, 0.0d);
    java.io.ObjectOutputStream var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var7 = var6.clone();
//     java.lang.Object var8 = var6.clone();
//     var6.clear();
//     boolean var10 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     boolean var13 = var11.equals((java.lang.Object)(byte)10);
//     java.lang.Object var14 = var11.clone();
//     java.lang.Object var15 = var11.clone();
//     java.lang.Object var16 = var11.clone();
//     boolean var17 = var6.equals((java.lang.Object)var11);
//     java.awt.Shape var19 = null;
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var19, var22);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var25);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var30, 100.0d, 100.0d);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 0.0d, (-1.0f), 0.0f);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var19, var33);
//     var6.setShape(0, var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var6
//     assertTrue("Contract failed: equals-hashcode on var11 and var6", var11.equals(var6) ? var11.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var6.", var11.equals(var6) == var6.equals(var11));
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = var0.getShape(1);
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 100.0d, 100.0d);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, (-1.0f), 0.0f);
    java.io.ObjectOutputStream var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     var1.clear();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     var1.setShape(1, var8);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var8, (-1.0d), 100.0f, 10.0f);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var15 = null;
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, (-1.0d));
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, (-1.0d), 0.0d);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 10.0d, 100.0f, 100.0f);
    org.jfree.chart.util.RectangleAnchor var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, var41, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 0.0d, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    var0.setShape(10, var7);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.lang.Object var17 = null;
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, var17);
    java.io.ObjectOutputStream var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var11, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), 100.0f, 0.0f);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var26, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = var0.getShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    boolean var17 = var15.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    var18.clear();
    boolean var21 = var15.equals((java.lang.Object)var18);
    int var22 = var15.size();
    java.lang.Object var23 = var15.clone();
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)(-1.0f), (java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var11, var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var21 = null;
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var19, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    var0.setShape(100, var15);
    java.awt.Shape var26 = var0.getShape(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)1.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
//     boolean var24 = var22.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
//     var25.clear();
//     var25.clear();
//     boolean var28 = var22.equals((java.lang.Object)var25);
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)var28);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var21, 100.0d, 1.0f, 10.0f);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    var7.clear();
    java.lang.Object var10 = var7.clone();
    boolean var12 = var7.equals((java.lang.Object)(byte)0);
    java.awt.Shape var14 = var7.getShape((-1));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    boolean var18 = var7.equals((java.lang.Object)var16);
    boolean var19 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var22 = var20.getShape(0);
    java.lang.Object var23 = var20.clone();
    java.awt.Shape var25 = var20.getShape(10);
    java.lang.Object var26 = var20.clone();
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var29 = var20.equals((java.lang.Object)var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var33, (java.lang.Object)100.0f);
    boolean var37 = var20.equals((java.lang.Object)var36);
    java.awt.Shape var39 = var20.getShape(0);
    java.lang.Object var40 = var20.clone();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     var6.clear();
//     var6.clear();
//     java.lang.Object var9 = var6.clone();
//     boolean var11 = var6.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var13 = var6.getShape((-1));
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var6);
//     var6.clear();
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     java.awt.Shape var30 = null;
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var28, var30);
//     boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, 100.0d, 100.0d);
//     var6.setShape(10, var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var6
//     assertTrue("Contract failed: equals-hashcode on var3 and var6", var3.equals(var6) ? var3.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var6.", var3.equals(var6) == var6.equals(var3));
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), 10.0d);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.clone(var56);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.clone(var60);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var57, var61);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.clone(var65);
    java.awt.Shape var67 = null;
    boolean var68 = org.jfree.chart.util.ShapeUtilities.equal(var65, var67);
    boolean var69 = org.jfree.chart.util.ShapeUtilities.equal(var61, var65);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 10.0d, 10.0f, 100.0f);
    boolean var74 = org.jfree.chart.util.ShapeUtilities.equal(var53, var65);
    java.awt.Shape var75 = null;
    java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var79 = org.jfree.chart.util.ShapeUtilities.clone(var78);
    java.awt.Shape var82 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var83 = org.jfree.chart.util.ShapeUtilities.clone(var82);
    boolean var84 = org.jfree.chart.util.ShapeUtilities.equal(var79, var83);
    boolean var85 = org.jfree.chart.util.ShapeUtilities.equal(var75, var79);
    java.awt.Shape var89 = org.jfree.chart.util.ShapeUtilities.rotateShape(var79, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var92 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var89, 10.0d, 10.0d);
    boolean var93 = org.jfree.chart.util.ShapeUtilities.equal(var53, var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 1.0d, 100.0f, (-1.0f));
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var5, var12);
//     boolean var14 = var1.equals((java.lang.Object)var12);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var12, 1.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     boolean var6 = var0.equals((java.lang.Object)' ');
//     java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.lang.Object var8 = var0.clone();
//     int var9 = var0.size();
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, (-1.0d));
//     var0.setShape(10, var15);
//     java.awt.Shape var18 = var0.getShape((-1));
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 1.0d, 10.0f, 100.0f);
//     var0.setShape(100, var22);
//     org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
//     var28.clear();
//     java.awt.Shape var31 = var28.getShape(100);
//     int var32 = var28.size();
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
//     boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
//     java.awt.Shape var47 = null;
//     boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var45, var47);
//     boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var41, var45);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.rotateShape(var45, 10.0d, 10.0f, 100.0f);
//     var28.setShape(1, var45);
//     var28.clear();
//     java.lang.Object var56 = var28.clone();
//     java.lang.Object var57 = var28.clone();
//     java.lang.Object var58 = var28.clone();
//     boolean var59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var0.", var28.equals(var0) == var0.equals(var28));
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, (-1.0d), 0.0d);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 1.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, (-1.0d), 10.0d);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var16 = var15.clone();
    java.lang.Object var17 = var15.clone();
    var15.clear();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var15.setShape(100, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 100.0d, 0.0d);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var14, var22);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 0.0d, 1.0f, (-1.0f));
    boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var3, 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     boolean var3 = var1.equals((java.lang.Object)(byte)10);
//     java.lang.Object var4 = var1.clone();
//     java.lang.Object var5 = var1.clone();
//     var1.clear();
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var8 = var7.clone();
//     java.lang.Object var9 = var7.clone();
//     var7.clear();
//     java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     boolean var16 = var7.equals((java.lang.Object)var15);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     boolean var21 = var7.equals((java.lang.Object)var20);
//     boolean var22 = var1.equals((java.lang.Object)var20);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var20, (-1.0d), 0.0f, 0.0f);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.lang.Object var10 = var0.clone();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.lang.Object var5 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
//     var0.setShape(1, var13);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)var21);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, (-1.0d));
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 0.0d, 100.0f, 10.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
//     org.jfree.chart.util.ShapeList var31 = new org.jfree.chart.util.ShapeList();
//     var31.clear();
//     var31.clear();
//     java.lang.Object var34 = var31.clone();
//     boolean var36 = var31.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var38 = var31.getShape((-1));
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
//     boolean var42 = var31.equals((java.lang.Object)var40);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var40, 1.0d, 10.0f, (-1.0f));
//     boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var29, var46);
//     var0.setShape(10, var46);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var0.", var31.equals(var0) == var0.equals(var31));
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     java.awt.Shape var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     var1.setShape(10, var6);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var0, var6);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, 1.0f, 1.0f);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     var18.clear();
//     var18.clear();
//     java.lang.Object var21 = var18.clone();
//     boolean var23 = var18.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var25 = var18.getShape((-1));
//     boolean var26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var18);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var1.", var18.equals(var1) == var1.equals(var18));
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     boolean var6 = var0.equals((java.lang.Object)(-1));
//     java.awt.Shape var8 = var0.getShape(0);
//     int var9 = var0.size();
//     org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var11 = var10.clone();
//     java.lang.Object var12 = var10.clone();
//     var10.clear();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var10.setShape(100, var17);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var20, (java.lang.Object)var23);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 0.0d, (-1.0d));
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var17, var23);
//     boolean var29 = var0.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var10.", var0.equals(var10) == var10.equals(var0));
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 10.0f, 1.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, (-1.0d), 1.0d);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, 100.0f, 1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var18, 10.0d, 1.0f, 0.0f);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     boolean var8 = var6.equals((java.lang.Object)(byte)10);
//     java.lang.Object var9 = var6.clone();
//     java.lang.Object var10 = var6.clone();
//     java.lang.Object var11 = var6.clone();
//     org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var14 = var12.getShape(0);
//     org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var16 = var15.clone();
//     boolean var17 = var12.equals(var16);
//     java.lang.Object var18 = var12.clone();
//     boolean var19 = var6.equals(var18);
//     boolean var20 = var0.equals((java.lang.Object)var6);
//     java.awt.Shape var22 = var6.getShape(10);
//     org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var24 = var23.clone();
//     java.lang.Object var25 = var23.clone();
//     int var26 = var23.size();
//     java.awt.Shape var28 = var23.getShape(0);
//     java.awt.Shape var30 = var23.getShape(10);
//     java.awt.Shape var32 = var23.getShape(100);
//     java.lang.Object var33 = var23.clone();
//     boolean var34 = var6.equals(var33);
//     org.jfree.chart.util.ShapeList var36 = new org.jfree.chart.util.ShapeList();
//     boolean var38 = var36.equals((java.lang.Object)(short)1);
//     int var39 = var36.size();
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var36.setShape(0, var42);
//     java.awt.Shape var45 = null;
//     org.jfree.chart.util.ShapeList var46 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var48 = var46.getShape(0);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.rotateShape(var51, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var51);
//     var46.setShape(10, var51);
//     boolean var58 = org.jfree.chart.util.ShapeUtilities.equal(var45, var51);
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.rotateShape(var51, 0.0d, 1.0f, 1.0f);
//     var36.setShape(1, var51);
//     var6.setShape(100, var51);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var6
//     assertTrue("Contract failed: equals-hashcode on var12 and var6", var12.equals(var6) ? var12.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var46
//     assertTrue("Contract failed: equals-hashcode on var12 and var46", var12.equals(var46) ? var12.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var6
//     assertTrue("Contract failed: equals-hashcode on var15 and var6", var15.equals(var6) ? var15.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var36
//     assertTrue("Contract failed: equals-hashcode on var15 and var36", var15.equals(var36) ? var15.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var46
//     assertTrue("Contract failed: equals-hashcode on var15 and var46", var15.equals(var46) ? var15.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var36
//     assertTrue("Contract failed: equals-hashcode on var23 and var36", var23.equals(var36) ? var23.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var46
//     assertTrue("Contract failed: equals-hashcode on var23 and var46", var23.equals(var46) ? var23.hashCode() == var46.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var36.", var0.equals(var36) == var36.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var46.", var0.equals(var46) == var46.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var6.", var12.equals(var6) == var6.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var36.", var12.equals(var36) == var36.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var46.", var12.equals(var46) == var46.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var6.", var15.equals(var6) == var6.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var36.", var15.equals(var36) == var36.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var46.", var15.equals(var46) == var46.equals(var15));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var6.", var23.equals(var6) == var6.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var36.", var23.equals(var36) == var36.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var46.", var23.equals(var46) == var46.equals(var23));
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = var0.clone();
    int var20 = var0.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    java.awt.Shape var6 = var3.getShape(100);
    int var7 = var3.size();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = null;
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 10.0f, 100.0f);
    var3.setShape(1, var20);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var1, var20);
    org.jfree.chart.util.RectangleAnchor var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var31, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     var0.clear();
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     int var5 = var0.size();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 100.0f, 10.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 10.0d, 100.0d);
//     var0.setShape(0, var17);
//     org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var24 = var22.getShape(0);
//     java.lang.Object var25 = var22.clone();
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var28 = var22.equals((java.lang.Object)var27);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var27, 0.0d, 1.0d);
//     org.jfree.chart.util.ShapeList var32 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var34 = var32.getShape(0);
//     java.lang.Object var35 = var32.clone();
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var38 = var32.equals((java.lang.Object)var37);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 1.0d);
//     boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var27, var41);
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var17, var41);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var0
//     assertTrue("Contract failed: equals-hashcode on var32 and var0", var32.equals(var0) ? var32.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var0.", var22.equals(var0) == var0.equals(var22));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var0.", var32.equals(var0) == var0.equals(var32));
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var6 = var4.getShape(0);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var8 = var7.clone();
    boolean var9 = var4.equals(var8);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = var4.equals((java.lang.Object)var14);
    boolean var17 = var0.equals((java.lang.Object)var14);
    java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
    java.io.ObjectOutputStream var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var14, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var15, 100.0d, 100.0f, 10.0f);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    var0.setShape(100, var6);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 1.0d, 1.0d);
    java.io.ObjectOutputStream var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var1.equals(var5);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     java.awt.Shape var11 = var8.getShape(100);
//     int var12 = var8.size();
//     boolean var13 = var1.equals((java.lang.Object)var12);
//     java.awt.Shape var15 = var1.getShape(10);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)100.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, 0.0d, (-1.0f), 100.0f);
//     boolean var29 = var1.equals((java.lang.Object)var24);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var24, 0.0d, 0.0f, (-1.0f));
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    var0.clear();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    boolean var11 = var0.equals((java.lang.Object)0);
    java.lang.Object var12 = var0.clone();
    java.awt.Shape var14 = var0.getShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var9 = var0.getShape(0);
    java.lang.Object var10 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    var0.setShape(1, var7);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    java.lang.Object var11 = var9.clone();
    java.awt.Shape var13 = var9.getShape(10);
    java.awt.Shape var15 = var9.getShape(100);
    java.awt.Shape var17 = null;
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, (-1.0d));
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var37, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var41);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 1.0d, 0.0f, (-1.0f));
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var34, var41);
    var9.setShape(11, var34);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    boolean var51 = var0.equals((java.lang.Object)var50);
    java.io.ObjectOutputStream var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var50, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 100.0f, 100.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 0.0d, 0.0f, (-1.0f));
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 1.0d, 100.0f, 0.0f);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 10.0f, 100.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 0.0d, 100.0f, (-1.0f));
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var12, var23);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var29, 100.0d, 100.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var32, 100.0d, 0.0f, 100.0f);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    java.lang.Object var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    boolean var3 = var1.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    var4.clear();
    var4.clear();
    boolean var7 = var1.equals((java.lang.Object)var4);
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.lang.Object var9 = var1.clone();
    java.awt.Shape var11 = var1.getShape(100);
    java.lang.Object var12 = var1.clone();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
//     boolean var17 = var0.equals((java.lang.Object)var16);
//     java.awt.Shape var19 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     boolean var23 = var21.equals((java.lang.Object)(byte)10);
//     java.lang.Object var24 = var21.clone();
//     java.lang.Object var25 = var21.clone();
//     int var26 = var21.size();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     boolean var30 = var21.equals((java.lang.Object)var28);
//     var0.setShape(101, var28);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 1.0d, 100.0f, (-1.0f));
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var3, var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var0, var15);
    java.io.ObjectOutputStream var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var15, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var6 = var4.getShape(0);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var8 = var7.clone();
    boolean var9 = var4.equals(var8);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = var4.equals((java.lang.Object)var14);
    boolean var17 = var0.equals((java.lang.Object)var14);
    int var18 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     var7.clear();
//     java.awt.Shape var10 = var7.getShape(100);
//     int var11 = var7.size();
//     boolean var12 = var0.equals((java.lang.Object)var11);
//     java.awt.Shape var14 = var0.getShape(10);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)100.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 0.0d, (-1.0f), 100.0f);
//     boolean var28 = var0.equals((java.lang.Object)var23);
//     java.awt.Shape var30 = null;
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 100.0d, 0.0f, (-1.0f));
//     var0.setShape(0, var44);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.lang.Object var13 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var12 = var11.clone();
    boolean var13 = var8.equals(var12);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    var14.clear();
    var14.clear();
    java.lang.Object var17 = var14.clone();
    boolean var19 = var14.equals((java.lang.Object)(byte)0);
    java.awt.Shape var21 = var14.getShape((-1));
    boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var14);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var25 = var23.getShape(0);
    java.lang.Object var26 = var23.clone();
    java.awt.Shape var28 = var23.getShape(10);
    java.lang.Object var29 = var23.clone();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var32 = var23.equals((java.lang.Object)var31);
    boolean var33 = var14.equals((java.lang.Object)var32);
    boolean var34 = var0.equals((java.lang.Object)var33);
    java.lang.Object var35 = var0.clone();
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, (-1.0d));
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal(var35, (java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     java.lang.Object var4 = var1.clone();
//     java.awt.Shape var6 = var1.getShape(10);
//     int var7 = var1.size();
//     java.lang.Object var8 = var1.clone();
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     var1.setShape(100, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var16, (-1.0d), (-1.0f), 1.0f);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    boolean var5 = var3.equals((java.lang.Object)(byte)10);
    java.lang.Object var6 = var3.clone();
    java.lang.Object var7 = var3.clone();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 0.0d, 100.0d);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
//     boolean var13 = var0.equals((java.lang.Object)var11);
//     java.awt.Shape var15 = var0.getShape((-1));
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
//     var0.setShape(10, var25);
//     java.lang.Object var27 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var27
//     assertTrue("Contract failed: equals-hashcode on var1 and var27", var1.equals(var27) ? var1.hashCode() == var27.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var27.", var1.equals(var27) == var27.equals(var1));
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var7 = var5.getShape(0);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var5.equals(var9);
//     java.lang.Object var11 = var5.clone();
//     boolean var12 = var0.equals((java.lang.Object)var5);
//     java.awt.Shape var14 = var0.getShape(1);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)var20);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var25, var29);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
//     java.awt.Shape var35 = null;
//     boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var33, var35);
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var29, var33);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var29, (java.lang.Object)1.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var29);
//     boolean var43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var20, (java.lang.Object)var42);
//     java.lang.Object var44 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
//     var0.setShape(1, var42);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.io.ObjectOutputStream var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var10, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = var0.clone();
//     boolean var5 = var0.equals((java.lang.Object)100L);
//     java.lang.Object var6 = var0.clone();
//     var0.clear();
//     java.lang.Object var8 = var0.clone();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     var11.clear();
//     var11.clear();
//     java.awt.Shape var15 = var11.getShape(1);
//     boolean var17 = var11.equals((java.lang.Object)' ');
//     java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
//     java.lang.Object var19 = var11.clone();
//     int var20 = var11.size();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 0.0d, (-1.0d));
//     var11.setShape(10, var26);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var10, var26);
//     boolean var29 = var0.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var11.", var0.equals(var11) == var11.equals(var0));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.awt.Shape var14 = var0.getShape(0);
    var0.clear();
    boolean var17 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 10.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 0.0f, 0.0f);
    boolean var25 = var0.equals((java.lang.Object)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.lang.Object var5 = var0.clone();
    java.lang.Object var6 = var0.clone();
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
    var0.setShape(0, var15);
    java.awt.Shape var22 = var0.getShape(10);
    java.awt.Shape var24 = var0.getShape(0);
    java.awt.Shape var26 = var0.getShape(1);
    java.lang.Object var27 = var0.clone();
    java.lang.Object var28 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    var0.setShape(10, var5);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     java.lang.Object var8 = var0.clone();
//     java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
//     var0.setShape(101, var13);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 10.0d, 10.0f, 1.0f);
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var7, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.0d, 0.0f, 100.0f);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.awt.Shape var14 = var0.getShape(0);
    var0.clear();
    boolean var17 = var0.equals((java.lang.Object)(byte)0);
    int var18 = var0.size();
    java.lang.Object var19 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape(100);
    java.awt.Shape var9 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.awt.Shape var14 = var10.getShape(1);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var17 = var15.getShape(0);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var19 = var18.clone();
    boolean var20 = var15.equals(var19);
    java.lang.Object var21 = var15.clone();
    boolean var22 = var10.equals((java.lang.Object)var15);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    var23.clear();
    var23.clear();
    java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var34 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 1.0d, 0.0f, (-1.0f));
    boolean var40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var23, (java.lang.Object)(-1.0f));
    java.lang.Object var41 = var23.clone();
    boolean var42 = var15.equals((java.lang.Object)var23);
    boolean var43 = var0.equals((java.lang.Object)var15);
    java.lang.Object var44 = var15.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    java.awt.Shape var10 = var7.getShape(100);
    int var11 = var7.size();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    java.awt.Shape var26 = null;
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, 10.0d, 10.0f, 100.0f);
    var7.setShape(1, var24);
    var7.clear();
    java.lang.Object var35 = var7.clone();
    int var36 = var7.size();
    boolean var37 = var3.equals((java.lang.Object)var7);
    org.jfree.chart.util.ShapeList var38 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var40 = var38.getShape(0);
    java.lang.Object var41 = var38.clone();
    java.awt.Shape var43 = var38.getShape(10);
    java.lang.Object var44 = var38.clone();
    boolean var45 = var3.equals(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    var11.clear();
    var11.clear();
    java.lang.Object var14 = var11.clone();
    boolean var15 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    boolean var24 = var0.equals((java.lang.Object)var19);
    java.io.ObjectOutputStream var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var19, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    var0.setShape(10, var5);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var0.setShape(0, var19);
    java.io.ObjectOutputStream var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var19, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 100.0d);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, (-1.0d), 0.0f, 0.0f);
    java.io.ObjectOutputStream var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    boolean var7 = var5.equals((java.lang.Object)(short)1);
    int var8 = var5.size();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var5.setShape(0, var11);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var2, var11);
    org.jfree.chart.util.RectangleAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var15, 100.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.awt.Shape var14 = null;
//     var0.setShape(11, var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 10.0f, 100.0f);
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, (-1.0d));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 1.0d, 1.0f, 100.0f);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     java.awt.Shape var9 = null;
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var9, (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var3 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 0.0d, (-1.0d));
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 0.0f, 100.0f);
    boolean var25 = var0.equals((java.lang.Object)var7);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    java.awt.Shape var40 = null;
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var38, var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.rotateShape(var48, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, (-1.0d), 0.0d);
    boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var46, var55);
    java.lang.Object var57 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var46);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.rotateShape(var46, 10.0d, 100.0f, 0.0f);
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var61, 0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var64);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
    var0.setShape(0, var15);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var23 = null;
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var27, var31);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var23, var27);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var27, 100.0d, 0.0f, (-1.0f));
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var22, var37);
    boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0, (java.lang.Object)var22);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.io.ObjectOutputStream var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var40, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 1.0d, 10.0f, 100.0f);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, (-1.0d), 0.0d);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, 0.0d, 1.0d);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, (-1.0d), 10.0d);
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal(var28, (java.lang.Object)10.0d);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0d, (java.lang.Object)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone(var11);
    boolean var13 = var0.equals(var11);
    java.lang.Object var14 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 1.0d, 100.0f, (-1.0f));
//     boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var3, var10);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var3, var13);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var16, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 10.0d, 1.0d);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var13, var23);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var23, 10.0d, 0.0f, 1.0f);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var0, var3);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 10.0f, 100.0f);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var3, var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, (-1.0d), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    java.awt.Shape var9 = var0.getShape(100);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 100.0d, var2);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    var8.clear();
    java.awt.Shape var11 = var8.getShape(100);
    java.lang.Object var12 = null;
    boolean var13 = var8.equals(var12);
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)100.0d, (java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.io.ObjectOutputStream var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 0.0d, (-1.0f), 0.0f);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    var0.setShape(10, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = null;
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, (-1.0f), 10.0f);
    boolean var33 = var0.equals((java.lang.Object)10.0f);
    java.awt.Shape var35 = var0.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var0, var17);
    java.io.ObjectOutputStream var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var17, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var15 = null;
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, (-1.0d));
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, (-1.0d), 0.0d);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, (-1.0d), 10.0d);
    org.jfree.chart.util.RectangleAnchor var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, var40, (-1.0d), (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var1.equals(var5);
//     java.lang.Object var7 = var1.clone();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var9);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var9, 1.0d, (-1.0f), 1.0f);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 1.0f);
    boolean var9 = var0.equals((java.lang.Object)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var10 = var0.equals((java.lang.Object)var9);
//     var0.clear();
//     org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var14 = var13.clone();
//     java.lang.Object var15 = var13.clone();
//     var13.clear();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var13.setShape(100, var20);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 100.0d, 0.0d);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
//     var0.setShape(100, var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var13.", var3.equals(var13) == var13.equals(var3));
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, (-1.0f));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), 1.0f, 0.0f);
    boolean var11 = var0.equals((java.lang.Object)var6);
    int var12 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var15 = null;
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var13, var15);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var1, var18);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var18, 0.0d, 100.0f, (-1.0f));
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 0.0d, 1.0f, (-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var9, var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 10.0d, 1.0d);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var7, var15);
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var18 = var17.clone();
    java.lang.Object var19 = var17.clone();
    var17.clear();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var17.setShape(100, var24);
    boolean var26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var24);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var28);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.0d, (-1.0f), 0.0f);
    boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var7, var28);
    org.jfree.chart.util.RectangleAnchor var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var35, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

}
