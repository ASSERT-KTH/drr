
import junit.framework.*;

public class RandoopTest4 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test1"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    var0.clear();
    java.lang.Object var12 = var0.clone();
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    var0.clear();
    java.lang.Object var15 = var0.clone();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test2"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.lang.Object var7 = var3.clone();
    java.lang.Object var8 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test3"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    var0.clear();
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test4"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var2, var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var15, var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 10.0d, 1.0d);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var12, var22);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test5"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 10.0f, (-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var9, var18);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 10.0d, (-1.0f), 100.0f);
    java.awt.Shape var24 = null;
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var27 = var25.getShape(0);
    org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var29 = var28.clone();
    boolean var30 = var25.equals(var29);
    java.lang.Object var31 = var25.clone();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var35 = var25.equals((java.lang.Object)var34);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var39, 100.0d, 100.0f, 10.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var46, (-1.0d), (-1.0f), 0.0f);
    boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var43, var50);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, 10.0d, 0.0d);
    boolean var55 = org.jfree.chart.util.ShapeUtilities.equal(var24, var43);
    boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var23, var24);
    org.jfree.chart.util.RectangleAnchor var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, var57, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test6"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    var9.clear();
    java.awt.Shape var12 = var9.getShape(100);
    int var13 = var9.size();
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var9);
    java.lang.Object var15 = var0.clone();
    var0.clear();
    java.lang.Object var17 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test7"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
    boolean var17 = var0.equals((java.lang.Object)var16);
    java.awt.Shape var19 = var0.getShape(0);
    java.lang.Object var20 = var0.clone();
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    java.awt.Shape var26 = var21.getShape(10);
    java.lang.Object var27 = var21.clone();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var30 = var21.equals((java.lang.Object)var29);
    java.awt.Shape var32 = var21.getShape(11);
    int var33 = var21.size();
    boolean var34 = var0.equals((java.lang.Object)var21);
    java.lang.Object var35 = var21.clone();
    var21.clear();
    int var37 = var21.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test8"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 100.0f, 100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 1.0d, 100.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var9, var16);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 1.0d, 100.0f, 0.0f);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var6, var25);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test9"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    java.awt.Shape var45 = null;
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), 10.0d);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.clone(var56);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.clone(var60);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var57, var61);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.clone(var65);
    java.awt.Shape var67 = null;
    boolean var68 = org.jfree.chart.util.ShapeUtilities.equal(var65, var67);
    boolean var69 = org.jfree.chart.util.ShapeUtilities.equal(var61, var65);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 10.0d, 10.0f, 100.0f);
    boolean var74 = org.jfree.chart.util.ShapeUtilities.equal(var53, var65);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.clone(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test10"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test11"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 0.0d);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var20, var29);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"hi!", (java.lang.Object)var29);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var29, 1.0d, 100.0d);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var37);
    org.jfree.chart.util.ShapeList var40 = new org.jfree.chart.util.ShapeList();
    boolean var42 = var40.equals((java.lang.Object)(short)1);
    int var43 = var40.size();
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var40.setShape(0, var46);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var46);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var37, var46);
    boolean var50 = org.jfree.chart.util.ShapeUtilities.equal(var29, var37);
    java.lang.Object var51 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test12"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var5, var10);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test13"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
//     var0.setShape(10, var8);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     var18.clear();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
//     var18.setShape(100, var24);
//     boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     java.awt.Shape var45 = null;
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
//     boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), 10.0d);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var53, (-1.0d), 0.0d);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var56, 10.0d, (-1.0d));
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.rotateShape(var59, 10.0d, 1.0f, 10.0f);
//     org.jfree.chart.util.ShapeList var64 = new org.jfree.chart.util.ShapeList();
//     boolean var66 = var64.equals((java.lang.Object)(byte)10);
//     java.lang.Object var67 = var64.clone();
//     java.lang.Object var68 = var64.clone();
//     var64.clear();
//     org.jfree.chart.util.ShapeList var70 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var71 = var70.clone();
//     java.lang.Object var72 = var70.clone();
//     var70.clear();
//     java.lang.Object var74 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var70);
//     java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.clone(var77);
//     boolean var79 = var70.equals((java.lang.Object)var78);
//     java.awt.Shape var82 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var83 = org.jfree.chart.util.ShapeUtilities.clone(var82);
//     boolean var84 = var70.equals((java.lang.Object)var83);
//     boolean var85 = var64.equals((java.lang.Object)var83);
//     boolean var86 = org.jfree.chart.util.ShapeUtilities.equal(var63, var83);
//     
//     // Checks the contract:  equals-hashcode on var64 and var0
//     assertTrue("Contract failed: equals-hashcode on var64 and var0", var64.equals(var0) ? var64.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var18
//     assertTrue("Contract failed: equals-hashcode on var64 and var18", var64.equals(var18) ? var64.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var0
//     assertTrue("Contract failed: equals-hashcode on var70 and var0", var70.equals(var0) ? var70.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var18
//     assertTrue("Contract failed: equals-hashcode on var70 and var18", var70.equals(var18) ? var70.hashCode() == var18.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var64 and var0.", var64.equals(var0) == var0.equals(var64));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var64 and var18.", var64.equals(var18) == var18.equals(var64));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var70 and var0.", var70.equals(var0) == var0.equals(var70));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var70 and var18.", var70.equals(var18) == var18.equals(var70));
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test14"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.lang.Class var5 = null;
    java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    java.lang.Object var8 = null;
    boolean var9 = var0.equals(var8);
    java.lang.Object var10 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test15"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    int var6 = var0.size();
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test16"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = var8.clone();
    java.lang.Object var10 = var8.clone();
    java.awt.Shape var12 = var8.getShape(10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 1.0d, 100.0f, (-1.0f));
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var23);
    var8.setShape(10, var16);
    org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
    var26.clear();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    var26.setShape(100, var32);
    boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)var32);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var6, var32);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var6, var43);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var43);
    org.jfree.chart.util.RectangleAnchor var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var45, var46, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test17"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    boolean var5 = var3.equals((java.lang.Object)(short)1);
    int var6 = var3.size();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var3.setShape(0, var9);
    var3.clear();
    java.lang.Object var12 = null;
    boolean var13 = var3.equals(var12);
    java.lang.Object var14 = var3.clone();
    boolean var15 = var0.equals((java.lang.Object)var3);
    java.lang.Object var16 = var3.clone();
    java.lang.Object var17 = var3.clone();
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var19 = var18.clone();
    java.lang.Object var20 = var18.clone();
    var18.clear();
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    boolean var27 = var18.equals((java.lang.Object)var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = var18.equals((java.lang.Object)var31);
    java.lang.Object var33 = var18.clone();
    org.jfree.chart.util.ShapeList var34 = new org.jfree.chart.util.ShapeList();
    boolean var36 = var34.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var37 = new org.jfree.chart.util.ShapeList();
    var37.clear();
    var37.clear();
    boolean var40 = var34.equals((java.lang.Object)var37);
    org.jfree.chart.util.ShapeList var41 = new org.jfree.chart.util.ShapeList();
    boolean var43 = var41.equals((java.lang.Object)(byte)10);
    java.lang.Object var44 = var41.clone();
    java.lang.Object var45 = var41.clone();
    java.lang.Object var46 = var41.clone();
    org.jfree.chart.util.ShapeList var47 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var48 = var47.clone();
    java.lang.Object var49 = var47.clone();
    var47.clear();
    boolean var51 = var41.equals((java.lang.Object)var47);
    boolean var52 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var40, (java.lang.Object)var41);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    boolean var55 = var41.equals((java.lang.Object)0.0f);
    boolean var56 = var18.equals((java.lang.Object)var55);
    org.jfree.chart.util.ShapeList var57 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var59 = var57.getShape(0);
    org.jfree.chart.util.ShapeList var60 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var61 = var60.clone();
    boolean var62 = var57.equals(var61);
    java.awt.Shape var64 = var57.getShape((-1));
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var67, (-1.0d), 1.0d);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var67, 0.0d, (-1.0d));
    boolean var74 = var57.equals((java.lang.Object)(-1.0d));
    boolean var75 = var18.equals((java.lang.Object)(-1.0d));
    java.lang.Object var76 = var18.clone();
    boolean var77 = var3.equals(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test18"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    int var6 = var0.size();
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test19"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)100L);
    java.lang.Object var6 = var0.clone();
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test20"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 1.0d, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test21"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var0.setShape(0, var6);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var25 = null;
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var23, var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)1.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, 10.0f, 1.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, 1.0d);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var6, var39);
    java.io.ObjectOutputStream var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test22"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, (-1.0d), 0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test23"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = var0.getShape(10);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var23 = null;
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var21, var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 100.0d, 100.0d);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.0d, 100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 10.0f);
//     boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var32, var35);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, (-1.0d), 1.0f, 10.0f);
//     var0.setShape(2, var40);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var44);
//     org.jfree.chart.util.ShapeList var46 = new org.jfree.chart.util.ShapeList();
//     var46.clear();
//     var46.clear();
//     java.lang.Object var49 = var46.clone();
//     boolean var51 = var46.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var53 = var46.getShape((-1));
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var55);
//     boolean var57 = var46.equals((java.lang.Object)var55);
//     boolean var58 = org.jfree.chart.util.ShapeUtilities.equal(var45, var55);
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, 10.0d, 0.0f, 100.0f);
//     boolean var63 = org.jfree.chart.util.ShapeUtilities.equal(var40, var62);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var46 and var0.", var46.equals(var0) == var0.equals(var46));
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test24"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    java.lang.Object var6 = null;
    boolean var7 = var0.equals(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test25"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, (-1.0d), 0.0d);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var1, var9);
    java.io.ObjectOutputStream var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var9, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test26"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.awt.Shape var14 = var0.getShape(0);
    var0.clear();
    java.lang.Object var16 = var0.clone();
    int var17 = var0.size();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test27"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 100.0f, 0.0f);
    boolean var15 = var0.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test28"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    java.awt.Shape var10 = var0.getShape(10);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, (-1.0d), 1.0f, (-1.0f));
    boolean var19 = var0.equals((java.lang.Object)(-1.0d));
    java.lang.Object var20 = var0.clone();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 10.0d, 0.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 100.0d, 1.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 1.0d, (-1.0f), 10.0f);
    boolean var39 = var0.equals((java.lang.Object)10.0f);
    int var40 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test29"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    var0.clear();
    int var7 = var0.size();
    int var8 = var0.size();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test30"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var30 = var29.clone();
    java.lang.Object var31 = var29.clone();
    var29.clear();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var29.setShape(100, var36);
    var0.setShape(100, var36);
    java.awt.Shape var40 = var0.getShape(102);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test31"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var12 = var11.clone();
    boolean var13 = var8.equals(var12);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    var14.clear();
    var14.clear();
    java.lang.Object var17 = var14.clone();
    boolean var19 = var14.equals((java.lang.Object)(byte)0);
    java.awt.Shape var21 = var14.getShape((-1));
    boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var14);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var25 = var23.getShape(0);
    java.lang.Object var26 = var23.clone();
    java.awt.Shape var28 = var23.getShape(10);
    java.lang.Object var29 = var23.clone();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var32 = var23.equals((java.lang.Object)var31);
    boolean var33 = var14.equals((java.lang.Object)var32);
    boolean var34 = var0.equals((java.lang.Object)var33);
    int var35 = var0.size();
    int var36 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test32"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    var0.clear();
    int var4 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var15, var20);
    boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test33"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    int var6 = var0.size();
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test34"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    boolean var4 = var2.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    boolean var8 = var2.equals((java.lang.Object)var5);
    int var9 = var2.size();
    java.lang.Object var10 = var2.clone();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var2);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var19 = var2.equals((java.lang.Object)var13);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 10.0d, 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test35"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), (-1.0d));
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var7, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test36"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = null;
//     boolean var3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, var2);
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     var5.clear();
//     var5.clear();
//     java.awt.Shape var9 = var5.getShape(1);
//     boolean var11 = var5.equals((java.lang.Object)(-1));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
//     boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
//     java.awt.Shape var26 = null;
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var24, var26);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
//     var5.setShape(100, var20);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 1.0f, 0.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 10.0d, 0.0d);
//     var1.setShape(101, var20);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var38, 0.0d, 1.0f, 10.0f);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test37"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 10.0d, 100.0f, 100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var10, 100.0d, 100.0f, 100.0f);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test38"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var1, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.lang.Object var13 = var10.clone();
    boolean var15 = var10.equals((java.lang.Object)(byte)0);
    java.awt.Shape var17 = var10.getShape((-1));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    boolean var21 = var10.equals((java.lang.Object)var19);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 1.0f, (-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var4, var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 100.0d, 100.0f, 100.0f);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var31, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test39"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var0.setShape(0, var19);
    java.awt.Shape var22 = var0.getShape(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test40"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    int var5 = var0.size();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 10.0d, 100.0d);
    var0.setShape(0, var17);
    var0.clear();
    java.lang.Object var23 = var0.clone();
    var0.clear();
    int var25 = var0.size();
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 100.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var31 = null;
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.rotateShape(var35, 100.0d, 0.0f, (-1.0f));
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var30, var45);
    org.jfree.chart.util.ShapeList var47 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var49 = var47.getShape(0);
    org.jfree.chart.util.ShapeList var50 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var51 = var50.clone();
    boolean var52 = var47.equals(var51);
    java.awt.Shape var54 = var47.getShape((-1));
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.clone(var57);
    boolean var59 = var47.equals((java.lang.Object)var57);
    java.awt.Shape var61 = var47.getShape(0);
    var47.clear();
    boolean var63 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var46, (java.lang.Object)var47);
    boolean var64 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0f, (java.lang.Object)var47);
    org.jfree.chart.util.ShapeList var65 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var66 = var65.clone();
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.rotateShape(var72, 1.0d, 100.0f, (-1.0f));
    boolean var77 = org.jfree.chart.util.ShapeUtilities.equal(var69, var76);
    boolean var78 = var65.equals((java.lang.Object)var76);
    java.awt.Shape var79 = org.jfree.chart.util.ShapeUtilities.clone(var76);
    boolean var80 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var47, (java.lang.Object)var76);
    java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.rotateShape(var76, 10.0d, 10.0f, 0.0f);
    boolean var85 = var0.equals((java.lang.Object)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test41"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, (-1.0f), 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 0.0d);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), 1.0f, 100.0f);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var2, var16);
    java.awt.Shape var18 = null;
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var2, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test42"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    java.lang.Object var8 = var0.clone();
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.awt.Shape var14 = var10.getShape(1);
    boolean var16 = var10.equals((java.lang.Object)' ');
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.lang.Object var18 = var10.clone();
    int var19 = var10.size();
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    var21.clear();
    var21.clear();
    java.lang.Object var24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.lang.Object var25 = var21.clone();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    var21.setShape(0, var30);
    var10.setShape(10, var30);
    var0.setShape(10, var30);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var43 = null;
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var41, var43);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 1.0d, 100.0d);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, (-1.0d), 0.0f, 1.0f);
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var30, var47);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test43"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     int var3 = var0.size();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, (-1.0d));
//     boolean var9 = var0.equals((java.lang.Object)var5);
//     int var10 = var0.size();
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     var11.clear();
//     var11.clear();
//     java.lang.Object var14 = var11.clone();
//     boolean var16 = var11.equals((java.lang.Object)100L);
//     java.lang.Object var17 = var11.clone();
//     java.lang.Object var18 = var11.clone();
//     java.lang.Object var19 = var11.clone();
//     boolean var20 = var0.equals((java.lang.Object)var11);
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var22 = var21.clone();
//     java.lang.Object var23 = var21.clone();
//     java.awt.Shape var25 = var21.getShape(10);
//     java.awt.Shape var27 = var21.getShape(100);
//     java.lang.Object var28 = var21.clone();
//     java.awt.Shape var30 = var21.getShape(0);
//     int var31 = var21.size();
//     var21.clear();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     boolean var35 = var21.equals((java.lang.Object)100.0f);
//     java.lang.Object var36 = var21.clone();
//     boolean var37 = var11.equals(var36);
//     java.awt.Shape var39 = null;
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var39, var42);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var42, 10.0d, 0.0d);
//     var11.setShape(100, var46);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var11
//     assertTrue("Contract failed: equals-hashcode on var21 and var11", var21.equals(var11) ? var21.hashCode() == var11.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var11.", var0.equals(var11) == var11.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var11.", var21.equals(var11) == var11.equals(var21));
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test44"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     var1.clear();
//     java.awt.Shape var5 = var1.getShape(1);
//     boolean var7 = var1.equals((java.lang.Object)(-1));
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     java.awt.Shape var22 = null;
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
//     var1.setShape(100, var16);
//     java.awt.Shape var27 = var1.getShape(0);
//     java.lang.Object var28 = var1.clone();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 100.0d, 10.0f, 100.0f);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal(var28, (java.lang.Object)var36);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var36, 0.0d, 100.0f, (-1.0f));
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test45"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    java.lang.Object var13 = null;
    boolean var14 = var0.equals(var13);
    java.awt.Shape var16 = var0.getShape(101);
    java.lang.Object var17 = null;
    boolean var18 = var0.equals(var17);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test46"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    int var7 = var0.size();
    java.lang.Object var8 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test47"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    java.lang.Object var29 = var0.clone();
    java.lang.Object var30 = var0.clone();
    java.awt.Shape var32 = var0.getShape(1);
    java.lang.Object var33 = var0.clone();
    java.awt.Shape var35 = var0.getShape(101);
    java.awt.Shape var37 = var0.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test48"); }


    java.lang.Object var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var3 = var1.getShape(0);
    java.lang.Object var4 = var1.clone();
    java.awt.Shape var6 = var1.getShape(10);
    java.lang.Object var7 = var1.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var10 = var1.equals((java.lang.Object)var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)100.0f);
    boolean var18 = var1.equals((java.lang.Object)var17);
    java.awt.Shape var20 = var1.getShape(0);
    java.lang.Object var21 = var1.clone();
    org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var24 = var22.getShape(0);
    java.lang.Object var25 = var22.clone();
    java.awt.Shape var27 = var22.getShape(10);
    java.lang.Object var28 = var22.clone();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var31 = var22.equals((java.lang.Object)var30);
    java.awt.Shape var33 = var22.getShape(11);
    int var34 = var22.size();
    boolean var35 = var1.equals((java.lang.Object)var22);
    java.lang.Object var36 = var22.clone();
    int var37 = var22.size();
    boolean var38 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test49"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.awt.Shape var8 = var3.getShape(0);
    boolean var10 = var3.equals((java.lang.Object)(byte)0);
    java.lang.Object var11 = var3.clone();
    java.lang.Object var12 = var3.clone();
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test50"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)100L);
    java.lang.Object var6 = var0.clone();
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test51"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.0d, (-1.0f), 100.0f);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test52"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    var0.clear();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var11 = var0.getShape(101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test53"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var9 = null;
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var7, var9);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), (-1.0f), 0.0f);
    var0.setShape(0, var15);
    java.awt.Shape var22 = var0.getShape(10);
    java.awt.Shape var24 = var0.getShape(0);
    java.awt.Shape var26 = var0.getShape(1);
    java.lang.Object var27 = var0.clone();
    java.lang.Object var28 = null;
    boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var28);
    java.lang.Object var30 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test54"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var8 = var6.getShape(0);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    boolean var11 = var6.equals(var10);
    java.lang.Object var12 = var6.clone();
    boolean var13 = var0.equals(var12);
    var0.clear();
    java.lang.Object var15 = var0.clone();
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    boolean var19 = var17.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
    var20.clear();
    var20.clear();
    boolean var23 = var17.equals((java.lang.Object)var20);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var26 = var24.getShape(0);
    org.jfree.chart.util.ShapeList var27 = new org.jfree.chart.util.ShapeList();
    boolean var29 = var27.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
    var30.clear();
    var30.clear();
    boolean var33 = var27.equals((java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    java.awt.Shape var47 = null;
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var45, var47);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var41, var45);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var53 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var41, (java.lang.Object)1.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 0.0d, 10.0f, 1.0f);
    boolean var59 = var27.equals((java.lang.Object)var58);
    boolean var60 = var24.equals((java.lang.Object)var27);
    java.lang.Object var61 = var24.clone();
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.clone(var63);
    java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.rotateShape(var63, 10.0d, 10.0f, 10.0f);
    java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var68, 1.0d, 0.0d);
    java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var68, 1.0d, 0.0d);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.clone(var68);
    boolean var76 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var24, (java.lang.Object)var75);
    boolean var77 = var17.equals((java.lang.Object)var24);
    boolean var78 = org.jfree.chart.util.ObjectUtilities.equal(var16, (java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test55"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var30 = var29.clone();
    java.lang.Object var31 = var29.clone();
    var29.clear();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var29.setShape(100, var36);
    var0.setShape(100, var36);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 0.0d, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test56"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    boolean var9 = var7.equals((java.lang.Object)(byte)10);
    java.lang.Object var10 = var7.clone();
    java.lang.Object var11 = var7.clone();
    java.lang.Object var12 = var7.clone();
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    java.lang.Object var15 = var13.clone();
    var13.clear();
    boolean var17 = var7.equals((java.lang.Object)var13);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var7);
    java.awt.Shape var20 = var7.getShape((-1));
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.lang.Object var26 = var21.clone();
    boolean var27 = var7.equals((java.lang.Object)var21);
    var7.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test57"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    var4.clear();
    var4.clear();
    java.lang.Object var7 = var4.clone();
    boolean var9 = var4.equals((java.lang.Object)(byte)0);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var15 = var4.equals((java.lang.Object)var13);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var3, var13);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 100.0d, 1.0f, (-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, 1.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test58"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 10.0d, 100.0f, 100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test59"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 0.0d);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    var23.clear();
    var23.clear();
    java.lang.Object var26 = var23.clone();
    boolean var28 = var23.equals((java.lang.Object)100L);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var32 = null;
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var36, var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 100.0d, 0.0f, (-1.0f));
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var31, var46);
    var23.setShape(1, var46);
    java.awt.Shape var50 = var23.getShape(0);
    boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0d, (java.lang.Object)var23);
    var23.clear();
    java.lang.Object var53 = var23.clone();
    java.lang.Object var54 = org.jfree.chart.util.ObjectUtilities.clone(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test60"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var8 = var6.getShape(0);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    boolean var11 = var6.equals(var10);
    java.lang.Object var12 = var6.clone();
    boolean var13 = var0.equals(var12);
    var0.clear();
    int var15 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test61"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var15 = null;
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var13, var15);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var1, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 0.0d, 0.0d);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, (-1.0d), 10.0f, 10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var23, 100.0d, 1.0f, 10.0f);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test62"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var15 = null;
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var13, var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, 1.0d, 100.0d);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, 1.0f, 10.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 1.0d, (-1.0d));
    var0.setShape(1, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test63"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    var0.setShape(1, var7);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 1.0d, 0.0d);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    org.jfree.chart.util.RectangleAnchor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, var14, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test64"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.lang.Object var11 = null;
    boolean var12 = var0.equals(var11);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    var13.clear();
    var13.clear();
    java.awt.Shape var17 = var13.getShape(1);
    java.lang.Object var18 = var13.clone();
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    boolean var21 = var19.equals((java.lang.Object)(byte)10);
    java.lang.Object var22 = var19.clone();
    java.lang.Object var23 = var19.clone();
    java.lang.Object var24 = var19.clone();
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var27 = var25.getShape(0);
    org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var29 = var28.clone();
    boolean var30 = var25.equals(var29);
    java.lang.Object var31 = var25.clone();
    boolean var32 = var19.equals(var31);
    boolean var33 = var13.equals((java.lang.Object)var19);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (-1.0f));
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = var13.equals((java.lang.Object)var36);
    boolean var39 = var0.equals((java.lang.Object)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test65"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, 0.0d, (-1.0d));
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var33, var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var22, var33);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 1.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test66"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 100.0f);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var3, 100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test67"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 10.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, (-1.0d), 1.0d);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 1.0d, (-1.0f), (-1.0f));
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var26, var34);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test68"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    boolean var5 = var0.equals((java.lang.Object)var4);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test69"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, (-1.0d), 0.0d);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var19, var28);
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test70"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 0.0d, 100.0f, (-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var11, var22);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var29 = null;
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var28, var29);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test71"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test72"); }


    java.lang.Object var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var3, var10);
    boolean var12 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test73"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var3 = var1.getShape(0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    var1.setShape(10, var6);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var0, var6);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, 1.0f, 1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    var19.clear();
    java.lang.Object var21 = var19.clone();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var19.setShape(0, var25);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 0.0d, 100.0f, (-1.0f));
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var18, var25);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 100.0d, 100.0d);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 10.0d, 10.0d);
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test74"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, (-1.0d), 100.0f, 0.0f);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    java.awt.Shape var10 = var6.getShape(10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 1.0d, 100.0f, (-1.0f));
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var14, var21);
    var6.setShape(10, var14);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    var24.clear();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    var24.setShape(100, var30);
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)var30);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var5, var30);
    java.io.ObjectOutputStream var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var5, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test75"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 0.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test76"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     var0.clear();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var0.setShape(100, var7);
//     java.awt.Shape var10 = var0.getShape(1);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var12 = var11.clone();
//     java.lang.Object var13 = var11.clone();
//     int var14 = var11.size();
//     java.awt.Shape var16 = var11.getShape(0);
//     org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
//     boolean var19 = var17.equals((java.lang.Object)(byte)10);
//     java.lang.Object var20 = var17.clone();
//     java.lang.Object var21 = var17.clone();
//     java.lang.Object var22 = var17.clone();
//     boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)(-1.0f));
//     boolean var25 = var11.equals((java.lang.Object)(-1.0f));
//     java.lang.Object var26 = var11.clone();
//     org.jfree.chart.util.ShapeList var27 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var28 = var27.clone();
//     java.lang.Object var29 = var27.clone();
//     var27.clear();
//     int var31 = var27.size();
//     java.lang.Object var32 = var27.clone();
//     boolean var33 = var11.equals((java.lang.Object)var27);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
//     java.lang.Object var37 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
//     boolean var38 = var27.equals((java.lang.Object)var35);
//     java.lang.Object var39 = var27.clone();
//     java.lang.Object var40 = var27.clone();
//     boolean var41 = var0.equals(var40);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var0.", var17.equals(var0) == var0.equals(var17));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var0.", var27.equals(var0) == var0.equals(var27));
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test77"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 1.0d, 0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test78"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test79"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var0.setShape(100, var7);
    java.awt.Shape var10 = var0.getShape(1);
    var0.clear();
    int var12 = var0.size();
    java.lang.Object var13 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test80"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = var8.clone();
    java.lang.Object var10 = var8.clone();
    java.awt.Shape var12 = var8.getShape(10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 1.0d, 100.0f, (-1.0f));
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var23);
    var8.setShape(10, var16);
    org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
    var26.clear();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    var26.setShape(100, var32);
    boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)var32);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var6, var32);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test81"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var0.setShape(0, var19);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 10.0d, 10.0f, 10.0f);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var19, var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 100.0d, (-1.0d));
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, 100.0f, 100.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 1.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test82"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 1.0d, 100.0f, (-1.0f));
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var12, var19);
//     boolean var21 = var8.equals((java.lang.Object)var19);
//     var8.clear();
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var25);
//     java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
//     var8.setShape(101, var30);
//     boolean var33 = var0.equals((java.lang.Object)var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var8.", var3.equals(var8) == var8.equals(var3));
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test83"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    boolean var12 = var10.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    var13.clear();
    var13.clear();
    boolean var16 = var10.equals((java.lang.Object)var13);
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    boolean var18 = var0.equals((java.lang.Object)var10);
    java.lang.Object var19 = var10.clone();
    var10.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test84"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)100L);
    java.lang.Object var6 = var0.clone();
    java.lang.Object var7 = var0.clone();
    java.lang.Object var8 = var0.clone();
    java.awt.Shape var10 = var0.getShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test85"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    boolean var8 = var6.equals((java.lang.Object)(byte)10);
    java.lang.Object var9 = var6.clone();
    java.lang.Object var10 = var6.clone();
    java.lang.Object var11 = var6.clone();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)(-1.0f));
    boolean var14 = var0.equals((java.lang.Object)(-1.0f));
    java.lang.Object var15 = var0.clone();
    java.lang.Object var16 = null;
    boolean var17 = var0.equals(var16);
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = var0.clone();
    int var20 = var0.size();
    java.awt.Shape var22 = var0.getShape(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test86"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 1.0d);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, (-1.0d));
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test87"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    int var7 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test88"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    java.lang.Object var6 = null;
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test89"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var14 = null;
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)1.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var8);
//     org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
//     boolean var24 = var22.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
//     var25.clear();
//     var25.clear();
//     boolean var28 = var22.equals((java.lang.Object)var25);
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)var28);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 100.0d, 10.0f, 10.0f);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var21, var37);
//     boolean var39 = var0.equals((java.lang.Object)var38);
//     int var40 = var0.size();
//     java.lang.Object var41 = var0.clone();
//     java.awt.Shape var43 = null;
//     var0.setShape(0, var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test90"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 10.0d, 0.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test91"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = null;
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, (-1.0d));
    var0.setShape(11, var8);
    java.lang.Object var23 = var0.clone();
    java.awt.Shape var25 = var0.getShape(0);
    int var26 = var0.size();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 12);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test92"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    var6.clear();
    var6.clear();
    java.lang.Object var9 = var6.clone();
    boolean var11 = var6.equals((java.lang.Object)(byte)0);
    java.awt.Shape var13 = var6.getShape((-1));
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var6);
    int var15 = var6.size();
    var6.clear();
    var6.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test93"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    boolean var4 = var2.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    boolean var8 = var2.equals((java.lang.Object)var5);
    int var9 = var2.size();
    java.lang.Object var10 = var2.clone();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var2);
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    var12.clear();
    var12.clear();
    java.awt.Shape var16 = var12.getShape(1);
    boolean var18 = var12.equals((java.lang.Object)(-1));
    java.awt.Shape var20 = var12.getShape(0);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    boolean var25 = var12.equals(var24);
    java.awt.Shape var26 = null;
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var26, var30);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var30, 0.0d, (-1.0d));
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var30, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var48);
    boolean var50 = org.jfree.chart.util.ObjectUtilities.equal(var24, (java.lang.Object)var49);
    boolean var51 = var2.equals((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test94"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    var7.clear();
    java.lang.Object var10 = var7.clone();
    boolean var12 = var7.equals((java.lang.Object)(byte)0);
    java.awt.Shape var14 = var7.getShape((-1));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    boolean var18 = var7.equals((java.lang.Object)var16);
    boolean var19 = var0.equals((java.lang.Object)var7);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var24 = null;
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    boolean var29 = var7.equals((java.lang.Object)var28);
    org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
    var30.clear();
    var30.clear();
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = var30.equals((java.lang.Object)var37);
    org.jfree.chart.util.RectangleAnchor var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, var39, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test95"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    var7.clear();
    java.lang.Object var10 = var7.clone();
    boolean var12 = var7.equals((java.lang.Object)(byte)0);
    java.awt.Shape var14 = var7.getShape((-1));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    boolean var18 = var7.equals((java.lang.Object)var16);
    boolean var19 = var0.equals((java.lang.Object)var7);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var24 = null;
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    boolean var29 = var7.equals((java.lang.Object)var28);
    org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
    var30.clear();
    var30.clear();
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = var30.equals((java.lang.Object)var37);
    java.awt.Shape var40 = var30.getShape(11);
    var30.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test96"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    boolean var12 = var10.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    var13.clear();
    var13.clear();
    boolean var16 = var10.equals((java.lang.Object)var13);
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    boolean var18 = var0.equals((java.lang.Object)var10);
    var0.clear();
    java.lang.Object var20 = var0.clone();
    java.lang.Object var21 = null;
    boolean var22 = var0.equals(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test97"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    java.lang.Object var10 = var0.clone();
    java.lang.Object var11 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test98"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 10.0d, 0.0d);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 1.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 1.0d, (-1.0f), 10.0f);
    org.jfree.chart.util.RectangleAnchor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, var18, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test99"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 10.0d);
    org.jfree.chart.util.RectangleAnchor var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, var22, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test100"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     int var6 = var0.size();
//     java.lang.Object var7 = var0.clone();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     var0.setShape(100, var11);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 1.0f);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 100.0d, (-1.0f), 10.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var17, var24);
//     org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
//     var26.clear();
//     java.awt.Shape var29 = var26.getShape(100);
//     int var30 = var26.size();
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var26.setShape(0, var33);
//     boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var24, var33);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 1.0d, 1.0f, 0.0f);
//     var0.setShape(100, var39);
//     var0.clear();
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var26.", var0.equals(var26) == var26.equals(var0));
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test101"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test102"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    java.lang.Object var8 = var0.clone();
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.awt.Shape var14 = var10.getShape(1);
    boolean var16 = var10.equals((java.lang.Object)' ');
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.lang.Object var18 = var10.clone();
    int var19 = var10.size();
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    var21.clear();
    var21.clear();
    java.lang.Object var24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.lang.Object var25 = var21.clone();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    var21.setShape(0, var30);
    var10.setShape(10, var30);
    var0.setShape(10, var30);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test103"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var18 = null;
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var16, var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)1.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    var0.setShape(10, var12);
    java.lang.Object var27 = null;
    boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var27);
    java.awt.Shape var30 = var0.getShape(102);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var34 = null;
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var38, var42);
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 100.0d, 0.0f, (-1.0f));
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var33, var48);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var48, 100.0d, 100.0d);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var52, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 1.0d, 1.0d);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    var0.setShape(102, var62);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test104"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test105"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 0.0f, (-1.0f));
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test106"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 100.0d, 10.0f, 10.0f);
    var0.setShape(0, var31);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var31, 100.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test107"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    java.awt.Shape var10 = var0.getShape(100);
    java.lang.Object var11 = var0.clone();
    java.lang.Object var12 = null;
    boolean var13 = var0.equals(var12);
    java.awt.Shape var15 = var0.getShape(0);
    java.lang.Object var16 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test108"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    java.awt.Shape var7 = var3.getShape(1);
    boolean var9 = var3.equals((java.lang.Object)' ');
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    var3.setShape(100, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 0.0d, 10.0f, 10.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var2, var17);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test109"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var7);
    int var9 = var0.size();
    java.awt.Shape var11 = var0.getShape(1);
    var0.clear();
    java.awt.Shape var14 = var0.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test110"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    int var5 = var0.size();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    boolean var11 = var9.equals((java.lang.Object)(byte)10);
    java.lang.Object var12 = var9.clone();
    java.lang.Object var13 = var9.clone();
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, var13);
    var6.clear();
    boolean var16 = var0.equals((java.lang.Object)var6);
    java.lang.Object var17 = var6.clone();
    java.lang.Object var18 = var6.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test111"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100L);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test112"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 0.0d);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 1.0d, (-1.0d));
    org.jfree.chart.util.RectangleAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, var13, (-1.0d), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test113"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    boolean var7 = var5.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    var8.clear();
    var8.clear();
    boolean var11 = var5.equals((java.lang.Object)var8);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)var5);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    boolean var16 = var14.equals((java.lang.Object)(byte)10);
    boolean var17 = var5.equals((java.lang.Object)var16);
    java.lang.Object var18 = null;
    boolean var19 = var5.equals(var18);
    java.lang.Object var20 = var5.clone();
    java.lang.Object var21 = var5.clone();
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    var5.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test114"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.lang.Object var5 = var0.clone();
    int var6 = var0.size();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 1.0d);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, 1.0f, 100.0f);
    boolean var21 = var0.equals((java.lang.Object)0.0d);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    var23.clear();
    var23.clear();
    java.awt.Shape var27 = var23.getShape(1);
    boolean var29 = var23.equals((java.lang.Object)(-1));
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var42);
    java.awt.Shape var44 = null;
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var38, var42);
    var23.setShape(100, var38);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 100.0d, 0.0d);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 1.0d, 0.0f, 1.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var55, 100.0d, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test115"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 1.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, var18, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test116"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.lang.Class var5 = null;
    java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    java.lang.Object var8 = null;
    boolean var9 = var0.equals(var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    java.awt.Shape var13 = null;
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, 100.0f);
    boolean var35 = var10.equals((java.lang.Object)var17);
    java.lang.Object var36 = var10.clone();
    boolean var37 = var0.equals((java.lang.Object)var10);
    org.jfree.chart.util.ShapeList var38 = new org.jfree.chart.util.ShapeList();
    var38.clear();
    java.awt.Shape var41 = var38.getShape(100);
    java.lang.Object var42 = null;
    boolean var43 = var38.equals(var42);
    java.awt.Shape var45 = var38.getShape(100);
    java.awt.Shape var47 = var38.getShape((-1));
    int var48 = var38.size();
    boolean var49 = var10.equals((java.lang.Object)var48);
    java.awt.Shape var51 = var10.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test117"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, (-1.0f), 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 1.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test118"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = null;
    boolean var6 = var0.equals(var5);
    int var7 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test119"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
//     java.awt.Shape var19 = null;
//     var0.setShape(0, var19);
//     java.awt.Shape var22 = var0.getShape(0);
//     java.lang.Object var23 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var3
//     assertTrue("Contract failed: equals-hashcode on var23 and var3", var23.equals(var3) ? var23.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test120"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, (-1.0f));
    java.awt.Shape var7 = null;
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var2, var7);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test121"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var0, var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 0.0d);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
    boolean var30 = var28.equals((java.lang.Object)(short)1);
    int var31 = var28.size();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var28.setShape(0, var34);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var25, var34);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var17, var34);
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var42 = null;
    boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var41, var42);
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)var43);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var34, var47);
    java.lang.Object var49 = null;
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.rotateShape(var51, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var51);
    java.lang.Object var57 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var56);
    boolean var58 = org.jfree.chart.util.ObjectUtilities.equal(var49, (java.lang.Object)var56);
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.clone(var56);
    java.lang.Object var60 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var59);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var59, 10.0d, (-1.0d));
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.rotateShape(var59, 0.0d, (-1.0f), 1.0f);
    java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.rotateShape(var59, 0.0d, (-1.0f), 1.0f);
    boolean var72 = org.jfree.chart.util.ShapeUtilities.equal(var34, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test122"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = var0.clone();
    var0.clear();
    var0.clear();
    int var22 = var0.size();
    java.lang.Object var23 = var0.clone();
    java.awt.Shape var25 = var0.getShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test123"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     java.lang.Object var3 = var0.clone();
//     var0.clear();
//     java.awt.Shape var6 = null;
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var10, var14);
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, (-1.0d));
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 0.0f, 100.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
//     var0.setShape(10, var29);
//     java.lang.Object var32 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var32
//     assertTrue("Contract failed: equals-hashcode on var3 and var32", var3.equals(var32) ? var3.hashCode() == var32.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var32.", var3.equals(var32) == var32.equals(var3));
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test124"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 0.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 0.0d, (-1.0f), 0.0f);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test125"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 10.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, (-1.0d), 1.0d);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 1.0d, (-1.0f), (-1.0f));
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var26, var34);
    java.awt.Shape var43 = null;
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var34, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test126"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, (-1.0f));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), 1.0f, 0.0f);
    boolean var11 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.util.RectangleAnchor var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, var12, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test127"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    var7.clear();
    java.lang.Object var10 = var7.clone();
    boolean var12 = var7.equals((java.lang.Object)(byte)0);
    java.awt.Shape var14 = var7.getShape((-1));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    boolean var18 = var7.equals((java.lang.Object)var16);
    boolean var19 = var0.equals((java.lang.Object)var7);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var24 = null;
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    boolean var29 = var7.equals((java.lang.Object)var28);
    org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
    var30.clear();
    var30.clear();
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var30);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = var30.equals((java.lang.Object)var37);
    java.awt.Shape var40 = var30.getShape(11);
    java.lang.Object var41 = var30.clone();
    java.lang.Object var42 = var30.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test128"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, (-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test129"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    var1.clear();
    var1.clear();
    java.awt.Shape var5 = var1.getShape(1);
    boolean var7 = var1.equals((java.lang.Object)' ');
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.lang.Object var9 = var1.clone();
    java.awt.Shape var11 = var1.getShape((-1));
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    boolean var14 = var12.equals((java.lang.Object)(byte)10);
    java.lang.Object var15 = var12.clone();
    java.lang.Object var16 = var12.clone();
    var12.clear();
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var19 = var18.clone();
    java.lang.Object var20 = var18.clone();
    var18.clear();
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    boolean var27 = var18.equals((java.lang.Object)var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = var18.equals((java.lang.Object)var31);
    boolean var33 = var12.equals((java.lang.Object)var31);
    boolean var34 = var1.equals((java.lang.Object)var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    boolean var37 = var0.equals((java.lang.Object)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test130"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var7 = var6.clone();
//     java.lang.Object var8 = var6.clone();
//     var6.clear();
//     boolean var10 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     boolean var13 = var11.equals((java.lang.Object)(byte)10);
//     java.lang.Object var14 = var11.clone();
//     java.lang.Object var15 = var11.clone();
//     java.lang.Object var16 = var11.clone();
//     boolean var17 = var6.equals((java.lang.Object)var11);
//     java.awt.Shape var18 = null;
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
//     boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
//     boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var18, var31);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
//     boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var36, var40);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var44);
//     java.awt.Shape var46 = null;
//     boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var44, var46);
//     boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var40, var44);
//     boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var18, var44);
//     boolean var50 = var6.equals((java.lang.Object)var49);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     java.lang.Object var54 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var53);
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var53, 1.0d, 100.0f, 0.0f);
//     var6.setShape(102, var58);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var6
//     assertTrue("Contract failed: equals-hashcode on var11 and var6", var11.equals(var6) ? var11.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var6.", var11.equals(var6) == var6.equals(var11));
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test131"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var3);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 10.0d, 100.0f, 100.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 10.0d, 1.0f, 10.0f);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test132"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     int var3 = var0.size();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     var0.setShape(0, var6);
//     java.lang.Object var8 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var1 and var8.", var1.equals(var8) == var8.equals(var1));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var8.", var2.equals(var8) == var8.equals(var2));
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test133"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = null;
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var12, var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 0.0d);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var20, var29);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"hi!", (java.lang.Object)var29);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 0.0d, 0.0f, (-1.0f));
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 0.0d, 100.0f, 0.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 0.0d, 0.0f, 10.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test134"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     var1.clear();
//     java.awt.Shape var5 = var1.getShape(1);
//     boolean var7 = var1.equals((java.lang.Object)(-1));
//     java.awt.Shape var9 = var1.getShape(0);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, (-1.0f), 0.0f);
//     var1.setShape(0, var13);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var13, 1.0d, 0.0f, 0.0f);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test135"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var11, var15);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var21 = null;
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var19, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    var0.setShape(100, var15);
    java.awt.Shape var26 = var0.getShape(0);
    java.lang.Object var27 = var0.clone();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 100.0d, 10.0f, 100.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal(var27, (java.lang.Object)var35);
    org.jfree.chart.util.RectangleAnchor var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, var38, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test136"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     java.awt.Shape var5 = var0.getShape((-1));
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, (-1.0d), 0.0d);
//     var0.setShape(10, var12);
//     java.awt.Shape var18 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
//     var20.clear();
//     var20.clear();
//     java.awt.Shape var24 = var20.getShape(1);
//     boolean var26 = var20.equals((java.lang.Object)' ');
//     java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
//     java.lang.Object var28 = var20.clone();
//     int var29 = var20.size();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var32, 0.0d, (-1.0d));
//     var20.setShape(10, var35);
//     java.awt.Shape var38 = var20.getShape((-1));
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var42, 1.0d, 10.0f, 100.0f);
//     var20.setShape(100, var42);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var42, 100.0d, 0.0d);
//     var0.setShape(1, var50);
//     boolean var53 = var0.equals((java.lang.Object)(byte)(-1));
//     java.lang.Object var54 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var27 and var54
//     assertTrue("Contract failed: equals-hashcode on var27 and var54", var27.equals(var54) ? var27.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var54
//     assertTrue("Contract failed: equals-hashcode on var28 and var54", var28.equals(var54) ? var28.hashCode() == var54.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var54.", var27.equals(var54) == var54.equals(var27));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var54.", var28.equals(var54) == var54.equals(var28));
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test137"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var3 = var1.getShape(0);
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var5 = var4.clone();
//     boolean var6 = var1.equals(var5);
//     java.lang.Object var7 = var1.clone();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     java.awt.Shape var11 = var8.getShape(100);
//     int var12 = var8.size();
//     boolean var13 = var1.equals((java.lang.Object)var12);
//     java.awt.Shape var14 = null;
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 0.0d, (-1.0d));
//     boolean var32 = var1.equals((java.lang.Object)var31);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var31, var36);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var31);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var31, (-1.0d), 100.0f, 100.0f);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test138"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    java.awt.Shape var10 = var7.getShape(100);
    int var11 = var7.size();
    boolean var12 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var13 = null;
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
    boolean var31 = var0.equals((java.lang.Object)var30);
    java.lang.Object var32 = var0.clone();
    java.lang.Object var33 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test139"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    org.jfree.chart.util.RectangleAnchor var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, var8, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test140"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(100);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    boolean var6 = var0.equals((java.lang.Object)(-1.0f));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    var0.setShape(1, var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Shape var27 = null;
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var25, var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Shape var31 = null;
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var31, var44);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var48);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    boolean var54 = org.jfree.chart.util.ShapeUtilities.equal(var49, var53);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.clone(var57);
    java.awt.Shape var59 = null;
    boolean var60 = org.jfree.chart.util.ShapeUtilities.equal(var57, var59);
    boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var53, var57);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var31, var57);
    boolean var63 = org.jfree.chart.util.ShapeUtilities.equal(var25, var57);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var66, 1.0d, 0.0d);
    boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var25, var66);
    var0.setShape(102, var66);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.clone(var75);
    java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.clone(var75);
    java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.clone(var75);
    java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var75, 0.0d, 1.0d);
    var0.setShape(100, var81);
    java.awt.Shape var85 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var81, 0.0d, (-1.0d));
    java.awt.Shape var87 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var91 = org.jfree.chart.util.ShapeUtilities.rotateShape(var87, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var92 = org.jfree.chart.util.ShapeUtilities.clone(var87);
    java.awt.Shape var96 = org.jfree.chart.util.ShapeUtilities.rotateShape(var92, 0.0d, 1.0f, 0.0f);
    boolean var97 = org.jfree.chart.util.ShapeUtilities.equal(var85, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test141"); }


    java.lang.Object var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    var1.clear();
    java.awt.Shape var4 = var1.getShape(100);
    java.lang.Object var5 = null;
    boolean var6 = var1.equals(var5);
    java.lang.Object var7 = var1.clone();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    var8.clear();
    var8.clear();
    java.lang.Object var11 = var8.clone();
    boolean var13 = var8.equals((java.lang.Object)(byte)0);
    java.awt.Shape var15 = var8.getShape((-1));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    boolean var19 = var8.equals((java.lang.Object)var17);
    boolean var20 = var1.equals((java.lang.Object)var8);
    java.lang.Object var21 = var1.clone();
    org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
    var22.clear();
    java.awt.Shape var25 = var22.getShape(100);
    var22.clear();
    boolean var27 = org.jfree.chart.util.ObjectUtilities.equal(var21, (java.lang.Object)var22);
    boolean var28 = org.jfree.chart.util.ObjectUtilities.equal(var0, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test142"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, (-1.0d));
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    java.awt.Shape var9 = var5.getShape(1);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    boolean var15 = var10.equals(var14);
    java.lang.Object var16 = var10.clone();
    boolean var17 = var5.equals((java.lang.Object)var10);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0d, (java.lang.Object)var5);
    java.awt.Shape var20 = var5.getShape(11);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    var21.clear();
    var21.clear();
    java.awt.Shape var25 = var21.getShape(1);
    boolean var27 = var21.equals((java.lang.Object)' ');
    int var28 = var21.size();
    int var29 = var21.size();
    int var30 = var21.size();
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)11, (java.lang.Object)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test143"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     int var4 = var1.size();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     var1.setShape(0, var7);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 0.0d, 100.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 10.0d, 100.0f, 10.0f);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test144"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    var4.clear();
    java.awt.Shape var7 = var4.getShape(100);
    java.lang.Object var8 = null;
    boolean var9 = var4.equals(var8);
    java.awt.Shape var11 = var4.getShape(100);
    var4.clear();
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var15 = var13.getShape(0);
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var17 = var16.clone();
    boolean var18 = var13.equals(var17);
    java.lang.Object var19 = var13.clone();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    boolean var23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var21);
    boolean var24 = var4.equals((java.lang.Object)var13);
    java.lang.Object var25 = var4.clone();
    boolean var26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test145"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)1.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test146"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = var9.getShape(0);
    java.lang.Object var12 = var9.clone();
    boolean var13 = var0.equals(var12);
    var0.clear();
    java.awt.Shape var16 = var0.getShape(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test147"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, (-1.0d), 0.0d);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var19, var28);
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 10.0d, 100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 100.0d, 0.0d);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 10.0d, 1.0f, 10.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.rotateShape(var44, 100.0d, 10.0f, 10.0f);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test148"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    boolean var4 = var2.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    boolean var8 = var2.equals((java.lang.Object)var5);
    int var9 = var2.size();
    java.lang.Object var10 = var2.clone();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var2);
    java.lang.Object var12 = var2.clone();
    java.lang.Object var13 = var2.clone();
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    boolean var16 = var14.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    var17.clear();
    var17.clear();
    boolean var20 = var14.equals((java.lang.Object)var17);
    int var21 = var14.size();
    org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var24 = var22.getShape(0);
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var26 = var25.clone();
    boolean var27 = var22.equals(var26);
    java.lang.Object var28 = var22.clone();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var32 = var22.equals((java.lang.Object)var31);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var37 = null;
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var44);
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var41, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, (-1.0d));
    boolean var55 = org.jfree.chart.util.ShapeUtilities.equal(var31, var41);
    boolean var56 = var14.equals((java.lang.Object)var41);
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.rotateShape(var62, 1.0d, 100.0f, (-1.0f));
    boolean var67 = org.jfree.chart.util.ShapeUtilities.equal(var59, var66);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var59, var69);
    java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.rotateShape(var69, (-1.0d), 1.0f, 10.0f);
    boolean var75 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var41, (java.lang.Object)var69);
    java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var69, 1.0d, (-1.0d));
    boolean var79 = var2.equals((java.lang.Object)(-1.0d));
    java.lang.Object var80 = var2.clone();
    int var81 = var2.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test149"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, (-1.0d), 100.0d);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 0.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, (-1.0f), 100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)(-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 0.0d, 1.0f, (-1.0f));
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 1.0d, 100.0d);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var1, var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test150"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    int var7 = var0.size();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = null;
    boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, var9);
    java.lang.Object var11 = var8.clone();
    boolean var12 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var14 = var8.getShape(2);
    java.lang.Object var15 = var8.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test151"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 100.0d, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test152"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    int var7 = var0.size();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = null;
    boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, var9);
    java.lang.Object var11 = var8.clone();
    boolean var12 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var14 = var8.getShape(2);
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var18 = var16.getShape(0);
    java.lang.Object var19 = var16.clone();
    var16.clear();
    int var21 = var16.size();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, 0.0d, (-1.0d));
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var33, var38);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var42, var46);
    org.jfree.chart.util.ShapeList var48 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var49 = var48.clone();
    java.lang.Object var50 = var48.clone();
    java.awt.Shape var52 = var48.getShape(10);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.rotateShape(var59, 1.0d, 100.0f, (-1.0f));
    boolean var64 = org.jfree.chart.util.ShapeUtilities.equal(var56, var63);
    var48.setShape(10, var56);
    org.jfree.chart.util.ShapeList var66 = new org.jfree.chart.util.ShapeList();
    var66.clear();
    java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.clone(var71);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.clone(var75);
    boolean var77 = org.jfree.chart.util.ShapeUtilities.equal(var72, var76);
    var66.setShape(100, var72);
    boolean var79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var56, (java.lang.Object)var72);
    boolean var80 = org.jfree.chart.util.ShapeUtilities.equal(var46, var72);
    java.awt.Shape var83 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    boolean var84 = org.jfree.chart.util.ShapeUtilities.equal(var46, var83);
    boolean var85 = org.jfree.chart.util.ShapeUtilities.equal(var38, var83);
    var16.setShape(100, var83);
    java.awt.Shape var89 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var83, 0.0d, (-1.0d));
    java.awt.Shape var90 = org.jfree.chart.util.ShapeUtilities.clone(var83);
    java.awt.Shape var91 = org.jfree.chart.util.ShapeUtilities.clone(var90);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setShape((-1), var90);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test153"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    boolean var9 = var7.equals((java.lang.Object)(byte)10);
    java.lang.Object var10 = var7.clone();
    java.lang.Object var11 = var7.clone();
    java.lang.Object var12 = var7.clone();
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    java.lang.Object var15 = var13.clone();
    var13.clear();
    boolean var17 = var7.equals((java.lang.Object)var13);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var7);
    java.awt.Shape var20 = var7.getShape((-1));
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.lang.Object var26 = var21.clone();
    boolean var27 = var7.equals((java.lang.Object)var21);
    java.awt.Shape var29 = var21.getShape(10);
    java.awt.Shape var31 = var21.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test154"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    var0.setShape(1, var6);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 10.0d, 1.0f, 10.0f);
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 1.0d, 10.0f, 100.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var6, var16);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test155"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, (-1.0d), (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test156"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 0.0d, 100.0f, (-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var11, var22);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 10.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, var31, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test157"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    var6.clear();
    java.awt.Shape var9 = var6.getShape(100);
    int var10 = var6.size();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var15, var19);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var25 = null;
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var23, var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 10.0d, 10.0f, 100.0f);
    var6.setShape(1, var23);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var4, var23);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    org.jfree.chart.util.ShapeList var35 = new org.jfree.chart.util.ShapeList();
    var35.clear();
    var35.clear();
    java.awt.Shape var39 = var35.getShape(1);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var42);
    java.awt.Shape var44 = null;
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
    boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)var45);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, (-1.0d), (-1.0f), 0.0f);
    var35.setShape(0, var50);
    boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var4, var50);
    org.jfree.chart.util.RectangleAnchor var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, var57, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test158"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    java.awt.Shape var7 = var3.getShape(1);
    boolean var9 = var3.equals((java.lang.Object)' ');
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    var3.setShape(100, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 0.0d, 10.0f, 10.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var2, var17);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 0.0d, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test159"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var5 = var0.getShape(10);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
//     boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
//     boolean var17 = var0.equals((java.lang.Object)var16);
//     org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var20 = var19.clone();
//     java.lang.Object var21 = var19.clone();
//     int var22 = var19.size();
//     java.awt.Shape var24 = var19.getShape(0);
//     java.awt.Shape var26 = var19.getShape(10);
//     java.awt.Shape var28 = var19.getShape(100);
//     java.lang.Object var29 = var19.clone();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)var35);
//     var19.setShape(100, var35);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, 100.0d, 1.0d);
//     var0.setShape(100, var40);
//     java.lang.Object var42 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var42
//     assertTrue("Contract failed: equals-hashcode on var3 and var42", var3.equals(var42) ? var3.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var42
//     assertTrue("Contract failed: equals-hashcode on var20 and var42", var20.equals(var42) ? var20.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var42
//     assertTrue("Contract failed: equals-hashcode on var21 and var42", var21.equals(var42) ? var21.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var42
//     assertTrue("Contract failed: equals-hashcode on var29 and var42", var29.equals(var42) ? var29.hashCode() == var42.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var42.", var3.equals(var42) == var42.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var42.", var6.equals(var42) == var42.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var42.", var20.equals(var42) == var42.equals(var20));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var42.", var21.equals(var42) == var42.equals(var21));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var42.", var29.equals(var42) == var42.equals(var29));
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test160"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 10.0f, (-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var9, var18);
    java.io.ObjectOutputStream var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var9, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test161"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var11 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    var12.clear();
    int var14 = var12.size();
    boolean var15 = var0.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test162"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var9 = var0.getShape(0);
    int var10 = var0.size();
    var0.clear();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    boolean var14 = var0.equals((java.lang.Object)100.0f);
    java.lang.Object var15 = var0.clone();
    java.lang.Object var16 = var0.clone();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test163"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = var0.getShape(1);
    java.lang.Object var7 = var0.clone();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    boolean var10 = var8.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    var11.clear();
    var11.clear();
    boolean var14 = var8.equals((java.lang.Object)var11);
    boolean var15 = var0.equals((java.lang.Object)var8);
    int var16 = var8.size();
    var8.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test164"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, (-1.0d), 0.0d);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    var13.clear();
    java.awt.Shape var16 = var13.getShape(100);
    java.awt.Shape var18 = var13.getShape((-1));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, (-1.0d), 0.0d);
    var13.setShape(10, var25);
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var25);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, var30);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 1.0d, 10.0f, 100.0f);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var12, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test165"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 10.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     java.awt.Shape var8 = null;
//     boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, (-1.0d), 10.0d);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var3, var12);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, (-1.0d), 100.0f, 0.0f);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test166"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    int var3 = var0.size();
    int var4 = var0.size();
    int var5 = var0.size();
    java.lang.Object var6 = null;
    boolean var7 = var0.equals(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test167"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
//     boolean var13 = var0.equals((java.lang.Object)var11);
//     java.awt.Shape var15 = var0.getShape((-1));
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 10.0f, 10.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
//     var0.setShape(10, var25);
//     var0.clear();
//     int var28 = var0.size();
//     org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
//     boolean var31 = var29.equals((java.lang.Object)(byte)10);
//     java.lang.Object var32 = var29.clone();
//     java.lang.Object var33 = var29.clone();
//     var29.clear();
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 1.0d, 100.0f, (-1.0f));
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var38, var45);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, (-1.0d), 0.0f, (-1.0f));
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 0.0d, (-1.0f), 10.0f);
//     java.lang.Object var59 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var58);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
//     java.lang.Object var62 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var61);
//     java.lang.Object var63 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var61);
//     java.lang.Object var64 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var61);
//     boolean var65 = org.jfree.chart.util.ShapeUtilities.equal(var58, var61);
//     var29.setShape(2, var58);
//     boolean var67 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var29);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var29.", var0.equals(var29) == var29.equals(var0));
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test168"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.lang.Object var5 = null;
//     boolean var6 = var0.equals(var5);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 10.0d, 100.0f, 100.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     var0.setShape(1, var17);
//     org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
//     var19.clear();
//     var19.clear();
//     java.lang.Object var22 = var19.clone();
//     boolean var23 = var0.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test169"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    var0.clear();
    java.lang.Object var9 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test170"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    var0.setShape(1, var6);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    var8.setShape(10, var13);
    java.lang.Class var20 = null;
    java.lang.ClassLoader var21 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var20);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var21);
    boolean var23 = var8.equals((java.lang.Object)var21);
    boolean var24 = var0.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test171"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test172"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 1.0d, (-1.0d));
    java.io.ObjectOutputStream var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test173"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.awt.Shape var8 = var3.getShape(0);
    boolean var10 = var3.equals((java.lang.Object)(byte)0);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var14 = var12.getShape(0);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var16 = var15.clone();
    boolean var17 = var12.equals(var16);
    java.awt.Shape var19 = var12.getShape((-1));
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = var12.equals((java.lang.Object)var22);
    java.awt.Shape var26 = var12.getShape(0);
    var12.clear();
    var12.clear();
    boolean var29 = org.jfree.chart.util.ObjectUtilities.equal(var11, (java.lang.Object)var12);
    int var30 = var12.size();
    java.awt.Shape var32 = var12.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test174"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.io.ObjectOutputStream var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test175"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    boolean var8 = var6.equals((java.lang.Object)(byte)10);
    java.lang.Object var9 = var6.clone();
    java.lang.Object var10 = var6.clone();
    java.lang.Object var11 = var6.clone();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)(-1.0f));
    boolean var14 = var0.equals((java.lang.Object)(-1.0f));
    java.lang.Object var15 = var0.clone();
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    boolean var18 = var16.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    var19.clear();
    var19.clear();
    boolean var22 = var16.equals((java.lang.Object)var19);
    java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var16);
    java.lang.Object var24 = var16.clone();
    java.awt.Shape var26 = var16.getShape(100);
    java.lang.Object var27 = var16.clone();
    java.lang.Object var28 = null;
    boolean var29 = var16.equals(var28);
    java.lang.Object var30 = var16.clone();
    java.lang.Object var31 = var16.clone();
    var16.clear();
    org.jfree.chart.util.ShapeList var33 = new org.jfree.chart.util.ShapeList();
    boolean var35 = var33.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var36 = new org.jfree.chart.util.ShapeList();
    var36.clear();
    var36.clear();
    boolean var39 = var33.equals((java.lang.Object)var36);
    int var40 = var33.size();
    java.awt.Shape var42 = var33.getShape(100);
    boolean var43 = var16.equals((java.lang.Object)var33);
    boolean var44 = var0.equals((java.lang.Object)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test176"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.lang.Object var2 = var0.clone();
//     java.lang.Object var3 = var0.clone();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     java.awt.Shape var18 = null;
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var16, var18);
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)1.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     var0.setShape(10, var12);
//     java.lang.Object var27 = null;
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, var27);
//     java.awt.Shape var30 = var0.getShape(100);
//     java.lang.Object var31 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var31
//     assertTrue("Contract failed: equals-hashcode on var2 and var31", var2.equals(var31) ? var2.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var31
//     assertTrue("Contract failed: equals-hashcode on var3 and var31", var3.equals(var31) ? var3.hashCode() == var31.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var31.", var2.equals(var31) == var31.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var31.", var3.equals(var31) == var31.equals(var3));
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test177"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var12 = var11.clone();
    boolean var13 = var8.equals(var12);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    var14.clear();
    var14.clear();
    java.lang.Object var17 = var14.clone();
    boolean var19 = var14.equals((java.lang.Object)(byte)0);
    java.awt.Shape var21 = var14.getShape((-1));
    boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var14);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var25 = var23.getShape(0);
    java.lang.Object var26 = var23.clone();
    java.awt.Shape var28 = var23.getShape(10);
    java.lang.Object var29 = var23.clone();
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var32 = var23.equals((java.lang.Object)var31);
    boolean var33 = var14.equals((java.lang.Object)var32);
    boolean var34 = var0.equals((java.lang.Object)var33);
    int var35 = var0.size();
    org.jfree.chart.util.ShapeList var36 = new org.jfree.chart.util.ShapeList();
    var36.clear();
    var36.clear();
    java.awt.Shape var40 = var36.getShape(1);
    boolean var42 = var36.equals((java.lang.Object)' ');
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var46 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var45);
    java.lang.Object var47 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var45);
    java.lang.Object var48 = org.jfree.chart.util.ObjectUtilities.clone(var47);
    boolean var49 = var36.equals(var47);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 1.0d, 0.0d);
    boolean var56 = var36.equals((java.lang.Object)0.0d);
    java.lang.Object var57 = var36.clone();
    boolean var58 = var0.equals((java.lang.Object)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test178"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var8 = var6.getShape(0);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    boolean var11 = var6.equals(var10);
    java.lang.Object var12 = var6.clone();
    boolean var13 = var0.equals(var12);
    var0.clear();
    java.lang.Object var15 = var0.clone();
    java.lang.Object var16 = var0.clone();
    java.lang.Object var17 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test179"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     java.awt.Shape var4 = var1.getShape(100);
//     java.awt.Shape var6 = var1.getShape((-1));
//     var1.clear();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     var8.clear();
//     var8.clear();
//     java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var18);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 1.0d, 0.0f, (-1.0f));
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)(-1.0f));
//     java.lang.Object var26 = var8.clone();
//     java.lang.Object var27 = var8.clone();
//     var8.clear();
//     var8.clear();
//     org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
//     var30.clear();
//     java.awt.Shape var33 = var30.getShape(100);
//     java.lang.Object var34 = null;
//     boolean var35 = var30.equals(var34);
//     java.lang.Object var36 = var30.clone();
//     java.awt.Shape var38 = var30.getShape(10);
//     var30.clear();
//     boolean var40 = var8.equals((java.lang.Object)var30);
//     boolean var41 = var1.equals((java.lang.Object)var30);
//     org.jfree.chart.util.ShapeList var42 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var44 = var42.getShape(0);
//     java.lang.Object var45 = var42.clone();
//     java.awt.Shape var47 = var42.getShape(10);
//     java.lang.Object var48 = var42.clone();
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     boolean var51 = var42.equals((java.lang.Object)var50);
//     boolean var52 = var1.equals((java.lang.Object)var50);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var50, (-1.0d), 100.0f, 1.0f);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test180"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 0.0d, 1.0f, (-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var9, var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 10.0d, 1.0d);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var7, var15);
    org.jfree.chart.util.RectangleAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, var17, 1.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test181"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 1.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test182"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    boolean var17 = var15.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    var18.clear();
    boolean var21 = var15.equals((java.lang.Object)var18);
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
    boolean var23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var15);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var25 = var24.clone();
    java.lang.Object var26 = var24.clone();
    java.awt.Shape var28 = var24.getShape(10);
    java.lang.Object var29 = null;
    boolean var30 = var24.equals(var29);
    var24.clear();
    java.lang.Object var32 = var24.clone();
    boolean var33 = var15.equals((java.lang.Object)var24);
    boolean var34 = var0.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test183"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    var6.clear();
    var6.clear();
    java.lang.Object var9 = var6.clone();
    boolean var11 = var6.equals((java.lang.Object)(byte)0);
    java.awt.Shape var13 = var6.getShape((-1));
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var6);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var17 = var15.getShape(0);
    java.lang.Object var18 = var15.clone();
    java.awt.Shape var20 = var15.getShape(10);
    java.lang.Object var21 = var15.clone();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var24 = var15.equals((java.lang.Object)var23);
    boolean var25 = var6.equals((java.lang.Object)var24);
    java.awt.Shape var27 = var6.getShape(0);
    var6.clear();
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test184"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = null;
    var0.setShape(10, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)10);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test185"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = var0.getShape((-1));
    var0.clear();
    java.awt.Shape var11 = var0.getShape(10);
    java.lang.Object var12 = var0.clone();
    java.lang.Object var13 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test186"); }


    java.lang.Class var0 = null;
    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)0.0d);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test187"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
    boolean var17 = var0.equals((java.lang.Object)var16);
    int var18 = var0.size();
    int var19 = var0.size();
    java.lang.Object var20 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test188"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var3 = var1.getShape(0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    var1.setShape(10, var6);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var0, var6);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, 1.0f, 1.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    var19.clear();
    java.lang.Object var21 = var19.clone();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var19.setShape(0, var25);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 0.0d, 100.0f, (-1.0f));
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var18, var25);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var33, (java.lang.Object)var36);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, (-1.0d));
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var36, var42);
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var18, var36);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var48, 10.0d, 0.0d);
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var46, var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test189"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, (-1.0d), 0.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-1.0d), 1.0f, 1.0f);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var2, var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var18, var21);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    org.jfree.chart.util.ShapeList var27 = new org.jfree.chart.util.ShapeList();
    var27.clear();
    var27.clear();
    java.lang.Object var30 = var27.clone();
    boolean var32 = var27.equals((java.lang.Object)(byte)0);
    java.awt.Shape var34 = var27.getShape((-1));
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = var27.equals((java.lang.Object)var36);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var26, var36);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 100.0d, 1.0f, (-1.0f));
    boolean var44 = org.jfree.chart.util.ShapeUtilities.equal(var21, var43);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.clone(var51);
    java.awt.Shape var53 = null;
    boolean var54 = org.jfree.chart.util.ShapeUtilities.equal(var51, var53);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var51, 100.0d, 100.0d);
    boolean var58 = org.jfree.chart.util.ShapeUtilities.equal(var21, var51);
    boolean var59 = org.jfree.chart.util.ShapeUtilities.equal(var16, var21);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, (-1.0d), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test190"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, 0.0d, (-1.0d));
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var1, var6);
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test191"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    int var8 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test192"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var17 = var0.getShape(1);
    var0.clear();
    var0.clear();
    java.awt.Shape var21 = var0.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test193"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
//     var2.clear();
//     var2.clear();
//     java.awt.Shape var6 = var2.getShape(1);
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var9 = var7.getShape(0);
//     org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var11 = var10.clone();
//     boolean var12 = var7.equals(var11);
//     java.lang.Object var13 = var7.clone();
//     boolean var14 = var2.equals((java.lang.Object)var7);
//     var2.clear();
//     boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var2);
//     java.lang.Class var17 = null;
//     java.lang.ClassLoader var18 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var17);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)0.0d);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
//     boolean var25 = var2.equals((java.lang.Object)var18);
//     java.lang.Object var26 = var2.clone();
//     java.awt.Shape var27 = null;
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
//     boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
//     java.awt.Shape var41 = null;
//     boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var39, var41);
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var39);
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var27, var44);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var44, 0.0d, 0.0d);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var44);
//     org.jfree.chart.util.ShapeList var50 = new org.jfree.chart.util.ShapeList();
//     var50.clear();
//     var50.clear();
//     java.awt.Shape var54 = var50.getShape(1);
//     boolean var56 = var50.equals((java.lang.Object)(-1));
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.clone(var60);
//     java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.clone(var64);
//     boolean var66 = org.jfree.chart.util.ShapeUtilities.equal(var61, var65);
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.clone(var69);
//     java.awt.Shape var71 = null;
//     boolean var72 = org.jfree.chart.util.ShapeUtilities.equal(var69, var71);
//     boolean var73 = org.jfree.chart.util.ShapeUtilities.equal(var65, var69);
//     var50.setShape(100, var65);
//     boolean var75 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var44, (java.lang.Object)var50);
//     java.awt.Shape var76 = org.jfree.chart.util.ShapeUtilities.clone(var44);
//     boolean var77 = org.jfree.chart.util.ObjectUtilities.equal(var26, (java.lang.Object)var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var50
//     assertTrue("Contract failed: equals-hashcode on var2 and var50", var2.equals(var50) ? var2.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var50
//     assertTrue("Contract failed: equals-hashcode on var7 and var50", var7.equals(var50) ? var7.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var50
//     assertTrue("Contract failed: equals-hashcode on var10 and var50", var10.equals(var50) ? var10.hashCode() == var50.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var50.", var2.equals(var50) == var50.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var50.", var7.equals(var50) == var50.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var50.", var10.equals(var50) == var50.equals(var10));
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test194"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, (-1.0d), 0.0d);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 1.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, (-1.0d), 10.0d);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var16 = var15.clone();
    java.lang.Object var17 = var15.clone();
    var15.clear();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var15.setShape(100, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 100.0d, 0.0d);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var14, var22);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test195"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Shape var3 = var0.getShape((-1));
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var7 = var5.getShape(0);
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var5.equals(var9);
//     java.lang.Object var11 = var5.clone();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var15 = var5.equals((java.lang.Object)var14);
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 0.0d, 100.0f, 1.0f);
//     java.awt.Shape var20 = null;
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var20, var24);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, 100.0d, 0.0f, (-1.0f));
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 0.0d, (-1.0d));
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var14, var24);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, (-1.0d), 0.0d);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 10.0d, 100.0f, 100.0f);
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
//     boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var41, var47);
//     var0.setShape(10, var47);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test196"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, (-1.0d), 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test197"); }


    java.lang.Object var0 = null;
    java.awt.Shape var1 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, (-1.0d));
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    boolean var26 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var25);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var25, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test198"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    var0.setShape(10, var5);
    java.lang.Class var12 = null;
    java.lang.ClassLoader var13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var12);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var13);
    boolean var15 = var0.equals((java.lang.Object)var13);
    int var16 = var0.size();
    java.lang.Object var17 = null;
    boolean var18 = var0.equals(var17);
    java.lang.Object var20 = null;
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var25 = org.jfree.chart.util.ObjectUtilities.equal(var20, (java.lang.Object)var23);
    var0.setShape(100, var23);
    java.lang.Object var27 = var0.clone();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, (-1.0d), 0.0d);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 0.0d, 1.0d);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var39, (-1.0d), 10.0d);
    boolean var43 = var0.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test199"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 1.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, (-1.0d), 1.0d);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, 100.0d, 10.0d);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 0.0d, 10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test200"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    boolean var9 = var7.equals((java.lang.Object)(byte)10);
    java.lang.Object var10 = var7.clone();
    java.lang.Object var11 = var7.clone();
    java.lang.Object var12 = var7.clone();
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    java.lang.Object var15 = var13.clone();
    var13.clear();
    boolean var17 = var7.equals((java.lang.Object)var13);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var7);
    java.awt.Shape var20 = var7.getShape((-1));
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.lang.Object var26 = var21.clone();
    boolean var27 = var7.equals((java.lang.Object)var21);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
    java.awt.Shape var30 = var21.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test201"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var20 = var18.getShape(0);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var22 = var21.clone();
    boolean var23 = var18.equals(var22);
    java.awt.Shape var25 = var18.getShape((-1));
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    boolean var30 = var18.equals((java.lang.Object)var28);
    java.awt.Shape var32 = var18.getShape(0);
    var18.clear();
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)var18);
    int var35 = var18.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test202"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    boolean var12 = var10.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    var13.clear();
    var13.clear();
    boolean var16 = var10.equals((java.lang.Object)var13);
    int var17 = var10.size();
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var20 = var18.getShape(0);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var22 = var21.clone();
    boolean var23 = var18.equals(var22);
    java.lang.Object var24 = var18.clone();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var28 = var18.equals((java.lang.Object)var27);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var27, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var33 = null;
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var33, var37);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var37, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, (-1.0d));
    boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var27, var37);
    boolean var52 = var10.equals((java.lang.Object)var37);
    org.jfree.chart.util.ShapeList var53 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var55 = var53.getShape(0);
    java.lang.Object var56 = var53.clone();
    java.awt.Shape var58 = var53.getShape(10);
    java.lang.Object var59 = var53.clone();
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var62 = var53.equals((java.lang.Object)var61);
    org.jfree.chart.util.ShapeList var63 = new org.jfree.chart.util.ShapeList();
    boolean var65 = var63.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var66 = new org.jfree.chart.util.ShapeList();
    var66.clear();
    var66.clear();
    boolean var69 = var63.equals((java.lang.Object)var66);
    java.lang.Object var70 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var63);
    boolean var71 = var53.equals((java.lang.Object)var63);
    boolean var72 = var10.equals((java.lang.Object)var53);
    boolean var73 = var0.equals((java.lang.Object)var72);
    int var74 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test203"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 1.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 100.0d, (-1.0f), 10.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var21, var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var18, var21);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, (-1.0d), 10.0f, 1.0f);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var21, var33);
    org.jfree.chart.util.ShapeList var39 = new org.jfree.chart.util.ShapeList();
    var39.clear();
    var39.clear();
    java.lang.Object var42 = var39.clone();
    boolean var44 = var39.equals((java.lang.Object)(byte)0);
    var39.clear();
    var39.clear();
    java.lang.Object var47 = var39.clone();
    org.jfree.chart.util.ShapeList var48 = new org.jfree.chart.util.ShapeList();
    boolean var50 = var48.equals((java.lang.Object)(byte)10);
    java.lang.Object var51 = var48.clone();
    java.lang.Object var52 = var48.clone();
    java.lang.Object var53 = var48.clone();
    org.jfree.chart.util.ShapeList var54 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var56 = var54.getShape(0);
    org.jfree.chart.util.ShapeList var57 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var58 = var57.clone();
    boolean var59 = var54.equals(var58);
    java.lang.Object var60 = var54.clone();
    boolean var61 = var48.equals(var60);
    org.jfree.chart.util.ShapeList var62 = new org.jfree.chart.util.ShapeList();
    var62.clear();
    var62.clear();
    java.lang.Object var65 = var62.clone();
    boolean var67 = var62.equals((java.lang.Object)(byte)0);
    java.awt.Shape var69 = var62.getShape((-1));
    java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.clone(var71);
    boolean var73 = var62.equals((java.lang.Object)var71);
    java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.rotateShape(var71, 1.0d, 10.0f, (-1.0f));
    java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    boolean var81 = org.jfree.chart.util.ShapeUtilities.equal(var71, var80);
    boolean var82 = var48.equals((java.lang.Object)var81);
    boolean var83 = var39.equals((java.lang.Object)var48);
    boolean var84 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var38, (java.lang.Object)var48);
    java.awt.Shape var86 = var48.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test204"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    var2.clear();
    var2.clear();
    java.awt.Shape var6 = var2.getShape(1);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var9 = var7.getShape(0);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var11 = var10.clone();
    boolean var12 = var7.equals(var11);
    java.lang.Object var13 = var7.clone();
    boolean var14 = var2.equals((java.lang.Object)var7);
    var2.clear();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var2);
    var2.clear();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, (-1.0d));
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, (-1.0d), 0.0d);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, (-1.0d), 1.0f, 1.0f);
    boolean var30 = var2.equals((java.lang.Object)1.0f);
    var2.clear();
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test205"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    var0.setShape(1, var7);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    java.lang.Object var11 = var9.clone();
    java.awt.Shape var13 = var9.getShape(10);
    java.awt.Shape var15 = var9.getShape(100);
    java.awt.Shape var17 = null;
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, (-1.0d));
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var37, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var41);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 1.0d, 0.0f, (-1.0f));
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var34, var41);
    var9.setShape(11, var34);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    boolean var51 = var0.equals((java.lang.Object)var50);
    int var52 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test206"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
    var22.clear();
    java.awt.Shape var25 = var22.getShape(100);
    java.lang.Object var26 = null;
    boolean var27 = var22.equals(var26);
    java.lang.Object var28 = var22.clone();
    java.awt.Shape var30 = var22.getShape(10);
    var22.clear();
    boolean var32 = var0.equals((java.lang.Object)var22);
    org.jfree.chart.util.ShapeList var33 = new org.jfree.chart.util.ShapeList();
    var33.clear();
    var33.clear();
    java.awt.Shape var37 = var33.getShape(1);
    boolean var39 = var33.equals((java.lang.Object)' ');
    java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    java.lang.Object var41 = var33.clone();
    java.lang.Object var42 = null;
    boolean var43 = var33.equals(var42);
    java.lang.Object var44 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var33);
    boolean var45 = var0.equals(var44);
    int var46 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test207"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 0.0d, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test208"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    var0.setShape(1, var7);
    java.awt.Shape var10 = var0.getShape(102);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test209"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test210"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 1.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, (-1.0d), 1.0d);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, (-1.0d), 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test211"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.awt.Shape var3 = null;
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
//     boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 0.0f, (-1.0f));
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var2, var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 100.0d, 100.0d);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, (-1.0d), (-1.0f), 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 1.0d, 100.0f, 10.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, (-1.0d));
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var34, var39);
//     boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var23, var34);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, (-1.0d), 10.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var23, 100.0d, 10.0f, 100.0f);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test212"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
//     java.awt.Shape var6 = null;
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var9 = var7.getShape(0);
//     org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var11 = var10.clone();
//     boolean var12 = var7.equals(var11);
//     java.lang.Object var13 = var7.clone();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var17 = var7.equals((java.lang.Object)var16);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 0.0d, 100.0f, 1.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 100.0d, 100.0f, 10.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, (-1.0d), (-1.0f), 0.0f);
//     boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var25, var32);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 10.0d, 0.0d);
//     boolean var37 = org.jfree.chart.util.ShapeUtilities.equal(var6, var25);
//     boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var1, var6);
//     org.jfree.chart.util.ShapeList var39 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var40 = var39.clone();
//     java.lang.Object var41 = var39.clone();
//     var39.clear();
//     java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var39);
//     java.awt.Shape var45 = var39.getShape(1);
//     var39.clear();
//     int var47 = var39.size();
//     org.jfree.chart.util.ShapeList var49 = new org.jfree.chart.util.ShapeList();
//     var49.clear();
//     java.awt.Shape var52 = var49.getShape(100);
//     int var53 = var49.size();
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.clone(var57);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.clone(var61);
//     boolean var63 = org.jfree.chart.util.ShapeUtilities.equal(var58, var62);
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.clone(var66);
//     java.awt.Shape var68 = null;
//     boolean var69 = org.jfree.chart.util.ShapeUtilities.equal(var66, var68);
//     boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var62, var66);
//     java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.rotateShape(var66, 10.0d, 10.0f, 100.0f);
//     var49.setShape(1, var66);
//     var49.clear();
//     java.lang.Object var77 = var49.clone();
//     java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.rotateShape(var80, 100.0d, 10.0f, 10.0f);
//     var49.setShape(0, var80);
//     var39.setShape(0, var80);
//     boolean var87 = org.jfree.chart.util.ShapeUtilities.equal(var1, var80);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var49
//     assertTrue("Contract failed: equals-hashcode on var7 and var49", var7.equals(var49) ? var7.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var39
//     assertTrue("Contract failed: equals-hashcode on var10 and var39", var10.equals(var39) ? var10.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var49
//     assertTrue("Contract failed: equals-hashcode on var10 and var49", var10.equals(var49) ? var10.hashCode() == var49.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var39.", var7.equals(var39) == var39.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var49.", var7.equals(var49) == var49.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var39.", var10.equals(var39) == var39.equals(var10));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var49.", var10.equals(var49) == var49.equals(var10));
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test213"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    boolean var8 = var6.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    var9.clear();
    var9.clear();
    boolean var12 = var6.equals((java.lang.Object)var9);
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)var6);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 100.0d, 1.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, (-1.0f));
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, (-1.0d), 0.0f, 1.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var4, var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var4, var30);
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test214"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    java.awt.Shape var10 = var0.getShape(10);
    java.lang.Object var11 = var0.clone();
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var14 = var12.getShape(0);
    java.lang.Object var15 = var12.clone();
    java.awt.Shape var17 = var12.getShape(10);
    java.lang.Object var18 = var12.clone();
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var21 = var12.equals((java.lang.Object)var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var24);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)100.0f);
    boolean var29 = var12.equals((java.lang.Object)var28);
    java.awt.Shape var31 = var12.getShape(0);
    java.lang.Object var32 = var12.clone();
    org.jfree.chart.util.ShapeList var33 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var35 = var33.getShape(0);
    java.lang.Object var36 = var33.clone();
    java.awt.Shape var38 = var33.getShape(10);
    java.lang.Object var39 = var33.clone();
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var42 = var33.equals((java.lang.Object)var41);
    java.awt.Shape var44 = var33.getShape(11);
    int var45 = var33.size();
    boolean var46 = var12.equals((java.lang.Object)var33);
    java.lang.Object var47 = var33.clone();
    boolean var48 = var0.equals(var47);
    java.awt.Shape var50 = var0.getShape(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test215"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    java.awt.Shape var6 = var3.getShape(100);
    int var7 = var3.size();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = null;
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 10.0f, 100.0f);
    var3.setShape(1, var20);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var1, var20);
    java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test216"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var9 = var0.getShape(0);
    int var10 = var0.size();
    var0.clear();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    boolean var14 = var0.equals((java.lang.Object)100.0f);
    java.awt.Shape var16 = var0.getShape(10);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, (-1.0d), 100.0f, (-1.0f));
    boolean var24 = var0.equals((java.lang.Object)(-1.0d));
    java.lang.Object var25 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test217"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.io.ObjectOutputStream var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var4, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test218"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, (-1.0d), 0.0f, 10.0f);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test219"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var10 = var0.equals((java.lang.Object)var9);
//     java.lang.Object var11 = var0.clone();
//     java.lang.Object var12 = var0.clone();
//     java.awt.Shape var14 = var0.getShape(101);
//     org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var17 = var16.clone();
//     java.lang.Object var18 = var16.clone();
//     var16.clear();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var16.setShape(100, var23);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 100.0d, 0.0d);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 1.0d, (-1.0d));
//     var0.setShape(1, var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var16.", var3.equals(var16) == var16.equals(var3));
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test220"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    var0.clear();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var14 = var13.clone();
    boolean var15 = var10.equals(var14);
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    var16.clear();
    var16.clear();
    java.lang.Object var19 = var16.clone();
    boolean var21 = var16.equals((java.lang.Object)(byte)0);
    java.awt.Shape var23 = var16.getShape((-1));
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var15, (java.lang.Object)var16);
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var27 = var25.getShape(0);
    java.lang.Object var28 = var25.clone();
    java.awt.Shape var30 = var25.getShape(10);
    java.lang.Object var31 = var25.clone();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var34 = var25.equals((java.lang.Object)var33);
    boolean var35 = var16.equals((java.lang.Object)var34);
    boolean var36 = var0.equals((java.lang.Object)var35);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    org.jfree.chart.util.ShapeList var41 = new org.jfree.chart.util.ShapeList();
    var41.clear();
    var41.clear();
    java.lang.Object var44 = var41.clone();
    boolean var46 = var41.equals((java.lang.Object)(byte)0);
    var41.clear();
    var41.clear();
    java.lang.Object var49 = var41.clone();
    java.lang.Object var50 = var41.clone();
    boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var40, (java.lang.Object)var41);
    boolean var52 = var0.equals((java.lang.Object)var41);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var55);
    org.jfree.chart.util.ShapeList var57 = new org.jfree.chart.util.ShapeList();
    var57.clear();
    var57.clear();
    java.lang.Object var60 = var57.clone();
    boolean var62 = var57.equals((java.lang.Object)(byte)0);
    java.awt.Shape var64 = var57.getShape((-1));
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.clone(var66);
    boolean var68 = var57.equals((java.lang.Object)var66);
    boolean var69 = org.jfree.chart.util.ShapeUtilities.equal(var56, var66);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.rotateShape(var66, 10.0d, 0.0f, 100.0f);
    boolean var74 = var41.equals((java.lang.Object)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test221"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    var0.clear();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    var6.clear();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var15 = var6.equals((java.lang.Object)var14);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    boolean var20 = var6.equals((java.lang.Object)var19);
    boolean var21 = var0.equals((java.lang.Object)var19);
    java.io.ObjectOutputStream var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var19, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test222"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var4 = org.jfree.chart.util.ShapeUtilities.equal(var1, var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 10.0d, 1.0d);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test223"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, (-1.0d), 0.0d);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 1.0d);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, (-1.0d), 10.0d);
    java.io.ObjectOutputStream var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var11, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test224"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     boolean var5 = var3.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     var6.clear();
//     var6.clear();
//     boolean var9 = var3.equals((java.lang.Object)var6);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     java.awt.Shape var23 = null;
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var21, var23);
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)1.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, 10.0f, 1.0f);
//     boolean var35 = var3.equals((java.lang.Object)var34);
//     boolean var36 = var0.equals((java.lang.Object)var3);
//     java.awt.Shape var38 = null;
//     var3.setShape(100, var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var6
//     assertTrue("Contract failed: equals-hashcode on var3 and var6", var3.equals(var6) ? var3.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var3
//     assertTrue("Contract failed: equals-hashcode on var6 and var3", var6.equals(var3) ? var6.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test225"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
//     boolean var6 = org.jfree.chart.util.ShapeUtilities.equal(var2, var5);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     var11.clear();
//     var11.clear();
//     java.lang.Object var14 = var11.clone();
//     boolean var16 = var11.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var18 = var11.getShape((-1));
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     boolean var22 = var11.equals((java.lang.Object)var20);
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var10, var20);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 100.0d, 1.0f, (-1.0f));
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var5, var27);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var5, 100.0d, 100.0f, 0.0f);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test226"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 10.0d);
    org.jfree.chart.util.RectangleAnchor var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, var32, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test227"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var30 = var29.clone();
    java.lang.Object var31 = var29.clone();
    var29.clear();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    var29.setShape(100, var36);
    var0.setShape(100, var36);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var42, var46);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.clone(var50);
    java.awt.Shape var52 = null;
    boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var50, var52);
    boolean var54 = org.jfree.chart.util.ShapeUtilities.equal(var46, var50);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.rotateShape(var50, 10.0d, (-1.0f), 10.0f);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.clone(var62);
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.rotateShape(var63, 0.0d, 10.0f, 100.0f);
    boolean var68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)100, (java.lang.Object)var67);
    org.jfree.chart.util.RectangleAnchor var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var67, var69, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test228"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    java.awt.Shape var17 = null;
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var15, var17);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var11, var15);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 100.0d, 100.0d);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 1.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var27, 100.0d, (-1.0f), 10.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var25, var32);
    boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var22, var25);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var37 = null;
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var44);
    boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var41, var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var37, var41);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 100.0d, 0.0f, (-1.0f));
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var36, var51);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var51, 100.0d, 100.0d);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var55);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.clone(var55);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var55, 1.0d, 1.0d);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.clone(var55);
    boolean var66 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)var55);
    boolean var67 = org.jfree.chart.util.ShapeUtilities.equal(var3, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test229"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    java.awt.Shape var9 = var0.getShape(100);
    java.lang.Object var10 = var0.clone();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var24 = null;
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 100.0d, 100.0d);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 0.0d, 100.0f, 0.0f);
    boolean var34 = var0.equals((java.lang.Object)100.0f);
    java.lang.Object var35 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test230"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.lang.Object var5 = var0.clone();
    int var6 = var0.size();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 1.0d, 0.0f, (-1.0f));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    var0.setShape(0, var21);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    java.io.ObjectOutputStream var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test231"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    var6.clear();
    boolean var10 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    boolean var13 = var11.equals((java.lang.Object)(byte)10);
    java.lang.Object var14 = var11.clone();
    java.lang.Object var15 = var11.clone();
    java.lang.Object var16 = var11.clone();
    boolean var17 = var6.equals((java.lang.Object)var11);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var21 = var18.getShape(100);
    int var22 = var18.size();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var27, var31);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    java.awt.Shape var37 = null;
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var35, var37);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape(var35, 10.0d, 10.0f, 100.0f);
    var18.setShape(1, var35);
    var18.clear();
    java.lang.Object var46 = var18.clone();
    java.lang.Object var47 = var18.clone();
    java.lang.Object var48 = var18.clone();
    boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)var18);
    java.lang.Object var50 = var18.clone();
    org.jfree.chart.util.ShapeList var51 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var53 = var51.getShape(0);
    java.lang.Object var54 = var51.clone();
    java.awt.Shape var56 = var51.getShape(10);
    java.lang.Object var57 = var51.clone();
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var60 = var51.equals((java.lang.Object)var59);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.clone(var63);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var67 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var64, (java.lang.Object)100.0f);
    boolean var68 = var51.equals((java.lang.Object)var67);
    java.awt.Shape var70 = var51.getShape(0);
    boolean var71 = var18.equals((java.lang.Object)var51);
    java.awt.Shape var73 = var18.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test232"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    boolean var8 = var6.equals((java.lang.Object)(byte)10);
    java.lang.Object var9 = var6.clone();
    java.lang.Object var10 = var6.clone();
    java.lang.Object var11 = var6.clone();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)(-1.0f));
    boolean var14 = var0.equals((java.lang.Object)(-1.0f));
    java.lang.Object var15 = var0.clone();
    java.lang.Object var16 = null;
    boolean var17 = var0.equals(var16);
    java.lang.Object var18 = var0.clone();
    java.lang.Object var19 = var0.clone();
    org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var21 = var20.clone();
    java.lang.Object var22 = var20.clone();
    int var23 = var20.size();
    java.awt.Shape var25 = var20.getShape(0);
    org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
    boolean var28 = var26.equals((java.lang.Object)(byte)10);
    java.lang.Object var29 = var26.clone();
    java.lang.Object var30 = var26.clone();
    java.lang.Object var31 = var26.clone();
    boolean var33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)(-1.0f));
    boolean var34 = var20.equals((java.lang.Object)(-1.0f));
    java.lang.Object var35 = var20.clone();
    org.jfree.chart.util.ShapeList var36 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var37 = var36.clone();
    java.lang.Object var38 = var36.clone();
    var36.clear();
    int var40 = var36.size();
    java.lang.Object var41 = var36.clone();
    boolean var42 = var20.equals((java.lang.Object)var36);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.clone(var44);
    java.lang.Object var46 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var44);
    boolean var47 = var36.equals((java.lang.Object)var44);
    java.lang.Object var48 = var36.clone();
    boolean var49 = var0.equals(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test233"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     var0.clear();
//     java.lang.Object var14 = var0.clone();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var16);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 0.0d, (-1.0f), 0.0f);
//     boolean var22 = var0.equals((java.lang.Object)var16);
//     org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var26 = var24.getShape(0);
//     int var27 = var24.size();
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     var24.setShape(10, var31);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var31);
//     var0.setShape(0, var33);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var24.", var3.equals(var24) == var24.equals(var3));
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test234"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 100.0d, 10.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test235"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, (-1.0d), 10.0f, 100.0f);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    java.lang.Object var11 = var8.clone();
    java.awt.Shape var13 = var8.getShape(10);
    int var14 = var8.size();
    java.lang.Object var15 = var8.clone();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    var8.setShape(100, var19);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var19, var23);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var7, var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test236"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, (-1.0d), 100.0f, 0.0f);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    java.awt.Shape var10 = var6.getShape(10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 1.0d, 100.0f, (-1.0f));
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var14, var21);
    var6.setShape(10, var14);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    var24.clear();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var29);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    var24.setShape(100, var30);
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)var30);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var5, var30);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, (-1.0d));
    org.jfree.chart.util.RectangleAnchor var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, var42, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test237"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 1.0f, (-1.0f));
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 0.0f, 0.0f);
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    var12.clear();
    var12.clear();
    java.awt.Shape var16 = var12.getShape(1);
    boolean var18 = var12.equals((java.lang.Object)' ');
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    var12.setShape(100, var21);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 0.0d, 10.0f, 10.0f);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var7, var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, (-1.0d), 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test238"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 10.0f, 1.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), 100.0f, 1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(-1.0d));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test239"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.awt.Shape var4 = var0.getShape(1);
//     java.lang.Object var5 = var0.clone();
//     int var6 = var0.size();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 1.0d, 0.0f, (-1.0f));
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var14);
//     var0.setShape(0, var21);
//     org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
//     boolean var25 = var23.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
//     var26.clear();
//     var26.clear();
//     boolean var29 = var23.equals((java.lang.Object)var26);
//     java.lang.Object var30 = var26.clone();
//     boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var0.", var23.equals(var0) == var0.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test240"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
//     var1.clear();
//     var1.clear();
//     java.awt.Shape var5 = var1.getShape(1);
//     boolean var7 = var1.equals((java.lang.Object)(-1));
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
//     java.awt.Shape var22 = null;
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
//     boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
//     var1.setShape(100, var16);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 0.0d);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 1.0d, 0.0f, 1.0f);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 100.0d, (-1.0d));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var33, 1.0d, 0.0f, 0.0f);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test241"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 100.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test242"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 0.0d, 100.0f, (-1.0f));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, 0.0d, 0.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var10, 1.0d, 0.0f, 100.0f);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test243"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    int var5 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 100.0d, 100.0d);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 10.0d, 10.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    boolean var20 = var0.equals((java.lang.Object)var18);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 100.0d, 100.0d);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var23, 100.0d, 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test244"); }


    java.lang.Class var0 = null;
    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)0.0d);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)(-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test245"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var0.setShape(0, var19);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 10.0d, 10.0f, 10.0f);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var19, var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 100.0d, (-1.0d));
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 0.0d, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test246"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     int var7 = var0.size();
//     java.lang.Object var8 = var0.clone();
//     var0.clear();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
//     java.awt.Shape var24 = null;
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
//     boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 10.0d, 10.0f, 100.0f);
//     var0.setShape(12, var30);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test247"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.lang.Class var5 = null;
    java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    java.lang.Object var8 = var0.clone();
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    var9.clear();
    java.awt.Shape var12 = var9.getShape(100);
    java.lang.Object var13 = null;
    boolean var14 = var9.equals(var13);
    java.lang.Object var15 = var9.clone();
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    var16.clear();
    var16.clear();
    java.lang.Object var19 = var16.clone();
    boolean var21 = var16.equals((java.lang.Object)(byte)0);
    java.awt.Shape var23 = var16.getShape((-1));
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    boolean var27 = var16.equals((java.lang.Object)var25);
    boolean var28 = var9.equals((java.lang.Object)var16);
    var9.clear();
    java.lang.Object var30 = var9.clone();
    boolean var31 = var0.equals(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test248"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    var0.clear();
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    var7.clear();
    var7.clear();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 1.0d, 0.0f, (-1.0f));
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)(-1.0f));
    java.lang.Object var25 = var7.clone();
    java.lang.Object var26 = var7.clone();
    var7.clear();
    var7.clear();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    var29.clear();
    java.awt.Shape var32 = var29.getShape(100);
    java.lang.Object var33 = null;
    boolean var34 = var29.equals(var33);
    java.lang.Object var35 = var29.clone();
    java.awt.Shape var37 = var29.getShape(10);
    var29.clear();
    boolean var39 = var7.equals((java.lang.Object)var29);
    boolean var40 = var0.equals((java.lang.Object)var29);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
    java.lang.Object var44 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
    java.lang.Object var45 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
    boolean var46 = var0.equals(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test249"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.lang.Class var1 = null;
//     java.lang.ClassLoader var2 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var1);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var2);
//     org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
//     var10.clear();
//     var10.clear();
//     java.awt.Shape var14 = var10.getShape(1);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var19 = null;
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)var20);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, (-1.0d), (-1.0f), 0.0f);
//     var10.setShape(0, var25);
//     boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var25);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var25, 1.0d, 100.0f, 1.0f);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test250"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    var0.clear();
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    var0.clear();
    java.awt.Shape var12 = var0.getShape(12);
    java.lang.Object var13 = var0.clone();
    java.awt.Shape var15 = var0.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test251"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = var0.getShape(10);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test252"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var11 = var0.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test253"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 100.0d);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    var5.clear();
    var5.clear();
    java.awt.Shape var9 = var5.getShape(1);
    java.lang.Object var10 = var5.clone();
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    boolean var13 = var11.equals((java.lang.Object)(byte)10);
    java.lang.Object var14 = var11.clone();
    java.lang.Object var15 = var11.clone();
    java.lang.Object var16 = var11.clone();
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var19 = var17.getShape(0);
    org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var21 = var20.clone();
    boolean var22 = var17.equals(var21);
    java.lang.Object var23 = var17.clone();
    boolean var24 = var11.equals(var23);
    boolean var25 = var5.equals((java.lang.Object)var11);
    java.awt.Shape var27 = var11.getShape(10);
    org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var29 = var28.clone();
    java.lang.Object var30 = var28.clone();
    int var31 = var28.size();
    java.awt.Shape var33 = var28.getShape(0);
    java.awt.Shape var35 = var28.getShape(10);
    java.awt.Shape var37 = var28.getShape(100);
    java.lang.Object var38 = var28.clone();
    boolean var39 = var11.equals(var38);
    org.jfree.chart.util.ShapeList var40 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var41 = var40.clone();
    var40.clear();
    var40.clear();
    boolean var44 = var11.equals((java.lang.Object)var40);
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)var11);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test254"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     var0.clear();
//     java.lang.Object var3 = var0.clone();
//     boolean var5 = var0.equals((java.lang.Object)(byte)0);
//     var0.clear();
//     var0.clear();
//     java.lang.Object var8 = var0.clone();
//     java.lang.Object var9 = var0.clone();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
//     java.awt.Shape var24 = null;
//     boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var22, var24);
//     boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 10.0d, 10.0f, 100.0f);
//     java.awt.Shape var31 = null;
//     boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var30, var31);
//     var0.setShape(102, var30);
//     java.lang.Object var34 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var34
//     assertTrue("Contract failed: equals-hashcode on var3 and var34", var3.equals(var34) ? var3.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var34
//     assertTrue("Contract failed: equals-hashcode on var9 and var34", var9.equals(var34) ? var9.hashCode() == var34.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var34.", var3.equals(var34) == var34.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var34.", var8.equals(var34) == var34.equals(var8));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var34.", var9.equals(var34) == var34.equals(var9));
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test255"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     java.awt.Shape var7 = var3.getShape(1);
//     boolean var9 = var3.equals((java.lang.Object)' ');
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
//     java.lang.Object var11 = var3.clone();
//     int var12 = var3.size();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 0.0d, (-1.0d));
//     var3.setShape(10, var18);
//     boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var2, var18);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var18, 0.0d, 0.0f, (-1.0f));
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test256"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 1.0d, 0.0f, (-1.0f));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 0.0d, (-1.0f), 1.0f);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var19 = var18.clone();
    java.lang.Object var20 = var18.clone();
    java.awt.Shape var22 = var18.getShape(10);
    java.awt.Shape var24 = var18.getShape(100);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 0.0d, (-1.0d));
    boolean var30 = var18.equals((java.lang.Object)(-1.0d));
    org.jfree.chart.util.ShapeList var31 = new org.jfree.chart.util.ShapeList();
    var31.clear();
    var31.clear();
    java.lang.Object var34 = var31.clone();
    boolean var36 = var31.equals((java.lang.Object)(byte)0);
    var31.clear();
    var31.clear();
    boolean var39 = var18.equals((java.lang.Object)var31);
    org.jfree.chart.util.ShapeList var40 = new org.jfree.chart.util.ShapeList();
    var40.clear();
    java.awt.Shape var43 = var40.getShape(100);
    java.lang.Object var44 = null;
    boolean var45 = var40.equals(var44);
    java.lang.Object var46 = var40.clone();
    java.lang.Object var47 = org.jfree.chart.util.ObjectUtilities.clone(var46);
    boolean var48 = var31.equals(var47);
    boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test257"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 1.0d, 100.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 100.0f, 100.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 10.0d, 100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test258"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     var3.clear();
//     var3.clear();
//     boolean var6 = var0.equals((java.lang.Object)var3);
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)100.0f);
//     java.awt.Shape var12 = null;
//     var0.setShape(0, var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test259"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
    boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    var0.setShape(10, var8);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
    var18.setShape(100, var24);
    boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test260"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = var5.getShape(0);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = var8.clone();
    boolean var10 = var5.equals(var9);
    java.lang.Object var11 = var5.clone();
    boolean var12 = var0.equals((java.lang.Object)var5);
    java.lang.Object var13 = null;
    boolean var14 = var0.equals(var13);
    int var15 = var0.size();
    var0.clear();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test261"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)100.0f);
    boolean var17 = var0.equals((java.lang.Object)var16);
    java.awt.Shape var19 = var0.getShape(0);
    java.lang.Object var20 = var0.clone();
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    java.lang.Object var24 = var21.clone();
    java.awt.Shape var26 = var21.getShape(10);
    java.lang.Object var27 = var21.clone();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var30 = var21.equals((java.lang.Object)var29);
    java.awt.Shape var32 = var21.getShape(11);
    int var33 = var21.size();
    boolean var34 = var0.equals((java.lang.Object)var21);
    java.lang.Object var35 = var21.clone();
    java.awt.Shape var37 = var21.getShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test262"); }


    java.lang.Object var0 = null;
    org.jfree.chart.util.ShapeList var1 = new org.jfree.chart.util.ShapeList();
    var1.clear();
    var1.clear();
    java.lang.Object var4 = var1.clone();
    boolean var6 = var1.equals((java.lang.Object)(byte)0);
    var1.clear();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test263"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Shape var4 = var0.getShape(10);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 1.0d, 100.0f, (-1.0f));
//     boolean var16 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
//     var0.setShape(10, var8);
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     var18.clear();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
//     var18.setShape(100, var24);
//     boolean var31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var24);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
//     boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     java.awt.Shape var45 = null;
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var43, var45);
//     boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var39, var43);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone(var43);
//     boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var8, var43);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
//     org.jfree.chart.util.ShapeList var54 = new org.jfree.chart.util.ShapeList();
//     var54.clear();
//     var54.clear();
//     java.lang.Object var57 = var54.clone();
//     boolean var59 = var54.equals((java.lang.Object)(byte)0);
//     var54.clear();
//     var54.clear();
//     java.lang.Object var62 = var54.clone();
//     java.lang.Object var63 = var54.clone();
//     boolean var64 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var53, (java.lang.Object)var54);
//     boolean var65 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)var64);
//     
//     // Checks the contract:  equals-hashcode on var54 and var0
//     assertTrue("Contract failed: equals-hashcode on var54 and var0", var54.equals(var0) ? var54.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var18
//     assertTrue("Contract failed: equals-hashcode on var54 and var18", var54.equals(var18) ? var54.hashCode() == var18.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var0.", var54.equals(var0) == var0.equals(var54));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var18.", var54.equals(var18) == var18.equals(var54));
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test264"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     int var3 = var0.size();
//     var0.clear();
//     var0.clear();
//     var0.clear();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     boolean var10 = var8.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     var11.clear();
//     var11.clear();
//     boolean var14 = var8.equals((java.lang.Object)var11);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
//     java.awt.Shape var28 = null;
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var26, var28);
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)1.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var22);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 0.0d, 10.0f, 1.0f);
//     boolean var40 = var8.equals((java.lang.Object)var39);
//     var0.setShape(100, var39);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var0.", var11.equals(var0) == var0.equals(var11));
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test265"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    var0.clear();
    var0.clear();
    var0.clear();
    java.lang.Object var9 = var0.clone();
    int var10 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test266"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    int var3 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    var0.setShape(10, var7);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 0.0d, 1.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test267"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var6 = var4.getShape(0);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var8 = var7.clone();
    boolean var9 = var4.equals(var8);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = var4.equals((java.lang.Object)var14);
    boolean var17 = var0.equals((java.lang.Object)var14);
    var0.clear();
    java.lang.Object var19 = var0.clone();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var23, var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    java.awt.Shape var33 = null;
    boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var31, var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var27, var31);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.rotateShape(var41, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var45, (-1.0d), 0.0d);
    boolean var49 = org.jfree.chart.util.ShapeUtilities.equal(var39, var48);
    java.lang.Object var50 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var39);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.rotateShape(var39, 10.0d, 100.0f, 0.0f);
    boolean var55 = var0.equals((java.lang.Object)10.0d);
    org.jfree.chart.util.ShapeList var56 = new org.jfree.chart.util.ShapeList();
    boolean var58 = var56.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var59 = new org.jfree.chart.util.ShapeList();
    var59.clear();
    var59.clear();
    boolean var62 = var56.equals((java.lang.Object)var59);
    java.lang.Object var63 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var56);
    java.lang.Object var64 = var56.clone();
    java.awt.Shape var66 = var56.getShape(100);
    java.lang.Object var67 = var56.clone();
    boolean var68 = var0.equals(var67);
    org.jfree.chart.util.ShapeList var69 = new org.jfree.chart.util.ShapeList();
    boolean var71 = var69.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var72 = new org.jfree.chart.util.ShapeList();
    var72.clear();
    var72.clear();
    boolean var75 = var69.equals((java.lang.Object)var72);
    org.jfree.chart.util.ShapeList var76 = new org.jfree.chart.util.ShapeList();
    boolean var78 = var76.equals((java.lang.Object)(byte)10);
    java.lang.Object var79 = var76.clone();
    java.lang.Object var80 = var76.clone();
    java.lang.Object var81 = var76.clone();
    org.jfree.chart.util.ShapeList var82 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var83 = var82.clone();
    java.lang.Object var84 = var82.clone();
    var82.clear();
    boolean var86 = var76.equals((java.lang.Object)var82);
    boolean var87 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var75, (java.lang.Object)var76);
    java.awt.Shape var89 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    boolean var90 = var76.equals((java.lang.Object)0.0f);
    java.awt.Shape var92 = var76.getShape(100);
    int var93 = var76.size();
    boolean var94 = var0.equals((java.lang.Object)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test268"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.lang.Class var5 = null;
    java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    java.lang.Object var8 = null;
    boolean var9 = var0.equals(var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    java.awt.Shape var13 = null;
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, (-1.0d));
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 0.0f, 100.0f);
    boolean var35 = var10.equals((java.lang.Object)var17);
    java.lang.Object var36 = var10.clone();
    boolean var37 = var0.equals((java.lang.Object)var10);
    java.lang.Object var38 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var40 = var10.getShape(101);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test269"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.0d, (-1.0f), 0.0f);
    org.jfree.chart.util.RectangleAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var7, 10.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test270"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape(0);
//     org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var4 = var3.clone();
//     boolean var5 = var0.equals(var4);
//     java.awt.Shape var7 = var0.getShape((-1));
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.awt.Shape var14 = var0.getShape(0);
//     var0.clear();
//     java.lang.Object var16 = var0.clone();
//     java.lang.Object var17 = var0.clone();
//     java.lang.Object var18 = var0.clone();
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (-1.0f));
//     boolean var22 = var0.equals((java.lang.Object)var21);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 1.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, (-1.0d), 10.0f, 1.0f);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var32);
//     boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var30, var32);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var30, (-1.0d), 1.0d);
//     var0.setShape(0, var37);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var0.", var3.equals(var0) == var0.equals(var3));
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test271"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    int var3 = var0.size();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    var0.setShape(10, var7);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, 10.0d, 100.0d);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var18, var20);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 10.0d, 1.0d);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var16, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test272"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    var0.setShape(0, var6);
    var0.clear();
    int var9 = var0.size();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 0.0d, (-1.0d));
    boolean var15 = var0.equals((java.lang.Object)(-1.0d));
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var18 = var17.clone();
    java.lang.Object var19 = var17.clone();
    java.awt.Shape var21 = var17.getShape(10);
    java.awt.Shape var23 = var17.getShape(100);
    java.awt.Shape var25 = null;
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var29, var33);
    boolean var35 = org.jfree.chart.util.ShapeUtilities.equal(var25, var29);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var29, 0.0d, (-1.0d));
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.rotateShape(var45, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var50 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var49);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.clone(var49);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.rotateShape(var49, 1.0d, 0.0f, (-1.0f));
    boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var42, var49);
    var17.setShape(11, var42);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.clone(var42);
    var0.setShape(0, var42);
    java.io.ObjectOutputStream var60 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var42, var60);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test273"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = var5.getShape(0);
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var9 = var8.clone();
    boolean var10 = var5.equals(var9);
    java.lang.Object var11 = var5.clone();
    boolean var12 = var0.equals((java.lang.Object)var5);
    java.lang.Object var13 = var0.clone();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    var18.clear();
    java.awt.Shape var22 = var18.getShape(1);
    boolean var24 = var18.equals((java.lang.Object)(-1));
    java.awt.Shape var26 = var18.getShape(0);
    org.jfree.chart.util.ShapeList var27 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var29 = var27.getShape(0);
    java.lang.Object var30 = var27.clone();
    boolean var31 = var18.equals(var30);
    java.awt.Shape var32 = null;
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var36, var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, (-1.0d));
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.clone(var54);
    boolean var56 = org.jfree.chart.util.ObjectUtilities.equal(var30, (java.lang.Object)var55);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, 100.0d, 10.0f, (-1.0f));
    boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var16, var60);
    boolean var62 = var0.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test274"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    java.awt.Shape var15 = var0.getShape(0);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var0.setShape(0, var19);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test275"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, (-1.0d), 0.0d);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test276"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    org.jfree.chart.util.ShapeList var2 = new org.jfree.chart.util.ShapeList();
    var2.clear();
    var2.clear();
    java.awt.Shape var6 = var2.getShape(1);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var9 = var7.getShape(0);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var11 = var10.clone();
    boolean var12 = var7.equals(var11);
    java.lang.Object var13 = var7.clone();
    boolean var14 = var2.equals((java.lang.Object)var7);
    var2.clear();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var2);
    java.lang.Class var17 = null;
    java.lang.ClassLoader var18 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var17);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)0.0d);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    boolean var25 = var2.equals((java.lang.Object)var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test277"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     java.lang.Object var6 = var0.clone();
//     org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
//     var7.clear();
//     var7.clear();
//     java.lang.Object var10 = var7.clone();
//     boolean var12 = var7.equals((java.lang.Object)(byte)0);
//     java.awt.Shape var14 = var7.getShape((-1));
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
//     boolean var18 = var7.equals((java.lang.Object)var16);
//     boolean var19 = var0.equals((java.lang.Object)var7);
//     java.lang.Object var20 = var0.clone();
//     org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
//     var21.clear();
//     java.awt.Shape var24 = var21.getShape(100);
//     var21.clear();
//     boolean var26 = org.jfree.chart.util.ObjectUtilities.equal(var20, (java.lang.Object)var21);
//     int var27 = var21.size();
//     org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
//     var28.clear();
//     var28.clear();
//     java.awt.Shape var32 = var28.getShape(1);
//     boolean var34 = var28.equals((java.lang.Object)' ');
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     var28.setShape(100, var37);
//     java.awt.Shape var40 = var28.getShape(100);
//     java.lang.Object var41 = var28.clone();
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.rotateShape(var48, 1.0d, 100.0f, (-1.0f));
//     boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var45, var52);
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     boolean var56 = org.jfree.chart.util.ShapeUtilities.equal(var45, var55);
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, (-1.0d), 1.0f, 10.0f);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.rotateShape(var63, (-1.0d), (-1.0f), 0.0f);
//     java.lang.Object var68 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var67);
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.clone(var67);
//     boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var55, var67);
//     java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var55, 0.0d, (-1.0d));
//     var28.setShape(2, var55);
//     boolean var75 = var21.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var28
//     assertTrue("Contract failed: equals-hashcode on var21 and var28", var21.equals(var28) ? var21.hashCode() == var28.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var28.", var0.equals(var28) == var28.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var28.", var7.equals(var28) == var28.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var28.", var21.equals(var28) == var28.equals(var21));
//     
//     // Checks the contract:  equals-hashcode on var6 and var41
//     assertTrue("Contract failed: equals-hashcode on var6 and var41", var6.equals(var41) ? var6.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var41
//     assertTrue("Contract failed: equals-hashcode on var10 and var41", var10.equals(var41) ? var10.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var41
//     assertTrue("Contract failed: equals-hashcode on var20 and var41", var20.equals(var41) ? var20.hashCode() == var41.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var41.", var6.equals(var41) == var41.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var41.", var10.equals(var41) == var41.equals(var10));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var41.", var20.equals(var41) == var41.equals(var20));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test278"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    int var3 = var0.size();
    int var4 = var0.size();
    int var5 = var0.size();
    java.awt.Shape var7 = var0.getShape(1);
    java.lang.Object var8 = var0.clone();
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var10 = var9.clone();
    java.lang.Object var11 = var9.clone();
    var9.clear();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, (-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, (-1.0d), 1.0f, 0.0f);
    boolean var20 = var9.equals((java.lang.Object)var15);
    boolean var21 = var0.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test279"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(100);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    boolean var6 = var0.equals((java.lang.Object)(-1.0f));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    var0.setShape(1, var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var17, var21);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Shape var27 = null;
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var25, var27);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var21, var25);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Shape var31 = null;
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var31, var44);
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var48);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    boolean var54 = org.jfree.chart.util.ShapeUtilities.equal(var49, var53);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.clone(var57);
    java.awt.Shape var59 = null;
    boolean var60 = org.jfree.chart.util.ShapeUtilities.equal(var57, var59);
    boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var53, var57);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var31, var57);
    boolean var63 = org.jfree.chart.util.ShapeUtilities.equal(var25, var57);
    java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var66, 1.0d, 0.0d);
    boolean var70 = org.jfree.chart.util.ShapeUtilities.equal(var25, var66);
    var0.setShape(102, var66);
    org.jfree.chart.util.ShapeList var72 = new org.jfree.chart.util.ShapeList();
    var72.clear();
    var72.clear();
    java.awt.Shape var76 = null;
    java.awt.Shape var79 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.clone(var79);
    java.awt.Shape var83 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.clone(var83);
    boolean var85 = org.jfree.chart.util.ShapeUtilities.equal(var80, var84);
    boolean var86 = org.jfree.chart.util.ShapeUtilities.equal(var76, var80);
    java.awt.Shape var90 = org.jfree.chart.util.ShapeUtilities.rotateShape(var80, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var93 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var80, 0.0d, (-1.0d));
    var72.setShape(11, var80);
    java.lang.Object var95 = var72.clone();
    boolean var96 = var0.equals(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test280"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var8, var12);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    java.awt.Shape var18 = null;
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var16, var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var12, (java.lang.Object)1.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var25, var29);
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var4, var25);
    org.jfree.chart.util.RectangleAnchor var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, var32, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test281"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.awt.Shape var8 = var3.getShape(0);
    boolean var10 = var3.equals((java.lang.Object)(byte)0);
    java.lang.Object var11 = var3.clone();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test282"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    java.awt.Shape var7 = var3.getShape(1);
    boolean var9 = var3.equals((java.lang.Object)' ');
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    var3.setShape(100, var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 0.0d, 10.0f, 10.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var2, var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test283"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 1.0f, (-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var10 = null;
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var10, var14);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var14, 100.0d, 0.0f, (-1.0f));
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var9, var24);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 100.0d, 100.0d);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, 0.0d, (-1.0d));
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var41, var46);
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var30, var41);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    boolean var50 = org.jfree.chart.util.ShapeUtilities.equal(var7, var49);
    java.awt.Shape var51 = null;
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var49, var51);
    java.awt.Shape var53 = null;
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.clone(var55);
    boolean var57 = org.jfree.chart.util.ShapeUtilities.equal(var53, var56);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var56, 10.0d, 0.0d);
    boolean var61 = org.jfree.chart.util.ShapeUtilities.equal(var51, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test284"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    var0.clear();
    var0.clear();
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var6 = var4.getShape(0);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var8 = var7.clone();
    boolean var9 = var4.equals(var8);
    java.awt.Shape var11 = var4.getShape((-1));
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var16 = var4.equals((java.lang.Object)var14);
    boolean var17 = var0.equals((java.lang.Object)var14);
    java.awt.Shape var19 = var0.getShape(1);
    java.awt.Shape var21 = var0.getShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test285"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(short)1);
    int var3 = var0.size();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setShape(0, var6);
    java.awt.Shape var9 = null;
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var12 = var10.getShape(0);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    var10.setShape(10, var15);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var9, var15);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 0.0d, 1.0f, 1.0f);
    var0.setShape(1, var15);
    org.jfree.chart.util.RectangleAnchor var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, var28, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test286"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     var0.clear();
//     java.awt.Shape var3 = var0.getShape(100);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 1.0f);
//     var0.setShape(10, var7);
//     org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
//     var9.clear();
//     java.awt.Shape var12 = var9.getShape(100);
//     int var13 = var9.size();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var9.setShape(0, var16);
//     boolean var18 = var0.equals((java.lang.Object)var16);
//     org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
//     boolean var21 = var19.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
//     var22.clear();
//     var22.clear();
//     boolean var25 = var19.equals((java.lang.Object)var22);
//     int var26 = var19.size();
//     java.awt.Shape var28 = var19.getShape(100);
//     java.awt.Shape var30 = var19.getShape(0);
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var33);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
//     boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var34, var38);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var42);
//     java.awt.Shape var44 = null;
//     boolean var45 = org.jfree.chart.util.ShapeUtilities.equal(var42, var44);
//     boolean var46 = org.jfree.chart.util.ShapeUtilities.equal(var38, var42);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
//     boolean var50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var38, (java.lang.Object)1.0f);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.clone(var38);
//     boolean var52 = var19.equals((java.lang.Object)var38);
//     java.lang.Object var53 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     org.jfree.chart.util.ShapeList var54 = new org.jfree.chart.util.ShapeList();
//     var54.clear();
//     var54.clear();
//     java.lang.Object var57 = var54.clone();
//     boolean var59 = var54.equals((java.lang.Object)100L);
//     java.lang.Object var60 = var54.clone();
//     var54.clear();
//     boolean var62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)var54);
//     boolean var63 = var0.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var9
//     assertTrue("Contract failed: equals-hashcode on var19 and var9", var19.equals(var9) ? var19.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var9
//     assertTrue("Contract failed: equals-hashcode on var22 and var9", var22.equals(var9) ? var22.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var0
//     assertTrue("Contract failed: equals-hashcode on var54 and var0", var54.equals(var0) ? var54.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var9
//     assertTrue("Contract failed: equals-hashcode on var54 and var9", var54.equals(var9) ? var54.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var9.", var19.equals(var9) == var9.equals(var19));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var0.", var22.equals(var0) == var0.equals(var22));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var9.", var22.equals(var9) == var9.equals(var22));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var0.", var54.equals(var0) == var0.equals(var54));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var9.", var54.equals(var9) == var9.equals(var54));
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test287"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 10.0d, 100.0d);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 1.0d, 100.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 0.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, (-1.0d), 100.0d);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var24, (-1.0d), 0.0f, 0.0f);
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var10, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test288"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var9 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = var9.getShape(0);
    java.lang.Object var12 = var9.clone();
    boolean var13 = var0.equals(var12);
    java.awt.Shape var14 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var14, var18);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 0.0d, (-1.0d));
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var36);
    boolean var38 = org.jfree.chart.util.ObjectUtilities.equal(var12, (java.lang.Object)var37);
    java.io.ObjectOutputStream var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var37, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test289"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 1.0d, 1.0f, 1.0f);
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test290"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)(-1.0f));
    java.awt.Shape var19 = null;
    var0.setShape(0, var19);
    int var21 = var0.size();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test291"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 1.0d, 100.0f, (-1.0f));
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var14);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 0.0d, (-1.0f), 10.0f);
    boolean var28 = org.jfree.chart.util.ShapeUtilities.equal(var4, var27);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var27, 0.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test292"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test293"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    var0.setShape(1, var6);
    java.lang.Object var8 = var0.clone();
    var0.clear();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test294"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var28 = null;
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var26, var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
    boolean var31 = org.jfree.chart.util.ShapeUtilities.equal(var0, var26);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 0.0d, 0.0d);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 0.0d, 10.0f, (-1.0f));
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.rotateShape(var40, 100.0d, 10.0f, 100.0f);
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)var44);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 100.0d, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test295"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 10.0f);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var0, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var28 = null;
    boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var26, var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var26, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 10.0d, 100.0f, 100.0f);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var13, var38);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, 0.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test296"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.rotateShape(var7, 1.0d, 100.0f, (-1.0f));
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    boolean var13 = var0.equals((java.lang.Object)var11);
    var0.clear();
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
    var0.setShape(101, var22);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, (-1.0d), 0.0d);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var30, var34);
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var26, var34);
    java.lang.Object var41 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var22, var26);
    java.io.ObjectOutputStream var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var22, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test297"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 1.0d, 10.0f, (-1.0f));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
    boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var9, var18);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 10.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test298"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    int var9 = var0.size();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, (-1.0d));
    var0.setShape(10, var15);
    java.awt.Shape var18 = var0.getShape((-1));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var22, 1.0d, 10.0f, 100.0f);
    var0.setShape(100, var22);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 100.0d, 10.0f, 100.0f);
    var0.setShape(11, var36);
    java.awt.Shape var38 = null;
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.clone(var41);
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var42, var46);
    boolean var48 = org.jfree.chart.util.ShapeUtilities.equal(var38, var42);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.rotateShape(var42, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var42, 0.0d, (-1.0d));
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.rotateShape(var42, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.clone(var42);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.clone(var60);
    boolean var62 = var0.equals((java.lang.Object)var61);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.clone(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test299"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.lang.Object var3 = var0.clone();
    boolean var5 = var0.equals((java.lang.Object)(byte)0);
    java.lang.Object var6 = var0.clone();
    java.awt.Shape var8 = var0.getShape((-1));
    var0.clear();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var15, 10.0d, 100.0f, 100.0f);
    var0.setShape(0, var15);
    org.jfree.chart.util.RectangleAnchor var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, var21, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test300"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var3);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var4, var8);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var0, var4);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, (-1.0f));
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, (-1.0d));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 100.0d, 0.0f, 100.0f);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    org.jfree.chart.util.RectangleAnchor var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, var24, 10.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test301"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 10.0d, 100.0d);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 1.0d, 100.0d);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.rotateShape(var16, 0.0d, 100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test302"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 100.0d, 100.0d);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 100.0d, 10.0f, 100.0f);
    org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
    var18.clear();
    var18.clear();
    java.awt.Shape var22 = var18.getShape(1);
    java.lang.Object var23 = var18.clone();
    int var24 = var18.size();
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var32);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var32, 1.0d, 0.0f, (-1.0f));
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    var18.setShape(0, var39);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var17, var39);
    boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var9, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test303"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    java.awt.Shape var8 = var3.getShape(0);
    boolean var10 = var3.equals((java.lang.Object)(byte)0);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var14 = var12.getShape(0);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var16 = var15.clone();
    boolean var17 = var12.equals(var16);
    java.awt.Shape var19 = var12.getShape((-1));
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var22);
    boolean var24 = var12.equals((java.lang.Object)var22);
    java.awt.Shape var26 = var12.getShape(0);
    var12.clear();
    var12.clear();
    boolean var29 = org.jfree.chart.util.ObjectUtilities.equal(var11, (java.lang.Object)var12);
    java.awt.Shape var31 = var12.getShape(101);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test304"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    int var7 = var0.size();
    java.lang.Object var8 = var0.clone();
    java.lang.Object var9 = var0.clone();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    var14.clear();
    var14.clear();
    java.lang.Object var17 = var14.clone();
    boolean var19 = var14.equals((java.lang.Object)(byte)0);
    java.awt.Shape var21 = var14.getShape((-1));
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
    boolean var25 = var14.equals((java.lang.Object)var23);
    boolean var26 = org.jfree.chart.util.ShapeUtilities.equal(var13, var23);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    boolean var29 = var0.equals((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test305"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 1.0d);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 1.0d, (-1.0f), (-1.0f));
    java.io.ObjectOutputStream var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test306"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    var3.clear();
    var3.clear();
    boolean var6 = var0.equals((java.lang.Object)var3);
    int var7 = var0.size();
    java.awt.Shape var9 = var0.getShape(100);
    java.awt.Shape var11 = var0.getShape(0);
    java.awt.Shape var13 = var0.getShape(0);
    var0.clear();
    java.lang.Object var15 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test307"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    var6.clear();
    var6.clear();
    java.lang.Object var9 = var6.clone();
    boolean var11 = var6.equals((java.lang.Object)(byte)0);
    java.awt.Shape var13 = var6.getShape((-1));
    boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var6);
    int var15 = var6.size();
    var6.clear();
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (-1.0f));
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    boolean var21 = var6.equals((java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test308"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var3 = var0.size();
    java.awt.Shape var5 = var0.getShape(0);
    java.awt.Shape var7 = var0.getShape(10);
    java.awt.Shape var9 = var0.getShape(100);
    java.lang.Object var10 = var0.clone();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    boolean var13 = var0.equals((java.lang.Object)0.0f);
    java.lang.Object var14 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test309"); }


    java.lang.Object var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    boolean var9 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 10.0d, (-1.0d));
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var10, 0.0d, (-1.0f), 1.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test310"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.awt.Shape var6 = var0.getShape(100);
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var9 = var0.getShape(0);
    int var10 = var0.size();
    var0.clear();
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    boolean var14 = var0.equals((java.lang.Object)100.0f);
    java.awt.Shape var16 = var0.getShape(10);
    java.awt.Shape var18 = var0.getShape(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test311"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    boolean var8 = var6.equals((java.lang.Object)(byte)10);
    java.lang.Object var9 = var6.clone();
    java.lang.Object var10 = var6.clone();
    java.lang.Object var11 = var6.clone();
    org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var14 = var12.getShape(0);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var16 = var15.clone();
    boolean var17 = var12.equals(var16);
    java.lang.Object var18 = var12.clone();
    boolean var19 = var6.equals(var18);
    boolean var20 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    boolean var23 = var21.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    var24.clear();
    var24.clear();
    boolean var27 = var21.equals((java.lang.Object)var24);
    java.awt.Shape var29 = var24.getShape(0);
    boolean var31 = var24.equals((java.lang.Object)(byte)0);
    java.lang.Object var32 = var24.clone();
    boolean var33 = var0.equals(var32);
    java.lang.Object var34 = null;
    boolean var35 = var0.equals(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test312"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(100);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.awt.Shape var6 = var0.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test313"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    boolean var12 = var0.equals((java.lang.Object)var10);
    var0.clear();
    java.lang.Object var14 = var0.clone();
    var0.clear();
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    var16.clear();
    var16.clear();
    java.lang.Object var19 = var16.clone();
    boolean var21 = var16.equals((java.lang.Object)(byte)0);
    java.lang.Object var22 = var16.clone();
    int var23 = var16.size();
    java.lang.Object var24 = var16.clone();
    java.lang.Object var25 = var16.clone();
    boolean var26 = var0.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test314"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 100.0d, 100.0d);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 0.0d, (-1.0f), 0.0f);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var16 = var14.getShape(0);
    org.jfree.chart.util.ShapeList var17 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var18 = var17.clone();
    boolean var19 = var14.equals(var18);
    java.lang.Object var20 = var14.clone();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var24 = var14.equals((java.lang.Object)var23);
    org.jfree.chart.util.ShapeList var25 = new org.jfree.chart.util.ShapeList();
    var25.clear();
    var25.clear();
    java.lang.Object var28 = var25.clone();
    boolean var29 = var14.equals((java.lang.Object)var25);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var33, (java.lang.Object)100.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    boolean var38 = var14.equals((java.lang.Object)var33);
    boolean var39 = org.jfree.chart.util.ShapeUtilities.equal(var9, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test315"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(short)1);
//     int var3 = var0.size();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var0.setShape(0, var6);
//     var0.clear();
//     java.lang.Object var9 = null;
//     boolean var10 = var0.equals(var9);
//     java.lang.Object var11 = var0.clone();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     var0.setShape(10, var15);
//     java.lang.Object var17 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var11 and var17
//     assertTrue("Contract failed: equals-hashcode on var11 and var17", var11.equals(var17) ? var11.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var17.", var11.equals(var17) == var17.equals(var11));
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test316"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.util.ShapeList var7 = new org.jfree.chart.util.ShapeList();
    boolean var9 = var7.equals((java.lang.Object)(byte)10);
    java.lang.Object var10 = var7.clone();
    java.lang.Object var11 = var7.clone();
    var7.clear();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var7);
    org.jfree.chart.util.RectangleAnchor var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var14, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test317"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, (-1.0d));
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var6, (-1.0d), 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test318"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    int var4 = var0.size();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var17);
    java.awt.Shape var19 = null;
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var17, var19);
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 10.0d, 10.0f, 100.0f);
    var0.setShape(1, var17);
    var0.clear();
    java.lang.Object var28 = var0.clone();
    int var29 = var0.size();
    java.awt.Shape var31 = var0.getShape(10);
    java.awt.Shape var33 = var0.getShape(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test319"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    org.jfree.chart.util.ShapeList var3 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var4 = var3.clone();
    boolean var5 = var0.equals(var4);
    java.awt.Shape var7 = var0.getShape((-1));
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var10 = var8.getShape(0);
    java.lang.Object var11 = var8.clone();
    java.awt.Shape var13 = var8.getShape(10);
    java.lang.Object var14 = var8.clone();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var17 = var8.equals((java.lang.Object)var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    boolean var24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)100.0f);
    boolean var25 = var8.equals((java.lang.Object)var24);
    int var26 = var8.size();
    boolean var27 = var0.equals((java.lang.Object)var26);
    org.jfree.chart.util.ShapeList var28 = new org.jfree.chart.util.ShapeList();
    var28.clear();
    var28.clear();
    java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var28);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var38);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.rotateShape(var38, 1.0d, 0.0f, (-1.0f));
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var28, (java.lang.Object)(-1.0f));
    java.lang.Object var46 = var28.clone();
    java.lang.Object var47 = var28.clone();
    boolean var48 = var0.equals((java.lang.Object)var28);
    java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 100.0f);
    boolean var52 = var28.equals((java.lang.Object)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test320"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(short)1);
    java.lang.Object var3 = var0.clone();
    var0.clear();
    java.awt.Shape var6 = var0.getShape(1);
    java.awt.Shape var8 = var0.getShape(0);
    java.lang.Object var9 = null;
    boolean var10 = var0.equals(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test321"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     var0.clear();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
//     var0.setShape(100, var7);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 100.0d, 0.0d);
//     org.jfree.chart.util.ShapeList var12 = new org.jfree.chart.util.ShapeList();
//     boolean var14 = var12.equals((java.lang.Object)(short)1);
//     int var15 = var12.size();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     var12.setShape(0, var18);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var18, (-1.0d), 0.0f, 10.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone(var23);
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var23);
//     org.jfree.chart.util.ShapeList var26 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var27 = var26.clone();
//     var26.clear();
//     var26.clear();
//     org.jfree.chart.util.ShapeList var30 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var32 = var30.getShape(0);
//     org.jfree.chart.util.ShapeList var33 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var34 = var33.clone();
//     boolean var35 = var30.equals(var34);
//     java.awt.Shape var37 = var30.getShape((-1));
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.clone(var40);
//     boolean var42 = var30.equals((java.lang.Object)var40);
//     boolean var43 = var26.equals((java.lang.Object)var40);
//     var26.clear();
//     int var45 = var26.size();
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var12
//     assertTrue("Contract failed: equals-hashcode on var26 and var12", var26.equals(var12) ? var26.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var12
//     assertTrue("Contract failed: equals-hashcode on var30 and var12", var30.equals(var12) ? var30.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var12
//     assertTrue("Contract failed: equals-hashcode on var33 and var12", var33.equals(var12) ? var33.hashCode() == var12.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var12.", var26.equals(var12) == var12.equals(var26));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var0.", var30.equals(var0) == var0.equals(var30));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var12.", var30.equals(var12) == var12.equals(var30));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var0.", var33.equals(var0) == var0.equals(var33));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var12.", var33.equals(var12) == var12.equals(var33));
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test322"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, (-1.0f));
    boolean var5 = org.jfree.chart.util.ShapeUtilities.equal(var1, var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.lang.Object var13 = var10.clone();
    boolean var15 = var10.equals((java.lang.Object)(byte)0);
    java.awt.Shape var17 = var10.getShape((-1));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    boolean var21 = var10.equals((java.lang.Object)var19);
    boolean var22 = org.jfree.chart.util.ShapeUtilities.equal(var9, var19);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 1.0f, (-1.0f));
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var4, var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var4, 0.0d, 100.0f, 1.0f);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test323"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    var0.clear();
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = var0.equals((java.lang.Object)var13);
    java.lang.Object var15 = var0.clone();
    org.jfree.chart.util.ShapeList var16 = new org.jfree.chart.util.ShapeList();
    boolean var18 = var16.equals((java.lang.Object)(byte)10);
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    var19.clear();
    var19.clear();
    boolean var22 = var16.equals((java.lang.Object)var19);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    boolean var25 = var23.equals((java.lang.Object)(byte)10);
    java.lang.Object var26 = var23.clone();
    java.lang.Object var27 = var23.clone();
    java.lang.Object var28 = var23.clone();
    org.jfree.chart.util.ShapeList var29 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var30 = var29.clone();
    java.lang.Object var31 = var29.clone();
    var29.clear();
    boolean var33 = var23.equals((java.lang.Object)var29);
    boolean var34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)var23);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    boolean var37 = var23.equals((java.lang.Object)0.0f);
    boolean var38 = var0.equals((java.lang.Object)var37);
    org.jfree.chart.util.ShapeList var39 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var41 = var39.getShape(0);
    org.jfree.chart.util.ShapeList var42 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var43 = var42.clone();
    boolean var44 = var39.equals(var43);
    java.awt.Shape var46 = var39.getShape((-1));
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, (-1.0d), 1.0d);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, 0.0d, (-1.0d));
    boolean var56 = var39.equals((java.lang.Object)(-1.0d));
    boolean var57 = var0.equals((java.lang.Object)(-1.0d));
    java.awt.Shape var59 = var0.getShape(2);
    java.lang.Object var60 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test324"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)' ');
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var8 = var0.clone();
    int var9 = var0.size();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 1.0d, 100.0f, (-1.0f));
    boolean var25 = org.jfree.chart.util.ShapeUtilities.equal(var17, var24);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 0.0d, (-1.0f), 10.0f);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var14, var37);
    boolean var39 = var0.equals((java.lang.Object)var14);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var42 = null;
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var45);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.clone(var49);
    boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var46, var50);
    boolean var52 = org.jfree.chart.util.ShapeUtilities.equal(var42, var46);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.rotateShape(var46, 100.0d, 0.0f, (-1.0f));
    boolean var57 = org.jfree.chart.util.ShapeUtilities.equal(var41, var56);
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var56, 100.0d, 100.0d);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.clone(var60);
    java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.clone(var60);
    java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 1.0d, 100.0f, 10.0f);
    java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var75, 0.0d, (-1.0d));
    boolean var79 = org.jfree.chart.util.ShapeUtilities.equal(var73, var78);
    boolean var80 = org.jfree.chart.util.ShapeUtilities.equal(var62, var73);
    java.awt.Shape var81 = org.jfree.chart.util.ShapeUtilities.clone(var62);
    boolean var82 = org.jfree.chart.util.ShapeUtilities.equal(var14, var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test325"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    boolean var6 = var0.equals((java.lang.Object)(-1));
    java.awt.Shape var8 = var0.getShape(0);
    int var9 = var0.size();
    org.jfree.chart.util.ShapeList var10 = new org.jfree.chart.util.ShapeList();
    var10.clear();
    var10.clear();
    java.lang.Object var13 = var10.clone();
    boolean var15 = var10.equals((java.lang.Object)(byte)0);
    var10.clear();
    var10.clear();
    java.lang.Object var18 = var10.clone();
    boolean var19 = var0.equals((java.lang.Object)var10);
    java.awt.Shape var21 = var10.getShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test326"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    java.awt.Shape var4 = var0.getShape(10);
    java.lang.Class var5 = null;
    java.lang.ClassLoader var6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var5);
    boolean var7 = var0.equals((java.lang.Object)var5);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var15);
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var12, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = null;
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var20, var22);
    boolean var24 = org.jfree.chart.util.ShapeUtilities.equal(var16, var20);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, 10.0f, 100.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, 10.0d, (-1.0f), 10.0f);
    var0.setShape(12, var20);
    org.jfree.chart.util.RectangleAnchor var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, var34, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test327"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    java.lang.Object var5 = var0.clone();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var7 = var6.clone();
    java.lang.Object var8 = var6.clone();
    var6.clear();
    boolean var10 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
    boolean var13 = var11.equals((java.lang.Object)(byte)10);
    java.lang.Object var14 = var11.clone();
    java.lang.Object var15 = var11.clone();
    java.lang.Object var16 = var11.clone();
    boolean var17 = var6.equals((java.lang.Object)var11);
    var11.clear();
    java.lang.Object var19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test328"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 1.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    java.awt.Shape var8 = null;
    boolean var9 = org.jfree.chart.util.ShapeUtilities.equal(var6, var8);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var8, 10.0d, (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test329"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone(var6);
    boolean var8 = org.jfree.chart.util.ShapeUtilities.equal(var3, var7);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    java.awt.Shape var13 = null;
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var11, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var7, var11);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)1.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var7);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, (-1.0d), 100.0d);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var28, 0.0d, (-1.0d));
    boolean var32 = org.jfree.chart.util.ShapeUtilities.equal(var26, var31);
    boolean var33 = org.jfree.chart.util.ShapeUtilities.equal(var24, var31);
    org.jfree.chart.util.RectangleAnchor var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, var34, (-1.0d), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test330"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 1.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 1.0d, 100.0f, (-1.0f));
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest4.test331"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     boolean var2 = var0.equals((java.lang.Object)(byte)10);
//     java.lang.Object var3 = var0.clone();
//     java.lang.Object var4 = var0.clone();
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var7 = var6.clone();
//     java.lang.Object var8 = var6.clone();
//     var6.clear();
//     boolean var10 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.util.ShapeList var11 = new org.jfree.chart.util.ShapeList();
//     boolean var13 = var11.equals((java.lang.Object)(byte)10);
//     java.lang.Object var14 = var11.clone();
//     java.lang.Object var15 = var11.clone();
//     java.lang.Object var16 = var11.clone();
//     boolean var17 = var6.equals((java.lang.Object)var11);
//     java.awt.Shape var19 = var11.getShape(1);
//     org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
//     var20.clear();
//     var20.clear();
//     java.awt.Shape var24 = var20.getShape(1);
//     boolean var26 = var20.equals((java.lang.Object)(-1));
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.clone(var30);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.clone(var34);
//     boolean var36 = org.jfree.chart.util.ShapeUtilities.equal(var31, var35);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
//     java.awt.Shape var41 = null;
//     boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var39, var41);
//     boolean var43 = org.jfree.chart.util.ShapeUtilities.equal(var35, var39);
//     var20.setShape(100, var35);
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, 100.0d, 0.0d);
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape(var47, 0.0d, 10.0f, 100.0f);
//     java.lang.Object var52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var51);
//     boolean var53 = var11.equals(var52);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var20
//     assertTrue("Contract failed: equals-hashcode on var11 and var20", var11.equals(var20) ? var11.hashCode() == var20.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var20.", var0.equals(var20) == var20.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var20.", var6.equals(var20) == var20.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var11 and var20.", var11.equals(var20) == var20.equals(var11));
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test332"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 100.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var5 = null;
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.clone(var12);
    boolean var14 = org.jfree.chart.util.ShapeUtilities.equal(var9, var13);
    boolean var15 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 0.0f, (-1.0f));
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var4, var19);
    org.jfree.chart.util.ShapeList var21 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var23 = var21.getShape(0);
    org.jfree.chart.util.ShapeList var24 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var25 = var24.clone();
    boolean var26 = var21.equals(var25);
    java.awt.Shape var28 = var21.getShape((-1));
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.clone(var31);
    boolean var33 = var21.equals((java.lang.Object)var31);
    java.awt.Shape var35 = var21.getShape(0);
    var21.clear();
    boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var20, (java.lang.Object)var21);
    boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0f, (java.lang.Object)var21);
    org.jfree.chart.util.ShapeList var39 = new org.jfree.chart.util.ShapeList();
    java.lang.Object var40 = var39.clone();
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var46, 1.0d, 100.0f, (-1.0f));
    boolean var51 = org.jfree.chart.util.ShapeUtilities.equal(var43, var50);
    boolean var52 = var39.equals((java.lang.Object)var50);
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.clone(var50);
    boolean var54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var21, (java.lang.Object)var50);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.clone(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test333"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    java.awt.Shape var3 = var0.getShape(100);
    java.awt.Shape var5 = var0.getShape((-1));
    var0.clear();
    int var7 = var0.size();
    java.lang.Object var8 = var0.clone();
    java.awt.Shape var10 = var0.getShape(101);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 100.0f);
    boolean var14 = var0.equals((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test334"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 100.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var3, 0.0d, (-1.0f), 100.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 100.0d, 10.0f, 10.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, (-1.0d), 0.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, 0.0d, 1.0d);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, (-1.0d), 10.0d);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var3, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test335"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    boolean var11 = org.jfree.chart.util.ShapeUtilities.equal(var6, var10);
    boolean var12 = org.jfree.chart.util.ShapeUtilities.equal(var2, var6);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var6, 100.0d, 0.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var1, var16);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 100.0d, 100.0d);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone(var20);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.rotateShape(var20, (-1.0d), 100.0f, 0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, (-1.0d), 10.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, (-1.0d), 1.0d);
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 1.0d, (-1.0f), (-1.0f));
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var26, var34);
    org.jfree.chart.util.RectangleAnchor var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, var43, 100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test336"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    var0.clear();
    var0.clear();
    java.awt.Shape var4 = var0.getShape(1);
    java.lang.Object var5 = var0.clone();
    int var6 = var0.size();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 1.0d, 100.0f, (-1.0f));
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var9, var16);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 1.0d, 10.0d);
    boolean var25 = var0.equals((java.lang.Object)var24);
    java.lang.Object var26 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test337"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test338"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape(10);
    int var6 = var0.size();
    java.lang.Object var7 = var0.clone();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.clone(var11);
    var0.setShape(100, var11);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 0.0d, 100.0d);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 1.0d, (-1.0d));
    org.jfree.chart.util.ShapeList var20 = new org.jfree.chart.util.ShapeList();
    var20.clear();
    var20.clear();
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    var20.setShape(1, var26);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var26);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var11, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test339"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    var4.clear();
    var4.clear();
    java.awt.Shape var8 = var4.getShape(1);
    boolean var10 = var4.equals((java.lang.Object)' ');
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone(var15);
    boolean var17 = var4.equals(var15);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 1.0d, 0.0d);
    boolean var24 = var4.equals((java.lang.Object)0.0d);
    java.lang.Object var25 = var4.clone();
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone(var28);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.clone(var32);
    boolean var34 = org.jfree.chart.util.ShapeUtilities.equal(var29, var33);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone(var37);
    java.awt.Shape var39 = null;
    boolean var40 = org.jfree.chart.util.ShapeUtilities.equal(var37, var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var33, var37);
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var33, (java.lang.Object)1.0f);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.clone(var33);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape(var46, 0.0d, 100.0f, 100.0f);
    boolean var51 = var4.equals((java.lang.Object)var46);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.clone(var46);
    boolean var53 = org.jfree.chart.util.ShapeUtilities.equal(var3, var52);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.clone(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest4.test340"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 1.0d, 100.0f, (-1.0f));
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var2, var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), (-1.0f), 0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, (-1.0d), 0.0f, (-1.0f));
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.clone(var2);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, (-1.0d), 0.0d);
    org.jfree.chart.util.ShapeList var23 = new org.jfree.chart.util.ShapeList();
    var23.clear();
    var23.clear();
    java.lang.Object var26 = var23.clone();
    boolean var28 = var23.equals((java.lang.Object)100L);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var32 = null;
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.clone(var35);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.clone(var39);
    boolean var41 = org.jfree.chart.util.ShapeUtilities.equal(var36, var40);
    boolean var42 = org.jfree.chart.util.ShapeUtilities.equal(var32, var36);
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape(var36, 100.0d, 0.0f, (-1.0f));
    boolean var47 = org.jfree.chart.util.ShapeUtilities.equal(var31, var46);
    var23.setShape(1, var46);
    java.awt.Shape var50 = var23.getShape(0);
    boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0d, (java.lang.Object)var23);
    var23.clear();
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, (-1.0d), 1.0f, 100.0f);
    var23.setShape(102, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

}
