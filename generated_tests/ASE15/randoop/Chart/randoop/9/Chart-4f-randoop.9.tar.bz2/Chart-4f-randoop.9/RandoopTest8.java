
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var4 = var3.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
    var2.setNoDataMessagePaint(var4);
    var2.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var10 = var2.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var12 = new org.jfree.chart.renderer.xy.XYItemRendererState(var11);
    boolean var13 = var12.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var14 = null;
    var12.setCrosshairState(var14);
    boolean var16 = var2.equals((java.lang.Object)var12);
    org.jfree.chart.axis.AxisLocation var18 = var2.getDomainAxisLocation(13);
    var0.setRangeAxisLocation(1, var18);
    int var20 = var0.getRangeAxisCount();
    java.lang.String var21 = var0.getPlotType();
    boolean var22 = var0.isRangeZeroBaselineVisible();
    boolean var23 = var0.isDomainZoomable();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var25 = var24.getLegendItems();
    org.jfree.chart.util.SortOrder var26 = var24.getColumnRenderingOrder();
    org.jfree.chart.axis.ValueAxis var28 = var24.getRangeAxisForDataset(0);
    org.jfree.chart.axis.LogAxis var30 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var31 = var30.getLabelInsets();
    double var33 = var31.calculateLeftInset(0.025d);
    var24.setInsets(var31, false);
    double var37 = var31.calculateBottomInset(Double.NaN);
    double var39 = var31.calculateTopOutset((-6.0d));
    var0.setAxisOffset(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Combined Range XYPlot"+ "'", var21.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 3.0d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var2 = var1.getLimit();
//     double var3 = var1.getLimit();
//     org.jfree.chart.JFreeChart var4 = var1.getPieChart();
//     org.jfree.data.category.CategoryDataset var5 = var1.getDataset();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getMiddleMillisecond();
//     java.util.Date var8 = var6.getStart();
//     java.util.Date var9 = var6.getEnd();
//     var1.setAggregatedItemsKey((java.lang.Comparable)var6);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.awt.Stroke var13 = var12.getMinorTickMarkStroke();
//     var12.setFixedDimension(1.0E-5d);
//     double var16 = var12.getUpperMargin();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.05d);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    int var9 = var0.indexOf((java.lang.Comparable)4.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.getYValue(13, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var1.markerChanged(var3);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var9 = var5.isItemLabelVisible(0, (-1), true);
    var5.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
    org.jfree.chart.axis.LogAxis var16 = new org.jfree.chart.axis.LogAxis("");
    var16.setAutoTickUnitSelection(true);
    var16.resizeRange(0.05d, (-1.0d));
    boolean var22 = var16.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, (org.jfree.chart.axis.ValueAxis)var16, var23);
    java.lang.String var25 = var24.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var28 = var27.getBaseItemLabelPaint();
    var26.setBaseFillPaint(var28);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var28);
    var24.setRadiusGridlinePaint(var28);
    var5.setSeriesPaint(100, var28, true);
    var1.setBaseSectionOutlinePaint(var28);
    java.awt.Paint var35 = var1.getLabelPaint();
    org.jfree.chart.labels.StandardPieToolTipGenerator var36 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    org.jfree.data.general.PieDataset var37 = null;
    java.lang.String var39 = var36.generateToolTip(var37, (java.lang.Comparable)10.0f);
    java.lang.Object var40 = var36.clone();
    var1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator)var36);
    org.jfree.chart.labels.PieToolTipGenerator var42 = var1.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Polar Plot"+ "'", var25.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var0, (org.jfree.data.Range)var1);
    double var3 = var0.getLength();
    java.util.Date var4 = var0.getUpperDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    var1.handleClick(10, 0, var5);
    java.awt.Paint var7 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.awt.Stroke var2 = null;
    var0.setStroke(7, var2);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var0);
//     var0.removeAllSeries();
//     double var3 = var0.getIntervalWidth();
//     double var5 = var0.getRangeUpperBound(false);
//     java.lang.Object var6 = var0.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Object var2 = null;
    boolean var3 = var0.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     var0.setBaseFillPaint(var2);
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(var2);
//     java.awt.Graphics2D var5 = null;
//     java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var9 = new org.jfree.chart.axis.SymbolAxis("hi!", var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     boolean var14 = var11.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var16 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var11.setTickUnit(var16, false, true);
//     var9.setTickUnit(var16, false, true);
//     org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var25 = var24.getChartArea();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.entity.PieSectionEntity var32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var25, var26, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var34 = var33.getLegendItems();
//     var33.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var36 = null;
//     int var37 = var33.indexOf(var36);
//     org.jfree.chart.util.RectangleEdge var38 = var33.getDomainAxisEdge();
//     boolean var39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var38);
//     double var40 = var9.valueToJava2D(0.05d, var25, var38);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var25, (-3.0d), 2.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer3D var45 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
//     var45.setSeriesToolTipGenerator(0, var47, true);
//     boolean var50 = var45.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var45.getPositiveItemLabelPositionFallback();
//     var45.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
//     org.jfree.chart.block.BlockContainer var55 = var54.getItemContainer();
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var57 = null;
//     java.util.TimeZone var58 = null;
//     org.jfree.data.time.TimeSeriesCollection var59 = new org.jfree.data.time.TimeSeriesCollection(var57, var58);
//     org.jfree.chart.title.LegendItemBlockContainer var61 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var56, (org.jfree.data.general.Dataset)var59, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("");
//     boolean var64 = var63.getNotify();
//     org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle("");
//     boolean var67 = var66.getNotify();
//     org.jfree.chart.renderer.xy.XYBarRenderer var68 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var69 = var68.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var70 = new org.jfree.chart.block.BlockBorder(var69);
//     var66.setFrame((org.jfree.chart.block.BlockFrame)var70);
//     var66.setURLText("");
//     var61.add((org.jfree.chart.block.Block)var63, (java.lang.Object)var66);
//     var54.setWrapper((org.jfree.chart.block.BlockContainer)var61);
//     org.jfree.chart.entity.TitleEntity var77 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var25, (org.jfree.chart.title.Title)var54, "null");
//     java.awt.Shape var80 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var25, (-6.0d), 9.223372036854776E18d);
//     var4.draw(var5, var25);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getRangeAxisCount();
    int var2 = var0.getWeight();
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    java.lang.String var4 = var3.getPlotType();
    double var5 = var3.getMinimumArcAngleToDraw();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
    org.jfree.chart.util.SortOrder var8 = var6.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var9 = var6.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var15 = var14.getBaseItemLabelPaint();
    var13.setBaseFillPaint(var15);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
    org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var15);
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var6.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var18, var19, false);
    float var22 = var18.getAlpha();
    double var23 = var18.getEndValue();
    org.jfree.chart.util.RectangleInsets var24 = var18.getLabelOffset();
    var3.setSimpleLabelOffset(var24);
    var0.setAxisOffset(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Pie 3D Plot"+ "'", var4.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     double var2 = var1.getMaxY();
//     double var3 = var1.getMaxY();
//     long var4 = var1.getMaximumItemAge();
//     var1.clear();
//     org.jfree.data.time.TimeSeries var6 = null;
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.TimeSeriesCollection var8 = new org.jfree.data.time.TimeSeriesCollection(var6, var7);
//     org.jfree.data.Range var10 = var8.getDomainBounds(true);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     long var12 = var11.getMiddleMillisecond();
//     java.util.Date var13 = var11.getEnd();
//     org.jfree.data.time.TimeSeries var14 = var8.getSeries((java.lang.Comparable)var11);
//     org.jfree.data.DefaultKeyedValues var15 = new org.jfree.data.DefaultKeyedValues();
//     var15.clear();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getLegendItems();
//     org.jfree.chart.util.SortOrder var19 = var17.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var20 = var17.getColumnRenderingOrder();
//     var15.sortByKeys(var20);
//     org.jfree.data.category.CategoryDataset var22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var11, (org.jfree.data.KeyedValues)var15);
//     long var23 = var11.getSerialIndex();
//     java.lang.Number var24 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    java.lang.String var3 = var1.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var11 = var10.getBaseItemLabelPaint();
    var9.setBaseFillPaint(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
    var4.setRangeGridlinePaint(var11);
    var4.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
    java.lang.Object var21 = null;
    boolean var22 = var20.equals(var21);
    var4.setAxisOffset(var20);
    var1.setLabelInsets(var20, true);
    org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
    double var27 = var26.getLimit();
    double var28 = var26.getLimit();
    org.jfree.chart.JFreeChart var29 = var26.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var29, 0, 0);
    org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
    var33.setSeriesToolTipGenerator(0, var35, true);
    boolean var38 = var33.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var39 = var33.getPositiveItemLabelPositionFallback();
    var33.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("");
    boolean var45 = var44.getNotify();
    org.jfree.chart.util.HorizontalAlignment var46 = var44.getHorizontalAlignment();
    java.lang.String var47 = var46.toString();
    var42.setHorizontalAlignment(var46);
    var29.removeSubtitle((org.jfree.chart.title.Title)var42);
    org.jfree.chart.block.BlockFrame var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var42.setFrame(var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var47.equals("HorizontalAlignment.CENTER"));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var29 = var25.getDomainAxis(255);
    var25.setRangeCrosshairVisible(true);
    java.awt.Stroke var32 = var25.getDomainZeroBaselineStroke();
    boolean var33 = var25.isDomainCrosshairLockedOnData();
    org.jfree.chart.util.RectangleEdge var34 = var25.getRangeAxisEdge();
    org.jfree.chart.annotations.XYAnnotation var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var36 = var25.removeAnnotation(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var2);
//     boolean var4 = var3.isAutoWidth();
//     boolean var5 = var3.isAutoWidth();
//     double var7 = var3.getDomainLowerBound(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.util.LogFormat var2 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
    var8.setBaseNegativeItemLabelPosition(var16);
    boolean var18 = var7.equals((java.lang.Object)var8);
    java.text.NumberFormat var19 = var7.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var2, var19);
    var19.setMaximumIntegerDigits(2147483647);
    java.text.NumberFormat var24 = java.text.NumberFormat.getIntegerInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var25 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var26 = var25.getXFormat();
    java.math.RoundingMode var27 = var26.getRoundingMode();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var24, var26);
    java.lang.String var30 = var26.format(0.05d);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("HorizontalAlignment.CENTER", var19, var26);
    java.lang.Object var32 = var31.clone();
    org.jfree.chart.axis.SegmentedTimeline var33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var34 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var35 = var34.getSegmentsIncludedSize();
    var33.setBaseTimeline(var34);
    long var37 = var33.getSegmentsGroupSize();
    var33.setAdjustForDaylightSaving(true);
    boolean var40 = var31.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "0.05"+ "'", var30.equals("0.05"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 25200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var4 = var3.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
    java.lang.String var6 = var5.getToolTipText();
    var5.setToolTipText("");
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    org.jfree.chart.entity.PlotEntity var13 = new org.jfree.chart.entity.PlotEntity(var10, (org.jfree.chart.plot.Plot)var12);
    boolean var14 = var5.equals((java.lang.Object)var10);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.clone(var10);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("");
    boolean var18 = var17.getNotify();
    java.lang.String var19 = var17.getURLText();
    int var20 = var17.getMaximumLinesToDisplay();
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
    var22.setExpandToFitSpace(false);
    boolean var25 = var17.equals((java.lang.Object)var22);
    org.jfree.chart.entity.TitleEntity var27 = new org.jfree.chart.entity.TitleEntity(var15, (org.jfree.chart.title.Title)var22, "hi!");
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    var28.setSeriesToolTipGenerator(0, var30, true);
    org.jfree.chart.urls.CategoryURLGenerator var36 = var28.getURLGenerator((-1), 0, true);
    org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.LegendItemSource var38 = null;
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle(var38);
    org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var42 = var41.getTickLabelFont();
    var37.add((org.jfree.chart.block.Block)var39, (java.lang.Object)var41);
    org.jfree.chart.util.HorizontalAlignment var44 = null;
    org.jfree.chart.util.VerticalAlignment var45 = null;
    org.jfree.chart.block.FlowArrangement var48 = new org.jfree.chart.block.FlowArrangement(var44, var45, 1.0d, 0.05d);
    org.jfree.chart.axis.SegmentedTimeline var49 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var50 = var49.clone();
    org.jfree.chart.axis.AxisState var52 = new org.jfree.chart.axis.AxisState(100.0d);
    var52.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var56 = var55.getLegendItems();
    org.jfree.chart.util.SortOrder var57 = var55.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var58 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var59 = var58.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var64 = var60.isItemLabelVisible(0, (-1), true);
    boolean var65 = var59.equals((java.lang.Object)var60);
    org.jfree.chart.renderer.xy.XYBarRenderer var66 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var67 = var66.getBaseStroke();
    var60.setBaseStroke(var67, false);
    var55.setRangeCrosshairStroke(var67);
    org.jfree.chart.axis.CategoryAxis3D var72 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var73 = var55.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var72);
    var52.setTicks(var73);
    var49.addExceptions(var73);
    boolean var76 = var48.equals((java.lang.Object)var73);
    org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var48);
    org.jfree.chart.block.BlockBorder var78 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var79 = var78.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var80 = new org.jfree.chart.plot.MultiplePiePlot();
    double var81 = var80.getLimit();
    double var82 = var80.getLimit();
    org.jfree.chart.JFreeChart var83 = var80.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var86 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var78, var83, (-1), 1);
    java.lang.Object var87 = var83.clone();
    boolean var88 = var83.isNotify();
    org.jfree.chart.title.LegendTitle var89 = var83.getLegend();
    var83.removeLegend();
    java.awt.Paint var91 = null;
    var83.setBorderPaint(var91);
    boolean var93 = var37.equals((java.lang.Object)var83);
    var22.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var83);
    org.jfree.chart.event.ChartProgressListener var95 = null;
    var83.addProgressListener(var95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var99 = new org.jfree.chart.entity.JFreeChartEntity(var0, var83, "black", "SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    var0.setLimit(1.0d);
    org.jfree.chart.util.TableOrder var5 = var0.getDataExtractOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.Size2D var1 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
//     org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var7 = var4.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var13 = var12.getBaseItemLabelPaint();
//     var11.setBaseFillPaint(var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(var13);
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var13);
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var19 = var4.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var16, var17, false);
//     float var20 = var16.getAlpha();
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var24 = var23.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!", var24);
//     org.jfree.chart.util.RectangleAnchor var26 = var25.getTextAnchor();
//     var16.setLabelAnchor(var26);
//     java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var1, 1.0d, 0.47712125471966244d, var26);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var28, 0.5d, 10.0f, 1.0f);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((-3.0d), 0.05d);
    double var3 = var2.getXValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-3.0d));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    var3.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.setVerticalTickLabels(false);
    var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8, true);
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.event.MarkerChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var3.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var21, var24);
    org.jfree.chart.text.TextAnchor var26 = var21.getLabelTextAnchor();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
    java.lang.Object var29 = null;
    boolean var30 = var28.equals(var29);
    org.jfree.chart.text.TextAnchor var31 = var28.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "", var26, var31, 10.0d);
    java.lang.String var34 = var33.toString();
    java.lang.String var35 = var33.getText();
    double var36 = var33.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + ""+ "'", var35.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 10.0d);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var2 = var0.getShape((-16777216));
//     org.jfree.data.time.TimeSeries var3 = null;
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
//     org.jfree.data.Range var7 = var5.getDomainBounds(true);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     long var9 = var8.getMiddleMillisecond();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.TimeSeries var11 = var5.getSeries((java.lang.Comparable)var8);
//     org.jfree.data.DefaultKeyedValues var12 = new org.jfree.data.DefaultKeyedValues();
//     var12.clear();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getLegendItems();
//     org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var17 = var14.getColumnRenderingOrder();
//     var12.sortByKeys(var17);
//     org.jfree.data.category.CategoryDataset var19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var8, (org.jfree.data.KeyedValues)var12);
//     org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var19, false);
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var19, 90.0d);
//     org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var19, 255);
//     org.jfree.data.general.PieDataset var27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var19, (java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     org.jfree.data.general.DefaultPieDataset var29 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var27);
//     int var30 = var29.getItemCount();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var33 = var32.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(var33);
//     var31.setNoDataMessagePaint(var33);
//     var31.setRangeZeroBaselineVisible(true);
//     var31.setCrosshairDatasetIndex(100);
//     org.jfree.chart.util.SortOrder var40 = var31.getRowRenderingOrder();
//     var29.sortByKeys(var40);
//     double var42 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset)var29);
//     boolean var43 = var0.equals((java.lang.Object)var29);
//     org.jfree.data.time.TimeSeries var44 = null;
//     java.util.TimeZone var45 = null;
//     org.jfree.data.time.TimeSeriesCollection var46 = new org.jfree.data.time.TimeSeriesCollection(var44, var45);
//     org.jfree.data.Range var48 = var46.getDomainBounds(true);
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     long var50 = var49.getMiddleMillisecond();
//     java.util.Date var51 = var49.getEnd();
//     org.jfree.data.time.TimeSeries var52 = var46.getSeries((java.lang.Comparable)var49);
//     org.jfree.data.DefaultKeyedValues var53 = new org.jfree.data.DefaultKeyedValues();
//     var53.clear();
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var56 = var55.getLegendItems();
//     org.jfree.chart.util.SortOrder var57 = var55.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var58 = var55.getColumnRenderingOrder();
//     var53.sortByKeys(var58);
//     org.jfree.data.category.CategoryDataset var60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var49, (org.jfree.data.KeyedValues)var53);
//     org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var60, false);
//     org.jfree.data.Range var64 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var60, 90.0d);
//     org.jfree.data.general.PieDataset var66 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var60, 255);
//     org.jfree.data.general.PieDataset var68 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var60, (java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot(var68);
//     org.jfree.data.general.DefaultPieDataset var70 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var68);
//     int var71 = var70.getItemCount();
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var73 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var74 = var73.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var75 = new org.jfree.chart.block.BlockBorder(var74);
//     var72.setNoDataMessagePaint(var74);
//     var72.setRangeZeroBaselineVisible(true);
//     var72.setCrosshairDatasetIndex(100);
//     org.jfree.chart.util.SortOrder var81 = var72.getRowRenderingOrder();
//     var70.sortByKeys(var81);
//     var29.sortByKeys(var81);
//     
//     // Checks the contract:  equals-hashcode on var5 and var46
//     assertTrue("Contract failed: equals-hashcode on var5 and var46", var5.equals(var46) ? var5.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var5
//     assertTrue("Contract failed: equals-hashcode on var46 and var5", var46.equals(var5) ? var46.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var55
//     assertTrue("Contract failed: equals-hashcode on var14 and var55", var14.equals(var55) ? var14.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var72
//     assertTrue("Contract failed: equals-hashcode on var31 and var72", var31.equals(var72) ? var31.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var14
//     assertTrue("Contract failed: equals-hashcode on var55 and var14", var55.equals(var14) ? var55.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var31
//     assertTrue("Contract failed: equals-hashcode on var72 and var31", var72.equals(var31) ? var72.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var56
//     assertTrue("Contract failed: equals-hashcode on var15 and var56", var15.equals(var56) ? var15.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var15
//     assertTrue("Contract failed: equals-hashcode on var56 and var15", var56.equals(var15) ? var56.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var69
//     assertTrue("Contract failed: equals-hashcode on var28 and var69", var28.equals(var69) ? var28.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var28
//     assertTrue("Contract failed: equals-hashcode on var69 and var28", var69.equals(var28) ? var69.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var75
//     assertTrue("Contract failed: equals-hashcode on var34 and var75", var34.equals(var75) ? var34.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var34
//     assertTrue("Contract failed: equals-hashcode on var75 and var34", var75.equals(var34) ? var75.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var2);
    boolean var4 = var3.isAutoWidth();
    boolean var5 = var3.isAutoWidth();
    org.jfree.data.Range var7 = var3.getDomainBounds(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    var0.setSeriesPaint(100, var23, true);
    java.awt.Shape var30 = var0.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var31.setSeriesToolTipGenerator(0, var33, true);
    boolean var36 = var31.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    var31.setPositiveItemLabelPositionFallback(var40);
    java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
    org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var52 = var51.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
    boolean var54 = var50.equals((java.lang.Object)var53);
    boolean var55 = var50.isShapeFilled();
    org.jfree.chart.util.GradientPaintTransformer var56 = var50.getFillPaintTransformer();
    java.awt.Stroke var57 = var50.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    var0.setPositiveItemLabelPositionFallback(var9);
    var0.setMinimumBarLength(0.14d);
    double var19 = var0.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var2 = var1.getLabelAngle();
//     float var3 = var1.getMaximumCategoryLabelWidthRatio();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var5, (org.jfree.chart.plot.Plot)var7);
//     var1.setPlot((org.jfree.chart.plot.Plot)var7);
//     org.jfree.data.time.TimeSeries var10 = null;
//     org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var10);
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     var13.setAutoTickUnitSelection(true);
//     var13.resizeRange(0.05d, (-1.0d));
//     boolean var19 = var13.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var11, (org.jfree.chart.axis.ValueAxis)var13, var20);
//     org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var13.setTickUnit(var23, false, false);
//     java.awt.Paint var27 = var1.getTickLabelPaint((java.lang.Comparable)false);
//     org.jfree.chart.axis.LogAxis var29 = new org.jfree.chart.axis.LogAxis("");
//     var29.setAutoTickUnitSelection(true);
//     boolean var32 = var29.isAutoTickUnitSelection();
//     var29.resizeRange(0.05d);
//     java.awt.Font var35 = var29.getLabelFont();
//     boolean var36 = var29.isPositiveArrowVisible();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     double var39 = var38.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     var38.handleClick(10, 0, var42);
//     java.awt.Paint var44 = var38.getShadowPaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var47 = var46.getBaseItemLabelPaint();
//     var45.setBaseFillPaint(var47);
//     org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder(var47);
//     var38.setLabelBackgroundPaint(var47);
//     var29.setTickLabelPaint(var47);
//     boolean var52 = var1.equals((java.lang.Object)var47);
//     org.jfree.chart.plot.CombinedRangeXYPlot var53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var56 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var57 = var56.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var58 = new org.jfree.chart.block.BlockBorder(var57);
//     var55.setNoDataMessagePaint(var57);
//     var55.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var63 = var55.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var65 = new org.jfree.chart.renderer.xy.XYItemRendererState(var64);
//     boolean var66 = var65.getProcessVisibleItemsOnly();
//     org.jfree.chart.plot.XYCrosshairState var67 = null;
//     var65.setCrosshairState(var67);
//     boolean var69 = var55.equals((java.lang.Object)var65);
//     org.jfree.chart.axis.AxisLocation var71 = var55.getDomainAxisLocation(13);
//     var53.setRangeAxisLocation(1, var71);
//     int var73 = var53.getRangeAxisCount();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var74 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var75 = var74.getBaseNegativeItemLabelPosition();
//     var74.setShapesFilled(false);
//     boolean var78 = var74.getShapesVisible();
//     java.awt.Paint var79 = var74.getBaseLegendTextPaint();
//     var53.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var74);
//     java.util.List var81 = var53.getSubplots();
//     boolean var82 = var1.equals((java.lang.Object)var81);
//     
//     // Checks the contract:  equals-hashcode on var49 and var58
//     assertTrue("Contract failed: equals-hashcode on var49 and var58", var49.equals(var58) ? var49.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var49
//     assertTrue("Contract failed: equals-hashcode on var58 and var49", var58.equals(var49) ? var58.hashCode() == var49.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-9782341200000L), (java.lang.Number)(-3.0d));
    double var3 = var2.getXValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-9.7823412E12d));

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 3.0d);
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.chart.axis.LogAxis var6 = new org.jfree.chart.axis.LogAxis("");
    var6.setAutoTickUnitSelection(true);
    var6.resizeRange(0.05d, (-1.0d));
    boolean var12 = var6.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var4, (org.jfree.chart.axis.ValueAxis)var6, var13);
    java.lang.String var15 = var14.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var18 = var17.getBaseItemLabelPaint();
    var16.setBaseFillPaint(var18);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(var18);
    var14.setRadiusGridlinePaint(var18);
    int var22 = var2.compareTo((java.lang.Object)var14);
    boolean var23 = var14.isRadiusGridlinesVisible();
    java.awt.Stroke var24 = var14.getRadiusGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Polar Plot"+ "'", var15.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var0);
    var0.clearSelection();
    java.lang.Object var3 = var0.clone();
    org.jfree.data.xy.IntervalXYDelegate var4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    org.jfree.chart.entity.PlotEntity var5 = new org.jfree.chart.entity.PlotEntity(var2, (org.jfree.chart.plot.Plot)var4);
    double var6 = var4.getLabelGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var7 = var4.getLabelGenerator();
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var11 = var10.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    var4.handleClick((-1), 100, var12);
    int var14 = var4.getBackgroundImageAlignment();
    java.awt.Paint var15 = var4.getLabelShadowPaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("[size=100]", var15);
    java.lang.String var17 = var16.getLabel();
    var16.setSeriesIndex(10);
    java.awt.Paint var20 = var16.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "[size=100]"+ "'", var17.equals("[size=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
//     boolean var3 = var2.isEmpty();
//     double var4 = var2.getMinX();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     int var3 = var1.indexOf((java.lang.Comparable)86400000L);
//     double var5 = var1.getDomainLowerBound(false);
//     org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState(100.0d);
//     var9.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = var12.getLegendItems();
//     org.jfree.chart.util.SortOrder var14 = var12.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var21 = var17.isItemLabelVisible(0, (-1), true);
//     boolean var22 = var16.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var24 = var23.getBaseStroke();
//     var17.setBaseStroke(var24, false);
//     var12.setRangeCrosshairStroke(var24);
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var30 = var12.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var29);
//     var9.setTicks(var30);
//     var6.addExceptions(var30);
//     org.jfree.data.Range var34 = var1.getDomainBounds(var30, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var37 = var1.getXValue(0, 2);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.chart.util.LogFormat var1 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var6 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var11 = var7.getURLGenerator(100, (-1), false);
    java.awt.Paint var13 = var7.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var15 = var14.getBaseNegativeItemLabelPosition();
    var7.setBaseNegativeItemLabelPosition(var15);
    boolean var17 = var6.equals((java.lang.Object)var7);
    java.text.NumberFormat var18 = var6.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var1, var18);
    int var20 = var1.getMinimumIntegerDigits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var0.setShadowXOffset((-1.0d));
    var0.setDrawBarOutline(false);
    java.awt.Stroke var6 = var0.lookupSeriesStroke(0);
    var0.setShadowXOffset(Double.NEGATIVE_INFINITY);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var9.setShadowXOffset((-1.0d));
    var9.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var9.getSeriesNegativeItemLabelPosition(0);
    var0.setNegativeItemLabelPositionFallback(var15);
    boolean var18 = var0.equals((java.lang.Object)10L);
    var0.setBase(4.0d);
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var24 = var23.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("hi!", var24);
    var0.setBaseItemLabelFont(var24, false);
    var0.setAutoPopulateSeriesStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var3, false);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    double var11 = var10.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    var10.handleClick(10, 0, var14);
    java.awt.Paint var16 = var10.getShadowPaint();
    java.awt.Paint[] var17 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var19 = var18.getBaseItemLabelPaint();
    java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    java.awt.Paint[] var25 = new java.awt.Paint[] { var23};
    java.awt.Stroke var26 = null;
    java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Shape var30 = null;
    java.awt.Shape[] var31 = new java.awt.Shape[] { var30};
    org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var20, var25, var27, var29, var31);
    java.awt.Shape var33 = var32.getNextShape();
    var10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var32);
    var10.setCircular(true);
    boolean var37 = var10.getAutoPopulateSectionOutlineStroke();
    boolean var38 = var10.isCircular();
    var3.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    org.jfree.chart.plot.AbstractPieLabelDistributor var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setLabelDistributor(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(8.0d, 0.025000000000000022d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    boolean var8 = var5.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var5.setTickUnit(var10, false, true);
    var3.setTickUnit(var10, false, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(100, (-1), false);
    java.awt.Paint var27 = var21.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var28 = null;
    var21.setLegendItemToolTipGenerator(var28);
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var34 = var33.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("", var34);
    var21.setSeriesItemLabelFont(1, var34, false);
    org.jfree.chart.axis.MarkerAxisBand var38 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var3, Double.NaN, 3.0d, 0.08d, 4.0d, var34);
    int var39 = var3.getMinorTickCount();
    org.jfree.chart.ChartRenderingInfo var41 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var42 = var41.getChartArea();
    org.jfree.chart.util.RectangleEdge var43 = null;
    double var44 = var3.java2DToValue((-1.0d), var42, var43);
    java.awt.Shape var45 = var3.getUpArrow();
    java.awt.Paint var46 = var3.getGridBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    double var5 = var3.getLabelGap();
    double var6 = var3.getLabelGap();
    boolean var7 = var3.isCircular();
    java.awt.Font var8 = var3.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     org.jfree.chart.entity.LegendItemEntity var51 = new org.jfree.chart.entity.LegendItemEntity(var30);
//     java.lang.Object var52 = var51.clone();
//     java.lang.String var53 = var51.toString();
//     org.jfree.data.xy.DefaultXYDataset var54 = new org.jfree.data.xy.DefaultXYDataset();
//     int var55 = var54.getSeriesCount();
//     org.jfree.chart.axis.SegmentedTimeline var56 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var57 = var56.clone();
//     org.jfree.chart.axis.AxisState var59 = new org.jfree.chart.axis.AxisState(100.0d);
//     var59.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var63 = var62.getLegendItems();
//     org.jfree.chart.util.SortOrder var64 = var62.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var65 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var66 = var65.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var67 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var71 = var67.isItemLabelVisible(0, (-1), true);
//     boolean var72 = var66.equals((java.lang.Object)var67);
//     org.jfree.chart.renderer.xy.XYBarRenderer var73 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var74 = var73.getBaseStroke();
//     var67.setBaseStroke(var74, false);
//     var62.setRangeCrosshairStroke(var74);
//     org.jfree.chart.axis.CategoryAxis3D var79 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var80 = var62.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var79);
//     var59.setTicks(var80);
//     var56.addExceptions(var80);
//     org.jfree.data.time.DateRange var83 = new org.jfree.data.time.DateRange();
//     org.jfree.data.Range var85 = org.jfree.data.Range.shift((org.jfree.data.Range)var83, 10.0d);
//     org.jfree.data.Range var87 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var54, var80, var85, false);
//     var51.setDataset((org.jfree.data.general.Dataset)var54);
//     
//     // Checks the contract:  equals-hashcode on var40 and var66
//     assertTrue("Contract failed: equals-hashcode on var40 and var66", var40.equals(var66) ? var40.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var40
//     assertTrue("Contract failed: equals-hashcode on var66 and var40", var66.equals(var40) ? var66.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    int var7 = var6.getMaximumLinesToDisplay();
    java.awt.Paint var8 = var6.getPaint();
    var0.setBaseItemLabelPaint(var8);
    java.awt.Shape var11 = var0.lookupSeriesShape(0);
    org.jfree.chart.event.RendererChangeEvent var12 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var0);
    org.jfree.chart.plot.XYPlot var13 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(5);
//     org.jfree.data.xy.DefaultXYDataset var4 = new org.jfree.data.xy.DefaultXYDataset();
//     int var5 = var4.getSeriesCount();
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var6, (org.jfree.data.Range)var7);
//     boolean var9 = var4.equals((java.lang.Object)var6);
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var10, (org.jfree.data.Range)var11);
//     org.jfree.chart.block.LengthConstraintType var13 = var12.getWidthConstraintType();
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var16, (org.jfree.data.Range)var17);
//     org.jfree.chart.block.LengthConstraintType var19 = var18.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var6, var13, 0.0d, (org.jfree.data.Range)var15, var19);
//     org.jfree.data.xy.DefaultXYDataset var21 = new org.jfree.data.xy.DefaultXYDataset();
//     int var22 = var21.getSeriesCount();
//     org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var23, (org.jfree.data.Range)var24);
//     boolean var26 = var21.equals((java.lang.Object)var23);
//     boolean var27 = var15.intersects((org.jfree.data.Range)var23);
//     java.util.Date var28 = var15.getLowerDate();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var34 = var33.getAlpha();
//     int var35 = var33.getTransparency();
//     boolean var36 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
//     java.awt.Paint var43 = var37.getSeriesFillPaint(100);
//     java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
//     var29.setAxisLineStroke(var45);
//     java.util.TimeZone var47 = var29.getTimeZone();
//     org.jfree.chart.axis.TickUnitSource var48 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var47);
//     org.jfree.data.time.TimeSeriesCollection var49 = new org.jfree.data.time.TimeSeriesCollection(var47);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(var28, var47);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, var51);
//     var51.setDescription("java.awt.Color[r=0,g=0,b=100]");
//     boolean var55 = var1.isOnOrBefore(var51);
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month();
//     long var57 = var56.getMiddleMillisecond();
//     java.util.Date var58 = var56.getStart();
//     java.util.Date var59 = var56.getEnd();
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year(var59);
//     org.jfree.data.time.RegularTimePeriod var61 = var60.previous();
//     java.util.Date var62 = var60.getStart();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     int var64 = var1.compare(var63);
//     org.jfree.data.time.SpreadsheetDate var66 = new org.jfree.data.time.SpreadsheetDate(5);
//     java.util.Date var67 = var66.toDate();
//     boolean var68 = var1.isAfter((org.jfree.data.time.SerialDate)var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-41635));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    var0.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var11 = var10.getChartArea();
    var0.setBaseShape((java.awt.Shape)var11);
    org.jfree.data.general.PieDataset var13 = null;
    java.lang.Comparable var16 = null;
    org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var11, var13, 100, 2147483647, var16, "", "Polar Plot");
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var23 = var22.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("", var23);
    java.lang.String var25 = var24.getToolTipText();
    var24.setToolTipText("");
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    boolean var33 = var24.equals((java.lang.Object)var29);
    org.jfree.chart.axis.LogAxis var35 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var36 = var35.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var39 = new org.jfree.chart.entity.AxisEntity(var29, (org.jfree.chart.axis.Axis)var35, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var41 = var40.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var42 = new org.jfree.chart.plot.MultiplePiePlot();
    double var43 = var42.getLimit();
    double var44 = var42.getLimit();
    org.jfree.chart.JFreeChart var45 = var42.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var48 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var40, var45, (-1), 1);
    boolean var49 = var39.equals((java.lang.Object)var45);
    org.jfree.chart.entity.JFreeChartEntity var51 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var11, var45, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.event.RendererChangeEvent var52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var45);
    java.lang.Object var53 = var52.getRenderer();
    boolean var54 = var52.getSeriesVisibilityChanged();
    boolean var55 = var52.getSeriesVisibilityChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelInsets();
    double var5 = var3.calculateLeftInset(0.025d);
    double var6 = var3.getRight();
    var0.setAxisOffset(var3);
    org.jfree.chart.axis.AxisSpace var8 = new org.jfree.chart.axis.AxisSpace();
    double var9 = var8.getLeft();
    var0.setFixedRangeAxisSpace(var8, true);
    java.lang.String var12 = var8.toString();
    double var13 = var8.getLeft();
    var8.setLeft(6.0d);
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var19 = var18.getDataArea();
    java.lang.String[] var22 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
    org.jfree.chart.axis.LogAxis var25 = new org.jfree.chart.axis.LogAxis("");
    var25.setAutoTickUnitSelection(true);
    boolean var28 = var25.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var25.setTickUnit(var30, false, true);
    var23.setTickUnit(var30, false, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var45 = var41.getURLGenerator(100, (-1), false);
    java.awt.Paint var47 = var41.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var48 = null;
    var41.setLegendItemToolTipGenerator(var48);
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var54 = var53.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("", var54);
    var41.setSeriesItemLabelFont(1, var54, false);
    org.jfree.chart.axis.MarkerAxisBand var58 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var23, Double.NaN, 3.0d, 0.08d, 4.0d, var54);
    int var59 = var23.getMinorTickCount();
    org.jfree.chart.ChartRenderingInfo var61 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var62 = var61.getChartArea();
    org.jfree.chart.util.RectangleEdge var63 = null;
    double var64 = var23.java2DToValue((-1.0d), var62, var63);
    java.awt.geom.Rectangle2D var65 = var8.shrink(var19, var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    int var3 = var1.indexOf((java.lang.Comparable)86400000L);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    var5.resizeRange(0.05d, (-1.0d));
    var5.configure();
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var5, var12);
    boolean var14 = var13.isDomainZoomable();
    org.jfree.chart.renderer.PolarItemRenderer var15 = var13.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleAnchor var9 = null;
    java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
    var3.zoomRangeAxes(0.05d, var7, var10, false);
    var0.zoomDomainAxes(0.08d, var2, var10, false);
    var0.setAngleGridlinesVisible(false);
    org.jfree.chart.renderer.PolarItemRenderer var17 = var0.getRenderer();
    java.awt.Paint var18 = var0.getAngleGridlinePaint();
    java.lang.Object var19 = null;
    boolean var20 = var0.equals(var19);
    java.awt.Paint var21 = var0.getAngleGridlinePaint();
    java.lang.String var22 = var0.getPlotType();
    org.jfree.data.time.TimeSeries var23 = null;
    java.util.TimeZone var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
    org.jfree.data.Range var27 = var25.getDomainBounds(true);
    org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var25);
    var25.clearSelection();
    var0.setDataset((org.jfree.data.xy.XYDataset)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Polar Plot"+ "'", var22.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    var0.setWeight((-16777216));
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getDomainMarkers(var8);
    org.jfree.chart.axis.AxisLocation var10 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var11 = var10.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    java.awt.Paint var27 = var19.getRadiusGridlinePaint();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var37 = var36.getBaseItemLabelPaint();
    var35.setBaseFillPaint(var37);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var35.setBaseStroke(var48);
    var34.setAxisLineStroke(var48);
    var31.setLabelOutlineStroke(var48);
    java.awt.Paint var54 = var31.getLabelOutlinePaint();
    boolean var55 = org.jfree.chart.util.PaintUtilities.equal(var27, var54);
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var54);
    var1.setSubtitlePaint(var54);
    java.awt.Paint var58 = var1.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var60 = var59.getLegendItems();
    var59.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var59.rendererChanged(var62);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var59.markerChanged(var64);
    java.awt.Paint var66 = var59.getRangeCrosshairPaint();
    var1.setChartBackgroundPaint(var66);
    java.awt.Paint var68 = var1.getSubtitlePaint();
    org.jfree.chart.plot.MultiplePiePlot var69 = new org.jfree.chart.plot.MultiplePiePlot();
    double var70 = var69.getLimit();
    double var71 = var69.getLimit();
    org.jfree.chart.JFreeChart var72 = var69.getPieChart();
    java.util.List var73 = var72.getSubtitles();
    var72.setAntiAlias(false);
    var72.setBorderVisible(true);
    var1.apply(var72);
    org.jfree.chart.renderer.category.BarPainter var79 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBarPainter(var79);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
    var0.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var12 = var11.getBaseItemLabelPaint();
    java.awt.Paint var14 = var11.getSeriesPaint(10);
    boolean var15 = var11.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("");
    int var18 = var17.getMaximumLinesToDisplay();
    java.awt.Paint var19 = var17.getPaint();
    var11.setBaseItemLabelPaint(var19);
    var9.setBackgroundPaint(var19);
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var24 = var23.getLabelAngle();
    java.lang.String var25 = var23.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var27 = var26.getLegendItems();
    org.jfree.chart.util.SortOrder var28 = var26.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var33 = var32.getBaseItemLabelPaint();
    var31.setBaseFillPaint(var33);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var33);
    org.jfree.chart.plot.IntervalMarker var36 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var33);
    var26.setRangeGridlinePaint(var33);
    var26.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var42 = var41.getLabelInsets();
    java.lang.Object var43 = null;
    boolean var44 = var42.equals(var43);
    var26.setAxisOffset(var42);
    var23.setLabelInsets(var42, true);
    org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot();
    double var49 = var48.getLimit();
    double var50 = var48.getLimit();
    org.jfree.chart.JFreeChart var51 = var48.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var23, var51, 0, 0);
    int var55 = var51.getBackgroundImageAlignment();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var51);
    var51.setAntiAlias(false);
    org.jfree.chart.axis.AxisState var60 = new org.jfree.chart.axis.AxisState(100.0d);
    var60.cursorLeft((-1.0d));
    var60.cursorLeft(0.05d);
    java.util.List var65 = var60.getTicks();
    var51.setSubtitles(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     double var5 = var4.getInteriorGap();
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
//     var6.setStartAngle(0.08d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = var6.getLabelGenerator();
//     var4.setLabelGenerator(var9);
//     int var11 = var2.compareTo((java.lang.Object)var9);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(1, var2);
//     java.util.Calendar var13 = null;
//     var12.peg(var13);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    java.awt.Paint var27 = var19.getRadiusGridlinePaint();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var37 = var36.getBaseItemLabelPaint();
    var35.setBaseFillPaint(var37);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var35.setBaseStroke(var48);
    var34.setAxisLineStroke(var48);
    var31.setLabelOutlineStroke(var48);
    java.awt.Paint var54 = var31.getLabelOutlinePaint();
    boolean var55 = org.jfree.chart.util.PaintUtilities.equal(var27, var54);
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var54);
    var1.setSubtitlePaint(var54);
    java.awt.Color var61 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var62 = var61.getAlpha();
    int var63 = var61.getGreen();
    org.jfree.data.time.DateRange var64 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var66 = org.jfree.data.Range.shift((org.jfree.data.Range)var64, 10.0d);
    boolean var67 = var61.equals((java.lang.Object)10.0d);
    var1.setCrosshairPaint((java.awt.Paint)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     java.lang.String var12 = var11.getPlotType();
//     var11.zoom(90.0d);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
//     org.jfree.chart.util.SortOrder var17 = var15.getColumnRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var19 = var15.getRangeAxisForDataset(0);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var24 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var25 = var24.getAlpha();
//     int var26 = var24.getTransparency();
//     boolean var27 = var20.equals((java.lang.Object)var24);
//     org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
//     var28.setSeriesToolTipGenerator(0, var30, true);
//     boolean var33 = var28.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var35 = var28.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var37 = var36.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var42 = var38.isItemLabelVisible(0, (-1), true);
//     boolean var43 = var37.equals((java.lang.Object)var38);
//     var28.setPositiveItemLabelPositionFallback(var37);
//     java.awt.Paint var46 = var28.lookupSeriesFillPaint(2147483647);
//     var20.setLabelPaint(var46);
//     org.jfree.chart.axis.DateTickUnit var48 = var20.getTickUnit();
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var50 = var49.getBaseStroke();
//     double var51 = var49.getShadowXOffset();
//     boolean var52 = var49.getAutoPopulateSeriesOutlinePaint();
//     boolean var56 = var49.getItemCreateEntity(13, 100, true);
//     org.jfree.data.xy.DefaultXYDataset var57 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.time.TimeSeries var58 = null;
//     java.util.TimeZone var59 = null;
//     org.jfree.data.time.TimeSeriesCollection var60 = new org.jfree.data.time.TimeSeriesCollection(var58, var59);
//     org.jfree.data.Range var62 = var60.getDomainBounds(true);
//     org.jfree.data.Range var63 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var60);
//     java.lang.String[] var65 = org.jfree.data.time.SerialDate.getMonths(false);
//     boolean var66 = var60.equals((java.lang.Object)var65);
//     org.jfree.data.general.SeriesChangeEvent var67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var65);
//     var57.seriesChanged(var67);
//     org.jfree.data.Range var69 = var49.findDomainBounds((org.jfree.data.xy.XYDataset)var57);
//     org.jfree.data.general.DatasetChangeEvent var70 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var48, (org.jfree.data.general.Dataset)var57);
//     var15.datasetChanged(var70);
//     var11.datasetChanged(var70);
//     
//     // Checks the contract:  equals-hashcode on var1 and var60
//     assertTrue("Contract failed: equals-hashcode on var1 and var60", var1.equals(var60) ? var1.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var1
//     assertTrue("Contract failed: equals-hashcode on var60 and var1", var60.equals(var1) ? var60.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.setMinorTickCount(1);
    org.jfree.chart.event.AxisChangeEvent var6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    java.lang.String var7 = var6.toString();
    org.jfree.chart.axis.Axis var8 = var6.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
    float var7 = var6.getForegroundAlpha();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, 1, true);
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var14 = null;
    java.util.TimeZone var15 = null;
    org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14, var15);
    org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, (org.jfree.data.general.Dataset)var16, (java.lang.Comparable)(-1.0d));
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var22 = var21.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
    java.lang.String var24 = var23.getToolTipText();
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(100, (-1), false);
    java.awt.Paint var31 = var25.getSeriesFillPaint(100);
    java.awt.Stroke var33 = var25.lookupSeriesOutlineStroke(100);
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var35 = var34.getBaseItemLabelPaint();
    java.awt.Paint var37 = var34.getSeriesPaint(10);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var39 = var38.getBaseNegativeItemLabelPosition();
    var34.setPositiveItemLabelPositionFallback(var39);
    var25.setPositiveItemLabelPositionFallback(var39);
    var18.add((org.jfree.chart.block.Block)var23, (java.lang.Object)var39);
    var0.setBasePositiveItemLabelPosition(var39);
    boolean var44 = var0.isDrawBarOutline();
    java.awt.Font var46 = var0.getSeriesItemLabelFont(1);
    var0.setShadowVisible(false);
    double var49 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getRangeAxisLocation();
    java.awt.Paint var27 = var25.getDomainZeroBaselinePaint();
    org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    java.awt.Paint var32 = var31.getLabelPaint();
    org.jfree.chart.util.Layer var33 = null;
    var25.addRangeMarker(0, (org.jfree.chart.plot.Marker)var31, var33, false);
    boolean var36 = var25.isRangeCrosshairLockedOnData();
    org.jfree.chart.plot.SeriesRenderingOrder var37 = var25.getSeriesRenderingOrder();
    org.jfree.data.time.TimeSeries var38 = null;
    org.jfree.data.time.TimeSeriesCollection var39 = new org.jfree.data.time.TimeSeriesCollection(var38);
    int var41 = var39.indexOf((java.lang.Comparable)86400000L);
    org.jfree.chart.axis.LogAxis var43 = new org.jfree.chart.axis.LogAxis("");
    var43.setAutoTickUnitSelection(true);
    var43.resizeRange(0.05d, (-1.0d));
    var43.configure();
    org.jfree.chart.renderer.PolarItemRenderer var50 = null;
    org.jfree.chart.plot.PolarPlot var51 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var39, (org.jfree.chart.axis.ValueAxis)var43, var50);
    org.jfree.data.xy.XYDataset var52 = var51.getDataset();
    boolean var53 = var37.equals((java.lang.Object)var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.StandardXYToolTipGenerator var2 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    var1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var2, true);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(255, (org.jfree.chart.labels.XYToolTipGenerator)var2, (org.jfree.chart.urls.XYURLGenerator)var6);
    var7.setSeriesVisible(10, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getRangeAxisLocation();
    var25.setDomainPannable(true);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var34 = var33.getAlpha();
    int var35 = var33.getTransparency();
    boolean var36 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
    java.awt.Paint var43 = var37.getSeriesFillPaint(100);
    java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
    var29.setAxisLineStroke(var45);
    java.util.TimeZone var47 = var29.getTimeZone();
    boolean var49 = var29.isHiddenValue(61200000L);
    int var50 = var25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var55 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var56 = var55.getAlpha();
    int var57 = var55.getTransparency();
    boolean var58 = var51.equals((java.lang.Object)var55);
    org.jfree.chart.renderer.xy.XYBarRenderer var59 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var63 = var59.getURLGenerator(100, (-1), false);
    java.awt.Paint var65 = var59.getSeriesFillPaint(100);
    java.awt.Stroke var67 = var59.lookupSeriesOutlineStroke(100);
    var51.setAxisLineStroke(var67);
    java.util.TimeZone var69 = var51.getTimeZone();
    var29.setTimeZone(var69);
    org.jfree.chart.axis.TickUnitSource var71 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var69);
    org.jfree.data.time.TimeSeriesCollection var72 = new org.jfree.data.time.TimeSeriesCollection(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.data.time.TimePeriodAnchor var7 = var3.getXPosition();
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var3, false);
    org.jfree.data.xy.IntervalXYDelegate var10 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var3);
    java.util.List var11 = var3.getSeries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     double var6 = var0.getRangeUpperBound(true);
//     double var8 = var0.getRangeUpperBound(true);
//     org.jfree.chart.LegendItemSource var9 = null;
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
//     org.jfree.chart.LegendItemSource[] var11 = var10.getSources();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     org.jfree.chart.entity.PlotEntity var16 = new org.jfree.chart.entity.PlotEntity(var13, (org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var21 = var20.getBaseItemLabelPaint();
//     var19.setBaseFillPaint(var21);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var23.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var29 = var25.isItemLabelVisible(0, (-1), true);
//     boolean var30 = var24.equals((java.lang.Object)var25);
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var32 = var31.getBaseStroke();
//     var25.setBaseStroke(var32, false);
//     var19.setBaseStroke(var32);
//     var18.setAxisLineStroke(var32);
//     var15.setLabelOutlineStroke(var32);
//     java.awt.Paint var38 = var15.getLabelOutlinePaint();
//     org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var40 = var39.getBaseItemLabelPaint();
//     java.awt.Paint var42 = var39.getSeriesPaint(10);
//     java.awt.Shape var44 = null;
//     var39.setSeriesShape(0, var44, false);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var48 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     var47.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var48, true);
//     java.awt.Stroke var54 = var47.getItemStroke(0, 100, false);
//     var39.setBaseStroke(var54, false);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var58 = var57.getLegendItems();
//     org.jfree.chart.util.SortOrder var59 = var57.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var62 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var63 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var64 = var63.getBaseItemLabelPaint();
//     var62.setBaseFillPaint(var64);
//     org.jfree.chart.block.BlockBorder var66 = new org.jfree.chart.block.BlockBorder(var64);
//     org.jfree.chart.plot.IntervalMarker var67 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var64);
//     var57.setRangeGridlinePaint(var64);
//     var57.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var72 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var73 = var72.getLabelInsets();
//     java.lang.Object var74 = null;
//     boolean var75 = var73.equals(var74);
//     var57.setAxisOffset(var73);
//     org.jfree.chart.block.LineBorder var77 = new org.jfree.chart.block.LineBorder(var38, var54, var73);
//     var10.setLegendItemGraphicPadding(var73);
//     org.jfree.chart.util.RectangleInsets var79 = var10.getItemLabelPadding();
//     boolean var80 = var0.equals((java.lang.Object)var10);
//     org.jfree.chart.util.RectangleAnchor var81 = var10.getLegendItemGraphicLocation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }
// 
// 
//     org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
//     java.lang.Boolean var2 = var0.getBoolean(10);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState(100.0d);
//     var9.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = var12.getLegendItems();
//     org.jfree.chart.util.SortOrder var14 = var12.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var21 = var17.isItemLabelVisible(0, (-1), true);
//     boolean var22 = var16.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var24 = var23.getBaseStroke();
//     var17.setBaseStroke(var24, false);
//     var12.setRangeCrosshairStroke(var24);
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var30 = var12.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var29);
//     var9.setTicks(var30);
//     var6.addExceptions(var30);
//     boolean var33 = var0.equals((java.lang.Object)var6);
//     java.lang.Class var34 = null;
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     long var36 = var35.getMiddleMillisecond();
//     java.util.Date var37 = var35.getStart();
//     java.util.Date var38 = var35.getEnd();
//     java.util.TimeZone var39 = null;
//     org.jfree.data.time.RegularTimePeriod var40 = org.jfree.data.time.RegularTimePeriod.createInstance(var34, var38, var39);
//     long var41 = var6.toTimelineValue(var38);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var38);
//     org.jfree.data.time.SerialDate var43 = var42.getSerialDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1058475600000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, 0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var7 = var3.isItemLabelVisible(0, (-1), true);
    var3.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var11 = null;
    org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection(var11);
    org.jfree.chart.axis.LogAxis var14 = new org.jfree.chart.axis.LogAxis("");
    var14.setAutoTickUnitSelection(true);
    var14.resizeRange(0.05d, (-1.0d));
    boolean var20 = var14.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var21 = null;
    org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, (org.jfree.chart.axis.ValueAxis)var14, var21);
    java.lang.String var23 = var22.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var26 = var25.getBaseItemLabelPaint();
    var24.setBaseFillPaint(var26);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var26);
    var22.setRadiusGridlinePaint(var26);
    var3.setSeriesPaint(100, var26, true);
    var2.setShadowPaint(var26);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var2.setSeriesToolTipGenerator(10, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Polar Plot"+ "'", var23.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var31 = var30.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var31);
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(100, (-1), false);
    boolean var38 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var42 = var33.getItemFillPaint(100, (-1), true);
    var25.setRangeZeroBaselinePaint(var42);
    java.awt.Paint var44 = var25.getRangeTickBandPaint();
    boolean var45 = var25.isRangeGridlinesVisible();
    org.jfree.data.xy.DefaultXYDataset var46 = new org.jfree.data.xy.DefaultXYDataset();
    int var47 = var46.getSeriesCount();
    org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var48, (org.jfree.data.Range)var49);
    boolean var51 = var46.equals((java.lang.Object)var48);
    var46.removeSeries((java.lang.Comparable)' ');
    var46.removeSeries((java.lang.Comparable)1418759999999L);
    int var56 = var25.indexOf((org.jfree.data.xy.XYDataset)var46);
    boolean var57 = var25.isRangeZeroBaselineVisible();
    org.jfree.data.time.TimeSeries var58 = null;
    org.jfree.data.time.TimeSeriesCollection var59 = new org.jfree.data.time.TimeSeriesCollection(var58);
    org.jfree.chart.axis.LogAxis var61 = new org.jfree.chart.axis.LogAxis("");
    var61.setAutoTickUnitSelection(true);
    var61.resizeRange(0.05d, (-1.0d));
    boolean var67 = var61.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var68 = null;
    org.jfree.chart.plot.PolarPlot var69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var59, (org.jfree.chart.axis.ValueAxis)var61, var68);
    java.lang.String var70 = var69.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var71 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var72 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var73 = var72.getBaseItemLabelPaint();
    var71.setBaseFillPaint(var73);
    org.jfree.chart.block.BlockBorder var75 = new org.jfree.chart.block.BlockBorder(var73);
    var69.setRadiusGridlinePaint(var73);
    java.awt.Paint var77 = var69.getRadiusGridlinePaint();
    org.jfree.data.general.DatasetChangeEvent var78 = null;
    var69.datasetChanged(var78);
    org.jfree.chart.plot.PlotOrientation var80 = var69.getOrientation();
    var25.setOrientation(var80);
    org.jfree.chart.axis.AxisLocation var83 = var25.getRangeAxisLocation(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + "Polar Plot"+ "'", var70.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var31 = var30.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var31);
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(100, (-1), false);
    boolean var38 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var42 = var33.getItemFillPaint(100, (-1), true);
    var25.setRangeZeroBaselinePaint(var42);
    java.awt.Paint var44 = var25.getRangeTickBandPaint();
    org.jfree.chart.axis.AxisSpace var45 = var25.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var47 = var46.getCategories();
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var46.getDomainMarkers(0, var49);
    org.jfree.chart.axis.AxisSpace var51 = var46.getFixedDomainAxisSpace();
    int var52 = var46.getRendererCount();
    org.jfree.chart.plot.DatasetRenderingOrder var53 = var46.getDatasetRenderingOrder();
    var25.setDatasetRenderingOrder(var53);
    var25.clearSelection();
    boolean var56 = var25.isDomainZeroBaselineVisible();
    org.jfree.chart.plot.DatasetRenderingOrder var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.setDatasetRenderingOrder(var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }
// 
// 
//     org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat();
//     org.jfree.chart.util.LogFormat var9 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var10.getURLGenerator(100, (-1), false);
//     java.awt.Paint var16 = var10.getSeriesFillPaint(100);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var17.getBaseNegativeItemLabelPosition();
//     var10.setBaseNegativeItemLabelPosition(var18);
//     boolean var20 = var9.equals((java.lang.Object)var10);
//     java.text.NumberFormat var21 = var9.getExponentFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var4, var21);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var23 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var24 = var23.getXFormat();
//     java.math.RoundingMode var25 = var24.getRoundingMode();
//     org.jfree.chart.labels.StandardPieToolTipGenerator var26 = new org.jfree.chart.labels.StandardPieToolTipGenerator("2014", var21, var24);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var28 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var29 = var28.getXFormat();
//     org.jfree.chart.axis.NumberTickUnit var31 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var29, 0);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var32 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var33 = var32.getXFormat();
//     java.math.RoundingMode var34 = var33.getRoundingMode();
//     var29.setRoundingMode(var34);
//     int var36 = var29.getMaximumIntegerDigits();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var37 = new org.jfree.chart.labels.StandardXYToolTipGenerator("TimePeriodAnchor.START", var21, var29);
//     org.jfree.chart.util.LogFormat var40 = new org.jfree.chart.util.LogFormat();
//     org.jfree.chart.util.LogFormat var45 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var50 = var46.getURLGenerator(100, (-1), false);
//     java.awt.Paint var52 = var46.getSeriesFillPaint(100);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var54 = var53.getBaseNegativeItemLabelPosition();
//     var46.setBaseNegativeItemLabelPosition(var54);
//     boolean var56 = var45.equals((java.lang.Object)var46);
//     java.text.NumberFormat var57 = var45.getExponentFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var58 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var40, var57);
//     var57.setMaximumIntegerDigits(2147483647);
//     java.lang.String[] var63 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var64 = new org.jfree.chart.axis.SymbolAxis("hi!", var63);
//     org.jfree.chart.axis.LogAxis var66 = new org.jfree.chart.axis.LogAxis("");
//     var66.setAutoTickUnitSelection(true);
//     boolean var69 = var66.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var71 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var66.setTickUnit(var71, false, true);
//     var64.setTickUnit(var71, false, true);
//     var64.resizeRange2(Double.NEGATIVE_INFINITY, 4.0d);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var81 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var82 = var81.getXFormat();
//     java.math.RoundingMode var83 = var82.getRoundingMode();
//     var64.setNumberFormatOverride(var82);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var85 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", var57, var82);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var86 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var29, var82);
//     
//     // Checks the contract:  equals-hashcode on var18 and var54
//     assertTrue("Contract failed: equals-hashcode on var18 and var54", var18.equals(var54) ? var18.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var18
//     assertTrue("Contract failed: equals-hashcode on var54 and var18", var54.equals(var18) ? var54.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=3.0, height=0.0]");

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     java.util.List var5 = var0.getSeries();
//     double var7 = var0.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, 0, 1.0d, (-1.0d));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    java.awt.Paint var27 = var19.getRadiusGridlinePaint();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var37 = var36.getBaseItemLabelPaint();
    var35.setBaseFillPaint(var37);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var35.setBaseStroke(var48);
    var34.setAxisLineStroke(var48);
    var31.setLabelOutlineStroke(var48);
    java.awt.Paint var54 = var31.getLabelOutlinePaint();
    boolean var55 = org.jfree.chart.util.PaintUtilities.equal(var27, var54);
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var54);
    var1.setSubtitlePaint(var54);
    java.awt.Paint var58 = var1.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var60 = var59.getLegendItems();
    var59.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var59.rendererChanged(var62);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var59.markerChanged(var64);
    java.awt.Paint var66 = var59.getRangeCrosshairPaint();
    var1.setChartBackgroundPaint(var66);
    java.awt.Paint var68 = var1.getSubtitlePaint();
    org.jfree.chart.plot.MultiplePiePlot var69 = new org.jfree.chart.plot.MultiplePiePlot();
    double var70 = var69.getLimit();
    double var71 = var69.getLimit();
    org.jfree.chart.JFreeChart var72 = var69.getPieChart();
    java.util.List var73 = var72.getSubtitles();
    var72.setAntiAlias(false);
    var72.setBorderVisible(true);
    var1.apply(var72);
    org.jfree.chart.axis.CategoryAxis3D var82 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var83 = var82.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var84 = new org.jfree.chart.block.LabelBlock("hi!", var83);
    java.awt.Color var88 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var89 = var88.getAlpha();
    org.jfree.chart.text.TextFragment var90 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", var83, (java.awt.Paint)var88);
    var1.setErrorIndicatorPaint((java.awt.Paint)var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 255);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 0.05d);
    org.jfree.chart.axis.SegmentedTimeline var5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var6 = var5.clone();
    org.jfree.chart.axis.AxisState var8 = new org.jfree.chart.axis.AxisState(100.0d);
    var8.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
    org.jfree.chart.util.SortOrder var13 = var11.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var15 = var14.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var20 = var16.isItemLabelVisible(0, (-1), true);
    boolean var21 = var15.equals((java.lang.Object)var16);
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    var16.setBaseStroke(var23, false);
    var11.setRangeCrosshairStroke(var23);
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var29 = var11.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var28);
    var8.setTicks(var29);
    var5.addExceptions(var29);
    boolean var32 = var4.equals((java.lang.Object)var29);
    org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var36 = new org.jfree.chart.renderer.xy.XYItemRendererState(var35);
    org.jfree.chart.entity.EntityCollection var37 = var36.getEntityCollection();
    var4.add((org.jfree.chart.block.Block)var34, (java.lang.Object)var36);
    var4.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var5 = var4.getBaseStroke();
    java.lang.Boolean var7 = var4.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var11 = var10.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
    var4.setBaseItemLabelFont(var11, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var17 = var16.getXFormat();
    var4.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var16);
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var20, (org.jfree.chart.urls.XYURLGenerator)var24);
    org.jfree.chart.renderer.xy.XYStepRenderer var26 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var24);
    java.lang.Object var27 = var26.clone();
    var26.setBaseLinesVisible(true);
    java.awt.Shape var30 = var26.getLegendLine();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
    var32.setSeriesKey((java.lang.Comparable)10.0d);
    java.lang.String var35 = var32.getDescription();
    java.awt.Stroke var36 = var32.getLineStroke();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
    double var39 = var38.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    var38.handleClick(10, 0, var42);
    java.awt.Paint var44 = var38.getShadowPaint();
    java.awt.Paint[] var45 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var47 = var46.getBaseItemLabelPaint();
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var51 = var50.getBaseItemLabelPaint();
    var49.setBaseFillPaint(var51);
    java.awt.Paint[] var53 = new java.awt.Paint[] { var51};
    java.awt.Stroke var54 = null;
    java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Shape var58 = null;
    java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var48, var53, var55, var57, var59);
    java.awt.Shape var61 = var60.getNextShape();
    var38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var60);
    var38.setCircular(true);
    boolean var65 = var38.getAutoPopulateSectionOutlineStroke();
    java.awt.Paint var66 = var38.getOutlinePaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("TimePeriodAnchor.START", "VerticalAlignment.CENTER", "", "Pie 3D Plot", var30, var36, var66);
    java.awt.Shape var68 = var67.getLine();
    java.lang.String var69 = var67.getLabel();
    java.awt.Stroke var70 = var67.getLineStroke();
    java.lang.Object var71 = var67.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "TimePeriodAnchor.START"+ "'", var69.equals("TimePeriodAnchor.START"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var1);
//     org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis("");
//     var4.setAutoTickUnitSelection(true);
//     var4.resizeRange(0.05d, (-1.0d));
//     boolean var10 = var4.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, (org.jfree.chart.axis.ValueAxis)var4, var11);
//     java.lang.String var13 = var12.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var16 = var15.getBaseItemLabelPaint();
//     var14.setBaseFillPaint(var16);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(var16);
//     var12.setRadiusGridlinePaint(var16);
//     java.awt.Paint var20 = var12.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var12.datasetChanged(var21);
//     boolean var23 = var12.isRadiusGridlinesVisible();
//     var12.setRadiusGridlinesVisible(false);
//     org.jfree.chart.plot.MultiplePiePlot var27 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var28 = var27.getLimit();
//     double var29 = var27.getLimit();
//     org.jfree.chart.JFreeChart var30 = var27.getPieChart();
//     org.jfree.data.category.CategoryDataset var31 = var27.getDataset();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     long var33 = var32.getMiddleMillisecond();
//     java.util.Date var34 = var32.getStart();
//     java.util.Date var35 = var32.getEnd();
//     var27.setAggregatedItemsKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var38 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var37);
//     java.util.TimeZone var39 = var38.getTimeZone();
//     var38.configure();
//     org.jfree.data.Range var41 = var12.getDataRange((org.jfree.chart.axis.ValueAxis)var38);
//     var38.setMinorTickMarksVisible(true);
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)644288400000L, "[size=100]", "RectangleEdge.BOTTOM");
//     boolean var48 = var47.getNotify();
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     long var50 = var49.getMiddleMillisecond();
//     java.util.Date var51 = var49.getStart();
//     java.util.Date var52 = var49.getEnd();
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year(var52);
//     org.jfree.data.time.RegularTimePeriod var54 = var53.previous();
//     java.util.Date var55 = var53.getStart();
//     org.jfree.data.time.TimeSeriesDataItem var56 = var47.getDataItem((org.jfree.data.time.RegularTimePeriod)var53);
//     int var57 = var53.getYear();
//     var38.setLast((org.jfree.data.time.RegularTimePeriod)var53);
//     java.util.Locale var59 = var38.getLocale();
//     org.jfree.chart.labels.StandardPieToolTipGenerator var60 = new org.jfree.chart.labels.StandardPieToolTipGenerator("31-December-2014", var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "Polar Plot"+ "'", var13.equals("Polar Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var52 = var51.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
//     boolean var54 = var50.equals((java.lang.Object)var53);
//     boolean var55 = var50.isShapeFilled();
//     java.awt.Stroke var56 = var50.getLineStroke();
//     java.awt.Paint var57 = var50.getFillPaint();
//     java.lang.Object var58 = var50.clone();
//     boolean var59 = var50.isShapeFilled();
//     org.jfree.chart.block.BlockFrame var60 = var50.getFrame();
//     org.jfree.chart.plot.MultiplePiePlot var61 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var62 = var61.getLimit();
//     double var63 = var61.getLimit();
//     org.jfree.chart.JFreeChart var64 = var61.getPieChart();
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var66 = var65.getLegendItems();
//     org.jfree.chart.util.SortOrder var67 = var65.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var70 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var72 = var71.getBaseItemLabelPaint();
//     var70.setBaseFillPaint(var72);
//     org.jfree.chart.block.BlockBorder var74 = new org.jfree.chart.block.BlockBorder(var72);
//     org.jfree.chart.plot.IntervalMarker var75 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var72);
//     var65.setRangeGridlinePaint(var72);
//     java.awt.Paint var77 = var65.getDomainCrosshairPaint();
//     var61.setAggregatedItemsPaint(var77);
//     var50.setLinePaint(var77);
//     
//     // Checks the contract:  equals-hashcode on var25 and var74
//     assertTrue("Contract failed: equals-hashcode on var25 and var74", var25.equals(var74) ? var25.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var25
//     assertTrue("Contract failed: equals-hashcode on var74 and var25", var74.equals(var25) ? var74.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.general.Dataset var6 = var5.getDataset();
    var5.setURLText("black");
    var5.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var2 = org.jfree.data.Range.shift((org.jfree.data.Range)var0, 10.0d);
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange((org.jfree.data.Range)var0);
    double var4 = var0.getCentralValue();
    org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.DefaultXYDataset var6 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var7 = null;
    java.util.TimeZone var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var7, var8);
    org.jfree.data.Range var11 = var9.getDomainBounds(true);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var9);
    java.lang.String[] var14 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var15 = var9.equals((java.lang.Object)var14);
    org.jfree.data.general.SeriesChangeEvent var16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var14);
    var6.seriesChanged(var16);
    var5.seriesChanged(var16);
    boolean var19 = var0.equals((java.lang.Object)var5);
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range)var0, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    var2.setAutoTickUnitSelection(true);
    boolean var5 = var2.isAutoTickUnitSelection();
    var2.resizeRange(0.05d);
    java.awt.Font var8 = var2.getLabelFont();
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("hi!", var8);
    org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
    var12.setAutoTickUnitSelection(true);
    boolean var15 = var12.isAutoTickUnitSelection();
    var12.resizeRange(0.05d);
    java.awt.Font var18 = var12.getLabelFont();
    org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("hi!", var18);
    org.jfree.chart.text.TextFragment var20 = var19.getLastTextFragment();
    var9.removeFragment(var20);
    org.jfree.data.time.TimeSeries var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var22);
    int var25 = var23.indexOf((java.lang.Comparable)86400000L);
    org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
    var27.setAutoTickUnitSelection(true);
    var27.resizeRange(0.05d, (-1.0d));
    var27.configure();
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var23, (org.jfree.chart.axis.ValueAxis)var27, var34);
    boolean var36 = var9.equals((java.lang.Object)var27);
    java.lang.Object var37 = null;
    boolean var38 = var9.equals(var37);
    org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("");
    var40.setSeriesKey((java.lang.Comparable)10.0d);
    int var43 = var40.getDatasetIndex();
    org.jfree.chart.renderer.xy.XYBarRenderer var44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var45 = var44.getBaseItemLabelPaint();
    var40.setOutlinePaint(var45);
    java.lang.String var47 = var40.getDescription();
    boolean var48 = var40.isShapeFilled();
    boolean var49 = var9.equals((java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    var0.setBaseFillPaint(var2);
    double var4 = var0.getItemLabelAnchorOffset();
    org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection();
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var5);
    var5.clearSelection();
    org.jfree.data.Range var8 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var5);
    org.jfree.data.xy.XYSeries var11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    boolean var12 = var11.isEmpty();
    org.jfree.data.xy.XYSeries var15 = var11.createCopy(13, 31);
    int var16 = var5.indexOf(var11);
    org.jfree.data.xy.XYDataItem var19 = var11.addOrUpdate((-0.975d), 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var5 = var4.getAlpha();
    int var6 = var4.getTransparency();
    boolean var7 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    java.awt.Stroke var16 = var8.lookupSeriesOutlineStroke(100);
    var0.setAxisLineStroke(var16);
    java.util.TimeZone var18 = var0.getTimeZone();
    boolean var20 = var0.isHiddenValue(61200000L);
    org.jfree.chart.axis.SegmentedTimeline var24 = new org.jfree.chart.axis.SegmentedTimeline(604800000L, 10, (-1));
    boolean var26 = var24.containsDomainValue(1420012800000L);
    var0.setTimeline((org.jfree.chart.axis.Timeline)var24);
    long var30 = var24.getExceptionSegmentCount(1404331199999L, (-2208960000000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0L);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var4 = var3.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
    var2.setNoDataMessagePaint(var4);
    var2.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var10 = var2.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var12 = new org.jfree.chart.renderer.xy.XYItemRendererState(var11);
    boolean var13 = var12.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var14 = null;
    var12.setCrosshairState(var14);
    boolean var16 = var2.equals((java.lang.Object)var12);
    org.jfree.chart.axis.AxisLocation var18 = var2.getDomainAxisLocation(13);
    var0.setRangeAxisLocation(1, var18);
    int var20 = var0.getRangeAxisCount();
    java.lang.String var21 = var0.getPlotType();
    boolean var22 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis("");
    var24.setAutoTickUnitSelection(true);
    boolean var27 = var24.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var29 = var28.getLegendItems();
    org.jfree.chart.util.SortOrder var30 = var28.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var32 = var31.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var37 = var33.isItemLabelVisible(0, (-1), true);
    boolean var38 = var32.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var40 = var39.getBaseStroke();
    var33.setBaseStroke(var40, false);
    var28.setRangeCrosshairStroke(var40);
    org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var46 = var28.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var45);
    var24.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
    org.jfree.chart.plot.CombinedDomainXYPlot var48 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.AxisLocation var49 = var48.getRangeAxisLocation();
    var48.mapDatasetToDomainAxis(1, 1);
    java.awt.Paint var53 = var48.getDomainTickBandPaint();
    java.awt.Stroke var54 = var48.getDomainZeroBaselineStroke();
    var0.remove((org.jfree.chart.plot.XYPlot)var48);
    org.jfree.data.xy.XYDataset var57 = var48.getDataset(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Combined Range XYPlot"+ "'", var21.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var3 = var2.getCategories();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    var2.setAnchorValue(1.0d, true);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
    double var10 = var2.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
    java.text.AttributedString var3 = var1.getAttributedLabel(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    var3.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.setVerticalTickLabels(false);
    var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8, true);
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.event.MarkerChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var3.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var21, var24);
    org.jfree.chart.text.TextAnchor var26 = var21.getLabelTextAnchor();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
    java.lang.Object var29 = null;
    boolean var30 = var28.equals(var29);
    org.jfree.chart.text.TextAnchor var31 = var28.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "", var26, var31, 10.0d);
    java.lang.String var34 = var33.toString();
    boolean var36 = var33.equals((java.lang.Object)"java.awt.Color[r=0,g=0,b=0]");
    java.lang.String var37 = var33.toString();
    org.jfree.chart.axis.TickType var38 = var33.getTickType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + ""+ "'", var37.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     boolean var27 = var25.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var29 = var25.getDomainAxis(255);
//     org.jfree.chart.LegendItemCollection var30 = var25.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = var0.getLastLine();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var8 = var7.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("", var8);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var13 = var12.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("hi!", var13);
    org.jfree.chart.util.RectangleAnchor var15 = var14.getTextAnchor();
    org.jfree.chart.text.TextBlockAnchor var16 = var14.getContentAlignmentPoint();
    java.lang.String var17 = var16.toString();
    var9.setContentAlignmentPoint(var16);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var19.setSeriesToolTipGenerator(0, var21, true);
    boolean var24 = var19.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var25 = var19.getPositiveItemLabelPositionFallback();
    var19.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19);
    org.jfree.data.time.TimeSeries var29 = null;
    org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
    org.jfree.chart.axis.LogAxis var32 = new org.jfree.chart.axis.LogAxis("");
    var32.setAutoTickUnitSelection(true);
    var32.resizeRange(0.05d, (-1.0d));
    boolean var38 = var32.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var39 = null;
    org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var30, (org.jfree.chart.axis.ValueAxis)var32, var39);
    java.lang.String var41 = var40.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var43 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var44 = var43.getBaseItemLabelPaint();
    var42.setBaseFillPaint(var44);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var44);
    var40.setRadiusGridlinePaint(var44);
    java.awt.Paint var48 = var40.getRadiusGridlinePaint();
    var28.setBackgroundPaint(var48);
    org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var51 = var50.getBaseItemLabelPaint();
    var28.setBackgroundPaint(var51);
    java.awt.Graphics2D var53 = null;
    org.jfree.data.time.DateRange var54 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var55 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var54, (org.jfree.data.Range)var55);
    org.jfree.chart.block.LengthConstraintType var57 = var56.getWidthConstraintType();
    org.jfree.data.xy.DefaultXYDataset var59 = new org.jfree.data.xy.DefaultXYDataset();
    int var60 = var59.getSeriesCount();
    org.jfree.data.time.DateRange var61 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var62 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var61, (org.jfree.data.Range)var62);
    boolean var64 = var59.equals((java.lang.Object)var61);
    org.jfree.data.time.DateRange var65 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var66 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var67 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var65, (org.jfree.data.Range)var66);
    org.jfree.chart.block.LengthConstraintType var68 = var67.getWidthConstraintType();
    org.jfree.data.time.DateRange var70 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var71 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var72 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var71, (org.jfree.data.Range)var72);
    org.jfree.chart.block.LengthConstraintType var74 = var73.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var61, var68, 0.0d, (org.jfree.data.Range)var70, var74);
    org.jfree.data.xy.DefaultXYDataset var76 = new org.jfree.data.xy.DefaultXYDataset();
    int var77 = var76.getSeriesCount();
    org.jfree.data.time.DateRange var78 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var79 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var80 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var78, (org.jfree.data.Range)var79);
    boolean var81 = var76.equals((java.lang.Object)var78);
    boolean var82 = var70.intersects((org.jfree.data.Range)var78);
    org.jfree.chart.block.RectangleConstraint var83 = var56.toRangeWidth((org.jfree.data.Range)var70);
    org.jfree.chart.util.Size2D var84 = var28.arrange(var53, var56);
    org.jfree.chart.block.RectangleConstraint var86 = var56.toFixedWidth(3.0d);
    boolean var87 = var16.equals((java.lang.Object)var56);
    var0.draw(var2, 0.8f, 0.0f, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "TextBlockAnchor.CENTER"+ "'", var17.equals("TextBlockAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "Polar Plot"+ "'", var41.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
//     var0.setNoDataMessagePaint(var2);
//     java.awt.Stroke var5 = var0.getRangeZeroBaselineStroke();
//     boolean var6 = var0.isRangePannable();
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis(0);
//     org.jfree.data.time.TimeSeries var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
//     org.jfree.chart.axis.LogAxis var16 = new org.jfree.chart.axis.LogAxis("");
//     var16.setAutoTickUnitSelection(true);
//     var16.resizeRange(0.05d, (-1.0d));
//     boolean var22 = var16.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, (org.jfree.chart.axis.ValueAxis)var16, var23);
//     java.lang.String var25 = var24.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var28 = var27.getBaseItemLabelPaint();
//     var26.setBaseFillPaint(var28);
//     org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var28);
//     var24.setRadiusGridlinePaint(var28);
//     java.awt.Paint var32 = var24.getRadiusGridlinePaint();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     org.jfree.chart.entity.PlotEntity var37 = new org.jfree.chart.entity.PlotEntity(var34, (org.jfree.chart.plot.Plot)var36);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var42 = var41.getBaseItemLabelPaint();
//     var40.setBaseFillPaint(var42);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var45 = var44.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var50 = var46.isItemLabelVisible(0, (-1), true);
//     boolean var51 = var45.equals((java.lang.Object)var46);
//     org.jfree.chart.renderer.xy.XYBarRenderer var52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var53 = var52.getBaseStroke();
//     var46.setBaseStroke(var53, false);
//     var40.setBaseStroke(var53);
//     var39.setAxisLineStroke(var53);
//     var36.setLabelOutlineStroke(var53);
//     java.awt.Paint var59 = var36.getLabelOutlinePaint();
//     boolean var60 = org.jfree.chart.util.PaintUtilities.equal(var32, var59);
//     org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var59);
//     var0.setDomainGridlinePaint(var59);
//     
//     // Checks the contract:  equals-hashcode on var3 and var30
//     assertTrue("Contract failed: equals-hashcode on var3 and var30", var3.equals(var30) ? var3.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var3
//     assertTrue("Contract failed: equals-hashcode on var30 and var3", var30.equals(var3) ? var30.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    var5.resizeRange(0.05d, (-1.0d));
    var5.setVerticalTickLabels(false);
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5, true);
    var5.setTickLabelsVisible(false);
    org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var18 = var17.clone();
    boolean var19 = var5.equals((java.lang.Object)var17);
    var5.centerRange(3.0d);
    double var22 = var5.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var8 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var13 = var9.getURLGenerator(100, (-1), false);
    java.awt.Paint var15 = var9.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var16.getBaseNegativeItemLabelPosition();
    var9.setBaseNegativeItemLabelPosition(var17);
    boolean var19 = var8.equals((java.lang.Object)var9);
    java.text.NumberFormat var20 = var8.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var3, var20);
    var20.setMaximumFractionDigits(96);
    org.jfree.chart.labels.StandardPieToolTipGenerator var24 = new org.jfree.chart.labels.StandardPieToolTipGenerator("java.awt.Color[r=255,g=255,b=255]", var1, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var1 = null;
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var3, true);
//     double var9 = var3.getDomainUpperBound(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    org.jfree.chart.title.TextTitle var4 = var3.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var1 = var0.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var2 = var0.getPlotInfo();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var3 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
//     var3.setEndValue((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Font var7 = var3.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     org.jfree.chart.util.SortOrder var10 = var8.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     var13.setBaseFillPaint(var15);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
//     org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var15);
//     var8.setRangeGridlinePaint(var15);
//     org.jfree.chart.util.SortOrder var20 = var8.getColumnRenderingOrder();
//     java.awt.Paint var21 = var8.getRangeZeroBaselinePaint();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.text.G2TextMeasurer var25 = new org.jfree.chart.text.G2TextMeasurer(var24);
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=255,b=255]", var7, var21, 1.0f, 13, (org.jfree.chart.text.TextMeasurer)var25);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 3.0d);
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    org.jfree.chart.axis.LogAxis var6 = new org.jfree.chart.axis.LogAxis("");
    var6.setAutoTickUnitSelection(true);
    var6.resizeRange(0.05d, (-1.0d));
    boolean var12 = var6.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var4, (org.jfree.chart.axis.ValueAxis)var6, var13);
    java.lang.String var15 = var14.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var18 = var17.getBaseItemLabelPaint();
    var16.setBaseFillPaint(var18);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(var18);
    var14.setRadiusGridlinePaint(var18);
    int var22 = var2.compareTo((java.lang.Object)var14);
    org.jfree.chart.LegendItemCollection var23 = var14.getLegendItems();
    org.jfree.data.xy.XYDataset var24 = var14.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Polar Plot"+ "'", var15.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     double var10 = var0.getUpperClip();
//     boolean var11 = var0.getShadowsVisible();
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var12.setShadowXOffset((-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var18 = var12.getNegativeItemLabelPosition(2147483647, 100, true);
//     var0.setBasePositiveItemLabelPosition(var18, true);
//     org.jfree.chart.labels.ItemLabelAnchor var21 = var18.getItemLabelAnchor();
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var23 = var22.getLimit();
//     double var24 = var22.getLimit();
//     org.jfree.chart.JFreeChart var25 = var22.getPieChart();
//     org.jfree.data.category.CategoryDataset var26 = var22.getDataset();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     long var28 = var27.getMiddleMillisecond();
//     java.util.Date var29 = var27.getStart();
//     java.util.Date var30 = var27.getEnd();
//     var22.setAggregatedItemsKey((java.lang.Comparable)var27);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var32.getBaseNegativeItemLabelPosition();
//     boolean var34 = var22.equals((java.lang.Object)var32);
//     var22.setAggregatedItemsKey((java.lang.Comparable)"Category Plot");
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var38 = var37.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var39 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var40 = var39.getLimit();
//     double var41 = var39.getLimit();
//     org.jfree.chart.JFreeChart var42 = var39.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var37, var42, (-1), 1);
//     java.lang.Object var46 = var42.clone();
//     boolean var47 = var42.isNotify();
//     org.jfree.chart.title.LegendTitle var48 = var42.getLegend();
//     var42.removeLegend();
//     java.awt.Paint var50 = null;
//     var42.setBorderPaint(var50);
//     var22.setPieChart(var42);
//     double var53 = var22.getLimit();
//     org.jfree.chart.util.TableOrder var54 = var22.getDataExtractOrder();
//     boolean var55 = var21.equals((java.lang.Object)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("VerticalAlignment.CENTER", var1, var2);
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var5 = var4.getBaseStroke();
    java.lang.Boolean var7 = var4.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var11 = var10.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
    var4.setBaseItemLabelFont(var11, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var17 = var16.getXFormat();
    var4.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var16);
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var20, (org.jfree.chart.urls.XYURLGenerator)var24);
    org.jfree.chart.renderer.xy.XYStepRenderer var26 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var24);
    org.jfree.chart.renderer.xy.XYStepRenderer var27 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var3, (org.jfree.chart.urls.XYURLGenerator)var24);
    var27.setUseFillPaint(false);
    java.lang.Boolean var31 = var27.getSeriesShapesFilled(28);
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
    double var35 = var34.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    var34.handleClick(10, 0, var38);
    java.awt.Paint var40 = var34.getShadowPaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var43 = var42.getBaseItemLabelPaint();
    var41.setBaseFillPaint(var43);
    org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(var43);
    var34.setLabelBackgroundPaint(var43);
    java.lang.String[] var49 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var50 = new org.jfree.chart.axis.SymbolAxis("hi!", var49);
    org.jfree.chart.axis.LogAxis var52 = new org.jfree.chart.axis.LogAxis("");
    var52.setAutoTickUnitSelection(true);
    boolean var55 = var52.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var57 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var52.setTickUnit(var57, false, true);
    var50.setTickUnit(var57, false, true);
    org.jfree.chart.ChartRenderingInfo var65 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var66 = var65.getChartArea();
    org.jfree.data.general.PieDataset var67 = null;
    org.jfree.chart.entity.PieSectionEntity var73 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var66, var67, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var75 = var74.getLegendItems();
    var74.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var77 = null;
    int var78 = var74.indexOf(var77);
    org.jfree.chart.util.RectangleEdge var79 = var74.getDomainAxisEdge();
    boolean var80 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var79);
    double var81 = var50.valueToJava2D(0.05d, var66, var79);
    var34.setLegendItemShape((java.awt.Shape)var66);
    int var83 = var34.getBackgroundImageAlignment();
    java.awt.Font var84 = var34.getLabelFont();
    var27.setLegendTextFont(68, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = var0.getRangeCrosshairStroke();
//     var0.setAnchorValue(0.025d, false);
//     var0.zoom(4.0d);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var1 = var0.clone();
//     long var2 = var0.getSegmentsExcludedSize();
//     long var3 = var0.getSegmentsGroupSize();
//     long var4 = var0.getStartTime();
//     long var6 = var0.getTimeFromLong(1388563200000L);
//     java.util.Date var7 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var8 = var0.getSegment(var7);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    double var3 = var1.getMaximumLabelWidth();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var1.setURLGenerator(var4);
    var1.setForegroundAlpha(0.5f);
    java.awt.Paint var8 = var1.getLabelOutlinePaint();
    java.awt.Paint var9 = var1.getBaseSectionOutlinePaint();
    java.awt.Font var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    java.lang.String var3 = var1.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var11 = var10.getBaseItemLabelPaint();
    var9.setBaseFillPaint(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
    var4.setRangeGridlinePaint(var11);
    var4.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
    java.lang.Object var21 = null;
    boolean var22 = var20.equals(var21);
    var4.setAxisOffset(var20);
    var1.setLabelInsets(var20, true);
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.data.time.TimeSeries var7 = null;
    org.jfree.data.time.TimeSeriesCollection var8 = new org.jfree.data.time.TimeSeriesCollection(var7);
    org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
    var10.setAutoTickUnitSelection(true);
    var10.resizeRange(0.05d, (-1.0d));
    boolean var16 = var10.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, (org.jfree.chart.axis.ValueAxis)var10, var17);
    java.lang.String var19 = var18.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var22 = var21.getBaseItemLabelPaint();
    var20.setBaseFillPaint(var22);
    org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder(var22);
    var18.setRadiusGridlinePaint(var22);
    java.awt.Paint var26 = var18.getRadiusGridlinePaint();
    var5.setDomainGridlinePaint(var26);
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(3.0d, 0.0d);
    var5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var30, true);
    java.awt.Paint var33 = var30.getBaseFillPaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var35 = var34.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var40 = var36.isItemLabelVisible(0, (-1), true);
    boolean var41 = var35.equals((java.lang.Object)var36);
    var36.setBaseCreateEntities(true, false);
    var36.setShapesFilled(true);
    boolean var47 = var36.getBaseSeriesVisible();
    java.awt.Stroke var48 = var36.getBaseOutlineStroke();
    java.awt.Color var51 = java.awt.Color.getColor("DateTickUnitType.DAY", (-2));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem(var0, "12/31/69 4:00 PM", "JFreeChartEntity: tooltip = null", "UnitType.ABSOLUTE", var4, var33, var48, (java.awt.Paint)var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Polar Plot"+ "'", var19.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.clear();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
    org.jfree.chart.util.SortOrder var4 = var2.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var5 = var2.getColumnRenderingOrder();
    var0.sortByKeys(var5);
    var0.setValue((java.lang.Comparable)(byte)0, 2.0d);
    org.jfree.data.xy.XYDataItem var13 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var15 = var13.compareTo((java.lang.Object)100.0f);
    var13.setY(8.0d);
    var0.insertValue(0, (java.lang.Comparable)8.0d, Double.NEGATIVE_INFINITY);
    var0.addValue((java.lang.Comparable)(-1), (java.lang.Number)(-6291476));
    org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)100.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    org.jfree.chart.urls.XYURLGenerator var5 = var1.getURLGenerator(100, 100, false);
    java.text.DateFormat var8 = null;
    java.text.DateFormat var9 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("VerticalAlignment.CENTER", var8, var9);
    java.lang.String var11 = var10.getNullYString();
    var1.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var10, false);
    java.text.DateFormat var14 = var10.getXDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "null"+ "'", var11.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var3.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     boolean var10 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var12 = var11.getBaseStroke();
//     var5.setBaseStroke(var12, false);
//     var0.setRangeCrosshairStroke(var12);
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var18 = var0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var20 = var19.getLegendItems();
//     org.jfree.chart.util.SortOrder var21 = var19.getColumnRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxisForDataset(0);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var28 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var29 = var28.getAlpha();
//     int var30 = var28.getTransparency();
//     boolean var31 = var24.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
//     var32.setSeriesToolTipGenerator(0, var34, true);
//     boolean var37 = var32.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var39 = var32.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var40.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var46 = var42.isItemLabelVisible(0, (-1), true);
//     boolean var47 = var41.equals((java.lang.Object)var42);
//     var32.setPositiveItemLabelPositionFallback(var41);
//     java.awt.Paint var50 = var32.lookupSeriesFillPaint(2147483647);
//     var24.setLabelPaint(var50);
//     org.jfree.chart.axis.DateTickUnit var52 = var24.getTickUnit();
//     org.jfree.chart.renderer.xy.XYBarRenderer var53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var54 = var53.getBaseStroke();
//     double var55 = var53.getShadowXOffset();
//     boolean var56 = var53.getAutoPopulateSeriesOutlinePaint();
//     boolean var60 = var53.getItemCreateEntity(13, 100, true);
//     org.jfree.data.xy.DefaultXYDataset var61 = new org.jfree.data.xy.DefaultXYDataset();
//     org.jfree.data.time.TimeSeries var62 = null;
//     java.util.TimeZone var63 = null;
//     org.jfree.data.time.TimeSeriesCollection var64 = new org.jfree.data.time.TimeSeriesCollection(var62, var63);
//     org.jfree.data.Range var66 = var64.getDomainBounds(true);
//     org.jfree.data.Range var67 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     java.lang.String[] var69 = org.jfree.data.time.SerialDate.getMonths(false);
//     boolean var70 = var64.equals((java.lang.Object)var69);
//     org.jfree.data.general.SeriesChangeEvent var71 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var69);
//     var61.seriesChanged(var71);
//     org.jfree.data.Range var73 = var53.findDomainBounds((org.jfree.data.xy.XYDataset)var61);
//     org.jfree.data.general.DatasetChangeEvent var74 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var52, (org.jfree.data.general.Dataset)var61);
//     var19.datasetChanged(var74);
//     org.jfree.data.general.Dataset var76 = var74.getDataset();
//     var0.datasetChanged(var74);
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var41
//     assertTrue("Contract failed: equals-hashcode on var4 and var41", var4.equals(var41) ? var4.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var4
//     assertTrue("Contract failed: equals-hashcode on var41 and var4", var41.equals(var4) ? var41.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("VerticalAlignment.CENTER", var1, var2);
    java.lang.String var4 = var3.getNullYString();
    java.lang.Object var5 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "null"+ "'", var4.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var7 = var3.getDomainBounds(true);
    org.jfree.data.time.TimePeriodAnchor var8 = var3.getXPosition();
    org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
    var10.setAutoTickUnitSelection(true);
    boolean var13 = var10.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var15 = var14.getLegendItems();
    org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var17.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var23 = var19.isItemLabelVisible(0, (-1), true);
    boolean var24 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var26 = var25.getBaseStroke();
    var19.setBaseStroke(var26, false);
    var14.setRangeCrosshairStroke(var26);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var32 = var14.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var31);
    var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
    org.jfree.chart.plot.CombinedDomainXYPlot var34 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var10);
    java.awt.Stroke var35 = var34.getDomainCrosshairStroke();
    org.jfree.chart.util.RectangleEdge var36 = var34.getDomainAxisEdge();
    var3.addChangeListener((org.jfree.data.general.DatasetChangeListener)var34);
    org.jfree.data.xy.DefaultXYDataset var39 = new org.jfree.data.xy.DefaultXYDataset();
    int var40 = var39.getSeriesCount();
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var42 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var41, (org.jfree.data.Range)var42);
    boolean var44 = var39.equals((java.lang.Object)var41);
    var39.removeSeries((java.lang.Comparable)' ');
    int var48 = var39.indexOf((java.lang.Comparable)4.0d);
    org.jfree.data.xy.XYDatasetSelectionState var49 = var39.getSelectionState();
    var34.setDataset(13, (org.jfree.data.xy.XYDataset)var39);
    org.jfree.chart.LegendItemCollection var51 = var34.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getRangeGridlineStroke();
    org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
    var28.setAutoTickUnitSelection(true);
    boolean var31 = var28.isAutoTickUnitSelection();
    java.awt.Paint var32 = var28.getLabelPaint();
    boolean var33 = var28.isAxisLineVisible();
    org.jfree.data.Range var34 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var28);
    java.lang.Object var35 = var25.clone();
    int var36 = var25.getWeight();
    java.awt.Paint var37 = var25.getDomainTickBandPaint();
    org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    var41.setEndValue((-1.0d));
    java.awt.Paint var44 = var41.getPaint();
    org.jfree.chart.util.RectangleAnchor var45 = var41.getLabelAnchor();
    org.jfree.chart.util.GradientPaintTransformer var46 = var41.getGradientPaintTransformer();
    org.jfree.chart.util.Layer var47 = null;
    boolean var49 = var25.removeRangeMarker(255, (org.jfree.chart.plot.Marker)var41, var47, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    var2.setAutoTickUnitSelection(true);
    boolean var5 = var2.isAutoTickUnitSelection();
    var2.resizeRange(0.05d);
    java.awt.Font var8 = var2.getLabelFont();
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("hi!", var8);
    org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
    var12.setAutoTickUnitSelection(true);
    boolean var15 = var12.isAutoTickUnitSelection();
    var12.resizeRange(0.05d);
    java.awt.Font var18 = var12.getLabelFont();
    org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("hi!", var18);
    org.jfree.chart.text.TextFragment var20 = var19.getLastTextFragment();
    var9.removeFragment(var20);
    org.jfree.data.time.TimeSeries var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var22);
    int var25 = var23.indexOf((java.lang.Comparable)86400000L);
    org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
    var27.setAutoTickUnitSelection(true);
    var27.resizeRange(0.05d, (-1.0d));
    var27.configure();
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var23, (org.jfree.chart.axis.ValueAxis)var27, var34);
    boolean var36 = var9.equals((java.lang.Object)var27);
    org.jfree.chart.text.TextFragment var37 = var9.getFirstTextFragment();
    org.jfree.chart.text.TextFragment var38 = var9.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var31 = var30.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var31);
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(100, (-1), false);
    boolean var38 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var42 = var33.getItemFillPaint(100, (-1), true);
    var25.setRangeZeroBaselinePaint(var42);
    org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    java.awt.Paint var48 = var47.getLabelPaint();
    org.jfree.chart.util.Layer var49 = null;
    boolean var51 = var25.removeRangeMarker(5, (org.jfree.chart.plot.Marker)var47, var49, true);
    org.jfree.chart.axis.AxisLocation var52 = var25.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.getSeparatorsVisible();
    java.awt.Paint var3 = var1.getSeparatorPaint();
    boolean var4 = var1.getSectionOutlinesVisible();
    org.jfree.chart.axis.LogAxis var6 = new org.jfree.chart.axis.LogAxis("");
    var6.setAutoTickUnitSelection(true);
    var6.setMinorTickCount(1);
    org.jfree.chart.event.AxisChangeEvent var11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var6);
    var1.axisChanged(var11);
    org.jfree.chart.axis.Axis var13 = var11.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    java.lang.Boolean var4 = var1.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var8 = var7.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("", var8);
    var1.setBaseItemLabelFont(var8, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var14 = var13.getXFormat();
    var1.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var13);
    org.jfree.chart.urls.StandardXYURLGenerator var17 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1, (org.jfree.chart.labels.XYToolTipGenerator)var13, (org.jfree.chart.urls.XYURLGenerator)var17);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
    org.jfree.chart.entity.PlotEntity var24 = new org.jfree.chart.entity.PlotEntity(var21, (org.jfree.chart.plot.Plot)var23);
    double var25 = var23.getLabelGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var26 = var23.getLabelGenerator();
    org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var30 = var29.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
    var23.handleClick((-1), 100, var31);
    int var33 = var23.getBackgroundImageAlignment();
    java.awt.Paint var34 = var23.getLabelShadowPaint();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("[size=100]", var34);
    org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10);
    boolean var40 = var37.equals((java.lang.Object)var39);
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10);
    boolean var45 = var42.equals((java.lang.Object)var44);
    org.jfree.chart.util.GradientPaintTransformer var46 = var44.getGradientTransformer();
    var39.setGradientTransformer(var46);
    var35.setFillPaintTransformer(var46);
    var18.setGradientTransformer(var46);
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var51 = null;
    java.util.TimeZone var52 = null;
    org.jfree.data.time.TimeSeriesCollection var53 = new org.jfree.data.time.TimeSeriesCollection(var51, var52);
    org.jfree.chart.title.LegendItemBlockContainer var55 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var50, (org.jfree.data.general.Dataset)var53, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var57 = var53.getDomainBounds(true);
    org.jfree.data.time.TimePeriodAnchor var58 = var53.getXPosition();
    org.jfree.data.Range var59 = var18.findRangeBounds((org.jfree.data.xy.XYDataset)var53);
    java.awt.Paint var63 = var18.getItemFillPaint((-6291476), 0, true);
    boolean var64 = var18.getPlotArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var0.setShadowXOffset((-1.0d));
    var0.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setBaseSeriesVisibleInLegend(false);
    double var9 = var0.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 8.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    var1.handleClick(10, 0, var5);
    java.awt.Paint var7 = var1.getShadowPaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var10 = var9.getBaseItemLabelPaint();
    var8.setBaseFillPaint(var10);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(var10);
    var1.setLabelBackgroundPaint(var10);
    java.lang.String[] var16 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var17 = new org.jfree.chart.axis.SymbolAxis("hi!", var16);
    org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
    var19.setAutoTickUnitSelection(true);
    boolean var22 = var19.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var19.setTickUnit(var24, false, true);
    var17.setTickUnit(var24, false, true);
    org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var33 = var32.getChartArea();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.entity.PieSectionEntity var40 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var33, var34, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var42 = var41.getLegendItems();
    var41.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var44 = null;
    int var45 = var41.indexOf(var44);
    org.jfree.chart.util.RectangleEdge var46 = var41.getDomainAxisEdge();
    boolean var47 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var46);
    double var48 = var17.valueToJava2D(0.05d, var33, var46);
    var1.setLegendItemShape((java.awt.Shape)var33);
    double var50 = var1.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0E-5d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    var0.setSeriesPaint(100, var23, true);
    java.awt.Shape var30 = var0.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var31.setSeriesToolTipGenerator(0, var33, true);
    boolean var36 = var31.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    var31.setPositiveItemLabelPositionFallback(var40);
    java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
    org.jfree.chart.entity.LegendItemEntity var51 = new org.jfree.chart.entity.LegendItemEntity(var30);
    java.lang.Object var52 = var51.clone();
    java.lang.String var53 = var51.toString();
    java.awt.Shape var54 = var51.getArea();
    java.lang.String var55 = var51.toString();
    org.jfree.chart.plot.CrosshairState var57 = new org.jfree.chart.plot.CrosshairState(true);
    boolean var58 = var51.equals((java.lang.Object)var57);
    java.lang.Object var59 = var51.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var53.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var55.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    java.awt.Paint var27 = var19.getRadiusGridlinePaint();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var37 = var36.getBaseItemLabelPaint();
    var35.setBaseFillPaint(var37);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var35.setBaseStroke(var48);
    var34.setAxisLineStroke(var48);
    var31.setLabelOutlineStroke(var48);
    java.awt.Paint var54 = var31.getLabelOutlinePaint();
    boolean var55 = org.jfree.chart.util.PaintUtilities.equal(var27, var54);
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var54);
    var1.setSubtitlePaint(var54);
    java.awt.Paint var58 = var1.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var60 = var59.getLegendItems();
    var59.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var59.rendererChanged(var62);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var59.markerChanged(var64);
    java.awt.Paint var66 = var59.getRangeCrosshairPaint();
    var1.setChartBackgroundPaint(var66);
    org.jfree.chart.util.RectangleInsets var68 = var1.getAxisOffset();
    java.awt.Paint var69 = var1.getErrorIndicatorPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var5, (org.jfree.chart.plot.Plot)var7);
    var1.setPlot((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var7.setURLGenerator(var10);
    var7.setCircular(false, true);
    boolean var15 = var7.isNotify();
    java.awt.Paint var16 = var7.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var7 = var5.compareTo((java.lang.Object)100.0f);
    var5.setSelected(false);
    double var10 = var5.getYValue();
    var5.setY(0.025d);
    org.jfree.data.xy.XYDataItem var13 = var2.addOrUpdate(var5);
    boolean var14 = var2.getAllowDuplicateXValues();
    org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    org.jfree.data.xy.XYDataItem var20 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var22 = var20.compareTo((java.lang.Object)100.0f);
    var20.setSelected(false);
    double var25 = var20.getYValue();
    var20.setY(0.025d);
    org.jfree.data.xy.XYDataItem var28 = var17.addOrUpdate(var20);
    java.lang.Object var29 = var20.clone();
    java.lang.String var30 = var20.toString();
    org.jfree.chart.renderer.xy.XYBarRenderer var32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var33 = var32.getBaseStroke();
    java.lang.Boolean var35 = var32.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var39 = var38.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var40 = new org.jfree.chart.block.LabelBlock("", var39);
    var32.setBaseItemLabelFont(var39, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var44 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var45 = var44.getXFormat();
    var32.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var44);
    org.jfree.chart.urls.StandardXYURLGenerator var48 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1, (org.jfree.chart.labels.XYToolTipGenerator)var44, (org.jfree.chart.urls.XYURLGenerator)var48);
    java.lang.Object var50 = var49.clone();
    boolean var53 = var49.getItemVisible(0, 10);
    java.lang.Object var54 = var49.clone();
    boolean var55 = var49.getUseFillPaint();
    java.awt.Shape var56 = var49.getLegendArea();
    boolean var57 = var20.equals((java.lang.Object)var49);
    java.lang.Number var58 = var20.getX();
    var20.setY(6.08d);
    var2.add(var20);
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var63 = var62.getLegendItems();
    org.jfree.chart.util.SortOrder var64 = var62.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var65 = var62.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var69 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var70 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var71 = var70.getBaseItemLabelPaint();
    var69.setBaseFillPaint(var71);
    org.jfree.chart.block.BlockBorder var73 = new org.jfree.chart.block.BlockBorder(var71);
    org.jfree.chart.plot.IntervalMarker var74 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var71);
    org.jfree.chart.util.Layer var75 = null;
    boolean var77 = var62.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var74, var75, false);
    org.jfree.chart.util.LengthAdjustmentType var78 = var74.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var79 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var74);
    int var80 = var20.compareTo((java.lang.Object)var79);
    java.lang.Object var81 = var20.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "[0.0, 0.025]"+ "'", var30.equals("[0.0, 0.025]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + 0+ "'", var58.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     org.jfree.chart.renderer.xy.XYBarPainter var5 = var0.getBarPainter();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var0.getPositiveItemLabelPosition(2147483647, 0, true);
//     org.jfree.data.time.TimeSeries var10 = null;
//     java.util.TimeZone var11 = null;
//     org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection(var10, var11);
//     org.jfree.data.Range var14 = var12.getDomainBounds(true);
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var12);
//     var12.clearSelection();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("black");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var21 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     var20.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var21, true);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var24.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.urls.XYURLGenerator var26 = var24.getBaseURLGenerator();
//     boolean var27 = var21.equals((java.lang.Object)var24);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var12, var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.xy.XYItemRenderer)var24);
//     org.jfree.data.Range var29 = var0.findDomainBounds((org.jfree.data.xy.XYDataset)var12);
//     org.jfree.data.time.TimeSeries var30 = null;
//     java.util.TimeZone var31 = null;
//     org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var30, var31);
//     org.jfree.data.Range var34 = var32.getDomainBounds(true);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     long var36 = var35.getMiddleMillisecond();
//     java.util.Date var37 = var35.getEnd();
//     org.jfree.data.time.TimeSeries var38 = var32.getSeries((java.lang.Comparable)var35);
//     org.jfree.data.DefaultKeyedValues var39 = new org.jfree.data.DefaultKeyedValues();
//     var39.clear();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var42 = var41.getLegendItems();
//     org.jfree.chart.util.SortOrder var43 = var41.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var44 = var41.getColumnRenderingOrder();
//     var39.sortByKeys(var44);
//     org.jfree.data.category.CategoryDataset var46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var35, (org.jfree.data.KeyedValues)var39);
//     org.jfree.data.Range var48 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var46, false);
//     org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var46, 90.0d);
//     org.jfree.data.general.PieDataset var52 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var46, 255);
//     org.jfree.data.general.PieDataset var54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var46, (java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.PiePlot var55 = new org.jfree.chart.plot.PiePlot(var54);
//     org.jfree.data.general.DefaultPieDataset var56 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var54);
//     java.util.List var57 = var56.getKeys();
//     org.jfree.data.time.DateRange var58 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var59 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var58, (org.jfree.data.Range)var59);
//     java.util.Date var61 = var58.getLowerDate();
//     int var62 = var56.getIndex((java.lang.Comparable)var61);
//     org.jfree.data.time.TimeSeries var63 = var12.getSeries((java.lang.Comparable)var61);
//     
//     // Checks the contract:  equals-hashcode on var12 and var32
//     assertTrue("Contract failed: equals-hashcode on var12 and var32", var12.equals(var32) ? var12.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var12
//     assertTrue("Contract failed: equals-hashcode on var32 and var12", var32.equals(var12) ? var32.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    boolean var2 = var1.isShapeFilled();
    java.lang.String var3 = var1.getLabel();
    java.awt.Paint var4 = var1.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(5);
    org.jfree.data.xy.DefaultXYDataset var4 = new org.jfree.data.xy.DefaultXYDataset();
    int var5 = var4.getSeriesCount();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var6, (org.jfree.data.Range)var7);
    boolean var9 = var4.equals((java.lang.Object)var6);
    org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var10, (org.jfree.data.Range)var11);
    org.jfree.chart.block.LengthConstraintType var13 = var12.getWidthConstraintType();
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var16, (org.jfree.data.Range)var17);
    org.jfree.chart.block.LengthConstraintType var19 = var18.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var6, var13, 0.0d, (org.jfree.data.Range)var15, var19);
    org.jfree.data.xy.DefaultXYDataset var21 = new org.jfree.data.xy.DefaultXYDataset();
    int var22 = var21.getSeriesCount();
    org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var23, (org.jfree.data.Range)var24);
    boolean var26 = var21.equals((java.lang.Object)var23);
    boolean var27 = var15.intersects((org.jfree.data.Range)var23);
    java.util.Date var28 = var15.getLowerDate();
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var34 = var33.getAlpha();
    int var35 = var33.getTransparency();
    boolean var36 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
    java.awt.Paint var43 = var37.getSeriesFillPaint(100);
    java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
    var29.setAxisLineStroke(var45);
    java.util.TimeZone var47 = var29.getTimeZone();
    org.jfree.chart.axis.TickUnitSource var48 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var47);
    org.jfree.data.time.TimeSeriesCollection var49 = new org.jfree.data.time.TimeSeriesCollection(var47);
    org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(var28, var47);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var28);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, var51);
    var51.setDescription("java.awt.Color[r=0,g=0,b=100]");
    boolean var55 = var1.isOnOrBefore(var51);
    java.lang.String var56 = var51.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + "java.awt.Color[r=0,g=0,b=100]"+ "'", var56.equals("java.awt.Color[r=0,g=0,b=100]"));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    boolean var8 = var5.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var5.setTickUnit(var10, false, true);
    var3.setTickUnit(var10, false, true);
    var3.resizeRange2(Double.NEGATIVE_INFINITY, 4.0d);
    java.lang.String[] var22 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
    org.jfree.chart.axis.LogAxis var25 = new org.jfree.chart.axis.LogAxis("");
    var25.setAutoTickUnitSelection(true);
    boolean var28 = var25.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var25.setTickUnit(var30, false, true);
    var23.setTickUnit(var30, false, true);
    org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var39 = var38.getChartArea();
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.entity.PieSectionEntity var46 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var39, var40, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var48 = var47.getLegendItems();
    var47.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var50 = null;
    int var51 = var47.indexOf(var50);
    org.jfree.chart.util.RectangleEdge var52 = var47.getDomainAxisEdge();
    boolean var53 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var52);
    double var54 = var23.valueToJava2D(0.05d, var39, var52);
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var39, (-3.0d), 2.0f, 10.0f);
    var3.setRightArrow((java.awt.Shape)var39);
    java.lang.String[] var63 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var64 = new org.jfree.chart.axis.SymbolAxis("hi!", var63);
    org.jfree.chart.axis.SymbolAxis var65 = new org.jfree.chart.axis.SymbolAxis("java.awt.Color[r=255,g=255,b=255]", var63);
    org.jfree.chart.axis.NumberTickUnit var67 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var65.setTickUnit(var67, false, true);
    java.lang.String var71 = var67.toString();
    var3.setTickUnit(var67, false, true);
    org.jfree.chart.axis.NumberTickUnit var75 = var3.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + "[size=100]"+ "'", var71.equals("[size=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var6 = var3.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var12 = var11.getBaseItemLabelPaint();
    var10.setBaseFillPaint(var12);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var12);
    org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var12);
    org.jfree.chart.util.Layer var16 = null;
    boolean var18 = var3.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var15, var16, false);
    float var19 = var15.getAlpha();
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var23 = var22.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("hi!", var23);
    org.jfree.chart.util.RectangleAnchor var25 = var24.getTextAnchor();
    var15.setLabelAnchor(var25);
    java.awt.geom.Rectangle2D var27 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 0.47712125471966244d, var25);
    java.io.ObjectOutputStream var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape)var27, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)(byte)10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var7 = var4.getFixedRangeAxisSpace();
    var4.clearDomainMarkers();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var9.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var15 = var11.isItemLabelVisible(0, (-1), true);
    boolean var16 = var10.equals((java.lang.Object)var11);
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var18 = var17.getBaseStroke();
    var11.setBaseStroke(var18, false);
    var4.setDomainCrosshairStroke(var18);
    org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var25 = var24.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var26 = var24.getPlotInfo();
    java.awt.geom.Point2D var27 = null;
    var4.zoomDomainAxes(3.0d, 3.0d, var26, var27);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var31 = var30.getLegendItems();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var36 = var35.getBaseItemLabelPaint();
    var34.setBaseFillPaint(var36);
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var36);
    org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var36);
    boolean var40 = var30.removeDomainMarker((org.jfree.chart.plot.Marker)var39);
    java.lang.String var41 = var39.getLabel();
    var39.setStartValue(10.0d);
    org.jfree.chart.util.Layer var44 = null;
    var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var39, var44, true);
    boolean var47 = var1.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.CategoryAxis var49 = var4.getDomainAxis(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     double var2 = var1.getMaxY();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     long var4 = var3.getMiddleMillisecond();
//     java.util.Date var5 = var3.getStart();
//     java.lang.String var6 = var3.toString();
//     org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder();
//     boolean var8 = var3.equals((java.lang.Object)var7);
//     var1.add((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)10.0f, false);
//     var1.removeAgedItems(true);
//     var1.clear();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 3.0d);
//     boolean var18 = var17.isSelected();
//     var1.add(var17);
//     java.util.List var20 = var1.getItems();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"poly");
//     org.jfree.data.time.TimeSeries var23 = var1.addAndOrUpdate(var22);
//     var22.setMaximumItemCount(0);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     long var32 = var31.getMiddleMillisecond();
//     java.util.Date var33 = var31.getStart();
//     java.util.Date var34 = var31.getEnd();
//     var26.setAggregatedItemsKey((java.lang.Comparable)var31);
//     java.lang.Number var36 = var22.getValue((org.jfree.data.time.RegularTimePeriod)var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "December 2014"+ "'", var6.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     java.util.List var5 = var0.getSeries();
//     double var7 = var0.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.getYValue(10, 2);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.lang.Boolean var6 = var0.getSeriesItemLabelsVisible(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var11 = var7.isItemLabelVisible(0, (-1), true);
//     var7.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var19 = var7.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var20 = null;
//     java.util.TimeZone var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var20, var21);
//     org.jfree.data.Range var24 = var22.getDomainBounds(true);
//     org.jfree.data.Range var25 = var7.findDomainBounds((org.jfree.data.xy.XYDataset)var22);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var7.getPositiveItemLabelPosition(0, (-1), true);
//     var0.setNegativeItemLabelPositionFallback(var29);
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
//     var32.setSeriesToolTipGenerator(0, var34, true);
//     boolean var37 = var32.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var38 = var32.getPositiveItemLabelPositionFallback();
//     var32.setItemMargin(3.0d);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = null;
//     var32.setBaseItemLabelGenerator(var41);
//     java.awt.Paint var44 = null;
//     var32.setSeriesPaint(13, var44);
//     var32.setBase(1.0E-8d);
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var49.setShadowXOffset((-1.0d));
//     org.jfree.chart.renderer.xy.XYBarRenderer var52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var56 = var52.getURLGenerator(100, (-1), false);
//     java.awt.Paint var58 = var52.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var59 = null;
//     var52.setLegendItemToolTipGenerator(var59);
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var62 = var61.getLegendItems();
//     org.jfree.chart.util.SortOrder var63 = var61.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var64 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var65 = var64.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var70 = var66.isItemLabelVisible(0, (-1), true);
//     boolean var71 = var65.equals((java.lang.Object)var66);
//     org.jfree.chart.renderer.xy.XYBarRenderer var72 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var73 = var72.getBaseStroke();
//     var66.setBaseStroke(var73, false);
//     var61.setRangeCrosshairStroke(var73);
//     var52.addChangeListener((org.jfree.chart.event.RendererChangeListener)var61);
//     org.jfree.chart.renderer.category.BarRenderer3D var78 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var78.setShadowXOffset((-1.0d));
//     var78.setDrawBarOutline(false);
//     org.jfree.chart.labels.ItemLabelPosition var84 = var78.getSeriesNegativeItemLabelPosition(0);
//     var52.setBasePositiveItemLabelPosition(var84, false);
//     var49.setPositiveItemLabelPositionFallback(var84);
//     var32.setSeriesNegativeItemLabelPosition(12, var84, true);
//     var0.setSeriesPositiveItemLabelPosition(15, var84);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var64 and var7.", var64.equals(var7) == var7.equals(var64));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var7.", var66.equals(var7) == var7.equals(var66));
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    var2.setAutoTickUnitSelection(true);
    var2.resizeRange(0.05d, (-1.0d));
    org.jfree.data.xy.DefaultXYDataset var9 = new org.jfree.data.xy.DefaultXYDataset();
    int var10 = var9.getSeriesCount();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var11, (org.jfree.data.Range)var12);
    boolean var14 = var9.equals((java.lang.Object)var11);
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var15, (org.jfree.data.Range)var16);
    org.jfree.chart.block.LengthConstraintType var18 = var17.getWidthConstraintType();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var21, (org.jfree.data.Range)var22);
    org.jfree.chart.block.LengthConstraintType var24 = var23.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var11, var18, 0.0d, (org.jfree.data.Range)var20, var24);
    var2.setRangeWithMargins((org.jfree.data.Range)var11, true, false);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var31 = var29.getDataset(10);
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var29.getDomainMarkers(10, var33);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
    org.jfree.data.Range var36 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var2);
    var0.setGap((-3.0d));
    java.awt.Stroke var39 = var0.getRangeMinorGridlineStroke();
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.plot.IntervalMarker var44 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    boolean var45 = var41.equals((java.lang.Object)var44);
    org.jfree.chart.util.Layer var46 = null;
    boolean var48 = var0.removeDomainMarker((-6291476), (org.jfree.chart.plot.Marker)var44, var46, false);
    java.lang.Object var49 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    org.jfree.chart.util.StandardGradientPaintTransformer var4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var4);
    org.jfree.data.time.TimeSeries var6 = null;
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var6);
    org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
    var9.setAutoTickUnitSelection(true);
    var9.resizeRange(0.05d, (-1.0d));
    boolean var15 = var9.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var16 = null;
    org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, (org.jfree.chart.axis.ValueAxis)var9, var16);
    java.awt.Paint var18 = var17.getAngleLabelPaint();
    var1.setLabelPaint(var18);
    boolean var20 = var1.isShapeVisible();
    boolean var21 = var1.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(1057694400000L, (-16777216), 12);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(28, (-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var31 = var30.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var31);
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(100, (-1), false);
    boolean var38 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var42 = var33.getItemFillPaint(100, (-1), true);
    var25.setRangeZeroBaselinePaint(var42);
    java.awt.Paint var44 = var25.getRangeTickBandPaint();
    org.jfree.chart.axis.AxisSpace var45 = var25.getFixedDomainAxisSpace();
    java.util.List var46 = var25.getSubplots();
    boolean var47 = var25.isDomainCrosshairLockedOnData();
    java.awt.Stroke var48 = var25.getRangeCrosshairStroke();
    var25.setBackgroundAlpha((-1.0f));
    java.awt.Font var51 = var25.getNoDataMessageFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.urls.PieURLGenerator var1 = var0.getURLGenerator();
    var0.setSectionOutlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("Polar Plot");
    boolean var6 = var0.equals((java.lang.Object)"Polar Plot");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.entity.PlotEntity var11 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var10);
    double var12 = var10.getLabelGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = var10.getLabelGenerator();
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    var10.handleClick((-1), 100, var18);
    var10.setBackgroundImageAlignment(1);
    double var22 = var10.getMaximumLabelWidth();
    double var23 = var10.getLabelGap();
    double var24 = var10.getLabelLinkMargin();
    boolean var25 = var0.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(5);
    java.util.Date var2 = var1.toDate();
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
    java.lang.Object var4 = null;
    int var5 = var3.compareTo(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var1.markerChanged(var3);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var9 = var5.isItemLabelVisible(0, (-1), true);
    var5.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
    org.jfree.chart.axis.LogAxis var16 = new org.jfree.chart.axis.LogAxis("");
    var16.setAutoTickUnitSelection(true);
    var16.resizeRange(0.05d, (-1.0d));
    boolean var22 = var16.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var23 = null;
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, (org.jfree.chart.axis.ValueAxis)var16, var23);
    java.lang.String var25 = var24.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var28 = var27.getBaseItemLabelPaint();
    var26.setBaseFillPaint(var28);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var28);
    var24.setRadiusGridlinePaint(var28);
    var5.setSeriesPaint(100, var28, true);
    var1.setBaseSectionOutlinePaint(var28);
    java.awt.Paint var35 = var1.getLabelPaint();
    org.jfree.chart.labels.StandardPieToolTipGenerator var36 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    org.jfree.data.general.PieDataset var37 = null;
    java.lang.String var39 = var36.generateToolTip(var37, (java.lang.Comparable)10.0f);
    java.lang.Object var40 = var36.clone();
    var1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator)var36);
    java.lang.Object var42 = var36.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Polar Plot"+ "'", var25.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(15, (java.lang.Boolean)false);
    int var27 = var22.getPassCount();
    java.awt.Font var29 = var22.lookupLegendTextFont((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    double var5 = var3.getLabelGap();
    double var6 = var3.getLabelGap();
    var3.setLabelLinkMargin(4.0d);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    java.awt.Paint var13 = var12.getLabelPaint();
    var10.setLabelPaint(var13);
    var3.setOutlinePaint(var13);
    double var16 = var3.getInteriorGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.08d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.awt.Stroke var2 = null;
    var0.setStroke(1, var2);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var5 = var4.getCategories();
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.util.Layer var10 = null;
    var4.addRangeMarker(13, (org.jfree.chart.plot.Marker)var9, var10);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    var13.setSeriesKey((java.lang.Comparable)10.0d);
    org.jfree.chart.util.StandardGradientPaintTransformer var16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var16);
    var9.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var16);
    boolean var19 = var0.equals((java.lang.Object)var9);
    org.jfree.chart.axis.LogAxis var21 = new org.jfree.chart.axis.LogAxis("");
    var21.setAutoTickUnitSelection(true);
    boolean var24 = var21.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var26 = var25.getLegendItems();
    org.jfree.chart.util.SortOrder var27 = var25.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var29 = var28.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var34 = var30.isItemLabelVisible(0, (-1), true);
    boolean var35 = var29.equals((java.lang.Object)var30);
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var37 = var36.getBaseStroke();
    var30.setBaseStroke(var37, false);
    var25.setRangeCrosshairStroke(var37);
    org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var43 = var25.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var42);
    var21.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var25);
    org.jfree.chart.plot.CombinedDomainXYPlot var45 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var21);
    java.awt.Stroke var46 = var45.getDomainCrosshairStroke();
    boolean var47 = var45.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var51 = var50.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var52 = new org.jfree.chart.block.LabelBlock("", var51);
    org.jfree.chart.renderer.xy.XYBarRenderer var53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var57 = var53.getURLGenerator(100, (-1), false);
    boolean var58 = var52.equals((java.lang.Object)var53);
    java.awt.Paint var62 = var53.getItemFillPaint(100, (-1), true);
    var45.setRangeZeroBaselinePaint(var62);
    java.awt.Paint var64 = var45.getRangeTickBandPaint();
    org.jfree.chart.axis.ValueAxis var66 = var45.getRangeAxis(28);
    boolean var67 = var0.equals((java.lang.Object)var45);
    org.jfree.chart.plot.CombinedRangeXYPlot var68 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.axis.LogAxis var70 = new org.jfree.chart.axis.LogAxis("");
    var70.setAutoTickUnitSelection(true);
    var70.resizeRange(0.05d, (-1.0d));
    boolean var76 = var70.isVerticalTickLabels();
    java.text.NumberFormat var77 = var70.getNumberFormatOverride();
    org.jfree.chart.axis.ValueAxis[] var78 = new org.jfree.chart.axis.ValueAxis[] { var70};
    var68.setDomainAxes(var78);
    java.lang.Object var80 = var68.clone();
    org.jfree.chart.plot.DatasetRenderingOrder var81 = var68.getDatasetRenderingOrder();
    var45.setDatasetRenderingOrder(var81);
    org.jfree.data.xy.XYDataset var83 = var45.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    double var3 = var2.getLimit();
    double var4 = var2.getLimit();
    org.jfree.chart.JFreeChart var5 = var2.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
    java.lang.Object var9 = var5.clone();
    boolean var10 = var5.isNotify();
    org.jfree.chart.title.LegendTitle var11 = var5.getLegend();
    var5.removeLegend();
    java.awt.Paint var13 = null;
    var5.setBorderPaint(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var15 = var5.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    java.lang.Boolean var12 = var0.getSeriesCreateEntities(0);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getBasePositiveItemLabelPosition();
    org.jfree.data.time.TimeSeries var14 = null;
    java.util.TimeZone var15 = null;
    org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14, var15);
    org.jfree.data.Range var17 = var0.findDomainBounds((org.jfree.data.xy.XYDataset)var16);
    java.util.List var18 = var16.getSeries();
    org.jfree.data.time.TimeSeries var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.removeSeries(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     java.lang.String var12 = var11.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     var13.setBaseFillPaint(var15);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
//     var11.setRadiusGridlinePaint(var15);
//     java.awt.Paint var19 = var11.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var11.datasetChanged(var20);
//     boolean var22 = var11.isRadiusGridlinesVisible();
//     var11.setRadiusGridlinesVisible(false);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     long var32 = var31.getMiddleMillisecond();
//     java.util.Date var33 = var31.getStart();
//     java.util.Date var34 = var31.getEnd();
//     var26.setAggregatedItemsKey((java.lang.Comparable)var31);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var36);
//     java.util.TimeZone var38 = var37.getTimeZone();
//     var37.configure();
//     org.jfree.data.Range var40 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     var37.setMinorTickMarksVisible(true);
//     org.jfree.data.time.RegularTimePeriod var43 = var37.getLast();
//     org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var46 = var45.getLimit();
//     double var47 = var45.getLimit();
//     org.jfree.chart.JFreeChart var48 = var45.getPieChart();
//     org.jfree.data.category.CategoryDataset var49 = var45.getDataset();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     long var51 = var50.getMiddleMillisecond();
//     java.util.Date var52 = var50.getStart();
//     java.util.Date var53 = var50.getEnd();
//     var45.setAggregatedItemsKey((java.lang.Comparable)var50);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var56 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var50, (org.jfree.data.time.RegularTimePeriod)var55);
//     java.util.TimeZone var57 = var56.getTimeZone();
//     var56.configure();
//     java.lang.Class var59 = var56.getMajorTickTimePeriodClass();
//     org.jfree.chart.axis.PeriodAxisLabelInfo[] var60 = var56.getLabelInfo();
//     var37.setLabelInfo(var60);
//     
//     // Checks the contract:  equals-hashcode on var26 and var45
//     assertTrue("Contract failed: equals-hashcode on var26 and var45", var26.equals(var45) ? var26.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var26
//     assertTrue("Contract failed: equals-hashcode on var45 and var26", var45.equals(var26) ? var45.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var48
//     assertTrue("Contract failed: equals-hashcode on var29 and var48", var29.equals(var48) ? var29.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var29
//     assertTrue("Contract failed: equals-hashcode on var48 and var29", var48.equals(var29) ? var48.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    var0.setSeriesPaint(100, var23, true);
    java.awt.Shape var30 = var0.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var31.setSeriesToolTipGenerator(0, var33, true);
    boolean var36 = var31.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    var31.setPositiveItemLabelPositionFallback(var40);
    java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
    org.jfree.chart.entity.LegendItemEntity var51 = new org.jfree.chart.entity.LegendItemEntity(var30);
    java.lang.Object var52 = var51.clone();
    java.lang.String var53 = var51.toString();
    java.awt.Shape var54 = var51.getArea();
    java.lang.String var55 = var51.toString();
    org.jfree.chart.plot.CrosshairState var57 = new org.jfree.chart.plot.CrosshairState(true);
    boolean var58 = var51.equals((java.lang.Object)var57);
    org.jfree.data.general.Dataset var59 = var51.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var53.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var55.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     int var2 = var1.getMaximumLinesToDisplay();
//     java.awt.Paint var3 = var1.getPaint();
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var5 = var4.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var7 = var6.getLimit();
//     double var8 = var6.getLimit();
//     org.jfree.chart.JFreeChart var9 = var6.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var9, (-1), 1);
//     java.lang.Object var13 = var9.clone();
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var9);
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
//     org.jfree.chart.event.TitleChangeEvent var17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var16);
//     var9.addLegend(var16);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.LogAxis var21 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var22 = var21.getLabelInsets();
//     double var24 = var22.calculateLeftInset(0.025d);
//     double var25 = var22.getRight();
//     double var27 = var22.calculateRightInset((-0.975d));
//     java.lang.String var28 = var22.toString();
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var31 = var30.getLowerMargin();
//     var30.setLabel("");
//     org.jfree.chart.renderer.category.BarRenderer3D var36 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = null;
//     var36.setSeriesToolTipGenerator(0, var38, true);
//     boolean var41 = var36.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var42 = var36.getPositiveItemLabelPositionFallback();
//     var36.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var46 = var45.getBaseItemLabelPaint();
//     java.awt.Paint var48 = var45.getSeriesPaint(10);
//     java.awt.Shape var50 = null;
//     var45.setSeriesShape(0, var50, false);
//     var45.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var56 = var55.getChartArea();
//     var45.setBaseShape((java.awt.Shape)var56);
//     boolean var58 = var36.equals((java.lang.Object)var56);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var60 = var59.getLegendItems();
//     var59.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var62 = null;
//     int var63 = var59.indexOf(var62);
//     org.jfree.chart.util.RectangleEdge var64 = var59.getDomainAxisEdge();
//     org.jfree.data.xy.XYDataItem var67 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
//     int var69 = var67.compareTo((java.lang.Object)100.0f);
//     boolean var70 = var64.equals((java.lang.Object)var67);
//     double var71 = var30.getCategoryMiddle(100, 255, var56, var64);
//     java.awt.geom.Rectangle2D var72 = var22.createOutsetRectangle(var56);
//     org.jfree.chart.plot.WaferMapPlot var73 = new org.jfree.chart.plot.WaferMapPlot();
//     float var74 = var73.getForegroundAlpha();
//     org.jfree.chart.block.BlockBorder var75 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var76 = var75.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var77 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var78 = var77.getLimit();
//     double var79 = var77.getLimit();
//     org.jfree.chart.JFreeChart var80 = var77.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var83 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var75, var80, (-1), 1);
//     java.lang.Object var84 = var80.clone();
//     boolean var85 = var80.isNotify();
//     var80.setBackgroundImageAlpha(10.0f);
//     var73.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var80);
//     org.jfree.chart.event.ChartProgressListener var89 = null;
//     var80.removeProgressListener(var89);
//     org.jfree.chart.ChartRenderingInfo var93 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var94 = var93.getChartArea();
//     org.jfree.chart.RenderingSource var95 = var93.getRenderingSource();
//     java.awt.image.BufferedImage var96 = var80.createBufferedImage(5, 1, var93);
//     var9.draw(var19, var72, var93);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
    var31.setAutoTickUnitSelection(true);
    boolean var34 = var31.isAutoTickUnitSelection();
    var31.resizeRange(0.05d);
    java.awt.Font var37 = var31.getLabelFont();
    boolean var38 = var31.isPositiveArrowVisible();
    var25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var31, true);
    var25.setRangePannable(true);
    org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var48 = var47.getLegendItems();
    org.jfree.chart.util.SortOrder var49 = var47.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.util.RectangleAnchor var53 = null;
    java.awt.geom.Point2D var54 = org.jfree.chart.util.RectangleAnchor.coordinates(var52, var53);
    var47.zoomRangeAxes(0.05d, var51, var54, false);
    var44.zoomDomainAxes(0.08d, var46, var54, false);
    org.jfree.chart.ChartRenderingInfo var61 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var62 = var61.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var63 = new org.jfree.chart.plot.PlotRenderingInfo(var61);
    org.jfree.chart.renderer.xy.XYItemRendererState var64 = new org.jfree.chart.renderer.xy.XYItemRendererState(var63);
    java.awt.geom.Rectangle2D var65 = null;
    org.jfree.chart.util.RectangleAnchor var66 = null;
    java.awt.geom.Point2D var67 = org.jfree.chart.util.RectangleAnchor.coordinates(var65, var66);
    var44.zoomDomainAxes(0.025d, 90.0d, var63, var67);
    java.lang.Object var69 = var63.clone();
    java.awt.geom.Point2D var70 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.zoomRangeAxes((-0.975d), var63, var70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(0.14d, "JFreeChartEntity: tooltip = null", "Pie 3D Plot", true);
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(6.0d, (java.text.NumberFormat)var5);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    java.awt.Stroke var8 = var0.lookupSeriesOutlineStroke(100);
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var12 = var11.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("", var12);
    java.lang.String var14 = var13.getToolTipText();
    var13.setToolTipText("");
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    org.jfree.chart.entity.PlotEntity var21 = new org.jfree.chart.entity.PlotEntity(var18, (org.jfree.chart.plot.Plot)var20);
    boolean var22 = var13.equals((java.lang.Object)var18);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    var0.setLegendBar(var18);
    org.jfree.chart.labels.XYItemLabelGenerator var25 = var0.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     org.jfree.data.Range var13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1, true);
//     var1.removeAllSeries();
//     java.util.List var15 = var1.getSeries();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getLegendItems();
//     var16.clearDomainAxes();
//     org.jfree.chart.event.RendererChangeEvent var19 = null;
//     var16.rendererChanged(var19);
//     int var21 = var16.getDomainAxisCount();
//     var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var16);
//     org.jfree.data.xy.XYSeriesCollection var23 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var25 = var23.getRangeBounds(true);
//     double var27 = var23.getDomainLowerBound(true);
//     double var29 = var23.getRangeUpperBound(true);
//     int var30 = var23.getSeriesCount();
//     java.util.List var31 = var23.getSeries();
//     var1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 3.0d);
    var1.add(var4);
    var1.setRangeDescription("hi!");
    var1.clear();
    var1.setMaximumItemAge(644288400000L);
    var1.setDescription("RectangleEdge.BOTTOM");

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    double var4 = var3.getLimit();
    double var5 = var3.getLimit();
    org.jfree.chart.JFreeChart var6 = var3.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var6, (-1), 1);
    java.lang.Object var10 = var6.clone();
    boolean var11 = var6.isNotify();
    org.jfree.chart.title.LegendTitle var12 = var6.getLegend();
    var6.removeLegend();
    java.awt.Paint var14 = null;
    var6.setBorderPaint(var14);
    java.lang.Object var16 = var6.getTextAntiAlias();
    java.awt.RenderingHints var17 = var6.getRenderingHints();
    boolean var18 = var0.equals((java.lang.Object)var17);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
    java.lang.String var20 = var19.getToolTipText();
    org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelInsets();
    double var25 = var23.calculateLeftInset(0.025d);
    double var26 = var23.getRight();
    double var28 = var23.trimWidth(0.0d);
    org.jfree.chart.util.UnitType var29 = var23.getUnitType();
    org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets(var29, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, (-3.0d), 0.2d);
    org.jfree.chart.util.RectangleInsets var39 = new org.jfree.chart.util.RectangleInsets(var29, 2.0d, (-0.975d), Double.NEGATIVE_INFINITY, 8.0d);
    org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets(var29, 0.0d, 0.14d, 10.0d, 0.025d);
    var0.add((org.jfree.chart.block.Block)var19, (java.lang.Object)var44);
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets();
    boolean var47 = var0.equals((java.lang.Object)var46);
    org.jfree.chart.util.UnitType var48 = var46.getUnitType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var0 = new org.jfree.chart.renderer.category.GradientBarPainter();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getStart();
//     java.util.Date var4 = var1.getEnd();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     java.util.Date var7 = var5.getStart();
//     boolean var8 = var0.equals((java.lang.Object)var7);
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var12 = var11.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("", var12);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var15 = var14.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var17 = var16.getLimit();
//     double var18 = var16.getLimit();
//     org.jfree.chart.JFreeChart var19 = var16.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var14, var19, (-1), 1);
//     var13.setFrame((org.jfree.chart.block.BlockFrame)var14);
//     java.awt.Paint var24 = var14.getPaint();
//     boolean var25 = var0.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter)var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("[0.0, 10.0]");
    var1.setToolTipText("[size=1]");

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleAnchor var9 = null;
    java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
    var3.zoomRangeAxes(0.05d, var7, var10, false);
    var0.zoomDomainAxes(0.08d, var2, var10, false);
    org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var18 = var17.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
    org.jfree.chart.renderer.xy.XYItemRendererState var20 = new org.jfree.chart.renderer.xy.XYItemRendererState(var19);
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleAnchor var22 = null;
    java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var22);
    var0.zoomDomainAxes(0.025d, 90.0d, var19, var23);
    org.jfree.chart.axis.LogAxis var26 = new org.jfree.chart.axis.LogAxis("");
    var26.setAutoTickUnitSelection(true);
    boolean var29 = var26.isAutoTickUnitSelection();
    var26.resizeRange(0.05d);
    java.awt.Font var32 = var26.getLabelFont();
    boolean var33 = var26.isPositiveArrowVisible();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
    double var36 = var35.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var35.handleClick(10, 0, var39);
    java.awt.Paint var41 = var35.getShadowPaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var43 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var44 = var43.getBaseItemLabelPaint();
    var42.setBaseFillPaint(var44);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var44);
    var35.setLabelBackgroundPaint(var44);
    var26.setTickLabelPaint(var44);
    double var49 = var26.getAutoRangeMinimumSize();
    java.awt.Stroke var50 = var26.getTickMarkStroke();
    var26.setRange(0.47712125471966244d, Double.POSITIVE_INFINITY);
    org.jfree.data.Range var54 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var26);
    org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var58 = var57.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("", var58);
    org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var64 = var60.getURLGenerator(100, (-1), false);
    boolean var65 = var59.equals((java.lang.Object)var60);
    org.jfree.chart.axis.LogAxis var68 = new org.jfree.chart.axis.LogAxis("");
    var68.setAutoTickUnitSelection(true);
    boolean var71 = var68.isAutoTickUnitSelection();
    var68.resizeRange(0.05d);
    java.awt.Font var74 = var68.getLabelFont();
    org.jfree.chart.text.TextLine var75 = new org.jfree.chart.text.TextLine("hi!", var74);
    var59.setFont(var74);
    var0.setAngleLabelFont(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    boolean var8 = var5.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var5.setTickUnit(var10, false, true);
    var3.setTickUnit(var10, false, true);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var19, var20, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var28 = var27.getLegendItems();
    var27.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var30 = null;
    int var31 = var27.indexOf(var30);
    org.jfree.chart.util.RectangleEdge var32 = var27.getDomainAxisEdge();
    boolean var33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var32);
    double var34 = var3.valueToJava2D(0.05d, var19, var32);
    var3.setFixedAutoRange(0.14d);
    double var37 = var3.getUpperMargin();
    var3.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.05d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    int var7 = var6.getMaximumLinesToDisplay();
    java.awt.Paint var8 = var6.getPaint();
    var0.setBaseItemLabelPaint(var8);
    var0.setBase((-3.0d));
    java.awt.Paint var12 = var0.getBaseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var20 = var19.getBaseStroke();
    var13.setBaseStroke(var20, false);
    var7.setBaseStroke(var20);
    var6.setAxisLineStroke(var20);
    var3.setLabelOutlineStroke(var20);
    org.jfree.data.general.PieDataset var26 = null;
    var3.setDataset(var26);
    org.jfree.chart.plot.AbstractPieLabelDistributor var28 = var3.getLabelDistributor();
    int var29 = var28.getItemCount();
    var28.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var32 = var28.getPieLabelRecord(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLowerMargin();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("January");

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var1.markerChanged(var3);
    org.jfree.chart.util.Rotation var5 = var1.getDirection();
    double var6 = var5.getFactor();
    double var7 = var5.getFactor();
    boolean var9 = var5.equals((java.lang.Object)"java.awt.Color[r=0,g=0,b=0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var7 = var5.compareTo((java.lang.Object)100.0f);
    var5.setSelected(false);
    double var10 = var5.getYValue();
    org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
    var12.setAutoTickUnitSelection(true);
    var12.resizeRange(0.05d, (-1.0d));
    org.jfree.data.xy.DefaultXYDataset var19 = new org.jfree.data.xy.DefaultXYDataset();
    int var20 = var19.getSeriesCount();
    org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var21, (org.jfree.data.Range)var22);
    boolean var24 = var19.equals((java.lang.Object)var21);
    org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var25, (org.jfree.data.Range)var26);
    org.jfree.chart.block.LengthConstraintType var28 = var27.getWidthConstraintType();
    org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var31, (org.jfree.data.Range)var32);
    org.jfree.chart.block.LengthConstraintType var34 = var33.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var21, var28, 0.0d, (org.jfree.data.Range)var30, var34);
    var12.setRangeWithMargins((org.jfree.data.Range)var21, true, false);
    int var39 = var5.compareTo((java.lang.Object)true);
    var2.add(var5, false);
    var2.add(0.14d, (java.lang.Number)100L);
    double[][] var45 = var2.toArray();
    java.lang.String var46 = var2.getDescription();
    org.jfree.data.xy.XYSeries var49 = var2.createCopy(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "");
    java.awt.Image var8 = null;
    org.jfree.chart.ui.ProjectInfo var12 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var8, "", "", "");
    java.util.List var13 = var12.getContributors();
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    var12.addOptionalLibrary("RectangleEdge.RIGHT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
    org.jfree.chart.util.SortOrder var11 = var9.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var12.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var18 = var14.isItemLabelVisible(0, (-1), true);
    boolean var19 = var13.equals((java.lang.Object)var14);
    org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var21 = var20.getBaseStroke();
    var14.setBaseStroke(var21, false);
    var9.setRangeCrosshairStroke(var21);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
    boolean var27 = var0.isSeriesVisible(0);
    org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var32 = var31.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(var32);
    var30.setNoDataMessagePaint(var32);
    var30.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var38 = var30.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var40 = new org.jfree.chart.renderer.xy.XYItemRendererState(var39);
    boolean var41 = var40.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var42 = null;
    var40.setCrosshairState(var42);
    boolean var44 = var30.equals((java.lang.Object)var40);
    org.jfree.chart.axis.AxisLocation var46 = var30.getDomainAxisLocation(13);
    var28.setRangeAxisLocation(1, var46);
    int var48 = var28.getRangeAxisCount();
    java.lang.String var49 = var28.getPlotType();
    boolean var50 = var28.isRangeZeroBaselineVisible();
    var28.clearAnnotations();
    var0.setPlot((org.jfree.chart.plot.XYPlot)var28);
    var0.setUseYInterval(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "Combined Range XYPlot"+ "'", var49.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getRangeGridlineStroke();
    org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
    var28.setAutoTickUnitSelection(true);
    boolean var31 = var28.isAutoTickUnitSelection();
    java.awt.Paint var32 = var28.getLabelPaint();
    boolean var33 = var28.isAxisLineVisible();
    org.jfree.data.Range var34 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var28);
    java.lang.Object var35 = var25.clone();
    int var36 = var25.getWeight();
    java.awt.Paint var37 = var25.getDomainTickBandPaint();
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    boolean var42 = var38.equals((java.lang.Object)var41);
    org.jfree.chart.util.Layer var43 = null;
    boolean var44 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var41, var43);
    var25.setRangeCrosshairValue(0.025000000000000022d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.zoomRange(1.3803842646028848d, 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    org.jfree.chart.util.StandardGradientPaintTransformer var4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var4);
    org.jfree.chart.util.GradientPaintTransformType var6 = var4.getType();
    org.jfree.chart.axis.SegmentedTimeline var7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var8 = var7.getSegmentsIncludedSize();
    long var9 = var7.getSegmentSize();
    boolean var10 = var6.equals((java.lang.Object)var7);
    java.lang.String var11 = var6.toString();
    org.jfree.data.time.TimeSeries var12 = null;
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    var15.setAutoTickUnitSelection(true);
    var15.resizeRange(0.05d, (-1.0d));
    boolean var21 = var15.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, (org.jfree.chart.axis.ValueAxis)var15, var22);
    org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var13, true);
    var13.removeAllSeries();
    java.util.List var27 = var13.getSeries();
    boolean var28 = var6.equals((java.lang.Object)var27);
    java.lang.String var29 = var6.toString();
    org.jfree.chart.util.StandardGradientPaintTransformer var30 = new org.jfree.chart.util.StandardGradientPaintTransformer(var6);
    java.lang.String var31 = var6.toString();
    java.lang.String var32 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 25200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 900000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var11.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var29.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var31.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var32.equals("GradientPaintTransformType.VERTICAL"));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var1 = var0.getBaseItemLabelPaint();
//     java.awt.Paint var3 = var0.getSeriesPaint(10);
//     java.awt.Shape var5 = null;
//     var0.setSeriesShape(0, var5, false);
//     var0.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var11 = var10.getChartArea();
//     var0.setBaseShape((java.awt.Shape)var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     java.lang.Comparable var16 = null;
//     org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var11, var13, 100, 2147483647, var16, "", "Polar Plot");
//     org.jfree.data.time.TimeSeries var22 = null;
//     java.util.TimeZone var23 = null;
//     org.jfree.data.time.TimeSeriesCollection var24 = new org.jfree.data.time.TimeSeriesCollection(var22, var23);
//     org.jfree.data.Range var26 = var24.getDomainBounds(true);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     long var28 = var27.getMiddleMillisecond();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.TimeSeries var30 = var24.getSeries((java.lang.Comparable)var27);
//     org.jfree.data.DefaultKeyedValues var31 = new org.jfree.data.DefaultKeyedValues();
//     var31.clear();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var34 = var33.getLegendItems();
//     org.jfree.chart.util.SortOrder var35 = var33.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var36 = var33.getColumnRenderingOrder();
//     var31.sortByKeys(var36);
//     org.jfree.data.category.CategoryDataset var38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var27, (org.jfree.data.KeyedValues)var31);
//     org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var38);
//     org.jfree.chart.entity.CategoryItemEntity var42 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var11, "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var38, (java.lang.Comparable)0.08d, (java.lang.Comparable)"black");
//     java.lang.String var43 = var42.toString();
//     java.lang.String var44 = var42.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    double var5 = var3.getLabelGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var3.getLabelGenerator();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    var3.handleClick((-1), 100, var11);
    var3.setBackgroundImageAlignment(1);
    double var15 = var3.getMaximumLabelWidth();
    java.awt.Shape var16 = var3.getLegendItemShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    var0.setSeriesPaint(100, var23, true);
    java.awt.Shape var30 = var0.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var31.setSeriesToolTipGenerator(0, var33, true);
    boolean var36 = var31.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    var31.setPositiveItemLabelPositionFallback(var40);
    java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
    org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var52 = var51.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
    boolean var54 = var50.equals((java.lang.Object)var53);
    boolean var55 = var50.isShapeFilled();
    java.awt.Color var59 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var60 = var59.getAlpha();
    int var61 = var59.getGreen();
    var50.setOutlinePaint((java.awt.Paint)var59);
    java.awt.Paint var63 = var50.getOutlinePaint();
    boolean var64 = var50.isShapeFilled();
    java.awt.Stroke var65 = var50.getOutlineStroke();
    java.lang.Object var66 = var50.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(15, (java.lang.Boolean)false);
    int var27 = var22.getPassCount();
    java.awt.Paint var28 = null;
    java.awt.Color var32 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    boolean var33 = org.jfree.chart.util.PaintUtilities.equal(var28, (java.awt.Paint)var32);
    var22.setBaseFillPaint((java.awt.Paint)var32, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }


    org.jfree.chart.renderer.category.BarRenderer3D var1 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var1.setSeriesToolTipGenerator(0, var3, true);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var1.getURLGenerator((-1), 0, true);
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var15 = var14.getTickLabelFont();
    var10.add((org.jfree.chart.block.Block)var12, (java.lang.Object)var14);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 1.0d, 0.05d);
    org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var23 = var22.clone();
    org.jfree.chart.axis.AxisState var25 = new org.jfree.chart.axis.AxisState(100.0d);
    var25.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var29 = var28.getLegendItems();
    org.jfree.chart.util.SortOrder var30 = var28.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var32 = var31.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var37 = var33.isItemLabelVisible(0, (-1), true);
    boolean var38 = var32.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var40 = var39.getBaseStroke();
    var33.setBaseStroke(var40, false);
    var28.setRangeCrosshairStroke(var40);
    org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var46 = var28.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var45);
    var25.setTicks(var46);
    var22.addExceptions(var46);
    boolean var49 = var21.equals((java.lang.Object)var46);
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var21);
    java.awt.Font var51 = var50.getItemFont();
    java.awt.Color var54 = java.awt.Color.getColor("DateTickUnitType.DAY", (-2));
    org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("SerialDate.weekInMonthToString(): invalid code.", var51, (java.awt.Paint)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    boolean var2 = var1.getNotify();
    org.jfree.chart.util.HorizontalAlignment var3 = var1.getHorizontalAlignment();
    var1.setID("December 2014");
    boolean var6 = var1.isVisible();
    org.jfree.chart.event.TitleChangeEvent var7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    java.lang.Object var8 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    int var4 = var1.getDatasetIndex();
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var6 = var5.getBaseItemLabelPaint();
    var1.setOutlinePaint(var6);
    java.awt.Shape var8 = var1.getShape();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var10 = var9.getBaseStroke();
    double var11 = var9.getShadowXOffset();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.XYPlot var13 = null;
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    var15.setAutoTickUnitSelection(true);
    var15.setVisible(false);
    org.jfree.chart.plot.Plot var20 = var15.getPlot();
    var15.setLowerMargin(0.08d);
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var24 = var23.getBaseItemLabelPaint();
    java.awt.Paint var26 = var23.getSeriesPaint(10);
    java.awt.Shape var28 = null;
    var23.setSeriesShape(0, var28, false);
    var23.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var34 = var33.getChartArea();
    var23.setBaseShape((java.awt.Shape)var34);
    org.jfree.data.general.PieDataset var36 = null;
    java.lang.Comparable var39 = null;
    org.jfree.chart.entity.PieSectionEntity var42 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var34, var36, 100, 2147483647, var39, "", "Polar Plot");
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("");
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
    java.awt.Paint var48 = var47.getLabelPaint();
    var45.setLabelPaint(var48);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
    org.jfree.chart.util.SortOrder var52 = var50.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var54 = var53.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var59 = var55.isItemLabelVisible(0, (-1), true);
    boolean var60 = var54.equals((java.lang.Object)var55);
    org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var62 = var61.getBaseStroke();
    var55.setBaseStroke(var62, false);
    var50.setRangeCrosshairStroke(var62);
    var9.drawDomainLine(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var34, 10.0d, var48, var62);
    var1.setOutlinePaint(var48);
    java.lang.String var68 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var1.handleClick(10, 0, var5);
//     java.awt.Paint var7 = var1.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = var1.getURLGenerator();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var1.setLegendItemShape(var10);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     long var13 = var12.getMiddleMillisecond();
//     java.util.Date var14 = var12.getStart();
//     java.util.Date var15 = var12.getEnd();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var15);
//     org.jfree.data.time.RegularTimePeriod var17 = var16.previous();
//     java.util.Date var18 = var16.getStart();
//     java.awt.Stroke var19 = var1.getSectionOutlineStroke((java.lang.Comparable)var18);
//     org.jfree.data.time.TimeSeries var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var21);
//     org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis("");
//     var24.setAutoTickUnitSelection(true);
//     var24.resizeRange(0.05d, (-1.0d));
//     boolean var30 = var24.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var31 = null;
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var22, (org.jfree.chart.axis.ValueAxis)var24, var31);
//     int var33 = var32.getSeriesCount();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("December 2014", (org.jfree.chart.plot.Plot)var32);
//     boolean var35 = var1.equals((java.lang.Object)"December 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     var1.setSeriesKey((java.lang.Comparable)10.0d);
//     org.jfree.chart.util.StandardGradientPaintTransformer var4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var4);
//     org.jfree.data.time.TimeSeries var6 = null;
//     org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var6);
//     org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
//     var9.setAutoTickUnitSelection(true);
//     var9.resizeRange(0.05d, (-1.0d));
//     boolean var15 = var9.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var16 = null;
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, (org.jfree.chart.axis.ValueAxis)var9, var16);
//     java.awt.Paint var18 = var17.getAngleLabelPaint();
//     var1.setLabelPaint(var18);
//     boolean var20 = var1.isShapeVisible();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var22 = var21.getBaseItemLabelPaint();
//     java.awt.Paint var24 = var21.getSeriesPaint(10);
//     java.awt.Shape var26 = null;
//     var21.setSeriesShape(0, var26, false);
//     var21.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var32 = var31.getChartArea();
//     var21.setBaseShape((java.awt.Shape)var32);
//     org.jfree.data.general.PieDataset var34 = null;
//     java.lang.Comparable var37 = null;
//     org.jfree.chart.entity.PieSectionEntity var40 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var32, var34, 100, 2147483647, var37, "", "Polar Plot");
//     org.jfree.data.time.TimeSeries var43 = null;
//     java.util.TimeZone var44 = null;
//     org.jfree.data.time.TimeSeriesCollection var45 = new org.jfree.data.time.TimeSeriesCollection(var43, var44);
//     org.jfree.data.Range var47 = var45.getDomainBounds(true);
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     long var49 = var48.getMiddleMillisecond();
//     java.util.Date var50 = var48.getEnd();
//     org.jfree.data.time.TimeSeries var51 = var45.getSeries((java.lang.Comparable)var48);
//     org.jfree.data.DefaultKeyedValues var52 = new org.jfree.data.DefaultKeyedValues();
//     var52.clear();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var55 = var54.getLegendItems();
//     org.jfree.chart.util.SortOrder var56 = var54.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var57 = var54.getColumnRenderingOrder();
//     var52.sortByKeys(var57);
//     org.jfree.data.category.CategoryDataset var59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var48, (org.jfree.data.KeyedValues)var52);
//     org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var59);
//     org.jfree.chart.entity.CategoryItemEntity var63 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var32, "", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var59, (java.lang.Comparable)0.08d, (java.lang.Comparable)"black");
//     org.jfree.chart.plot.MultiplePiePlot var64 = new org.jfree.chart.plot.MultiplePiePlot(var59);
//     org.jfree.data.Range var66 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var59, false);
//     org.jfree.data.Range var67 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var59);
//     var1.setDataset((org.jfree.data.general.Dataset)var59);
//     
//     // Checks the contract:  equals-hashcode on var7 and var45
//     assertTrue("Contract failed: equals-hashcode on var7 and var45", var7.equals(var45) ? var7.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var7
//     assertTrue("Contract failed: equals-hashcode on var45 and var7", var45.equals(var7) ? var45.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var20 = var19.getBaseStroke();
    var13.setBaseStroke(var20, false);
    var7.setBaseStroke(var20);
    var6.setAxisLineStroke(var20);
    var3.setLabelOutlineStroke(var20);
    java.awt.Paint var26 = var3.getLabelOutlinePaint();
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var28 = var27.getBaseItemLabelPaint();
    java.awt.Paint var30 = var27.getSeriesPaint(10);
    java.awt.Shape var32 = null;
    var27.setSeriesShape(0, var32, false);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.StandardXYToolTipGenerator var36 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    var35.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var36, true);
    java.awt.Stroke var42 = var35.getItemStroke(0, 100, false);
    var27.setBaseStroke(var42, false);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var46 = var45.getLegendItems();
    org.jfree.chart.util.SortOrder var47 = var45.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var51 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var52 = var51.getBaseItemLabelPaint();
    var50.setBaseFillPaint(var52);
    org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var52);
    org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var52);
    var45.setRangeGridlinePaint(var52);
    var45.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var60 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var61 = var60.getLabelInsets();
    java.lang.Object var62 = null;
    boolean var63 = var61.equals(var62);
    var45.setAxisOffset(var61);
    org.jfree.chart.block.LineBorder var65 = new org.jfree.chart.block.LineBorder(var26, var42, var61);
    double var67 = var61.calculateBottomOutset(8.0d);
    double var68 = var61.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 3.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getURLGenerator((-1), 0, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getBaseToolTipGenerator();
    java.awt.Paint var13 = var0.getItemLabelPaint(255, 0, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
    var0.setSeriesItemLabelGenerator(1, var15, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     boolean var27 = var25.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var29 = var25.getDomainAxis(255);
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var31 = null;
//     java.util.TimeZone var32 = null;
//     org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
//     org.jfree.chart.title.LegendItemBlockContainer var35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, (org.jfree.data.general.Dataset)var33, (java.lang.Comparable)(-1.0d));
//     org.jfree.data.Range var36 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var33);
//     org.jfree.data.time.TimePeriodAnchor var37 = var33.getXPosition();
//     org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var33, false);
//     org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
//     var41.setAutoTickUnitSelection(true);
//     var41.setVisible(false);
//     org.jfree.chart.plot.Plot var46 = var41.getPlot();
//     var41.setLowerMargin(0.08d);
//     org.jfree.chart.renderer.PolarItemRenderer var49 = null;
//     org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var33, (org.jfree.chart.axis.ValueAxis)var41, var49);
//     org.jfree.data.Range var51 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var41);
//     int var52 = var25.getRendererCount();
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var56 = var53.getFixedRangeAxisSpace();
//     var53.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var58 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var59 = var58.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var64 = var60.isItemLabelVisible(0, (-1), true);
//     boolean var65 = var59.equals((java.lang.Object)var60);
//     org.jfree.chart.renderer.xy.XYBarRenderer var66 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var67 = var66.getBaseStroke();
//     var60.setBaseStroke(var67, false);
//     var53.setDomainCrosshairStroke(var67);
//     var25.setRangeMinorGridlineStroke(var67);
//     
//     // Checks the contract:  equals-hashcode on var9 and var59
//     assertTrue("Contract failed: equals-hashcode on var9 and var59", var9.equals(var59) ? var9.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var9
//     assertTrue("Contract failed: equals-hashcode on var59 and var9", var59.equals(var9) ? var59.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getRangeAxisLocation();
    java.awt.Paint var27 = var25.getDomainZeroBaselinePaint();
    org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    java.awt.Paint var32 = var31.getLabelPaint();
    org.jfree.chart.util.Layer var33 = null;
    var25.addRangeMarker(0, (org.jfree.chart.plot.Marker)var31, var33, false);
    org.jfree.chart.util.RectangleInsets var36 = var31.getLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(true);
    var1.updateCrosshairY(Double.NaN, (-1));
    var1.setAnchorX(2.0d);
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
    org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleAnchor var16 = null;
    java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
    var10.zoomRangeAxes(0.05d, var14, var17, false);
    var7.zoomDomainAxes(0.08d, var9, var17, false);
    org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var25 = var24.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
    org.jfree.chart.renderer.xy.XYItemRendererState var27 = new org.jfree.chart.renderer.xy.XYItemRendererState(var26);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleAnchor var29 = null;
    java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
    var7.zoomDomainAxes(0.025d, 90.0d, var26, var30);
    var1.setAnchor(var30);
    var1.updateCrosshairY(0.14d, (-16777216));
    double var36 = var1.getCrosshairDistance();
    java.awt.geom.Point2D var37 = var1.getAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "", "", "");
    java.lang.String var8 = var7.getName();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var12, "", "", "");
    java.lang.String var17 = var16.getName();
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var16);
    java.awt.Image var19 = null;
    var7.setLogo(var19);
    var7.setVersion("hi!");
    java.lang.String var23 = var7.getName();
    java.awt.Image var27 = null;
    org.jfree.chart.ui.ProjectInfo var31 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var27, "", "", "");
    java.lang.String var32 = var31.getName();
    java.awt.Image var36 = null;
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var36, "", "", "");
    java.lang.String var41 = var40.getName();
    var31.addOptionalLibrary((org.jfree.chart.ui.Library)var40);
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var40);
    java.lang.String var44 = var7.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + ""+ "'", var32.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + ""+ "'", var41.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + ""+ "'", var44.equals(""));

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    boolean var2 = var1.getProcessVisibleItemsOnly();
    org.jfree.data.time.TimeSeries var3 = null;
    java.util.TimeZone var4 = null;
    org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
    org.jfree.data.Range var7 = var5.getDomainBounds(true);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var5);
    var1.startSeriesPass((org.jfree.data.xy.XYDataset)var5, 100, 0, (-1), 10, 10);
    org.jfree.data.general.DatasetGroup var15 = var5.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var5.getStartXValue((-41635), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    java.awt.Paint var27 = var19.getRadiusGridlinePaint();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var37 = var36.getBaseItemLabelPaint();
    var35.setBaseFillPaint(var37);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var35.setBaseStroke(var48);
    var34.setAxisLineStroke(var48);
    var31.setLabelOutlineStroke(var48);
    java.awt.Paint var54 = var31.getLabelOutlinePaint();
    boolean var55 = org.jfree.chart.util.PaintUtilities.equal(var27, var54);
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 9.223372036854776E18d, 1202264.4346174132d, var54);
    var1.setSubtitlePaint(var54);
    java.awt.Paint var58 = var1.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var60 = var59.getLegendItems();
    var59.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var62 = null;
    var59.rendererChanged(var62);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var59.markerChanged(var64);
    java.awt.Paint var66 = var59.getRangeCrosshairPaint();
    var1.setChartBackgroundPaint(var66);
    java.lang.Object var68 = null;
    boolean var69 = var1.equals(var68);
    java.awt.Paint var70 = var1.getThermometerPaint();
    java.awt.Font var71 = var1.getLargeFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(15, (java.lang.Boolean)false);
    boolean var27 = var22.getBaseShapesFilled();
    var22.setUseFillPaint(false);
    var22.setDrawSeriesLineAsPath(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setStepPoint(Double.POSITIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var5 = var4.getAlpha();
    int var6 = var4.getTransparency();
    boolean var7 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    java.awt.Stroke var16 = var8.lookupSeriesOutlineStroke(100);
    var0.setAxisLineStroke(var16);
    java.util.TimeZone var18 = var0.getTimeZone();
    org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var18);
    org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18);
    org.jfree.data.time.TimeSeries var22 = var20.getSeries((java.lang.Comparable)2.0f);
    org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var27 = var26.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var27);
    var25.setNoDataMessagePaint(var27);
    var25.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var33 = var25.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var34 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var35 = new org.jfree.chart.renderer.xy.XYItemRendererState(var34);
    boolean var36 = var35.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var37 = null;
    var35.setCrosshairState(var37);
    boolean var39 = var25.equals((java.lang.Object)var35);
    org.jfree.chart.axis.AxisLocation var41 = var25.getDomainAxisLocation(13);
    var23.setRangeAxisLocation(1, var41);
    org.jfree.chart.axis.ValueAxis var43 = var23.getDomainAxis();
    int var44 = var23.getRangeAxisCount();
    boolean var45 = var20.equals((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getURLGenerator((-1), 0, true);
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.LegendItemSource var10 = null;
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var14 = var13.getTickLabelFont();
//     var9.add((org.jfree.chart.block.Block)var11, (java.lang.Object)var13);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 1.0d, 0.05d);
//     org.jfree.chart.axis.SegmentedTimeline var21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.axis.AxisState var24 = new org.jfree.chart.axis.AxisState(100.0d);
//     var24.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var28 = var27.getLegendItems();
//     org.jfree.chart.util.SortOrder var29 = var27.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var31 = var30.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var36 = var32.isItemLabelVisible(0, (-1), true);
//     boolean var37 = var31.equals((java.lang.Object)var32);
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var39 = var38.getBaseStroke();
//     var32.setBaseStroke(var39, false);
//     var27.setRangeCrosshairStroke(var39);
//     org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var45 = var27.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var44);
//     var24.setTicks(var45);
//     var21.addExceptions(var45);
//     boolean var48 = var20.equals((java.lang.Object)var45);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var9, (org.jfree.chart.block.Arrangement)var20);
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.PiePlot var51 = new org.jfree.chart.plot.PiePlot(var50);
//     double var52 = var51.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var55 = null;
//     var51.handleClick(10, 0, var55);
//     java.awt.Paint var57 = var51.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var58 = var51.getURLGenerator();
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var51.setLegendItemShape(var60);
//     var0.setBaseLegendShape(var60);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var63 = null;
//     var0.setBaseItemLabelGenerator(var63, false);
//     org.jfree.chart.plot.DrawingSupplier var66 = var0.getDrawingSupplier();
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var69 = var68.getLegendItems();
//     org.jfree.chart.util.SortOrder var70 = var68.getColumnRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var72 = var68.getRangeAxisForDataset(0);
//     org.jfree.chart.util.Layer var73 = null;
//     java.util.Collection var74 = var68.getDomainMarkers(var73);
//     org.jfree.chart.axis.CategoryAxis3D var75 = new org.jfree.chart.axis.CategoryAxis3D();
//     var75.setCategoryMargin((-1.0d));
//     java.lang.String var78 = var75.getLabelToolTip();
//     org.jfree.chart.axis.CategoryAxis[] var79 = new org.jfree.chart.axis.CategoryAxis[] { var75};
//     var68.setDomainAxes(var79);
//     java.awt.geom.Rectangle2D var81 = null;
//     var0.drawOutline(var67, var68, var81);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(0, false);
    boolean var27 = var22.getUseFillPaint();
    org.jfree.chart.labels.XYItemLabelGenerator var28 = null;
    var22.setBaseItemLabelGenerator(var28);
    org.jfree.chart.urls.XYURLGenerator var30 = var22.getBaseURLGenerator();
    var22.setBaseShapesVisible(true);
    boolean var33 = var22.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
//     double var3 = var2.getMinY();
//     java.lang.Comparable var4 = var2.getKey();
//     org.jfree.data.xy.XYDataItem var7 = var2.addOrUpdate(Double.NaN, (-1.0d));
//     java.beans.PropertyChangeListener var8 = null;
//     var2.addPropertyChangeListener(var8);
//     java.beans.PropertyChangeListener var10 = null;
//     var2.removePropertyChangeListener(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     boolean var27 = var25.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var29 = var25.getDomainAxis(255);
//     var25.setRangeCrosshairVisible(true);
//     java.awt.Stroke var32 = var25.getDomainZeroBaselineStroke();
//     boolean var33 = var25.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var34 = var25.getRangeAxisEdge();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var36 = var35.getLegendItems();
//     var35.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     int var39 = var35.indexOf(var38);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var41 = var40.getCategories();
//     org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
//     org.jfree.chart.util.Layer var46 = null;
//     var40.addRangeMarker(13, (org.jfree.chart.plot.Marker)var45, var46);
//     float var48 = var45.getAlpha();
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var45);
//     var25.addDomainMarker((org.jfree.chart.plot.Marker)var45);
//     
//     // Checks the contract:  equals-hashcode on var6 and var36
//     assertTrue("Contract failed: equals-hashcode on var6 and var36", var6.equals(var36) ? var6.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var6
//     assertTrue("Contract failed: equals-hashcode on var36 and var6", var36.equals(var6) ? var36.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    boolean var7 = var0.getBaseSeriesVisible();
    var0.setShadowVisible(true);
    var0.setDefaultEntityRadius(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }


    org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var0, (org.jfree.data.Range)var1);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.data.xy.DefaultXYDataset var5 = new org.jfree.data.xy.DefaultXYDataset();
    int var6 = var5.getSeriesCount();
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var7, (org.jfree.data.Range)var8);
    boolean var10 = var5.equals((java.lang.Object)var7);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var11, (org.jfree.data.Range)var12);
    org.jfree.chart.block.LengthConstraintType var14 = var13.getWidthConstraintType();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var17, (org.jfree.data.Range)var18);
    org.jfree.chart.block.LengthConstraintType var20 = var19.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var7, var14, 0.0d, (org.jfree.data.Range)var16, var20);
    org.jfree.data.xy.DefaultXYDataset var22 = new org.jfree.data.xy.DefaultXYDataset();
    int var23 = var22.getSeriesCount();
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var24, (org.jfree.data.Range)var25);
    boolean var27 = var22.equals((java.lang.Object)var24);
    boolean var28 = var16.intersects((org.jfree.data.Range)var24);
    org.jfree.chart.block.RectangleConstraint var29 = var2.toRangeWidth((org.jfree.data.Range)var16);
    org.jfree.data.Range var30 = var2.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var31 = var2.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var33 = var2.toFixedHeight(8.0d);
    org.jfree.chart.block.RectangleConstraint var35 = var33.toFixedHeight(0.0d);
    org.jfree.data.Range var36 = var33.getHeightRange();
    boolean var39 = var36.intersects(1.0E-5d, 100.0d);
    boolean var41 = var36.contains(6.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var15 = null;
    var8.setLegendItemToolTipGenerator(var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var18 = var17.getLegendItems();
    org.jfree.chart.util.SortOrder var19 = var17.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var21 = var20.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var26 = var22.isItemLabelVisible(0, (-1), true);
    boolean var27 = var21.equals((java.lang.Object)var22);
    org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var29 = var28.getBaseStroke();
    var22.setBaseStroke(var29, false);
    var17.setRangeCrosshairStroke(var29);
    var8.addChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    boolean var34 = var17.getDrawSharedDomainAxis();
    org.jfree.data.time.TimeSeries var35 = null;
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var35);
    org.jfree.chart.axis.LogAxis var38 = new org.jfree.chart.axis.LogAxis("");
    var38.setAutoTickUnitSelection(true);
    var38.resizeRange(0.05d, (-1.0d));
    boolean var44 = var38.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var36, (org.jfree.chart.axis.ValueAxis)var38, var45);
    java.lang.String var47 = var46.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var51 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var52 = var51.getBaseItemLabelPaint();
    var50.setBaseFillPaint(var52);
    org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var52);
    org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var52);
    var46.setAngleLabelPaint(var52);
    var17.setRangeMinorGridlinePaint(var52);
    var0.setSeriesFillPaint(0, var52);
    org.jfree.chart.labels.CategoryItemLabelGenerator var59 = null;
    var0.setBaseItemLabelGenerator(var59, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Polar Plot"+ "'", var47.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.VerticalAlignment var3 = var2.getVerticalAlignment();
    java.awt.Font var4 = var2.getFont();
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(15, 15, 0);
    java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    java.awt.color.ColorSpace var13 = var12.getColorSpace();
    float[] var17 = new float[] { 0.0f, 10.0f, 100.0f};
    float[] var18 = var8.getColorComponents(var13, var17);
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("DateTickUnitType.DAY", var4, (java.awt.Paint)var8, 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var5 = var4.getTickLabelFont();
    var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var4);
    org.jfree.chart.block.BlockContainer var7 = var2.getItemContainer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    int var3 = var1.indexOf((java.lang.Comparable)86400000L);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    var5.resizeRange(0.05d, (-1.0d));
    var5.configure();
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var5, var12);
    org.jfree.data.xy.XYDataset var14 = var13.getDataset();
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(100, (-1), false);
    java.awt.Paint var21 = var15.getSeriesFillPaint(100);
    java.awt.Stroke var23 = var15.lookupSeriesOutlineStroke(100);
    java.awt.Paint var27 = var15.getItemLabelPaint(2147483647, 100, true);
    var13.setRadiusGridlinePaint(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
    var0.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var12 = var11.getBaseItemLabelPaint();
    java.awt.Paint var14 = var11.getSeriesPaint(10);
    boolean var15 = var11.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("");
    int var18 = var17.getMaximumLinesToDisplay();
    java.awt.Paint var19 = var17.getPaint();
    var11.setBaseItemLabelPaint(var19);
    var9.setBackgroundPaint(var19);
    org.jfree.chart.util.RectangleInsets var22 = var9.getItemLabelPadding();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
    var24.setSeriesToolTipGenerator(0, var26, true);
    org.jfree.chart.urls.CategoryURLGenerator var32 = var24.getURLGenerator((-1), 0, true);
    org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.LegendItemSource var34 = null;
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
    org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var38 = var37.getTickLabelFont();
    var33.add((org.jfree.chart.block.Block)var35, (java.lang.Object)var37);
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var40, var41, 1.0d, 0.05d);
    org.jfree.chart.axis.SegmentedTimeline var45 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var46 = var45.clone();
    org.jfree.chart.axis.AxisState var48 = new org.jfree.chart.axis.AxisState(100.0d);
    var48.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var52 = var51.getLegendItems();
    org.jfree.chart.util.SortOrder var53 = var51.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var55 = var54.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var60 = var56.isItemLabelVisible(0, (-1), true);
    boolean var61 = var55.equals((java.lang.Object)var56);
    org.jfree.chart.renderer.xy.XYBarRenderer var62 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var63 = var62.getBaseStroke();
    var56.setBaseStroke(var63, false);
    var51.setRangeCrosshairStroke(var63);
    org.jfree.chart.axis.CategoryAxis3D var68 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var69 = var51.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var68);
    var48.setTicks(var69);
    var45.addExceptions(var69);
    boolean var72 = var44.equals((java.lang.Object)var69);
    org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var44);
    java.awt.Font var74 = var73.getItemFont();
    org.jfree.data.general.PieDataset var75 = null;
    org.jfree.chart.plot.PiePlot var76 = new org.jfree.chart.plot.PiePlot(var75);
    double var77 = var76.getInteriorGap();
    double var78 = var76.getMaximumExplodePercent();
    org.jfree.data.general.DatasetChangeEvent var79 = null;
    var76.datasetChanged(var79);
    org.jfree.chart.JFreeChart var82 = new org.jfree.chart.JFreeChart("Pie Plot", var74, (org.jfree.chart.plot.Plot)var76, true);
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    java.lang.Boolean var4 = var1.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var8 = var7.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("", var8);
    var1.setBaseItemLabelFont(var8, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var14 = var13.getXFormat();
    var1.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var13);
    org.jfree.chart.urls.StandardXYURLGenerator var17 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1, (org.jfree.chart.labels.XYToolTipGenerator)var13, (org.jfree.chart.urls.XYURLGenerator)var17);
    java.lang.Object var19 = var18.clone();
    boolean var22 = var18.getItemVisible(0, 10);
    java.lang.Object var23 = var18.clone();
    var18.setOutline(true);
    org.jfree.chart.LegendItem var28 = var18.getLegendItem((-460), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(0, (java.lang.Boolean)false);
    boolean var29 = var22.getItemLineVisible(96, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
    var0.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("");
    boolean var12 = var11.getNotify();
    org.jfree.chart.util.HorizontalAlignment var13 = var11.getHorizontalAlignment();
    java.lang.String var14 = var13.toString();
    var9.setHorizontalAlignment(var13);
    java.lang.Object var16 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var14.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    var0.removeSeries((java.lang.Comparable)1418759999999L);
    org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, false);
    org.jfree.data.xy.IntervalXYDelegate var12 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    double var3 = var1.getMaximumLabelWidth();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var1.setURLGenerator(var4);
    var1.setForegroundAlpha(0.5f);
    java.awt.Paint var8 = var1.getLabelOutlinePaint();
    var1.setSectionOutlinesVisible(false);
    boolean var11 = var1.getIgnoreZeroValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setSeriesLinesVisible(15, (java.lang.Boolean)false);
    boolean var27 = var22.getBaseShapesFilled();
    var22.setUseFillPaint(false);
    boolean var32 = var22.getItemLineVisible((-1), 13);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var36 = var35.getBaseItemLabelPaint();
    var34.setBaseFillPaint(var36);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var39 = var38.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var44 = var40.isItemLabelVisible(0, (-1), true);
    boolean var45 = var39.equals((java.lang.Object)var40);
    org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var47 = var46.getBaseStroke();
    var40.setBaseStroke(var47, false);
    var34.setBaseStroke(var47);
    var22.setSeriesOutlineStroke(13, var47);
    boolean var54 = var22.getItemLineVisible(2147483647, 100);
    org.jfree.chart.annotations.XYAnnotation var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.addAnnotation(var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", true);
    var2.setDescription("TextBlockAnchor.CENTER");
    var2.clear();

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = var1.getLabelPaint();
    java.awt.Paint var3 = var1.getLabelShadowPaint();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
    var1.setLegendItemShape(var6);
    java.awt.Stroke var8 = var1.getLabelLinkStroke();
    boolean var9 = var1.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var0.getSeriesPaint(0);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var8 = var7.getAlpha();
    int var9 = var7.getTransparency();
    boolean var10 = var3.equals((java.lang.Object)var7);
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var11.getURLGenerator(100, (-1), false);
    java.awt.Paint var17 = var11.getSeriesFillPaint(100);
    java.awt.Stroke var19 = var11.lookupSeriesOutlineStroke(100);
    var3.setAxisLineStroke(var19);
    java.util.TimeZone var21 = var3.getTimeZone();
    boolean var23 = var3.isHiddenValue(61200000L);
    org.jfree.data.Range var24 = null;
    org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var27 = org.jfree.data.Range.shift((org.jfree.data.Range)var25, 10.0d);
    org.jfree.data.Range var28 = org.jfree.data.Range.combine(var24, var27);
    var3.setRange(var28);
    java.awt.Font var30 = var3.getTickLabelFont();
    var0.setBaseLegendTextFont(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
//     var31.setAutoTickUnitSelection(true);
//     boolean var34 = var31.isAutoTickUnitSelection();
//     var31.resizeRange(0.05d);
//     java.awt.Font var37 = var31.getLabelFont();
//     boolean var38 = var31.isPositiveArrowVisible();
//     var25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var31, true);
//     int var41 = var25.getWeight();
//     org.jfree.chart.LegendItemCollection var42 = var25.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     int var4 = var0.indexOf(var3);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     var5.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var17 = var5.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var18 = null;
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18, var19);
//     org.jfree.data.Range var22 = var20.getDomainBounds(true);
//     org.jfree.data.Range var23 = var5.findDomainBounds((org.jfree.data.xy.XYDataset)var20);
//     java.awt.Paint var24 = var5.getBaseItemLabelPaint();
//     var0.setDomainCrosshairPaint(var24);
//     org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelInsets();
//     boolean var29 = var27.isPositiveArrowVisible();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var27);
//     var27.setAutoRangeMinimumSize(4.0d);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var35 = var34.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var36 = new org.jfree.chart.block.BlockBorder(var35);
//     var33.setNoDataMessagePaint(var35);
//     var33.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var41 = var33.getDomainAxisEdge(255);
//     var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var33);
//     java.lang.String var43 = var27.getLabel();
//     org.jfree.data.time.DateRange var44 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var45 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var44, (org.jfree.data.Range)var45);
//     java.lang.String var47 = var44.toString();
//     var27.setRange((org.jfree.data.Range)var44);
//     double var49 = var27.getLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + ""+ "'", var43.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var47.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("DateTickUnit[DateTickUnitType.DAY, 1]", "PlotEntity: tooltip = null");

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    java.awt.Paint var4 = var3.getGridBandPaint();
    boolean var5 = var3.isAutoRange();
    double var6 = var3.getLabelAngle();
    var3.setAutoRangeIncludesZero(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    var9.setRangeMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    java.util.Iterator var2 = var1.iterator();
    java.util.Iterator var3 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var5 = var4.getAlpha();
    int var6 = var4.getTransparency();
    boolean var7 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var8.setSeriesToolTipGenerator(0, var10, true);
    boolean var13 = var8.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = var8.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var16.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var22 = var18.isItemLabelVisible(0, (-1), true);
    boolean var23 = var17.equals((java.lang.Object)var18);
    var8.setPositiveItemLabelPositionFallback(var17);
    java.awt.Paint var26 = var8.lookupSeriesFillPaint(2147483647);
    var0.setLabelPaint(var26);
    org.jfree.chart.axis.DateTickUnit var28 = var0.getTickUnit();
    var0.setLabel("java.awt.Color[r=0,g=0,b=100]");
    var0.setMinorTickMarkInsideLength(0.8f);
    org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(5);
    org.jfree.data.xy.DefaultXYDataset var4 = new org.jfree.data.xy.DefaultXYDataset();
    int var5 = var4.getSeriesCount();
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var6, (org.jfree.data.Range)var7);
    boolean var9 = var4.equals((java.lang.Object)var6);
    org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var10, (org.jfree.data.Range)var11);
    org.jfree.chart.block.LengthConstraintType var13 = var12.getWidthConstraintType();
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var16, (org.jfree.data.Range)var17);
    org.jfree.chart.block.LengthConstraintType var19 = var18.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var6, var13, 0.0d, (org.jfree.data.Range)var15, var19);
    org.jfree.data.xy.DefaultXYDataset var21 = new org.jfree.data.xy.DefaultXYDataset();
    int var22 = var21.getSeriesCount();
    org.jfree.data.time.DateRange var23 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var23, (org.jfree.data.Range)var24);
    boolean var26 = var21.equals((java.lang.Object)var23);
    boolean var27 = var15.intersects((org.jfree.data.Range)var23);
    java.util.Date var28 = var15.getLowerDate();
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var34 = var33.getAlpha();
    int var35 = var33.getTransparency();
    boolean var36 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
    java.awt.Paint var43 = var37.getSeriesFillPaint(100);
    java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
    var29.setAxisLineStroke(var45);
    java.util.TimeZone var47 = var29.getTimeZone();
    org.jfree.chart.axis.TickUnitSource var48 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var47);
    org.jfree.data.time.TimeSeriesCollection var49 = new org.jfree.data.time.TimeSeriesCollection(var47);
    org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(var28, var47);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var28);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, var51);
    var51.setDescription("java.awt.Color[r=0,g=0,b=100]");
    boolean var55 = var1.isOnOrBefore(var51);
    int var56 = var1.toSerial();
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(5);
    int var59 = var58.getMonth();
    org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(5);
    boolean var63 = var1.isInRange((org.jfree.data.time.SerialDate)var58, (org.jfree.data.time.SerialDate)var61, (-6291476));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
    float var7 = var6.getForegroundAlpha();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
    org.jfree.data.time.TimeSeries var12 = null;
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    var15.setAutoTickUnitSelection(true);
    var15.resizeRange(0.05d, (-1.0d));
    boolean var21 = var15.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, (org.jfree.chart.axis.ValueAxis)var15, var22);
    java.lang.String var24 = var23.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var27 = var26.getBaseItemLabelPaint();
    var25.setBaseFillPaint(var27);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var27);
    var23.setRadiusGridlinePaint(var27);
    java.awt.Paint var31 = var23.getRadiusGridlinePaint();
    var10.setDomainGridlinePaint(var31);
    var10.setRangePannable(false);
    org.jfree.chart.axis.LogAxis var36 = new org.jfree.chart.axis.LogAxis("");
    var36.setAutoTickUnitSelection(true);
    var36.setVisible(false);
    org.jfree.chart.plot.Plot var41 = var36.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var42.setSeriesToolTipGenerator(0, var44, true);
    boolean var47 = var42.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = var42.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var51 = var50.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var56 = var52.isItemLabelVisible(0, (-1), true);
    boolean var57 = var51.equals((java.lang.Object)var52);
    var42.setPositiveItemLabelPositionFallback(var51);
    java.awt.Stroke var60 = var42.lookupSeriesOutlineStroke(1);
    var36.setTickMarkStroke(var60);
    org.jfree.chart.plot.MultiplePiePlot var62 = new org.jfree.chart.plot.MultiplePiePlot();
    double var63 = var62.getLimit();
    double var64 = var62.getLimit();
    org.jfree.chart.JFreeChart var65 = var62.getPieChart();
    org.jfree.chart.renderer.xy.XYBarRenderer var66 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var67 = var66.getBaseItemLabelPaint();
    java.awt.Paint var69 = var66.getSeriesPaint(10);
    java.awt.Shape var71 = null;
    var66.setSeriesShape(0, var71, false);
    var66.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var76 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var77 = var76.getChartArea();
    var66.setBaseShape((java.awt.Shape)var77);
    org.jfree.data.general.PieDataset var79 = null;
    java.lang.Comparable var82 = null;
    org.jfree.chart.entity.PieSectionEntity var85 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var77, var79, 100, 2147483647, var82, "", "Polar Plot");
    var62.setLegendItemShape((java.awt.Shape)var77);
    org.jfree.chart.util.RectangleEdge var87 = null;
    double var88 = org.jfree.chart.util.RectangleEdge.coordinate(var77, var87);
    java.awt.Paint var90 = null;
    java.awt.Stroke var91 = null;
    var0.drawRangeLine(var9, var10, (org.jfree.chart.axis.ValueAxis)var36, var77, 6.0d, var90, var91);
    org.jfree.chart.plot.CategoryPlot var93 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Polar Plot"+ "'", var24.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var1 = var0.getSegmentsIncludedSize();
    long var2 = var0.getSegmentSize();
    java.util.List var3 = var0.getExceptionSegments();
    long var4 = var0.getSegmentsGroupSize();
    int var5 = var0.getGroupSegmentCount();
    long var6 = var0.getSegmentsIncludedSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 900000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 25200000L);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var5 = var4.getAlpha();
//     int var6 = var4.getTransparency();
//     boolean var7 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
//     java.awt.Paint var14 = var8.getSeriesFillPaint(100);
//     java.awt.Stroke var16 = var8.lookupSeriesOutlineStroke(100);
//     var0.setAxisLineStroke(var16);
//     java.util.TimeZone var18 = var0.getTimeZone();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var24 = var23.getAlpha();
//     int var25 = var23.getTransparency();
//     boolean var26 = var19.equals((java.lang.Object)var23);
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var33 = var32.getAlpha();
//     int var34 = var32.getTransparency();
//     boolean var35 = var28.equals((java.lang.Object)var32);
//     org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var40 = var36.getURLGenerator(100, (-1), false);
//     java.awt.Paint var42 = var36.getSeriesFillPaint(100);
//     java.awt.Stroke var44 = var36.lookupSeriesOutlineStroke(100);
//     var28.setAxisLineStroke(var44);
//     java.util.TimeZone var46 = var28.getTimeZone();
//     org.jfree.chart.axis.TickUnitSource var47 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var46);
//     org.jfree.data.time.TimeSeriesCollection var48 = new org.jfree.data.time.TimeSeriesCollection(var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("JFreeChartEntity: tooltip =  version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", var46);
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var54 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var55 = var54.getAlpha();
//     int var56 = var54.getTransparency();
//     boolean var57 = var50.equals((java.lang.Object)var54);
//     org.jfree.chart.renderer.category.BarRenderer3D var58 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var60 = null;
//     var58.setSeriesToolTipGenerator(0, var60, true);
//     boolean var63 = var58.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var65 = var58.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var67 = var66.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var68 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var72 = var68.isItemLabelVisible(0, (-1), true);
//     boolean var73 = var67.equals((java.lang.Object)var68);
//     var58.setPositiveItemLabelPositionFallback(var67);
//     java.awt.Paint var76 = var58.lookupSeriesFillPaint(2147483647);
//     var50.setLabelPaint(var76);
//     org.jfree.chart.axis.DateTickUnit var78 = var50.getTickUnit();
//     var49.setTickUnit(var78, true, true);
//     java.lang.String var83 = var78.valueToString(6.0d);
//     var19.setTickUnit(var78);
//     java.util.Date var85 = var0.calculateLowestVisibleTickValue(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var83 + "' != '" + "12/31/69 4:00 PM"+ "'", var83.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    int var7 = var6.getMaximumLinesToDisplay();
    java.awt.Paint var8 = var6.getPaint();
    var0.setBaseItemLabelPaint(var8);
    var0.setBase((-3.0d));
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var14 = var13.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(var14);
    var12.setNoDataMessagePaint(var14);
    var12.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var20 = var12.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = new org.jfree.chart.renderer.xy.XYItemRendererState(var21);
    boolean var23 = var22.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var24 = null;
    var22.setCrosshairState(var24);
    boolean var26 = var12.equals((java.lang.Object)var22);
    java.awt.Stroke var27 = var12.getOutlineStroke();
    var0.setBaseOutlineStroke(var27, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var10 = new org.jfree.chart.renderer.xy.XYItemRendererState(var9);
    boolean var11 = var10.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var12 = null;
    var10.setCrosshairState(var12);
    boolean var14 = var0.equals((java.lang.Object)var10);
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    org.jfree.chart.renderer.xy.XYItemRendererState var19 = new org.jfree.chart.renderer.xy.XYItemRendererState(var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var21 = var20.getLegendItems();
    org.jfree.chart.util.SortOrder var22 = var20.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleAnchor var26 = null;
    java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
    var20.zoomRangeAxes(0.05d, var24, var27, false);
    var0.panRangeAxes(0.0d, var18, var27);
    java.io.ObjectOutputStream var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var27, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("December 2014");
    java.awt.Paint var2 = var1.getWallPaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var7 = var3.isItemLabelVisible(0, (-1), true);
    var3.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var11 = null;
    org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection(var11);
    org.jfree.chart.axis.LogAxis var14 = new org.jfree.chart.axis.LogAxis("");
    var14.setAutoTickUnitSelection(true);
    var14.resizeRange(0.05d, (-1.0d));
    boolean var20 = var14.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var21 = null;
    org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, (org.jfree.chart.axis.ValueAxis)var14, var21);
    java.lang.String var23 = var22.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var26 = var25.getBaseItemLabelPaint();
    var24.setBaseFillPaint(var26);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var26);
    var22.setRadiusGridlinePaint(var26);
    var3.setSeriesPaint(100, var26, true);
    java.awt.Shape var33 = var3.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var34.setSeriesToolTipGenerator(0, var36, true);
    boolean var39 = var34.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var41 = var34.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var43 = var42.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var48 = var44.isItemLabelVisible(0, (-1), true);
    boolean var49 = var43.equals((java.lang.Object)var44);
    var34.setPositiveItemLabelPositionFallback(var43);
    java.awt.Paint var52 = var34.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var53 = new org.jfree.chart.title.LegendGraphic(var33, var52);
    org.jfree.chart.ChartRenderingInfo var54 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var55 = var54.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var56 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
    boolean var57 = var53.equals((java.lang.Object)var56);
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("");
    var59.setSeriesKey((java.lang.Comparable)10.0d);
    org.jfree.chart.util.StandardGradientPaintTransformer var62 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var59.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var62);
    org.jfree.chart.util.GradientPaintTransformType var64 = var62.getType();
    var53.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var62);
    org.jfree.chart.renderer.category.BarRenderer3D var66 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var66.setShadowXOffset((-1.0d));
    var66.setDrawBarOutline(false);
    java.awt.Stroke var72 = var66.lookupSeriesStroke(0);
    var53.setLineStroke(var72);
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var75 = var74.getLegendItems();
    org.jfree.chart.axis.LogAxis var77 = new org.jfree.chart.axis.LogAxis("");
    var77.setAutoTickUnitSelection(true);
    int var80 = var74.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var77);
    java.lang.Comparable var81 = null;
    var74.setDomainCrosshairRowKey(var81);
    org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var87 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var88 = var87.getAlpha();
    int var89 = var87.getTransparency();
    boolean var90 = var83.equals((java.lang.Object)var87);
    var74.setRangeCrosshairPaint((java.awt.Paint)var87);
    var53.setOutlinePaint((java.awt.Paint)var87);
    var1.setDomainGridlinePaint((java.awt.Paint)var87);
    int var94 = var87.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Polar Plot"+ "'", var23.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getRangeAxisLocation();
    var25.setDomainPannable(true);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var34 = var33.getAlpha();
    int var35 = var33.getTransparency();
    boolean var36 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
    java.awt.Paint var43 = var37.getSeriesFillPaint(100);
    java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
    var29.setAxisLineStroke(var45);
    java.util.TimeZone var47 = var29.getTimeZone();
    boolean var49 = var29.isHiddenValue(61200000L);
    int var50 = var25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    java.awt.Stroke var51 = var25.getRangeCrosshairStroke();
    org.jfree.chart.util.RectangleEdge var52 = var25.getRangeAxisEdge();
    boolean var53 = var25.isRangeMinorGridlinesVisible();
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    org.jfree.chart.title.LegendTitle var55 = var54.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.data.time.TimeSeries var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
//     org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
//     var5.setAutoTickUnitSelection(true);
//     var5.resizeRange(0.05d, (-1.0d));
//     boolean var11 = var5.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var12 = null;
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var3, (org.jfree.chart.axis.ValueAxis)var5, var12);
//     java.lang.String var14 = var13.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var17 = var16.getBaseItemLabelPaint();
//     var15.setBaseFillPaint(var17);
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var17);
//     var13.setRadiusGridlinePaint(var17);
//     java.awt.Paint var21 = var13.getRadiusGridlinePaint();
//     var0.setDomainGridlinePaint(var21);
//     var0.setRangePannable(false);
//     org.jfree.chart.util.RectangleInsets var25 = var0.getAxisOffset();
//     org.jfree.chart.axis.CategoryAxis var27 = var0.getDomainAxisForDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var32 = var31.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(var32);
//     var30.setNoDataMessagePaint(var32);
//     var30.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var38 = var30.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var40 = new org.jfree.chart.renderer.xy.XYItemRendererState(var39);
//     boolean var41 = var40.getProcessVisibleItemsOnly();
//     org.jfree.chart.plot.XYCrosshairState var42 = null;
//     var40.setCrosshairState(var42);
//     boolean var44 = var30.equals((java.lang.Object)var40);
//     org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var47 = var46.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var48 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     org.jfree.chart.renderer.xy.XYItemRendererState var49 = new org.jfree.chart.renderer.xy.XYItemRendererState(var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
//     org.jfree.chart.util.SortOrder var52 = var50.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleAnchor var56 = null;
//     java.awt.geom.Point2D var57 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var56);
//     var50.zoomRangeAxes(0.05d, var54, var57, false);
//     var30.panRangeAxes(0.0d, var48, var57);
//     var0.panDomainAxes(0.0d, var29, var57);
//     
//     // Checks the contract:  equals-hashcode on var1 and var51
//     assertTrue("Contract failed: equals-hashcode on var1 and var51", var1.equals(var51) ? var1.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var1
//     assertTrue("Contract failed: equals-hashcode on var51 and var1", var51.equals(var1) ? var51.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var33
//     assertTrue("Contract failed: equals-hashcode on var19 and var33", var19.equals(var33) ? var19.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var19
//     assertTrue("Contract failed: equals-hashcode on var33 and var19", var33.equals(var19) ? var33.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
    org.jfree.chart.util.Layer var13 = null;
    boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
    var17.setSeriesToolTipGenerator(0, var19, true);
    boolean var22 = var17.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var17.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var26 = var25.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var31 = var27.isItemLabelVisible(0, (-1), true);
    boolean var32 = var26.equals((java.lang.Object)var27);
    var17.setPositiveItemLabelPositionFallback(var26);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17, false);
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)"\uFFFD", true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var3 = var2.getBaseStroke();
    java.lang.Boolean var5 = var2.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var9 = var8.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var9);
    var2.setBaseItemLabelFont(var9, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var14 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var15 = var14.getXFormat();
    var2.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var14);
    org.jfree.chart.urls.StandardXYURLGenerator var18 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1, (org.jfree.chart.labels.XYToolTipGenerator)var14, (org.jfree.chart.urls.XYURLGenerator)var18);
    org.jfree.chart.labels.StandardXYToolTipGenerator var21 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var25 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var21, (org.jfree.chart.urls.XYURLGenerator)var25);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-41635), (org.jfree.chart.labels.XYToolTipGenerator)var14, (org.jfree.chart.urls.XYURLGenerator)var25);
    java.lang.Object var28 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAxisLineVisible();
    org.jfree.data.xy.DefaultXYDataset var6 = new org.jfree.data.xy.DefaultXYDataset();
    int var7 = var6.getSeriesCount();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var8, (org.jfree.data.Range)var9);
    boolean var11 = var6.equals((java.lang.Object)var8);
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var12, (org.jfree.data.Range)var13);
    org.jfree.chart.block.LengthConstraintType var15 = var14.getWidthConstraintType();
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var18, (org.jfree.data.Range)var19);
    org.jfree.chart.block.LengthConstraintType var21 = var20.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var8, var15, 0.0d, (org.jfree.data.Range)var17, var21);
    var1.setRange((org.jfree.data.Range)var17, false, true);
    long var26 = var17.getUpperMillis();
    java.util.Date var27 = var17.getUpperDate();
    double var28 = var17.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var4 = var2.getDomainBounds(true);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     long var6 = var5.getMiddleMillisecond();
//     java.util.Date var7 = var5.getEnd();
//     org.jfree.data.time.TimeSeries var8 = var2.getSeries((java.lang.Comparable)var5);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var10 = var9.getCategories();
//     java.lang.Object var11 = null;
//     boolean var12 = var9.equals(var11);
//     org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var18 = var14.getURLGenerator(100, (-1), false);
//     java.awt.Paint var20 = var14.getSeriesFillPaint(100);
//     java.awt.Stroke var22 = var14.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var24 = var23.getBaseItemLabelPaint();
//     java.awt.Paint var26 = var23.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
//     var23.setPositiveItemLabelPositionFallback(var28);
//     var14.setPositiveItemLabelPositionFallback(var28);
//     boolean var31 = var13.equals((java.lang.Object)var28);
//     boolean var32 = var9.equals((java.lang.Object)var28);
//     var9.setForegroundAlpha((-1.0f));
//     var2.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var9);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var37 = var36.getCategories();
//     java.lang.Object var38 = null;
//     boolean var39 = var36.equals(var38);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var41 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     var40.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var41, true);
//     java.awt.Stroke var47 = var40.getItemStroke(0, 100, false);
//     var36.setRangeCrosshairStroke(var47);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var56 = var55.getBaseItemLabelPaint();
//     var54.setBaseFillPaint(var56);
//     org.jfree.chart.block.BlockBorder var58 = new org.jfree.chart.block.BlockBorder(var56);
//     org.jfree.chart.plot.IntervalMarker var59 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var56);
//     boolean var60 = var50.removeDomainMarker((org.jfree.chart.plot.Marker)var59);
//     org.jfree.chart.util.Layer var61 = null;
//     var36.addRangeMarker(255, (org.jfree.chart.plot.Marker)var59, var61);
//     org.jfree.chart.util.SortOrder var63 = var36.getColumnRenderingOrder();
//     var9.setRowRenderingOrder(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var2 = var1.getLabelAngle();
//     java.lang.String var3 = var1.getLabelURL();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
//     org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var11 = var10.getBaseItemLabelPaint();
//     var9.setBaseFillPaint(var11);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
//     org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
//     var4.setRangeGridlinePaint(var11);
//     var4.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
//     java.lang.Object var21 = null;
//     boolean var22 = var20.equals(var21);
//     var4.setAxisOffset(var20);
//     var1.setLabelInsets(var20, true);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var29, 0, 0);
//     var32.setType((-1));
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var36 = var35.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var37 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var38 = var37.getLimit();
//     double var39 = var37.getLimit();
//     org.jfree.chart.JFreeChart var40 = var37.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var35, var40, (-1), 1);
//     java.lang.Object var44 = var40.clone();
//     boolean var45 = var40.isNotify();
//     var40.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.title.LegendTitle var48 = var40.getLegend();
//     int var49 = var40.getBackgroundImageAlignment();
//     var32.setChart(var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var13
//     assertTrue("Contract failed: equals-hashcode on var35 and var13", var35.equals(var13) ? var35.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.setVisible(false);
    var1.setLabelAngle(0.025d);
    var1.pan(0.0d);
    var1.setTickMarksVisible(false);
    var1.setAutoTickUnitSelection(true);
    org.jfree.data.Range var14 = null;
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var17 = org.jfree.data.Range.shift((org.jfree.data.Range)var15, 10.0d);
    org.jfree.data.Range var18 = org.jfree.data.Range.combine(var14, var17);
    var1.setRange(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var2 = null;
    java.util.TimeZone var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var2, var3);
    org.jfree.data.Range var6 = var4.getDomainBounds(true);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var4);
    java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var10 = var4.equals((java.lang.Object)var9);
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
    var1.seriesChanged(var11);
    java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var1);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var15 = var14.getLegendItems();
    org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
    org.jfree.chart.axis.ValueAxis var18 = var14.getRangeAxisForDataset(0);
    boolean var19 = var1.equals((java.lang.Object)0);
    org.jfree.data.xy.XYDataItem var22 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var24 = var22.compareTo((java.lang.Object)100.0f);
    var22.setSelected(false);
    double var27 = var22.getYValue();
    org.jfree.chart.axis.LogAxis var29 = new org.jfree.chart.axis.LogAxis("");
    var29.setAutoTickUnitSelection(true);
    var29.resizeRange(0.05d, (-1.0d));
    org.jfree.data.xy.DefaultXYDataset var36 = new org.jfree.data.xy.DefaultXYDataset();
    int var37 = var36.getSeriesCount();
    org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var39 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var38, (org.jfree.data.Range)var39);
    boolean var41 = var36.equals((java.lang.Object)var38);
    org.jfree.data.time.DateRange var42 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var43 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var42, (org.jfree.data.Range)var43);
    org.jfree.chart.block.LengthConstraintType var45 = var44.getWidthConstraintType();
    org.jfree.data.time.DateRange var47 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var48, (org.jfree.data.Range)var49);
    org.jfree.chart.block.LengthConstraintType var51 = var50.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var38, var45, 0.0d, (org.jfree.data.Range)var47, var51);
    var29.setRangeWithMargins((org.jfree.data.Range)var38, true, false);
    int var56 = var22.compareTo((java.lang.Object)true);
    org.jfree.chart.title.LegendItemBlockContainer var57 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)var56);
    org.jfree.chart.axis.CategoryAxis3D var60 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var61 = var60.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("", var61);
    org.jfree.chart.renderer.xy.XYBarRenderer var63 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var67 = var63.getURLGenerator(100, (-1), false);
    boolean var68 = var62.equals((java.lang.Object)var63);
    org.jfree.data.time.DateRange var69 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var71 = org.jfree.data.Range.shift((org.jfree.data.Range)var69, 10.0d);
    var57.add((org.jfree.chart.block.Block)var62, (java.lang.Object)var71);
    var57.setToolTipText("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    var57.setURLText("java.awt.Color[r=0,g=0,b=0]");
    boolean var77 = var57.isEmpty();
    java.lang.String var78 = var57.getToolTipText();
    java.lang.Comparable var79 = var57.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var78 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var78.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var79 + "' != '" + 1+ "'", var79.equals(1));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getRangeGridlineStroke();
    org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
    var28.setAutoTickUnitSelection(true);
    boolean var31 = var28.isAutoTickUnitSelection();
    java.awt.Paint var32 = var28.getLabelPaint();
    boolean var33 = var28.isAxisLineVisible();
    org.jfree.data.Range var34 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var28);
    java.lang.Object var35 = var25.clone();
    int var36 = var25.getWeight();
    java.awt.Paint var37 = var25.getDomainTickBandPaint();
    org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var39 = var38.getBaseStroke();
    java.lang.Boolean var41 = var38.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var45 = var44.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("", var45);
    var38.setBaseItemLabelFont(var45, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var50 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var51 = var50.getXFormat();
    var38.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var50);
    org.jfree.chart.labels.StandardXYToolTipGenerator var54 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var58 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var59 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var54, (org.jfree.chart.urls.XYURLGenerator)var58);
    org.jfree.chart.renderer.xy.XYStepRenderer var60 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var50, (org.jfree.chart.urls.XYURLGenerator)var58);
    java.lang.Object var61 = var60.clone();
    var60.setSeriesLinesVisible(15, (java.lang.Boolean)false);
    boolean var65 = var60.getBaseShapesFilled();
    var60.setUseFillPaint(false);
    var60.setDefaultEntityRadius(10);
    java.awt.Stroke var70 = var60.getBaseStroke();
    var25.setDomainZeroBaselineStroke(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var7.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var13 = var9.isItemLabelVisible(0, (-1), true);
    boolean var14 = var8.equals((java.lang.Object)var9);
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var16 = var15.getBaseStroke();
    var9.setBaseStroke(var16, false);
    var4.setRangeCrosshairStroke(var16);
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var22 = var4.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var21);
    var1.setTicks(var22);
    org.jfree.chart.axis.SegmentedTimeline var24 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    org.jfree.data.time.TimeSeries var25 = null;
    org.jfree.data.time.TimeSeriesCollection var26 = new org.jfree.data.time.TimeSeriesCollection(var25);
    org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
    var28.setAutoTickUnitSelection(true);
    var28.resizeRange(0.05d, (-1.0d));
    boolean var34 = var28.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var26, (org.jfree.chart.axis.ValueAxis)var28, var35);
    org.jfree.data.Range var38 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var26, true);
    var26.removeAllSeries();
    java.util.List var40 = var26.getSeries();
    var24.addExceptions(var40);
    var1.setTicks(var40);
    java.util.List var43 = var1.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var2 = var1.getLimit();
//     double var3 = var1.getLimit();
//     org.jfree.chart.JFreeChart var4 = var1.getPieChart();
//     org.jfree.data.category.CategoryDataset var5 = var1.getDataset();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getMiddleMillisecond();
//     java.util.Date var8 = var6.getStart();
//     java.util.Date var9 = var6.getEnd();
//     var1.setAggregatedItemsKey((java.lang.Comparable)var6);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.util.TimeZone var13 = var12.getTimeZone();
//     var12.configure();
//     java.lang.Class var15 = var12.getMajorTickTimePeriodClass();
//     java.awt.Paint var16 = var12.getTickMarkPaint();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.awt.Shape var23 = var22.getLegendLine();
    boolean var24 = var22.getBaseShapesFilled();
    var22.setDrawSeriesLineAsPath(false);
    var22.setBaseShapesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(100, (-1), false);
    boolean var10 = var4.equals((java.lang.Object)var5);
    java.awt.Paint var14 = var5.getItemFillPaint(100, (-1), true);
    boolean var15 = var5.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var17 = var16.getLegendItems();
    org.jfree.chart.util.SortOrder var18 = var16.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var19 = var16.getColumnRenderingOrder();
    java.awt.Paint var20 = var16.getRangeMinorGridlinePaint();
    var5.setBaseFillPaint(var20, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    var3.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.setVerticalTickLabels(false);
    var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8, true);
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.event.MarkerChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var3.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var21, var24);
    org.jfree.chart.text.TextAnchor var26 = var21.getLabelTextAnchor();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
    java.lang.Object var29 = null;
    boolean var30 = var28.equals(var29);
    org.jfree.chart.text.TextAnchor var31 = var28.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "", var26, var31, 10.0d);
    java.lang.Object var34 = var33.clone();
    org.jfree.chart.axis.TickType var35 = var33.getTickType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("12/31/69 4:00 PM");

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     int var4 = var0.indexOf(var3);
//     org.jfree.chart.util.RectangleEdge var5 = var0.getDomainAxisEdge();
//     var0.setNoDataMessage("TextBlockAnchor.CENTER");
//     org.jfree.data.time.TimeSeries var9 = null;
//     org.jfree.data.time.TimeSeriesCollection var10 = new org.jfree.data.time.TimeSeriesCollection(var9);
//     java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var10);
//     org.jfree.data.time.TimeSeries var13 = var10.getSeries((java.lang.Comparable)15);
//     double var15 = var10.getDomainLowerBound(false);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var22 = var21.getAlpha();
//     int var23 = var21.getTransparency();
//     boolean var24 = var17.equals((java.lang.Object)var21);
//     org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(100, (-1), false);
//     java.awt.Paint var31 = var25.getSeriesFillPaint(100);
//     java.awt.Stroke var33 = var25.lookupSeriesOutlineStroke(100);
//     var17.setAxisLineStroke(var33);
//     java.util.TimeZone var35 = var17.getTimeZone();
//     org.jfree.chart.axis.TickUnitSource var36 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var35);
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("TitleEntity: tooltip = hi!", var35);
//     java.lang.String[] var40 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var41 = new org.jfree.chart.axis.SymbolAxis("hi!", var40);
//     java.awt.Paint var42 = var41.getGridBandPaint();
//     org.jfree.chart.axis.MarkerAxisBand var43 = var41.getMarkerBand();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var48 = var44.isItemLabelVisible(0, (-1), true);
//     var44.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var10, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var44);
//     float var54 = var37.getMinorTickMarkOutsideLength();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setRangeAxis((-2), (org.jfree.chart.axis.ValueAxis)var37, true);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 2.0f);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(100, (-1), false);
    java.awt.Paint var9 = var3.getSeriesFillPaint(100);
    java.awt.Stroke var11 = var3.lookupSeriesOutlineStroke(100);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var15 = var14.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("", var15);
    java.lang.String var17 = var16.getToolTipText();
    var16.setToolTipText("");
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
    org.jfree.chart.entity.PlotEntity var24 = new org.jfree.chart.entity.PlotEntity(var21, (org.jfree.chart.plot.Plot)var23);
    boolean var25 = var16.equals((java.lang.Object)var21);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var21);
    var3.setLegendBar(var21);
    boolean var28 = var1.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var5 = var4.getBaseStroke();
    java.lang.Boolean var7 = var4.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var11 = var10.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
    var4.setBaseItemLabelFont(var11, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var17 = var16.getXFormat();
    var4.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var16);
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var20, (org.jfree.chart.urls.XYURLGenerator)var24);
    org.jfree.chart.renderer.xy.XYStepRenderer var26 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var24);
    java.lang.Object var27 = var26.clone();
    var26.setBaseLinesVisible(true);
    java.awt.Shape var30 = var26.getLegendLine();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
    var32.setSeriesKey((java.lang.Comparable)10.0d);
    java.lang.String var35 = var32.getDescription();
    java.awt.Stroke var36 = var32.getLineStroke();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
    double var39 = var38.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    var38.handleClick(10, 0, var42);
    java.awt.Paint var44 = var38.getShadowPaint();
    java.awt.Paint[] var45 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var47 = var46.getBaseItemLabelPaint();
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var51 = var50.getBaseItemLabelPaint();
    var49.setBaseFillPaint(var51);
    java.awt.Paint[] var53 = new java.awt.Paint[] { var51};
    java.awt.Stroke var54 = null;
    java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Shape var58 = null;
    java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var48, var53, var55, var57, var59);
    java.awt.Shape var61 = var60.getNextShape();
    var38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var60);
    var38.setCircular(true);
    boolean var65 = var38.getAutoPopulateSectionOutlineStroke();
    java.awt.Paint var66 = var38.getOutlinePaint();
    org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("TimePeriodAnchor.START", "VerticalAlignment.CENTER", "", "Pie 3D Plot", var30, var36, var66);
    java.awt.Shape var68 = var67.getLine();
    java.awt.Paint var69 = var67.getOutlinePaint();
    java.lang.String var70 = var67.getURLText();
    var67.setLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + "Pie 3D Plot"+ "'", var70.equals("Pie 3D Plot"));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var3 = null;
    int var4 = var0.indexOf(var3);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var9 = var5.isItemLabelVisible(0, (-1), true);
    var5.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var17 = var5.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var18 = null;
    java.util.TimeZone var19 = null;
    org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18, var19);
    org.jfree.data.Range var22 = var20.getDomainBounds(true);
    org.jfree.data.Range var23 = var5.findDomainBounds((org.jfree.data.xy.XYDataset)var20);
    java.awt.Paint var24 = var5.getBaseItemLabelPaint();
    var0.setDomainCrosshairPaint(var24);
    org.jfree.chart.axis.ValueAxis var27 = var0.getRangeAxisForDataset(255);
    double var28 = var0.getRangeCrosshairValue();
    org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
    var31.setAutoTickUnitSelection(true);
    var31.setVisible(false);
    var31.setLabelAngle(0.025d);
    var31.pan(0.0d);
    var0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var31);
    float var41 = var0.getForegroundAlpha();
    org.jfree.chart.axis.LogAxis var43 = new org.jfree.chart.axis.LogAxis("");
    var43.setAutoTickUnitSelection(true);
    boolean var46 = var43.isAutoTickUnitSelection();
    java.awt.Paint var47 = var43.getLabelPaint();
    boolean var48 = var43.isAxisLineVisible();
    var43.setLabel("[size=1]");
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    var2.setAutoTickUnitSelection(true);
    boolean var5 = var2.isAutoTickUnitSelection();
    var2.resizeRange(0.05d);
    java.awt.Font var8 = var2.getLabelFont();
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("hi!", var8);
    org.jfree.chart.text.TextFragment var10 = var9.getLastTextFragment();
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var16 = var15.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("", var16);
    java.lang.String var18 = var17.getToolTipText();
    org.jfree.chart.axis.LogAxis var21 = new org.jfree.chart.axis.LogAxis("");
    var21.setAutoTickUnitSelection(true);
    boolean var24 = var21.isAutoTickUnitSelection();
    var21.resizeRange(0.05d);
    java.awt.Font var27 = var21.getLabelFont();
    org.jfree.chart.text.TextLine var28 = new org.jfree.chart.text.TextLine("hi!", var27);
    var17.setFont(var27);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("TitleEntity: tooltip = Pie Plot", var27);
    org.jfree.chart.axis.LogAxis var32 = new org.jfree.chart.axis.LogAxis("");
    var32.setAutoTickUnitSelection(true);
    boolean var35 = var32.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var37 = var36.getLegendItems();
    org.jfree.chart.util.SortOrder var38 = var36.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var48 = var47.getBaseStroke();
    var41.setBaseStroke(var48, false);
    var36.setRangeCrosshairStroke(var48);
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var54 = var36.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var53);
    var32.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var36);
    org.jfree.chart.plot.CombinedDomainXYPlot var56 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var32);
    java.awt.Stroke var57 = var56.getDomainCrosshairStroke();
    boolean var58 = var56.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var60 = var56.getDomainAxis(255);
    org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var62 = null;
    java.util.TimeZone var63 = null;
    org.jfree.data.time.TimeSeriesCollection var64 = new org.jfree.data.time.TimeSeriesCollection(var62, var63);
    org.jfree.chart.title.LegendItemBlockContainer var66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var61, (org.jfree.data.general.Dataset)var64, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var67 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var64);
    org.jfree.data.time.TimePeriodAnchor var68 = var64.getXPosition();
    org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var64, false);
    org.jfree.chart.axis.LogAxis var72 = new org.jfree.chart.axis.LogAxis("");
    var72.setAutoTickUnitSelection(true);
    var72.setVisible(false);
    org.jfree.chart.plot.Plot var77 = var72.getPlot();
    var72.setLowerMargin(0.08d);
    org.jfree.chart.renderer.PolarItemRenderer var80 = null;
    org.jfree.chart.plot.PolarPlot var81 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var64, (org.jfree.chart.axis.ValueAxis)var72, var80);
    org.jfree.data.Range var82 = var56.getDataRange((org.jfree.chart.axis.ValueAxis)var72);
    int var83 = var56.getRendererCount();
    java.util.List var84 = var56.getAnnotations();
    java.awt.Paint var85 = var56.getRangeMinorGridlinePaint();
    org.jfree.chart.text.TextFragment var86 = new org.jfree.chart.text.TextFragment("poly", var27, var85);
    var9.removeFragment(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var1 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
//     var1.setSeriesToolTipGenerator(0, var3, true);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var1.getURLGenerator((-1), 0, true);
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.LegendItemSource var11 = null;
//     org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle(var11);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var15 = var14.getTickLabelFont();
//     var10.add((org.jfree.chart.block.Block)var12, (java.lang.Object)var14);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 1.0d, 0.05d);
//     org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var23 = var22.clone();
//     org.jfree.chart.axis.AxisState var25 = new org.jfree.chart.axis.AxisState(100.0d);
//     var25.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getLegendItems();
//     org.jfree.chart.util.SortOrder var30 = var28.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var31.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var37 = var33.isItemLabelVisible(0, (-1), true);
//     boolean var38 = var32.equals((java.lang.Object)var33);
//     org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var40 = var39.getBaseStroke();
//     var33.setBaseStroke(var40, false);
//     var28.setRangeCrosshairStroke(var40);
//     org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var46 = var28.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var45);
//     var25.setTicks(var46);
//     var22.addExceptions(var46);
//     boolean var49 = var21.equals((java.lang.Object)var46);
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var21);
//     java.awt.Font var51 = var50.getItemFont();
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     double var54 = var53.getInteriorGap();
//     double var55 = var53.getMaximumExplodePercent();
//     org.jfree.data.general.DatasetChangeEvent var56 = null;
//     var53.datasetChanged(var56);
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart("Pie Plot", var51, (org.jfree.chart.plot.Plot)var53, true);
//     java.awt.Paint var60 = var53.getLabelOutlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.renderer.xy.XYBarRenderer var62 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var66 = var62.getURLGenerator(100, (-1), false);
//     java.awt.Paint var68 = var62.getSeriesFillPaint(100);
//     java.awt.Stroke var70 = var62.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var72 = var71.getBaseItemLabelPaint();
//     java.awt.Paint var74 = var71.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var75 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var76 = var75.getBaseNegativeItemLabelPosition();
//     var71.setPositiveItemLabelPositionFallback(var76);
//     var62.setPositiveItemLabelPositionFallback(var76);
//     boolean var79 = var61.equals((java.lang.Object)var76);
//     java.awt.Paint var80 = var61.getBasePaint();
//     var53.setLabelShadowPaint(var80);
//     
//     // Checks the contract:  equals-hashcode on var32 and var76
//     assertTrue("Contract failed: equals-hashcode on var32 and var76", var32.equals(var76) ? var32.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var32
//     assertTrue("Contract failed: equals-hashcode on var76 and var32", var76.equals(var32) ? var76.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    var0.setRangeCrosshairValue(10.0d);
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var13 = var12.clone();
    double var14 = var12.getLeft();
    java.lang.Object var15 = var12.clone();
    var0.setFixedRangeAxisSpace(var12, true);
    boolean var18 = var0.isRangeMinorGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    var0.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var11 = var10.getChartArea();
    var0.setBaseShape((java.awt.Shape)var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var14 = var13.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot();
    double var16 = var15.getLimit();
    double var17 = var15.getLimit();
    org.jfree.chart.JFreeChart var18 = var15.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var13, var18, (-1), 1);
    java.lang.Object var22 = var18.clone();
    org.jfree.chart.entity.JFreeChartEntity var23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var11, var18);
    var18.setBackgroundImageAlignment(10);
    java.lang.Object var26 = var18.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var15, "", "Polar Plot");
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var9, "[size=100]", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    java.awt.Shape var23 = var22.getArea();
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
    var24.setSeriesToolTipGenerator(0, var26, true);
    boolean var29 = var24.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var30 = var24.getPositiveItemLabelPositionFallback();
    var24.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.data.time.TimeSeries var34 = null;
    org.jfree.data.time.TimeSeriesCollection var35 = new org.jfree.data.time.TimeSeriesCollection(var34);
    org.jfree.chart.axis.LogAxis var37 = new org.jfree.chart.axis.LogAxis("");
    var37.setAutoTickUnitSelection(true);
    var37.resizeRange(0.05d, (-1.0d));
    boolean var43 = var37.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var44 = null;
    org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var35, (org.jfree.chart.axis.ValueAxis)var37, var44);
    java.lang.String var46 = var45.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var49 = var48.getBaseItemLabelPaint();
    var47.setBaseFillPaint(var49);
    org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(var49);
    var45.setRadiusGridlinePaint(var49);
    java.awt.Paint var53 = var45.getRadiusGridlinePaint();
    var33.setBackgroundPaint(var53);
    java.lang.String var55 = var33.getID();
    org.jfree.chart.entity.TitleEntity var57 = new org.jfree.chart.entity.TitleEntity(var23, (org.jfree.chart.title.Title)var33, "PlotOrientation.HORIZONTAL");
    org.jfree.chart.title.Title var58 = var57.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "Polar Plot"+ "'", var46.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     double var6 = var0.getRangeUpperBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var9 = var0.getX(0, 2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     java.lang.String var12 = var11.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     var13.setBaseFillPaint(var15);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
//     var11.setRadiusGridlinePaint(var15);
//     java.awt.Paint var19 = var11.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var11.datasetChanged(var20);
//     boolean var22 = var11.isRadiusGridlinesVisible();
//     var11.setRadiusGridlinesVisible(false);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     long var32 = var31.getMiddleMillisecond();
//     java.util.Date var33 = var31.getStart();
//     java.util.Date var34 = var31.getEnd();
//     var26.setAggregatedItemsKey((java.lang.Comparable)var31);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var36);
//     java.util.TimeZone var38 = var37.getTimeZone();
//     var37.configure();
//     org.jfree.data.Range var40 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     var37.setMinorTickMarksVisible(true);
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)644288400000L, "[size=100]", "RectangleEdge.BOTTOM");
//     boolean var47 = var46.getNotify();
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     long var49 = var48.getMiddleMillisecond();
//     java.util.Date var50 = var48.getStart();
//     java.util.Date var51 = var48.getEnd();
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year(var51);
//     org.jfree.data.time.RegularTimePeriod var53 = var52.previous();
//     java.util.Date var54 = var52.getStart();
//     org.jfree.data.time.TimeSeriesDataItem var55 = var46.getDataItem((org.jfree.data.time.RegularTimePeriod)var52);
//     int var56 = var52.getYear();
//     var37.setLast((org.jfree.data.time.RegularTimePeriod)var52);
//     org.jfree.data.time.RegularTimePeriod var58 = var52.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "Polar Plot"+ "'", var12.equals("Polar Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    var1.setURLText("Nearest");

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var3 = var2.getLimit();
//     double var4 = var2.getLimit();
//     org.jfree.chart.JFreeChart var5 = var2.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
//     java.lang.Object var9 = var5.clone();
//     boolean var10 = var5.isNotify();
//     org.jfree.chart.title.LegendTitle var11 = var5.getLegend();
//     var5.removeLegend();
//     java.awt.Paint var13 = null;
//     var5.setBorderPaint(var13);
//     java.lang.Object var15 = var5.getTextAntiAlias();
//     java.awt.RenderingHints var16 = var5.getRenderingHints();
//     java.awt.Paint var17 = var5.getBorderPaint();
//     java.lang.String[] var21 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var22 = new org.jfree.chart.axis.SymbolAxis("hi!", var21);
//     org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("java.awt.Color[r=255,g=255,b=255]", var21);
//     java.awt.Paint var24 = var23.getGridBandAlternatePaint();
//     var5.setBorderPaint(var24);
//     org.jfree.chart.block.CenterArrangement var26 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var28 = var27.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var29 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var30 = var29.getLimit();
//     double var31 = var29.getLimit();
//     org.jfree.chart.JFreeChart var32 = var29.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var35 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var27, var32, (-1), 1);
//     java.lang.Object var36 = var32.clone();
//     boolean var37 = var32.isNotify();
//     org.jfree.chart.title.LegendTitle var38 = var32.getLegend();
//     var32.removeLegend();
//     java.awt.Paint var40 = null;
//     var32.setBorderPaint(var40);
//     java.lang.Object var42 = var32.getTextAntiAlias();
//     java.awt.RenderingHints var43 = var32.getRenderingHints();
//     boolean var44 = var26.equals((java.lang.Object)var43);
//     var5.setRenderingHints(var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var36
//     assertTrue("Contract failed: equals-hashcode on var9 and var36", var9.equals(var36) ? var9.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var9
//     assertTrue("Contract failed: equals-hashcode on var36 and var9", var36.equals(var9) ? var36.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAnchor var4 = var0.getDomainGridlinePosition();
    int var5 = var0.getCrosshairDatasetIndex();
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    boolean var7 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var1 = var0.getLimit();
//     double var2 = var0.getLimit();
//     org.jfree.chart.JFreeChart var3 = var0.getPieChart();
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     long var6 = var5.getMiddleMillisecond();
//     java.util.Date var7 = var5.getStart();
//     java.util.Date var8 = var5.getEnd();
//     var0.setAggregatedItemsKey((java.lang.Comparable)var5);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var10.getBaseNegativeItemLabelPosition();
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     java.lang.Comparable var13 = var0.getAggregatedItemsKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var9 = var8.getBaseItemLabelPaint();
//     var7.setBaseFillPaint(var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
//     double var16 = var12.getEndValue();
//     org.jfree.chart.axis.LogAxis var18 = new org.jfree.chart.axis.LogAxis("");
//     var18.setAutoTickUnitSelection(true);
//     boolean var21 = var18.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var23 = var22.getLegendItems();
//     org.jfree.chart.util.SortOrder var24 = var22.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var25.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var31 = var27.isItemLabelVisible(0, (-1), true);
//     boolean var32 = var26.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var34 = var33.getBaseStroke();
//     var27.setBaseStroke(var34, false);
//     var22.setRangeCrosshairStroke(var34);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var40 = var22.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var39);
//     var18.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var18);
//     java.awt.Stroke var43 = var42.getDomainCrosshairStroke();
//     boolean var44 = var42.isDomainMinorGridlinesVisible();
//     java.awt.Stroke var45 = var42.getRangeGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var47 = var42.getDomainAxisEdge(2147483647);
//     org.jfree.chart.plot.SeriesRenderingOrder var48 = var42.getSeriesRenderingOrder();
//     boolean var49 = var12.equals((java.lang.Object)var48);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var4 = var3.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
//     var2.setNoDataMessagePaint(var4);
//     var2.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var10 = var2.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var12 = new org.jfree.chart.renderer.xy.XYItemRendererState(var11);
//     boolean var13 = var12.getProcessVisibleItemsOnly();
//     org.jfree.chart.plot.XYCrosshairState var14 = null;
//     var12.setCrosshairState(var14);
//     boolean var16 = var2.equals((java.lang.Object)var12);
//     org.jfree.chart.axis.AxisLocation var18 = var2.getDomainAxisLocation(13);
//     var0.setRangeAxisLocation(1, var18);
//     org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
//     java.util.List var21 = var0.getSubplots();
//     java.awt.Paint var22 = var0.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var27 = var26.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var27);
//     var25.setNoDataMessagePaint(var27);
//     var25.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var33 = var25.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var35 = new org.jfree.chart.renderer.xy.XYItemRendererState(var34);
//     boolean var36 = var35.getProcessVisibleItemsOnly();
//     org.jfree.chart.plot.XYCrosshairState var37 = null;
//     var35.setCrosshairState(var37);
//     boolean var39 = var25.equals((java.lang.Object)var35);
//     org.jfree.chart.axis.AxisLocation var41 = var25.getDomainAxisLocation(13);
//     var23.setRangeAxisLocation(1, var41);
//     int var43 = var23.getRangeAxisCount();
//     java.lang.String var44 = var23.getPlotType();
//     org.jfree.chart.axis.LogAxis var46 = new org.jfree.chart.axis.LogAxis("");
//     var46.setAutoTickUnitSelection(true);
//     boolean var49 = var46.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
//     org.jfree.chart.util.SortOrder var52 = var50.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var54 = var53.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var59 = var55.isItemLabelVisible(0, (-1), true);
//     boolean var60 = var54.equals((java.lang.Object)var55);
//     org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var62 = var61.getBaseStroke();
//     var55.setBaseStroke(var62, false);
//     var50.setRangeCrosshairStroke(var62);
//     org.jfree.chart.axis.CategoryAxis3D var67 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var68 = var50.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var67);
//     var46.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var50);
//     org.jfree.chart.plot.CombinedDomainXYPlot var70 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var46);
//     org.jfree.chart.axis.AxisLocation var71 = var70.getRangeAxisLocation();
//     java.awt.Paint var72 = var70.getDomainZeroBaselinePaint();
//     org.jfree.chart.plot.IntervalMarker var76 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
//     java.awt.Paint var77 = var76.getLabelPaint();
//     org.jfree.chart.util.Layer var78 = null;
//     var70.addRangeMarker(0, (org.jfree.chart.plot.Marker)var76, var78, false);
//     boolean var81 = var70.isRangeCrosshairLockedOnData();
//     org.jfree.chart.plot.SeriesRenderingOrder var82 = var70.getSeriesRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var83 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var87 = var83.isItemLabelVisible(0, (-1), true);
//     var83.setShapesFilled(true);
//     boolean var90 = var82.equals((java.lang.Object)var83);
//     var23.setSeriesRenderingOrder(var82);
//     var0.setSeriesRenderingOrder(var82);
//     
//     // Checks the contract:  equals-hashcode on var0 and var23
//     assertTrue("Contract failed: equals-hashcode on var0 and var23", var0.equals(var23) ? var0.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var51
//     assertTrue("Contract failed: equals-hashcode on var20 and var51", var20.equals(var51) ? var20.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var20
//     assertTrue("Contract failed: equals-hashcode on var51 and var20", var51.equals(var20) ? var51.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    var25.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
    var31.setAutoTickUnitSelection(true);
    boolean var34 = var31.isAutoTickUnitSelection();
    var31.resizeRange(0.05d);
    java.awt.Font var37 = var31.getLabelFont();
    boolean var38 = var31.isPositiveArrowVisible();
    var25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var31, true);
    org.jfree.chart.axis.LogAxis var42 = new org.jfree.chart.axis.LogAxis("");
    var42.setAutoTickUnitSelection(true);
    boolean var45 = var42.isAutoTickUnitSelection();
    var42.resizeRange(0.05d);
    java.awt.Font var48 = var42.getLabelFont();
    double var50 = var42.calculateValue(6.08d);
    int var51 = var25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var42);
    boolean var52 = var25.isRangeGridlinesVisible();
    java.awt.Stroke var53 = var25.getRangeZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1202264.4346174132d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "", "", "");
    java.lang.String var8 = var7.getName();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var12, "", "", "");
    java.lang.String var17 = var16.getName();
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var16);
    java.awt.Image var19 = null;
    var7.setLogo(var19);
    var7.setVersion("hi!");
    java.lang.String var23 = var7.getName();
    java.awt.Image var27 = null;
    org.jfree.chart.ui.ProjectInfo var31 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var27, "", "", "");
    java.lang.String var32 = var31.getName();
    java.awt.Image var36 = null;
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var36, "", "", "");
    java.lang.String var41 = var40.getName();
    var31.addOptionalLibrary((org.jfree.chart.ui.Library)var40);
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var40);
    var7.setVersion("[Dec 31, 1969 4:00:00 PM --> Dec 1, 2014 12:00:00 AM]");
    org.jfree.chart.ui.BasicProjectInfo var50 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", "");
    java.awt.Image var54 = null;
    org.jfree.chart.ui.ProjectInfo var58 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var54, "", "", "");
    java.util.List var59 = var58.getContributors();
    var50.addOptionalLibrary((org.jfree.chart.ui.Library)var58);
    org.jfree.chart.ui.Library[] var61 = var58.getLibraries();
    var7.addLibrary((org.jfree.chart.ui.Library)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + ""+ "'", var32.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + ""+ "'", var41.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var2 = null;
    java.util.TimeZone var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var2, var3);
    org.jfree.data.Range var6 = var4.getDomainBounds(true);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var4);
    java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var10 = var4.equals((java.lang.Object)var9);
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
    var1.seriesChanged(var11);
    var0.seriesChanged(var11);
    org.jfree.data.general.SeriesChangeInfo var14 = null;
    var11.setSummary(var14);
    org.jfree.data.general.SeriesChangeInfo var16 = null;
    var11.setSummary(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    var1.configure();
    org.jfree.chart.axis.CategoryLabelPositions var3 = var1.getCategoryLabelPositions();
    org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var7 = var6.getBaseItemLabelPaint();
    java.awt.Paint var9 = var6.getSeriesPaint(10);
    java.awt.Shape var11 = null;
    var6.setSeriesShape(0, var11, false);
    var6.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    var6.setBaseShape((java.awt.Shape)var17);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var20 = var19.getLegendItems();
    var19.clearDomainAxes();
    org.jfree.chart.util.RectangleEdge var23 = var19.getRangeAxisEdge(3);
    double var24 = var1.getCategoryStart(31, 1, var17, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var4 = var2.getDomainBounds(true);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     long var6 = var5.getMiddleMillisecond();
//     java.util.Date var7 = var5.getEnd();
//     org.jfree.data.time.TimeSeries var8 = var2.getSeries((java.lang.Comparable)var5);
//     org.jfree.data.DefaultKeyedValues var9 = new org.jfree.data.DefaultKeyedValues();
//     var9.clear();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
//     org.jfree.chart.util.SortOrder var13 = var11.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var14 = var11.getColumnRenderingOrder();
//     var9.sortByKeys(var14);
//     org.jfree.data.category.CategoryDataset var16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var5, (org.jfree.data.KeyedValues)var9);
//     org.jfree.data.Range var18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var16, false);
//     org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var16, 90.0d);
//     org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var16, 255);
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var16, (java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     org.jfree.data.general.DefaultPieDataset var26 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var24);
//     java.util.List var27 = var26.getKeys();
//     int var29 = var26.getIndex((java.lang.Comparable)'#');
//     org.jfree.data.general.DatasetGroup var31 = new org.jfree.data.general.DatasetGroup("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var34 = var33.getTickLabelFont();
//     boolean var35 = var31.equals((java.lang.Object)var34);
//     var26.setGroup(var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var38 = var26.getValue((java.lang.Comparable)"[size=\uFFFD]");
//       fail("Expected exception of type org.jfree.data.UnknownKeyException");
//     } catch (org.jfree.data.UnknownKeyException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    var3.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.setVerticalTickLabels(false);
    var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8, true);
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.event.MarkerChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var3.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var21, var24);
    org.jfree.chart.text.TextAnchor var26 = var21.getLabelTextAnchor();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
    java.lang.Object var29 = null;
    boolean var30 = var28.equals(var29);
    org.jfree.chart.text.TextAnchor var31 = var28.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "", var26, var31, 10.0d);
    org.jfree.chart.text.TextAnchor var34 = var33.getRotationAnchor();
    java.lang.String var35 = var33.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + ""+ "'", var35.equals(""));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var4 = var3.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
//     var2.setNoDataMessagePaint(var4);
//     var2.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var10 = var2.getDomainAxisEdge(255);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var12 = new org.jfree.chart.renderer.xy.XYItemRendererState(var11);
//     boolean var13 = var12.getProcessVisibleItemsOnly();
//     org.jfree.chart.plot.XYCrosshairState var14 = null;
//     var12.setCrosshairState(var14);
//     boolean var16 = var2.equals((java.lang.Object)var12);
//     org.jfree.chart.axis.AxisLocation var18 = var2.getDomainAxisLocation(13);
//     var0.setRangeAxisLocation(1, var18);
//     int var20 = var0.getRangeAxisCount();
//     java.lang.String var21 = var0.getPlotType();
//     boolean var22 = var0.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.DefaultXYDataset var23 = new org.jfree.data.xy.DefaultXYDataset();
//     int var24 = var23.getSeriesCount();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getLegendItems();
//     org.jfree.chart.util.SortOrder var27 = var25.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var29 = var28.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var34 = var30.isItemLabelVisible(0, (-1), true);
//     boolean var35 = var29.equals((java.lang.Object)var30);
//     org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var37 = var36.getBaseStroke();
//     var30.setBaseStroke(var37, false);
//     var25.setRangeCrosshairStroke(var37);
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var43 = var25.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var42);
//     org.jfree.data.Range var45 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var23, var43, false);
//     int var46 = var0.indexOf((org.jfree.data.xy.XYDataset)var23);
//     org.jfree.chart.axis.ValueAxis var47 = var0.getRangeAxis();
//     org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var52 = var48.getURLGenerator(100, (-1), false);
//     org.jfree.chart.renderer.xy.XYBarPainter var53 = var48.getBarPainter();
//     org.jfree.chart.labels.ItemLabelPosition var57 = var48.getPositiveItemLabelPosition(2147483647, 0, true);
//     var48.setBarAlignmentFactor((-0.975d));
//     java.lang.Object var60 = null;
//     boolean var61 = var48.equals(var60);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     org.jfree.chart.entity.PlotEntity var66 = new org.jfree.chart.entity.PlotEntity(var63, (org.jfree.chart.plot.Plot)var65);
//     org.jfree.chart.axis.CategoryAxis3D var68 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var69 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var70 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var71 = var70.getBaseItemLabelPaint();
//     var69.setBaseFillPaint(var71);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var73 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var74 = var73.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var75 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var79 = var75.isItemLabelVisible(0, (-1), true);
//     boolean var80 = var74.equals((java.lang.Object)var75);
//     org.jfree.chart.renderer.xy.XYBarRenderer var81 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var82 = var81.getBaseStroke();
//     var75.setBaseStroke(var82, false);
//     var69.setBaseStroke(var82);
//     var68.setAxisLineStroke(var82);
//     var65.setLabelOutlineStroke(var82);
//     java.awt.Paint var88 = var65.getShadowPaint();
//     var48.setBasePaint(var88);
//     var0.setRangeGridlinePaint(var88);
//     
//     // Checks the contract:  equals-hashcode on var29 and var74
//     assertTrue("Contract failed: equals-hashcode on var29 and var74", var29.equals(var74) ? var29.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var29
//     assertTrue("Contract failed: equals-hashcode on var74 and var29", var74.equals(var29) ? var74.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    java.util.List var4 = var3.getSubtitles();
    var3.setAntiAlias(false);
    java.awt.Stroke var7 = var3.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     double var6 = var0.getRangeUpperBound(true);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var0, false);
//     double var10 = var0.getRangeUpperBound(true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var12 = var11.getBaseItemLabelPaint();
//     java.awt.Paint var14 = var11.getSeriesPaint(10);
//     java.awt.Shape var16 = null;
//     var11.setSeriesShape(0, var16, false);
//     var11.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var22 = var21.getChartArea();
//     var11.setBaseShape((java.awt.Shape)var22);
//     org.jfree.data.general.PieDataset var24 = null;
//     java.lang.Comparable var27 = null;
//     org.jfree.chart.entity.PieSectionEntity var30 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var22, var24, 100, 2147483647, var27, "", "Polar Plot");
//     var30.setPieIndex(0);
//     org.jfree.data.general.PieDataset var33 = null;
//     var30.setDataset(var33);
//     int var35 = var30.getSectionIndex();
//     boolean var36 = var0.equals((java.lang.Object)var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    double var11 = var0.getShadowXOffset();
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var3);
    org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
    var9.setAutoTickUnitSelection(true);
    var9.setVisible(false);
    org.jfree.chart.plot.Plot var14 = var9.getPlot();
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var3, (org.jfree.chart.axis.ValueAxis)var9, var15);
    java.lang.String[] var19 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var20 = new org.jfree.chart.axis.SymbolAxis("hi!", var19);
    org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
    var22.setAutoTickUnitSelection(true);
    boolean var25 = var22.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var27 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var22.setTickUnit(var27, false, true);
    var20.setTickUnit(var27, false, true);
    var9.setTickUnit(var27, true, true);
    java.lang.String var37 = var9.getLabel();
    boolean var38 = var9.isAutoRange();
    java.awt.Paint var39 = var9.getTickLabelPaint();
    org.jfree.chart.plot.WaferMapPlot var40 = new org.jfree.chart.plot.WaferMapPlot();
    float var41 = var40.getForegroundAlpha();
    var40.setNotify(false);
    org.jfree.chart.plot.MultiplePiePlot var44 = new org.jfree.chart.plot.MultiplePiePlot();
    double var45 = var44.getLimit();
    double var46 = var44.getLimit();
    var40.setParent((org.jfree.chart.plot.Plot)var44);
    java.awt.Color var51 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    java.awt.color.ColorSpace var52 = var51.getColorSpace();
    int var53 = var51.getBlue();
    var44.setAggregatedItemsPaint((java.awt.Paint)var51);
    int var55 = var51.getBlue();
    java.awt.Color var56 = var51.brighter();
    var9.setTickLabelPaint((java.awt.Paint)var51);
    java.awt.Color var58 = var51.brighter();
    java.lang.Object var59 = null;
    boolean var60 = var51.equals(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + ""+ "'", var37.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    var3.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.setVerticalTickLabels(false);
    var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8, true);
    org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.event.MarkerChangeListener var22 = null;
    var21.addChangeListener(var22);
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var3.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var21, var24);
    org.jfree.chart.text.TextAnchor var26 = var21.getLabelTextAnchor();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var28 = var27.getBaseNegativeItemLabelPosition();
    java.lang.Object var29 = null;
    boolean var30 = var28.equals(var29);
    org.jfree.chart.text.TextAnchor var31 = var28.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick(var0, 1.0E-8d, "", var26, var31, 10.0d);
    java.lang.String var34 = var33.toString();
    boolean var36 = var33.equals((java.lang.Object)"java.awt.Color[r=0,g=0,b=0]");
    java.lang.String var37 = var33.toString();
    org.jfree.chart.text.TextAnchor var38 = var33.getRotationAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + ""+ "'", var37.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
    boolean var27 = var25.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var29 = var25.getDomainAxis(255);
    org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var31 = null;
    java.util.TimeZone var32 = null;
    org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
    org.jfree.chart.title.LegendItemBlockContainer var35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, (org.jfree.data.general.Dataset)var33, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var36 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var33);
    org.jfree.data.time.TimePeriodAnchor var37 = var33.getXPosition();
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var33, false);
    org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
    var41.setAutoTickUnitSelection(true);
    var41.setVisible(false);
    org.jfree.chart.plot.Plot var46 = var41.getPlot();
    var41.setLowerMargin(0.08d);
    org.jfree.chart.renderer.PolarItemRenderer var49 = null;
    org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var33, (org.jfree.chart.axis.ValueAxis)var41, var49);
    org.jfree.data.Range var51 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var41);
    int var52 = var25.getRendererCount();
    java.util.List var53 = var25.getAnnotations();
    java.awt.Paint var54 = var25.getRangeMinorGridlinePaint();
    org.jfree.chart.annotations.XYAnnotation var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var57 = var25.removeAnnotation(var55, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    var0.setCrosshairDatasetIndex(100);
    org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
    var10.setAutoTickUnitSelection(true);
    var10.setMinorTickCount(1);
    org.jfree.chart.event.AxisChangeEvent var15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var10);
    var0.axisChanged(var15);
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var4 = var3.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
    var2.setNoDataMessagePaint(var4);
    var2.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var10 = var2.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var12 = new org.jfree.chart.renderer.xy.XYItemRendererState(var11);
    boolean var13 = var12.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var14 = null;
    var12.setCrosshairState(var14);
    boolean var16 = var2.equals((java.lang.Object)var12);
    org.jfree.chart.axis.AxisLocation var18 = var2.getDomainAxisLocation(13);
    var0.setRangeAxisLocation(1, var18);
    org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(100, (-1), false);
    java.awt.Paint var27 = var21.getSeriesFillPaint(100);
    java.awt.Stroke var29 = var21.lookupSeriesOutlineStroke(100);
    java.awt.Paint var33 = var21.getItemLabelPaint(2147483647, 100, true);
    var0.setRangeZeroBaselinePaint(var33);
    int var35 = var0.getRendererCount();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
    double var39 = var38.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    var38.handleClick(10, 0, var42);
    java.awt.Paint var44 = var38.getShadowPaint();
    java.awt.Paint[] var45 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var47 = var46.getBaseItemLabelPaint();
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var51 = var50.getBaseItemLabelPaint();
    var49.setBaseFillPaint(var51);
    java.awt.Paint[] var53 = new java.awt.Paint[] { var51};
    java.awt.Stroke var54 = null;
    java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
    java.awt.Stroke var56 = null;
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Shape var58 = null;
    java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var48, var53, var55, var57, var59);
    java.awt.Shape var61 = var60.getNextShape();
    var38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var60);
    var38.setCircular(true);
    org.jfree.chart.util.RectangleInsets var65 = var38.getLabelPadding();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var70 = var66.isItemLabelVisible(0, (-1), true);
    var66.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var78 = var66.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var79 = null;
    java.util.TimeZone var80 = null;
    org.jfree.data.time.TimeSeriesCollection var81 = new org.jfree.data.time.TimeSeriesCollection(var79, var80);
    org.jfree.data.Range var83 = var81.getDomainBounds(true);
    org.jfree.data.Range var84 = var66.findDomainBounds((org.jfree.data.xy.XYDataset)var81);
    java.awt.Paint var85 = var66.getBaseItemLabelPaint();
    var38.setBaseSectionPaint(var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint((-128010), var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    double var5 = var4.getInteriorGap();
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    var6.setStartAngle(0.08d);
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var6.getLabelGenerator();
    var4.setLabelGenerator(var9);
    int var11 = var2.compareTo((java.lang.Object)var9);
    org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(1, var2);
    long var13 = var2.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.String var5 = var1.toString();
    java.lang.Throwable[] var6 = var1.getSuppressed();
    java.lang.String var7 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var2.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var4.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var5.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var7.equals("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    var0.setDrawBarOutline(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    boolean var1 = var0.getDarkerSides();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var1.handleClick(10, 0, var5);
//     java.awt.Paint var7 = var1.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = var1.getURLGenerator();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var1.setLegendItemShape(var10);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     long var14 = var13.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     double var17 = var16.getMaxY();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     long var19 = var18.getMiddleMillisecond();
//     java.util.Date var20 = var18.getStart();
//     java.lang.String var21 = var18.toString();
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder();
//     boolean var23 = var18.equals((java.lang.Object)var22);
//     var16.add((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)10.0f, false);
//     var16.removeAgedItems(true);
//     var16.clear();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var30, 3.0d);
//     boolean var33 = var32.isSelected();
//     var16.add(var32);
//     var13.add(var32);
//     java.awt.Stroke var36 = var1.getSectionOutlineStroke((java.lang.Comparable)var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "December 2014"+ "'", var21.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    double var4 = var2.calculateLeftInset(0.025d);
    double var5 = var2.getRight();
    double var7 = var2.calculateLeftOutset((-1.0d));
    java.lang.Object var8 = null;
    boolean var9 = var2.equals(var8);
    double var11 = var2.calculateLeftInset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.0d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setVersion("Pie 3D Plot");
    var0.addOptionalLibrary("Value");

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var27 = var23.isItemLabelVisible(0, (-1), true);
    var23.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var31 = null;
    org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var31);
    org.jfree.chart.axis.LogAxis var34 = new org.jfree.chart.axis.LogAxis("");
    var34.setAutoTickUnitSelection(true);
    var34.resizeRange(0.05d, (-1.0d));
    boolean var40 = var34.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var41 = null;
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var32, (org.jfree.chart.axis.ValueAxis)var34, var41);
    java.lang.String var43 = var42.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var46 = var45.getBaseItemLabelPaint();
    var44.setBaseFillPaint(var46);
    org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var46);
    var42.setRadiusGridlinePaint(var46);
    var23.setSeriesPaint(100, var46, true);
    java.awt.Shape var53 = var23.lookupLegendShape(10);
    var22.setLegendLine(var53);
    boolean var55 = var22.getDrawOutlines();
    boolean var56 = var22.getBaseShapesVisible();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var58 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var59 = var58.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var64 = var60.isItemLabelVisible(0, (-1), true);
    boolean var65 = var59.equals((java.lang.Object)var60);
    var22.setSeriesNegativeItemLabelPosition(7, var59, false);
    boolean var68 = var22.getBaseShapesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "Polar Plot"+ "'", var43.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    double var2 = var0.getShadowXOffset();
    boolean var3 = var0.getAutoPopulateSeriesOutlinePaint();
    java.awt.Font var5 = null;
    var0.setLegendTextFont(100, var5);
    boolean var10 = var0.isItemLabelVisible(28, (-16777216), true);
    org.jfree.chart.LegendItem var13 = var0.getLegendItem((-8355712), 96);
    org.jfree.chart.labels.XYToolTipGenerator var15 = var0.getSeriesToolTipGenerator(7);
    boolean var16 = var0.getAutoPopulateSeriesOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     boolean var27 = var25.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var31 = var30.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var31);
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var37 = var33.getURLGenerator(100, (-1), false);
//     boolean var38 = var32.equals((java.lang.Object)var33);
//     java.awt.Paint var42 = var33.getItemFillPaint(100, (-1), true);
//     var25.setRangeZeroBaselinePaint(var42);
//     java.awt.Paint var44 = var25.getRangeTickBandPaint();
//     org.jfree.chart.axis.AxisSpace var45 = var25.getFixedDomainAxisSpace();
//     java.awt.Paint var46 = var25.getDomainMinorGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var48 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var49 = var48.getLabelAngle();
//     java.lang.String var50 = var48.getLabelURL();
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var52 = var51.getLegendItems();
//     org.jfree.chart.util.SortOrder var53 = var51.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var58 = var57.getBaseItemLabelPaint();
//     var56.setBaseFillPaint(var58);
//     org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(var58);
//     org.jfree.chart.plot.IntervalMarker var61 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var58);
//     var51.setRangeGridlinePaint(var58);
//     var51.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var66 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var67 = var66.getLabelInsets();
//     java.lang.Object var68 = null;
//     boolean var69 = var67.equals(var68);
//     var51.setAxisOffset(var67);
//     var48.setLabelInsets(var67, true);
//     org.jfree.chart.plot.MultiplePiePlot var73 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var74 = var73.getLimit();
//     double var75 = var73.getLimit();
//     org.jfree.chart.JFreeChart var76 = var73.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var79 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var48, var76, 0, 0);
//     int var80 = var76.getBackgroundImageAlignment();
//     org.jfree.chart.LegendItemSource var81 = null;
//     org.jfree.chart.title.LegendTitle var82 = new org.jfree.chart.title.LegendTitle(var81);
//     org.jfree.chart.event.TitleChangeEvent var83 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var82);
//     org.jfree.chart.event.ChartChangeEventType var84 = null;
//     var83.setType(var84);
//     var76.titleChanged(var83);
//     java.awt.Color var90 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var91 = var90.getAlpha();
//     int var92 = var90.getGreen();
//     java.awt.Color var93 = var90.darker();
//     var76.setBackgroundPaint((java.awt.Paint)var90);
//     java.util.List var95 = var76.getSubtitles();
//     var25.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var76);
//     
//     // Checks the contract:  equals-hashcode on var6 and var52
//     assertTrue("Contract failed: equals-hashcode on var6 and var52", var6.equals(var52) ? var6.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var6
//     assertTrue("Contract failed: equals-hashcode on var52 and var6", var52.equals(var6) ? var52.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("Polar Plot");
//     java.lang.String[] var4 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var5 = new org.jfree.chart.axis.SymbolAxis("hi!", var4);
//     org.jfree.chart.axis.LogAxis var7 = new org.jfree.chart.axis.LogAxis("");
//     var7.setAutoTickUnitSelection(true);
//     boolean var10 = var7.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var12 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var7.setTickUnit(var12, false, true);
//     var5.setTickUnit(var12, false, true);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.entity.PieSectionEntity var28 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var21, var22, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = var29.getLegendItems();
//     var29.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var32 = null;
//     int var33 = var29.indexOf(var32);
//     org.jfree.chart.util.RectangleEdge var34 = var29.getDomainAxisEdge();
//     boolean var35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var34);
//     double var36 = var5.valueToJava2D(0.05d, var21, var34);
//     var5.setFixedAutoRange(0.14d);
//     java.awt.Shape var39 = var5.getUpArrow();
//     double var40 = var5.getFixedAutoRange();
//     org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var48 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10);
//     boolean var49 = var46.equals((java.lang.Object)var48);
//     java.awt.Font var53 = var48.getItemLabelFont(0, (-1), false);
//     org.jfree.chart.axis.MarkerAxisBand var54 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var5, 0.0d, 0.0d, 0.0d, 0.5d, var53);
//     var1.setFont(var53);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var57 = var56.getLegendItems();
//     org.jfree.chart.util.SortOrder var58 = var56.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var59 = var56.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var63 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var64 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var65 = var64.getBaseItemLabelPaint();
//     var63.setBaseFillPaint(var65);
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(var65);
//     org.jfree.chart.plot.IntervalMarker var68 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var65);
//     org.jfree.chart.util.Layer var69 = null;
//     boolean var71 = var56.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var68, var69, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var73 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
//     var73.setSeriesToolTipGenerator(0, var75, true);
//     boolean var78 = var73.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var80 = var73.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var81 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var82 = var81.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var83 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var87 = var83.isItemLabelVisible(0, (-1), true);
//     boolean var88 = var82.equals((java.lang.Object)var83);
//     var73.setPositiveItemLabelPositionFallback(var82);
//     var56.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var73, false);
//     java.awt.Stroke var92 = var56.getRangeGridlineStroke();
//     java.awt.Font var93 = var56.getNoDataMessageFont();
//     var1.setFont(var93);
//     
//     // Checks the contract:  equals-hashcode on var30 and var57
//     assertTrue("Contract failed: equals-hashcode on var30 and var57", var30.equals(var57) ? var30.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var30
//     assertTrue("Contract failed: equals-hashcode on var57 and var30", var57.equals(var30) ? var57.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    java.awt.Stroke var25 = var1.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     boolean var2 = var0.equals((java.lang.Object)(byte)1);
//     int var3 = var0.getSegmentsIncluded();
//     java.util.Date var5 = var0.getDate(1L);
//     var0.addException(25200000L);
//     var0.addBaseTimelineExclusions(100L, 0L);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     long var12 = var11.getMiddleMillisecond();
//     java.util.Date var13 = var11.getEnd();
//     long var14 = var0.getTime(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1420099199999L);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.getSeparatorsVisible();
    java.awt.Stroke var3 = var1.getSeparatorStroke();
    double var4 = var1.getOuterSeparatorExtension();
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot();
    float var6 = var5.getForegroundAlpha();
    var5.setNotify(false);
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    double var10 = var9.getLimit();
    double var11 = var9.getLimit();
    var5.setParent((org.jfree.chart.plot.Plot)var9);
    java.awt.Color var16 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    java.awt.color.ColorSpace var17 = var16.getColorSpace();
    int var18 = var16.getBlue();
    var9.setAggregatedItemsPaint((java.awt.Paint)var16);
    var1.setSeparatorPaint((java.awt.Paint)var16);
    int var21 = var16.getGreen();
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var4 = new org.jfree.chart.axis.SymbolAxis("hi!", var3);
//     java.awt.Paint var5 = var4.getGridBandPaint();
//     double var6 = var4.getLowerMargin();
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
//     org.jfree.data.xy.XYDataset var8 = var0.getDataset();
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     org.jfree.chart.renderer.RendererState var14 = new org.jfree.chart.renderer.RendererState(var13);
//     org.jfree.chart.axis.LogAxis var17 = new org.jfree.chart.axis.LogAxis("");
//     var17.setAutoTickUnitSelection(true);
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.resizeRange(0.05d);
//     java.awt.Font var23 = var17.getLabelFont();
//     org.jfree.data.time.TimeSeries var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
//     org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
//     var27.setAutoTickUnitSelection(true);
//     var27.resizeRange(0.05d, (-1.0d));
//     boolean var33 = var27.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var25, (org.jfree.chart.axis.ValueAxis)var27, var34);
//     java.lang.String var36 = var35.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var39 = var38.getBaseItemLabelPaint();
//     var37.setBaseFillPaint(var39);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(var39);
//     var35.setRadiusGridlinePaint(var39);
//     java.awt.Paint var43 = var35.getRadiusGridlinePaint();
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("Polar Plot", var23, (org.jfree.chart.plot.Plot)var35, false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var49 = var48.getBaseItemLabelPaint();
//     java.awt.Paint var51 = var48.getSeriesPaint(10);
//     java.awt.Shape var53 = null;
//     var48.setSeriesShape(0, var53, false);
//     var48.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var58 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var59 = var58.getChartArea();
//     var48.setBaseShape((java.awt.Shape)var59);
//     java.awt.Point var61 = var35.translateValueThetaRadiusToJava2D((-0.975d), 1.0d, var59);
//     var0.zoomRangeAxes(12.0d, (-0.975d), var13, (java.awt.geom.Point2D)var61);
//     
//     // Checks the contract:  equals-hashcode on var11 and var58
//     assertTrue("Contract failed: equals-hashcode on var11 and var58", var11.equals(var58) ? var11.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var11
//     assertTrue("Contract failed: equals-hashcode on var58 and var11", var58.equals(var11) ? var58.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    int var7 = var6.getMaximumLinesToDisplay();
    java.awt.Paint var8 = var6.getPaint();
    var0.setBaseItemLabelPaint(var8);
    org.jfree.chart.LegendItem var12 = var0.getLegendItem(28, 0);
    org.jfree.chart.labels.XYItemLabelGenerator var13 = null;
    var0.setBaseItemLabelGenerator(var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var17 = var15.getSeriesPaint(0);
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var19 = var18.getBaseItemLabelPaint();
    java.awt.Paint var21 = var18.getSeriesPaint(10);
    boolean var22 = var18.getDataBoundsIncludesVisibleSeriesOnly();
    var18.clearSeriesStrokes(true);
    var18.setBase((-6.0d));
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var28 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
    var18.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var28);
    var15.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var28);
    java.lang.Object var31 = var28.clone();
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var28);
    java.lang.Object var33 = var28.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test281"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var1.handleClick(10, 0, var5);
//     java.awt.Paint var7 = var1.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = var1.getURLGenerator();
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var1.setLegendItemShape(var10);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     long var13 = var12.getMiddleMillisecond();
//     java.util.Date var14 = var12.getStart();
//     java.util.Date var15 = var12.getEnd();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var15);
//     org.jfree.data.time.RegularTimePeriod var17 = var16.previous();
//     java.util.Date var18 = var16.getStart();
//     java.awt.Stroke var19 = var1.getSectionOutlineStroke((java.lang.Comparable)var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var22 = var21.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(var22);
//     var20.setNoDataMessagePaint(var22);
//     java.awt.Stroke var25 = var20.getRangeZeroBaselineStroke();
//     var1.setLabelOutlineStroke(var25);
//     boolean var27 = var1.getSectionOutlinesVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test282"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     org.jfree.chart.entity.LegendItemEntity var51 = new org.jfree.chart.entity.LegendItemEntity(var30);
//     java.lang.Object var52 = var51.clone();
//     java.lang.String var53 = var51.toString();
//     java.awt.Shape var54 = var51.getArea();
//     java.lang.String var55 = var51.toString();
//     org.jfree.chart.plot.CrosshairState var57 = new org.jfree.chart.plot.CrosshairState(true);
//     boolean var58 = var51.equals((java.lang.Object)var57);
//     java.lang.String[] var61 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var62 = new org.jfree.chart.axis.SymbolAxis("hi!", var61);
//     org.jfree.chart.axis.LogAxis var64 = new org.jfree.chart.axis.LogAxis("");
//     var64.setAutoTickUnitSelection(true);
//     boolean var67 = var64.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var69 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var64.setTickUnit(var69, false, true);
//     var62.setTickUnit(var69, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var80 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var84 = var80.getURLGenerator(100, (-1), false);
//     java.awt.Paint var86 = var80.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var87 = null;
//     var80.setLegendItemToolTipGenerator(var87);
//     org.jfree.chart.axis.CategoryAxis3D var92 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var93 = var92.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var94 = new org.jfree.chart.block.LabelBlock("", var93);
//     var80.setSeriesItemLabelFont(1, var93, false);
//     org.jfree.chart.axis.MarkerAxisBand var97 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var62, Double.NaN, 3.0d, 0.08d, 4.0d, var93);
//     boolean var98 = var51.equals((java.lang.Object)3.0d);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var80.", var22.equals(var80) == var80.equals(var22));
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test283"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var4 = var2.getDomainBounds(true);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     long var6 = var5.getMiddleMillisecond();
//     java.util.Date var7 = var5.getEnd();
//     org.jfree.data.time.TimeSeries var8 = var2.getSeries((java.lang.Comparable)var5);
//     org.jfree.data.DefaultKeyedValues var9 = new org.jfree.data.DefaultKeyedValues();
//     var9.clear();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
//     org.jfree.chart.util.SortOrder var13 = var11.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var14 = var11.getColumnRenderingOrder();
//     var9.sortByKeys(var14);
//     org.jfree.data.category.CategoryDataset var16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var5, (org.jfree.data.KeyedValues)var9);
//     org.jfree.data.Range var18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var16, false);
//     org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var16, true);
//     org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var16, (java.lang.Comparable)3.0d);
//     org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test284"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     java.lang.String var12 = var11.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     var13.setBaseFillPaint(var15);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
//     var11.setRadiusGridlinePaint(var15);
//     java.awt.Paint var19 = var11.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var20 = null;
//     var11.datasetChanged(var20);
//     boolean var22 = var11.isRadiusGridlinesVisible();
//     var11.setRadiusGridlinesVisible(false);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     long var32 = var31.getMiddleMillisecond();
//     java.util.Date var33 = var31.getStart();
//     java.util.Date var34 = var31.getEnd();
//     var26.setAggregatedItemsKey((java.lang.Comparable)var31);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var36);
//     java.util.TimeZone var38 = var37.getTimeZone();
//     var37.configure();
//     org.jfree.data.Range var40 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     var37.setMinorTickMarksVisible(true);
//     org.jfree.data.time.RegularTimePeriod var43 = var37.getLast();
//     org.jfree.data.Range var44 = var37.getRange();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "Polar Plot"+ "'", var12.equals("Polar Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test285"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var3 = var2.getBaseStroke();
    double var4 = var2.getShadowXOffset();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.XYPlot var6 = null;
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.setVisible(false);
    org.jfree.chart.plot.Plot var13 = var8.getPlot();
    var8.setLowerMargin(0.08d);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var17 = var16.getBaseItemLabelPaint();
    java.awt.Paint var19 = var16.getSeriesPaint(10);
    java.awt.Shape var21 = null;
    var16.setSeriesShape(0, var21, false);
    var16.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var27 = var26.getChartArea();
    var16.setBaseShape((java.awt.Shape)var27);
    org.jfree.data.general.PieDataset var29 = null;
    java.lang.Comparable var32 = null;
    org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var27, var29, 100, 2147483647, var32, "", "Polar Plot");
    org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("");
    org.jfree.data.general.PieDataset var39 = null;
    org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
    java.awt.Paint var41 = var40.getLabelPaint();
    var38.setLabelPaint(var41);
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var44 = var43.getLegendItems();
    org.jfree.chart.util.SortOrder var45 = var43.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var47 = var46.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var48 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var52 = var48.isItemLabelVisible(0, (-1), true);
    boolean var53 = var47.equals((java.lang.Object)var48);
    org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var55 = var54.getBaseStroke();
    var48.setBaseStroke(var55, false);
    var43.setRangeCrosshairStroke(var55);
    var2.drawDomainLine(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var27, 10.0d, var41, var55);
    org.jfree.data.time.TimeSeries var60 = null;
    org.jfree.data.time.TimeSeriesCollection var61 = new org.jfree.data.time.TimeSeriesCollection(var60);
    java.lang.Number var62 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var61);
    org.jfree.data.time.TimeSeries var64 = var61.getSeries((java.lang.Comparable)15);
    int var65 = var61.getSeriesCount();
    org.jfree.chart.plot.MultiplePiePlot var66 = new org.jfree.chart.plot.MultiplePiePlot();
    double var67 = var66.getLimit();
    double var68 = var66.getLimit();
    org.jfree.chart.JFreeChart var69 = var66.getPieChart();
    boolean var70 = var69.getAntiAlias();
    java.awt.Image var71 = null;
    var69.setBackgroundImage(var71);
    java.util.List var73 = var69.getSubtitles();
    org.jfree.data.Range var75 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var61, var73, true);
    var0.drawRangeTickBands(var1, var27, var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test286"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test287"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var1);
//     org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis("");
//     var4.setAutoTickUnitSelection(true);
//     var4.resizeRange(0.05d, (-1.0d));
//     boolean var10 = var4.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, (org.jfree.chart.axis.ValueAxis)var4, var11);
//     java.lang.String var13 = var12.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var16 = var15.getBaseItemLabelPaint();
//     var14.setBaseFillPaint(var16);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(var16);
//     var12.setRadiusGridlinePaint(var16);
//     java.awt.Paint var20 = var12.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var12.datasetChanged(var21);
//     boolean var23 = var12.isRadiusGridlinesVisible();
//     var12.setRadiusGridlinesVisible(false);
//     org.jfree.chart.plot.MultiplePiePlot var27 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var28 = var27.getLimit();
//     double var29 = var27.getLimit();
//     org.jfree.chart.JFreeChart var30 = var27.getPieChart();
//     org.jfree.data.category.CategoryDataset var31 = var27.getDataset();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     long var33 = var32.getMiddleMillisecond();
//     java.util.Date var34 = var32.getStart();
//     java.util.Date var35 = var32.getEnd();
//     var27.setAggregatedItemsKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var38 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var37);
//     java.util.TimeZone var39 = var38.getTimeZone();
//     var38.configure();
//     org.jfree.data.Range var41 = var12.getDataRange((org.jfree.chart.axis.ValueAxis)var38);
//     var38.setMinorTickMarksVisible(true);
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)644288400000L, "[size=100]", "RectangleEdge.BOTTOM");
//     boolean var48 = var47.getNotify();
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     long var50 = var49.getMiddleMillisecond();
//     java.util.Date var51 = var49.getStart();
//     java.util.Date var52 = var49.getEnd();
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year(var52);
//     org.jfree.data.time.RegularTimePeriod var54 = var53.previous();
//     java.util.Date var55 = var53.getStart();
//     org.jfree.data.time.TimeSeriesDataItem var56 = var47.getDataItem((org.jfree.data.time.RegularTimePeriod)var53);
//     int var57 = var53.getYear();
//     var38.setLast((org.jfree.data.time.RegularTimePeriod)var53);
//     java.util.Locale var59 = var38.getLocale();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var60 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("SerialDate.weekInMonthToString(): invalid code.", var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "Polar Plot"+ "'", var13.equals("Polar Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test288"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
    org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
    java.lang.Object var23 = var22.clone();
    var22.setBaseLinesVisible(true);
    var22.setDrawSeriesLineAsPath(true);
    boolean var28 = var22.getBaseShapesFilled();
    var22.setDrawSeriesLineAsPath(true);
    boolean var31 = var22.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test289"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    java.awt.Paint var26 = var25.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis();
    org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var30 = org.jfree.data.Range.shift((org.jfree.data.Range)var28, 10.0d);
    org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var34 = org.jfree.data.Range.expand((org.jfree.data.Range)var31, 1.0d, 1.0E-100d);
    boolean var35 = var28.intersects(var34);
    var27.setRangeWithMargins((org.jfree.data.Range)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test290"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var12 = var0.getItemPaint(0, 100, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var14 = var13.getBaseItemLabelPaint();
    java.awt.Paint var16 = var13.getSeriesPaint(10);
    boolean var17 = var13.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
    int var20 = var19.getMaximumLinesToDisplay();
    java.awt.Paint var21 = var19.getPaint();
    var13.setBaseItemLabelPaint(var21);
    var0.setBaseOutlinePaint(var21, false);
    boolean var25 = var0.getAutoPopulateSeriesFillPaint();
    double var26 = var0.getRangeBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test291"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test292"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
    var3.setAutoTickUnitSelection(true);
    boolean var6 = var3.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var8 = var7.getLegendItems();
    org.jfree.chart.util.SortOrder var9 = var7.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var11 = var10.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var16 = var12.isItemLabelVisible(0, (-1), true);
    boolean var17 = var11.equals((java.lang.Object)var12);
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var19 = var18.getBaseStroke();
    var12.setBaseStroke(var19, false);
    var7.setRangeCrosshairStroke(var19);
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var25 = var7.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var24);
    var3.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Stroke var28 = var27.getDomainCrosshairStroke();
    boolean var29 = var27.isDomainMinorGridlinesVisible();
    boolean var30 = var1.equals((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test293"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("Polar Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange();
//     org.jfree.data.Range var6 = org.jfree.data.Range.shift((org.jfree.data.Range)var4, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(3.0d, (org.jfree.data.Range)var4);
//     org.jfree.chart.block.LengthConstraintType var8 = var7.getHeightConstraintType();
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var2, var7);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test294"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLowerMargin();
    java.awt.Paint var3 = var1.getLabelPaint();
    var1.setLowerMargin(1.0592537251772889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test295"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickMarkPosition var1 = var0.getTickMarkPosition();
    var0.setAutoRange(false);
    java.lang.Object var4 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test296"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var3 = null;
    int var4 = var0.indexOf(var3);
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var12 = var8.isItemLabelVisible(0, (-1), true);
    var8.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var20 = var8.getItemPaint(0, 100, true);
    var7.setPaint(var20);
    boolean var22 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var7);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var25 = null;
    var23.setSeriesToolTipGenerator(0, var25, true);
    boolean var28 = var23.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var29 = var23.getPositiveItemLabelPositionFallback();
    var23.setItemMargin(3.0d);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var34 = var33.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var34);
    var32.setNoDataMessagePaint(var34);
    java.awt.Stroke var37 = var32.getRangeZeroBaselineStroke();
    var23.setBaseStroke(var37);
    boolean var39 = var23.getAutoPopulateSeriesOutlineStroke();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test297"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
//     float var7 = var6.getForegroundAlpha();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.data.Range var10 = var0.findRangeBounds(var9);
//     boolean var11 = var0.getShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test298"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var9 = new org.jfree.chart.axis.SymbolAxis("hi!", var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    boolean var14 = var11.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var16 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var11.setTickUnit(var16, false, true);
    var9.setTickUnit(var16, false, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var31 = var27.getURLGenerator(100, (-1), false);
    java.awt.Paint var33 = var27.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var34 = null;
    var27.setLegendItemToolTipGenerator(var34);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var40 = var39.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("", var40);
    var27.setSeriesItemLabelFont(1, var40, false);
    org.jfree.chart.axis.MarkerAxisBand var44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var9, Double.NaN, 3.0d, 0.08d, 4.0d, var40);
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var9);
    float var47 = var9.getMinorTickMarkInsideLength();
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
    boolean var50 = var49.isShapeFilled();
    java.lang.String var51 = var49.getLabel();
    org.jfree.data.general.PieDataset var52 = null;
    org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
    double var54 = var53.getInteriorGap();
    var53.clearSectionOutlineStrokes(false);
    java.awt.Color var59 = java.awt.Color.getColor("hi!", (-1));
    var53.setLabelLinkPaint((java.awt.Paint)var59);
    java.lang.String var61 = var59.toString();
    var49.setOutlinePaint((java.awt.Paint)var59);
    var9.setGridBandPaint((java.awt.Paint)var59);
    java.awt.Color var64 = var59.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + ""+ "'", var51.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var61.equals("java.awt.Color[r=255,g=255,b=255]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test299"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(0.0d);
    var1.cursorLeft(0.0d);
    double var4 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test300"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
//     double var3 = var2.getMinY();
//     java.lang.String var4 = var2.getDescription();
//     var2.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test301"); }
// 
// 
//     org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
//     boolean var2 = var0.containsKey((java.lang.Comparable)"Polar Plot");
//     org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelInsets();
//     org.jfree.chart.axis.NumberTickUnit var6 = var4.getTickUnit();
//     boolean var7 = var0.containsKey((java.lang.Comparable)var6);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Paint var12 = var11.getLabelPaint();
//     var9.setLabelPaint(var12);
//     java.awt.Stroke var14 = var9.getLineStroke();
//     boolean var15 = var0.equals((java.lang.Object)var14);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 3.0d);
//     var17.add(var20);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Color var26 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var27 = var26.getAlpha();
//     int var28 = var26.getTransparency();
//     boolean var29 = var22.equals((java.lang.Object)var26);
//     org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var34 = var30.getURLGenerator(100, (-1), false);
//     java.awt.Paint var36 = var30.getSeriesFillPaint(100);
//     java.awt.Stroke var38 = var30.lookupSeriesOutlineStroke(100);
//     var22.setAxisLineStroke(var38);
//     java.util.TimeZone var40 = var22.getTimeZone();
//     org.jfree.chart.axis.TickUnitSource var41 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var40);
//     org.jfree.data.time.TimeSeriesCollection var42 = new org.jfree.data.time.TimeSeriesCollection(var17, var40);
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0f);
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     long var46 = var45.getMiddleMillisecond();
//     java.util.Date var47 = var45.getEnd();
//     var44.delete((org.jfree.data.time.RegularTimePeriod)var45);
//     var42.addSeries(var44);
//     java.lang.String[] var53 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var54 = new org.jfree.chart.axis.SymbolAxis("hi!", var53);
//     org.jfree.chart.axis.SymbolAxis var55 = new org.jfree.chart.axis.SymbolAxis("java.awt.Color[r=255,g=255,b=255]", var53);
//     org.jfree.chart.axis.NumberTickUnit var57 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var55.setTickUnit(var57, false, true);
//     java.lang.String var61 = var57.toString();
//     var44.setKey((java.lang.Comparable)var57);
//     boolean var63 = var0.containsKey((java.lang.Comparable)var57);
//     var0.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "[size=100]"+ "'", var61.equals("[size=100]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test302"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var2 = var1.getLimit();
//     double var3 = var1.getLimit();
//     org.jfree.chart.JFreeChart var4 = var1.getPieChart();
//     org.jfree.data.category.CategoryDataset var5 = var1.getDataset();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getMiddleMillisecond();
//     java.util.Date var8 = var6.getStart();
//     java.util.Date var9 = var6.getEnd();
//     var1.setAggregatedItemsKey((java.lang.Comparable)var6);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.util.TimeZone var13 = var12.getTimeZone();
//     var12.configure();
//     var12.setAutoRange(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test303"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var2 = var1.getLimit();
//     double var3 = var1.getLimit();
//     org.jfree.chart.JFreeChart var4 = var1.getPieChart();
//     org.jfree.data.category.CategoryDataset var5 = var1.getDataset();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getMiddleMillisecond();
//     java.util.Date var8 = var6.getStart();
//     java.util.Date var9 = var6.getEnd();
//     var1.setAggregatedItemsKey((java.lang.Comparable)var6);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("PlotEntity: tooltip = null", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.awt.Stroke var13 = var12.getMinorTickMarkStroke();
//     var12.setFixedDimension(1.0E-5d);
//     java.awt.Paint var16 = var12.getMinorTickMarkPaint();
//     var12.setMinorTickMarkInsideLength(0.0f);
//     org.jfree.data.time.TimeSeries var19 = null;
//     org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var19);
//     org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
//     var22.setAutoTickUnitSelection(true);
//     var22.resizeRange(0.05d, (-1.0d));
//     boolean var28 = var22.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var20, (org.jfree.chart.axis.ValueAxis)var22, var29);
//     java.lang.String var31 = var30.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var34 = var33.getBaseItemLabelPaint();
//     var32.setBaseFillPaint(var34);
//     org.jfree.chart.block.BlockBorder var36 = new org.jfree.chart.block.BlockBorder(var34);
//     var30.setRadiusGridlinePaint(var34);
//     java.awt.Paint var38 = var30.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var39 = null;
//     var30.datasetChanged(var39);
//     org.jfree.chart.plot.PlotOrientation var41 = var30.getOrientation();
//     boolean var42 = var30.isAngleLabelsVisible();
//     org.jfree.chart.LegendItemCollection var43 = var30.getLegendItems();
//     java.awt.Stroke var44 = var30.getRadiusGridlineStroke();
//     var12.setMinorTickMarkStroke(var44);
//     var12.setMinorTickMarkOutsideLength(100.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "Polar Plot"+ "'", var31.equals("Polar Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test304"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var1 = var0.getCategories();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(0, var3);
    org.jfree.chart.plot.Marker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    boolean var7 = var0.removeDomainMarker(var5, var6);
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test305"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var9 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var10 = new org.jfree.chart.renderer.xy.XYItemRendererState(var9);
    boolean var11 = var10.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var12 = null;
    var10.setCrosshairState(var12);
    boolean var14 = var0.equals((java.lang.Object)var10);
    boolean var15 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    var18.setEndValue((-1.0d));
    java.lang.Object var21 = var18.clone();
    java.awt.Font var22 = var18.getLabelFont();
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var26 = var25.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("", var26);
    java.lang.String var28 = var27.getToolTipText();
    var27.setToolTipText("");
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
    org.jfree.chart.entity.PlotEntity var35 = new org.jfree.chart.entity.PlotEntity(var32, (org.jfree.chart.plot.Plot)var34);
    boolean var36 = var27.equals((java.lang.Object)var32);
    org.jfree.chart.util.RectangleAnchor var37 = var27.getTextAnchor();
    java.lang.String var38 = var37.toString();
    var18.setLabelAnchor(var37);
    boolean var40 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "RectangleAnchor.CENTER"+ "'", var38.equals("RectangleAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test306"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var7 = var5.compareTo((java.lang.Object)100.0f);
    var5.setSelected(false);
    double var10 = var5.getYValue();
    var5.setY(0.025d);
    org.jfree.data.xy.XYDataItem var13 = var2.addOrUpdate(var5);
    boolean var14 = var2.getAllowDuplicateXValues();
    java.util.List var15 = var2.getItems();
    var2.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test307"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    double var8 = var7.getLimit();
    double var9 = var7.getLimit();
    org.jfree.chart.JFreeChart var10 = var7.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var10, (-1), 1);
    var4.setFrame((org.jfree.chart.block.BlockFrame)var5);
    java.lang.String var15 = var4.getID();
    java.awt.Paint var16 = var4.getPaint();
    double var17 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test308"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    double var3 = var2.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var2.handleClick(10, 0, var6);
    org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelInsets();
    java.lang.Object var11 = null;
    boolean var12 = var10.equals(var11);
    var2.setSimpleLabelOffset(var10);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    var2.setLabelPadding(var16);
    var0.setSimpleLabelOffset(var16);
    org.jfree.chart.labels.XYToolTipGenerator var20 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, var20, (org.jfree.chart.urls.XYURLGenerator)var24);
    boolean var26 = var0.equals((java.lang.Object)10);
    var0.setSimpleLabels(false);
    double var29 = var0.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0E-5d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test309"); }


    org.jfree.chart.util.StrokeMap var0 = new org.jfree.chart.util.StrokeMap();
    org.jfree.chart.renderer.category.BarRenderer3D var1 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var1.setSeriesToolTipGenerator(0, var3, true);
    boolean var6 = var1.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var7 = var1.getPositiveItemLabelPositionFallback();
    var1.setItemMargin(3.0d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var1.getSeriesItemLabelGenerator((-1));
    boolean var12 = var1.isDrawBarOutline();
    var1.setDataBoundsIncludesVisibleSeriesOnly(true);
    boolean var15 = var0.equals((java.lang.Object)var1);
    java.awt.Stroke var17 = var0.getStroke((java.lang.Comparable)(-0.8538719643217619d));
    java.lang.Object var18 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test310"); }
// 
// 
//     org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
//     org.jfree.data.Range var2 = var0.getRangeBounds(true);
//     double var4 = var0.getDomainLowerBound(true);
//     var0.setIntervalPositionFactor(0.12d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var9 = var0.getEndY(7, (-128010));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test311"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var1 = var0.getSegmentsIncludedSize();
//     long var2 = var0.getSegmentSize();
//     java.util.List var3 = var0.getExceptionSegments();
//     long var5 = var0.getTimeFromLong(1418759999999L);
//     java.util.Date var6 = null;
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     double var9 = var8.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var8.handleClick(10, 0, var12);
//     java.awt.Paint var14 = var8.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = var8.getURLGenerator();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var8.setLegendItemShape(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getMiddleMillisecond();
//     java.util.Date var21 = var19.getStart();
//     java.util.Date var22 = var19.getEnd();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var22);
//     org.jfree.data.time.RegularTimePeriod var24 = var23.previous();
//     java.util.Date var25 = var23.getStart();
//     java.awt.Stroke var26 = var8.getSectionOutlineStroke((java.lang.Comparable)var25);
//     boolean var27 = var0.containsDomainRange(var6, var25);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test312"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.axis.AxisLocation var26 = var25.getRangeAxisLocation();
    var25.setDomainPannable(true);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var33 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var34 = var33.getAlpha();
    int var35 = var33.getTransparency();
    boolean var36 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var41 = var37.getURLGenerator(100, (-1), false);
    java.awt.Paint var43 = var37.getSeriesFillPaint(100);
    java.awt.Stroke var45 = var37.lookupSeriesOutlineStroke(100);
    var29.setAxisLineStroke(var45);
    java.util.TimeZone var47 = var29.getTimeZone();
    boolean var49 = var29.isHiddenValue(61200000L);
    int var50 = var25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
    java.awt.Stroke var51 = var25.getRangeCrosshairStroke();
    org.jfree.chart.plot.PolarPlot var52 = new org.jfree.chart.plot.PolarPlot();
    java.lang.String[] var55 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var56 = new org.jfree.chart.axis.SymbolAxis("hi!", var55);
    java.awt.Paint var57 = var56.getGridBandPaint();
    double var58 = var56.getLowerMargin();
    var52.setAxis((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.data.Range var60 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var62 = var61.getBaseItemLabelPaint();
    java.awt.Paint var64 = var61.getSeriesPaint(10);
    java.awt.Shape var66 = null;
    var61.setSeriesShape(0, var66, false);
    var61.setBase((-1.0d));
    boolean var71 = var61.getAutoPopulateSeriesOutlinePaint();
    java.awt.Paint var75 = var61.getItemFillPaint(28, (-1), true);
    var25.setRangeCrosshairPaint(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

}
