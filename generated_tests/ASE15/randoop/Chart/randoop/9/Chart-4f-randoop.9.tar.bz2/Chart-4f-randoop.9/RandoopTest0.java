
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, var2, false);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getNumberInstance(var0);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var0, var1, var2);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.util.Locale var0 = null;
    org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAxisLineStroke(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.Plot var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var0, var1, "hi!", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0f, 1.0f, var4, (-1.0d), (-1.0f), (-1.0f));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.Plot var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var2 = new org.jfree.chart.entity.PlotEntity(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    boolean var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getEndXValue(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var3 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var0);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setMargin(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var3 = var2.getBaseItemLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("hi!", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, (-1.0d), (-1.0f), (-1.0f));
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var2 = var1.getTickLabelFont();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.getCategoryMiddle(0, 0, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieToolTipGenerator var3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), 10.0f, var4);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.awt.Shape var5 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var8 = var7.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(var8);
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var12 = var11.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var12);
    java.awt.Stroke var14 = null;
    java.awt.Shape var16 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var18 = var17.getBaseStroke();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var20 = var19.getBaseItemLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", true, var5, true, var8, false, var12, var14, false, var16, var18, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRightArrow(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var8 = var7.getBaseItemLabelPaint();
//     java.lang.Object var9 = var4.draw(var5, var6, (java.lang.Object)var8);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLowerMargin();
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)1L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.generateToolTip((org.jfree.data.xy.XYDataset)var3, (-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    int var2 = var1.getMaximumLinesToDisplay();
    var1.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 100.0d, "", var3, var4, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var2 = null;
//     var0.mapDatasetToDomainAxes(100, var2);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYBarPainter var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBarPainter(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.05d, 0.0f, 10.0f);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    var0.setShapesFilled(false);
    var0.setBaseCreateEntities(false);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlinePaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0, true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieToolTipGenerator var3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var14 = var13.getBaseItemLabelPaint();
    var12.setBaseFillPaint(var14);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var14);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var17.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var23 = var19.isItemLabelVisible(0, (-1), true);
    boolean var24 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var26 = var25.getBaseStroke();
    var19.setBaseStroke(var26, false);
    java.awt.Shape var30 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var32 = var31.getBaseStroke();
    org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var34 = var33.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "hi!", true, var5, true, var9, true, var14, var26, false, var30, var32, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
    boolean var3 = var2.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var4 = new org.jfree.chart.entity.TitleEntity(var0, (org.jfree.chart.title.Title)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var6 = var0.initialise(var1, var2, var3, 0, var5);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(0, var1);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.plot.PlotRenderingInfo var0 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
//     boolean var2 = var1.getProcessVisibleItemsOnly();
//     org.jfree.data.time.TimeSeries var3 = null;
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
//     org.jfree.data.Range var7 = var5.getDomainBounds(true);
//     org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var5);
//     var1.startSeriesPass((org.jfree.data.xy.XYDataset)var5, 100, 0, (-1), 10, 10);
//     java.util.List var15 = null;
//     org.jfree.data.Range var17 = var5.getDomainBounds(var15, false);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.axis.NumberTickUnit var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var2, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var2 = var1.getCategories();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var5 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var0.setShadowXOffset((-1.0d));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.05d, 100.0d, 2147483647, (java.lang.Comparable)(byte)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var3 = new org.jfree.chart.entity.JFreeChartEntity(var0, var1, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset(10);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var7 = var0.removeRangeMarker(100, var4, var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("hi!", var1, var2, var3);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.time.TimeSeries var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var2.indexOf(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorRight(0.0d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    int var7 = var6.getMaximumLinesToDisplay();
    java.awt.Paint var8 = var6.getPaint();
    var0.setBaseItemLabelPaint(var8);
    org.jfree.chart.annotations.XYAnnotation var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var1 = var0.getXFormat();
//     java.math.RoundingMode var2 = null;
//     var1.setRoundingMode(var2);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBase(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.removeSeries(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.util.List var1 = null;
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var4 = org.jfree.data.Range.shift((org.jfree.data.Range)var2, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var1, var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSelected((-1), 1, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     var3.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var8 = var0.initialise(var1, var2, var3, 1, var7);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", var3);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryAnchor var1 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.getCategoryJava2DCoordinate(var1, 10, 0, var4, var5);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var1 = null;
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
//     org.jfree.data.time.TimeSeries var6 = null;
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.TimeSeriesCollection var8 = new org.jfree.data.time.TimeSeriesCollection(var6, var7);
//     org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var8, (java.lang.Comparable)'4');
//     
//     // Checks the contract:  equals-hashcode on var3 and var8
//     assertTrue("Contract failed: equals-hashcode on var3 and var8", var3.equals(var8) ? var3.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var3
//     assertTrue("Contract failed: equals-hashcode on var8 and var3", var8.equals(var3) ? var8.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var10
//     assertTrue("Contract failed: equals-hashcode on var5 and var10", var5.equals(var10) ? var5.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var5
//     assertTrue("Contract failed: equals-hashcode on var10 and var5", var10.equals(var5) ? var10.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     var5.zoomRangeAxes(0.05d, var9, var12, false);
//     var0.zoomRangeAxes(0.05d, var4, var12, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0f, 0.0f, 2.0d, 0.0f, 0.0f);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    var5.resizeRange(0.05d, (-1.0d));
    var5.setVerticalTickLabels(false);
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2147483647, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.getEndYValue(0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var3.getStartX(0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.jfree.data.time.TimePeriodAnchor var9 = var2.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.getStartYValue(100, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.getEndXValue(2147483647, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = var2.getSeries((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.awt.Paint var6 = var0.getSeriesFillPaint(100);
//     java.awt.Stroke var8 = var0.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
//     org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var13.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var19 = var15.isItemLabelVisible(0, (-1), true);
//     boolean var20 = var14.equals((java.lang.Object)var15);
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var22 = var21.getBaseStroke();
//     var15.setBaseStroke(var22, false);
//     var10.setRangeCrosshairStroke(var22);
//     var0.setSeriesStroke(0, var22, true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    var1.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true, false);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
    org.jfree.chart.util.Layer var13 = null;
    boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.jfree.data.time.TimePeriodAnchor var9 = var2.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.getEndXValue((-1), (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    int var2 = var1.getMaximumLinesToDisplay();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMargin(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getYValue(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     java.util.Date var1 = null;
//     var0.addException(var1);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
    } catch (java.lang.StringIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var12 = var0.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var13 = null;
    java.util.TimeZone var14 = null;
    org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var13, var14);
    org.jfree.data.Range var17 = var15.getDomainBounds(true);
    org.jfree.data.Range var18 = var0.findDomainBounds((org.jfree.data.xy.XYDataset)var15);
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(100, (-1), false);
    java.awt.Paint var27 = var21.getSeriesFillPaint(100);
    java.awt.Stroke var29 = var21.lookupSeriesOutlineStroke(100);
    org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var31 = var30.getBaseItemLabelPaint();
    java.awt.Paint var33 = var30.getSeriesPaint(10);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var35 = var34.getBaseNegativeItemLabelPosition();
    var30.setPositiveItemLabelPositionFallback(var35);
    var21.setPositiveItemLabelPositionFallback(var35);
    boolean var38 = var20.equals((java.lang.Object)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition(2147483647, var35, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var0, (org.jfree.data.Range)var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    org.jfree.chart.annotations.XYAnnotation var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     long var2 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1420099199999L);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var2 = var1.getChartArea();
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var2);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var0.getXValue(1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    boolean var9 = var0.getShapesVisible();
    double var10 = var0.getRangeBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    java.lang.Object var3 = null;
    boolean var4 = var2.equals(var3);
    double var6 = var2.calculateLeftInset(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!", var1, var2);
    org.jfree.chart.JFreeChart var4 = var3.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     var0.addBaseTimelineExclusions(0L, 100L);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setAutoPopulateSectionOutlineStroke(false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Polar Plot", var1);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.handleClick(0, 1, var5);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.JFreeChart var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var15 = new org.jfree.chart.entity.JFreeChartEntity(var9, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "", "", "");
    java.awt.Image var8 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = var0.getItemCount(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Polar Plot", var1, 0.0f, 0.0f, var4, 90.0d, var6);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var4 = var3.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var4);
    var2.setNoDataMessagePaint(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var3.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     boolean var10 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var12 = var11.getBaseStroke();
//     var5.setBaseStroke(var12, false);
//     var0.setRangeCrosshairStroke(var12);
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var18 = var0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     var0.drawBackground(var19, var21);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    var0.clear();

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var2 = var0.getDataset(10);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     var5.zoomRangeAxes(0.05d, var9, var12, false);
//     var0.zoomDomainAxes(90.0d, var4, var12, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.chart.plot.CategoryMarker var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addDomainMarker(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    boolean var2 = var1.getNotify();
    java.lang.String var3 = var1.getURLText();
    int var4 = var1.getMaximumLinesToDisplay();
    org.jfree.chart.util.HorizontalAlignment var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getURLGenerator((-1), 0, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getBaseToolTipGenerator();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var15 = var14.getTickLabelFont();
    var12.setFont(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-1), var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.util.SortOrder var3 = var1.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var4.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var10 = var6.isItemLabelVisible(0, (-1), true);
    boolean var11 = var5.equals((java.lang.Object)var6);
    org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var13 = var12.getBaseStroke();
    var6.setBaseStroke(var13, false);
    var1.setRangeCrosshairStroke(var13);
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var19 = var1.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var19, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var1, (org.jfree.chart.urls.XYURLGenerator)var5);
    org.jfree.chart.labels.XYSeriesLabelGenerator var7 = var6.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var2 = var1.getTickLabelFont();
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var4 = var1.getTickLabelPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
    org.jfree.chart.util.SortOrder var4 = var2.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var5.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var11 = var7.isItemLabelVisible(0, (-1), true);
    boolean var12 = var6.equals((java.lang.Object)var7);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var14 = var13.getBaseStroke();
    var7.setBaseStroke(var14, false);
    var2.setRangeCrosshairStroke(var14);
    org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var20 = var2.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var19);
    org.jfree.data.Range var22 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var0, var20, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var26 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var0, 10, (-1.0d), 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var9 = var8.getBaseItemLabelPaint();
//     var7.setBaseFillPaint(var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getLegendItems();
//     var16.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var19 = null;
//     int var20 = var16.indexOf(var19);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var25 = var21.isItemLabelVisible(0, (-1), true);
//     var21.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var33 = var21.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var34 = null;
//     java.util.TimeZone var35 = null;
//     org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var34, var35);
//     org.jfree.data.Range var38 = var36.getDomainBounds(true);
//     org.jfree.data.Range var39 = var21.findDomainBounds((org.jfree.data.xy.XYDataset)var36);
//     java.awt.Paint var40 = var21.getBaseItemLabelPaint();
//     var16.setDomainCrosshairPaint(var40);
//     var12.setLabelPaint(var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(90.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     java.awt.Image var0 = null;
//     java.io.ObjectOutputStream var1 = null;
//     org.jfree.chart.util.SerialUtilities.writeImage(var0, var1);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    int var2 = var1.getSeriesCount();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var3, (org.jfree.data.Range)var4);
    boolean var6 = var1.equals((java.lang.Object)var3);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var7, (org.jfree.data.Range)var8);
    org.jfree.chart.block.LengthConstraintType var10 = var9.getWidthConstraintType();
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var13, (org.jfree.data.Range)var14);
    org.jfree.chart.block.LengthConstraintType var16 = var15.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var3, var10, 0.0d, (org.jfree.data.Range)var12, var16);
    double var19 = var12.constrain(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.08d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var2 = var1.getCategories();
    org.jfree.chart.util.Layer var4 = null;
    java.util.Collection var5 = var1.getDomainMarkers(0, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "VerticalAlignment.CENTER");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.resizeRange(0.05d, (-1.0d));
    org.jfree.data.xy.DefaultXYDataset var8 = new org.jfree.data.xy.DefaultXYDataset();
    int var9 = var8.getSeriesCount();
    org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var10, (org.jfree.data.Range)var11);
    boolean var13 = var8.equals((java.lang.Object)var10);
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var14, (org.jfree.data.Range)var15);
    org.jfree.chart.block.LengthConstraintType var17 = var16.getWidthConstraintType();
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var20, (org.jfree.data.Range)var21);
    org.jfree.chart.block.LengthConstraintType var23 = var22.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var10, var17, 0.0d, (org.jfree.data.Range)var19, var23);
    var1.setRangeWithMargins((org.jfree.data.Range)var10, true, false);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var30 = var28.getDataset(10);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers(10, var32);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
    org.jfree.data.Range var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultAutoRange(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var6 = var5.getBaseItemLabelPaint();
//     var4.setBaseFillPaint(var6);
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var6};
//     java.awt.Stroke var9 = null;
//     java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
//     java.awt.Stroke var11 = null;
//     java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var3, var8, var10, var12, var14);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var18 = var17.getBaseItemLabelPaint();
//     var16.setBaseFillPaint(var18);
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var18};
//     java.awt.Paint[] var21 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var27 = var26.getBaseItemLabelPaint();
//     var25.setBaseFillPaint(var27);
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var27};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Shape var34 = null;
//     java.awt.Shape[] var35 = new java.awt.Shape[] { var34};
//     org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var24, var29, var31, var33, var35);
//     java.awt.Paint[] var37 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var39 = var38.getBaseItemLabelPaint();
//     java.awt.Paint[] var40 = new java.awt.Paint[] { var39};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var43 = var42.getBaseItemLabelPaint();
//     var41.setBaseFillPaint(var43);
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var43};
//     java.awt.Stroke var46 = null;
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     java.awt.Stroke var48 = null;
//     java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
//     java.awt.Shape var50 = null;
//     java.awt.Shape[] var51 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var40, var45, var47, var49, var51);
//     java.awt.Paint[] var53 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var55 = var54.getBaseItemLabelPaint();
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var58 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var59 = var58.getBaseItemLabelPaint();
//     var57.setBaseFillPaint(var59);
//     java.awt.Paint[] var61 = new java.awt.Paint[] { var59};
//     java.awt.Stroke var62 = null;
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Stroke var64 = null;
//     java.awt.Stroke[] var65 = new java.awt.Stroke[] { var64};
//     java.awt.Shape var66 = null;
//     java.awt.Shape[] var67 = new java.awt.Shape[] { var66};
//     org.jfree.chart.plot.DefaultDrawingSupplier var68 = new org.jfree.chart.plot.DefaultDrawingSupplier(var53, var56, var61, var63, var65, var67);
//     org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var20, var31, var49, var67);
//     
//     // Checks the contract:  equals-hashcode on var15 and var36
//     assertTrue("Contract failed: equals-hashcode on var15 and var36", var15.equals(var36) ? var15.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var52
//     assertTrue("Contract failed: equals-hashcode on var15 and var52", var15.equals(var52) ? var15.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var68
//     assertTrue("Contract failed: equals-hashcode on var15 and var68", var15.equals(var68) ? var15.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var15
//     assertTrue("Contract failed: equals-hashcode on var36 and var15", var36.equals(var15) ? var36.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var52
//     assertTrue("Contract failed: equals-hashcode on var36 and var52", var36.equals(var52) ? var36.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var68
//     assertTrue("Contract failed: equals-hashcode on var36 and var68", var36.equals(var68) ? var36.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var15
//     assertTrue("Contract failed: equals-hashcode on var52 and var15", var52.equals(var15) ? var52.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var36
//     assertTrue("Contract failed: equals-hashcode on var52 and var36", var52.equals(var36) ? var52.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var68
//     assertTrue("Contract failed: equals-hashcode on var52 and var68", var52.equals(var68) ? var52.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var15
//     assertTrue("Contract failed: equals-hashcode on var68 and var15", var68.equals(var15) ? var68.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var36
//     assertTrue("Contract failed: equals-hashcode on var68 and var36", var68.equals(var36) ? var68.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var52
//     assertTrue("Contract failed: equals-hashcode on var68 and var52", var68.equals(var52) ? var68.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     org.jfree.chart.util.SortOrder var4 = var2.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var5.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var11 = var7.isItemLabelVisible(0, (-1), true);
//     boolean var12 = var6.equals((java.lang.Object)var7);
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var14 = var13.getBaseStroke();
//     var7.setBaseStroke(var14, false);
//     var2.setRangeCrosshairStroke(var14);
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var20 = var2.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var19);
//     java.awt.Font var22 = var19.getTickLabelFont((java.lang.Comparable)(byte)1);
//     var0.setLegendTextFont(0, var22);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var0.setShadowXOffset((-1.0d));
//     org.jfree.chart.labels.CategoryToolTipGenerator var4 = var0.getSeriesToolTipGenerator(10);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var9 = var8.getLabelAngle();
//     java.lang.String var10 = var8.getLabelURL();
//     org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var13 = var12.getLabelInsets();
//     org.jfree.chart.util.Layer var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var16 = var15.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     var0.drawAnnotations(var5, var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var14, var17);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var1 = var0.getXFormat();
//     java.util.Currency var2 = null;
//     var1.setCurrency(var2);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var3, "", "", "");
    java.lang.String var8 = var7.getName();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var12, "", "", "");
    java.lang.String var17 = var16.getName();
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var16);
    java.lang.String var19 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var19.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var9);
    org.jfree.chart.JFreeChart var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var16 = new org.jfree.chart.entity.JFreeChartEntity(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var4 = var2.getDomainBounds(true);
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
//     double var7 = var2.getDomainUpperBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var2.getItemCount(255);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.ChartRenderingInfo var2 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var3 = var2.getChartArea();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.entity.PieSectionEntity var10 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var3, var4, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = var12.getLegendItems();
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     var15.setAutoTickUnitSelection(true);
//     int var18 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.util.Layer var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     var0.drawAnnotations(var1, var3, var11, (org.jfree.chart.axis.ValueAxis)var15, var19, var22);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getSeriesKey(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.util.RectangleAnchor var14 = var4.getTextAnchor();
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setContentAlignmentPoint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.lang.String var5 = var4.getToolTipText();
//     var4.setToolTipText("");
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var10 = var9.getBaseItemLabelPaint();
//     java.awt.Paint var12 = var9.getSeriesPaint(10);
//     java.awt.Shape var14 = null;
//     var9.setSeriesShape(0, var14, false);
//     var9.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     var9.setBaseShape((java.awt.Shape)var20);
//     org.jfree.data.general.PieDataset var22 = null;
//     java.lang.Comparable var25 = null;
//     org.jfree.chart.entity.PieSectionEntity var28 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var20, var22, 100, 2147483647, var25, "", "Polar Plot");
//     java.lang.Object var29 = null;
//     java.lang.Object var30 = var4.draw(var8, var20, var29);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var0, (java.lang.Comparable[])var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    org.jfree.chart.entity.PlotEntity var9 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    var13.setBaseCreateEntities(true, false);
    java.awt.Paint var23 = var13.lookupSeriesFillPaint(2147483647);
    java.awt.Paint var25 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var27 = var26.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var32 = var31.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("", var32);
    java.lang.String var34 = var33.getToolTipText();
    var33.setToolTipText("");
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var39 = null;
    org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
    org.jfree.chart.entity.PlotEntity var41 = new org.jfree.chart.entity.PlotEntity(var38, (org.jfree.chart.plot.Plot)var40);
    boolean var42 = var33.equals((java.lang.Object)var38);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.clone(var38);
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var45 = var44.getLegendItems();
    org.jfree.chart.util.SortOrder var46 = var44.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var47 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var48 = var47.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var53 = var49.isItemLabelVisible(0, (-1), true);
    boolean var54 = var48.equals((java.lang.Object)var49);
    org.jfree.chart.renderer.xy.XYBarRenderer var55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var56 = var55.getBaseStroke();
    var49.setBaseStroke(var56, false);
    var44.setRangeCrosshairStroke(var56);
    java.awt.Color var63 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem(var0, "VerticalAlignment.CENTER", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "hi!", false, var6, false, var23, false, var25, var27, false, var43, var56, (java.awt.Paint)var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 255);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.awt.Paint var6 = var0.getSeriesFillPaint(100);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var7.getBaseNegativeItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var8);
//     org.jfree.data.time.TimeSeries var11 = null;
//     org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection(var11);
//     org.jfree.chart.axis.LogAxis var14 = new org.jfree.chart.axis.LogAxis("");
//     var14.setAutoTickUnitSelection(true);
//     var14.resizeRange(0.05d, (-1.0d));
//     boolean var20 = var14.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var21 = null;
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, (org.jfree.chart.axis.ValueAxis)var14, var21);
//     java.lang.String var23 = var22.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var26 = var25.getBaseItemLabelPaint();
//     var24.setBaseFillPaint(var26);
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var26);
//     var22.setRadiusGridlinePaint(var26);
//     var0.setSeriesFillPaint(255, var26);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var0.", var25.equals(var0) == var0.equals(var25));
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var1 = null;
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var8 = var7.getChartArea();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.entity.PieSectionEntity var15 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var8, var9, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     var5.draw(var6, var8);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var7 = var6.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
    var0.setBaseItemLabelFont(var7, false);
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var13 = var12.getXFormat();
    var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
    org.jfree.data.time.TimeSeries var15 = null;
    java.util.TimeZone var16 = null;
    org.jfree.data.time.TimeSeriesCollection var17 = new org.jfree.data.time.TimeSeriesCollection(var15, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var20 = var12.generateLabelString((org.jfree.data.xy.XYDataset)var17, 0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleAnchor var6 = null;
    java.awt.geom.Point2D var7 = org.jfree.chart.util.RectangleAnchor.coordinates(var5, var6);
    var0.zoomRangeAxes(0.05d, var4, var7, false);
    org.jfree.chart.plot.CategoryMarker var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-1), var11, var12, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0d, 0.8f, 2.0f);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.rotateShape(var5, 3.0d, 1.0f, 0.0f);
    org.jfree.data.time.TimeSeries var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var10);
    org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
    var13.setAutoTickUnitSelection(true);
    var13.resizeRange(0.05d, (-1.0d));
    boolean var19 = var13.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var11, (org.jfree.chart.axis.ValueAxis)var13, var20);
    java.lang.String var22 = var21.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var25 = var24.getBaseItemLabelPaint();
    var23.setBaseFillPaint(var25);
    org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var25);
    var21.setRadiusGridlinePaint(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem(var0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "", var5, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Polar Plot"+ "'", var22.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var1 = var0.getXFormat();
    boolean var3 = var0.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var4 = var3.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.resizeRange(0.05d, (-1.0d));
    boolean var7 = var1.isVerticalTickLabels();
    java.text.NumberFormat var8 = var1.getNumberFormatOverride();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelInsets();
    java.awt.geom.Rectangle2D var12 = null;
    var0.drawDomainGridLine(var7, var8, (org.jfree.chart.axis.ValueAxis)var10, var12, 10.0d);
    java.util.Collection var15 = var0.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0, false);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
//     double var5 = var3.getLabelGap();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.chart.entity.PlotEntity var10 = new org.jfree.chart.entity.PlotEntity(var7, (org.jfree.chart.plot.Plot)var9);
//     double var11 = var9.getLabelGap();
//     org.jfree.chart.labels.PieSectionLabelGenerator var12 = var9.getLabelGenerator();
//     var3.setLabelGenerator(var12);
//     
//     // Checks the contract:  equals-hashcode on var3 and var9
//     assertTrue("Contract failed: equals-hashcode on var3 and var9", var3.equals(var9) ? var3.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var3
//     assertTrue("Contract failed: equals-hashcode on var9 and var3", var9.equals(var3) ? var9.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     int var4 = var0.indexOf(var3);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     var5.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var17 = var5.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var18 = null;
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18, var19);
//     org.jfree.data.Range var22 = var20.getDomainBounds(true);
//     org.jfree.data.Range var23 = var5.findDomainBounds((org.jfree.data.xy.XYDataset)var20);
//     java.awt.Paint var24 = var5.getBaseItemLabelPaint();
//     var0.setDomainCrosshairPaint(var24);
//     org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var28 = var27.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var34 = var33.getLegendItems();
//     org.jfree.chart.util.SortOrder var35 = var33.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Point2D var40 = org.jfree.chart.util.RectangleAnchor.coordinates(var38, var39);
//     var33.zoomRangeAxes(0.05d, var37, var40, false);
//     var30.zoomDomainAxes(0.08d, var32, var40, false);
//     var0.zoomDomainAxes(1.0d, var29, var40, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var34
//     assertTrue("Contract failed: equals-hashcode on var1 and var34", var1.equals(var34) ? var1.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var1
//     assertTrue("Contract failed: equals-hashcode on var34 and var1", var34.equals(var1) ? var34.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    double var3 = var1.getMaximumExplodePercent();
    java.awt.Paint var5 = var1.getSectionOutlinePaint((java.lang.Comparable)0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var1.handleClick(10, 0, var5);
//     org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var9 = var8.getLabelInsets();
//     java.lang.Object var10 = null;
//     boolean var11 = var9.equals(var10);
//     var1.setSimpleLabelOffset(var9);
//     org.jfree.chart.axis.LogAxis var14 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
//     var1.setLabelPadding(var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var19 = var18.getBaseItemLabelPaint();
//     java.awt.Paint var21 = var18.getSeriesPaint(10);
//     java.awt.Shape var23 = null;
//     var18.setSeriesShape(0, var23, false);
//     var18.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var28 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var29 = var28.getChartArea();
//     var18.setBaseShape((java.awt.Shape)var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     java.lang.Comparable var34 = null;
//     org.jfree.chart.entity.PieSectionEntity var37 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var29, var31, 100, 2147483647, var34, "", "Polar Plot");
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     org.jfree.chart.entity.PlotEntity var42 = new org.jfree.chart.entity.PlotEntity(var39, (org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.ChartRenderingInfo var44 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var45 = var44.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     org.jfree.chart.plot.PiePlotState var47 = var1.initialise(var17, var29, var41, (java.lang.Integer)2147483647, var46);
//     
//     // Checks the contract:  equals-hashcode on var28 and var44
//     assertTrue("Contract failed: equals-hashcode on var28 and var44", var28.equals(var44) ? var28.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var28
//     assertTrue("Contract failed: equals-hashcode on var44 and var28", var44.equals(var28) ? var44.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var0.setShadowXOffset((-1.0d));
    var0.setDrawBarOutline(false);
    var0.setSeriesVisible(0, (java.lang.Boolean)false, false);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(1);
    org.jfree.chart.plot.PieLabelRecord var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 3.0d, 1.0f, 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, 4.0d, 0.8f, 10.0f);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAnchor var4 = var0.getDomainGridlinePosition();
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var4 = var3.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("hi!", var4);
//     org.jfree.chart.util.RectangleAnchor var6 = var5.getTextAnchor();
//     java.awt.geom.Point2D var7 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var6);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var3 = var2.getLimit();
//     double var4 = var2.getLimit();
//     org.jfree.chart.JFreeChart var5 = var2.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
//     java.lang.Object var9 = var5.clone();
//     org.jfree.chart.event.TitleChangeEvent var10 = null;
//     var5.titleChanged(var10);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    boolean var4 = var3.getAntiAlias();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var5 = var3.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var12 = var0.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var13 = null;
    java.util.TimeZone var14 = null;
    org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var13, var14);
    org.jfree.data.Range var17 = var15.getDomainBounds(true);
    org.jfree.data.Range var18 = var0.findDomainBounds((org.jfree.data.xy.XYDataset)var15);
    java.awt.Paint var19 = var0.getBaseItemLabelPaint();
    var0.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.05d, 1.0d, 0.025d, 90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    double var3 = var2.getLimit();
    double var4 = var2.getLimit();
    org.jfree.chart.JFreeChart var5 = var2.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
    java.lang.Object var9 = var5.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var12 = var5.createBufferedImage(0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.getStartYValue(1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.StandardXYToolTipGenerator var9 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    var8.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var9, true);
    java.awt.Stroke var15 = var8.getItemStroke(0, 100, false);
    var0.setBaseStroke(var15, false);
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var0.notifyListeners(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    boolean var2 = var1.getProcessVisibleItemsOnly();
    org.jfree.data.time.TimeSeries var3 = null;
    java.util.TimeZone var4 = null;
    org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
    org.jfree.data.Range var7 = var5.getDomainBounds(true);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var5);
    var1.startSeriesPass((org.jfree.data.xy.XYDataset)var5, 100, 0, (-1), 10, 10);
    java.lang.Number var15 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var5);
    java.lang.Number var16 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + Double.NaN+ "'", var15.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + Double.NaN+ "'", var16.equals(Double.NaN));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    int var9 = var0.indexOf((java.lang.Comparable)4.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.getItemCount(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.resizeRange(0.05d, (-1.0d));
    var1.configure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.jfree.data.time.TimePeriodAnchor var9 = var2.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.getItemCount(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var6 = var2.isItemLabelVisible(0, (-1), true);
    boolean var7 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var9 = var8.getBaseStroke();
    var2.setBaseStroke(var9, false);
    org.jfree.chart.labels.XYItemLabelGenerator var12 = var2.getBaseItemLabelGenerator();
    boolean var13 = var2.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getXValue(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setCategoryLabelPositionOffset((-1));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var15, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var21 = var20.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
    double var23 = var22.getLimit();
    double var24 = var22.getLimit();
    org.jfree.chart.JFreeChart var25 = var22.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var25, (-1), 1);
    boolean var29 = var19.equals((java.lang.Object)var25);
    org.jfree.chart.title.LegendTitle var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.addLegend(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var1 = var0.getBaseItemLabelPaint();
//     java.awt.Paint var3 = var0.getSeriesPaint(10);
//     boolean var4 = var0.getDataBoundsIncludesVisibleSeriesOnly();
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var7 = var6.getBaseStroke();
//     var0.setSeriesOutlineStroke(10, var7);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, (-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var2 = new org.jfree.chart.block.BlockBorder(var1);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
//     var5.setAutoTickUnitSelection(true);
//     boolean var8 = var5.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var5.setTickUnit(var10, false, true);
//     var3.setTickUnit(var10, false, true);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var20 = var19.getBaseItemLabelPaint();
//     java.awt.Paint var22 = var19.getSeriesPaint(10);
//     java.awt.Shape var24 = null;
//     var19.setSeriesShape(0, var24, false);
//     var19.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var30 = var29.getChartArea();
//     var19.setBaseShape((java.awt.Shape)var30);
//     org.jfree.data.general.PieDataset var32 = null;
//     java.lang.Comparable var35 = null;
//     org.jfree.chart.entity.PieSectionEntity var38 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var30, var32, 100, 2147483647, var35, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var42 = var41.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("", var42);
//     java.lang.String var44 = var43.getToolTipText();
//     var43.setToolTipText("");
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.PiePlot var50 = new org.jfree.chart.plot.PiePlot(var49);
//     org.jfree.chart.entity.PlotEntity var51 = new org.jfree.chart.entity.PlotEntity(var48, (org.jfree.chart.plot.Plot)var50);
//     boolean var52 = var43.equals((java.lang.Object)var48);
//     org.jfree.chart.axis.LogAxis var54 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var55 = var54.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var58 = new org.jfree.chart.entity.AxisEntity(var48, (org.jfree.chart.axis.Axis)var54, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var60 = var59.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var61 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var62 = var61.getLimit();
//     double var63 = var61.getLimit();
//     org.jfree.chart.JFreeChart var64 = var61.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var67 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var59, var64, (-1), 1);
//     boolean var68 = var58.equals((java.lang.Object)var64);
//     org.jfree.chart.entity.JFreeChartEntity var70 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var30, var64, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var72 = var71.getBaseItemLabelPaint();
//     java.awt.Paint var74 = var71.getSeriesPaint(10);
//     java.awt.Shape var76 = null;
//     var71.setSeriesShape(0, var76, false);
//     var71.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var81 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var82 = var81.getChartArea();
//     var71.setBaseShape((java.awt.Shape)var82);
//     org.jfree.chart.plot.CategoryPlot var84 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var85 = var84.getLegendItems();
//     var84.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var87 = null;
//     int var88 = var84.indexOf(var87);
//     org.jfree.chart.util.RectangleEdge var89 = var84.getDomainAxisEdge();
//     boolean var90 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var89);
//     boolean var91 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var89);
//     org.jfree.chart.ChartRenderingInfo var92 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var93 = var92.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var94 = new org.jfree.chart.plot.PlotRenderingInfo(var92);
//     org.jfree.chart.axis.AxisState var95 = var3.draw(var17, 3.0d, var30, var82, var89, var94);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10);
    org.jfree.chart.util.GradientPaintTransformer var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setGradientTransformer(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
    var0.setItemMargin(3.0d);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)(-1.0d));
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
    boolean var19 = var18.getNotify();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("");
    boolean var22 = var21.getNotify();
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var24 = var23.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var24);
    var21.setFrame((org.jfree.chart.block.BlockFrame)var25);
    var21.setURLText("");
    var16.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var21);
    var9.setWrapper((org.jfree.chart.block.BlockContainer)var16);
    org.jfree.chart.util.RectangleInsets var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setMargin(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    boolean var4 = var1.isAutoTickUnitSelection();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
    org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var14 = var10.isItemLabelVisible(0, (-1), true);
    boolean var15 = var9.equals((java.lang.Object)var10);
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    var10.setBaseStroke(var17, false);
    var5.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    boolean var25 = var5.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    double var3 = var2.getLimit();
    double var4 = var2.getLimit();
    org.jfree.chart.JFreeChart var5 = var2.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
    java.lang.Object var9 = var5.clone();
    boolean var10 = var5.isNotify();
    org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var14 = var5.createBufferedImage((-1), (-1), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     boolean var2 = var0.containsDomainValue(0L);
//     var0.addBaseTimelineExclusions((-1L), 100L);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleAnchor var9 = null;
//     java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
//     var3.zoomRangeAxes(0.05d, var7, var10, false);
//     var0.zoomDomainAxes(0.08d, var2, var10, false);
//     var0.setAngleGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var0.zoomRangeAxes(2.0d, 0.14d, var21, var24);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.resizeRange(0.05d, (-1.0d));
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var8 = var7.getBaseItemLabelPaint();
    var1.setTickLabelPaint(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBase(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     double var1 = var0.getTop();
//     org.jfree.chart.ChartRenderingInfo var2 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var3 = var2.getChartArea();
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var5 = var4.getBaseItemLabelPaint();
//     java.awt.Paint var7 = var4.getSeriesPaint(10);
//     java.awt.Shape var9 = null;
//     var4.setSeriesShape(0, var9, false);
//     var4.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     var4.setBaseShape((java.awt.Shape)var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     java.lang.Comparable var20 = null;
//     org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var15, var17, 100, 2147483647, var20, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var27 = var26.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("", var27);
//     java.lang.String var29 = var28.getToolTipText();
//     var28.setToolTipText("");
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     org.jfree.chart.entity.PlotEntity var36 = new org.jfree.chart.entity.PlotEntity(var33, (org.jfree.chart.plot.Plot)var35);
//     boolean var37 = var28.equals((java.lang.Object)var33);
//     org.jfree.chart.axis.LogAxis var39 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var40 = var39.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var43 = new org.jfree.chart.entity.AxisEntity(var33, (org.jfree.chart.axis.Axis)var39, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var45 = var44.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var46 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var47 = var46.getLimit();
//     double var48 = var46.getLimit();
//     org.jfree.chart.JFreeChart var49 = var46.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var52 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var44, var49, (-1), 1);
//     boolean var53 = var43.equals((java.lang.Object)var49);
//     org.jfree.chart.entity.JFreeChartEntity var55 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var15, var49, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     java.awt.geom.Rectangle2D var56 = var0.expand(var3, var15);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("VerticalAlignment.CENTER", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(0);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var11 = var10.getCategories();
//     org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var14 = var13.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var16 = var0.initialise(var8, var9, var10, 0, var15);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var1 = null;
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("");
//     boolean var8 = var7.getNotify();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("");
//     boolean var11 = var10.getNotify();
//     org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var13 = var12.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var13);
//     var10.setFrame((org.jfree.chart.block.BlockFrame)var14);
//     var10.setURLText("");
//     var5.add((org.jfree.chart.block.Block)var7, (java.lang.Object)var10);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var22 = var21.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("hi!", var22);
//     var23.setMargin(4.0d, 10.0d, 100.0d, 4.0d);
//     var5.add((org.jfree.chart.block.Block)var23);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.util.Size2D var31 = var23.arrange(var30);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var6 = var2.isItemLabelVisible(0, (-1), true);
//     boolean var7 = var1.equals((java.lang.Object)var2);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     var13.setAutoTickUnitSelection(true);
//     int var16 = var10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getLegendItems();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var23);
//     boolean var27 = var17.removeDomainMarker((org.jfree.chart.plot.Marker)var26);
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var29 = var28.getBaseItemLabelPaint();
//     java.awt.Paint var31 = var28.getSeriesPaint(10);
//     java.awt.Shape var33 = null;
//     var28.setSeriesShape(0, var33, false);
//     var28.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var39 = var38.getChartArea();
//     var28.setBaseShape((java.awt.Shape)var39);
//     org.jfree.data.general.PieDataset var41 = null;
//     java.lang.Comparable var44 = null;
//     org.jfree.chart.entity.PieSectionEntity var47 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var39, var41, 100, 2147483647, var44, "", "Polar Plot");
//     var2.drawDomainMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.plot.Marker)var26, var39);
//     
//     // Checks the contract:  equals-hashcode on var10 and var17
//     assertTrue("Contract failed: equals-hashcode on var10 and var17", var10.equals(var17) ? var10.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var10
//     assertTrue("Contract failed: equals-hashcode on var17 and var10", var17.equals(var10) ? var17.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var11
//     assertTrue("Contract failed: equals-hashcode on var18 and var11", var18.equals(var11) ? var18.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.general.DatasetGroup var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setGroup(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
//     var2.setAutoTickUnitSelection(true);
//     boolean var5 = var2.isAutoTickUnitSelection();
//     var2.resizeRange(0.05d);
//     java.awt.Font var8 = var2.getLabelFont();
//     org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("hi!", var8);
//     org.jfree.chart.text.TextFragment var10 = var9.getLastTextFragment();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.text.TextAnchor var14 = null;
//     var10.draw(var11, 100.0f, 2.0f, var14, 100.0f, 100.0f, (-0.975d));
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var1 = var0.getBaseToolTipGenerator();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var7 = var3.getURLGenerator(100, (-1), false);
//     java.awt.Paint var9 = var3.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var10 = null;
//     var3.setLegendItemToolTipGenerator(var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = var12.getLegendItems();
//     org.jfree.chart.util.SortOrder var14 = var12.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var21 = var17.isItemLabelVisible(0, (-1), true);
//     boolean var22 = var16.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var24 = var23.getBaseStroke();
//     var17.setBaseStroke(var24, false);
//     var12.setRangeCrosshairStroke(var24);
//     var3.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     org.jfree.chart.axis.LogAxis var30 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var31 = var30.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var33 = var32.getChartArea();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var37 = var36.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
//     var35.setNoDataMessagePaint(var37);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var41 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     var40.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var41, true);
//     java.awt.Stroke var47 = var40.getItemStroke(0, 100, false);
//     var0.drawRangeLine(var2, var12, (org.jfree.chart.axis.ValueAxis)var30, var33, 0.0d, var37, var47);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    int var2 = var1.getSeriesCount();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var6.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var12 = var8.isItemLabelVisible(0, (-1), true);
    boolean var13 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var15 = var14.getBaseStroke();
    var8.setBaseStroke(var15, false);
    var3.setRangeCrosshairStroke(var15);
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var21 = var3.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var20);
    org.jfree.data.Range var23 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1, var21, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(1);
    var1.sort();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var4 = var1.getPieLabelRecord(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
//     float var7 = var6.getForegroundAlpha();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, 1, true);
//     double var13 = var0.getMaximumBarWidth();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var16 = var15.getCategories();
//     java.lang.Object var17 = null;
//     boolean var18 = var15.equals(var17);
//     org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var24 = var20.getURLGenerator(100, (-1), false);
//     java.awt.Paint var26 = var20.getSeriesFillPaint(100);
//     java.awt.Stroke var28 = var20.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var30 = var29.getBaseItemLabelPaint();
//     java.awt.Paint var32 = var29.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var34 = var33.getBaseNegativeItemLabelPosition();
//     var29.setPositiveItemLabelPositionFallback(var34);
//     var20.setPositiveItemLabelPositionFallback(var34);
//     boolean var37 = var19.equals((java.lang.Object)var34);
//     boolean var38 = var15.equals((java.lang.Object)var34);
//     org.jfree.chart.axis.LogAxis var40 = new org.jfree.chart.axis.LogAxis("");
//     var40.setAutoTickUnitSelection(true);
//     boolean var43 = var40.isAutoTickUnitSelection();
//     var40.resizeRange(0.05d);
//     java.awt.Font var46 = var40.getLabelFont();
//     org.jfree.chart.plot.IntervalMarker var49 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
//     org.jfree.chart.event.MarkerChangeListener var50 = null;
//     var49.addChangeListener(var50);
//     java.awt.geom.Rectangle2D var52 = null;
//     var0.drawRangeMarker(var14, var15, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.plot.Marker)var49, var52);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var2 = var1.getLabelAngle();
//     java.lang.String var3 = var1.getLabelURL();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
//     org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var11 = var10.getBaseItemLabelPaint();
//     var9.setBaseFillPaint(var11);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
//     org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
//     var4.setRangeGridlinePaint(var11);
//     var4.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
//     java.lang.Object var21 = null;
//     boolean var22 = var20.equals(var21);
//     var4.setAxisOffset(var20);
//     var1.setLabelInsets(var20, true);
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var29, 0, 0);
//     org.jfree.chart.axis.CategoryAnchor var33 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var37 = var36.getChartArea();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.entity.PieSectionEntity var44 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var37, var38, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var46 = var45.getLegendItems();
//     var45.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var48 = null;
//     int var49 = var45.indexOf(var48);
//     org.jfree.chart.util.RectangleEdge var50 = var45.getDomainAxisEdge();
//     org.jfree.data.xy.XYDataItem var53 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
//     int var55 = var53.compareTo((java.lang.Object)100.0f);
//     boolean var56 = var50.equals((java.lang.Object)var53);
//     double var57 = var1.getCategoryJava2DCoordinate(var33, 100, (-1), var37, var50);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape(var2, 3.0d, 1.0f, 0.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var6, 2.0d, 1.0f, 0.0f);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var9 = new org.jfree.chart.axis.SymbolAxis("hi!", var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    boolean var14 = var11.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var16 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var11.setTickUnit(var16, false, true);
    var9.setTickUnit(var16, false, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var31 = var27.getURLGenerator(100, (-1), false);
    java.awt.Paint var33 = var27.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var34 = null;
    var27.setLegendItemToolTipGenerator(var34);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var40 = var39.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("", var40);
    var27.setSeriesItemLabelFont(1, var40, false);
    org.jfree.chart.axis.MarkerAxisBand var44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var9, Double.NaN, 3.0d, 0.08d, 4.0d, var40);
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var9);
    java.lang.String var47 = var9.valueToString(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + ""+ "'", var47.equals(""));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.plot.CategoryMarker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.CENTER", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    var0.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var11 = var10.getChartArea();
    var0.setBaseShape((java.awt.Shape)var11);
    org.jfree.data.general.PieDataset var13 = null;
    java.lang.Comparable var16 = null;
    org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var11, var13, 100, 2147483647, var16, "", "Polar Plot");
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var23 = var22.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("", var23);
    java.lang.String var25 = var24.getToolTipText();
    var24.setToolTipText("");
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var29, (org.jfree.chart.plot.Plot)var31);
    boolean var33 = var24.equals((java.lang.Object)var29);
    org.jfree.chart.axis.LogAxis var35 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var36 = var35.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var39 = new org.jfree.chart.entity.AxisEntity(var29, (org.jfree.chart.axis.Axis)var35, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var41 = var40.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var42 = new org.jfree.chart.plot.MultiplePiePlot();
    double var43 = var42.getLimit();
    double var44 = var42.getLimit();
    org.jfree.chart.JFreeChart var45 = var42.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var48 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var40, var45, (-1), 1);
    boolean var49 = var39.equals((java.lang.Object)var45);
    org.jfree.chart.entity.JFreeChartEntity var51 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var11, var45, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.event.ChartChangeListener var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var45.addChangeListener(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.StandardXYToolTipGenerator var1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    var0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var1, true);
    org.jfree.data.time.TimeSeries var4 = null;
    java.util.TimeZone var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var4, var5);
    org.jfree.data.Range var8 = var6.getDomainBounds(true);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    java.lang.String[] var11 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var12 = var6.equals((java.lang.Object)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var15 = var1.generateToolTip((org.jfree.data.xy.XYDataset)var6, (-1), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2147483647, 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Polar Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.plot.PlotOrientation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    var0.setShapesFilled(false);
    java.awt.Stroke var5 = var0.getSeriesOutlineStroke(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    var1.handleClick(10, 0, var5);
    java.awt.Paint var7 = var1.getShadowPaint();
    org.jfree.chart.urls.PieURLGenerator var8 = var1.getURLGenerator();
    org.jfree.chart.util.Rotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.getStartXValue(10, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    java.awt.Paint var3 = var0.getSeriesPaint(10);
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.StandardXYToolTipGenerator var9 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    var8.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var9, true);
    java.awt.Stroke var15 = var8.getItemStroke(0, 100, false);
    var0.setBaseStroke(var15, false);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var18, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var6 = var5.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var8 = var7.getLimit();
//     double var9 = var7.getLimit();
//     org.jfree.chart.JFreeChart var10 = var7.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var10, (-1), 1);
//     var4.setFrame((org.jfree.chart.block.BlockFrame)var5);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var17 = var16.getBaseItemLabelPaint();
//     java.awt.Paint var19 = var16.getSeriesPaint(10);
//     java.awt.Shape var21 = null;
//     var16.setSeriesShape(0, var21, false);
//     var16.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var27 = var26.getChartArea();
//     var16.setBaseShape((java.awt.Shape)var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     java.lang.Comparable var32 = null;
//     org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var27, var29, 100, 2147483647, var32, "", "Polar Plot");
//     var5.draw(var15, var27);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var3.getStartX(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.14d, 0.2d, 0, (java.lang.Comparable)0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    int var9 = var0.indexOf((java.lang.Comparable)4.0d);
    int var11 = var0.indexOf((java.lang.Comparable)0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance(var0);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.util.SortOrder var3 = var1.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var4.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var10 = var6.isItemLabelVisible(0, (-1), true);
    boolean var11 = var5.equals((java.lang.Object)var6);
    org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var13 = var12.getBaseStroke();
    var6.setBaseStroke(var13, false);
    var1.setRangeCrosshairStroke(var13);
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var19 = var1.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
//     double var5 = var3.getLabelGap();
//     org.jfree.chart.labels.PieSectionLabelGenerator var6 = var3.getLabelGenerator();
//     org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var10 = var9.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     var3.handleClick((-1), 100, var11);
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var14 = var13.getBaseItemLabelPaint();
//     java.awt.Paint var16 = var13.getSeriesPaint(10);
//     java.awt.Shape var18 = null;
//     var13.setSeriesShape(0, var18, false);
//     var13.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var23 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var24 = var23.getChartArea();
//     var13.setBaseShape((java.awt.Shape)var24);
//     org.jfree.data.general.PieDataset var26 = null;
//     java.lang.Comparable var29 = null;
//     org.jfree.chart.entity.PieSectionEntity var32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var24, var26, 100, 2147483647, var29, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var36 = var35.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("", var36);
//     java.lang.String var38 = var37.getToolTipText();
//     var37.setToolTipText("");
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
//     org.jfree.chart.entity.PlotEntity var45 = new org.jfree.chart.entity.PlotEntity(var42, (org.jfree.chart.plot.Plot)var44);
//     boolean var46 = var37.equals((java.lang.Object)var42);
//     org.jfree.chart.axis.LogAxis var48 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var49 = var48.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var52 = new org.jfree.chart.entity.AxisEntity(var42, (org.jfree.chart.axis.Axis)var48, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var54 = var53.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var55 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var56 = var55.getLimit();
//     double var57 = var55.getLimit();
//     org.jfree.chart.JFreeChart var58 = var55.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var61 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var53, var58, (-1), 1);
//     boolean var62 = var52.equals((java.lang.Object)var58);
//     org.jfree.chart.entity.JFreeChartEntity var64 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var24, var58, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     var11.setPlotArea(var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var44
//     assertTrue("Contract failed: equals-hashcode on var3 and var44", var3.equals(var44) ? var3.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var3
//     assertTrue("Contract failed: equals-hashcode on var44 and var3", var44.equals(var3) ? var44.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var23
//     assertTrue("Contract failed: equals-hashcode on var9 and var23", var9.equals(var23) ? var9.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var9
//     assertTrue("Contract failed: equals-hashcode on var23 and var9", var23.equals(var9) ? var23.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
//     java.lang.Class var3 = null;
//     java.util.EventListener[] var4 = var2.getListeners(var3);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var3, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var3.getStartY(13, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    var1.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var1.rendererChanged(var4);
    java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var10 = new org.jfree.chart.axis.SymbolAxis("hi!", var9);
    org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
    var12.setAutoTickUnitSelection(true);
    boolean var15 = var12.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var17 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var12.setTickUnit(var17, false, true);
    var10.setTickUnit(var17, false, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var32 = var28.getURLGenerator(100, (-1), false);
    java.awt.Paint var34 = var28.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var35 = null;
    var28.setLegendItemToolTipGenerator(var35);
    org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var41 = var40.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("", var41);
    var28.setSeriesItemLabelFont(1, var41, false);
    org.jfree.chart.axis.MarkerAxisBand var45 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var10, Double.NaN, 3.0d, 0.08d, 4.0d, var41);
    var1.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var47 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var2.getX(255, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.awt.Paint var6 = var0.getSeriesFillPaint(100);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var7.getBaseNegativeItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var8);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var10.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var16 = var12.isItemLabelVisible(0, (-1), true);
//     boolean var17 = var11.equals((java.lang.Object)var12);
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var19 = var18.getBaseStroke();
//     var12.setBaseStroke(var19, false);
//     var0.setBaseStroke(var19);
//     
//     // Checks the contract:  equals-hashcode on var8 and var11
//     assertTrue("Contract failed: equals-hashcode on var8 and var11", var8.equals(var11) ? var8.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var8
//     assertTrue("Contract failed: equals-hashcode on var11 and var8", var11.equals(var8) ? var11.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var6 = var5.getBaseItemLabelPaint();
//     var4.setBaseFillPaint(var6);
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var6};
//     java.awt.Stroke var9 = null;
//     java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
//     java.awt.Stroke var11 = null;
//     java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var3, var8, var10, var12, var14);
//     java.awt.Paint[] var16 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var18 = var17.getBaseItemLabelPaint();
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var22 = var21.getBaseItemLabelPaint();
//     var20.setBaseFillPaint(var22);
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var22};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Shape var29 = null;
//     java.awt.Shape[] var30 = new java.awt.Shape[] { var29};
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var19, var24, var26, var28, var30);
//     java.awt.Paint[] var32 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var34 = var33.getBaseItemLabelPaint();
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var38 = var37.getBaseItemLabelPaint();
//     var36.setBaseFillPaint(var38);
//     java.awt.Paint[] var40 = new java.awt.Paint[] { var38};
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Shape var45 = null;
//     java.awt.Shape[] var46 = new java.awt.Shape[] { var45};
//     org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var35, var40, var42, var44, var46);
//     java.awt.Paint[] var48 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var50 = var49.getBaseItemLabelPaint();
//     java.awt.Paint[] var51 = new java.awt.Paint[] { var50};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var54 = var53.getBaseItemLabelPaint();
//     var52.setBaseFillPaint(var54);
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var54};
//     java.awt.Stroke var57 = null;
//     java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
//     java.awt.Stroke var59 = null;
//     java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
//     java.awt.Shape var61 = null;
//     java.awt.Shape[] var62 = new java.awt.Shape[] { var61};
//     org.jfree.chart.plot.DefaultDrawingSupplier var63 = new org.jfree.chart.plot.DefaultDrawingSupplier(var48, var51, var56, var58, var60, var62);
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.rotateShape(var65, 3.0d, 1.0f, 0.0f);
//     java.awt.Shape[] var70 = new java.awt.Shape[] { var69};
//     org.jfree.chart.plot.DefaultDrawingSupplier var71 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var19, var44, var58, var70);
//     
//     // Checks the contract:  equals-hashcode on var15 and var31
//     assertTrue("Contract failed: equals-hashcode on var15 and var31", var15.equals(var31) ? var15.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var47
//     assertTrue("Contract failed: equals-hashcode on var15 and var47", var15.equals(var47) ? var15.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var63
//     assertTrue("Contract failed: equals-hashcode on var15 and var63", var15.equals(var63) ? var15.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var15
//     assertTrue("Contract failed: equals-hashcode on var31 and var15", var31.equals(var15) ? var31.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var47
//     assertTrue("Contract failed: equals-hashcode on var31 and var47", var31.equals(var47) ? var31.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var63
//     assertTrue("Contract failed: equals-hashcode on var31 and var63", var31.equals(var63) ? var31.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var15
//     assertTrue("Contract failed: equals-hashcode on var47 and var15", var47.equals(var15) ? var47.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var31
//     assertTrue("Contract failed: equals-hashcode on var47 and var31", var47.equals(var31) ? var47.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var63
//     assertTrue("Contract failed: equals-hashcode on var47 and var63", var47.equals(var63) ? var47.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var15
//     assertTrue("Contract failed: equals-hashcode on var63 and var15", var63.equals(var15) ? var63.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var31
//     assertTrue("Contract failed: equals-hashcode on var63 and var31", var63.equals(var31) ? var63.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var47
//     assertTrue("Contract failed: equals-hashcode on var63 and var47", var63.equals(var47) ? var63.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelInsets();
    double var5 = var3.calculateLeftInset(0.025d);
    double var6 = var3.getRight();
    var0.setAxisOffset(var3);
    org.jfree.chart.util.RectangleEdge var8 = var0.getRangeAxisEdge();
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var0.rendererChanged(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var2 = var1.getLabelAngle();
//     float var3 = var1.getMaximumCategoryLabelWidthRatio();
//     double var4 = var1.getFixedDimension();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var8 = var5.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAnchor var9 = var5.getDomainGridlinePosition();
//     org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var13 = var12.getBaseItemLabelPaint();
//     java.awt.Paint var15 = var12.getSeriesPaint(10);
//     java.awt.Shape var17 = null;
//     var12.setSeriesShape(0, var17, false);
//     var12.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var23 = var22.getChartArea();
//     var12.setBaseShape((java.awt.Shape)var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var26 = var25.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var27 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var28 = var27.getLimit();
//     double var29 = var27.getLimit();
//     org.jfree.chart.JFreeChart var30 = var27.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var25, var30, (-1), 1);
//     java.lang.Object var34 = var30.clone();
//     org.jfree.chart.entity.JFreeChartEntity var35 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var23, var30);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var37 = var36.getLegendItems();
//     var36.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     int var40 = var36.indexOf(var39);
//     org.jfree.chart.util.RectangleEdge var41 = var36.getDomainAxisEdge();
//     double var42 = var1.getCategoryJava2DCoordinate(var9, 1, 13, var23, var41);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    float var1 = var0.getForegroundAlpha();
    var0.setNotify(false);
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    double var5 = var4.getLimit();
    double var6 = var4.getLimit();
    var0.setParent((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.util.TableOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDataExtractOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var4 = var2.getDomainBounds(true);
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
    java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.jfree.data.time.TimePeriodAnchor var9 = var2.getXPosition();
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "TimePeriodAnchor.START"+ "'", var10.equals("TimePeriodAnchor.START"));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Polar Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.rendererChanged(var3);
//     java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var9 = new org.jfree.chart.axis.SymbolAxis("hi!", var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     boolean var14 = var11.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var16 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var11.setTickUnit(var16, false, true);
//     var9.setTickUnit(var16, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var31 = var27.getURLGenerator(100, (-1), false);
//     java.awt.Paint var33 = var27.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var34 = null;
//     var27.setLegendItemToolTipGenerator(var34);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var40 = var39.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("", var40);
//     var27.setSeriesItemLabelFont(1, var40, false);
//     org.jfree.chart.axis.MarkerAxisBand var44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var9, Double.NaN, 3.0d, 0.08d, 4.0d, var40);
//     var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var47 = var46.getLegendItems();
//     var46.clearDomainAxes();
//     org.jfree.chart.axis.LogAxis var51 = new org.jfree.chart.axis.LogAxis("");
//     var51.setAutoTickUnitSelection(true);
//     var51.resizeRange(0.05d, (-1.0d));
//     var51.setVerticalTickLabels(false);
//     var46.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var51, true);
//     org.jfree.chart.axis.AxisSpace var61 = var46.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var63 = var46.getDomainAxisLocation(10);
//     var0.setDomainAxisLocation(var63);
//     
//     // Checks the contract:  equals-hashcode on var1 and var47
//     assertTrue("Contract failed: equals-hashcode on var1 and var47", var1.equals(var47) ? var1.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var1
//     assertTrue("Contract failed: equals-hashcode on var47 and var1", var47.equals(var1) ? var47.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
//     var5.setAutoTickUnitSelection(true);
//     boolean var8 = var5.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var5.setTickUnit(var10, false, true);
//     var3.setTickUnit(var10, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(100, (-1), false);
//     java.awt.Paint var27 = var21.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var28 = null;
//     var21.setLegendItemToolTipGenerator(var28);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var34 = var33.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("", var34);
//     var21.setSeriesItemLabelFont(1, var34, false);
//     org.jfree.chart.axis.MarkerAxisBand var38 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var3, Double.NaN, 3.0d, 0.08d, 4.0d, var34);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var40 = var39.getLegendItems();
//     org.jfree.chart.util.SortOrder var41 = var39.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var46 = var45.getBaseItemLabelPaint();
//     var44.setBaseFillPaint(var46);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var46);
//     org.jfree.chart.plot.IntervalMarker var49 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var46);
//     var39.setRangeGridlinePaint(var46);
//     org.jfree.chart.util.SortOrder var51 = var39.getColumnRenderingOrder();
//     var3.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var45 and var21.", var45.equals(var21) == var21.equals(var45));
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TimePeriodAnchor.START", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     var0.clearDomainMarkers();
//     int var5 = var0.getCrosshairDatasetIndex();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     org.jfree.chart.util.SortOrder var10 = var8.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
//     var8.zoomRangeAxes(0.05d, var12, var15, false);
//     var0.zoomRangeAxes(10.0d, var7, var15, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var1.setTickUnit(var6, false, true);
//     var1.setTickLabelsVisible(true);
//     java.lang.String[] var14 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var15 = new org.jfree.chart.axis.SymbolAxis("hi!", var14);
//     org.jfree.chart.axis.LogAxis var17 = new org.jfree.chart.axis.LogAxis("");
//     var17.setAutoTickUnitSelection(true);
//     boolean var20 = var17.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var22 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var17.setTickUnit(var22, false, true);
//     var15.setTickUnit(var22, false, true);
//     org.jfree.chart.ChartRenderingInfo var30 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var31 = var30.getChartArea();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.entity.PieSectionEntity var38 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var31, var32, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var40 = var39.getLegendItems();
//     var39.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var42 = null;
//     int var43 = var39.indexOf(var42);
//     org.jfree.chart.util.RectangleEdge var44 = var39.getDomainAxisEdge();
//     boolean var45 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var44);
//     double var46 = var15.valueToJava2D(0.05d, var31, var44);
//     var1.setLeftArrow((java.awt.Shape)var31);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var49 = var48.getLegendItems();
//     var48.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var51 = null;
//     int var52 = var48.indexOf(var51);
//     org.jfree.chart.util.RectangleEdge var53 = var48.getDomainAxisEdge();
//     boolean var54 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var53);
//     boolean var55 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var53);
//     double var56 = org.jfree.chart.util.RectangleEdge.coordinate(var31, var53);
//     
//     // Checks the contract:  equals-hashcode on var39 and var48
//     assertTrue("Contract failed: equals-hashcode on var39 and var48", var39.equals(var48) ? var39.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var39
//     assertTrue("Contract failed: equals-hashcode on var48 and var39", var48.equals(var39) ? var48.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var49
//     assertTrue("Contract failed: equals-hashcode on var40 and var49", var40.equals(var49) ? var40.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var40
//     assertTrue("Contract failed: equals-hashcode on var49 and var40", var49.equals(var40) ? var49.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(100, (-1), false);
//     boolean var10 = var4.equals((java.lang.Object)var5);
//     java.awt.Paint var14 = var5.getItemFillPaint(100, (-1), true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var17 = var16.getBaseItemLabelPaint();
//     java.awt.Paint var19 = var16.getSeriesPaint(10);
//     java.awt.Shape var21 = null;
//     var16.setSeriesShape(0, var21, false);
//     var16.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var27 = var26.getChartArea();
//     var16.setBaseShape((java.awt.Shape)var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     java.lang.Comparable var32 = null;
//     org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var27, var29, 100, 2147483647, var32, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var39 = var38.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var40 = new org.jfree.chart.block.LabelBlock("", var39);
//     java.lang.String var41 = var40.getToolTipText();
//     var40.setToolTipText("");
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     org.jfree.chart.entity.PlotEntity var48 = new org.jfree.chart.entity.PlotEntity(var45, (org.jfree.chart.plot.Plot)var47);
//     boolean var49 = var40.equals((java.lang.Object)var45);
//     org.jfree.chart.axis.LogAxis var51 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var52 = var51.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var55 = new org.jfree.chart.entity.AxisEntity(var45, (org.jfree.chart.axis.Axis)var51, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var57 = var56.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var58 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var59 = var58.getLimit();
//     double var60 = var58.getLimit();
//     org.jfree.chart.JFreeChart var61 = var58.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var64 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var56, var61, (-1), 1);
//     boolean var65 = var55.equals((java.lang.Object)var61);
//     org.jfree.chart.entity.JFreeChartEntity var67 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var27, var61, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.plot.XYPlot var68 = null;
//     org.jfree.data.time.TimeSeries var69 = null;
//     org.jfree.data.time.TimeSeriesCollection var70 = new org.jfree.data.time.TimeSeriesCollection(var69);
//     int var72 = var70.indexOf((java.lang.Comparable)86400000L);
//     org.jfree.chart.axis.LogAxis var74 = new org.jfree.chart.axis.LogAxis("");
//     var74.setAutoTickUnitSelection(true);
//     var74.resizeRange(0.05d, (-1.0d));
//     var74.configure();
//     org.jfree.chart.renderer.PolarItemRenderer var81 = null;
//     org.jfree.chart.plot.PolarPlot var82 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var70, (org.jfree.chart.axis.ValueAxis)var74, var81);
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var84 = var5.initialise(var15, var27, var68, (org.jfree.data.xy.XYDataset)var70, var83);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     java.awt.Paint var4 = var1.getSeriesPaint(10);
//     java.awt.Shape var6 = null;
//     var1.setSeriesShape(0, var6, false);
//     var1.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     var1.setBaseShape((java.awt.Shape)var12);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var15 = var14.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var17 = var16.getLimit();
//     double var18 = var16.getLimit();
//     org.jfree.chart.JFreeChart var19 = var16.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var14, var19, (-1), 1);
//     java.lang.Object var23 = var19.clone();
//     org.jfree.chart.entity.JFreeChartEntity var24 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var12, var19);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var12, 10.0d, 0.0f, 1.0f);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
    float var7 = var6.getForegroundAlpha();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, 1, true);
    double var13 = var0.getMaximumBarWidth();
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator(2147483647, var15, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.labels.StandardXYToolTipGenerator var1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var2 = var1.getXFormat();
//     org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var2, 0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     var5.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
//     org.jfree.chart.axis.LogAxis var16 = new org.jfree.chart.axis.LogAxis("");
//     var16.setAutoTickUnitSelection(true);
//     var16.resizeRange(0.05d, (-1.0d));
//     boolean var22 = var16.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, (org.jfree.chart.axis.ValueAxis)var16, var23);
//     java.lang.String var25 = var24.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var28 = var27.getBaseItemLabelPaint();
//     var26.setBaseFillPaint(var28);
//     org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var28);
//     var24.setRadiusGridlinePaint(var28);
//     var5.setSeriesPaint(100, var28, true);
//     java.awt.Shape var35 = var5.lookupLegendShape(10);
//     java.lang.StringBuffer var36 = null;
//     java.text.FieldPosition var37 = null;
//     java.lang.StringBuffer var38 = var2.format((java.lang.Object)10, var36, var37);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.lang.String var5 = var4.getToolTipText();
//     var4.setToolTipText("");
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
//     boolean var13 = var4.equals((java.lang.Object)var9);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var15, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var21 = var20.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var23 = var22.getLimit();
//     double var24 = var22.getLimit();
//     org.jfree.chart.JFreeChart var25 = var22.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var25, (-1), 1);
//     boolean var29 = var19.equals((java.lang.Object)var25);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var32 = var31.getBaseItemLabelPaint();
//     java.awt.Paint var34 = var31.getSeriesPaint(10);
//     java.awt.Shape var36 = null;
//     var31.setSeriesShape(0, var36, false);
//     var31.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var41 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var42 = var41.getChartArea();
//     var31.setBaseShape((java.awt.Shape)var42);
//     org.jfree.data.general.PieDataset var44 = null;
//     java.lang.Comparable var47 = null;
//     org.jfree.chart.entity.PieSectionEntity var50 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var42, var44, 100, 2147483647, var47, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var54 = var53.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("", var54);
//     java.lang.String var56 = var55.getToolTipText();
//     var55.setToolTipText("");
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot(var61);
//     org.jfree.chart.entity.PlotEntity var63 = new org.jfree.chart.entity.PlotEntity(var60, (org.jfree.chart.plot.Plot)var62);
//     boolean var64 = var55.equals((java.lang.Object)var60);
//     org.jfree.chart.axis.LogAxis var66 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var67 = var66.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var70 = new org.jfree.chart.entity.AxisEntity(var60, (org.jfree.chart.axis.Axis)var66, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var71 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var72 = var71.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var73 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var74 = var73.getLimit();
//     double var75 = var73.getLimit();
//     org.jfree.chart.JFreeChart var76 = var73.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var79 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var71, var76, (-1), 1);
//     boolean var80 = var70.equals((java.lang.Object)var76);
//     org.jfree.chart.entity.JFreeChartEntity var82 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var42, var76, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.ChartRenderingInfo var83 = new org.jfree.chart.ChartRenderingInfo();
//     var25.draw(var30, var42, var83);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
    org.jfree.chart.util.Layer var13 = null;
    boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
    org.jfree.chart.util.LengthAdjustmentType var16 = var12.getLabelOffsetType();
    org.jfree.chart.util.RectangleAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setLabelAnchor(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var0, (org.jfree.data.Range)var1);
//     java.lang.String var3 = var0.toString();
//     double var5 = var0.constrain(2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    boolean var2 = var1.getProcessVisibleItemsOnly();
    org.jfree.data.time.TimeSeries var3 = null;
    java.util.TimeZone var4 = null;
    org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
    org.jfree.data.Range var7 = var5.getDomainBounds(true);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var5);
    var1.startSeriesPass((org.jfree.data.xy.XYDataset)var5, 100, 0, (-1), 10, 10);
    var1.setProcessVisibleItemsOnly(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getSeriesItemLabelGenerator((-1));
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = null;
//     java.lang.String[] var15 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var16 = new org.jfree.chart.axis.SymbolAxis("hi!", var15);
//     org.jfree.chart.axis.LogAxis var18 = new org.jfree.chart.axis.LogAxis("");
//     var18.setAutoTickUnitSelection(true);
//     boolean var21 = var18.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var18.setTickUnit(var23, false, true);
//     var16.setTickUnit(var23, false, true);
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var32 = var31.getChartArea();
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.entity.PieSectionEntity var39 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var32, var33, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var41 = var40.getLegendItems();
//     var40.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var43 = null;
//     int var44 = var40.indexOf(var43);
//     org.jfree.chart.util.RectangleEdge var45 = var40.getDomainAxisEdge();
//     boolean var46 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var45);
//     double var47 = var16.valueToJava2D(0.05d, var32, var45);
//     var0.drawOutline(var11, var12, var32);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var6 = var5.getLabelAngle();
    java.lang.String var7 = var5.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
    org.jfree.chart.util.SortOrder var10 = var8.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var15 = var14.getBaseItemLabelPaint();
    var13.setBaseFillPaint(var15);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
    org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var15);
    var8.setRangeGridlinePaint(var15);
    var8.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var23 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var24 = var23.getLabelInsets();
    java.lang.Object var25 = null;
    boolean var26 = var24.equals(var25);
    var8.setAxisOffset(var24);
    var5.setLabelInsets(var24, true);
    var1.setTickLabelInsets(var24);
    double var32 = var24.extendHeight(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 8.0d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    var0.removeSeries((java.lang.Comparable)1418759999999L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var11 = var0.getSeriesKey(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.setMaximumCategoryLabelWidthRatio(10.0f);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.data.Range var3 = org.jfree.data.Range.shift((org.jfree.data.Range)var1, 10.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.combine(var0, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = org.jfree.data.Range.scale(var3, (-0.975d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     java.awt.Paint[] var5 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var7 = var6.getBaseItemLabelPaint();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var11 = var10.getBaseItemLabelPaint();
//     var9.setBaseFillPaint(var11);
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var11};
//     java.awt.Stroke var14 = null;
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Shape var18 = null;
//     java.awt.Shape[] var19 = new java.awt.Shape[] { var18};
//     org.jfree.chart.plot.DefaultDrawingSupplier var20 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var8, var13, var15, var17, var19);
//     java.awt.Paint[] var21 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var27 = var26.getBaseItemLabelPaint();
//     var25.setBaseFillPaint(var27);
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var27};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Shape var34 = null;
//     java.awt.Shape[] var35 = new java.awt.Shape[] { var34};
//     org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var24, var29, var31, var33, var35);
//     java.awt.Paint[] var37 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var39 = var38.getBaseItemLabelPaint();
//     java.awt.Paint[] var40 = new java.awt.Paint[] { var39};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var43 = var42.getBaseItemLabelPaint();
//     var41.setBaseFillPaint(var43);
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var43};
//     java.awt.Stroke var46 = null;
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     java.awt.Stroke var48 = null;
//     java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
//     java.awt.Shape var50 = null;
//     java.awt.Shape[] var51 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var40, var45, var47, var49, var51);
//     java.awt.Paint[] var53 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var55 = var54.getBaseItemLabelPaint();
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var58 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var59 = var58.getBaseItemLabelPaint();
//     var57.setBaseFillPaint(var59);
//     java.awt.Paint[] var61 = new java.awt.Paint[] { var59};
//     java.awt.Stroke var62 = null;
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Stroke var64 = null;
//     java.awt.Stroke[] var65 = new java.awt.Stroke[] { var64};
//     java.awt.Shape var66 = null;
//     java.awt.Shape[] var67 = new java.awt.Shape[] { var66};
//     org.jfree.chart.plot.DefaultDrawingSupplier var68 = new org.jfree.chart.plot.DefaultDrawingSupplier(var53, var56, var61, var63, var65, var67);
//     org.jfree.chart.axis.CategoryAxis3D var71 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var72 = var71.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("", var72);
//     java.lang.String var74 = var73.getToolTipText();
//     var73.setToolTipText("");
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var79 = null;
//     org.jfree.chart.plot.PiePlot var80 = new org.jfree.chart.plot.PiePlot(var79);
//     org.jfree.chart.entity.PlotEntity var81 = new org.jfree.chart.entity.PlotEntity(var78, (org.jfree.chart.plot.Plot)var80);
//     boolean var82 = var73.equals((java.lang.Object)var78);
//     java.awt.Shape var83 = org.jfree.chart.util.ShapeUtilities.clone(var78);
//     java.awt.Shape[] var84 = new java.awt.Shape[] { var78};
//     org.jfree.chart.plot.DefaultDrawingSupplier var85 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var5, var24, var47, var63, var84);
//     
//     // Checks the contract:  equals-hashcode on var20 and var36
//     assertTrue("Contract failed: equals-hashcode on var20 and var36", var20.equals(var36) ? var20.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var52
//     assertTrue("Contract failed: equals-hashcode on var20 and var52", var20.equals(var52) ? var20.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var68
//     assertTrue("Contract failed: equals-hashcode on var20 and var68", var20.equals(var68) ? var20.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var20
//     assertTrue("Contract failed: equals-hashcode on var36 and var20", var36.equals(var20) ? var36.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var52
//     assertTrue("Contract failed: equals-hashcode on var36 and var52", var36.equals(var52) ? var36.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var68
//     assertTrue("Contract failed: equals-hashcode on var36 and var68", var36.equals(var68) ? var36.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var20
//     assertTrue("Contract failed: equals-hashcode on var52 and var20", var52.equals(var20) ? var52.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var36
//     assertTrue("Contract failed: equals-hashcode on var52 and var36", var52.equals(var36) ? var52.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var68
//     assertTrue("Contract failed: equals-hashcode on var52 and var68", var52.equals(var68) ? var52.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var20
//     assertTrue("Contract failed: equals-hashcode on var68 and var20", var68.equals(var20) ? var68.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var36
//     assertTrue("Contract failed: equals-hashcode on var68 and var36", var68.equals(var36) ? var68.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var52
//     assertTrue("Contract failed: equals-hashcode on var68 and var52", var68.equals(var52) ? var68.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(Double.NaN);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.clearDomainMarkers();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var5.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var11 = var7.isItemLabelVisible(0, (-1), true);
    boolean var12 = var6.equals((java.lang.Object)var7);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var14 = var13.getBaseStroke();
    var7.setBaseStroke(var14, false);
    var0.setDomainCrosshairStroke(var14);
    org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var21 = var20.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var22 = var20.getPlotInfo();
    java.awt.geom.Point2D var23 = null;
    var0.zoomDomainAxes(3.0d, 3.0d, var22, var23);
    org.jfree.data.category.CategoryDataset var25 = null;
    var0.setDataset(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var0.setShadowXOffset((-1.0d));
    var0.setDrawBarOutline(false);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    boolean var14 = var8.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var6, (org.jfree.chart.axis.ValueAxis)var8, var15);
    java.lang.String var17 = var16.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var22 = var21.getBaseItemLabelPaint();
    var20.setBaseFillPaint(var22);
    org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder(var22);
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var22);
    var16.setAngleLabelPaint(var22);
    var0.setShadowPaint(var22);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var30 = var29.getBaseItemLabelPaint();
    java.awt.Paint var32 = var29.getSeriesPaint(10);
    java.awt.Shape var34 = null;
    var29.setSeriesShape(0, var34, false);
    var29.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var39 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var40 = var39.getChartArea();
    var29.setBaseShape((java.awt.Shape)var40);
    org.jfree.data.general.PieDataset var42 = null;
    java.lang.Comparable var45 = null;
    org.jfree.chart.entity.PieSectionEntity var48 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var40, var42, 100, 2147483647, var45, "", "Polar Plot");
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var52 = var51.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("", var52);
    java.lang.String var54 = var53.getToolTipText();
    var53.setToolTipText("");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var59 = null;
    org.jfree.chart.plot.PiePlot var60 = new org.jfree.chart.plot.PiePlot(var59);
    org.jfree.chart.entity.PlotEntity var61 = new org.jfree.chart.entity.PlotEntity(var58, (org.jfree.chart.plot.Plot)var60);
    boolean var62 = var53.equals((java.lang.Object)var58);
    org.jfree.chart.axis.LogAxis var64 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var65 = var64.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var68 = new org.jfree.chart.entity.AxisEntity(var58, (org.jfree.chart.axis.Axis)var64, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var69 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var70 = var69.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var71 = new org.jfree.chart.plot.MultiplePiePlot();
    double var72 = var71.getLimit();
    double var73 = var71.getLimit();
    org.jfree.chart.JFreeChart var74 = var71.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var77 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var69, var74, (-1), 1);
    boolean var78 = var68.equals((java.lang.Object)var74);
    org.jfree.chart.entity.JFreeChartEntity var80 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var40, var74, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    org.jfree.chart.plot.CategoryPlot var81 = null;
    org.jfree.chart.ChartRenderingInfo var83 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var84 = var83.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var85 = new org.jfree.chart.plot.PlotRenderingInfo(var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var86 = var0.initialise(var28, var40, var81, 2147483647, var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Polar Plot"+ "'", var17.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var12 = null;
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
//     boolean var19 = var18.getNotify();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("");
//     boolean var22 = var21.getNotify();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var24 = var23.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var24);
//     var21.setFrame((org.jfree.chart.block.BlockFrame)var25);
//     var21.setURLText("");
//     var16.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var21);
//     var9.setWrapper((org.jfree.chart.block.BlockContainer)var16);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var33 = var32.getChartArea();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.entity.PieSectionEntity var40 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var33, var34, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     var41.setShapesFilled(true);
//     var41.setShapesVisible(false);
//     java.lang.Object var50 = var16.draw(var31, var33, (java.lang.Object)var41);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.awt.Paint var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!", var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    var3.setType(var4);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var2 = var1.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var4 = var3.getLimit();
//     double var5 = var3.getLimit();
//     org.jfree.chart.JFreeChart var6 = var3.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var6, (-1), 1);
//     org.jfree.chart.event.ChartProgressEvent var12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(short)100, var6, 10, 2147483647);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
//     var14.setSeriesToolTipGenerator(0, var16, true);
//     boolean var19 = var14.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var14.getPositiveItemLabelPositionFallback();
//     var14.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var24 = var23.getBaseItemLabelPaint();
//     java.awt.Paint var26 = var23.getSeriesPaint(10);
//     java.awt.Shape var28 = null;
//     var23.setSeriesShape(0, var28, false);
//     var23.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var34 = var33.getChartArea();
//     var23.setBaseShape((java.awt.Shape)var34);
//     boolean var36 = var14.equals((java.lang.Object)var34);
//     org.jfree.data.time.TimeSeries var37 = null;
//     org.jfree.data.time.TimeSeriesCollection var38 = new org.jfree.data.time.TimeSeriesCollection(var37);
//     org.jfree.chart.axis.LogAxis var40 = new org.jfree.chart.axis.LogAxis("");
//     var40.setAutoTickUnitSelection(true);
//     var40.resizeRange(0.05d, (-1.0d));
//     boolean var46 = var40.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var47 = null;
//     org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var38, (org.jfree.chart.axis.ValueAxis)var40, var47);
//     var48.addCornerTextItem("");
//     org.jfree.chart.ChartRenderingInfo var52 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var53 = var52.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     org.jfree.chart.renderer.xy.XYItemRendererState var55 = new org.jfree.chart.renderer.xy.XYItemRendererState(var54);
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleAnchor var57 = null;
//     java.awt.geom.Point2D var58 = org.jfree.chart.util.RectangleAnchor.coordinates(var56, var57);
//     var48.zoomRangeAxes(0.14d, var54, var58);
//     org.jfree.chart.ChartRenderingInfo var60 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var61 = var60.getChartArea();
//     var6.draw(var13, var34, var58, var60);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Polar Plot", var1, 0.0f, 2.0f, var4, 100.0d, var6);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseStroke();
//     java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var7 = var6.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
//     var0.setBaseItemLabelFont(var7, false);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var13 = var12.getXFormat();
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
//     org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
//     java.lang.Object var23 = var22.clone();
//     var22.setSeriesLinesVisible(15, (java.lang.Boolean)false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var28 = var27.getBaseStroke();
//     java.lang.Boolean var30 = var27.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var34 = var33.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("", var34);
//     var27.setBaseItemLabelFont(var34, false);
//     boolean var38 = var22.equals((java.lang.Object)var34);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var0.", var27.equals(var0) == var0.equals(var27));
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var1 = var0.getCategories();
    org.jfree.chart.plot.IntervalMarker var5 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    org.jfree.chart.util.Layer var6 = null;
    var0.addRangeMarker(13, (org.jfree.chart.plot.Marker)var5, var6);
    var5.setLabel("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.data.category.CategoryDataset var5 = var0.getDataset();
    java.lang.Object var6 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var3 = var2.getLimit();
//     double var4 = var2.getLimit();
//     org.jfree.chart.JFreeChart var5 = var2.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
//     java.lang.Object var9 = var5.clone();
//     boolean var10 = var5.isNotify();
//     org.jfree.chart.title.LegendTitle var11 = var5.getLegend();
//     boolean var12 = var5.getAntiAlias();
//     var5.setBorderVisible(true);
//     java.awt.RenderingHints var15 = null;
//     var5.setRenderingHints(var15);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.get(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Font var2 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     var1.setParent((org.jfree.chart.plot.Plot)var4);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
//     double var5 = var3.getStartAngle();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var8 = var7.getBaseItemLabelPaint();
//     java.awt.Paint var10 = var7.getSeriesPaint(10);
//     java.awt.Shape var12 = null;
//     var7.setSeriesShape(0, var12, false);
//     var7.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var18 = var17.getChartArea();
//     var7.setBaseShape((java.awt.Shape)var18);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     double var22 = var21.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     var21.handleClick(10, 0, var25);
//     org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var29 = var28.getLabelInsets();
//     java.lang.Object var30 = null;
//     boolean var31 = var29.equals(var30);
//     var21.setSimpleLabelOffset(var29);
//     org.jfree.chart.axis.LogAxis var34 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var35 = var34.getLabelInsets();
//     var21.setLabelPadding(var35);
//     org.jfree.chart.axis.LogAxis var38 = new org.jfree.chart.axis.LogAxis("");
//     var38.setAutoTickUnitSelection(true);
//     var38.setVisible(false);
//     boolean var43 = var21.equals((java.lang.Object)false);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var48 = var45.getFixedRangeAxisSpace();
//     var45.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var50.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var56 = var52.isItemLabelVisible(0, (-1), true);
//     boolean var57 = var51.equals((java.lang.Object)var52);
//     org.jfree.chart.renderer.xy.XYBarRenderer var58 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var59 = var58.getBaseStroke();
//     var52.setBaseStroke(var59, false);
//     var45.setDomainCrosshairStroke(var59);
//     org.jfree.chart.ChartRenderingInfo var65 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var66 = var65.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var67 = var65.getPlotInfo();
//     java.awt.geom.Point2D var68 = null;
//     var45.zoomDomainAxes(3.0d, 3.0d, var67, var68);
//     org.jfree.chart.plot.PiePlotState var70 = var3.initialise(var6, var18, var21, (java.lang.Integer)13, var67);
//     
//     // Checks the contract:  equals-hashcode on var17 and var65
//     assertTrue("Contract failed: equals-hashcode on var17 and var65", var17.equals(var65) ? var17.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var17
//     assertTrue("Contract failed: equals-hashcode on var65 and var17", var65.equals(var17) ? var65.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var6 = var5.getBaseItemLabelPaint();
//     var4.setBaseFillPaint(var6);
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var6);
//     org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var6);
//     boolean var10 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var9);
//     org.jfree.data.time.TimeSeries var12 = null;
//     org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     var15.setAutoTickUnitSelection(true);
//     var15.resizeRange(0.05d, (-1.0d));
//     boolean var21 = var15.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, (org.jfree.chart.axis.ValueAxis)var15, var22);
//     var23.addCornerTextItem("");
//     org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var28 = var27.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     org.jfree.chart.renderer.xy.XYItemRendererState var30 = new org.jfree.chart.renderer.xy.XYItemRendererState(var29);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleAnchor var32 = null;
//     java.awt.geom.Point2D var33 = org.jfree.chart.util.RectangleAnchor.coordinates(var31, var32);
//     var23.zoomRangeAxes(0.14d, var29, var33);
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var39 = var38.getLegendItems();
//     org.jfree.chart.util.SortOrder var40 = var38.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleAnchor var44 = null;
//     java.awt.geom.Point2D var45 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var44);
//     var38.zoomRangeAxes(0.05d, var42, var45, false);
//     var35.zoomDomainAxes(0.08d, var37, var45, false);
//     var0.panDomainAxes(90.0d, var29, var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var38
//     assertTrue("Contract failed: equals-hashcode on var0 and var38", var0.equals(var38) ? var0.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var0
//     assertTrue("Contract failed: equals-hashcode on var38 and var0", var38.equals(var0) ? var38.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var39
//     assertTrue("Contract failed: equals-hashcode on var1 and var39", var1.equals(var39) ? var1.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var1
//     assertTrue("Contract failed: equals-hashcode on var39 and var1", var39.equals(var1) ? var39.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
//     boolean var3 = var1.isPositiveArrowVisible();
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var6 = var5.getBaseStroke();
//     double var7 = var5.getShadowXOffset();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = null;
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.setVisible(false);
//     org.jfree.chart.plot.Plot var16 = var11.getPlot();
//     var11.setLowerMargin(0.08d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var20 = var19.getBaseItemLabelPaint();
//     java.awt.Paint var22 = var19.getSeriesPaint(10);
//     java.awt.Shape var24 = null;
//     var19.setSeriesShape(0, var24, false);
//     var19.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var30 = var29.getChartArea();
//     var19.setBaseShape((java.awt.Shape)var30);
//     org.jfree.data.general.PieDataset var32 = null;
//     java.lang.Comparable var35 = null;
//     org.jfree.chart.entity.PieSectionEntity var38 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var30, var32, 100, 2147483647, var35, "", "Polar Plot");
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     java.awt.Paint var44 = var43.getLabelPaint();
//     var41.setLabelPaint(var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var47 = var46.getLegendItems();
//     org.jfree.chart.util.SortOrder var48 = var46.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var50 = var49.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var55 = var51.isItemLabelVisible(0, (-1), true);
//     boolean var56 = var50.equals((java.lang.Object)var51);
//     org.jfree.chart.renderer.xy.XYBarRenderer var57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var58 = var57.getBaseStroke();
//     var51.setBaseStroke(var58, false);
//     var46.setRangeCrosshairStroke(var58);
//     var5.drawDomainLine(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, var30, 10.0d, var44, var58);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var64 = var63.getLegendItems();
//     var63.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     int var67 = var63.indexOf(var66);
//     org.jfree.chart.util.RectangleEdge var68 = var63.getDomainAxisEdge();
//     double var69 = var1.valueToJava2D(1.0d, var30, var68);
//     
//     // Checks the contract:  equals-hashcode on var47 and var64
//     assertTrue("Contract failed: equals-hashcode on var47 and var64", var47.equals(var64) ? var47.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var47
//     assertTrue("Contract failed: equals-hashcode on var64 and var47", var64.equals(var47) ? var64.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.util.SortOrder var3 = var1.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var4.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var10 = var6.isItemLabelVisible(0, (-1), true);
    boolean var11 = var5.equals((java.lang.Object)var6);
    org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var13 = var12.getBaseStroke();
    var6.setBaseStroke(var13, false);
    var1.setRangeCrosshairStroke(var13);
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var19 = var1.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", var4);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.text.TextMeasurer var8 = null;
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.START", var4, var6, 0.8f, var8);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var3 = var2.getLimit();
//     double var4 = var2.getLimit();
//     org.jfree.chart.JFreeChart var5 = var2.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
//     java.lang.Object var9 = var5.clone();
//     boolean var10 = var5.isNotify();
//     org.jfree.chart.title.LegendTitle var11 = var5.getLegend();
//     var5.removeLegend();
//     var5.setNotify(false);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     long var16 = var15.getMiddleMillisecond();
//     java.util.Date var17 = var15.getStart();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var18.getBaseNegativeItemLabelPosition();
//     var18.setShapesFilled(false);
//     var18.setBaseCreateEntities(false);
//     var18.setPlotArea(true);
//     int var26 = var15.compareTo((java.lang.Object)var18);
//     java.util.Date var27 = var15.getEnd();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var5.setTextAntiAlias((java.lang.Object)var27);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0f, 0.8f, 3.0d, 1.0f, 10.0f);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
    java.lang.String var3 = var2.toString();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "VerticalAlignment.CENTER"+ "'", var3.equals("VerticalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseStroke();
//     java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var7 = var6.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
//     var0.setBaseItemLabelFont(var7, false);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var13 = var12.getXFormat();
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var16, (org.jfree.chart.urls.XYURLGenerator)var20);
//     org.jfree.chart.renderer.xy.XYStepRenderer var22 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var20);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var27 = var23.isItemLabelVisible(0, (-1), true);
//     var23.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var31 = null;
//     org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var31);
//     org.jfree.chart.axis.LogAxis var34 = new org.jfree.chart.axis.LogAxis("");
//     var34.setAutoTickUnitSelection(true);
//     var34.resizeRange(0.05d, (-1.0d));
//     boolean var40 = var34.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var32, (org.jfree.chart.axis.ValueAxis)var34, var41);
//     java.lang.String var43 = var42.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var46 = var45.getBaseItemLabelPaint();
//     var44.setBaseFillPaint(var46);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var46);
//     var42.setRadiusGridlinePaint(var46);
//     var23.setSeriesPaint(100, var46, true);
//     java.awt.Shape var53 = var23.lookupLegendShape(10);
//     var22.setLegendLine(var53);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var56 = var55.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var61 = var57.isItemLabelVisible(0, (-1), true);
//     boolean var62 = var56.equals((java.lang.Object)var57);
//     org.jfree.chart.renderer.xy.XYBarRenderer var63 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var64 = var63.getBaseStroke();
//     var57.setBaseStroke(var64, false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var67 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var68 = var67.getBaseStroke();
//     java.lang.Boolean var70 = var67.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var73 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var74 = var73.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("", var74);
//     var67.setBaseItemLabelFont(var74, false);
//     var57.setBaseItemLabelFont(var74, true);
//     java.awt.Shape var80 = var57.getBaseShape();
//     var22.setLegendLine(var80);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var67 and var0.", var67.equals(var0) == var0.equals(var67));
//     
//     // Checks the contract:  equals-hashcode on var8 and var75
//     assertTrue("Contract failed: equals-hashcode on var8 and var75", var8.equals(var75) ? var8.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var8
//     assertTrue("Contract failed: equals-hashcode on var75 and var8", var75.equals(var8) ? var75.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset(10);
    var0.setDomainCrosshairRowKey((java.lang.Comparable)10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("TextBlockAnchor.CENTER", 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1, (java.awt.Paint)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var13 = var12.getBaseItemLabelPaint();
//     java.awt.Paint var15 = var12.getSeriesPaint(10);
//     java.awt.Shape var17 = null;
//     var12.setSeriesShape(0, var17, false);
//     var12.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var23 = var22.getChartArea();
//     var12.setBaseShape((java.awt.Shape)var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     java.lang.Comparable var28 = null;
//     org.jfree.chart.entity.PieSectionEntity var31 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var23, var25, 100, 2147483647, var28, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var35 = var34.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("", var35);
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var38 = var37.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var39 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var40 = var39.getLimit();
//     double var41 = var39.getLimit();
//     org.jfree.chart.JFreeChart var42 = var39.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var37, var42, (-1), 1);
//     var36.setFrame((org.jfree.chart.block.BlockFrame)var37);
//     java.lang.Object var47 = var9.draw(var11, var23, (java.lang.Object)var37);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var4 = new org.jfree.chart.axis.SymbolAxis("hi!", var3);
//     org.jfree.chart.axis.LogAxis var6 = new org.jfree.chart.axis.LogAxis("");
//     var6.setAutoTickUnitSelection(true);
//     boolean var9 = var6.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var6.setTickUnit(var11, false, true);
//     var4.setTickUnit(var11, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var26 = var22.getURLGenerator(100, (-1), false);
//     java.awt.Paint var28 = var22.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var29 = null;
//     var22.setLegendItemToolTipGenerator(var29);
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var35 = var34.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("", var35);
//     var22.setSeriesItemLabelFont(1, var35, false);
//     org.jfree.chart.axis.MarkerAxisBand var39 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var4, Double.NaN, 3.0d, 0.08d, 4.0d, var35);
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", var35);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var42 = var40.calculateDimensions(var41);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.data.Range var5 = var3.getDomainBounds(true);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var3);
    java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var9 = var3.equals((java.lang.Object)var8);
    org.jfree.data.general.SeriesChangeEvent var10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
    var0.seriesChanged(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var0.getY(0, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(13, var1);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getEnd();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var3, var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    java.awt.Shape var4 = var1.getShape();
    java.io.ObjectOutputStream var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("RectangleConstraintType.RANGE", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(100, (-1), false);
//     java.awt.Paint var11 = var5.getSeriesFillPaint(100);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var13 = var12.getBaseNegativeItemLabelPosition();
//     var5.setBaseNegativeItemLabelPosition(var13);
//     boolean var15 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var18 = var17.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var20 = var19.getLimit();
//     double var21 = var19.getLimit();
//     org.jfree.chart.JFreeChart var22 = var19.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var17, var22, (-1), 1);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getLegendItems();
//     org.jfree.chart.util.SortOrder var28 = var26.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var30 = var29.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var35 = var31.isItemLabelVisible(0, (-1), true);
//     boolean var36 = var30.equals((java.lang.Object)var31);
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var38 = var37.getBaseStroke();
//     var31.setBaseStroke(var38, false);
//     var26.setRangeCrosshairStroke(var38);
//     org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var44 = var26.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var43);
//     java.awt.Font var46 = var43.getTickLabelFont((java.lang.Comparable)(byte)1);
//     boolean var47 = var17.equals((java.lang.Object)var46);
//     var5.setLegendTextFont(10, var46);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var5.", var37.equals(var5) == var5.equals(var37));
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(4.0d, 1.0d);
    java.awt.Paint var3 = var2.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    boolean var4 = var3.getAntiAlias();
    java.awt.Image var5 = null;
    var3.setBackgroundImage(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var7 = var3.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorLeft((-1.0d));
    var1.cursorUp(10.0d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    java.awt.Stroke var8 = var0.lookupSeriesOutlineStroke(100);
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var10 = var9.getBaseItemLabelPaint();
    java.awt.Paint var12 = var9.getSeriesPaint(10);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var14 = var13.getBaseNegativeItemLabelPosition();
    var9.setPositiveItemLabelPositionFallback(var14);
    var0.setPositiveItemLabelPositionFallback(var14);
    org.jfree.chart.plot.XYPlot var17 = var0.getPlot();
    var0.setShadowYOffset(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     int var3 = var1.indexOf((java.lang.Comparable)86400000L);
//     double var5 = var1.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.getEndXValue(10, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NaN);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     double var3 = var2.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var2.handleClick(10, 0, var6);
//     org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var10 = var9.getLabelInsets();
//     java.lang.Object var11 = null;
//     boolean var12 = var10.equals(var11);
//     var2.setSimpleLabelOffset(var10);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
//     var2.setLabelPadding(var16);
//     var0.setSimpleLabelOffset(var16);
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, var20, (org.jfree.chart.urls.XYURLGenerator)var24);
//     boolean var26 = var0.equals((java.lang.Object)10);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var0.drawOutline(var27, var28);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
//     var5.setAutoTickUnitSelection(true);
//     var5.resizeRange(0.05d, (-1.0d));
//     var5.setVerticalTickLabels(false);
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5, true);
//     org.jfree.chart.axis.AxisSpace var15 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var17 = var0.getDomainAxisLocation(10);
//     org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
//     var19.setAutoTickUnitSelection(true);
//     var19.resizeRange(0.05d, (-1.0d));
//     org.jfree.data.xy.DefaultXYDataset var26 = new org.jfree.data.xy.DefaultXYDataset();
//     int var27 = var26.getSeriesCount();
//     org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var28, (org.jfree.data.Range)var29);
//     boolean var31 = var26.equals((java.lang.Object)var28);
//     org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var32, (org.jfree.data.Range)var33);
//     org.jfree.chart.block.LengthConstraintType var35 = var34.getWidthConstraintType();
//     org.jfree.data.time.DateRange var37 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var39 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var38, (org.jfree.data.Range)var39);
//     org.jfree.chart.block.LengthConstraintType var41 = var40.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var28, var35, 0.0d, (org.jfree.data.Range)var37, var41);
//     var19.setRangeWithMargins((org.jfree.data.Range)var28, true, false);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var48 = var46.getDataset(10);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var46.getDomainMarkers(10, var50);
//     var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var46);
//     var46.clearDomainAxes();
//     boolean var54 = var17.equals((java.lang.Object)var46);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var46 and var0.", var46.equals(var0) == var0.equals(var46));
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var0.setShadowXOffset((-1.0d));
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getNegativeItemLabelPosition(2147483647, 100, true);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var10 = var9.getChartArea();
//     org.jfree.chart.plot.CategoryPlot var11 = null;
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var14 = var13.getTickLabelFont();
//     double var15 = var13.getFixedDimension();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var17 = var16.getLegendItems();
//     var16.clearDomainAxes();
//     org.jfree.chart.axis.LogAxis var21 = new org.jfree.chart.axis.LogAxis("");
//     var21.setAutoTickUnitSelection(true);
//     var21.resizeRange(0.05d, (-1.0d));
//     var21.setVerticalTickLabels(false);
//     var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var21, true);
//     var21.setTickLabelsVisible(false);
//     org.jfree.chart.axis.SegmentedTimeline var33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var34 = var33.clone();
//     boolean var35 = var21.equals((java.lang.Object)var33);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     var0.drawItem(var7, var8, var10, var11, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var21, var36, 13, (-1), false, 13);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("hi!", var3);
//     java.lang.String var5 = var4.getURLText();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var4.draw(var6, var7);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     var0.setPositiveItemLabelPositionFallback(var9);
//     boolean var17 = var0.getIncludeBaseInRange();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var19.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var22 = var20.equals((java.lang.Object)var21);
//     var0.setSeriesPositiveItemLabelPosition(1, var20, true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var20
//     assertTrue("Contract failed: equals-hashcode on var9 and var20", var9.equals(var20) ? var9.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var9
//     assertTrue("Contract failed: equals-hashcode on var20 and var9", var20.equals(var9) ? var20.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var4 = var2.getDomainBounds(true);
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var2);
//     java.lang.String[] var7 = org.jfree.data.time.SerialDate.getMonths(false);
//     boolean var8 = var2.equals((java.lang.Object)var7);
//     org.jfree.data.time.TimePeriodAnchor var9 = var2.getXPosition();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
//     var10.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     int var14 = var10.indexOf(var13);
//     org.jfree.chart.plot.Marker var15 = null;
//     boolean var16 = var10.removeDomainMarker(var15);
//     org.jfree.chart.plot.Plot var17 = var10.getRootPlot();
//     boolean var18 = var2.hasListener((java.util.EventListener)var10);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var21 = var20.getLegendItems();
//     var20.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     int var24 = var20.indexOf(var23);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var29 = var25.isItemLabelVisible(0, (-1), true);
//     var25.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var37 = var25.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var38 = null;
//     java.util.TimeZone var39 = null;
//     org.jfree.data.time.TimeSeriesCollection var40 = new org.jfree.data.time.TimeSeriesCollection(var38, var39);
//     org.jfree.data.Range var42 = var40.getDomainBounds(true);
//     org.jfree.data.Range var43 = var25.findDomainBounds((org.jfree.data.xy.XYDataset)var40);
//     java.awt.Paint var44 = var25.getBaseItemLabelPaint();
//     var20.setDomainCrosshairPaint(var44);
//     org.jfree.chart.axis.LogAxis var47 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var48 = var47.getLabelInsets();
//     boolean var49 = var47.isPositiveArrowVisible();
//     var20.setRangeAxis((org.jfree.chart.axis.ValueAxis)var47);
//     var47.setAutoRangeMinimumSize(4.0d);
//     var47.setLabelAngle(0.05d);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var56 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     org.jfree.chart.urls.StandardXYURLGenerator var60 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "hi!");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var56, (org.jfree.chart.urls.XYURLGenerator)var60);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var19, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.renderer.xy.XYItemRenderer)var61);
//     
//     // Checks the contract:  equals-hashcode on var2 and var40
//     assertTrue("Contract failed: equals-hashcode on var2 and var40", var2.equals(var40) ? var2.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var2
//     assertTrue("Contract failed: equals-hashcode on var40 and var2", var40.equals(var2) ? var40.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var21
//     assertTrue("Contract failed: equals-hashcode on var11 and var21", var11.equals(var21) ? var11.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var11
//     assertTrue("Contract failed: equals-hashcode on var21 and var11", var21.equals(var11) ? var21.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    double var4 = var2.calculateLeftInset(0.025d);
    double var5 = var2.getRight();
    double var7 = var2.calculateRightInset((-0.975d));
    double var9 = var2.calculateTopOutset(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(10);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var7 = var6.getBaseItemLabelPaint();
    java.awt.Paint var9 = var6.getSeriesPaint(10);
    java.awt.Shape var11 = null;
    var6.setSeriesShape(0, var11, false);
    var6.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    var6.setBaseShape((java.awt.Shape)var17);
    org.jfree.data.general.PieDataset var19 = null;
    java.lang.Comparable var22 = null;
    org.jfree.chart.entity.PieSectionEntity var25 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var17, var19, 100, 2147483647, var22, "", "Polar Plot");
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var29 = var28.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("", var29);
    java.lang.String var31 = var30.getToolTipText();
    var30.setToolTipText("");
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var35, (org.jfree.chart.plot.Plot)var37);
    boolean var39 = var30.equals((java.lang.Object)var35);
    org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var42 = var41.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var35, (org.jfree.chart.axis.Axis)var41, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var47 = var46.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot();
    double var49 = var48.getLimit();
    double var50 = var48.getLimit();
    org.jfree.chart.JFreeChart var51 = var48.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var46, var51, (-1), 1);
    boolean var55 = var45.equals((java.lang.Object)var51);
    org.jfree.chart.entity.JFreeChartEntity var57 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var17, var51, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    var4.setLine((java.awt.Shape)var17);
    var4.setURLText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var2 = null;
    java.util.TimeZone var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var2, var3);
    org.jfree.data.Range var6 = var4.getDomainBounds(true);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var4);
    java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var10 = var4.equals((java.lang.Object)var9);
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
    var1.seriesChanged(var11);
    var0.seriesChanged(var11);
    java.lang.String var14 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var20 = var19.getBaseStroke();
    var13.setBaseStroke(var20, false);
    var7.setBaseStroke(var20);
    var6.setAxisLineStroke(var20);
    var3.setLabelOutlineStroke(var20);
    java.awt.Paint var26 = var3.getLabelOutlinePaint();
    java.awt.Paint var27 = var3.getBaseSectionPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    float var3 = var1.getMaximumCategoryLabelWidthRatio();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var5, (org.jfree.chart.plot.Plot)var7);
    var1.setPlot((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var11 = var10.getLegendItems();
    org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var13 = var10.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAnchor var14 = var10.getDomainGridlinePosition();
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var18 = var17.getBaseItemLabelPaint();
    java.awt.Paint var20 = var17.getSeriesPaint(10);
    java.awt.Shape var22 = null;
    var17.setSeriesShape(0, var22, false);
    var17.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var28 = var27.getChartArea();
    var17.setBaseShape((java.awt.Shape)var28);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var31 = var30.getLegendItems();
    var30.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var33 = null;
    int var34 = var30.indexOf(var33);
    org.jfree.chart.util.RectangleEdge var35 = var30.getDomainAxisEdge();
    boolean var36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var37 = var1.getCategoryJava2DCoordinate(var14, 0, 0, var28, var35);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var1 = null;
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var3);
//     org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
//     var9.setAutoTickUnitSelection(true);
//     var9.setVisible(false);
//     org.jfree.chart.plot.Plot var14 = var9.getPlot();
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var3, (org.jfree.chart.axis.ValueAxis)var9, var15);
//     java.lang.String[] var19 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var20 = new org.jfree.chart.axis.SymbolAxis("hi!", var19);
//     org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
//     var22.setAutoTickUnitSelection(true);
//     boolean var25 = var22.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var27 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var22.setTickUnit(var27, false, true);
//     var20.setTickUnit(var27, false, true);
//     var9.setTickUnit(var27, true, true);
//     org.jfree.data.time.TimeSeries var37 = null;
//     org.jfree.data.time.TimeSeriesCollection var38 = new org.jfree.data.time.TimeSeriesCollection(var37);
//     int var40 = var38.indexOf((java.lang.Comparable)86400000L);
//     org.jfree.chart.axis.LogAxis var42 = new org.jfree.chart.axis.LogAxis("");
//     var42.setAutoTickUnitSelection(true);
//     var42.resizeRange(0.05d, (-1.0d));
//     var42.configure();
//     org.jfree.chart.renderer.PolarItemRenderer var49 = null;
//     org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var38, (org.jfree.chart.axis.ValueAxis)var42, var49);
//     boolean var51 = var27.equals((java.lang.Object)var38);
//     
//     // Checks the contract:  equals-hashcode on var3 and var38
//     assertTrue("Contract failed: equals-hashcode on var3 and var38", var3.equals(var38) ? var3.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var3
//     assertTrue("Contract failed: equals-hashcode on var38 and var3", var38.equals(var3) ? var38.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.block.BlockContainer var10 = var9.getItemContainer();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var12 = null;
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
//     boolean var19 = var18.getNotify();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("");
//     boolean var22 = var21.getNotify();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var24 = var23.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var24);
//     var21.setFrame((org.jfree.chart.block.BlockFrame)var25);
//     var21.setURLText("");
//     var16.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var21);
//     var9.setWrapper((org.jfree.chart.block.BlockContainer)var16);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var32 = var31.getBaseNegativeItemLabelPosition();
//     var31.setShapesFilled(false);
//     boolean var35 = var16.equals((java.lang.Object)false);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.util.Size2D var37 = var16.arrange(var36);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var52 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
//     var52.setSeriesToolTipGenerator(0, var54, true);
//     boolean var57 = var52.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var58 = var52.getPositiveItemLabelPositionFallback();
//     var52.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var62 = var61.getBaseItemLabelPaint();
//     java.awt.Paint var64 = var61.getSeriesPaint(10);
//     java.awt.Shape var66 = null;
//     var61.setSeriesShape(0, var66, false);
//     var61.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var72 = var71.getChartArea();
//     var61.setBaseShape((java.awt.Shape)var72);
//     boolean var74 = var52.equals((java.lang.Object)var72);
//     var50.draw(var51, var72);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var3 = var2.getBaseStroke();
//     double var4 = var2.getShadowXOffset();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = null;
//     org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
//     var8.setAutoTickUnitSelection(true);
//     var8.setVisible(false);
//     org.jfree.chart.plot.Plot var13 = var8.getPlot();
//     var8.setLowerMargin(0.08d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var17 = var16.getBaseItemLabelPaint();
//     java.awt.Paint var19 = var16.getSeriesPaint(10);
//     java.awt.Shape var21 = null;
//     var16.setSeriesShape(0, var21, false);
//     var16.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var27 = var26.getChartArea();
//     var16.setBaseShape((java.awt.Shape)var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     java.lang.Comparable var32 = null;
//     org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var27, var29, 100, 2147483647, var32, "", "Polar Plot");
//     org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("");
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var38.setLabelPaint(var41);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var44 = var43.getLegendItems();
//     org.jfree.chart.util.SortOrder var45 = var43.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var47 = var46.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var48 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var52 = var48.isItemLabelVisible(0, (-1), true);
//     boolean var53 = var47.equals((java.lang.Object)var48);
//     org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var55 = var54.getBaseStroke();
//     var48.setBaseStroke(var55, false);
//     var43.setRangeCrosshairStroke(var55);
//     var2.drawDomainLine(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, var27, 10.0d, var41, var55);
//     org.jfree.chart.plot.XYPlot var60 = null;
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.ChartRenderingInfo var62 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var63 = var62.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = new org.jfree.chart.plot.PlotRenderingInfo(var62);
//     org.jfree.chart.renderer.xy.XYItemRendererState var65 = new org.jfree.chart.renderer.xy.XYItemRendererState(var64);
//     org.jfree.chart.renderer.xy.XYItemRendererState var66 = var0.initialise(var1, var27, var60, var61, var64);
//     
//     // Checks the contract:  equals-hashcode on var26 and var62
//     assertTrue("Contract failed: equals-hashcode on var26 and var62", var26.equals(var62) ? var26.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var26
//     assertTrue("Contract failed: equals-hashcode on var62 and var26", var62.equals(var26) ? var62.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("TimePeriodAnchor.START");

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getURLGenerator((-1), 0, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getBaseToolTipGenerator();
    boolean var13 = var0.isItemLabelVisible(0, 2147483647, true);
    org.jfree.chart.labels.ItemLabelPosition var14 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
    var0.setBaseItemLabelGenerator(var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     var3.resizeRange(0.05d, (-1.0d));
//     boolean var9 = var3.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var10 = null;
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
//     java.lang.String var12 = var11.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     var13.setBaseFillPaint(var15);
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var15);
//     var11.setRadiusGridlinePaint(var15);
//     java.awt.Paint var19 = var11.getRadiusGridlinePaint();
//     double var20 = var11.getMaxRadius();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var25 = var21.getURLGenerator(100, (-1), false);
//     org.jfree.chart.renderer.xy.XYBarPainter var26 = var21.getBarPainter();
//     org.jfree.chart.labels.ItemLabelPosition var30 = var21.getPositiveItemLabelPosition(2147483647, 0, true);
//     boolean var31 = var21.getUseYInterval();
//     boolean var35 = var21.getItemCreateEntity(0, 2147483647, false);
//     java.util.Collection var36 = var21.getAnnotations();
//     boolean var37 = var11.equals((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var39 = null;
//     org.jfree.data.time.TimeSeriesCollection var40 = new org.jfree.data.time.TimeSeriesCollection(var39);
//     org.jfree.chart.axis.LogAxis var42 = new org.jfree.chart.axis.LogAxis("");
//     var42.setAutoTickUnitSelection(true);
//     var42.resizeRange(0.05d, (-1.0d));
//     boolean var48 = var42.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var49 = null;
//     org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var40, (org.jfree.chart.axis.ValueAxis)var42, var49);
//     var50.addCornerTextItem("");
//     org.jfree.chart.ChartRenderingInfo var54 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var55 = var54.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var56 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
//     org.jfree.chart.renderer.xy.XYItemRendererState var57 = new org.jfree.chart.renderer.xy.XYItemRendererState(var56);
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleAnchor var59 = null;
//     java.awt.geom.Point2D var60 = org.jfree.chart.util.RectangleAnchor.coordinates(var58, var59);
//     var50.zoomRangeAxes(0.14d, var56, var60);
//     org.jfree.data.time.TimeSeries var62 = null;
//     org.jfree.data.time.TimeSeriesCollection var63 = new org.jfree.data.time.TimeSeriesCollection(var62);
//     org.jfree.chart.axis.LogAxis var65 = new org.jfree.chart.axis.LogAxis("");
//     var65.setAutoTickUnitSelection(true);
//     var65.resizeRange(0.05d, (-1.0d));
//     boolean var71 = var65.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var72 = null;
//     org.jfree.chart.plot.PolarPlot var73 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var63, (org.jfree.chart.axis.ValueAxis)var65, var72);
//     var73.addCornerTextItem("");
//     org.jfree.chart.ChartRenderingInfo var77 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var78 = var77.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var79 = new org.jfree.chart.plot.PlotRenderingInfo(var77);
//     org.jfree.chart.renderer.xy.XYItemRendererState var80 = new org.jfree.chart.renderer.xy.XYItemRendererState(var79);
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.chart.util.RectangleAnchor var82 = null;
//     java.awt.geom.Point2D var83 = org.jfree.chart.util.RectangleAnchor.coordinates(var81, var82);
//     var73.zoomRangeAxes(0.14d, var79, var83);
//     var11.zoomRangeAxes(2.0d, var56, var83);
//     
//     // Checks the contract:  equals-hashcode on var1 and var40
//     assertTrue("Contract failed: equals-hashcode on var1 and var40", var1.equals(var40) ? var1.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var63
//     assertTrue("Contract failed: equals-hashcode on var1 and var63", var1.equals(var63) ? var1.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var1
//     assertTrue("Contract failed: equals-hashcode on var40 and var1", var40.equals(var1) ? var40.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var63
//     assertTrue("Contract failed: equals-hashcode on var40 and var63", var40.equals(var63) ? var40.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var1
//     assertTrue("Contract failed: equals-hashcode on var63 and var1", var63.equals(var1) ? var63.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var40
//     assertTrue("Contract failed: equals-hashcode on var63 and var40", var63.equals(var40) ? var63.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var73
//     assertTrue("Contract failed: equals-hashcode on var50 and var73", var50.equals(var73) ? var50.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var50
//     assertTrue("Contract failed: equals-hashcode on var73 and var50", var73.equals(var50) ? var73.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var77
//     assertTrue("Contract failed: equals-hashcode on var54 and var77", var54.equals(var77) ? var54.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var54
//     assertTrue("Contract failed: equals-hashcode on var77 and var54", var77.equals(var54) ? var77.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var79
//     assertTrue("Contract failed: equals-hashcode on var56 and var79", var56.equals(var79) ? var56.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var56
//     assertTrue("Contract failed: equals-hashcode on var79 and var56", var79.equals(var56) ? var79.hashCode() == var56.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(10);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var7 = var6.getBaseItemLabelPaint();
    java.awt.Paint var9 = var6.getSeriesPaint(10);
    java.awt.Shape var11 = null;
    var6.setSeriesShape(0, var11, false);
    var6.setBase((-1.0d));
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var17 = var16.getChartArea();
    var6.setBaseShape((java.awt.Shape)var17);
    org.jfree.data.general.PieDataset var19 = null;
    java.lang.Comparable var22 = null;
    org.jfree.chart.entity.PieSectionEntity var25 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var17, var19, 100, 2147483647, var22, "", "Polar Plot");
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var29 = var28.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("", var29);
    java.lang.String var31 = var30.getToolTipText();
    var30.setToolTipText("");
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var35, (org.jfree.chart.plot.Plot)var37);
    boolean var39 = var30.equals((java.lang.Object)var35);
    org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var42 = var41.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var35, (org.jfree.chart.axis.Axis)var41, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var47 = var46.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot();
    double var49 = var48.getLimit();
    double var50 = var48.getLimit();
    org.jfree.chart.JFreeChart var51 = var48.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var46, var51, (-1), 1);
    boolean var55 = var45.equals((java.lang.Object)var51);
    org.jfree.chart.entity.JFreeChartEntity var57 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var17, var51, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    var4.setLine((java.awt.Shape)var17);
    java.lang.String var59 = var4.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + ""+ "'", var59.equals(""));

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.XYPlot var3 = null;
//     org.jfree.data.time.TimeSeries var4 = null;
//     org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var4);
//     int var7 = var5.indexOf((java.lang.Comparable)86400000L);
//     org.jfree.chart.axis.LogAxis var9 = new org.jfree.chart.axis.LogAxis("");
//     var9.setAutoTickUnitSelection(true);
//     var9.resizeRange(0.05d, (-1.0d));
//     var9.configure();
//     org.jfree.chart.renderer.PolarItemRenderer var16 = null;
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var5, (org.jfree.chart.axis.ValueAxis)var9, var16);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var19 = var18.getLegendItems();
//     org.jfree.chart.util.SortOrder var20 = var18.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var21 = var18.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var27 = var26.getBaseItemLabelPaint();
//     var25.setBaseFillPaint(var27);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var27);
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var27);
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var33 = var18.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var30, var31, false);
//     org.jfree.chart.util.LengthAdjustmentType var34 = var30.getLabelOffsetType();
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var36 = var35.getBaseItemLabelPaint();
//     java.awt.Paint var38 = var35.getSeriesPaint(10);
//     java.awt.Shape var40 = null;
//     var35.setSeriesShape(0, var40, false);
//     var35.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var45 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var46 = var45.getChartArea();
//     var35.setBaseShape((java.awt.Shape)var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     java.lang.Comparable var51 = null;
//     org.jfree.chart.entity.PieSectionEntity var54 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var46, var48, 100, 2147483647, var51, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var58 = var57.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("", var58);
//     java.lang.String var60 = var59.getToolTipText();
//     var59.setToolTipText("");
//     java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var65 = null;
//     org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot(var65);
//     org.jfree.chart.entity.PlotEntity var67 = new org.jfree.chart.entity.PlotEntity(var64, (org.jfree.chart.plot.Plot)var66);
//     boolean var68 = var59.equals((java.lang.Object)var64);
//     org.jfree.chart.axis.LogAxis var70 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var71 = var70.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var74 = new org.jfree.chart.entity.AxisEntity(var64, (org.jfree.chart.axis.Axis)var70, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var75 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var76 = var75.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var77 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var78 = var77.getLimit();
//     double var79 = var77.getLimit();
//     org.jfree.chart.JFreeChart var80 = var77.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var83 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var75, var80, (-1), 1);
//     boolean var84 = var74.equals((java.lang.Object)var80);
//     org.jfree.chart.entity.JFreeChartEntity var86 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var46, var80, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     var1.drawRangeMarker(var2, var3, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.plot.Marker)var30, var46);
//     
//     // Checks the contract:  equals-hashcode on var29 and var75
//     assertTrue("Contract failed: equals-hashcode on var29 and var75", var29.equals(var75) ? var29.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var29
//     assertTrue("Contract failed: equals-hashcode on var75 and var29", var75.equals(var29) ? var75.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var3 = null;
    int var4 = var0.indexOf(var3);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var9 = var5.isItemLabelVisible(0, (-1), true);
    var5.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var17 = var5.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var18 = null;
    java.util.TimeZone var19 = null;
    org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18, var19);
    org.jfree.data.Range var22 = var20.getDomainBounds(true);
    org.jfree.data.Range var23 = var5.findDomainBounds((org.jfree.data.xy.XYDataset)var20);
    java.awt.Paint var24 = var5.getBaseItemLabelPaint();
    var0.setDomainCrosshairPaint(var24);
    org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var28 = var27.getLabelInsets();
    boolean var29 = var27.isPositiveArrowVisible();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var27);
    org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var32.setSeriesToolTipGenerator(0, var34, true);
    boolean var37 = var32.isDrawBarOutline();
    org.jfree.chart.plot.WaferMapPlot var38 = new org.jfree.chart.plot.WaferMapPlot();
    float var39 = var38.getForegroundAlpha();
    var32.addChangeListener((org.jfree.chart.event.RendererChangeListener)var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0f);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    java.util.TimeZone var0 = null;
    java.util.Locale var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.RendererChangeEvent var2 = new org.jfree.chart.event.RendererChangeEvent(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, (-1), var2);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     org.jfree.chart.renderer.xy.XYBarPainter var5 = var0.getBarPainter();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var0.getPositiveItemLabelPosition(2147483647, 0, true);
//     boolean var10 = var0.getUseYInterval();
//     boolean var14 = var0.getItemCreateEntity(0, 2147483647, false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var15.getURLGenerator(100, (-1), false);
//     org.jfree.chart.renderer.xy.XYBarPainter var20 = var15.getBarPainter();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var15.getPositiveItemLabelPosition(2147483647, 0, true);
//     boolean var25 = var15.getUseYInterval();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
//     var26.setSeriesToolTipGenerator(0, var28, true);
//     boolean var31 = var26.isDrawBarOutline();
//     org.jfree.chart.plot.WaferMapPlot var32 = new org.jfree.chart.plot.WaferMapPlot();
//     float var33 = var32.getForegroundAlpha();
//     var26.addChangeListener((org.jfree.chart.event.RendererChangeListener)var32);
//     org.jfree.chart.labels.ItemLabelPosition var38 = var26.getNegativeItemLabelPosition(0, 1, true);
//     var15.setPositiveItemLabelPositionFallback(var38);
//     var0.setBaseNegativeItemLabelPosition(var38);
//     
//     // Checks the contract:  equals-hashcode on var9 and var24
//     assertTrue("Contract failed: equals-hashcode on var9 and var24", var9.equals(var24) ? var9.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var9
//     assertTrue("Contract failed: equals-hashcode on var24 and var9", var24.equals(var9) ? var24.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var7 = var6.getBaseItemLabelPaint();
//     var5.setBaseFillPaint(var7);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(var7);
//     org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var7);
//     var0.setRangeGridlinePaint(var7);
//     org.jfree.chart.util.SortOrder var12 = var0.getColumnRenderingOrder();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var0.getRendererForDataset(var13);
//     java.awt.Stroke var15 = var0.getRangeCrosshairStroke();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = var0.getRendererForDataset(var16);
//     var0.mapDatasetToDomainAxis(10, 10);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var23 = var22.getLabelAngle();
//     java.lang.String var24 = var22.getLabelURL();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var26 = var25.getLegendItems();
//     org.jfree.chart.util.SortOrder var27 = var25.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var32 = var31.getBaseItemLabelPaint();
//     var30.setBaseFillPaint(var32);
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(var32);
//     org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var32);
//     var25.setRangeGridlinePaint(var32);
//     var25.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var40 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var41 = var40.getLabelInsets();
//     java.lang.Object var42 = null;
//     boolean var43 = var41.equals(var42);
//     var25.setAxisOffset(var41);
//     var22.setLabelInsets(var41, true);
//     org.jfree.chart.plot.MultiplePiePlot var47 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var48 = var47.getLimit();
//     double var49 = var47.getLimit();
//     org.jfree.chart.JFreeChart var50 = var47.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var53 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var22, var50, 0, 0);
//     double var54 = var22.getCategoryMargin();
//     java.awt.Stroke var55 = var22.getTickMarkStroke();
//     var0.setRangeMinorGridlineStroke(var55);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var34
//     assertTrue("Contract failed: equals-hashcode on var9 and var34", var9.equals(var34) ? var9.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var9
//     assertTrue("Contract failed: equals-hashcode on var34 and var9", var34.equals(var9) ? var34.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var35
//     assertTrue("Contract failed: equals-hashcode on var10 and var35", var10.equals(var35) ? var10.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var10
//     assertTrue("Contract failed: equals-hashcode on var35 and var10", var35.equals(var10) ? var35.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var2, (org.jfree.data.Range)var3);
    boolean var5 = var0.equals((java.lang.Object)var2);
    var0.removeSeries((java.lang.Comparable)' ');
    var0.removeSeries((java.lang.Comparable)1418759999999L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var11 = var0.getSeriesKey(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    var0.setShapesFilled(false);
    var0.setBaseCreateEntities(false);
    var0.setBaseSeriesVisibleInLegend(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var2 = var1.getLabelAngle();
//     java.lang.String var3 = var1.getLabelURL();
//     org.jfree.data.xy.XYDataItem var6 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
//     int var8 = var6.compareTo((java.lang.Object)100.0f);
//     var6.setSelected(false);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var16 = var15.getLowerMargin();
//     var15.setLabel("");
//     org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
//     var21.setSeriesToolTipGenerator(0, var23, true);
//     boolean var26 = var21.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var21.getPositiveItemLabelPositionFallback();
//     var21.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var31 = var30.getBaseItemLabelPaint();
//     java.awt.Paint var33 = var30.getSeriesPaint(10);
//     java.awt.Shape var35 = null;
//     var30.setSeriesShape(0, var35, false);
//     var30.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var40 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var41 = var40.getChartArea();
//     var30.setBaseShape((java.awt.Shape)var41);
//     boolean var43 = var21.equals((java.lang.Object)var41);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getLegendItems();
//     var44.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     int var48 = var44.indexOf(var47);
//     org.jfree.chart.util.RectangleEdge var49 = var44.getDomainAxisEdge();
//     org.jfree.data.xy.XYDataItem var52 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
//     int var54 = var52.compareTo((java.lang.Object)100.0f);
//     boolean var55 = var49.equals((java.lang.Object)var52);
//     double var56 = var15.getCategoryMiddle(100, 255, var41, var49);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var58 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var59 = var58.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(var59);
//     var57.setNoDataMessagePaint(var59);
//     var57.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var65 = var57.getDomainAxisEdge(255);
//     double var66 = var1.getCategorySeriesMiddle((java.lang.Comparable)var6, (java.lang.Comparable)(short)(-1), var12, 0.08d, var41, var65);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    java.lang.String var4 = var1.getDescription();
    java.awt.Stroke var5 = var1.getLineStroke();
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFillPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.util.LogFormat var2 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
    var8.setBaseNegativeItemLabelPosition(var16);
    boolean var18 = var7.equals((java.lang.Object)var8);
    java.text.NumberFormat var19 = var7.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var2, var19);
    org.jfree.chart.labels.StandardXYToolTipGenerator var21 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var22 = var21.getXFormat();
    java.math.RoundingMode var23 = var22.getRoundingMode();
    org.jfree.chart.labels.StandardPieToolTipGenerator var24 = new org.jfree.chart.labels.StandardPieToolTipGenerator("2014", var19, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var26 = var22.parseObject("org.jfree.data.UnknownKeyException: [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     var0.setPositiveItemLabelPositionFallback(var9);
//     boolean var17 = var0.getIncludeBaseInRange();
//     org.jfree.chart.util.GradientPaintTransformer var18 = var0.getGradientPaintTransformer();
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var20 = null;
//     java.util.TimeZone var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var20, var21);
//     org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, (org.jfree.data.general.Dataset)var22, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var28 = var27.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("", var28);
//     java.lang.String var30 = var29.getToolTipText();
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var35 = var31.getURLGenerator(100, (-1), false);
//     java.awt.Paint var37 = var31.getSeriesFillPaint(100);
//     java.awt.Stroke var39 = var31.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var41 = var40.getBaseItemLabelPaint();
//     java.awt.Paint var43 = var40.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var45 = var44.getBaseNegativeItemLabelPosition();
//     var40.setPositiveItemLabelPositionFallback(var45);
//     var31.setPositiveItemLabelPositionFallback(var45);
//     var24.add((org.jfree.chart.block.Block)var29, (java.lang.Object)var45);
//     var0.setBaseNegativeItemLabelPosition(var45, true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var45
//     assertTrue("Contract failed: equals-hashcode on var9 and var45", var9.equals(var45) ? var9.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var9
//     assertTrue("Contract failed: equals-hashcode on var45 and var9", var45.equals(var9) ? var45.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(255, 255, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var6 = var2.isItemLabelVisible(0, (-1), true);
//     boolean var7 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var9 = var8.getBaseStroke();
//     var2.setBaseStroke(var9, false);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var15 = var14.getLegendItems();
//     var14.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     int var18 = var14.indexOf(var17);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var23 = var19.isItemLabelVisible(0, (-1), true);
//     var19.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var31 = var19.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var32 = null;
//     java.util.TimeZone var33 = null;
//     org.jfree.data.time.TimeSeriesCollection var34 = new org.jfree.data.time.TimeSeriesCollection(var32, var33);
//     org.jfree.data.Range var36 = var34.getDomainBounds(true);
//     org.jfree.data.Range var37 = var19.findDomainBounds((org.jfree.data.xy.XYDataset)var34);
//     java.awt.Paint var38 = var19.getBaseItemLabelPaint();
//     var14.setDomainCrosshairPaint(var38);
//     org.jfree.chart.axis.LogAxis var41 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var42 = var41.getLabelInsets();
//     boolean var43 = var41.isPositiveArrowVisible();
//     var14.setRangeAxis((org.jfree.chart.axis.ValueAxis)var41);
//     var41.setAutoRangeMinimumSize(4.0d);
//     var41.setLabelAngle(0.05d);
//     java.lang.String[] var51 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var52 = new org.jfree.chart.axis.SymbolAxis("hi!", var51);
//     org.jfree.chart.axis.LogAxis var54 = new org.jfree.chart.axis.LogAxis("");
//     var54.setAutoTickUnitSelection(true);
//     boolean var57 = var54.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var59 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var54.setTickUnit(var59, false, true);
//     var52.setTickUnit(var59, false, true);
//     org.jfree.chart.ChartRenderingInfo var67 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var68 = var67.getChartArea();
//     org.jfree.data.general.PieDataset var69 = null;
//     org.jfree.chart.entity.PieSectionEntity var75 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var68, var69, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var77 = var76.getLegendItems();
//     var76.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var79 = null;
//     int var80 = var76.indexOf(var79);
//     org.jfree.chart.util.RectangleEdge var81 = var76.getDomainAxisEdge();
//     boolean var82 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var81);
//     double var83 = var52.valueToJava2D(0.05d, var68, var81);
//     var2.drawDomainGridLine(var12, var13, (org.jfree.chart.axis.ValueAxis)var41, var68, 3.0d);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var19.", var0.equals(var19) == var19.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var19.", var2.equals(var19) == var19.equals(var2));
//     
//     // Checks the contract:  equals-hashcode on var15 and var77
//     assertTrue("Contract failed: equals-hashcode on var15 and var77", var15.equals(var77) ? var15.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var15
//     assertTrue("Contract failed: equals-hashcode on var77 and var15", var77.equals(var15) ? var77.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
//     float var7 = var6.getForegroundAlpha();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, 1, true);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var0.drawOutline(var13, var14, var15);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.xy.IntervalXYDelegate var3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var3.getEndXValue(255, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var2 = var1.getTickLabelFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
//     var5.setSeriesToolTipGenerator(0, var7, true);
//     boolean var10 = var5.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var5.getPositiveItemLabelPositionFallback();
//     var5.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     java.awt.Paint var17 = var14.getSeriesPaint(10);
//     java.awt.Shape var19 = null;
//     var14.setSeriesShape(0, var19, false);
//     var14.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var25 = var24.getChartArea();
//     var14.setBaseShape((java.awt.Shape)var25);
//     boolean var27 = var5.equals((java.lang.Object)var25);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var29 = var28.getLegendItems();
//     var28.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     int var32 = var28.indexOf(var31);
//     org.jfree.chart.util.RectangleEdge var33 = var28.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisState var35 = new org.jfree.chart.axis.AxisState(100.0d);
//     var35.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var39 = var38.getLegendItems();
//     org.jfree.chart.util.SortOrder var40 = var38.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var42 = var41.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var47 = var43.isItemLabelVisible(0, (-1), true);
//     boolean var48 = var42.equals((java.lang.Object)var43);
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var50 = var49.getBaseStroke();
//     var43.setBaseStroke(var50, false);
//     var38.setRangeCrosshairStroke(var50);
//     org.jfree.chart.axis.CategoryAxis3D var55 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var56 = var38.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var55);
//     var35.setTicks(var56);
//     var1.drawTickMarks(var3, (-1.0d), var25, var33, var35);
//     
//     // Checks the contract:  equals-hashcode on var29 and var39
//     assertTrue("Contract failed: equals-hashcode on var29 and var39", var29.equals(var39) ? var29.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var29
//     assertTrue("Contract failed: equals-hashcode on var39 and var29", var39.equals(var29) ? var39.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.chart.util.BooleanList var1 = new org.jfree.chart.util.BooleanList();
//     java.lang.Boolean var3 = var1.getBoolean(10);
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     boolean var6 = var1.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var8 = var7.getBaseItemLabelPaint();
//     java.awt.Paint var10 = var7.getSeriesPaint(10);
//     java.awt.Shape var12 = null;
//     var7.setSeriesShape(0, var12, false);
//     var7.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var18 = var17.getChartArea();
//     var7.setBaseShape((java.awt.Shape)var18);
//     org.jfree.data.general.PieDataset var20 = null;
//     java.lang.Comparable var23 = null;
//     org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var18, var20, 100, 2147483647, var23, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var30 = var29.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("", var30);
//     java.lang.String var32 = var31.getToolTipText();
//     var31.setToolTipText("");
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     org.jfree.chart.entity.PlotEntity var39 = new org.jfree.chart.entity.PlotEntity(var36, (org.jfree.chart.plot.Plot)var38);
//     boolean var40 = var31.equals((java.lang.Object)var36);
//     org.jfree.chart.axis.LogAxis var42 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var43 = var42.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var36, (org.jfree.chart.axis.Axis)var42, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var48 = var47.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var49 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var50 = var49.getLimit();
//     double var51 = var49.getLimit();
//     org.jfree.chart.JFreeChart var52 = var49.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var55 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var47, var52, (-1), 1);
//     boolean var56 = var46.equals((java.lang.Object)var52);
//     org.jfree.chart.entity.JFreeChartEntity var58 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var18, var52, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     var5.setLine((java.awt.Shape)var18);
//     boolean var60 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var18);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 10, 100);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getInteriorGap();
//     double var3 = var1.getMaximumExplodePercent();
//     org.jfree.data.general.DatasetChangeEvent var4 = null;
//     var1.datasetChanged(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
//     var8.setAutoTickUnitSelection(true);
//     boolean var11 = var8.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var13 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var8.setTickUnit(var13, false, true);
//     var8.setTickLabelsVisible(true);
//     java.lang.String[] var21 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var22 = new org.jfree.chart.axis.SymbolAxis("hi!", var21);
//     org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis("");
//     var24.setAutoTickUnitSelection(true);
//     boolean var27 = var24.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var29 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var24.setTickUnit(var29, false, true);
//     var22.setTickUnit(var29, false, true);
//     org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var38 = var37.getChartArea();
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.entity.PieSectionEntity var45 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var38, var39, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var47 = var46.getLegendItems();
//     var46.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var49 = null;
//     int var50 = var46.indexOf(var49);
//     org.jfree.chart.util.RectangleEdge var51 = var46.getDomainAxisEdge();
//     boolean var52 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var51);
//     double var53 = var22.valueToJava2D(0.05d, var38, var51);
//     var8.setLeftArrow((java.awt.Shape)var38);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     var55.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var58 = var55.getFixedRangeAxisSpace();
//     var55.clearDomainMarkers();
//     int var60 = var55.getCrosshairDatasetIndex();
//     var55.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var67 = var64.getFixedRangeAxisSpace();
//     var64.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var69 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var70 = var69.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var71 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var75 = var71.isItemLabelVisible(0, (-1), true);
//     boolean var76 = var70.equals((java.lang.Object)var71);
//     org.jfree.chart.renderer.xy.XYBarRenderer var77 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var78 = var77.getBaseStroke();
//     var71.setBaseStroke(var78, false);
//     var64.setDomainCrosshairStroke(var78);
//     org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var85 = var84.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var86 = var84.getPlotInfo();
//     java.awt.geom.Point2D var87 = null;
//     var64.zoomDomainAxes(3.0d, 3.0d, var86, var87);
//     java.awt.geom.Rectangle2D var89 = null;
//     org.jfree.chart.util.RectangleAnchor var90 = null;
//     java.awt.geom.Point2D var91 = org.jfree.chart.util.RectangleAnchor.coordinates(var89, var90);
//     var55.zoomRangeAxes(4.0d, var86, var91, false);
//     org.jfree.chart.plot.PlotState var94 = null;
//     org.jfree.chart.ChartRenderingInfo var95 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var96 = var95.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var97 = var95.getPlotInfo();
//     var1.draw(var6, var38, var91, var94, var97);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.data.time.TimeSeries var10 = null;
//     org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var10);
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     var13.setAutoTickUnitSelection(true);
//     var13.resizeRange(0.05d, (-1.0d));
//     boolean var19 = var13.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var11, (org.jfree.chart.axis.ValueAxis)var13, var20);
//     java.lang.String var22 = var21.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var25 = var24.getBaseItemLabelPaint();
//     var23.setBaseFillPaint(var25);
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var25);
//     var21.setRadiusGridlinePaint(var25);
//     java.awt.Paint var29 = var21.getRadiusGridlinePaint();
//     var9.setBackgroundPaint(var29);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var31.setShadowXOffset((-1.0d));
//     var31.setDrawBarOutline(false);
//     org.jfree.data.time.TimeSeries var36 = null;
//     org.jfree.data.time.TimeSeriesCollection var37 = new org.jfree.data.time.TimeSeriesCollection(var36);
//     org.jfree.chart.axis.LogAxis var39 = new org.jfree.chart.axis.LogAxis("");
//     var39.setAutoTickUnitSelection(true);
//     var39.resizeRange(0.05d, (-1.0d));
//     boolean var45 = var39.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var46 = null;
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var37, (org.jfree.chart.axis.ValueAxis)var39, var46);
//     java.lang.String var48 = var47.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var53 = var52.getBaseItemLabelPaint();
//     var51.setBaseFillPaint(var53);
//     org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder(var53);
//     org.jfree.chart.plot.IntervalMarker var56 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var53);
//     var47.setAngleLabelPaint(var53);
//     var31.setShadowPaint(var53);
//     var9.setItemPaint(var53);
//     
//     // Checks the contract:  equals-hashcode on var11 and var37
//     assertTrue("Contract failed: equals-hashcode on var11 and var37", var11.equals(var37) ? var11.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var11
//     assertTrue("Contract failed: equals-hashcode on var37 and var11", var37.equals(var11) ? var37.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var55
//     assertTrue("Contract failed: equals-hashcode on var27 and var55", var27.equals(var55) ? var27.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var27
//     assertTrue("Contract failed: equals-hashcode on var55 and var27", var55.equals(var27) ? var55.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var3 = var2.getLimit();
//     double var4 = var2.getLimit();
//     org.jfree.chart.JFreeChart var5 = var2.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
//     java.lang.Object var9 = var5.clone();
//     boolean var10 = var5.isNotify();
//     org.jfree.chart.title.LegendTitle var11 = var5.getLegend();
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var17 = var16.getBaseItemLabelPaint();
//     var15.setBaseFillPaint(var17);
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var17);
//     org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var17);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
//     var21.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     int var25 = var21.indexOf(var24);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var30 = var26.isItemLabelVisible(0, (-1), true);
//     var26.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var38 = var26.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var39 = null;
//     java.util.TimeZone var40 = null;
//     org.jfree.data.time.TimeSeriesCollection var41 = new org.jfree.data.time.TimeSeriesCollection(var39, var40);
//     org.jfree.data.Range var43 = var41.getDomainBounds(true);
//     org.jfree.data.Range var44 = var26.findDomainBounds((org.jfree.data.xy.XYDataset)var41);
//     java.awt.Paint var45 = var26.getBaseItemLabelPaint();
//     var21.setDomainCrosshairPaint(var45);
//     var20.setOutlinePaint(var45);
//     var5.setBackgroundPaint(var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getPositiveItemLabelPositionFallback();
//     var0.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var10 = var9.getBaseItemLabelPaint();
//     java.awt.Paint var12 = var9.getSeriesPaint(10);
//     java.awt.Shape var14 = null;
//     var9.setSeriesShape(0, var14, false);
//     var9.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     var9.setBaseShape((java.awt.Shape)var20);
//     boolean var22 = var0.equals((java.lang.Object)var20);
//     int var23 = var0.getRowCount();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.LogAxis var26 = new org.jfree.chart.axis.LogAxis("");
//     var26.setAutoTickUnitSelection(true);
//     var26.resizeRange(0.05d, (-1.0d));
//     org.jfree.data.xy.DefaultXYDataset var33 = new org.jfree.data.xy.DefaultXYDataset();
//     int var34 = var33.getSeriesCount();
//     org.jfree.data.time.DateRange var35 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var35, (org.jfree.data.Range)var36);
//     boolean var38 = var33.equals((java.lang.Object)var35);
//     org.jfree.data.time.DateRange var39 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var39, (org.jfree.data.Range)var40);
//     org.jfree.chart.block.LengthConstraintType var42 = var41.getWidthConstraintType();
//     org.jfree.data.time.DateRange var44 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var45 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var45, (org.jfree.data.Range)var46);
//     org.jfree.chart.block.LengthConstraintType var48 = var47.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var35, var42, 0.0d, (org.jfree.data.Range)var44, var48);
//     var26.setRangeWithMargins((org.jfree.data.Range)var35, true, false);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var55 = var53.getDataset(10);
//     org.jfree.chart.util.Layer var57 = null;
//     java.util.Collection var58 = var53.getDomainMarkers(10, var57);
//     var26.addChangeListener((org.jfree.chart.event.AxisChangeListener)var53);
//     var53.clearDomainAxes();
//     org.jfree.chart.util.RectangleEdge var61 = var53.getDomainAxisEdge();
//     org.jfree.chart.renderer.xy.XYBarRenderer var62 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var63 = var62.getBaseItemLabelPaint();
//     java.awt.Paint var65 = var62.getSeriesPaint(10);
//     java.awt.Shape var67 = null;
//     var62.setSeriesShape(0, var67, false);
//     var62.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var72 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var73 = var72.getChartArea();
//     var62.setBaseShape((java.awt.Shape)var73);
//     var0.drawOutline(var24, var53, var73);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.data.Range var5 = var3.getDomainBounds(true);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var3);
    java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(false);
    boolean var9 = var3.equals((java.lang.Object)var8);
    org.jfree.data.general.SeriesChangeEvent var10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
    var0.seriesChanged(var10);
    java.lang.Number var12 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset)var0, 255, 0.0d, Double.NEGATIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var5 = var1.getURLGenerator(100, (-1), false);
    java.awt.Paint var7 = var1.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var8 = null;
    var1.setLegendItemToolTipGenerator(var8);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var14 = var13.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("", var14);
    var1.setSeriesItemLabelFont(1, var14, false);
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("hi!", var14);
    var18.setURLText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var2 = var1.getXFormat();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var2, 0);
    org.jfree.chart.labels.StandardXYToolTipGenerator var5 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.text.NumberFormat var6 = var5.getXFormat();
    java.math.RoundingMode var7 = var6.getRoundingMode();
    var2.setRoundingMode(var7);
    var2.setMinimumFractionDigits(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    java.lang.String var3 = var1.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var11 = var10.getBaseItemLabelPaint();
    var9.setBaseFillPaint(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
    var4.setRangeGridlinePaint(var11);
    var4.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
    java.lang.Object var21 = null;
    boolean var22 = var20.equals(var21);
    var4.setAxisOffset(var20);
    var1.setLabelInsets(var20, true);
    org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
    double var27 = var26.getLimit();
    double var28 = var26.getLimit();
    org.jfree.chart.JFreeChart var29 = var26.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var29, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var33 = var29.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     boolean var5 = var0.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     var0.setPositiveItemLabelPositionFallback(var9);
//     var0.setMinimumBarLength(0.14d);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var22 = var21.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(var22);
//     var20.setNoDataMessagePaint(var22);
//     var20.setAnchorValue(0.025d, false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var29 = var28.getBaseItemLabelPaint();
//     java.awt.Paint var31 = var28.getSeriesPaint(10);
//     java.awt.Shape var33 = null;
//     var28.setSeriesShape(0, var33, false);
//     var28.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var39 = var38.getChartArea();
//     var28.setBaseShape((java.awt.Shape)var39);
//     var0.drawBackground(var19, var20, var39);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
    org.jfree.chart.util.SortOrder var11 = var9.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var12.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var18 = var14.isItemLabelVisible(0, (-1), true);
    boolean var19 = var13.equals((java.lang.Object)var14);
    org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var21 = var20.getBaseStroke();
    var14.setBaseStroke(var21, false);
    var9.setRangeCrosshairStroke(var21);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
    org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D();
    var26.setShadowXOffset((-1.0d));
    var26.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var32 = var26.getSeriesNegativeItemLabelPosition(0);
    var0.setBasePositiveItemLabelPosition(var32, false);
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var37 = var36.getTickLabelFont();
    double var38 = var36.getFixedDimension();
    org.jfree.chart.axis.CategoryLabelPositions var39 = var36.getCategoryLabelPositions();
    boolean var40 = var32.equals((java.lang.Object)var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    boolean var8 = var5.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var5.setTickUnit(var10, false, true);
    var3.setTickUnit(var10, false, true);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var19, var20, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var28 = var27.getLegendItems();
    var27.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var30 = null;
    int var31 = var27.indexOf(var30);
    org.jfree.chart.util.RectangleEdge var32 = var27.getDomainAxisEdge();
    boolean var33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var32);
    double var34 = var3.valueToJava2D(0.05d, var19, var32);
    var3.setVerticalTickLabels(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    java.awt.Color var1 = java.awt.Color.getColor(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getStart();
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var5 = var4.getBaseItemLabelPaint();
//     java.awt.Paint var7 = var4.getSeriesPaint(10);
//     java.awt.Shape var9 = null;
//     var4.setSeriesShape(0, var9, false);
//     var4.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     var4.setBaseShape((java.awt.Shape)var15);
//     java.lang.String[] var19 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var20 = new org.jfree.chart.axis.SymbolAxis("hi!", var19);
//     org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
//     var22.setAutoTickUnitSelection(true);
//     boolean var25 = var22.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var27 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var22.setTickUnit(var27, false, true);
//     var20.setTickUnit(var27, false, true);
//     org.jfree.chart.ChartRenderingInfo var35 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var36 = var35.getChartArea();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.entity.PieSectionEntity var43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var36, var37, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var45 = var44.getLegendItems();
//     var44.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     int var48 = var44.indexOf(var47);
//     org.jfree.chart.util.RectangleEdge var49 = var44.getDomainAxisEdge();
//     boolean var50 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var49);
//     double var51 = var20.valueToJava2D(0.05d, var36, var49);
//     org.jfree.chart.util.RectangleEdge var52 = org.jfree.chart.util.RectangleEdge.opposite(var49);
//     double var53 = var0.dateToJava2D(var3, var15, var49);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    double var4 = var2.calculateLeftInset(0.025d);
    double var5 = var2.getRight();
    double var7 = var2.calculateBottomOutset(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var20 = var19.getBaseStroke();
    var13.setBaseStroke(var20, false);
    var7.setBaseStroke(var20);
    var6.setAxisLineStroke(var20);
    var3.setLabelOutlineStroke(var20);
    org.jfree.data.general.PieDataset var26 = null;
    var3.setDataset(var26);
    org.jfree.chart.plot.AbstractPieLabelDistributor var28 = var3.getLabelDistributor();
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var30 = var29.getLegendItems();
    org.jfree.chart.util.SortOrder var31 = var29.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var36 = var35.getBaseItemLabelPaint();
    var34.setBaseFillPaint(var36);
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var36);
    org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var36);
    var29.setRangeGridlinePaint(var36);
    var3.setBaseSectionOutlinePaint(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.data.category.CategoryDataset var5 = var0.getDataset();
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.AxisState var3 = new org.jfree.chart.axis.AxisState(100.0d);
//     var3.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
//     org.jfree.chart.util.SortOrder var8 = var6.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var9.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var15 = var11.isItemLabelVisible(0, (-1), true);
//     boolean var16 = var10.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var18 = var17.getBaseStroke();
//     var11.setBaseStroke(var18, false);
//     var6.setRangeCrosshairStroke(var18);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var24 = var6.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var23);
//     var3.setTicks(var24);
//     org.jfree.chart.axis.SegmentedTimeline var26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var27 = var26.getSegmentsIncludedSize();
//     long var28 = var26.getSegmentSize();
//     java.util.List var29 = var26.getExceptionSegments();
//     var3.setTicks(var29);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var33 = var32.getLegendItems();
//     var32.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     int var36 = var32.indexOf(var35);
//     org.jfree.chart.util.RectangleEdge var37 = var32.getDomainAxisEdge();
//     boolean var38 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var37);
//     boolean var39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var37);
//     java.util.List var40 = var0.refreshTicks(var1, var3, var31, var37);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var8 = var4.isItemLabelVisible(0, (-1), true);
//     var4.setShapesFilled(true);
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
//     var12.setSeriesToolTipGenerator(0, var14, true);
//     org.jfree.chart.urls.CategoryURLGenerator var20 = var12.getURLGenerator((-1), 0, true);
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.LegendItemSource var22 = null;
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var22);
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var26 = var25.getTickLabelFont();
//     var21.add((org.jfree.chart.block.Block)var23, (java.lang.Object)var25);
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 1.0d, 0.05d);
//     org.jfree.chart.axis.SegmentedTimeline var33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var34 = var33.clone();
//     org.jfree.chart.axis.AxisState var36 = new org.jfree.chart.axis.AxisState(100.0d);
//     var36.cursorLeft((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var40 = var39.getLegendItems();
//     org.jfree.chart.util.SortOrder var41 = var39.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var43 = var42.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var48 = var44.isItemLabelVisible(0, (-1), true);
//     boolean var49 = var43.equals((java.lang.Object)var44);
//     org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var51 = var50.getBaseStroke();
//     var44.setBaseStroke(var51, false);
//     var39.setRangeCrosshairStroke(var51);
//     org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var57 = var39.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var56);
//     var36.setTicks(var57);
//     var33.addExceptions(var57);
//     boolean var60 = var32.equals((java.lang.Object)var57);
//     org.jfree.chart.title.LegendTitle var61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var32);
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot(var62);
//     double var64 = var63.getInteriorGap();
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     var63.handleClick(10, 0, var67);
//     java.awt.Paint var69 = var63.getShadowPaint();
//     org.jfree.chart.urls.PieURLGenerator var70 = var63.getURLGenerator();
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var63.setLegendItemShape(var72);
//     var12.setBaseLegendShape(var72);
//     var4.setLegendShape(0, var72);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     var76.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var79 = var76.getFixedRangeAxisSpace();
//     var76.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var81 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var82 = var81.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var83 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var87 = var83.isItemLabelVisible(0, (-1), true);
//     boolean var88 = var82.equals((java.lang.Object)var83);
//     org.jfree.chart.renderer.xy.XYBarRenderer var89 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var90 = var89.getBaseStroke();
//     var83.setBaseStroke(var90, false);
//     var76.setDomainCrosshairStroke(var90);
//     java.awt.Paint var94 = null;
//     org.jfree.chart.LegendItem var95 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "HorizontalAlignment.CENTER", "", var72, var90, var94);
//     
//     // Checks the contract:  equals-hashcode on var43 and var82
//     assertTrue("Contract failed: equals-hashcode on var43 and var82", var43.equals(var82) ? var43.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var43
//     assertTrue("Contract failed: equals-hashcode on var82 and var43", var82.equals(var43) ? var82.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     var0.setShadowXOffset((-1.0d));
//     var0.setDrawBarOutline(false);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
//     var8.setAutoTickUnitSelection(true);
//     var8.resizeRange(0.05d, (-1.0d));
//     boolean var14 = var8.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var15 = null;
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var6, (org.jfree.chart.axis.ValueAxis)var8, var15);
//     java.lang.String var17 = var16.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var22 = var21.getBaseItemLabelPaint();
//     var20.setBaseFillPaint(var22);
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder(var22);
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var22);
//     var16.setAngleLabelPaint(var22);
//     var0.setShadowPaint(var22);
//     int var28 = var0.getColumnCount();
//     org.jfree.chart.labels.CategoryToolTipGenerator var29 = var0.getBaseToolTipGenerator();
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var32 = var31.getLegendItems();
//     var31.clearDomainAxes();
//     org.jfree.chart.axis.LogAxis var36 = new org.jfree.chart.axis.LogAxis("");
//     var36.setAutoTickUnitSelection(true);
//     var36.resizeRange(0.05d, (-1.0d));
//     var36.setVerticalTickLabels(false);
//     var31.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var36, true);
//     org.jfree.chart.axis.AxisSpace var46 = var31.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.LogAxis var48 = new org.jfree.chart.axis.LogAxis("");
//     var48.setAutoTickUnitSelection(true);
//     var48.resizeRange(0.05d, (-1.0d));
//     org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var55 = var54.getBaseItemLabelPaint();
//     var48.setTickLabelPaint(var55);
//     org.jfree.chart.plot.Marker var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     var0.drawRangeMarker(var30, var31, (org.jfree.chart.axis.ValueAxis)var48, var57, var58);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var7.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var13 = var9.isItemLabelVisible(0, (-1), true);
    boolean var14 = var8.equals((java.lang.Object)var9);
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var16 = var15.getBaseStroke();
    var9.setBaseStroke(var16, false);
    var4.setRangeCrosshairStroke(var16);
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var22 = var4.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var21);
    var1.setTicks(var22);
    org.jfree.data.time.TimeSeries var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
    org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
    var27.setAutoTickUnitSelection(true);
    var27.resizeRange(0.05d, (-1.0d));
    boolean var33 = var27.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var25, (org.jfree.chart.axis.ValueAxis)var27, var34);
    org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var25, true);
    var25.removeAllSeries();
    java.util.List var39 = var25.getSeries();
    var1.setTicks(var39);
    var1.setCursor(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var3.getBaseNegativeItemLabelPosition();
//     var3.setShapesFilled(false);
//     var3.setBaseCreateEntities(false);
//     var3.setPlotArea(true);
//     int var11 = var0.compareTo((java.lang.Object)var3);
//     java.util.Calendar var12 = null;
//     long var13 = var0.getLastMillisecond(var12);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    var5.resizeRange(0.05d, (-1.0d));
    var5.setVerticalTickLabels(false);
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5, true);
    var5.setTickLabelsVisible(false);
    org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var18 = var17.clone();
    boolean var19 = var5.equals((java.lang.Object)var17);
    double var21 = var5.calculateValue(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == Double.POSITIVE_INFINITY);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    java.awt.Paint var4 = var3.getLabelPaint();
    var1.setLabelPaint(var4);
    java.lang.String var6 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var9 = var8.getBaseItemLabelPaint();
//     var7.setBaseFillPaint(var9);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var17 = var13.isItemLabelVisible(0, (-1), true);
//     boolean var18 = var12.equals((java.lang.Object)var13);
//     org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var20 = var19.getBaseStroke();
//     var13.setBaseStroke(var20, false);
//     var7.setBaseStroke(var20);
//     var6.setAxisLineStroke(var20);
//     var3.setLabelOutlineStroke(var20);
//     java.awt.Paint var26 = var3.getLabelOutlinePaint();
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var28 = var27.getBaseItemLabelPaint();
//     java.awt.Paint var30 = var27.getSeriesPaint(10);
//     java.awt.Shape var32 = null;
//     var27.setSeriesShape(0, var32, false);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var36 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     var35.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var36, true);
//     java.awt.Stroke var42 = var35.getItemStroke(0, 100, false);
//     var27.setBaseStroke(var42, false);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var46 = var45.getLegendItems();
//     org.jfree.chart.util.SortOrder var47 = var45.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var51 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var52 = var51.getBaseItemLabelPaint();
//     var50.setBaseFillPaint(var52);
//     org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var52);
//     org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var52);
//     var45.setRangeGridlinePaint(var52);
//     var45.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var60 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var61 = var60.getLabelInsets();
//     java.lang.Object var62 = null;
//     boolean var63 = var61.equals(var62);
//     var45.setAxisOffset(var61);
//     org.jfree.chart.block.LineBorder var65 = new org.jfree.chart.block.LineBorder(var26, var42, var61);
//     java.awt.Graphics2D var66 = null;
//     java.awt.geom.Rectangle2D var67 = null;
//     var65.draw(var66, var67);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var1 = var0.getBaseItemLabelPaint();
//     java.awt.Paint var3 = var0.getSeriesPaint(10);
//     java.awt.Shape var5 = null;
//     var0.setSeriesShape(0, var5, false);
//     var0.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var11 = var10.getChartArea();
//     var0.setBaseShape((java.awt.Shape)var11);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var14 = var13.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var16 = var15.getLimit();
//     double var17 = var15.getLimit();
//     org.jfree.chart.JFreeChart var18 = var15.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var13, var18, (-1), 1);
//     java.lang.Object var22 = var18.clone();
//     org.jfree.chart.entity.JFreeChartEntity var23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var11, var18);
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var25 = var24.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var27 = var26.getLimit();
//     double var28 = var26.getLimit();
//     org.jfree.chart.JFreeChart var29 = var26.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var24, var29, (-1), 1);
//     org.jfree.data.time.TimeSeries var33 = null;
//     java.util.TimeZone var34 = null;
//     org.jfree.data.time.TimeSeriesCollection var35 = new org.jfree.data.time.TimeSeriesCollection(var33, var34);
//     org.jfree.data.Range var37 = var35.getDomainBounds(true);
//     org.jfree.data.Range var38 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var35);
//     java.lang.String[] var40 = org.jfree.data.time.SerialDate.getMonths(false);
//     boolean var41 = var35.equals((java.lang.Object)var40);
//     boolean var42 = var24.equals((java.lang.Object)var40);
//     boolean var43 = var23.equals((java.lang.Object)var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var24
//     assertTrue("Contract failed: equals-hashcode on var13 and var24", var13.equals(var24) ? var13.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var13
//     assertTrue("Contract failed: equals-hashcode on var24 and var13", var24.equals(var13) ? var24.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var26
//     assertTrue("Contract failed: equals-hashcode on var15 and var26", var15.equals(var26) ? var15.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var15
//     assertTrue("Contract failed: equals-hashcode on var26 and var15", var26.equals(var15) ? var26.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var29
//     assertTrue("Contract failed: equals-hashcode on var18 and var29", var18.equals(var29) ? var18.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var18
//     assertTrue("Contract failed: equals-hashcode on var29 and var18", var29.equals(var18) ? var29.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    double var8 = var7.getLimit();
    double var9 = var7.getLimit();
    org.jfree.chart.JFreeChart var10 = var7.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var10, (-1), 1);
    var4.setFrame((org.jfree.chart.block.BlockFrame)var5);
    java.awt.Paint var15 = var5.getPaint();
    org.jfree.chart.util.RectangleInsets var16 = var5.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    org.jfree.chart.renderer.xy.XYBarPainter var5 = var0.getBarPainter();
    org.jfree.chart.labels.ItemLabelPosition var9 = var0.getPositiveItemLabelPosition(2147483647, 0, true);
    boolean var10 = var0.getUseYInterval();
    boolean var14 = var0.getItemCreateEntity(0, 2147483647, false);
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlinePaint(var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var12 = var0.getItemPaint(0, 100, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var14 = var13.getBaseItemLabelPaint();
    java.awt.Paint var16 = var13.getSeriesPaint(10);
    boolean var17 = var13.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("");
    int var20 = var19.getMaximumLinesToDisplay();
    java.awt.Paint var21 = var19.getPaint();
    var13.setBaseItemLabelPaint(var21);
    var0.setBaseOutlinePaint(var21, false);
    var0.setRangeBase(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     var0.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     int var4 = var0.indexOf(var3);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var9 = var5.isItemLabelVisible(0, (-1), true);
//     var5.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
//     java.awt.Paint var17 = var5.getItemPaint(0, 100, true);
//     org.jfree.data.time.TimeSeries var18 = null;
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.TimeSeriesCollection var20 = new org.jfree.data.time.TimeSeriesCollection(var18, var19);
//     org.jfree.data.Range var22 = var20.getDomainBounds(true);
//     org.jfree.data.Range var23 = var5.findDomainBounds((org.jfree.data.xy.XYDataset)var20);
//     java.awt.Paint var24 = var5.getBaseItemLabelPaint();
//     var0.setDomainCrosshairPaint(var24);
//     org.jfree.chart.axis.LogAxis var27 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var28 = var27.getLabelInsets();
//     boolean var29 = var27.isPositiveArrowVisible();
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var27);
//     var27.setAutoRangeMinimumSize(4.0d);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var35 = var34.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var36 = new org.jfree.chart.block.BlockBorder(var35);
//     var33.setNoDataMessagePaint(var35);
//     var33.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var41 = var33.getDomainAxisEdge(255);
//     var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var33);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.plot.XYPlot var44 = null;
//     var43.setPlot(var44);
//     java.awt.Paint var46 = var43.getBaseOutlinePaint();
//     var27.setTickMarkPaint(var46);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var43 and var5.", var43.equals(var5) == var5.equals(var43));
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1, 0.0f, 1.0f, var4, 100.0d, var6);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.PaintScale var0 = null;
//     java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var4 = new org.jfree.chart.axis.SymbolAxis("hi!", var3);
//     java.awt.Paint var5 = var4.getGridBandPaint();
//     org.jfree.chart.title.PaintScaleLegend var6 = new org.jfree.chart.title.PaintScaleLegend(var0, (org.jfree.chart.axis.ValueAxis)var4);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     var3.setAutoTickUnitSelection(true);
//     int var6 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     org.jfree.data.Range var7 = var3.getRange();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
//     org.jfree.chart.util.SortOrder var11 = var9.getColumnRenderingOrder();
//     org.jfree.chart.axis.ValueAxis var13 = var9.getRangeAxisForDataset(0);
//     java.lang.String[] var16 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var17 = new org.jfree.chart.axis.SymbolAxis("hi!", var16);
//     org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
//     var19.setAutoTickUnitSelection(true);
//     boolean var22 = var19.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var19.setTickUnit(var24, false, true);
//     var17.setTickUnit(var24, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var39 = var35.getURLGenerator(100, (-1), false);
//     java.awt.Paint var41 = var35.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var42 = null;
//     var35.setLegendItemToolTipGenerator(var42);
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var48 = var47.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var49 = new org.jfree.chart.block.LabelBlock("", var48);
//     var35.setSeriesItemLabelFont(1, var48, false);
//     org.jfree.chart.axis.MarkerAxisBand var52 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var17, Double.NaN, 3.0d, 0.08d, 4.0d, var48);
//     int var53 = var17.getMinorTickCount();
//     org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var56 = var55.getChartArea();
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var17.java2DToValue((-1.0d), var56, var57);
//     org.jfree.chart.axis.CategoryAxis3D var60 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var60.addCategoryLabelToolTip((java.lang.Comparable)' ', "TextBlockAnchor.CENTER");
//     org.jfree.chart.axis.LogAxis var70 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var71 = var70.getLabelInsets();
//     double var73 = var71.calculateLeftInset(0.025d);
//     double var74 = var71.getRight();
//     double var76 = var71.calculateRightInset((-0.975d));
//     org.jfree.chart.ChartRenderingInfo var77 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var78 = var77.getChartArea();
//     java.awt.geom.Rectangle2D var79 = var71.createOutsetRectangle(var78);
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var81 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var82 = var81.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var83 = new org.jfree.chart.block.BlockBorder(var82);
//     var80.setNoDataMessagePaint(var82);
//     var80.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var88 = var80.getDomainAxisEdge(255);
//     double var89 = var60.getCategorySeriesMiddle((-1), 15, 10, 0, 0.0d, var78, var88);
//     org.jfree.chart.axis.AxisSpace var90 = new org.jfree.chart.axis.AxisSpace();
//     double var91 = var90.getTop();
//     java.lang.Object var92 = var90.clone();
//     org.jfree.chart.axis.AxisSpace var93 = var3.reserveSpace(var8, (org.jfree.chart.plot.Plot)var9, var56, var88, var90);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.lang.String var5 = var4.getToolTipText();
//     org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
//     var8.setAutoTickUnitSelection(true);
//     boolean var11 = var8.isAutoTickUnitSelection();
//     var8.resizeRange(0.05d);
//     java.awt.Font var14 = var8.getLabelFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("hi!", var14);
//     var4.setFont(var14);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.data.xy.DefaultXYDataset var19 = new org.jfree.data.xy.DefaultXYDataset();
//     int var20 = var19.getSeriesCount();
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var21, (org.jfree.data.Range)var22);
//     boolean var24 = var19.equals((java.lang.Object)var21);
//     org.jfree.data.time.DateRange var25 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var25, (org.jfree.data.Range)var26);
//     org.jfree.chart.block.LengthConstraintType var28 = var27.getWidthConstraintType();
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var31, (org.jfree.data.Range)var32);
//     org.jfree.chart.block.LengthConstraintType var34 = var33.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var21, var28, 0.0d, (org.jfree.data.Range)var30, var34);
//     org.jfree.chart.util.Size2D var36 = var4.arrange(var17, var35);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    var1.handleClick(10, 0, var5);
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var9 = var8.getLabelInsets();
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    var1.setSimpleLabelOffset(var9);
    double var14 = var9.extendWidth(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 6.08d);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
//     var0.setNoDataMessagePaint(var2);
//     var0.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
//     org.jfree.chart.axis.AxisSpace var9 = new org.jfree.chart.axis.AxisSpace();
//     double var10 = var9.getTop();
//     java.lang.Object var11 = var9.clone();
//     var0.setFixedDomainAxisSpace(var9);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var15 = var14.getLowerMargin();
//     var14.setLabel("");
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
//     var20.setSeriesToolTipGenerator(0, var22, true);
//     boolean var25 = var20.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var20.getPositiveItemLabelPositionFallback();
//     var20.setItemMargin(3.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var30 = var29.getBaseItemLabelPaint();
//     java.awt.Paint var32 = var29.getSeriesPaint(10);
//     java.awt.Shape var34 = null;
//     var29.setSeriesShape(0, var34, false);
//     var29.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var39 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var40 = var39.getChartArea();
//     var29.setBaseShape((java.awt.Shape)var40);
//     boolean var42 = var20.equals((java.lang.Object)var40);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var44 = var43.getLegendItems();
//     var43.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     int var47 = var43.indexOf(var46);
//     org.jfree.chart.util.RectangleEdge var48 = var43.getDomainAxisEdge();
//     org.jfree.data.xy.XYDataItem var51 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
//     int var53 = var51.compareTo((java.lang.Object)100.0f);
//     boolean var54 = var48.equals((java.lang.Object)var51);
//     double var55 = var14.getCategoryMiddle(100, 255, var40, var48);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var58 = var57.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(var58);
//     var56.setNoDataMessagePaint(var58);
//     var56.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var64 = var56.getDomainAxisEdge(255);
//     java.awt.geom.Rectangle2D var65 = var9.reserved(var40, var64);
//     
//     // Checks the contract:  equals-hashcode on var3 and var59
//     assertTrue("Contract failed: equals-hashcode on var3 and var59", var3.equals(var59) ? var3.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var3
//     assertTrue("Contract failed: equals-hashcode on var59 and var3", var59.equals(var3) ? var59.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var4 = var2.compareTo((java.lang.Object)100.0f);
    java.lang.Number var5 = var2.getX();
    boolean var6 = var2.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    boolean var1 = var0.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
    var3.setAutoTickUnitSelection(true);
    var3.resizeRange(0.05d, (-1.0d));
    boolean var9 = var3.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
    var11.addCornerTextItem("");
    org.jfree.chart.axis.TickUnit var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setAngleTickUnit(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)100, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var4 = var2.remove(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getStart();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var4.getBaseNegativeItemLabelPosition();
//     var4.setShapesFilled(false);
//     var4.setBaseCreateEntities(false);
//     var4.setPlotArea(true);
//     int var12 = var1.compareTo((java.lang.Object)var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)var1, 2.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    boolean var2 = var1.getProcessVisibleItemsOnly();
    org.jfree.chart.plot.XYCrosshairState var3 = null;
    var1.setCrosshairState(var3);
    org.jfree.chart.plot.XYCrosshairState var5 = null;
    var1.setCrosshairState(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    boolean var13 = var4.equals((java.lang.Object)var9);
    org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var15, "", "Polar Plot");
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var21 = var20.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
    double var23 = var22.getLimit();
    double var24 = var22.getLimit();
    org.jfree.chart.JFreeChart var25 = var22.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var25, (-1), 1);
    boolean var29 = var19.equals((java.lang.Object)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var30 = var25.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
    java.awt.Paint var6 = var0.getSeriesFillPaint(100);
    org.jfree.chart.labels.XYSeriesLabelGenerator var7 = null;
    var0.setLegendItemToolTipGenerator(var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
    org.jfree.chart.util.SortOrder var11 = var9.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var12.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var18 = var14.isItemLabelVisible(0, (-1), true);
    boolean var19 = var13.equals((java.lang.Object)var14);
    org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var21 = var20.getBaseStroke();
    var14.setBaseStroke(var21, false);
    var9.setRangeCrosshairStroke(var21);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
    org.jfree.chart.annotations.CategoryAnnotation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var27 = var9.removeAnnotation(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    double var5 = var3.getLabelGap();
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var3.getLabelGenerator();
    double var7 = var3.getShadowYOffset();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
    double var13 = var11.getLabelGap();
    double var14 = var11.getLabelGap();
    var11.setLabelLinkMargin(4.0d);
    org.jfree.chart.labels.PieSectionLabelGenerator var17 = var11.getLegendLabelGenerator();
    var3.setLabelGenerator(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var52 = var51.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
//     boolean var54 = var50.equals((java.lang.Object)var53);
//     boolean var55 = var50.isShapeFilled();
//     java.awt.Color var59 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
//     int var60 = var59.getAlpha();
//     int var61 = var59.getGreen();
//     var50.setOutlinePaint((java.awt.Paint)var59);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     var63.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var66 = var63.getFixedRangeAxisSpace();
//     var63.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var68 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var69 = var68.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var70 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var74 = var70.isItemLabelVisible(0, (-1), true);
//     boolean var75 = var69.equals((java.lang.Object)var70);
//     org.jfree.chart.renderer.xy.XYBarRenderer var76 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var77 = var76.getBaseStroke();
//     var70.setBaseStroke(var77, false);
//     var63.setDomainCrosshairStroke(var77);
//     org.jfree.chart.ChartRenderingInfo var83 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var84 = var83.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var85 = var83.getPlotInfo();
//     java.awt.geom.Point2D var86 = null;
//     var63.zoomDomainAxes(3.0d, 3.0d, var85, var86);
//     java.awt.Stroke var88 = var63.getDomainGridlineStroke();
//     var50.setOutlineStroke(var88);
//     
//     // Checks the contract:  equals-hashcode on var40 and var69
//     assertTrue("Contract failed: equals-hashcode on var40 and var69", var40.equals(var69) ? var40.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var40
//     assertTrue("Contract failed: equals-hashcode on var69 and var40", var69.equals(var40) ? var69.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var83
//     assertTrue("Contract failed: equals-hashcode on var51 and var83", var51.equals(var83) ? var51.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var51
//     assertTrue("Contract failed: equals-hashcode on var83 and var51", var83.equals(var51) ? var83.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var85
//     assertTrue("Contract failed: equals-hashcode on var53 and var85", var53.equals(var85) ? var53.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var53
//     assertTrue("Contract failed: equals-hashcode on var85 and var53", var85.equals(var53) ? var85.hashCode() == var53.hashCode() : true);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
//     var2.setSeriesToolTipGenerator(0, var4, true);
//     boolean var7 = var2.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var2.getPositiveItemLabelPositionFallback();
//     var2.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2);
//     org.jfree.data.time.TimeSeries var12 = null;
//     org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     var15.setAutoTickUnitSelection(true);
//     var15.resizeRange(0.05d, (-1.0d));
//     boolean var21 = var15.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, (org.jfree.chart.axis.ValueAxis)var15, var22);
//     java.lang.String var24 = var23.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var27 = var26.getBaseItemLabelPaint();
//     var25.setBaseFillPaint(var27);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var27);
//     var23.setRadiusGridlinePaint(var27);
//     java.awt.Paint var31 = var23.getRadiusGridlinePaint();
//     var11.setBackgroundPaint(var31);
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var34 = var33.getBaseItemLabelPaint();
//     var11.setBackgroundPaint(var34);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.data.time.DateRange var37 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var37, (org.jfree.data.Range)var38);
//     org.jfree.chart.block.LengthConstraintType var40 = var39.getWidthConstraintType();
//     org.jfree.data.xy.DefaultXYDataset var42 = new org.jfree.data.xy.DefaultXYDataset();
//     int var43 = var42.getSeriesCount();
//     org.jfree.data.time.DateRange var44 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var45 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var44, (org.jfree.data.Range)var45);
//     boolean var47 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.time.DateRange var48 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var48, (org.jfree.data.Range)var49);
//     org.jfree.chart.block.LengthConstraintType var51 = var50.getWidthConstraintType();
//     org.jfree.data.time.DateRange var53 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var54 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var55 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var54, (org.jfree.data.Range)var55);
//     org.jfree.chart.block.LengthConstraintType var57 = var56.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var44, var51, 0.0d, (org.jfree.data.Range)var53, var57);
//     org.jfree.data.xy.DefaultXYDataset var59 = new org.jfree.data.xy.DefaultXYDataset();
//     int var60 = var59.getSeriesCount();
//     org.jfree.data.time.DateRange var61 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var62 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var61, (org.jfree.data.Range)var62);
//     boolean var64 = var59.equals((java.lang.Object)var61);
//     boolean var65 = var53.intersects((org.jfree.data.Range)var61);
//     org.jfree.chart.block.RectangleConstraint var66 = var39.toRangeWidth((org.jfree.data.Range)var53);
//     org.jfree.chart.util.Size2D var67 = var11.arrange(var36, var39);
//     org.jfree.chart.block.RectangleConstraint var69 = var39.toFixedWidth(3.0d);
//     org.jfree.chart.util.Size2D var70 = var0.arrange(var1, var39);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.util.List var1 = var0.getCategories();
//     java.lang.Object var2 = null;
//     boolean var3 = var0.equals(var2);
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var9 = var5.getURLGenerator(100, (-1), false);
//     java.awt.Paint var11 = var5.getSeriesFillPaint(100);
//     java.awt.Stroke var13 = var5.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var15 = var14.getBaseItemLabelPaint();
//     java.awt.Paint var17 = var14.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var18.getBaseNegativeItemLabelPosition();
//     var14.setPositiveItemLabelPositionFallback(var19);
//     var5.setPositiveItemLabelPositionFallback(var19);
//     boolean var22 = var4.equals((java.lang.Object)var19);
//     boolean var23 = var0.equals((java.lang.Object)var19);
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     org.jfree.chart.entity.PlotEntity var29 = new org.jfree.chart.entity.PlotEntity(var26, (org.jfree.chart.plot.Plot)var28);
//     double var30 = var28.getLabelGap();
//     org.jfree.chart.labels.PieSectionLabelGenerator var31 = var28.getLabelGenerator();
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var35 = var34.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     var28.handleClick((-1), 100, var36);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var41 = var38.getFixedRangeAxisSpace();
//     var38.clearDomainMarkers();
//     int var43 = var38.getCrosshairDatasetIndex();
//     var38.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     var47.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var50 = var47.getFixedRangeAxisSpace();
//     var47.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var53 = var52.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var58 = var54.isItemLabelVisible(0, (-1), true);
//     boolean var59 = var53.equals((java.lang.Object)var54);
//     org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var61 = var60.getBaseStroke();
//     var54.setBaseStroke(var61, false);
//     var47.setDomainCrosshairStroke(var61);
//     org.jfree.chart.ChartRenderingInfo var67 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var68 = var67.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var69 = var67.getPlotInfo();
//     java.awt.geom.Point2D var70 = null;
//     var47.zoomDomainAxes(3.0d, 3.0d, var69, var70);
//     java.awt.geom.Rectangle2D var72 = null;
//     org.jfree.chart.util.RectangleAnchor var73 = null;
//     java.awt.geom.Point2D var74 = org.jfree.chart.util.RectangleAnchor.coordinates(var72, var73);
//     var38.zoomRangeAxes(4.0d, var69, var74, false);
//     var0.panRangeAxes(10.0d, var36, var74);
//     
//     // Checks the contract:  equals-hashcode on var19 and var53
//     assertTrue("Contract failed: equals-hashcode on var19 and var53", var19.equals(var53) ? var19.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var19
//     assertTrue("Contract failed: equals-hashcode on var53 and var19", var53.equals(var19) ? var53.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var67
//     assertTrue("Contract failed: equals-hashcode on var34 and var67", var34.equals(var67) ? var34.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var34
//     assertTrue("Contract failed: equals-hashcode on var67 and var34", var67.equals(var34) ? var67.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var69
//     assertTrue("Contract failed: equals-hashcode on var36 and var69", var36.equals(var69) ? var36.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var36
//     assertTrue("Contract failed: equals-hashcode on var69 and var36", var69.equals(var36) ? var69.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setVersion("Pie 3D Plot");
    java.awt.Image var3 = var0.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
    org.jfree.chart.util.SortOrder var4 = var2.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var5.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var11 = var7.isItemLabelVisible(0, (-1), true);
    boolean var12 = var6.equals((java.lang.Object)var7);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var14 = var13.getBaseStroke();
    var7.setBaseStroke(var14, false);
    var2.setRangeCrosshairStroke(var14);
    org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var20 = var2.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var19);
    org.jfree.data.Range var22 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var0, var20, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var25 = var0.getY(100, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.util.LogFormat var0 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var2 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var12 = var8.getURLGenerator(100, (-1), false);
    java.awt.Paint var14 = var8.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var16 = var15.getBaseNegativeItemLabelPosition();
    var8.setBaseNegativeItemLabelPosition(var16);
    boolean var18 = var7.equals((java.lang.Object)var8);
    java.text.NumberFormat var19 = var7.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var2, var19);
    var0.setExponentFormat((java.text.NumberFormat)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    java.awt.Shape var4 = var1.getShape();
    var1.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    java.awt.Paint[] var0 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var6 = var5.getBaseItemLabelPaint();
    var4.setBaseFillPaint(var6);
    java.awt.Paint[] var8 = new java.awt.Paint[] { var6};
    java.awt.Stroke var9 = null;
    java.awt.Stroke[] var10 = new java.awt.Stroke[] { var9};
    java.awt.Stroke var11 = null;
    java.awt.Stroke[] var12 = new java.awt.Stroke[] { var11};
    java.awt.Shape var13 = null;
    java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var3, var8, var10, var12, var14);
    java.awt.Shape var16 = var15.getNextShape();
    java.awt.Stroke var17 = var15.getNextStroke();
    java.lang.Object var18 = null;
    boolean var19 = var15.equals(var18);
    java.lang.Object var20 = var15.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.util.LogFormat var0 = new org.jfree.chart.util.LogFormat();
    java.util.Currency var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCurrency(var1);
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1L), 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getLabelAngle();
    java.lang.String var3 = var1.getLabelURL();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var11 = var10.getBaseItemLabelPaint();
    var9.setBaseFillPaint(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var11);
    var4.setRangeGridlinePaint(var11);
    var4.setRangePannable(true);
    org.jfree.chart.axis.LogAxis var19 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var20 = var19.getLabelInsets();
    java.lang.Object var21 = null;
    boolean var22 = var20.equals(var21);
    var4.setAxisOffset(var20);
    var1.setLabelInsets(var20, true);
    org.jfree.chart.plot.Plot var26 = var1.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Category Plot", var1);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var9 = var8.getBaseItemLabelPaint();
    var7.setBaseFillPaint(var9);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var17 = var13.isItemLabelVisible(0, (-1), true);
    boolean var18 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var20 = var19.getBaseStroke();
    var13.setBaseStroke(var20, false);
    var7.setBaseStroke(var20);
    var6.setAxisLineStroke(var20);
    var3.setLabelOutlineStroke(var20);
    org.jfree.data.general.PieDataset var26 = null;
    var3.setDataset(var26);
    org.jfree.chart.plot.AbstractPieLabelDistributor var28 = var3.getLabelDistributor();
    double var29 = var3.getLabelGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.025d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    var0.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var3 = null;
    int var4 = var0.indexOf(var3);
    org.jfree.chart.util.RectangleEdge var5 = var0.getDomainAxisEdge();
    int var6 = var0.getCrosshairDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var3, (java.lang.Comparable)(-1.0d));
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.data.time.TimePeriodAnchor var7 = var3.getXPosition();
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var3, false);
    java.lang.Object var10 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getRangeGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var30 = var27.getFixedRangeAxisSpace();
//     var27.clearDomainMarkers();
//     int var32 = var27.getCrosshairDatasetIndex();
//     var27.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var39 = var36.getFixedRangeAxisSpace();
//     var36.clearDomainMarkers();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var42 = var41.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var47 = var43.isItemLabelVisible(0, (-1), true);
//     boolean var48 = var42.equals((java.lang.Object)var43);
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var50 = var49.getBaseStroke();
//     var43.setBaseStroke(var50, false);
//     var36.setDomainCrosshairStroke(var50);
//     org.jfree.chart.ChartRenderingInfo var56 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var57 = var56.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var58 = var56.getPlotInfo();
//     java.awt.geom.Point2D var59 = null;
//     var36.zoomDomainAxes(3.0d, 3.0d, var58, var59);
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleAnchor var62 = null;
//     java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var62);
//     var27.zoomRangeAxes(4.0d, var58, var63, false);
//     var25.setQuadrantOrigin(var63);
//     
//     // Checks the contract:  equals-hashcode on var9 and var42
//     assertTrue("Contract failed: equals-hashcode on var9 and var42", var9.equals(var42) ? var9.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var9
//     assertTrue("Contract failed: equals-hashcode on var42 and var9", var42.equals(var9) ? var42.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var4 = var0.isItemLabelVisible(0, (-1), true);
    var0.setShapesFilled(true);
    org.jfree.data.time.TimeSeries var8 = null;
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
    org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
    var11.setAutoTickUnitSelection(true);
    var11.resizeRange(0.05d, (-1.0d));
    boolean var17 = var11.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
    java.lang.String var20 = var19.getPlotType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var23 = var22.getBaseItemLabelPaint();
    var21.setBaseFillPaint(var23);
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
    var19.setRadiusGridlinePaint(var23);
    var0.setSeriesPaint(100, var23, true);
    java.awt.Shape var30 = var0.lookupLegendShape(10);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var31.setSeriesToolTipGenerator(0, var33, true);
    boolean var36 = var31.isDrawBarOutline();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var45 = var41.isItemLabelVisible(0, (-1), true);
    boolean var46 = var40.equals((java.lang.Object)var41);
    var31.setPositiveItemLabelPositionFallback(var40);
    java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
    org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var52 = var51.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
    boolean var54 = var50.equals((java.lang.Object)var53);
    boolean var55 = var50.isShapeFilled();
    org.jfree.chart.util.GradientPaintTransformer var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setFillPaintTransformer(var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Polar Plot"+ "'", var20.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.lang.Object var1 = var0.clone();
//     java.util.Date var2 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var3 = var0.getSegment(var2);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.resizeRange(0.05d, (-1.0d));
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAxisLinePaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var1.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    var0.setNoDataMessagePaint(var2);
    var0.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(255);
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    java.lang.String var10 = var0.getPlotType();
    org.jfree.chart.axis.AxisState var13 = new org.jfree.chart.axis.AxisState(100.0d);
    var13.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var17 = var16.getLegendItems();
    org.jfree.chart.util.SortOrder var18 = var16.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var19.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var25 = var21.isItemLabelVisible(0, (-1), true);
    boolean var26 = var20.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var28 = var27.getBaseStroke();
    var21.setBaseStroke(var28, false);
    var16.setRangeCrosshairStroke(var28);
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var34 = var16.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var33);
    var13.setTicks(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(0, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Category Plot"+ "'", var10.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var25.setDomainMinorGridlinesVisible(true);
//     java.awt.Graphics2D var28 = null;
//     java.lang.String[] var31 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var32 = new org.jfree.chart.axis.SymbolAxis("hi!", var31);
//     org.jfree.chart.axis.LogAxis var34 = new org.jfree.chart.axis.LogAxis("");
//     var34.setAutoTickUnitSelection(true);
//     boolean var37 = var34.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var39 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var34.setTickUnit(var39, false, true);
//     var32.setTickUnit(var39, false, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var54 = var50.getURLGenerator(100, (-1), false);
//     java.awt.Paint var56 = var50.getSeriesFillPaint(100);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var57 = null;
//     var50.setLegendItemToolTipGenerator(var57);
//     org.jfree.chart.axis.CategoryAxis3D var62 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var63 = var62.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var64 = new org.jfree.chart.block.LabelBlock("", var63);
//     var50.setSeriesItemLabelFont(1, var63, false);
//     org.jfree.chart.axis.MarkerAxisBand var67 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var32, Double.NaN, 3.0d, 0.08d, 4.0d, var63);
//     int var68 = var32.getMinorTickCount();
//     org.jfree.chart.ChartRenderingInfo var70 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var71 = var70.getChartArea();
//     org.jfree.chart.util.RectangleEdge var72 = null;
//     double var73 = var32.java2DToValue((-1.0d), var71, var72);
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     var25.drawAnnotations(var28, var71, var74);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var50.", var16.equals(var50) == var50.equals(var16));
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var9 = var8.getBaseItemLabelPaint();
//     var7.setBaseFillPaint(var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(var9);
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var9);
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var15 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var12, var13, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
//     var17.setSeriesToolTipGenerator(0, var19, true);
//     boolean var22 = var17.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var24 = var17.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var25.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var31 = var27.isItemLabelVisible(0, (-1), true);
//     boolean var32 = var26.equals((java.lang.Object)var27);
//     var17.setPositiveItemLabelPositionFallback(var26);
//     var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17, false);
//     var0.zoom(4.0d);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var1 = var0.getBaseStroke();
//     java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var7 = var6.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var7);
//     var0.setBaseItemLabelFont(var7, false);
//     org.jfree.chart.labels.StandardXYToolTipGenerator var12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
//     java.text.NumberFormat var13 = var12.getXFormat();
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator)var12);
//     java.lang.String[] var17 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var18 = new org.jfree.chart.axis.SymbolAxis("hi!", var17);
//     org.jfree.chart.axis.LogAxis var20 = new org.jfree.chart.axis.LogAxis("");
//     var20.setAutoTickUnitSelection(true);
//     boolean var23 = var20.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var25 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var20.setTickUnit(var25, false, true);
//     var18.setTickUnit(var25, false, true);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var37 = var36.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var42 = var38.isItemLabelVisible(0, (-1), true);
//     boolean var43 = var37.equals((java.lang.Object)var38);
//     org.jfree.chart.renderer.xy.XYBarRenderer var44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var45 = var44.getBaseStroke();
//     var38.setBaseStroke(var45, false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var49 = var48.getBaseStroke();
//     java.lang.Boolean var51 = var48.getSeriesVisibleInLegend(10);
//     org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var55 = var54.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var56 = new org.jfree.chart.block.LabelBlock("", var55);
//     var48.setBaseItemLabelFont(var55, false);
//     var38.setBaseItemLabelFont(var55, true);
//     org.jfree.chart.axis.MarkerAxisBand var61 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var18, 8.0d, Double.NEGATIVE_INFINITY, 10.0d, 0.0d, var55);
//     var0.setBaseLegendTextFont(var55);
//     
//     // Checks the contract:  equals-hashcode on var8 and var56
//     assertTrue("Contract failed: equals-hashcode on var8 and var56", var8.equals(var56) ? var8.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var8
//     assertTrue("Contract failed: equals-hashcode on var56 and var8", var56.equals(var8) ? var56.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 0.05d);
    org.jfree.chart.axis.SegmentedTimeline var5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var6 = var5.clone();
    org.jfree.chart.axis.AxisState var8 = new org.jfree.chart.axis.AxisState(100.0d);
    var8.cursorLeft((-1.0d));
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
    org.jfree.chart.util.SortOrder var13 = var11.getColumnRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var15 = var14.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var20 = var16.isItemLabelVisible(0, (-1), true);
    boolean var21 = var15.equals((java.lang.Object)var16);
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    var16.setBaseStroke(var23, false);
    var11.setRangeCrosshairStroke(var23);
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.util.List var29 = var11.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var28);
    var8.setTicks(var29);
    var5.addExceptions(var29);
    boolean var32 = var4.equals((java.lang.Object)var29);
    var4.clear();
    java.lang.Object var34 = null;
    boolean var35 = var4.equals(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems(var0, 10, Double.NaN, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setSeriesKey((java.lang.Comparable)10.0d);
    org.jfree.chart.util.StandardGradientPaintTransformer var4 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var4);
    org.jfree.chart.util.GradientPaintTransformType var6 = var4.getType();
    org.jfree.chart.axis.LogAxis var8 = new org.jfree.chart.axis.LogAxis("");
    var8.setAutoTickUnitSelection(true);
    var8.resizeRange(0.05d, (-1.0d));
    var8.configure();
    boolean var15 = var4.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var4 = var0.isItemLabelVisible(0, (-1), true);
//     var0.setShapesFilled(true);
//     org.jfree.data.time.TimeSeries var8 = null;
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var8);
//     org.jfree.chart.axis.LogAxis var11 = new org.jfree.chart.axis.LogAxis("");
//     var11.setAutoTickUnitSelection(true);
//     var11.resizeRange(0.05d, (-1.0d));
//     boolean var17 = var11.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, (org.jfree.chart.axis.ValueAxis)var11, var18);
//     java.lang.String var20 = var19.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var23 = var22.getBaseItemLabelPaint();
//     var21.setBaseFillPaint(var23);
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(var23);
//     var19.setRadiusGridlinePaint(var23);
//     var0.setSeriesPaint(100, var23, true);
//     java.awt.Shape var30 = var0.lookupLegendShape(10);
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var31.setSeriesToolTipGenerator(0, var33, true);
//     boolean var36 = var31.isDrawBarOutline();
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = var31.getSeriesToolTipGenerator(0);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var40 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var45 = var41.isItemLabelVisible(0, (-1), true);
//     boolean var46 = var40.equals((java.lang.Object)var41);
//     var31.setPositiveItemLabelPositionFallback(var40);
//     java.awt.Paint var49 = var31.lookupSeriesFillPaint(2147483647);
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var30, var49);
//     org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D("");
//     double var53 = var52.getLabelAngle();
//     java.lang.String var54 = var52.getLabelURL();
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var56 = var55.getLegendItems();
//     org.jfree.chart.util.SortOrder var57 = var55.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var62 = var61.getBaseItemLabelPaint();
//     var60.setBaseFillPaint(var62);
//     org.jfree.chart.block.BlockBorder var64 = new org.jfree.chart.block.BlockBorder(var62);
//     org.jfree.chart.plot.IntervalMarker var65 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var62);
//     var55.setRangeGridlinePaint(var62);
//     var55.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var70 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var71 = var70.getLabelInsets();
//     java.lang.Object var72 = null;
//     boolean var73 = var71.equals(var72);
//     var55.setAxisOffset(var71);
//     var52.setLabelInsets(var71, true);
//     org.jfree.chart.plot.MultiplePiePlot var77 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var78 = var77.getLimit();
//     double var79 = var77.getLimit();
//     org.jfree.chart.JFreeChart var80 = var77.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var83 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var52, var80, 0, 0);
//     double var84 = var52.getCategoryMargin();
//     java.awt.Stroke var85 = var52.getTickMarkStroke();
//     var50.setLineStroke(var85);
//     
//     // Checks the contract:  equals-hashcode on var25 and var64
//     assertTrue("Contract failed: equals-hashcode on var25 and var64", var25.equals(var64) ? var25.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var25
//     assertTrue("Contract failed: equals-hashcode on var64 and var25", var64.equals(var25) ? var64.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.util.SortOrder var2 = var0.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var7 = var6.getBaseItemLabelPaint();
//     var5.setBaseFillPaint(var7);
//     org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(var7);
//     org.jfree.chart.plot.IntervalMarker var10 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var7);
//     var0.setRangeGridlinePaint(var7);
//     var0.setRangePannable(true);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
//     java.lang.Object var17 = null;
//     boolean var18 = var16.equals(var17);
//     var0.setAxisOffset(var16);
//     double var21 = var16.extendWidth(Double.NaN);
//     double var22 = var16.getRight();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.0d);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var2 = var0.getDataset(10);
    org.jfree.chart.util.Layer var4 = null;
    java.util.Collection var5 = var0.getDomainMarkers(10, var4);
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var4 = var3.getAlpha();
    int var5 = var3.getGreen();
    org.jfree.chart.axis.AxisSpace var6 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var7 = var6.clone();
    boolean var8 = var3.equals(var7);
    float[] var10 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var3.getRGBComponents(var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var1.getBaseItemLabelPaint();
//     java.awt.Paint var4 = var1.getSeriesPaint(10);
//     java.awt.Shape var6 = null;
//     var1.setSeriesShape(0, var6, false);
//     var1.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     var1.setBaseShape((java.awt.Shape)var12);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var15 = var14.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var17 = var16.getLimit();
//     double var18 = var16.getLimit();
//     org.jfree.chart.JFreeChart var19 = var16.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var14, var19, (-1), 1);
//     java.lang.Object var23 = var19.clone();
//     org.jfree.chart.entity.JFreeChartEntity var24 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var12, var19);
//     var0.setPieChart(var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var16
//     assertTrue("Contract failed: equals-hashcode on var0 and var16", var0.equals(var16) ? var0.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, (-6.0d));
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.data.Range var4 = var2.findRangeBounds(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextBlockAnchor.CENTER", var1, 1.0f, 0.0f, var4);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis("");
//     var2.setAutoTickUnitSelection(true);
//     boolean var5 = var2.isAutoTickUnitSelection();
//     var2.resizeRange(0.05d);
//     java.awt.Font var8 = var2.getLabelFont();
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var10.setLabelPaint(var13);
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("TitleEntity: tooltip = hi!", var8, var13, 10.0f);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.text.TextAnchor var20 = null;
//     var16.draw(var17, (-1.0f), 0.8f, var20, 1.0f, 1.0f, 10.0d);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.awt.Paint var6 = var0.getSeriesFillPaint(100);
//     java.awt.Stroke var8 = var0.lookupSeriesOutlineStroke(100);
//     java.awt.Paint var12 = var0.getItemLabelPaint(2147483647, 100, true);
//     org.jfree.data.time.TimeSeries var14 = null;
//     org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
//     org.jfree.chart.axis.LogAxis var17 = new org.jfree.chart.axis.LogAxis("");
//     var17.setAutoTickUnitSelection(true);
//     var17.resizeRange(0.05d, (-1.0d));
//     boolean var23 = var17.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var15, (org.jfree.chart.axis.ValueAxis)var17, var24);
//     java.lang.String var26 = var25.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var29 = var28.getBaseItemLabelPaint();
//     var27.setBaseFillPaint(var29);
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var29);
//     var25.setRadiusGridlinePaint(var29);
//     var0.setSeriesItemLabelPaint(10, var29);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var0.", var28.equals(var0) == var0.equals(var28));
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    boolean var5 = var0.isDrawBarOutline();
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot();
    float var7 = var6.getForegroundAlpha();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPosition(0, 1, true);
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.time.TimeSeries var14 = null;
    java.util.TimeZone var15 = null;
    org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14, var15);
    org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, (org.jfree.data.general.Dataset)var16, (java.lang.Comparable)(-1.0d));
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var22 = var21.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
    java.lang.String var24 = var23.getToolTipText();
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var29 = var25.getURLGenerator(100, (-1), false);
    java.awt.Paint var31 = var25.getSeriesFillPaint(100);
    java.awt.Stroke var33 = var25.lookupSeriesOutlineStroke(100);
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var35 = var34.getBaseItemLabelPaint();
    java.awt.Paint var37 = var34.getSeriesPaint(10);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var39 = var38.getBaseNegativeItemLabelPosition();
    var34.setPositiveItemLabelPositionFallback(var39);
    var25.setPositiveItemLabelPositionFallback(var39);
    var18.add((org.jfree.chart.block.Block)var23, (java.lang.Object)var39);
    var0.setBasePositiveItemLabelPosition(var39);
    var0.setBaseItemLabelsVisible(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    java.lang.String[] var2 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
    var5.setAutoTickUnitSelection(true);
    boolean var8 = var5.isAutoTickUnitSelection();
    org.jfree.chart.axis.NumberTickUnit var10 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
    var5.setTickUnit(var10, false, true);
    var3.setTickUnit(var10, false, true);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.entity.PieSectionEntity var26 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var19, var20, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var28 = var27.getLegendItems();
    var27.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var30 = null;
    int var31 = var27.indexOf(var30);
    org.jfree.chart.util.RectangleEdge var32 = var27.getDomainAxisEdge();
    boolean var33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var32);
    double var34 = var3.valueToJava2D(0.05d, var19, var32);
    var3.setFixedAutoRange(0.14d);
    java.lang.String[] var39 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.chart.axis.SymbolAxis var40 = new org.jfree.chart.axis.SymbolAxis("hi!", var39);
    java.awt.Paint var41 = var40.getGridBandPaint();
    org.jfree.data.RangeType var42 = var40.getRangeType();
    var3.setRangeType(var42);
    java.awt.Image var47 = null;
    org.jfree.chart.ui.ProjectInfo var51 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var47, "", "", "");
    java.lang.String var52 = var51.getName();
    java.awt.Image var56 = null;
    org.jfree.chart.ui.ProjectInfo var60 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "", var56, "", "", "");
    java.lang.String var61 = var60.getName();
    var51.addOptionalLibrary((org.jfree.chart.ui.Library)var60);
    org.jfree.chart.ui.Library[] var63 = var60.getLibraries();
    java.lang.String var64 = var60.getLicenceName();
    boolean var65 = var42.equals((java.lang.Object)var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + ""+ "'", var52.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + ""+ "'", var61.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + ""+ "'", var64.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("December 2014", var1, var2);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getBaseNegativeItemLabelPosition();
    var0.setShapesFilled(false);
    boolean var4 = var0.getShapesVisible();
    java.awt.Paint var5 = var0.getBaseLegendTextPaint();
    var0.setBaseCreateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    double var2 = var0.getLimit();
    org.jfree.chart.JFreeChart var3 = var0.getPieChart();
    boolean var4 = var3.getAntiAlias();
    int var5 = var3.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 15);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getRangeGridlineStroke();
//     org.jfree.chart.plot.Marker var28 = null;
//     org.jfree.chart.util.Layer var29 = null;
//     var25.addRangeMarker(13, var28, var29);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.setVisible(false);
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    var1.zoomRange(0.08d, 0.14d);
    org.jfree.data.Range var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.lang.String var5 = var4.getToolTipText();
//     var4.setToolTipText("");
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
//     boolean var13 = var4.equals((java.lang.Object)var9);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     boolean var17 = var16.getNotify();
//     java.lang.String var18 = var16.getURLText();
//     int var19 = var16.getMaximumLinesToDisplay();
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("");
//     var21.setExpandToFitSpace(false);
//     boolean var24 = var16.equals((java.lang.Object)var21);
//     org.jfree.chart.entity.TitleEntity var26 = new org.jfree.chart.entity.TitleEntity(var14, (org.jfree.chart.title.Title)var21, "hi!");
//     var21.setMargin(90.0d, (-0.975d), 0.08d, 0.05d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var33 = var32.getBaseItemLabelPaint();
//     java.awt.Paint var35 = var32.getSeriesPaint(10);
//     java.awt.Shape var37 = null;
//     var32.setSeriesShape(0, var37, false);
//     var32.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var42 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var43 = var42.getChartArea();
//     var32.setBaseShape((java.awt.Shape)var43);
//     org.jfree.data.general.PieDataset var45 = null;
//     java.lang.Comparable var48 = null;
//     org.jfree.chart.entity.PieSectionEntity var51 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var43, var45, 100, 2147483647, var48, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var55 = var54.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var56 = new org.jfree.chart.block.LabelBlock("", var55);
//     java.lang.String var57 = var56.getToolTipText();
//     var56.setToolTipText("");
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot(var62);
//     org.jfree.chart.entity.PlotEntity var64 = new org.jfree.chart.entity.PlotEntity(var61, (org.jfree.chart.plot.Plot)var63);
//     boolean var65 = var56.equals((java.lang.Object)var61);
//     org.jfree.chart.axis.LogAxis var67 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var68 = var67.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var71 = new org.jfree.chart.entity.AxisEntity(var61, (org.jfree.chart.axis.Axis)var67, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var72 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var73 = var72.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var74 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var75 = var74.getLimit();
//     double var76 = var74.getLimit();
//     org.jfree.chart.JFreeChart var77 = var74.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var80 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var72, var77, (-1), 1);
//     boolean var81 = var71.equals((java.lang.Object)var77);
//     org.jfree.chart.entity.JFreeChartEntity var83 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var43, var77, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     var21.setBounds(var43);
//     
//     // Checks the contract:  equals-hashcode on var4 and var56
//     assertTrue("Contract failed: equals-hashcode on var4 and var56", var4.equals(var56) ? var4.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var4
//     assertTrue("Contract failed: equals-hashcode on var56 and var4", var56.equals(var4) ? var56.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var63
//     assertTrue("Contract failed: equals-hashcode on var11 and var63", var11.equals(var63) ? var11.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var11
//     assertTrue("Contract failed: equals-hashcode on var63 and var11", var63.equals(var11) ? var63.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(15, (java.lang.Comparable)1L, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var0.getURLGenerator(100, (-1), false);
//     java.awt.Paint var6 = var0.getSeriesFillPaint(100);
//     java.awt.Stroke var8 = var0.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var10 = var9.getBaseItemLabelPaint();
//     java.awt.Paint var12 = var9.getSeriesPaint(10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var13.getBaseNegativeItemLabelPosition();
//     var9.setPositiveItemLabelPositionFallback(var14);
//     var0.setPositiveItemLabelPositionFallback(var14);
//     org.jfree.chart.plot.XYPlot var17 = var0.getPlot();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var0.getSeriesPositiveItemLabelPosition(255);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var0.getBaseNegativeItemLabelPosition();
//     
//     // Checks the contract:  equals-hashcode on var14 and var20
//     assertTrue("Contract failed: equals-hashcode on var14 and var20", var14.equals(var20) ? var14.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var14
//     assertTrue("Contract failed: equals-hashcode on var20 and var14", var20.equals(var14) ? var20.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    double var3 = var2.getLimit();
    double var4 = var2.getLimit();
    org.jfree.chart.JFreeChart var5 = var2.getPieChart();
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, (-1), 1);
    var8.setPercent(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    var1.clearDomainAxes();
    org.jfree.data.category.CategoryDataset var4 = null;
    int var5 = var1.indexOf(var4);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var10 = var6.isItemLabelVisible(0, (-1), true);
    var6.setSeriesCreateEntities(100, (java.lang.Boolean)true, false);
    java.awt.Paint var18 = var6.getItemPaint(0, 100, true);
    org.jfree.data.time.TimeSeries var19 = null;
    java.util.TimeZone var20 = null;
    org.jfree.data.time.TimeSeriesCollection var21 = new org.jfree.data.time.TimeSeriesCollection(var19, var20);
    org.jfree.data.Range var23 = var21.getDomainBounds(true);
    org.jfree.data.Range var24 = var6.findDomainBounds((org.jfree.data.xy.XYDataset)var21);
    java.awt.Paint var25 = var6.getBaseItemLabelPaint();
    var1.setDomainCrosshairPaint(var25);
    org.jfree.chart.axis.LogAxis var28 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelInsets();
    boolean var30 = var28.isPositiveArrowVisible();
    var1.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    var28.setAutoRangeMinimumSize(4.0d);
    var28.setLabelAngle(0.05d);
    boolean var36 = var0.equals((java.lang.Object)var28);
    org.jfree.data.xy.XYDataItem var40 = new org.jfree.data.xy.XYDataItem((java.lang.Number)0, (java.lang.Number)10.0f);
    int var42 = var40.compareTo((java.lang.Object)100.0f);
    var40.setSelected(false);
    double var45 = var40.getYValue();
    var40.setY(0.025d);
    java.lang.Object var48 = var40.clone();
    var40.setY(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(1, (java.lang.Comparable)0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var3 = var2.getBaseItemLabelPaint();
//     java.awt.Paint var5 = var2.getSeriesPaint(10);
//     java.awt.Shape var7 = null;
//     var2.setSeriesShape(0, var7, false);
//     var2.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var13 = var12.getChartArea();
//     var2.setBaseShape((java.awt.Shape)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     java.lang.Comparable var18 = null;
//     org.jfree.chart.entity.PieSectionEntity var21 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var13, var15, 100, 2147483647, var18, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var25 = var24.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("", var25);
//     java.lang.String var27 = var26.getToolTipText();
//     var26.setToolTipText("");
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     org.jfree.chart.entity.PlotEntity var34 = new org.jfree.chart.entity.PlotEntity(var31, (org.jfree.chart.plot.Plot)var33);
//     boolean var35 = var26.equals((java.lang.Object)var31);
//     org.jfree.chart.axis.LogAxis var37 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var38 = var37.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var41 = new org.jfree.chart.entity.AxisEntity(var31, (org.jfree.chart.axis.Axis)var37, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var43 = var42.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var44 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var45 = var44.getLimit();
//     double var46 = var44.getLimit();
//     org.jfree.chart.JFreeChart var47 = var44.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var50 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var42, var47, (-1), 1);
//     boolean var51 = var41.equals((java.lang.Object)var47);
//     org.jfree.chart.entity.JFreeChartEntity var53 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var13, var47, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var56 = var55.getBaseItemLabelPaint();
//     org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder(var56);
//     var54.setNoDataMessagePaint(var56);
//     var54.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.util.RectangleEdge var62 = var54.getDomainAxisEdge(255);
//     double var63 = var0.valueToJava2D(4.0d, var13, var62);
//     
//     // Checks the contract:  equals-hashcode on var42 and var57
//     assertTrue("Contract failed: equals-hashcode on var42 and var57", var42.equals(var57) ? var42.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var42
//     assertTrue("Contract failed: equals-hashcode on var57 and var42", var57.equals(var42) ? var57.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var3 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
    java.lang.String var5 = var4.getToolTipText();
    var4.setToolTipText("");
    java.lang.String var8 = var4.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     float var1 = var0.getForegroundAlpha();
//     var0.setNotify(false);
//     org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var5 = var4.getLimit();
//     double var6 = var4.getLimit();
//     var0.setParent((org.jfree.chart.plot.Plot)var4);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var10 = var9.getBaseStroke();
//     double var11 = var9.getShadowXOffset();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = null;
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     var15.setAutoTickUnitSelection(true);
//     var15.setVisible(false);
//     org.jfree.chart.plot.Plot var20 = var15.getPlot();
//     var15.setLowerMargin(0.08d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var24 = var23.getBaseItemLabelPaint();
//     java.awt.Paint var26 = var23.getSeriesPaint(10);
//     java.awt.Shape var28 = null;
//     var23.setSeriesShape(0, var28, false);
//     var23.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var34 = var33.getChartArea();
//     var23.setBaseShape((java.awt.Shape)var34);
//     org.jfree.data.general.PieDataset var36 = null;
//     java.lang.Comparable var39 = null;
//     org.jfree.chart.entity.PieSectionEntity var42 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var34, var36, 100, 2147483647, var39, "", "Polar Plot");
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("");
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     java.awt.Paint var48 = var47.getLabelPaint();
//     var45.setLabelPaint(var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
//     org.jfree.chart.util.SortOrder var52 = var50.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var54 = var53.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var59 = var55.isItemLabelVisible(0, (-1), true);
//     boolean var60 = var54.equals((java.lang.Object)var55);
//     org.jfree.chart.renderer.xy.XYBarRenderer var61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var62 = var61.getBaseStroke();
//     var55.setBaseStroke(var62, false);
//     var50.setRangeCrosshairStroke(var62);
//     var9.drawDomainLine(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var34, 10.0d, var48, var62);
//     java.awt.geom.Point2D var67 = null;
//     org.jfree.chart.plot.PlotState var68 = null;
//     org.jfree.chart.plot.PolarPlot var69 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var73 = var72.getLegendItems();
//     org.jfree.chart.util.SortOrder var74 = var72.getColumnRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     java.awt.geom.Rectangle2D var77 = null;
//     org.jfree.chart.util.RectangleAnchor var78 = null;
//     java.awt.geom.Point2D var79 = org.jfree.chart.util.RectangleAnchor.coordinates(var77, var78);
//     var72.zoomRangeAxes(0.05d, var76, var79, false);
//     var69.zoomDomainAxes(0.08d, var71, var79, false);
//     org.jfree.chart.ChartRenderingInfo var86 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var87 = var86.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var88 = new org.jfree.chart.plot.PlotRenderingInfo(var86);
//     org.jfree.chart.renderer.xy.XYItemRendererState var89 = new org.jfree.chart.renderer.xy.XYItemRendererState(var88);
//     java.awt.geom.Rectangle2D var90 = null;
//     org.jfree.chart.util.RectangleAnchor var91 = null;
//     java.awt.geom.Point2D var92 = org.jfree.chart.util.RectangleAnchor.coordinates(var90, var91);
//     var69.zoomDomainAxes(0.025d, 90.0d, var88, var92);
//     org.jfree.chart.renderer.xy.XYItemRendererState var94 = new org.jfree.chart.renderer.xy.XYItemRendererState(var88);
//     var0.draw(var8, var34, var67, var68, var88);
//     
//     // Checks the contract:  equals-hashcode on var33 and var86
//     assertTrue("Contract failed: equals-hashcode on var33 and var86", var33.equals(var86) ? var33.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var33
//     assertTrue("Contract failed: equals-hashcode on var86 and var33", var86.equals(var33) ? var86.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var73
//     assertTrue("Contract failed: equals-hashcode on var51 and var73", var51.equals(var73) ? var51.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var51
//     assertTrue("Contract failed: equals-hashcode on var73 and var51", var73.equals(var51) ? var73.hashCode() == var51.hashCode() : true);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     var1.setAutoTickUnitSelection(true);
//     boolean var4 = var1.isAutoTickUnitSelection();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var6 = var5.getLegendItems();
//     org.jfree.chart.util.SortOrder var7 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var8.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     boolean var14 = var10.isItemLabelVisible(0, (-1), true);
//     boolean var15 = var9.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var17 = var16.getBaseStroke();
//     var10.setBaseStroke(var17, false);
//     var5.setRangeCrosshairStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.util.List var23 = var5.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var22);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     java.awt.Stroke var26 = var25.getDomainCrosshairStroke();
//     var25.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var30 = var29.getLegendItems();
//     org.jfree.chart.util.SortOrder var31 = var29.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var32 = var29.getColumnRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var38 = var37.getBaseItemLabelPaint();
//     var36.setBaseFillPaint(var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(var38);
//     org.jfree.chart.plot.IntervalMarker var41 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-1.0d), var38);
//     org.jfree.chart.util.Layer var42 = null;
//     boolean var44 = var29.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var41, var42, false);
//     float var45 = var41.getAlpha();
//     org.jfree.chart.util.Layer var46 = null;
//     boolean var47 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var41, var46);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = var1.getLabelPaint();
    var1.setPieIndex(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    var1.setAutoTickUnitSelection(true);
    var1.setVisible(false);
    org.jfree.chart.plot.Plot var6 = var1.getPlot();
    org.jfree.data.time.TimeSeries var7 = null;
    org.jfree.data.time.TimeSeriesCollection var8 = new org.jfree.data.time.TimeSeriesCollection(var7);
    org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
    var10.setAutoTickUnitSelection(true);
    var10.resizeRange(0.05d, (-1.0d));
    boolean var16 = var10.isVerticalTickLabels();
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, (org.jfree.chart.axis.ValueAxis)var10, var17);
    java.lang.String var19 = var18.getPlotType();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
    org.jfree.chart.entity.PlotEntity var24 = new org.jfree.chart.entity.PlotEntity(var21, (org.jfree.chart.plot.Plot)var23);
    org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var29 = var28.getBaseItemLabelPaint();
    var27.setBaseFillPaint(var29);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var32 = var31.getBaseNegativeItemLabelPosition();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    boolean var37 = var33.isItemLabelVisible(0, (-1), true);
    boolean var38 = var32.equals((java.lang.Object)var33);
    org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var40 = var39.getBaseStroke();
    var33.setBaseStroke(var40, false);
    var27.setBaseStroke(var40);
    var26.setAxisLineStroke(var40);
    var23.setLabelOutlineStroke(var40);
    var18.setRadiusGridlineStroke(var40);
    var1.setTickMarkStroke(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Polar Plot"+ "'", var19.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    float[] var5 = new float[] { 10.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(2147483647, 0, 13, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getStart();
//     java.util.Date var4 = var1.getEnd();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(0, var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1418759999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.util.LogFormat var1 = new org.jfree.chart.util.LogFormat();
    org.jfree.chart.util.LogFormat var6 = new org.jfree.chart.util.LogFormat(10.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", false);
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var11 = var7.getURLGenerator(100, (-1), false);
    java.awt.Paint var13 = var7.getSeriesFillPaint(100);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    org.jfree.chart.labels.ItemLabelPosition var15 = var14.getBaseNegativeItemLabelPosition();
    var7.setBaseNegativeItemLabelPosition(var15);
    boolean var17 = var6.equals((java.lang.Object)var7);
    java.text.NumberFormat var18 = var6.getExponentFormat();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TimePeriodAnchor.START", (java.text.NumberFormat)var1, var18);
    java.lang.Object var20 = var19.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var3 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var3);
//     java.lang.String var5 = var4.getToolTipText();
//     var4.setToolTipText("");
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11);
//     boolean var13 = var4.equals((java.lang.Object)var9);
//     org.jfree.chart.axis.LogAxis var15 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var15, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var21 = var20.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var23 = var22.getLimit();
//     double var24 = var22.getLimit();
//     org.jfree.chart.JFreeChart var25 = var22.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var20, var25, (-1), 1);
//     boolean var29 = var19.equals((java.lang.Object)var25);
//     float var30 = var25.getBackgroundImageAlpha();
//     java.awt.RenderingHints var31 = null;
//     var25.setRenderingHints(var31);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var0, (org.jfree.data.Range)var1);
//     org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
//     org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.CategoryToolTipGenerator var6 = null;
//     var4.setSeriesToolTipGenerator(0, var6, true);
//     boolean var9 = var4.isDrawBarOutline();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var4.getPositiveItemLabelPositionFallback();
//     var4.setItemMargin(3.0d);
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.data.time.TimeSeries var14 = null;
//     org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
//     org.jfree.chart.axis.LogAxis var17 = new org.jfree.chart.axis.LogAxis("");
//     var17.setAutoTickUnitSelection(true);
//     var17.resizeRange(0.05d, (-1.0d));
//     boolean var23 = var17.isVerticalTickLabels();
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var15, (org.jfree.chart.axis.ValueAxis)var17, var24);
//     java.lang.String var26 = var25.getPlotType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var29 = var28.getBaseItemLabelPaint();
//     var27.setBaseFillPaint(var29);
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var29);
//     var25.setRadiusGridlinePaint(var29);
//     java.awt.Paint var33 = var25.getRadiusGridlinePaint();
//     var13.setBackgroundPaint(var33);
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var36 = var35.getBaseItemLabelPaint();
//     var13.setBackgroundPaint(var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.data.time.DateRange var39 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var39, (org.jfree.data.Range)var40);
//     org.jfree.chart.block.LengthConstraintType var42 = var41.getWidthConstraintType();
//     org.jfree.data.xy.DefaultXYDataset var44 = new org.jfree.data.xy.DefaultXYDataset();
//     int var45 = var44.getSeriesCount();
//     org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var47 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var46, (org.jfree.data.Range)var47);
//     boolean var49 = var44.equals((java.lang.Object)var46);
//     org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var51 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var52 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var50, (org.jfree.data.Range)var51);
//     org.jfree.chart.block.LengthConstraintType var53 = var52.getWidthConstraintType();
//     org.jfree.data.time.DateRange var55 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var57 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var56, (org.jfree.data.Range)var57);
//     org.jfree.chart.block.LengthConstraintType var59 = var58.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var60 = new org.jfree.chart.block.RectangleConstraint(0.05d, (org.jfree.data.Range)var46, var53, 0.0d, (org.jfree.data.Range)var55, var59);
//     org.jfree.data.xy.DefaultXYDataset var61 = new org.jfree.data.xy.DefaultXYDataset();
//     int var62 = var61.getSeriesCount();
//     org.jfree.data.time.DateRange var63 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var64 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var63, (org.jfree.data.Range)var64);
//     boolean var66 = var61.equals((java.lang.Object)var63);
//     boolean var67 = var55.intersects((org.jfree.data.Range)var63);
//     org.jfree.chart.block.RectangleConstraint var68 = var41.toRangeWidth((org.jfree.data.Range)var55);
//     org.jfree.chart.util.Size2D var69 = var13.arrange(var38, var41);
//     double var70 = var69.getHeight();
//     org.jfree.chart.util.Size2D var71 = var2.calculateConstrainedSize(var69);
//     
//     // Checks the contract:  equals-hashcode on var69 and var71
//     assertTrue("Contract failed: equals-hashcode on var69 and var71", var69.equals(var71) ? var69.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var69
//     assertTrue("Contract failed: equals-hashcode on var71 and var69", var71.equals(var69) ? var71.hashCode() == var69.hashCode() : true);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var5 = var4.getBaseItemLabelPaint();
//     java.awt.Paint var7 = var4.getSeriesPaint(10);
//     java.awt.Shape var9 = null;
//     var4.setSeriesShape(0, var9, false);
//     var4.setBase((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     var4.setBaseShape((java.awt.Shape)var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     java.lang.Comparable var20 = null;
//     org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var15, var17, 100, 2147483647, var20, "", "Polar Plot");
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Font var27 = var26.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("", var27);
//     java.lang.String var29 = var28.getToolTipText();
//     var28.setToolTipText("");
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     org.jfree.chart.entity.PlotEntity var36 = new org.jfree.chart.entity.PlotEntity(var33, (org.jfree.chart.plot.Plot)var35);
//     boolean var37 = var28.equals((java.lang.Object)var33);
//     org.jfree.chart.axis.LogAxis var39 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.RectangleInsets var40 = var39.getLabelInsets();
//     org.jfree.chart.entity.AxisEntity var43 = new org.jfree.chart.entity.AxisEntity(var33, (org.jfree.chart.axis.Axis)var39, "", "Polar Plot");
//     org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var45 = var44.getPaint();
//     org.jfree.chart.plot.MultiplePiePlot var46 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var47 = var46.getLimit();
//     double var48 = var46.getLimit();
//     org.jfree.chart.JFreeChart var49 = var46.getPieChart();
//     org.jfree.chart.event.ChartProgressEvent var52 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var44, var49, (-1), 1);
//     boolean var53 = var43.equals((java.lang.Object)var49);
//     org.jfree.chart.entity.JFreeChartEntity var55 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var15, var49, " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
//     java.lang.String[] var58 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var59 = new org.jfree.chart.axis.SymbolAxis("hi!", var58);
//     org.jfree.chart.axis.LogAxis var61 = new org.jfree.chart.axis.LogAxis("");
//     var61.setAutoTickUnitSelection(true);
//     boolean var64 = var61.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var66 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var61.setTickUnit(var66, false, true);
//     var59.setTickUnit(var66, false, true);
//     org.jfree.chart.ChartRenderingInfo var74 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var75 = var74.getChartArea();
//     org.jfree.data.general.PieDataset var76 = null;
//     org.jfree.chart.entity.PieSectionEntity var82 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var75, var76, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var84 = var83.getLegendItems();
//     var83.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var86 = null;
//     int var87 = var83.indexOf(var86);
//     org.jfree.chart.util.RectangleEdge var88 = var83.getDomainAxisEdge();
//     boolean var89 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var88);
//     double var90 = var59.valueToJava2D(0.05d, var75, var88);
//     org.jfree.chart.util.RectangleEdge var91 = org.jfree.chart.util.RectangleEdge.opposite(var88);
//     org.jfree.chart.axis.AxisState var93 = new org.jfree.chart.axis.AxisState(100.0d);
//     var93.cursorRight(Double.NaN);
//     var1.drawTickMarks(var2, 4.0d, var15, var88, var93);
//     
//     // Checks the contract:  equals-hashcode on var14 and var74
//     assertTrue("Contract failed: equals-hashcode on var14 and var74", var14.equals(var74) ? var14.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var14
//     assertTrue("Contract failed: equals-hashcode on var74 and var14", var74.equals(var14) ? var74.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var5 = var4.getLabelAngle();
    float var6 = var4.getMaximumCategoryLabelWidthRatio();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    org.jfree.chart.entity.PlotEntity var11 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var10);
    var4.setPlot((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var10.setURLGenerator(var13);
    boolean var15 = var1.equals((java.lang.Object)var10);
    java.lang.Comparable var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var17 = var10.getSectionPaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Color var4 = java.awt.Color.getHSBColor(1.0f, 10.0f, 0.0f);
    int var5 = var4.getAlpha();
    int var6 = var4.getTransparency();
    boolean var7 = var0.equals((java.lang.Object)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(0.05d, (-3.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     double var1 = var0.getLimit();
//     double var2 = var0.getLimit();
//     org.jfree.chart.JFreeChart var3 = var0.getPieChart();
//     int var4 = var3.getSubtitleCount();
//     java.awt.Image var5 = var3.getBackgroundImage();
//     java.awt.Graphics2D var6 = null;
//     java.lang.String[] var9 = org.jfree.data.time.SerialDate.getMonths(false);
//     org.jfree.chart.axis.SymbolAxis var10 = new org.jfree.chart.axis.SymbolAxis("hi!", var9);
//     org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
//     var12.setAutoTickUnitSelection(true);
//     boolean var15 = var12.isAutoTickUnitSelection();
//     org.jfree.chart.axis.NumberTickUnit var17 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
//     var12.setTickUnit(var17, false, true);
//     var10.setTickUnit(var17, false, true);
//     org.jfree.chart.ChartRenderingInfo var25 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var26 = var25.getChartArea();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.entity.PieSectionEntity var33 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var26, var27, 10, 1, (java.lang.Comparable)2.0d, "Polar Plot", "Polar Plot");
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var35 = var34.getLegendItems();
//     var34.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     int var38 = var34.indexOf(var37);
//     org.jfree.chart.util.RectangleEdge var39 = var34.getDomainAxisEdge();
//     boolean var40 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var39);
//     double var41 = var10.valueToJava2D(0.05d, var26, var39);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var26, (-3.0d), 2.0f, 10.0f);
//     org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo();
//     var3.draw(var6, var26, var46);
// 
//   }

}
