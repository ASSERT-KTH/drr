
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, (-1.0d), 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, (-1.0f), 100, var5);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(var0, (java.awt.Paint)var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, (-1.0d), 10, (java.lang.Comparable)1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.Marker var2 = null;
//     org.jfree.chart.util.Layer var3 = null;
//     boolean var4 = var0.removeDomainMarker(0, var2, var3);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.drawBackground(var1, var2);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var0.setNoDataMessage("");
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var0.draw(var4, var5, var6, var7, var8);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var0.setNoDataMessage("");
    boolean var5 = var0.equals((java.lang.Object)"hi!");
    org.jfree.chart.util.TableOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataExtractOrder(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.Marker var1 = null;
//     org.jfree.chart.util.Layer var2 = null;
//     boolean var3 = var0.removeDomainMarker(var1, var2);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3, true);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getDomainTickBandPaint();
//     boolean var8 = var0.equals((java.lang.Object)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("hi!");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 100.0f, (-1.0d), 0.0f, 1.0f);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 100.0d);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(100, var3, true);
    org.jfree.chart.axis.AxisLocation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("", var1, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0d, 100.0f, 100.0f);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var0.removeRangeMarker(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", var3);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-1.0d), 10.0d, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test36() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
//
//
//    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var0);
//
//  }
//
  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getDomainTickBandPaint();
//     java.awt.Stroke var8 = var6.getRangeCrosshairStroke();
//     var0.setRangeCrosshairStroke(var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", var1, var2);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(100, var3, true);
    var0.setRangeGridlinesVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 100, 255, (java.lang.Comparable)(-1), "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0d, 10.0f, (-1.0f));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.5f, 1, var8);
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.addLine("hi!", var11, (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3, true);
//     var0.setRangeGridlinesVisible(true);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var9 = var8.getDomainTickBandPaint();
//     var0.setParent((org.jfree.chart.plot.Plot)var8);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.event.ChartProgressListener var2 = null;
    var1.removeProgressListener(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var4 = var1.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.TOP_LEFT", var1, 0.5f, 100.0f, 10.0d, 0.0f, 0.0f);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var5.createOutsetRectangle(var6, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     java.util.List var6 = var1.refreshTicks(var2, var3, var4, var5);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    org.jfree.chart.text.TextAnchor var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelTextAnchor(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     java.lang.Class var22 = null;
//     java.util.EventListener[] var23 = var21.getListeners(var22);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.Range var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var1, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     var0.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.handleClick(10, 0, var5);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     double var7 = var5.calculateBottomInset((-1.0d));
//     java.awt.geom.Rectangle2D var8 = null;
//     var5.trim(var8);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    org.jfree.data.RangeType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     java.awt.Paint var31 = null;
//     var29.setOutlinePaint(var31);
//     boolean var33 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var29);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     var0.handleClick(10, 0, var4);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     var1.addAll(var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.util.List var5 = null;
//     var0.drawDomainTickBands(var3, var4, var5);
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var11 = var10.brighter();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.awt.Stroke var14 = var12.getRangeCrosshairStroke();
//     java.awt.Font var16 = null;
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20, 0.5f, 1, var23);
//     int var25 = var20.getGreen();
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var14, (java.awt.Paint)var20, var26, 1.0f);
//     org.jfree.chart.util.Layer var29 = null;
//     boolean var30 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var28, var29);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var0.drawBackground(var7, var8);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleAnchor.TOP_LEFT", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.RangeType var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var23 = var21.getLabelAnchor();
    org.jfree.chart.text.TextAnchor var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelTextAnchor(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.drawBackground(var2, var3);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var1.removeLegend();
//     int var3 = var1.getBackgroundImageAlignment();
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     var1.handleClick(100, 0, var6);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.awt.Paint var35 = null;
//     var33.setOutlinePaint(var35);
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var33, var37);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)1, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var2, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 1.0d);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var7 = var0.getDataset();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var12 = var11.brighter();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var14 = var13.getDomainTickBandPaint();
    java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
    java.awt.Font var17 = null;
    java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var21 = var20.brighter();
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
    int var26 = var21.getGreen();
    java.awt.Stroke var27 = null;
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
    java.awt.Paint var31 = null;
    var29.setOutlinePaint(var31);
    org.jfree.chart.util.Layer var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var29, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var3 = var2.getBaseSectionOutlinePaint();
    var2.setInteriorGap(0.0d);
    java.awt.Paint var6 = var2.getLabelShadowPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("", var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var3 = var2.brighter();
    int var4 = var3.getTransparency();
    float[] var6 = new float[] { (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBColorComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    var3.removeLegend();
    int var5 = var3.getBackgroundImageAlignment();
    boolean var6 = var3.isBorderVisible();
    boolean var7 = var3.isBorderVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleAnchor.TOP_LEFT");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleAnchor var9 = null;
//     java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
//     var3.zoomDomainAxes(0.0d, 10.0d, var7, var10);
//     org.jfree.chart.plot.PlotState var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var0.draw(var1, var2, var10, var12, var13);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleAnchor.TOP_LEFT", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     java.awt.Stroke var7 = var0.getOutlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var11 = var10.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
//     var10.zoomDomainAxes(0.0d, 10.0d, var14, var17);
//     var0.zoomRangeAxes(4.0d, var9, var17, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var7 = var0.getDataset();
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var15 = var14.getDomainTickBandPaint();
    java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
    java.awt.Font var18 = null;
    java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var22 = var21.brighter();
    org.jfree.chart.text.TextMeasurer var25 = null;
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
    int var27 = var22.getGreen();
    java.awt.Stroke var28 = null;
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
    org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
    java.awt.Paint var32 = null;
    var30.setOutlinePaint(var32);
    org.jfree.chart.util.Layer var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, (org.jfree.chart.plot.Marker)var30, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var27 = var26.getLegendItems();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getDomainTickBandPaint();
//     java.awt.Stroke var30 = var28.getRangeCrosshairStroke();
//     var26.setOutlineStroke(var30);
//     var26.setLabelGap(100.0d);
//     var21.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
//     java.awt.Color var6 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var0.setTickMarkPaint((java.awt.Paint)var6);
//     var0.centerRange(4.0d);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.axis.AxisState var16 = var0.draw(var10, Double.NEGATIVE_INFINITY, var12, var13, var14, var15);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var2 = var0.createInsetRectangle(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleAnchor.TOP_LEFT", var1);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var2 = var1.getTickLabelFont();
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var5 = var4.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var7.removeLegend();
//     boolean var9 = var7.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var11 = var10.getBaseSectionOutlinePaint();
//     var7.setBackgroundPaint(var11);
//     boolean var13 = var4.equals((java.lang.Object)var7);
//     java.awt.Color var16 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var4.setLabelPaint((java.awt.Paint)var16);
//     org.jfree.chart.text.TextMeasurer var20 = null;
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var2, (java.awt.Paint)var16, 1.0f, 0, var20);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var3.createInsetRectangle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Stroke var2 = var0.getDomainGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var4 = var0.getQuadrantPaint(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.util.RectangleEdge var6 = null;
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var10 = var9.getDomainTickBandPaint();
    java.lang.Object var11 = var9.clone();
    var9.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var14 = var9.getAxisOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1, (java.awt.Paint)var4, var6, var7, var8, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var0.handleClick(100, (-1), var13);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    double var2 = var0.getFixedAutoRange();
    var0.setAutoTickUnitSelection(true, true);
    org.jfree.chart.axis.NumberTickUnit var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var6, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.TOP_LEFT", var1, 0.0d, 100.0f, (-1.0f));
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataExtractOrder(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setDomainAxis(var4);
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    java.awt.Stroke var7 = var0.getOutlineStroke();
    org.jfree.chart.plot.PlotOrientation var8 = var0.getOrientation();
    org.jfree.chart.plot.SeriesRenderingOrder var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 0.05d);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    float var8 = var7.getBackgroundImageAlpha();
    java.awt.Paint var9 = var7.getAggregatedItemsPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var1.getCategoryJava2DCoordinate(var3, 255, (-1), var6, var7);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     boolean var10 = var0.isDomainGridlinesVisible();
//     boolean var11 = var0.isRangeCrosshairLockedOnData();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.awt.Paint var35 = null;
//     var33.setOutlinePaint(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var33.getLabelOffset();
//     var33.setAlpha(0.5f);
//     org.jfree.chart.util.Layer var40 = null;
//     boolean var41 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var33, var40);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var2 = var1.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     var4.removeLegend();
//     boolean var6 = var4.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
//     var4.setBackgroundPaint(var8);
//     boolean var10 = var1.equals((java.lang.Object)var4);
//     java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var1.setLabelPaint((java.awt.Paint)var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisState var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     java.util.List var19 = var1.refreshTicks(var15, var16, var17, var18);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var5 = var4.brighter();
//     var1.setAxisLinePaint((java.awt.Paint)var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var1.draw(var7, (-1.0d), var9, var10, var11, var12);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var2 = var1.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var1.getCategoryJava2DCoordinate(var3, (-1), 10, var6, var7);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
//     int var3 = var1.indexOf((java.lang.Object)15);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.lang.Object var7 = var5.clone();
//     var5.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var10 = var5.getAxisOffset();
//     boolean var11 = var5.isRangeZeroBaselineVisible();
//     var5.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.Plot var15 = var5.getRootPlot();
//     var1.set(255, (java.lang.Object)var5);
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.lang.Object var22 = var20.clone();
//     var20.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var25 = var20.getAxisOffset();
//     boolean var26 = var20.isRangeZeroBaselineVisible();
//     var20.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var30 = var20.getQuadrantOrigin();
//     var5.zoomRangeAxes(4.0d, (-1.0d), var19, var30);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var5.setRenderer(255, var7);
//     org.jfree.chart.LegendItemCollection var9 = var5.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
//     var0.setRangeAxisLocation(100, var10);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.awt.Stroke var14 = var12.getRangeCrosshairStroke();
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var12);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3, true);
//     var0.setRangeGridlinesVisible(true);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     var29.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var33 = var29.getLabelOffsetType();
//     org.jfree.chart.util.Layer var34 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var29, var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.Plot var10 = var0.getRootPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var12 = var0.getQuadrantPaint(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { Double.NEGATIVE_INFINITY};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
    org.jfree.data.RangeType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    int var3 = var1.indexOf((java.lang.Object)15);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.lang.Object var7 = var5.clone();
    var5.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var10 = var5.getAxisOffset();
    boolean var11 = var5.isRangeZeroBaselineVisible();
    var5.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.Plot var15 = var5.getRootPlot();
    var1.set(255, (java.lang.Object)var5);
    java.awt.Image var17 = null;
    var5.setBackgroundImage(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var1.setLabelPaint((java.awt.Paint)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var19 = var18.brighter();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var21 = var20.getDomainTickBandPaint();
    java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
    java.awt.Font var24 = null;
    java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var28 = var27.brighter();
    org.jfree.chart.text.TextMeasurer var31 = null;
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
    int var33 = var28.getGreen();
    java.awt.Stroke var34 = null;
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
    org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
    java.awt.Paint var38 = null;
    var36.setOutlinePaint(var38);
    org.jfree.chart.util.RectangleInsets var40 = var36.getLabelOffset();
    var1.setLabelInsets(var40);
    java.awt.geom.Rectangle2D var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var43 = var40.createInsetRectangle(var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var1 = var0.getRight();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var0.createOutsetRectangle(var2, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    float[] var22 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var23 = var3.getRGBComponents(var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    var0.setTickMarksVisible(false);
    java.awt.Stroke var4 = var0.getAxisLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize((-1.0d), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var28 = var27.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("hi!", var28);
//     var21.setLabelFont(var28);
//     java.lang.Class var31 = null;
//     java.util.EventListener[] var32 = var21.getListeners(var31);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    float[] var4 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(10, 0, (-1), var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Rotation.CLOCKWISE", var1, 0.0f, (-1.0f), var4, 10.0d, (-1.0f), 0.0f);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.lang.Class var23 = null;
//     java.util.EventListener[] var24 = var21.getListeners(var23);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    var1.setToolTipText("Rotation.CLOCKWISE");
    java.awt.Graphics2D var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var1.arrange(var4, var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(byte)0);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    java.awt.Paint var23 = null;
    var21.setOutlinePaint(var23);
    org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var28 = var27.getTickLabelFont();
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("hi!", var28);
    var21.setLabelFont(var28);
    java.lang.Object var31 = var21.clone();
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelPaint(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var5.createOutsetRectangle(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var7 = var6.brighter();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var7);
    float[] var9 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var10 = var7.getRGBColorComponents(var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3);
//     org.jfree.chart.block.LengthConstraintType var5 = var4.getWidthConstraintType();
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var9);
//     org.jfree.chart.block.LengthConstraintType var11 = var10.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1, var5, 0.0d, var7, var11);
//     org.jfree.chart.plot.MultiplePiePlot var13 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     boolean var15 = var11.equals((java.lang.Object)var13);
//     java.lang.String var16 = var13.getPlotType();
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var20 = var19.getDomainTickBandPaint();
//     java.lang.Object var21 = var19.clone();
//     var19.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var24 = var19.getAxisOffset();
//     boolean var25 = var19.isRangeZeroBaselineVisible();
//     var19.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var29 = var19.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     var13.draw(var17, var18, var29, var30, var31);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var1, 100.0f, 100.0f, var4);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"Other", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var1.removeLegend();
    int var3 = var1.getBackgroundImageAlignment();
    boolean var4 = var1.isBorderVisible();
    int var5 = var1.getSubtitleCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var7 = var1.getSubtitle(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    java.util.List var3 = var0.getAnnotations();
    org.jfree.chart.axis.CategoryAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    org.jfree.data.general.PieDataset var4 = var0.getDataset();
    var0.setStartAngle(0.05d);
    java.lang.Comparable var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var8 = var0.getSectionOutlinePaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

//  public void test150() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == true);
//
//  }
//
  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
//     java.awt.Color var6 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var0.setTickMarkPaint((java.awt.Paint)var6);
//     java.awt.color.ColorSpace var8 = null;
//     float[] var9 = new float[] { };
//     float[] var10 = var6.getColorComponents(var8, var9);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     float var1 = var0.getBackgroundImageAlpha();
//     java.awt.Paint var2 = var0.getAggregatedItemsPaint();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setAnchorValue(1.0d);
//     var5.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
//     var12.zoomDomainAxes(0.0d, 10.0d, var16, var19);
//     var5.zoomRangeAxes(0.05d, 0.0d, var11, var19);
//     org.jfree.chart.plot.PlotState var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var0.draw(var3, var4, var19, var22, var23);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 10.0f, (-1.0f), var4, 0.0d, var6);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    var1.setAxisLinePaint((java.awt.Paint)var5);
    org.jfree.chart.axis.CategoryLabelPositions var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3, true);
//     var0.setRangeGridlinesVisible(true);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var29);
//     java.awt.Paint var31 = var29.getPaint();
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var38 = var37.brighter();
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var40 = var39.getDomainTickBandPaint();
//     java.awt.Stroke var41 = var39.getRangeCrosshairStroke();
//     java.awt.Font var43 = null;
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var47 = var46.brighter();
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, 0.5f, 1, var50);
//     int var52 = var47.getGreen();
//     java.awt.Stroke var53 = null;
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var37, var41, (java.awt.Paint)var47, var53, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var56 = var55.getLabelAnchor();
//     java.awt.Paint var57 = null;
//     var55.setOutlinePaint(var57);
//     org.jfree.chart.util.RectangleInsets var59 = var55.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var61 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var62 = var61.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("hi!", var62);
//     var55.setLabelFont(var62);
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var66 = var65.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var67 = var65.getRangeAxis();
//     java.lang.Object var68 = var65.clone();
//     var65.setDomainZeroBaselineVisible(true);
//     java.awt.Color var73 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var74 = var73.brighter();
//     var65.setDomainCrosshairPaint((java.awt.Paint)var73);
//     var65.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.JFreeChart var79 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var62, (org.jfree.chart.plot.Plot)var65, false);
//     java.awt.Color var86 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var87 = var86.brighter();
//     org.jfree.chart.block.BlockBorder var88 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var87);
//     org.jfree.chart.text.TextLine var89 = new org.jfree.chart.text.TextLine("hi!", var62, (java.awt.Paint)var87);
//     var29.setLabelFont(var62);
//     
//     // Checks the contract:  equals-hashcode on var13 and var39
//     assertTrue("Contract failed: equals-hashcode on var13 and var39", var13.equals(var39) ? var13.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var13
//     assertTrue("Contract failed: equals-hashcode on var39 and var13", var39.equals(var13) ? var39.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 0.5f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-127));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var4 = var2.getSectionPaint((java.lang.Comparable)(short)(-1));
    boolean var5 = var0.hasListener((java.util.EventListener)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(4.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var3 = var1.getPieLabelRecord(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getDomainTickBandPaint();
//     java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
//     var0.setOutlineStroke(var4);
//     var0.setLabelGap(100.0d);
//     java.awt.Paint var8 = var0.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var11 = var9.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getRangeAxis();
//     org.jfree.chart.event.PlotChangeEvent var18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
//     boolean var19 = var12.equals((java.lang.Object)var18);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     var0.setRangeCrosshairValue((-1.0d), false);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var9 = var8.getDomainTickBandPaint();
//     java.lang.Object var10 = var8.clone();
//     var8.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var13 = var8.getAxisOffset();
//     boolean var14 = var8.isRangeZeroBaselineVisible();
//     java.awt.Stroke var15 = var8.getOutlineStroke();
//     var0.setRangeZeroBaselineStroke(var15);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     var1.setInteriorGap(0.0d);
//     boolean var5 = var0.equals((java.lang.Object)0.0d);
//     boolean var7 = var0.equals((java.lang.Object)1.0d);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
//     double var10 = var9.getRight();
//     org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var22 = var21.getDomainTickBandPaint();
//     java.awt.Stroke var23 = var21.getRangeCrosshairStroke();
//     java.awt.Font var25 = null;
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     org.jfree.chart.text.TextMeasurer var32 = null;
//     org.jfree.chart.text.TextBlock var33 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var29, 0.5f, 1, var32);
//     int var34 = var29.getGreen();
//     java.awt.Stroke var35 = null;
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var23, (java.awt.Paint)var29, var35, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var38 = var37.getLabelAnchor();
//     java.lang.String var39 = var38.toString();
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var38);
//     java.awt.geom.Rectangle2D var41 = var9.createInsetRectangle(var40);
//     var0.draw(var8, var41);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    var1.setLabel("");
    double var5 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.clearCategoryLabelToolTips();
//     var1.setLabelToolTip("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.lang.String var5 = var1.getLabelURL();
//     var1.setTickLabelsVisible(false);
//     org.jfree.chart.axis.CategoryAnchor var8 = null;
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets();
//     double var12 = var11.getRight();
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.awt.Stroke var25 = var23.getRangeCrosshairStroke();
//     java.awt.Font var27 = null;
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var31 = var30.brighter();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var31, 0.5f, 1, var34);
//     int var36 = var31.getGreen();
//     java.awt.Stroke var37 = null;
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var25, (java.awt.Paint)var31, var37, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var40 = var39.getLabelAnchor();
//     java.lang.String var41 = var40.toString();
//     java.awt.geom.Rectangle2D var42 = org.jfree.chart.util.RectangleAnchor.createRectangle(var15, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var40);
//     java.awt.geom.Rectangle2D var43 = var11.createInsetRectangle(var42);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var45 = var44.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var46 = var44.getRangeAxis();
//     java.lang.Object var47 = var44.clone();
//     var44.setDomainZeroBaselineVisible(true);
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var53 = var52.brighter();
//     var44.setDomainCrosshairPaint((java.awt.Paint)var52);
//     org.jfree.chart.util.RectangleEdge var55 = var44.getDomainAxisEdge();
//     boolean var56 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var55);
//     double var57 = var1.getCategoryJava2DCoordinate(var8, 15, 0, var43, var55);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var9 = var8.brighter();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getInsets();
    var1.setMargin(var11);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
//     var1.setToolTipText("Rotation.CLOCKWISE");
//     double var4 = var1.getWidth();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var9 = var8.getDomainTickBandPaint();
//     java.awt.Stroke var10 = var8.getRangeCrosshairStroke();
//     var6.setOutlineStroke(var10);
//     var6.setLabelGap(100.0d);
//     java.awt.Paint var14 = var6.getLabelLinkPaint();
//     var5.setRangeGridlinePaint(var14);
//     boolean var16 = var1.equals((java.lang.Object)var5);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets();
//     double var19 = var18.getRight();
//     org.jfree.chart.util.Size2D var22 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var31 = var30.getDomainTickBandPaint();
//     java.awt.Stroke var32 = var30.getRangeCrosshairStroke();
//     java.awt.Font var34 = null;
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var38 = var37.brighter();
//     org.jfree.chart.text.TextMeasurer var41 = null;
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, (java.awt.Paint)var38, 0.5f, 1, var41);
//     int var43 = var38.getGreen();
//     java.awt.Stroke var44 = null;
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var28, var32, (java.awt.Paint)var38, var44, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var47 = var46.getLabelAnchor();
//     java.lang.String var48 = var47.toString();
//     java.awt.geom.Rectangle2D var49 = org.jfree.chart.util.RectangleAnchor.createRectangle(var22, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var47);
//     java.awt.geom.Rectangle2D var50 = var18.createInsetRectangle(var49);
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var52 = var51.getDomainTickBandPaint();
//     java.lang.Object var53 = var51.clone();
//     java.lang.Object var54 = var1.draw(var17, var49, var53);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var51
//     assertTrue("Contract failed: equals-hashcode on var8 and var51", var8.equals(var51) ? var8.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var51
//     assertTrue("Contract failed: equals-hashcode on var30 and var51", var30.equals(var51) ? var30.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var8
//     assertTrue("Contract failed: equals-hashcode on var51 and var8", var51.equals(var8) ? var51.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var30
//     assertTrue("Contract failed: equals-hashcode on var51 and var30", var51.equals(var30) ? var51.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.ChartProgressListener var2 = null;
//     var1.removeProgressListener(var2);
//     org.jfree.chart.event.TitleChangeEvent var4 = null;
//     var1.titleChanged(var4);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Stroke var2 = var0.getDomainGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     var3.setRenderer(255, var5);
//     org.jfree.chart.LegendItemCollection var7 = var3.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var9 = var3.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var11 = var10.getDomainTickBandPaint();
//     java.lang.Object var12 = var10.clone();
//     var10.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var15 = var10.getAxisOffset();
//     boolean var16 = var10.isRangeZeroBaselineVisible();
//     java.awt.Stroke var17 = var10.getOutlineStroke();
//     org.jfree.chart.plot.PlotOrientation var18 = var10.getOrientation();
//     java.lang.Object var19 = null;
//     boolean var20 = var18.equals(var19);
//     org.jfree.chart.util.RectangleEdge var21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var9, var18);
//     var0.setOrientation(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var2 = var1.getTickMarkStroke();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
//     double var6 = var5.getRight();
//     org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.lang.String var35 = var34.toString();
//     java.awt.geom.Rectangle2D var36 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var34);
//     java.awt.geom.Rectangle2D var37 = var5.createInsetRectangle(var36);
//     org.jfree.chart.util.Size2D var40 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var47 = var46.brighter();
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var49 = var48.getDomainTickBandPaint();
//     java.awt.Stroke var50 = var48.getRangeCrosshairStroke();
//     java.awt.Font var52 = null;
//     java.awt.Color var55 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var56 = var55.brighter();
//     org.jfree.chart.text.TextMeasurer var59 = null;
//     org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, (java.awt.Paint)var56, 0.5f, 1, var59);
//     int var61 = var56.getGreen();
//     java.awt.Stroke var62 = null;
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var46, var50, (java.awt.Paint)var56, var62, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var65 = var64.getLabelAnchor();
//     java.lang.String var66 = var65.toString();
//     java.awt.geom.Rectangle2D var67 = org.jfree.chart.util.RectangleAnchor.createRectangle(var40, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var65);
//     org.jfree.chart.ui.ProjectInfo var68 = new org.jfree.chart.ui.ProjectInfo();
//     java.lang.String var69 = var68.getLicenceText();
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     var70.setRenderer(255, var72);
//     org.jfree.chart.LegendItemCollection var74 = var70.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var76 = var70.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var78 = var77.getDomainTickBandPaint();
//     java.lang.Object var79 = var77.clone();
//     var77.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var82 = var77.getAxisOffset();
//     boolean var83 = var77.isRangeZeroBaselineVisible();
//     java.awt.Stroke var84 = var77.getOutlineStroke();
//     org.jfree.chart.plot.PlotOrientation var85 = var77.getOrientation();
//     java.lang.Object var86 = null;
//     boolean var87 = var85.equals(var86);
//     org.jfree.chart.util.RectangleEdge var88 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var76, var85);
//     boolean var89 = var68.equals((java.lang.Object)var88);
//     org.jfree.chart.plot.PlotRenderingInfo var90 = null;
//     org.jfree.chart.axis.AxisState var91 = var1.draw(var3, 4.0d, var37, var67, var88, var90);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var5 = var3.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var6);
//     var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var6);
//     var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.AxisLocation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var4, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    var1.setLabelGap(100.0d);
    java.awt.Paint var9 = var1.getLabelLinkPaint();
    var0.setRangeGridlinePaint(var9);
    java.awt.Paint var11 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryMarker var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    boolean var2 = var0.getSectionOutlinesVisible();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    int var7 = var6.getTransparency();
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    float[] var11 = new float[] { 100.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var6.getRGBComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var1.setNotify(false);
    org.jfree.chart.ChartRenderingInfo var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var1.createBufferedImage(100, 10, (-127), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     boolean var7 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.event.RendererChangeEvent var8 = null;
//     var0.rendererChanged(var8);
//     boolean var10 = var0.isDomainGridlinesVisible();
//     boolean var11 = var0.isRangeCrosshairVisible();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
//     double var14 = var13.getRight();
//     org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getDomainTickBandPaint();
//     java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
//     java.awt.Font var29 = null;
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var33 = var32.brighter();
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, (java.awt.Paint)var33, 0.5f, 1, var36);
//     int var38 = var33.getGreen();
//     java.awt.Stroke var39 = null;
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var23, var27, (java.awt.Paint)var33, var39, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var42 = var41.getLabelAnchor();
//     java.lang.String var43 = var42.toString();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var42);
//     java.awt.geom.Rectangle2D var45 = var13.createInsetRectangle(var44);
//     var0.drawOutline(var12, var44);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     var8.setRenderer(255, var10);
//     org.jfree.chart.LegendItemCollection var12 = var8.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var13 = var8.getDomainAxisLocation();
//     var0.setRangeAxisLocation(0, var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var8 = var7.getDomainTickBandPaint();
    java.awt.Stroke var9 = var7.getRangeCrosshairStroke();
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 0.5f, 1, var18);
    int var20 = var15.getGreen();
    java.awt.Stroke var21 = null;
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var5, var9, (java.awt.Paint)var15, var21, 1.0f);
    org.jfree.chart.util.RectangleAnchor var24 = var23.getLabelAnchor();
    java.awt.Paint var25 = null;
    var23.setOutlinePaint(var25);
    org.jfree.chart.util.RectangleInsets var27 = var23.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var30 = var29.getTickLabelFont();
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("hi!", var30);
    var23.setLabelFont(var30);
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var34 = var33.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var35 = var33.getRangeAxis();
    java.lang.Object var36 = var33.clone();
    var33.setDomainZeroBaselineVisible(true);
    java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var42 = var41.brighter();
    var33.setDomainCrosshairPaint((java.awt.Paint)var41);
    var33.setRangeCrosshairValue(1.0d);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var30, (org.jfree.chart.plot.Plot)var33, false);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var49 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var50 = var49.getLegendItems();
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var52 = var51.getDomainTickBandPaint();
    java.awt.Stroke var53 = var51.getRangeCrosshairStroke();
    var49.setOutlineStroke(var53);
    var49.setLabelGap(100.0d);
    java.awt.Paint var57 = var49.getLabelLinkPaint();
    var48.setRangeGridlinePaint(var57);
    java.awt.Paint var59 = var48.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var60 = null;
    org.jfree.chart.util.HorizontalAlignment var61 = null;
    org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var64 = var63.getVerticalAlignment();
    java.awt.Color var71 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var72 = var71.brighter();
    org.jfree.chart.block.BlockBorder var73 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var72);
    org.jfree.chart.util.RectangleInsets var74 = var73.getInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var75 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE", var30, var59, var60, var61, var64, var74);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var9 = var8.getTickMarkStroke();
//     java.awt.Font var11 = var8.getTickLabelFont((java.lang.Comparable)100.0f);
//     org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets();
//     double var15 = var14.getRight();
//     org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var27 = var26.getDomainTickBandPaint();
//     java.awt.Stroke var28 = var26.getRangeCrosshairStroke();
//     java.awt.Font var30 = null;
//     java.awt.Color var33 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var34 = var33.brighter();
//     org.jfree.chart.text.TextMeasurer var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34, 0.5f, 1, var37);
//     int var39 = var34.getGreen();
//     java.awt.Stroke var40 = null;
//     org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var24, var28, (java.awt.Paint)var34, var40, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var43 = var42.getLabelAnchor();
//     java.lang.String var44 = var43.toString();
//     java.awt.geom.Rectangle2D var45 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var43);
//     java.awt.geom.Rectangle2D var46 = var14.createInsetRectangle(var45);
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var48 = var47.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var49 = var47.getRangeAxis();
//     java.lang.Object var50 = var47.clone();
//     var47.setDomainZeroBaselineVisible(true);
//     java.awt.Color var55 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var56 = var55.brighter();
//     var47.setDomainCrosshairPaint((java.awt.Paint)var55);
//     org.jfree.chart.util.RectangleEdge var58 = var47.getDomainAxisEdge();
//     double var59 = var8.getCategoryStart(1, (-1), var46, var58);
//     org.jfree.chart.ui.ProjectInfo var60 = new org.jfree.chart.ui.ProjectInfo();
//     java.lang.String var61 = var60.getLicenceText();
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     var62.setRenderer(255, var64);
//     org.jfree.chart.LegendItemCollection var66 = var62.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var68 = var62.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var70 = var69.getDomainTickBandPaint();
//     java.lang.Object var71 = var69.clone();
//     var69.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var74 = var69.getAxisOffset();
//     boolean var75 = var69.isRangeZeroBaselineVisible();
//     java.awt.Stroke var76 = var69.getOutlineStroke();
//     org.jfree.chart.plot.PlotOrientation var77 = var69.getOrientation();
//     java.lang.Object var78 = null;
//     boolean var79 = var77.equals(var78);
//     org.jfree.chart.util.RectangleEdge var80 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var68, var77);
//     boolean var81 = var60.equals((java.lang.Object)var80);
//     org.jfree.chart.plot.PlotRenderingInfo var82 = null;
//     org.jfree.chart.axis.AxisState var83 = var0.draw(var4, 0.0d, var6, var46, var80, var82);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Other", var3);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
//     org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getDomainTickBandPaint();
//     java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
//     java.awt.Font var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
//     int var27 = var22.getGreen();
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     java.lang.String var32 = var31.toString();
//     java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var6, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var31);
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var38 = var37.brighter();
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var40 = var39.getDomainTickBandPaint();
//     java.awt.Stroke var41 = var39.getRangeCrosshairStroke();
//     java.awt.Font var43 = null;
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var47 = var46.brighter();
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, 0.5f, 1, var50);
//     int var52 = var47.getGreen();
//     java.awt.Stroke var53 = null;
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var37, var41, (java.awt.Paint)var47, var53, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var56 = var55.getLabelAnchor();
//     var55.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var59 = var55.getLabelOffsetType();
//     java.awt.Color var63 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var64 = var63.brighter();
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var66 = var65.getDomainTickBandPaint();
//     java.awt.Stroke var67 = var65.getRangeCrosshairStroke();
//     java.awt.Font var69 = null;
//     java.awt.Color var72 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var73 = var72.brighter();
//     org.jfree.chart.text.TextMeasurer var76 = null;
//     org.jfree.chart.text.TextBlock var77 = org.jfree.chart.text.TextUtilities.createTextBlock("", var69, (java.awt.Paint)var73, 0.5f, 1, var76);
//     int var78 = var73.getGreen();
//     java.awt.Stroke var79 = null;
//     org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var63, var67, (java.awt.Paint)var73, var79, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var82 = var81.getLabelAnchor();
//     var81.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var85 = var81.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var86 = var3.createAdjustedRectangle(var33, var59, var85);
//     
//     // Checks the contract:  equals-hashcode on var14 and var39
//     assertTrue("Contract failed: equals-hashcode on var14 and var39", var14.equals(var39) ? var14.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var65
//     assertTrue("Contract failed: equals-hashcode on var14 and var65", var14.equals(var65) ? var14.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var14
//     assertTrue("Contract failed: equals-hashcode on var39 and var14", var39.equals(var14) ? var39.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var65
//     assertTrue("Contract failed: equals-hashcode on var39 and var65", var39.equals(var65) ? var39.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var14
//     assertTrue("Contract failed: equals-hashcode on var65 and var14", var65.equals(var14) ? var65.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var39
//     assertTrue("Contract failed: equals-hashcode on var65 and var39", var65.equals(var39) ? var65.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var81
//     assertTrue("Contract failed: equals-hashcode on var55 and var81", var55.equals(var81) ? var55.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var55
//     assertTrue("Contract failed: equals-hashcode on var81 and var55", var81.equals(var55) ? var81.hashCode() == var55.hashCode() : true);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.awt.Stroke var2 = var0.getRangeCrosshairStroke();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var8 = var7.brighter();
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var10 = var9.getDomainTickBandPaint();
    java.awt.Stroke var11 = var9.getRangeCrosshairStroke();
    java.awt.Font var13 = null;
    java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var17 = var16.brighter();
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var17, 0.5f, 1, var20);
    int var22 = var17.getGreen();
    java.awt.Stroke var23 = null;
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var7, var11, (java.awt.Paint)var17, var23, 1.0f);
    org.jfree.chart.util.RectangleAnchor var26 = var25.getLabelAnchor();
    java.awt.Paint var27 = null;
    var25.setOutlinePaint(var27);
    org.jfree.chart.util.RectangleInsets var29 = var25.getLabelOffset();
    var25.setValue(10.0d);
    org.jfree.chart.util.Layer var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, (org.jfree.chart.plot.Marker)var25, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Other", var1, 0.0f, 0.0f, 0.025d, 0.0f, 10.0f);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var6 = var5.brighter();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getDomainTickBandPaint();
//     java.awt.Stroke var9 = var7.getRangeCrosshairStroke();
//     java.awt.Font var11 = null;
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 0.5f, 1, var18);
//     int var20 = var15.getGreen();
//     java.awt.Stroke var21 = null;
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var5, var9, (java.awt.Paint)var15, var21, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var24 = var23.getLabelAnchor();
//     java.awt.Paint var25 = null;
//     var23.setOutlinePaint(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var23.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var30 = var29.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("hi!", var30);
//     var23.setLabelFont(var30);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var34 = var33.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var35 = var33.getRangeAxis();
//     java.lang.Object var36 = var33.clone();
//     var33.setDomainZeroBaselineVisible(true);
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var42 = var41.brighter();
//     var33.setDomainCrosshairPaint((java.awt.Paint)var41);
//     var33.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var30, (org.jfree.chart.plot.Plot)var33, false);
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var55 = var54.brighter();
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var55);
//     org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("hi!", var30, (java.awt.Paint)var55);
//     java.awt.Graphics2D var58 = null;
//     org.jfree.chart.text.TextAnchor var61 = null;
//     var57.draw(var58, 10.0f, 0.0f, var61, 100.0f, 100.0f, (-1.0d));
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselinePaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     var20.setRangeAxis(var23);
//     org.jfree.chart.axis.AxisLocation var26 = var20.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var20.setRenderer(var27, false);
//     var20.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement();
//     var31.clear();
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.FlowArrangement var37 = new org.jfree.chart.block.FlowArrangement(var33, var34, 0.0d, 100.0d);
//     var37.clear();
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var37);
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var44 = var43.brighter();
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var46 = var45.getDomainTickBandPaint();
//     java.awt.Stroke var47 = var45.getRangeCrosshairStroke();
//     java.awt.Font var49 = null;
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var53 = var52.brighter();
//     org.jfree.chart.text.TextMeasurer var56 = null;
//     org.jfree.chart.text.TextBlock var57 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, (java.awt.Paint)var53, 0.5f, 1, var56);
//     int var58 = var53.getGreen();
//     java.awt.Stroke var59 = null;
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var43, var47, (java.awt.Paint)var53, var59, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var62 = var61.getLabelAnchor();
//     boolean var64 = var62.equals((java.lang.Object)100.0f);
//     var39.setLegendItemGraphicLocation(var62);
//     var19.setLegendItemGraphicLocation(var62);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var31
//     assertTrue("Contract failed: equals-hashcode on var11 and var31", var11.equals(var31) ? var11.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var37
//     assertTrue("Contract failed: equals-hashcode on var17 and var37", var17.equals(var37) ? var17.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var11
//     assertTrue("Contract failed: equals-hashcode on var31 and var11", var31.equals(var11) ? var31.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var17
//     assertTrue("Contract failed: equals-hashcode on var37 and var17", var37.equals(var17) ? var37.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.5f, 1, var8);
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setLineAlignment(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var2 = var1.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!", var2);
//     org.jfree.data.Range var5 = null;
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var5);
//     double var7 = var6.getHeight();
//     boolean var8 = var3.equals((java.lang.Object)var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextAnchor var12 = null;
//     var3.draw(var9, 0.5f, 0.5f, var12, 0.5f, 0.5f, 1.0d);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleAnchor.TOP_LEFT", var1);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("Range[-1.0,0.0]", "Other");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
//     boolean var12 = var0.isRangeGridlinesVisible();
//     java.awt.Stroke var13 = var0.getOutlineStroke();
//     org.jfree.chart.plot.Marker var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var0.removeDomainMarker(var14, var15);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getDomainTickBandPaint();
//     java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
//     var0.setOutlineStroke(var4);
//     var0.setLabelGap(100.0d);
//     org.jfree.chart.util.RectangleInsets var8 = var0.getSimpleLabelOffset();
//     java.awt.Image var9 = var0.getBackgroundImage();
//     java.awt.Shape var10 = var0.getLegendItemShape();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.lang.Object var14 = var12.clone();
//     var12.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var17 = var12.getAxisOffset();
//     boolean var18 = var12.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var19 = var12.getDataset();
//     org.jfree.chart.axis.ValueAxis var21 = var12.getRangeAxisForDataset(0);
//     var12.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var25.setRenderer(255, var27);
//     org.jfree.chart.LegendItemCollection var29 = var25.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var31 = var25.getDomainAxisLocation(100);
//     var12.setDomainAxisLocation(100, var31, false);
//     boolean var34 = var11.equals((java.lang.Object)100);
//     var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var11);
//     
//     // Checks the contract:  equals-hashcode on var1 and var29
//     assertTrue("Contract failed: equals-hashcode on var1 and var29", var1.equals(var29) ? var1.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var1
//     assertTrue("Contract failed: equals-hashcode on var29 and var1", var29.equals(var1) ? var29.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 0.025d, 1, (java.lang.Comparable)"Range[-1.0,0.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    var0.setSimpleLabels(false);
    var0.setBackgroundImageAlpha(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInteriorGap(10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var2 = var1.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     var4.removeLegend();
//     boolean var6 = var4.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
//     var4.setBackgroundPaint(var8);
//     boolean var10 = var1.equals((java.lang.Object)var4);
//     java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var1.setLabelPaint((java.awt.Paint)var13);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var19 = var18.brighter();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
//     java.awt.Font var24 = null;
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var28 = var27.brighter();
//     org.jfree.chart.text.TextMeasurer var31 = null;
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
//     int var33 = var28.getGreen();
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
//     java.awt.Paint var38 = null;
//     var36.setOutlinePaint(var38);
//     org.jfree.chart.util.RectangleInsets var40 = var36.getLabelOffset();
//     var1.setLabelInsets(var40);
//     org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets();
//     double var43 = var42.getRight();
//     org.jfree.chart.util.Size2D var46 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var53 = var52.brighter();
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var55 = var54.getDomainTickBandPaint();
//     java.awt.Stroke var56 = var54.getRangeCrosshairStroke();
//     java.awt.Font var58 = null;
//     java.awt.Color var61 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var62 = var61.brighter();
//     org.jfree.chart.text.TextMeasurer var65 = null;
//     org.jfree.chart.text.TextBlock var66 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, (java.awt.Paint)var62, 0.5f, 1, var65);
//     int var67 = var62.getGreen();
//     java.awt.Stroke var68 = null;
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var52, var56, (java.awt.Paint)var62, var68, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var71 = var70.getLabelAnchor();
//     java.lang.String var72 = var71.toString();
//     java.awt.geom.Rectangle2D var73 = org.jfree.chart.util.RectangleAnchor.createRectangle(var46, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var71);
//     java.awt.geom.Rectangle2D var74 = var42.createInsetRectangle(var73);
//     java.awt.geom.Rectangle2D var77 = var40.createOutsetRectangle(var73, false, true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var54
//     assertTrue("Contract failed: equals-hashcode on var20 and var54", var20.equals(var54) ? var20.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var20
//     assertTrue("Contract failed: equals-hashcode on var54 and var20", var54.equals(var20) ? var54.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     var33.setValue(0.0d);
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var33, var37);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var2 = var1.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!", var2);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var5 = var4.getTickLabelFont();
//     double var6 = var4.getFixedAutoRange();
//     var4.setAutoTickUnitSelection(true, true);
//     boolean var10 = var3.equals((java.lang.Object)var4);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     var11.setRenderer(255, var13);
//     org.jfree.chart.LegendItemCollection var15 = var11.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var17 = var11.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getDomainTickBandPaint();
//     java.lang.Object var20 = var18.clone();
//     var18.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var23 = var18.getAxisOffset();
//     boolean var24 = var18.isRangeZeroBaselineVisible();
//     java.awt.Stroke var25 = var18.getOutlineStroke();
//     org.jfree.chart.plot.PlotOrientation var26 = var18.getOrientation();
//     java.lang.Object var27 = null;
//     boolean var28 = var26.equals(var27);
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var17, var26);
//     boolean var30 = var3.equals((java.lang.Object)var26);
//     java.awt.Font var31 = var3.getFont();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.util.Size2D var33 = var3.calculateDimensions(var32);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Paint var4 = var3.getTickMarkPaint();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var8 = var7.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("hi!", var8);
//     var3.setTickLabelFont((java.lang.Comparable)"hi!", var8);
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     var11.setOutlineStroke(var15);
//     var11.setLabelGap(100.0d);
//     java.awt.Paint var19 = var11.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var20.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     double var27 = var26.getFixedDimension();
//     java.lang.Object var28 = var26.clone();
//     org.jfree.chart.util.RectangleInsets var29 = var26.getLabelInsets();
//     java.awt.Color var32 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var26.setTickMarkPaint((java.awt.Paint)var32);
//     var11.setLabelShadowPaint((java.awt.Paint)var32);
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var8, (java.awt.Paint)var32);
//     java.awt.Paint var36 = null;
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.text.G2TextMeasurer var39 = new org.jfree.chart.text.G2TextMeasurer(var38);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var8, var36, (-1.0f), (org.jfree.chart.text.TextMeasurer)var39);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.util.List var5 = null;
//     var0.drawDomainTickBands(var3, var4, var5);
//     org.jfree.chart.axis.AxisSpace var7 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var8 = null;
//     var0.setRenderers(var8);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var6 = var5.getTickMarkStroke();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)100.0f);
//     org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets();
//     double var12 = var11.getRight();
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.awt.Stroke var25 = var23.getRangeCrosshairStroke();
//     java.awt.Font var27 = null;
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var31 = var30.brighter();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var31, 0.5f, 1, var34);
//     int var36 = var31.getGreen();
//     java.awt.Stroke var37 = null;
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var25, (java.awt.Paint)var31, var37, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var40 = var39.getLabelAnchor();
//     java.lang.String var41 = var40.toString();
//     java.awt.geom.Rectangle2D var42 = org.jfree.chart.util.RectangleAnchor.createRectangle(var15, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var40);
//     java.awt.geom.Rectangle2D var43 = var11.createInsetRectangle(var42);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var45 = var44.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var46 = var44.getRangeAxis();
//     java.lang.Object var47 = var44.clone();
//     var44.setDomainZeroBaselineVisible(true);
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var53 = var52.brighter();
//     var44.setDomainCrosshairPaint((java.awt.Paint)var52);
//     org.jfree.chart.util.RectangleEdge var55 = var44.getDomainAxisEdge();
//     double var56 = var5.getCategoryStart(1, (-1), var43, var55);
//     var0.drawBackground(var3, var43);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     var4.setRenderer(255, var6);
//     org.jfree.chart.LegendItemCollection var8 = var4.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
//     org.jfree.chart.util.SortOrder var10 = var4.getColumnRenderingOrder();
//     var0.setRowRenderingOrder(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,1.05]", "Rotation.CLOCKWISE", var3);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.ChartProgressListener var2 = null;
//     var1.removeProgressListener(var2);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     var1.handleClick(0, 10, var6);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("Range[-1.0,0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis();
//     var0.setRangeGridlinesVisible(false);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var19 = var18.brighter();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
//     java.awt.Font var24 = null;
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var28 = var27.brighter();
//     org.jfree.chart.text.TextMeasurer var31 = null;
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
//     int var33 = var28.getGreen();
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var36, var37);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getDomainTickBandPaint();
//     java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
//     var0.setOutlineStroke(var4);
//     org.jfree.chart.util.Rotation var6 = var0.getDirection();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
//     double var9 = var8.getRight();
//     org.jfree.chart.util.Size2D var12 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var19 = var18.brighter();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
//     java.awt.Font var24 = null;
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var28 = var27.brighter();
//     org.jfree.chart.text.TextMeasurer var31 = null;
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
//     int var33 = var28.getGreen();
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
//     java.lang.String var38 = var37.toString();
//     java.awt.geom.Rectangle2D var39 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var37);
//     java.awt.geom.Rectangle2D var40 = var8.createInsetRectangle(var39);
//     var0.drawOutline(var7, var39);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Stroke var2 = var0.getDomainGridlineStroke();
//     org.jfree.chart.plot.SeriesRenderingOrder var3 = var0.getSeriesRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.setAnchorValue(1.0d);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var4.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var29, var31);
//     org.jfree.chart.util.Layer var33 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var29, var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(-1L), var1, var2);
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.removeLegend();
    boolean var7 = var5.getAntiAlias();
    var3.setChart(var5);
    org.jfree.chart.JFreeChart var9 = var3.getChart();
    org.jfree.chart.event.ChartChangeEventType var10 = null;
    var3.setType(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var9 = var8.brighter();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var9);
    org.jfree.chart.util.RectangleInsets var11 = var10.getInsets();
    var1.setMargin(var11);
    java.awt.Paint var13 = var1.getBackgroundPaint();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.block.RectangleConstraint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var16 = var1.arrange(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis(10);
    org.jfree.data.category.CategoryDataset var10 = null;
    var0.setDataset(15, var10);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     double var5 = var4.getFixedDimension();
//     java.lang.Object var6 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getLabelInsets();
//     java.awt.Color var10 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var4.setTickMarkPaint((java.awt.Paint)var10);
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.lang.Object var14 = var12.clone();
//     var12.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var17 = var12.getAxisOffset();
//     boolean var18 = var12.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var19 = var12.getDataset();
//     java.awt.Paint var20 = var12.getRangeZeroBaselinePaint();
//     var4.setTickLabelPaint(var20);
//     var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var4);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.Size2D var26 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var33 = var32.brighter();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var35 = var34.getDomainTickBandPaint();
//     java.awt.Stroke var36 = var34.getRangeCrosshairStroke();
//     java.awt.Font var38 = null;
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var42 = var41.brighter();
//     org.jfree.chart.text.TextMeasurer var45 = null;
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var38, (java.awt.Paint)var42, 0.5f, 1, var45);
//     int var47 = var42.getGreen();
//     java.awt.Stroke var48 = null;
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var32, var36, (java.awt.Paint)var42, var48, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var51 = var50.getLabelAnchor();
//     java.lang.String var52 = var51.toString();
//     java.awt.geom.Rectangle2D var53 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var51);
//     java.awt.geom.Point2D var54 = null;
//     org.jfree.chart.plot.PlotState var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     var0.draw(var23, var53, var54, var55, var56);
//     
//     // Checks the contract:  equals-hashcode on var12 and var34
//     assertTrue("Contract failed: equals-hashcode on var12 and var34", var12.equals(var34) ? var12.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var12
//     assertTrue("Contract failed: equals-hashcode on var34 and var12", var34.equals(var12) ? var34.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var17 = var16.brighter();
//     var13.setAxisLinePaint((java.awt.Paint)var17);
//     var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var13);
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var22 = var20.getRangeAxis();
//     java.lang.Object var23 = var20.clone();
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var20.setDomainAxis(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     var20.setDataset(var26);
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     var20.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var29, true);
//     boolean var32 = var20.isRangeGridlinesVisible();
//     java.awt.Stroke var33 = var20.getOutlineStroke();
//     var0.setRangeGridlineStroke(var33);
//     
//     // Checks the contract:  equals-hashcode on var3 and var20
//     assertTrue("Contract failed: equals-hashcode on var3 and var20", var3.equals(var20) ? var3.hashCode() == var20.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var20.", var3.equals(var20) == var20.equals(var3));
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
//     boolean var2 = var0.getSectionOutlinesVisible();
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var6 = var5.brighter();
//     int var7 = var6.getTransparency();
//     var0.setBaseSectionOutlinePaint((java.awt.Paint)var6);
//     var0.setInteriorGap(0.0d);
//     java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var0.setBaseSectionPaint((java.awt.Paint)var13);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.lang.Object var17 = var15.clone();
//     var15.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var20 = var15.getAxisOffset();
//     boolean var21 = var15.isRangeZeroBaselineVisible();
//     java.awt.Stroke var22 = var15.getOutlineStroke();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.lang.Object var25 = var23.clone();
//     var23.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var28 = var23.getAxisOffset();
//     double var30 = var28.calculateBottomInset((-1.0d));
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var13, var22, var28);
//     
//     // Checks the contract:  equals-hashcode on var15 and var23
//     assertTrue("Contract failed: equals-hashcode on var15 and var23", var15.equals(var23) ? var15.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var15
//     assertTrue("Contract failed: equals-hashcode on var23 and var15", var23.equals(var15) ? var23.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var25
//     assertTrue("Contract failed: equals-hashcode on var17 and var25", var17.equals(var25) ? var17.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var17
//     assertTrue("Contract failed: equals-hashcode on var25 and var17", var25.equals(var17) ? var25.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.5f, 1, var8);
    int var10 = var5.getGreen();
    int var11 = var5.getRGB();
    float[] var12 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var13 = var5.getRGBComponents(var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    var2.setWidth(1.0d);
    java.lang.String var5 = var2.toString();
    var2.setHeight((-1.975d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Size2D[width=1.0, height=0.0]"+ "'", var5.equals("Size2D[width=1.0, height=0.0]"));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     java.awt.Stroke var7 = var0.getOutlineStroke();
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getDomainTickBandPaint();
//     java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
//     java.awt.Font var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
//     int var27 = var22.getGreen();
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     java.awt.Paint var32 = null;
//     var30.setOutlinePaint(var32);
//     org.jfree.chart.util.Layer var34 = null;
//     boolean var35 = var0.removeRangeMarker(15, (org.jfree.chart.plot.Marker)var30, var34);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    int var5 = var0.getIndexOf(var4);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var0.rendererChanged(var6);
    boolean var8 = var0.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var1.setLabelPaint((java.awt.Paint)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var19 = var18.brighter();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var21 = var20.getDomainTickBandPaint();
    java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
    java.awt.Font var24 = null;
    java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var28 = var27.brighter();
    org.jfree.chart.text.TextMeasurer var31 = null;
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
    int var33 = var28.getGreen();
    java.awt.Stroke var34 = null;
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
    org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
    java.awt.Paint var38 = null;
    var36.setOutlinePaint(var38);
    org.jfree.chart.util.RectangleInsets var40 = var36.getLabelOffset();
    var1.setLabelInsets(var40);
    java.awt.Paint var42 = var1.getTickLabelPaint();
    java.lang.Object var43 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.05d, 4.0d, 0.025d, Double.NEGATIVE_INFINITY);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var1 = null;
//     java.util.Collection var2 = var0.getRangeMarkers(var1);
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(1);
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var14 = var13.brighter();
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.awt.Stroke var17 = var15.getRangeCrosshairStroke();
//     java.awt.Font var19 = null;
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var23 = var22.brighter();
//     org.jfree.chart.text.TextMeasurer var26 = null;
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23, 0.5f, 1, var26);
//     int var28 = var23.getGreen();
//     java.awt.Stroke var29 = null;
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var13, var17, (java.awt.Paint)var23, var29, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var32 = var31.getLabelAnchor();
//     java.awt.Paint var33 = null;
//     var31.setOutlinePaint(var33);
//     org.jfree.chart.util.RectangleInsets var35 = var31.getLabelOffset();
//     var31.setValue(10.0d);
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var31, var38);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelLinkStroke(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    var0.setSimpleLabels(false);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var0.axisChanged(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.ValueAxis var9 = null;
    var0.setRangeAxis(1, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(short)(-1));
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Multiple Pie Plot", var1, 10.0f, 0.5f, var4, 0.14d, var6);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var4 = var2.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
//     var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
//     java.text.AttributedString var9 = null;
//     var5.setAttributedLabel(0, var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     java.text.AttributedString var13 = var5.generateAttributedSectionLabel(var11, (java.lang.Comparable)100);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     double var23 = var22.getFixedDimension();
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var26 = var24.getSectionPaint((java.lang.Comparable)(short)(-1));
//     boolean var27 = var22.hasListener((java.util.EventListener)var24);
//     double var28 = var24.getLabelGap();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.data.general.WaferMapDataset var30 = null;
//     org.jfree.chart.plot.WaferMapPlot var31 = new org.jfree.chart.plot.WaferMapPlot(var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.util.Size2D var35 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var42 = var41.brighter();
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var44 = var43.getDomainTickBandPaint();
//     java.awt.Stroke var45 = var43.getRangeCrosshairStroke();
//     java.awt.Font var47 = null;
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var51 = var50.brighter();
//     org.jfree.chart.text.TextMeasurer var54 = null;
//     org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var51, 0.5f, 1, var54);
//     int var56 = var51.getGreen();
//     java.awt.Stroke var57 = null;
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var41, var45, (java.awt.Paint)var51, var57, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var60 = var59.getLabelAnchor();
//     java.lang.String var61 = var60.toString();
//     java.awt.geom.Rectangle2D var62 = org.jfree.chart.util.RectangleAnchor.createRectangle(var35, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var60);
//     java.awt.geom.Point2D var63 = null;
//     org.jfree.chart.plot.PlotState var64 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var31.draw(var32, var62, var63, var64, var65);
//     var24.drawBackgroundImage(var29, var62);
//     var20.draw(var21, var62);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var5 = var3.getRangeAxis();
    java.lang.Object var6 = var3.clone();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("RectangleAnchor.TOP_LEFT", var2, (org.jfree.chart.plot.Plot)var3, true);
    var3.setWeight(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var12 = var3.getDomainAxisForDataset(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var27 = var26.brighter();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getDomainTickBandPaint();
//     java.awt.Stroke var30 = var28.getRangeCrosshairStroke();
//     java.awt.Font var32 = null;
//     java.awt.Color var35 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var36 = var35.brighter();
//     org.jfree.chart.text.TextMeasurer var39 = null;
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var32, (java.awt.Paint)var36, 0.5f, 1, var39);
//     int var41 = var36.getGreen();
//     java.awt.Stroke var42 = null;
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var26, var30, (java.awt.Paint)var36, var42, 1.0f);
//     var21.setOutlinePaint((java.awt.Paint)var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var44
//     assertTrue("Contract failed: equals-hashcode on var21 and var44", var21.equals(var44) ? var21.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var21
//     assertTrue("Contract failed: equals-hashcode on var44 and var21", var44.equals(var21) ? var44.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.Plot var10 = var0.getRootPlot();
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var10.datasetChanged(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(-1L), var1, var2);
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.removeLegend();
    boolean var7 = var5.getAntiAlias();
    var3.setChart(var5);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var3.setType(var9);
    java.lang.Object var11 = var3.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1L)+ "'", var11.equals((-1L)));

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis();
//     var0.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var17 = var15.getRangeAxis();
//     java.lang.Object var18 = var15.clone();
//     var15.setDomainZeroBaselineVisible(true);
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     var15.setDomainCrosshairPaint((java.awt.Paint)var23);
//     org.jfree.chart.util.RectangleEdge var26 = var15.getDomainAxisEdge();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     double var29 = var28.getRight();
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var39 = var38.brighter();
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var41 = var40.getDomainTickBandPaint();
//     java.awt.Stroke var42 = var40.getRangeCrosshairStroke();
//     java.awt.Font var44 = null;
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var48 = var47.brighter();
//     org.jfree.chart.text.TextMeasurer var51 = null;
//     org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var44, (java.awt.Paint)var48, 0.5f, 1, var51);
//     int var53 = var48.getGreen();
//     java.awt.Stroke var54 = null;
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var38, var42, (java.awt.Paint)var48, var54, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var57 = var56.getLabelAnchor();
//     java.lang.String var58 = var57.toString();
//     java.awt.geom.Rectangle2D var59 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var57);
//     java.awt.geom.Rectangle2D var60 = var28.createInsetRectangle(var59);
//     org.jfree.chart.axis.CategoryAxis3D var62 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var63 = var62.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var64 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var64);
//     var65.removeLegend();
//     boolean var67 = var65.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var68 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var69 = var68.getBaseSectionOutlinePaint();
//     var65.setBackgroundPaint(var69);
//     boolean var71 = var62.equals((java.lang.Object)var65);
//     java.util.List var72 = var65.getSubtitles();
//     var15.drawRangeTickBands(var27, var59, var72);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     org.jfree.chart.plot.CrosshairState var76 = null;
//     boolean var77 = var0.render(var14, var59, 0, var75, var76);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    org.jfree.chart.axis.ValueAxis var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.getRangeAxisIndex(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.awt.Stroke var2 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var3};
//     var0.setRenderers(var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleAnchor var15 = null;
//     java.awt.geom.Point2D var16 = org.jfree.chart.util.RectangleAnchor.coordinates(var14, var15);
//     var9.zoomDomainAxes(0.0d, 10.0d, var13, var16);
//     var0.zoomRangeAxes(0.0d, 0.14d, var8, var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    var0.mapDatasetToRangeAxis(10, 15);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var0.getRendererForDataset(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getRangeMarkers(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var5.createBufferedImage(0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.975d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     int var5 = var0.getIndexOf(var4);
//     java.awt.Paint var6 = var0.getRangeGridlinePaint();
//     double var7 = var0.getRangeCrosshairValue();
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getDomainTickBandPaint();
//     java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
//     java.awt.Font var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
//     int var27 = var22.getGreen();
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var32 = var30.getLabelAnchor();
//     org.jfree.chart.util.Layer var33 = null;
//     boolean var34 = var0.removeRangeMarker(255, (org.jfree.chart.plot.Marker)var30, var33);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "Size2D[width=1.0, height=0.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var1 = null;
//     java.util.Collection var2 = var0.getRangeMarkers(var1);
//     var0.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(1);
//     var0.setRangeCrosshairValue(10.0d, true);
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var14 = var13.brighter();
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.awt.Stroke var17 = var15.getRangeCrosshairStroke();
//     java.awt.Font var19 = null;
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var23 = var22.brighter();
//     org.jfree.chart.text.TextMeasurer var26 = null;
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23, 0.5f, 1, var26);
//     int var28 = var23.getGreen();
//     java.awt.Stroke var29 = null;
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var13, var17, (java.awt.Paint)var23, var29, 1.0f);
//     boolean var32 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var31);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    int var3 = var1.indexOf((java.lang.Object)15);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.lang.Object var7 = var5.clone();
    var5.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var10 = var5.getAxisOffset();
    boolean var11 = var5.isRangeZeroBaselineVisible();
    var5.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.Plot var15 = var5.getRootPlot();
    var1.set(255, (java.lang.Object)var5);
    var5.configureDomainAxes();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var20 = var5.removeRangeMarker(var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.util.List var11 = var4.getSubtitles();
    java.awt.Paint var12 = var4.getBackgroundPaint();
    var4.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("LengthConstraintType.FIXED", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.Plot var10 = var0.getRootPlot();
//     java.awt.Paint var11 = var0.getRangeTickBandPaint();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.awt.Paint var35 = null;
//     var33.setOutlinePaint(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var33.getLabelOffset();
//     var33.setValue(10.0d);
//     java.awt.Paint var40 = var33.getOutlinePaint();
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var33, var41);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.FIXED", var1, (-1.0f), 1.0f, var4, (-1.975d), var6);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Rotation.CLOCKWISE", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Other", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var28 = var27.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("hi!", var28);
//     var21.setLabelFont(var28);
//     java.lang.Object var31 = var21.clone();
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var33 = var32.getBaseSectionOutlinePaint();
//     var32.setInteriorGap(0.0d);
//     java.awt.Paint var36 = var32.getBackgroundPaint();
//     java.awt.Color var39 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var40 = var39.brighter();
//     int var41 = var40.getTransparency();
//     var32.setLabelOutlinePaint((java.awt.Paint)var40);
//     int var43 = var40.getGreen();
//     var21.setPaint((java.awt.Paint)var40);
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var47 = var46.getTickLabelFont();
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var49 = var48.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var50 = var48.getRangeAxis();
//     java.lang.Object var51 = var48.clone();
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("RectangleAnchor.TOP_LEFT", var47, (org.jfree.chart.plot.Plot)var48, true);
//     var21.setLabelFont(var47);
//     
//     // Checks the contract:  equals-hashcode on var5 and var48
//     assertTrue("Contract failed: equals-hashcode on var5 and var48", var5.equals(var48) ? var5.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var5
//     assertTrue("Contract failed: equals-hashcode on var48 and var5", var48.equals(var5) ? var48.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var1.removeLegend();
    int var3 = var1.getBackgroundImageAlignment();
    boolean var4 = var1.isBorderVisible();
    int var5 = var1.getSubtitleCount();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var1.createBufferedImage(10, (-127), (-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     boolean var7 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.event.RendererChangeEvent var8 = null;
//     var0.rendererChanged(var8);
//     boolean var10 = var0.isDomainGridlinesVisible();
//     var0.clearDomainMarkers();
//     var0.setDomainGridlinesVisible(true);
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var18 = var17.brighter();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var20 = var19.getDomainTickBandPaint();
//     java.awt.Stroke var21 = var19.getRangeCrosshairStroke();
//     java.awt.Font var23 = null;
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var27 = var26.brighter();
//     org.jfree.chart.text.TextMeasurer var30 = null;
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var27, 0.5f, 1, var30);
//     int var32 = var27.getGreen();
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var17, var21, (java.awt.Paint)var27, var33, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var36 = var35.getLabelAnchor();
//     java.awt.Paint var37 = null;
//     var35.setOutlinePaint(var37);
//     org.jfree.chart.util.RectangleInsets var39 = var35.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var42 = var41.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var43 = new org.jfree.chart.text.TextFragment("hi!", var42);
//     var35.setLabelFont(var42);
//     java.lang.Object var45 = var35.clone();
//     org.jfree.chart.util.Layer var46 = null;
//     boolean var47 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var35, var46);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var24 = var23.getLegendItems();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getDomainTickBandPaint();
//     java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
//     var23.setOutlineStroke(var27);
//     var23.setLabelGap(100.0d);
//     java.awt.Paint var31 = var23.getLabelLinkPaint();
//     var21.setPaint(var31);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    double var4 = var3.getFixedDimension();
    var3.setTickMarksVisible(false);
    org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var3);
    boolean var8 = var3.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(100, var3, true);
    var0.setRangeGridlinesVisible(true);
    org.jfree.chart.event.RendererChangeEvent var8 = null;
    var0.rendererChanged(var8);
    boolean var10 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Paint var2 = var1.getTickMarkPaint();
    java.lang.Comparable var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var4 = var1.getTickLabelPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis();
    var0.setRangeCrosshairLockedOnData(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var15 = var0.getDomainAxisForDataset(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.05d, 0.025d);
    java.lang.String var3 = var2.toString();
    double var4 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.05, height=0.025]"+ "'", var3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.05, height=0.025]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getRangeMarkers(var1);
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(1);
    var0.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.CategoryMarker var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    var2.setWidth(1.0d);
    var2.setWidth(0.0d);
    var2.setHeight((-1.975d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.CategoryMarker var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var7 = var0.getDataset();
//     java.awt.Paint var8 = var0.getRangeZeroBaselinePaint();
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getDomainTickBandPaint();
//     java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
//     java.awt.Font var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
//     int var27 = var22.getGreen();
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     java.awt.Paint var32 = null;
//     var30.setOutlinePaint(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var30.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var37 = var36.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("hi!", var37);
//     var30.setLabelFont(var37);
//     java.lang.Object var40 = var30.clone();
//     java.awt.Paint var41 = var30.getPaint();
//     boolean var42 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var30);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Rotation.CLOCKWISE", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.FlowArrangement var1 = new org.jfree.chart.block.FlowArrangement();
//     var1.clear();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var4 = var2.getSectionPaint((java.lang.Comparable)(short)(-1));
    boolean var5 = var0.hasListener((java.util.EventListener)var2);
    double var6 = var2.getLabelGap();
    java.awt.Graphics2D var7 = null;
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
    java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var20 = var19.brighter();
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var22 = var21.getDomainTickBandPaint();
    java.awt.Stroke var23 = var21.getRangeCrosshairStroke();
    java.awt.Font var25 = null;
    java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var29 = var28.brighter();
    org.jfree.chart.text.TextMeasurer var32 = null;
    org.jfree.chart.text.TextBlock var33 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var29, 0.5f, 1, var32);
    int var34 = var29.getGreen();
    java.awt.Stroke var35 = null;
    org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var23, (java.awt.Paint)var29, var35, 1.0f);
    org.jfree.chart.util.RectangleAnchor var38 = var37.getLabelAnchor();
    java.lang.String var39 = var38.toString();
    java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var38);
    java.awt.geom.Point2D var41 = null;
    org.jfree.chart.plot.PlotState var42 = null;
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    var9.draw(var10, var40, var41, var42, var43);
    var2.drawBackgroundImage(var7, var40);
    org.jfree.chart.util.RectangleInsets var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSimpleLabelOffset(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "RectangleAnchor.TOP_LEFT"+ "'", var39.equals("RectangleAnchor.TOP_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var12 = var11.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var11.setRangeAxis(100, var14, true);
//     var11.setRangeGridlinesVisible(true);
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var23 = var22.brighter();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var25 = var24.getDomainTickBandPaint();
//     java.awt.Stroke var26 = var24.getRangeCrosshairStroke();
//     java.awt.Font var28 = null;
//     java.awt.Color var31 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var32 = var31.brighter();
//     org.jfree.chart.text.TextMeasurer var35 = null;
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var32, 0.5f, 1, var35);
//     int var37 = var32.getGreen();
//     java.awt.Stroke var38 = null;
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var22, var26, (java.awt.Paint)var32, var38, 1.0f);
//     var11.addRangeMarker((org.jfree.chart.plot.Marker)var40);
//     java.awt.Paint var42 = var40.getPaint();
//     java.awt.Paint var43 = var40.getLabelPaint();
//     org.jfree.chart.util.Layer var44 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var40, var44);
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
    java.awt.Color var6 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var0.setTickMarkPaint((java.awt.Paint)var6);
    var0.centerRange(4.0d);
    java.awt.Shape var10 = var0.getLeftArrow();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(1.0d, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     boolean var7 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var9 = var8.getDomainTickBandPaint();
//     java.lang.Object var10 = var8.clone();
//     var8.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var13 = var8.getAxisOffset();
//     boolean var14 = var8.isRangeZeroBaselineVisible();
//     var8.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var18 = var8.getQuadrantOrigin();
//     java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var23 = var22.brighter();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var25 = var24.getDomainTickBandPaint();
//     java.awt.Stroke var26 = var24.getRangeCrosshairStroke();
//     java.awt.Font var28 = null;
//     java.awt.Color var31 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var32 = var31.brighter();
//     org.jfree.chart.text.TextMeasurer var35 = null;
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, (java.awt.Paint)var32, 0.5f, 1, var35);
//     int var37 = var32.getGreen();
//     java.awt.Stroke var38 = null;
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var22, var26, (java.awt.Paint)var32, var38, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var41 = var40.getLabelAnchor();
//     java.awt.Paint var42 = null;
//     var40.setOutlinePaint(var42);
//     org.jfree.chart.util.RectangleInsets var44 = var40.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var47 = var46.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("hi!", var47);
//     var40.setLabelFont(var47);
//     java.lang.Object var50 = var40.clone();
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.util.Layer var52 = null;
//     boolean var53 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var40, var52);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    double var20 = var0.getAnchorValue();
    var0.setWeight(0);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = var0.getRendererForDataset(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var3 = var2.getDomainTickBandPaint();
    java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
    var0.setOutlineStroke(var4);
    var0.setLabelGap(100.0d);
    java.awt.Paint var8 = var0.getLabelLinkPaint();
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var11 = var9.getSectionPaint((java.lang.Comparable)(short)(-1));
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    java.lang.Comparable var15 = null;
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var18 = var16.getSectionPaint((java.lang.Comparable)(short)(-1));
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var16.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var19);
    java.awt.Stroke var21 = var16.getBaseSectionOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSectionOutlineStroke(var15, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var2 = var1.getTickLabelFont();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var5 = var3.getRangeAxis();
    java.lang.Object var6 = var3.clone();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart("RectangleAnchor.TOP_LEFT", var2, (org.jfree.chart.plot.Plot)var3, true);
    var3.setWeight(15);
    java.awt.Paint var11 = var3.getRangeTickBandPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var13 = var3.getDomainAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
//     int var3 = var1.indexOf((java.lang.Object)15);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.lang.Object var7 = var5.clone();
//     var5.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var10 = var5.getAxisOffset();
//     boolean var11 = var5.isRangeZeroBaselineVisible();
//     var5.setRangeCrosshairValue(10.0d, true);
//     org.jfree.chart.plot.Plot var15 = var5.getRootPlot();
//     var1.set(255, (java.lang.Object)var5);
//     var5.configureDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var5.handleClick(0, 100, var20);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    var0.setDomainZeroBaselineVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    var0.setRenderer(var6);
    var0.setDomainZeroBaselineVisible(false);
    org.jfree.chart.annotations.XYAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var0.removeAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    boolean var4 = var0.isRangeZoomable();
    org.jfree.data.xy.XYDataset var5 = var0.getDataset();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var6.setRenderer(255, var8);
    org.jfree.chart.LegendItemCollection var10 = var6.getLegendItems();
    java.util.Iterator var11 = var10.iterator();
    var0.setFixedLegendItems(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "", "hi!", "hi!");
//     java.util.List var8 = var7.getContributors();
//     var7.setLicenceName("hi!");
//     org.jfree.chart.ui.Library var11 = null;
//     var7.addLibrary(var11);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 10.0f, 0.0f);
    float[] var7 = new float[] { 0.0f, 0.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var3.getComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     java.awt.Paint var31 = null;
//     var29.setOutlinePaint(var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 100.0f);
//     var29.setOutlinePaint((java.awt.Paint)var36);
//     org.jfree.chart.util.Layer var38 = null;
//     var0.addRangeMarker(15, (org.jfree.chart.plot.Marker)var29, var38);
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var44 = var43.brighter();
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var46 = var45.getDomainTickBandPaint();
//     java.awt.Stroke var47 = var45.getRangeCrosshairStroke();
//     java.awt.Font var49 = null;
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var53 = var52.brighter();
//     org.jfree.chart.text.TextMeasurer var56 = null;
//     org.jfree.chart.text.TextBlock var57 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, (java.awt.Paint)var53, 0.5f, 1, var56);
//     int var58 = var53.getGreen();
//     java.awt.Stroke var59 = null;
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var43, var47, (java.awt.Paint)var53, var59, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var62 = var61.getLabelAnchor();
//     var61.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var65 = var61.getLabelOffsetType();
//     var29.setLabelOffsetType(var65);
//     
//     // Checks the contract:  equals-hashcode on var13 and var45
//     assertTrue("Contract failed: equals-hashcode on var13 and var45", var13.equals(var45) ? var13.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var13
//     assertTrue("Contract failed: equals-hashcode on var45 and var13", var45.equals(var13) ? var45.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Paint var4 = var3.getTickMarkPaint();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var8 = var7.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("hi!", var8);
//     var3.setTickLabelFont((java.lang.Comparable)"hi!", var8);
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     var11.setOutlineStroke(var15);
//     var11.setLabelGap(100.0d);
//     java.awt.Paint var19 = var11.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var20.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     double var27 = var26.getFixedDimension();
//     java.lang.Object var28 = var26.clone();
//     org.jfree.chart.util.RectangleInsets var29 = var26.getLabelInsets();
//     java.awt.Color var32 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var26.setTickMarkPaint((java.awt.Paint)var32);
//     var11.setLabelShadowPaint((java.awt.Paint)var32);
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var8, (java.awt.Paint)var32);
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var37 = var36.getDomainTickBandPaint();
//     java.lang.Object var38 = var36.clone();
//     var36.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var41 = var36.getAxisOffset();
//     boolean var42 = var36.isRangeZeroBaselineVisible();
//     java.awt.Stroke var43 = var36.getOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.setAnchorValue(1.0d);
//     var44.clearDomainAxes();
//     org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var48);
//     var49.removeLegend();
//     boolean var51 = var49.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var53 = var52.getBaseSectionOutlinePaint();
//     var49.setBackgroundPaint(var53);
//     var44.setRangeGridlinePaint(var53);
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var58 = var56.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var59 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var56.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var59);
//     java.awt.Stroke var61 = var56.getBaseSectionOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(1.0E-5d, (java.awt.Paint)var32, var43, var53, var61, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var20 and var56
//     assertTrue("Contract failed: equals-hashcode on var20 and var56", var20.equals(var56) ? var20.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var20
//     assertTrue("Contract failed: equals-hashcode on var56 and var20", var56.equals(var20) ? var56.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var36
//     assertTrue("Contract failed: equals-hashcode on var13 and var36", var13.equals(var36) ? var13.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var13
//     assertTrue("Contract failed: equals-hashcode on var36 and var13", var36.equals(var13) ? var36.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var59
//     assertTrue("Contract failed: equals-hashcode on var23 and var59", var23.equals(var59) ? var23.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var23
//     assertTrue("Contract failed: equals-hashcode on var59 and var23", var59.equals(var23) ? var59.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     var1.setInteriorGap(0.0d);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     java.lang.Object var6 = var5.getTextAntiAlias();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     var5.handleClick(255, 255, var9);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var7 = var0.getDataset();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var0.getRenderer(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var11 = var0.getQuadrantPaint(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    var19.setNotify(false);
    org.jfree.chart.util.RectangleInsets var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setLegendItemGraphicPadding(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = var0.getRenderer();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.setAnchorValue(1.0d);
    java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var21 = var20.brighter();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var23 = var22.getDomainTickBandPaint();
    java.awt.Stroke var24 = var22.getRangeCrosshairStroke();
    java.awt.Font var26 = null;
    java.awt.Color var29 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var30 = var29.brighter();
    org.jfree.chart.text.TextMeasurer var33 = null;
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, (java.awt.Paint)var30, 0.5f, 1, var33);
    int var35 = var30.getGreen();
    java.awt.Stroke var36 = null;
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var20, var24, (java.awt.Paint)var30, var36, 1.0f);
    org.jfree.chart.util.RectangleAnchor var39 = var38.getLabelAnchor();
    org.jfree.chart.util.Layer var40 = null;
    boolean var41 = var13.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var38, var40);
    org.jfree.chart.util.Layer var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(1, (org.jfree.chart.plot.Marker)var38, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", 0.14d, (-127));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var7 = var6.getDomainTickBandPaint();
    java.awt.Stroke var8 = var6.getRangeCrosshairStroke();
    java.awt.Font var10 = null;
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var14 = var13.brighter();
    org.jfree.chart.text.TextMeasurer var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var14, 0.5f, 1, var17);
    int var19 = var14.getGreen();
    java.awt.Stroke var20 = null;
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var4, var8, (java.awt.Paint)var14, var20, 1.0f);
    org.jfree.chart.util.RectangleAnchor var23 = var22.getLabelAnchor();
    java.awt.Paint var24 = null;
    var22.setOutlinePaint(var24);
    org.jfree.chart.util.RectangleInsets var26 = var22.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var29 = var28.getTickLabelFont();
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("hi!", var29);
    var22.setLabelFont(var29);
    java.lang.Object var32 = var22.clone();
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var34 = var33.getBaseSectionOutlinePaint();
    var33.setInteriorGap(0.0d);
    java.awt.Paint var37 = var33.getBackgroundPaint();
    java.awt.Color var40 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var41 = var40.brighter();
    int var42 = var41.getTransparency();
    var33.setLabelOutlinePaint((java.awt.Paint)var41);
    int var44 = var41.getGreen();
    var22.setPaint((java.awt.Paint)var41);
    org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var47 = var46.getLegendItems();
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var49 = var48.getDomainTickBandPaint();
    java.awt.Stroke var50 = var48.getRangeCrosshairStroke();
    var46.setOutlineStroke(var50);
    var46.setLabelGap(100.0d);
    org.jfree.chart.util.RectangleInsets var54 = var46.getSimpleLabelOffset();
    java.awt.Image var55 = var46.getBackgroundImage();
    java.awt.Shape var56 = var46.getLegendItemShape();
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
    double var58 = var57.getFixedDimension();
    var57.setTickMarksVisible(false);
    java.awt.Stroke var61 = var57.getAxisLineStroke();
    var46.setBaseSectionOutlineStroke(var61);
    java.awt.Color var69 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    org.jfree.chart.block.BlockBorder var70 = new org.jfree.chart.block.BlockBorder(100.0d, 10.0d, 1.0d, 90.0d, (java.awt.Paint)var69);
    org.jfree.chart.plot.MultiplePiePlot var71 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var71);
    var72.removeLegend();
    boolean var74 = var72.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var75 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var76 = var75.getBaseSectionOutlinePaint();
    var72.setBackgroundPaint(var76);
    org.jfree.chart.plot.PiePlot3D var78 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var80 = var78.getSectionPaint((java.lang.Comparable)(short)(-1));
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var81 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var78.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var81);
    java.awt.Stroke var83 = var78.getBaseSectionOutlineStroke();
    var72.setBorderStroke(var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var86 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var41, var61, (java.awt.Paint)var69, var83, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var2 = var1.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     var4.removeLegend();
//     boolean var6 = var4.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
//     var4.setBackgroundPaint(var8);
//     boolean var10 = var1.equals((java.lang.Object)var4);
//     java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var1.setLabelPaint((java.awt.Paint)var13);
//     var1.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
//     var1.setFixedDimension(1.0d);
//     var1.setCategoryMargin(0.14d);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var24 = var23.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     var26.removeLegend();
//     boolean var28 = var26.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var30 = var29.getBaseSectionOutlinePaint();
//     var26.setBackgroundPaint(var30);
//     boolean var32 = var23.equals((java.lang.Object)var26);
//     java.awt.Color var35 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var23.setLabelPaint((java.awt.Paint)var35);
//     var23.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
//     var23.setFixedDimension(1.0d);
//     var23.setCategoryMargin(0.14d);
//     org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Paint var46 = var45.getTickMarkPaint();
//     org.jfree.chart.axis.CategoryLabelPositions var47 = var45.getCategoryLabelPositions();
//     var23.setCategoryLabelPositions(var47);
//     var1.setCategoryLabelPositions(var47);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var1 = var0.getRight();
//     org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var11 = var10.brighter();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.awt.Stroke var14 = var12.getRangeCrosshairStroke();
//     java.awt.Font var16 = null;
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20, 0.5f, 1, var23);
//     int var25 = var20.getGreen();
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var14, (java.awt.Paint)var20, var26, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var29 = var28.getLabelAnchor();
//     java.lang.String var30 = var29.toString();
//     java.awt.geom.Rectangle2D var31 = org.jfree.chart.util.RectangleAnchor.createRectangle(var4, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var29);
//     java.awt.geom.Rectangle2D var32 = var0.createInsetRectangle(var31);
//     double var34 = var0.calculateLeftOutset(1.0d);
//     double var36 = var0.calculateRightOutset(0.05d);
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets();
//     double var38 = var37.getRight();
//     org.jfree.chart.util.Size2D var41 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var48 = var47.brighter();
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var50 = var49.getDomainTickBandPaint();
//     java.awt.Stroke var51 = var49.getRangeCrosshairStroke();
//     java.awt.Font var53 = null;
//     java.awt.Color var56 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var57 = var56.brighter();
//     org.jfree.chart.text.TextMeasurer var60 = null;
//     org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, (java.awt.Paint)var57, 0.5f, 1, var60);
//     int var62 = var57.getGreen();
//     java.awt.Stroke var63 = null;
//     org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var47, var51, (java.awt.Paint)var57, var63, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var66 = var65.getLabelAnchor();
//     java.lang.String var67 = var66.toString();
//     java.awt.geom.Rectangle2D var68 = org.jfree.chart.util.RectangleAnchor.createRectangle(var41, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var66);
//     java.awt.geom.Rectangle2D var69 = var37.createInsetRectangle(var68);
//     java.awt.geom.Rectangle2D var70 = var0.createInsetRectangle(var69);
//     
//     // Checks the contract:  equals-hashcode on var4 and var41
//     assertTrue("Contract failed: equals-hashcode on var4 and var41", var4.equals(var41) ? var4.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var4
//     assertTrue("Contract failed: equals-hashcode on var41 and var4", var41.equals(var4) ? var41.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var49
//     assertTrue("Contract failed: equals-hashcode on var12 and var49", var12.equals(var49) ? var12.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var12
//     assertTrue("Contract failed: equals-hashcode on var49 and var12", var49.equals(var12) ? var49.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var65
//     assertTrue("Contract failed: equals-hashcode on var28 and var65", var28.equals(var65) ? var28.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var28
//     assertTrue("Contract failed: equals-hashcode on var65 and var28", var65.equals(var28) ? var65.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.util.List var11 = var4.getSubtitles();
    org.jfree.chart.event.ChartChangeListener var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addChangeListener(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     java.lang.String var31 = var30.toString();
//     java.awt.geom.Rectangle2D var32 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var30);
//     org.jfree.chart.util.Size2D var33 = var2.calculateConstrainedSize(var5);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     java.awt.Paint var21 = var19.getBackgroundPaint();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     var22.setRangeAxis(var25);
//     org.jfree.chart.axis.AxisLocation var28 = var22.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     var22.setRenderer(var29, false);
//     var22.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement();
//     var33.clear();
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 0.0d, 100.0d);
//     var39.clear();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var39);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     var42.setRenderer(255, var44);
//     org.jfree.chart.LegendItemCollection var46 = var42.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var48 = var42.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var49 = var42.getRangeAxisLocation();
//     org.jfree.chart.util.Layer var51 = null;
//     java.util.Collection var52 = var42.getDomainMarkers((-127), var51);
//     boolean var53 = var42.isRangeZoomable();
//     boolean var54 = var33.equals((java.lang.Object)var42);
//     java.awt.Paint var55 = var42.getRangeCrosshairPaint();
//     var19.setItemPaint(var55);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     var21.setAlpha(0.5f);
//     java.awt.Color var31 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var32 = var31.brighter();
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var34 = var33.getDomainTickBandPaint();
//     java.awt.Stroke var35 = var33.getRangeCrosshairStroke();
//     java.awt.Font var37 = null;
//     java.awt.Color var40 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var41 = var40.brighter();
//     org.jfree.chart.text.TextMeasurer var44 = null;
//     org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, (java.awt.Paint)var41, 0.5f, 1, var44);
//     int var46 = var41.getGreen();
//     java.awt.Stroke var47 = null;
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var31, var35, (java.awt.Paint)var41, var47, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var50 = var49.getLabelAnchor();
//     var49.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var53 = var49.getLabelOffsetType();
//     var21.setLabelOffsetType(var53);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.TOP_LEFT", var1, (-1.975d), 100.0f, 0.0f);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setDomainAxis(var4);
    org.jfree.data.xy.XYDataset var6 = null;
    var0.setDataset(var6);
    java.awt.Stroke var8 = var0.getDomainCrosshairStroke();
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-127), var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraint[LengthConstraintType.FIXED: width=0.05, height=0.025]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var10 = var9.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var11 = var9.getRangeAxis();
//     java.lang.Object var12 = var9.clone();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var9.setDomainAxis(var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     var9.setDataset(var15);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     var19.setRenderer(255, var21);
//     org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
//     var19.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var27 = var19.getDomainAxisLocation(15);
//     double var28 = var19.getAnchorValue();
//     java.awt.Paint var29 = var19.getRangeGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleAnchor var33 = null;
//     java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
//     var19.zoomRangeAxes(10.0d, var31, var34);
//     var9.zoomDomainAxes(0.0d, var18, var34, true);
//     var0.zoomDomainAxes(90.0d, (-1.975d), var8, var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.event.RendererChangeEvent var12 = null;
//     var0.rendererChanged(var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(255, var16);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     int var19 = var14.getIndexOf(var18);
//     org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var22.getRangeMarkers(var23);
//     var22.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     var28.setRenderer(255, var30);
//     org.jfree.chart.LegendItemCollection var32 = var28.getLegendItems();
//     var28.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var36 = var28.getDomainAxisLocation(15);
//     var22.setRangeAxisLocation(0, var36, true);
//     var0.setRangeAxisLocation(var36);
//     
//     // Checks the contract:  equals-hashcode on var2 and var32
//     assertTrue("Contract failed: equals-hashcode on var2 and var32", var2.equals(var32) ? var2.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
//     var0.setInteriorGap(0.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
//     double var6 = var5.getRight();
//     org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.lang.String var35 = var34.toString();
//     java.awt.geom.Rectangle2D var36 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var34);
//     java.awt.geom.Rectangle2D var37 = var5.createInsetRectangle(var36);
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var39 = var38.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var40 = var38.getRangeAxis();
//     java.lang.Object var41 = var38.clone();
//     var38.setDomainZeroBaselineVisible(true);
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var47 = var46.brighter();
//     var38.setDomainCrosshairPaint((java.awt.Paint)var46);
//     org.jfree.chart.util.RectangleEdge var49 = var38.getDomainAxisEdge();
//     double var50 = org.jfree.chart.util.RectangleEdge.coordinate(var37, var49);
//     org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var52 = var51.getBaseSectionOutlinePaint();
//     var51.setInteriorGap(0.0d);
//     java.awt.Paint var55 = var51.getBackgroundPaint();
//     var51.setSectionOutlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     org.jfree.chart.plot.PiePlotState var60 = var0.initialise(var4, var37, (org.jfree.chart.plot.PiePlot)var51, (java.lang.Integer)0, var59);
//     var60.setTotal(90.0d);
//     var60.setPassesRequired(15);
//     java.awt.geom.Rectangle2D var65 = var60.getPieArea();
//     org.jfree.chart.util.RectangleInsets var66 = new org.jfree.chart.util.RectangleInsets();
//     double var67 = var66.getRight();
//     org.jfree.chart.util.Size2D var70 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var76 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var77 = var76.brighter();
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var79 = var78.getDomainTickBandPaint();
//     java.awt.Stroke var80 = var78.getRangeCrosshairStroke();
//     java.awt.Font var82 = null;
//     java.awt.Color var85 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var86 = var85.brighter();
//     org.jfree.chart.text.TextMeasurer var89 = null;
//     org.jfree.chart.text.TextBlock var90 = org.jfree.chart.text.TextUtilities.createTextBlock("", var82, (java.awt.Paint)var86, 0.5f, 1, var89);
//     int var91 = var86.getGreen();
//     java.awt.Stroke var92 = null;
//     org.jfree.chart.plot.ValueMarker var94 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var76, var80, (java.awt.Paint)var86, var92, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var95 = var94.getLabelAnchor();
//     java.lang.String var96 = var95.toString();
//     java.awt.geom.Rectangle2D var97 = org.jfree.chart.util.RectangleAnchor.createRectangle(var70, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var95);
//     java.awt.geom.Rectangle2D var98 = var66.createInsetRectangle(var97);
//     var60.setPieArea(var97);
//     
//     // Checks the contract:  equals-hashcode on var9 and var70
//     assertTrue("Contract failed: equals-hashcode on var9 and var70", var9.equals(var70) ? var9.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var9
//     assertTrue("Contract failed: equals-hashcode on var70 and var9", var70.equals(var9) ? var70.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var78
//     assertTrue("Contract failed: equals-hashcode on var17 and var78", var17.equals(var78) ? var17.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var17
//     assertTrue("Contract failed: equals-hashcode on var78 and var17", var78.equals(var17) ? var78.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var94
//     assertTrue("Contract failed: equals-hashcode on var33 and var94", var33.equals(var94) ? var33.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var33
//     assertTrue("Contract failed: equals-hashcode on var94 and var33", var94.equals(var33) ? var94.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
//     var0.setInteriorGap(0.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
//     double var6 = var5.getRight();
//     org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     java.lang.String var35 = var34.toString();
//     java.awt.geom.Rectangle2D var36 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var34);
//     java.awt.geom.Rectangle2D var37 = var5.createInsetRectangle(var36);
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var39 = var38.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var40 = var38.getRangeAxis();
//     java.lang.Object var41 = var38.clone();
//     var38.setDomainZeroBaselineVisible(true);
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var47 = var46.brighter();
//     var38.setDomainCrosshairPaint((java.awt.Paint)var46);
//     org.jfree.chart.util.RectangleEdge var49 = var38.getDomainAxisEdge();
//     double var50 = org.jfree.chart.util.RectangleEdge.coordinate(var37, var49);
//     org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var52 = var51.getBaseSectionOutlinePaint();
//     var51.setInteriorGap(0.0d);
//     java.awt.Paint var55 = var51.getBackgroundPaint();
//     var51.setSectionOutlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     org.jfree.chart.plot.PiePlotState var60 = var0.initialise(var4, var37, (org.jfree.chart.plot.PiePlot)var51, (java.lang.Integer)0, var59);
//     double var61 = var60.getLatestAngle();
//     org.jfree.chart.util.RectangleInsets var62 = new org.jfree.chart.util.RectangleInsets();
//     double var63 = var62.getRight();
//     org.jfree.chart.util.Size2D var66 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var72 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var73 = var72.brighter();
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var75 = var74.getDomainTickBandPaint();
//     java.awt.Stroke var76 = var74.getRangeCrosshairStroke();
//     java.awt.Font var78 = null;
//     java.awt.Color var81 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var82 = var81.brighter();
//     org.jfree.chart.text.TextMeasurer var85 = null;
//     org.jfree.chart.text.TextBlock var86 = org.jfree.chart.text.TextUtilities.createTextBlock("", var78, (java.awt.Paint)var82, 0.5f, 1, var85);
//     int var87 = var82.getGreen();
//     java.awt.Stroke var88 = null;
//     org.jfree.chart.plot.ValueMarker var90 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var72, var76, (java.awt.Paint)var82, var88, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var91 = var90.getLabelAnchor();
//     java.lang.String var92 = var91.toString();
//     java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var66, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var91);
//     java.awt.geom.Rectangle2D var94 = var62.createInsetRectangle(var93);
//     var60.setExplodedPieArea(var94);
//     
//     // Checks the contract:  equals-hashcode on var9 and var66
//     assertTrue("Contract failed: equals-hashcode on var9 and var66", var9.equals(var66) ? var9.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var9
//     assertTrue("Contract failed: equals-hashcode on var66 and var9", var66.equals(var9) ? var66.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var74
//     assertTrue("Contract failed: equals-hashcode on var17 and var74", var17.equals(var74) ? var17.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var17
//     assertTrue("Contract failed: equals-hashcode on var74 and var17", var74.equals(var17) ? var74.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var90
//     assertTrue("Contract failed: equals-hashcode on var33 and var90", var33.equals(var90) ? var33.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var33
//     assertTrue("Contract failed: equals-hashcode on var90 and var33", var90.equals(var33) ? var90.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "LengthConstraintType.FIXED", var3);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getWidthConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var9);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1, var5, 0.0d, var7, var11);
    org.jfree.chart.plot.MultiplePiePlot var13 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    boolean var15 = var11.equals((java.lang.Object)var13);
    java.lang.String var16 = var13.getPlotType();
    org.jfree.data.category.CategoryDataset var17 = var13.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Multiple Pie Plot"+ "'", var16.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Range[-1.0,0.0]", var1);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getDomainTickBandPaint();
//     java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
//     var0.setOutlineStroke(var4);
//     var0.setLabelGap(100.0d);
//     java.awt.Paint var8 = var0.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var11 = var9.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.lang.Object var17 = var15.clone();
//     var15.clearRangeMarkers(100);
//     var15.mapDatasetToRangeAxis(10, 15);
//     int var23 = var15.getRangeAxisCount();
//     boolean var24 = var12.equals((java.lang.Object)var15);
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var31 = var30.getDomainTickBandPaint();
//     java.awt.Stroke var32 = var30.getRangeCrosshairStroke();
//     java.awt.Font var34 = null;
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var38 = var37.brighter();
//     org.jfree.chart.text.TextMeasurer var41 = null;
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, (java.awt.Paint)var38, 0.5f, 1, var41);
//     int var43 = var38.getGreen();
//     java.awt.Stroke var44 = null;
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var28, var32, (java.awt.Paint)var38, var44, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var47 = var46.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var48 = var46.getLabelAnchor();
//     java.awt.Color var51 = java.awt.Color.getColor("hi!", (-1));
//     var46.setLabelPaint((java.awt.Paint)var51);
//     org.jfree.chart.util.Layer var53 = null;
//     boolean var54 = var15.removeRangeMarker((org.jfree.chart.plot.Marker)var46, var53);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
//     java.awt.Color var29 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var30 = var29.brighter();
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var30);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getInsets();
//     var22.setMargin(var32);
//     var20.add((org.jfree.chart.block.Block)var22);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var36 = var35.getDomainTickBandPaint();
//     java.lang.Object var37 = var35.clone();
//     var35.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var40 = var35.getAxisOffset();
//     double var42 = var40.calculateBottomInset((-1.0d));
//     double var43 = var40.getTop();
//     double var44 = var40.getRight();
//     var20.setPadding(var40);
//     java.awt.Graphics2D var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var48 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var50 = var49.getDomainTickBandPaint();
//     java.lang.Object var51 = var49.clone();
//     var49.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var54 = var49.getAxisOffset();
//     boolean var55 = var49.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var56 = var49.getDataset();
//     org.jfree.chart.axis.ValueAxis var58 = var49.getRangeAxisForDataset(0);
//     var49.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     var62.setRenderer(255, var64);
//     org.jfree.chart.LegendItemCollection var66 = var62.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var68 = var62.getDomainAxisLocation(100);
//     var49.setDomainAxisLocation(100, var68, false);
//     boolean var71 = var48.equals((java.lang.Object)100);
//     java.text.AttributedString var73 = var48.getAttributedLabel(255);
//     java.lang.Object var74 = var20.draw(var46, var47, (java.lang.Object)255);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var4 = var2.getSectionPaint((java.lang.Comparable)(short)(-1));
//     boolean var5 = var0.hasListener((java.util.EventListener)var2);
//     var0.configure();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     var7.setFixedLegendItems(var9);
//     var0.setPlot((org.jfree.chart.plot.Plot)var7);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
    java.lang.Object var4 = var1.clone();
    var1.setDomainZeroBaselineVisible(true);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var10 = var9.brighter();
    var1.setDomainCrosshairPaint((java.awt.Paint)var9);
    var1.setRangeCrosshairValue(1.0d);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var15.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)1.0d, var15, 100, 255);
    org.jfree.chart.event.ChartProgressListener var20 = null;
    var15.addProgressListener(var20);
    org.jfree.chart.event.ChartProgressEvent var24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0f), var15, 100, 0);
    org.jfree.chart.JFreeChart var25 = var24.getChart();
    var25.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    java.lang.Object var2 = var0.clone();
    var0.setLabel("Rotation.CLOCKWISE");
    var0.setTickMarkInsideLength(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var23 = var21.getLabelAnchor();
    java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
    var21.setLabelPaint((java.awt.Paint)var26);
    org.jfree.chart.text.TextAnchor var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelTextAnchor(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    java.awt.Paint var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    var2.clearCategoryLabelToolTips();
    var2.setLabelToolTip("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var6 = var2.getLabelURL();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getLabelOutlineStroke();
    var2.setAxisLineStroke(var8);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var10.setRangeAxis(var13);
    org.jfree.chart.axis.AxisLocation var16 = var10.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    var10.setRenderer(var17, false);
    var10.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
    var21.clear();
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement(var23, var24, 0.0d, 100.0d);
    var27.clear();
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10, (org.jfree.chart.block.Arrangement)var21, (org.jfree.chart.block.Arrangement)var27);
    var29.setNotify(false);
    java.awt.Paint var32 = var29.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var33 = var29.getLegendItemGraphicPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder(var0, var8, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("Pie 3D Plot", "ThreadContext", "", "hi!");

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    boolean var1 = var0.isRangeZoomable();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var3 = var2.getTickLabelFont();
    double var4 = var2.getFixedAutoRange();
    var2.setAutoTickUnitSelection(true, true);
    var2.setAxisLineVisible(false);
    org.jfree.data.Range var10 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var2);
    double var11 = var2.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.chart.renderer.WaferMapRenderer var2 = null;
//     var1.setRenderer(var2);
//     org.jfree.chart.LegendItemCollection var4 = var1.getLegendItems();
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotOrientation var1 = var0.getOrientation();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getDomainTickBandPaint();
//     java.lang.Object var8 = var6.clone();
//     var6.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var11 = var6.getAxisOffset();
//     boolean var12 = var6.isRangeZeroBaselineVisible();
//     var6.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var16 = var6.getQuadrantOrigin();
//     var0.zoomRangeAxes(100.0d, 0.05d, var5, var16);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3);
//     var0.zoom(104.0d);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    double var5 = var4.getFixedDimension();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.util.RectangleInsets var7 = var4.getLabelInsets();
    java.awt.Color var10 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var4.setTickMarkPaint((java.awt.Paint)var10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var13 = var12.getDomainTickBandPaint();
    java.lang.Object var14 = var12.clone();
    var12.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var17 = var12.getAxisOffset();
    boolean var18 = var12.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var19 = var12.getDataset();
    java.awt.Paint var20 = var12.getRangeZeroBaselinePaint();
    var4.setTickLabelPaint(var20);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.axis.NumberTickUnit var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTickUnit(var23, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.handleClick(1, 15, var5);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeEvent var3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    java.awt.Paint var4 = var1.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var5 = var1.getMargin();
    double var6 = var5.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    var0.setAnchorValue(Double.NEGATIVE_INFINITY, true);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var7 = var6.getDomainTickBandPaint();
    java.lang.Object var8 = var6.clone();
    var6.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var11 = var6.getAxisOffset();
    boolean var12 = var6.isRangeZeroBaselineVisible();
    var6.setRangeCrosshairValue(10.0d, true);
    boolean var16 = var6.isDomainGridlinesVisible();
    boolean var17 = var6.isRangeCrosshairLockedOnData();
    boolean var18 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var23 = null;
    var20.setRangeAxis(var23);
    org.jfree.chart.axis.AxisLocation var26 = var20.getRangeAxisLocation(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     var21.setValue(10.0d);
//     java.awt.Paint var28 = var21.getOutlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var31 = var30.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var32 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     var33.removeLegend();
//     boolean var35 = var33.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var37 = var36.getBaseSectionOutlinePaint();
//     var33.setBackgroundPaint(var37);
//     boolean var39 = var30.equals((java.lang.Object)var33);
//     java.awt.Color var42 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var30.setLabelPaint((java.awt.Paint)var42);
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var48 = var47.brighter();
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var50 = var49.getDomainTickBandPaint();
//     java.awt.Stroke var51 = var49.getRangeCrosshairStroke();
//     java.awt.Font var53 = null;
//     java.awt.Color var56 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var57 = var56.brighter();
//     org.jfree.chart.text.TextMeasurer var60 = null;
//     org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, (java.awt.Paint)var57, 0.5f, 1, var60);
//     int var62 = var57.getGreen();
//     java.awt.Stroke var63 = null;
//     org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var47, var51, (java.awt.Paint)var57, var63, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var66 = var65.getLabelAnchor();
//     java.awt.Paint var67 = null;
//     var65.setOutlinePaint(var67);
//     org.jfree.chart.util.RectangleInsets var69 = var65.getLabelOffset();
//     var30.setLabelInsets(var69);
//     float var71 = var30.getMaximumCategoryLabelWidthRatio();
//     org.jfree.chart.util.RectangleInsets var72 = var30.getLabelInsets();
//     var21.setLabelOffset(var72);
//     
//     // Checks the contract:  equals-hashcode on var5 and var49
//     assertTrue("Contract failed: equals-hashcode on var5 and var49", var5.equals(var49) ? var5.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var5
//     assertTrue("Contract failed: equals-hashcode on var49 and var5", var49.equals(var5) ? var49.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var65
//     assertTrue("Contract failed: equals-hashcode on var21 and var65", var21.equals(var65) ? var21.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var21
//     assertTrue("Contract failed: equals-hashcode on var65 and var21", var65.equals(var21) ? var65.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
    double var6 = var5.getRight();
    org.jfree.chart.util.Size2D var9 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
    java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var16 = var15.brighter();
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var18 = var17.getDomainTickBandPaint();
    java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
    java.awt.Font var21 = null;
    java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var25 = var24.brighter();
    org.jfree.chart.text.TextMeasurer var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
    int var30 = var25.getGreen();
    java.awt.Stroke var31 = null;
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
    org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
    java.lang.String var35 = var34.toString();
    java.awt.geom.Rectangle2D var36 = org.jfree.chart.util.RectangleAnchor.createRectangle(var9, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var34);
    java.awt.geom.Rectangle2D var37 = var5.createInsetRectangle(var36);
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var39 = var38.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var40 = var38.getRangeAxis();
    java.lang.Object var41 = var38.clone();
    var38.setDomainZeroBaselineVisible(true);
    java.awt.Color var46 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var47 = var46.brighter();
    var38.setDomainCrosshairPaint((java.awt.Paint)var46);
    org.jfree.chart.util.RectangleEdge var49 = var38.getDomainAxisEdge();
    double var50 = org.jfree.chart.util.RectangleEdge.coordinate(var37, var49);
    org.jfree.chart.plot.PiePlot3D var51 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var52 = var51.getBaseSectionOutlinePaint();
    var51.setInteriorGap(0.0d);
    java.awt.Paint var55 = var51.getBackgroundPaint();
    var51.setSectionOutlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var59 = null;
    org.jfree.chart.plot.PiePlotState var60 = var0.initialise(var4, var37, (org.jfree.chart.plot.PiePlot)var51, (java.lang.Integer)0, var59);
    double var61 = var60.getLatestAngle();
    double var62 = var60.getLatestAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "RectangleAnchor.TOP_LEFT"+ "'", var35.equals("RectangleAnchor.TOP_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 90.0d);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var1.removeLegend();
//     boolean var3 = var1.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var5 = var4.getBaseSectionOutlinePaint();
//     var1.setBackgroundPaint(var5);
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var9 = var7.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var7.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var10);
//     java.awt.Stroke var12 = var7.getBaseSectionOutlineStroke();
//     var1.setBorderStroke(var12);
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Paint var18 = var17.getTickMarkPaint();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var22 = var21.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("hi!", var22);
//     var17.setTickLabelFont((java.lang.Comparable)"hi!", var22);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var26 = var25.getLegendItems();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var28 = var27.getDomainTickBandPaint();
//     java.awt.Stroke var29 = var27.getRangeCrosshairStroke();
//     var25.setOutlineStroke(var29);
//     var25.setLabelGap(100.0d);
//     java.awt.Paint var33 = var25.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var36 = var34.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var34.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     double var41 = var40.getFixedDimension();
//     java.lang.Object var42 = var40.clone();
//     org.jfree.chart.util.RectangleInsets var43 = var40.getLabelInsets();
//     java.awt.Color var46 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var40.setTickMarkPaint((java.awt.Paint)var46);
//     var25.setLabelShadowPaint((java.awt.Paint)var46);
//     org.jfree.chart.text.TextLine var49 = new org.jfree.chart.text.TextLine("", var22, (java.awt.Paint)var46);
//     java.awt.Color var50 = java.awt.Color.getColor("Range[0.0,1.05]", var46);
//     var1.setBackgroundPaint((java.awt.Paint)var50);
//     
//     // Checks the contract:  equals-hashcode on var7 and var34
//     assertTrue("Contract failed: equals-hashcode on var7 and var34", var7.equals(var34) ? var7.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var7
//     assertTrue("Contract failed: equals-hashcode on var34 and var7", var34.equals(var7) ? var34.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    var1.setLabelGap(100.0d);
    java.awt.Paint var9 = var1.getLabelLinkPaint();
    var0.setRangeGridlinePaint(var9);
    java.awt.Paint var11 = var0.getDomainGridlinePaint();
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var0.rendererChanged(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var14.setRenderer(255, var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    int var19 = var14.getIndexOf(var18);
    org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
    var0.setColumnRenderingOrder(var20);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    var23.setRenderer(255, var25);
    org.jfree.chart.LegendItemCollection var27 = var23.getLegendItems();
    org.jfree.chart.axis.AxisLocation var29 = var23.getDomainAxisLocation(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-127), var29, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     var20.setRenderer(255, var22);
//     org.jfree.chart.LegendItemCollection var24 = var20.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var26 = var20.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var27 = var20.getRangeAxisLocation();
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var20.getDomainMarkers((-127), var29);
//     boolean var31 = var20.isRangeZoomable();
//     boolean var32 = var11.equals((java.lang.Object)var20);
//     java.awt.Paint var33 = var20.getRangeCrosshairPaint();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     var34.setRenderer(255, var36);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     int var39 = var34.getIndexOf(var38);
//     org.jfree.chart.util.SortOrder var40 = var34.getColumnRenderingOrder();
//     var20.setRowRenderingOrder(var40);
//     
//     // Checks the contract:  equals-hashcode on var20 and var34
//     assertTrue("Contract failed: equals-hashcode on var20 and var34", var20.equals(var34) ? var20.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var20
//     assertTrue("Contract failed: equals-hashcode on var34 and var20", var34.equals(var20) ? var34.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     int var2 = var0.getRangeAxisCount();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var3.setRangeAxis(100, var6, true);
//     var3.setRangeGridlinesVisible(true);
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var17 = var16.getDomainTickBandPaint();
//     java.awt.Stroke var18 = var16.getRangeCrosshairStroke();
//     java.awt.Font var20 = null;
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.text.TextMeasurer var27 = null;
//     org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, (java.awt.Paint)var24, 0.5f, 1, var27);
//     int var29 = var24.getGreen();
//     java.awt.Stroke var30 = null;
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var14, var18, (java.awt.Paint)var24, var30, 1.0f);
//     var3.addRangeMarker((org.jfree.chart.plot.Marker)var32);
//     boolean var34 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var32);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.PlotOrientation var1 = var0.getOrientation();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    var0.setRadiusGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    boolean var10 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.SeriesRenderingOrder var11 = var0.getSeriesRenderingOrder();
    org.jfree.chart.axis.AxisLocation var12 = var0.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis(10);
    org.jfree.data.category.CategoryDataset var10 = null;
    var0.setDataset(15, var10);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var14 = var13.getVerticalAlignment();
    var13.setWidth(4.0d);
    var13.setPadding(0.025d, Double.NEGATIVE_INFINITY, 0.05d, 4.0d);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    double var23 = var22.getFixedDimension();
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var26 = var24.getSectionPaint((java.lang.Comparable)(short)(-1));
    boolean var27 = var22.hasListener((java.util.EventListener)var24);
    double var28 = var24.getLabelGap();
    java.awt.Graphics2D var29 = null;
    org.jfree.data.general.WaferMapDataset var30 = null;
    org.jfree.chart.plot.WaferMapPlot var31 = new org.jfree.chart.plot.WaferMapPlot(var30);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.util.Size2D var35 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
    java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var42 = var41.brighter();
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var44 = var43.getDomainTickBandPaint();
    java.awt.Stroke var45 = var43.getRangeCrosshairStroke();
    java.awt.Font var47 = null;
    java.awt.Color var50 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var51 = var50.brighter();
    org.jfree.chart.text.TextMeasurer var54 = null;
    org.jfree.chart.text.TextBlock var55 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var51, 0.5f, 1, var54);
    int var56 = var51.getGreen();
    java.awt.Stroke var57 = null;
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var41, var45, (java.awt.Paint)var51, var57, 1.0f);
    org.jfree.chart.util.RectangleAnchor var60 = var59.getLabelAnchor();
    java.lang.String var61 = var60.toString();
    java.awt.geom.Rectangle2D var62 = org.jfree.chart.util.RectangleAnchor.createRectangle(var35, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var60);
    java.awt.geom.Point2D var63 = null;
    org.jfree.chart.plot.PlotState var64 = null;
    org.jfree.chart.plot.PlotRenderingInfo var65 = null;
    var31.draw(var32, var62, var63, var64, var65);
    var24.drawBackgroundImage(var29, var62);
    var13.setBounds(var62);
    java.awt.Paint var69 = var13.getPaint();
    var0.setRangeGridlinePaint(var69);
    org.jfree.chart.annotations.CategoryAnnotation var71 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "RectangleAnchor.TOP_LEFT"+ "'", var61.equals("RectangleAnchor.TOP_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var1 = var0.getTickLabelFont();
    double var2 = var0.getFixedAutoRange();
    var0.setAutoTickUnitSelection(true, true);
    var0.setNegativeArrowVisible(true);
    boolean var8 = var0.isNegativeArrowVisible();
    boolean var9 = var0.isVisible();
    var0.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 0.14d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.5f, 0.0f, 0.05d, 0.5f, 1.0f);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var4 = null;
    var1.setRangeAxis(var4);
    org.jfree.chart.axis.AxisLocation var7 = var1.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var1.setRenderer(var8, false);
    var1.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement();
    var12.clear();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 0.0d, 100.0d);
    var18.clear();
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var12, (org.jfree.chart.block.Arrangement)var18);
    org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    java.awt.Color var30 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var31 = var30.brighter();
    org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var31);
    org.jfree.chart.util.RectangleInsets var33 = var32.getInsets();
    var23.setMargin(var33);
    var21.add((org.jfree.chart.block.Block)var23);
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var37 = var36.getDomainTickBandPaint();
    java.lang.Object var38 = var36.clone();
    var36.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var41 = var36.getAxisOffset();
    double var43 = var41.calculateBottomInset((-1.0d));
    double var44 = var41.getTop();
    double var45 = var41.getRight();
    var21.setPadding(var41);
    java.awt.Graphics2D var47 = null;
    org.jfree.data.Range var49 = null;
    org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(0.0d, var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var51 = var0.arrange(var21, var47, var50);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 4.0d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    double var4 = var3.getFixedDimension();
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var7 = var5.getSectionPaint((java.lang.Comparable)(short)(-1));
    boolean var8 = var3.hasListener((java.util.EventListener)var5);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.setAnchorValue(1.0d);
    var9.setAnchorValue(Double.NEGATIVE_INFINITY, true);
    var3.setPlot((org.jfree.chart.plot.Plot)var9);
    java.awt.Paint var16 = var9.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(100, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    double var21 = var20.getFixedDimension();
    java.lang.Object var22 = var20.clone();
    java.awt.Paint var23 = var20.getTickMarkPaint();
    var0.setRangeGridlinePaint(var23);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var0.getRangeMarkers(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    org.jfree.chart.event.PlotChangeEvent var3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    java.lang.Object var4 = var3.getSource();
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    var3.setChart(var6);
    java.lang.String var8 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotOrientation var1 = var0.getOrientation();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var5 = var4.getBaseSectionOutlinePaint();
//     var4.setInteriorGap(0.0d);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
//     double var10 = var9.getRight();
//     org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var22 = var21.getDomainTickBandPaint();
//     java.awt.Stroke var23 = var21.getRangeCrosshairStroke();
//     java.awt.Font var25 = null;
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     org.jfree.chart.text.TextMeasurer var32 = null;
//     org.jfree.chart.text.TextBlock var33 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var29, 0.5f, 1, var32);
//     int var34 = var29.getGreen();
//     java.awt.Stroke var35 = null;
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var19, var23, (java.awt.Paint)var29, var35, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var38 = var37.getLabelAnchor();
//     java.lang.String var39 = var38.toString();
//     java.awt.geom.Rectangle2D var40 = org.jfree.chart.util.RectangleAnchor.createRectangle(var13, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var38);
//     java.awt.geom.Rectangle2D var41 = var9.createInsetRectangle(var40);
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var43 = var42.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var44 = var42.getRangeAxis();
//     java.lang.Object var45 = var42.clone();
//     var42.setDomainZeroBaselineVisible(true);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var51 = var50.brighter();
//     var42.setDomainCrosshairPaint((java.awt.Paint)var50);
//     org.jfree.chart.util.RectangleEdge var53 = var42.getDomainAxisEdge();
//     double var54 = org.jfree.chart.util.RectangleEdge.coordinate(var41, var53);
//     org.jfree.chart.plot.PiePlot3D var55 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var56 = var55.getBaseSectionOutlinePaint();
//     var55.setInteriorGap(0.0d);
//     java.awt.Paint var59 = var55.getBackgroundPaint();
//     var55.setSectionOutlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     org.jfree.chart.plot.PiePlotState var64 = var4.initialise(var8, var41, (org.jfree.chart.plot.PiePlot)var55, (java.lang.Integer)0, var63);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.setAnchorValue(1.0d);
//     var65.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var73 = var72.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     java.awt.geom.Rectangle2D var77 = null;
//     org.jfree.chart.util.RectangleAnchor var78 = null;
//     java.awt.geom.Point2D var79 = org.jfree.chart.util.RectangleAnchor.coordinates(var77, var78);
//     var72.zoomDomainAxes(0.0d, 10.0d, var76, var79);
//     var65.zoomRangeAxes(0.05d, 0.0d, var71, var79);
//     org.jfree.chart.plot.PlotState var82 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     var0.draw(var3, var41, var79, var82, var83);
//     
//     // Checks the contract:  equals-hashcode on var21 and var72
//     assertTrue("Contract failed: equals-hashcode on var21 and var72", var21.equals(var72) ? var21.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var21
//     assertTrue("Contract failed: equals-hashcode on var72 and var21", var72.equals(var21) ? var72.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var1.setNotify(false);
//     org.jfree.chart.util.RectangleInsets var4 = var1.getPadding();
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getDomainTickBandPaint();
//     java.awt.Stroke var9 = var7.getRangeCrosshairStroke();
//     var6.setBorderStroke(var9);
//     var1.setBorderStroke(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.clearCategoryLabelToolTips();
    var1.setLabel("");
    int var5 = var1.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = var0.getRenderer();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     var4.setRenderer(255, var6);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     int var9 = var4.getIndexOf(var8);
//     org.jfree.chart.util.SortOrder var10 = var4.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var5 = var4.getDomainTickBandPaint();
//     java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
//     var2.setOutlineStroke(var6);
//     var2.setLabelGap(100.0d);
//     java.awt.Paint var10 = var2.getLabelLinkPaint();
//     var1.setRangeGridlinePaint(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var15 = var13.getRangeAxis();
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var13);
//     java.lang.Object var17 = var16.getSource();
//     var12.plotChanged(var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    var0.setAnchorValue(Double.NEGATIVE_INFINITY, true);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var7 = var6.getDomainTickBandPaint();
    java.lang.Object var8 = var6.clone();
    var6.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var11 = var6.getAxisOffset();
    boolean var12 = var6.isRangeZeroBaselineVisible();
    var6.setRangeCrosshairValue(10.0d, true);
    boolean var16 = var6.isDomainGridlinesVisible();
    boolean var17 = var6.isRangeCrosshairLockedOnData();
    boolean var18 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    var19.setRenderer(255, var21);
    org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
    org.jfree.chart.axis.AxisLocation var25 = var19.getDomainAxisLocation(100);
    java.awt.Color var30 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var31 = var30.brighter();
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var33 = var32.getDomainTickBandPaint();
    java.awt.Stroke var34 = var32.getRangeCrosshairStroke();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var40 = var39.brighter();
    org.jfree.chart.text.TextMeasurer var43 = null;
    org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40, 0.5f, 1, var43);
    int var45 = var40.getGreen();
    java.awt.Stroke var46 = null;
    org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var30, var34, (java.awt.Paint)var40, var46, 1.0f);
    org.jfree.chart.util.RectangleAnchor var49 = var48.getLabelAnchor();
    java.awt.Paint var50 = null;
    var48.setOutlinePaint(var50);
    java.awt.Color var55 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 100.0f);
    var48.setOutlinePaint((java.awt.Paint)var55);
    org.jfree.chart.util.Layer var57 = null;
    var19.addRangeMarker(15, (org.jfree.chart.plot.Marker)var48, var57);
    org.jfree.chart.util.Layer var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker((org.jfree.chart.plot.Marker)var48, var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     var0.setAnchorValue(Double.NEGATIVE_INFINITY, true);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getDomainTickBandPaint();
//     java.lang.Object var8 = var6.clone();
//     var6.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var11 = var6.getAxisOffset();
//     boolean var12 = var6.isRangeZeroBaselineVisible();
//     var6.setRangeCrosshairValue(10.0d, true);
//     boolean var16 = var6.isDomainGridlinesVisible();
//     boolean var17 = var6.isRangeCrosshairLockedOnData();
//     boolean var18 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.lang.Object var22 = var20.clone();
//     var20.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var25 = var20.getAxisOffset();
//     boolean var26 = var20.isRangeZeroBaselineVisible();
//     boolean var27 = var20.isRangeCrosshairVisible();
//     org.jfree.chart.event.RendererChangeEvent var28 = null;
//     var20.rendererChanged(var28);
//     boolean var30 = var20.isDomainGridlinesVisible();
//     var20.setNoDataMessage("Multiple Pie Plot");
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var33.setRenderer(255, var35);
//     org.jfree.chart.LegendItemCollection var37 = var33.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var39 = var33.getDomainAxisLocation(100);
//     org.jfree.chart.axis.AxisLocation var40 = var33.getRangeAxisLocation();
//     boolean var41 = var20.equals((java.lang.Object)var40);
//     var0.setDomainAxisLocation(0, var40);
//     
//     // Checks the contract:  equals-hashcode on var8 and var22
//     assertTrue("Contract failed: equals-hashcode on var8 and var22", var8.equals(var22) ? var8.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var8
//     assertTrue("Contract failed: equals-hashcode on var22 and var8", var22.equals(var8) ? var22.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.025d, 0.14d, 0.14d, 10.0d);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.lang.String var2 = var1.getNoDataMessage();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     double var5 = var4.getFixedDimension();
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var8 = var6.getSectionPaint((java.lang.Comparable)(short)(-1));
//     boolean var9 = var4.hasListener((java.util.EventListener)var6);
//     double var10 = var6.getLabelGap();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.general.WaferMapDataset var12 = null;
//     org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getDomainTickBandPaint();
//     java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
//     java.awt.Font var29 = null;
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var33 = var32.brighter();
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, (java.awt.Paint)var33, 0.5f, 1, var36);
//     int var38 = var33.getGreen();
//     java.awt.Stroke var39 = null;
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var23, var27, (java.awt.Paint)var33, var39, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var42 = var41.getLabelAnchor();
//     java.lang.String var43 = var42.toString();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var42);
//     java.awt.geom.Point2D var45 = null;
//     org.jfree.chart.plot.PlotState var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     var13.draw(var14, var44, var45, var46, var47);
//     var6.drawBackgroundImage(var11, var44);
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var51 = var50.getDomainTickBandPaint();
//     java.lang.Object var52 = var50.clone();
//     var50.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var55 = var50.getAxisOffset();
//     boolean var56 = var50.isRangeZeroBaselineVisible();
//     var50.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var60 = var50.getQuadrantOrigin();
//     org.jfree.chart.axis.ValueAxis var61 = var50.getRangeAxis();
//     var50.setRangeGridlinesVisible(false);
//     org.jfree.chart.LegendItemCollection var64 = var50.getFixedLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var69 = var68.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     java.awt.geom.Rectangle2D var73 = null;
//     org.jfree.chart.util.RectangleAnchor var74 = null;
//     java.awt.geom.Point2D var75 = org.jfree.chart.util.RectangleAnchor.coordinates(var73, var74);
//     var68.zoomDomainAxes(0.0d, 10.0d, var72, var75);
//     var50.zoomDomainAxes(0.0d, 0.0d, var67, var75);
//     org.jfree.chart.plot.PlotState var78 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     var1.draw(var3, var44, var75, var78, var79);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    double var3 = var2.getFixedDimension();
    var2.setTickMarksVisible(false);
    java.awt.Stroke var6 = var2.getAxisLineStroke();
    org.jfree.data.Range var9 = new org.jfree.data.Range((-1.0d), 0.0d);
    var2.setRangeWithMargins(var9, true, false);
    double var14 = var9.constrain(0.025d);
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var16 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, var16);
    org.jfree.chart.block.LengthConstraintType var18 = var17.getHeightConstraintType();
    org.jfree.data.Range var22 = new org.jfree.data.Range((-1.0d), 0.0d);
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var24 = null;
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, var24);
    org.jfree.chart.block.LengthConstraintType var26 = var25.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(1.0d, var9, var18, 100.0d, var22, var26);
    org.jfree.data.Range var28 = null;
    org.jfree.data.Range var29 = null;
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var28, var29);
    org.jfree.chart.block.LengthConstraintType var31 = var30.getHeightConstraintType();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    double var34 = var33.getFixedDimension();
    var33.setTickMarksVisible(false);
    java.awt.Stroke var37 = var33.getAxisLineStroke();
    org.jfree.data.Range var40 = new org.jfree.data.Range((-1.0d), 0.0d);
    var33.setRangeWithMargins(var40, true, false);
    org.jfree.data.Range var45 = org.jfree.data.Range.expandToInclude(var40, 0.05d);
    org.jfree.data.Range var47 = org.jfree.data.Range.shift(var45, 1.0d);
    java.lang.String var48 = var47.toString();
    org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D();
    double var51 = var50.getFixedDimension();
    var50.setTickMarksVisible(false);
    java.awt.Stroke var54 = var50.getAxisLineStroke();
    org.jfree.data.Range var57 = new org.jfree.data.Range((-1.0d), 0.0d);
    var50.setRangeWithMargins(var57, true, false);
    double var62 = var57.constrain(0.025d);
    org.jfree.data.Range var63 = null;
    org.jfree.data.Range var64 = null;
    org.jfree.chart.block.RectangleConstraint var65 = new org.jfree.chart.block.RectangleConstraint(var63, var64);
    org.jfree.chart.block.LengthConstraintType var66 = var65.getHeightConstraintType();
    org.jfree.data.Range var70 = new org.jfree.data.Range((-1.0d), 0.0d);
    org.jfree.data.Range var71 = null;
    org.jfree.data.Range var72 = null;
    org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(var71, var72);
    org.jfree.chart.block.LengthConstraintType var74 = var73.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint(1.0d, var57, var66, 100.0d, var70, var74);
    org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint((-1.975d), var9, var31, 0.05d, var47, var66);
    double var77 = var9.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "Range[0.0,1.05]"+ "'", var48.equals("Range[0.0,1.05]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (-1.0d));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
//     var21.setValue(10.0d);
//     java.awt.Paint var28 = var21.getOutlinePaint();
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var33 = var32.brighter();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var35 = var34.getDomainTickBandPaint();
//     java.awt.Stroke var36 = var34.getRangeCrosshairStroke();
//     java.awt.Font var38 = null;
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var42 = var41.brighter();
//     org.jfree.chart.text.TextMeasurer var45 = null;
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var38, (java.awt.Paint)var42, 0.5f, 1, var45);
//     int var47 = var42.getGreen();
//     java.awt.Stroke var48 = null;
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var32, var36, (java.awt.Paint)var42, var48, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var51 = var50.getLabelAnchor();
//     var50.setValue(0.0d);
//     org.jfree.chart.util.LengthAdjustmentType var54 = var50.getLabelOffsetType();
//     var21.setLabelOffsetType(var54);
//     
//     // Checks the contract:  equals-hashcode on var5 and var34
//     assertTrue("Contract failed: equals-hashcode on var5 and var34", var5.equals(var34) ? var5.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var5
//     assertTrue("Contract failed: equals-hashcode on var34 and var5", var34.equals(var5) ? var34.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.util.List var5 = null;
//     var0.drawDomainTickBands(var3, var4, var5);
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     double var9 = var8.getFixedDimension();
//     double var10 = var8.getLowerMargin();
//     var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var8);
//     java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var17 = var16.brighter();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getDomainTickBandPaint();
//     java.awt.Stroke var20 = var18.getRangeCrosshairStroke();
//     java.awt.Font var22 = null;
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var26 = var25.brighter();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var26, 0.5f, 1, var29);
//     int var31 = var26.getGreen();
//     java.awt.Stroke var32 = null;
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var20, (java.awt.Paint)var26, var32, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var36 = var34.getLabelAnchor();
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker)var34, var37);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var1 = null;
//     java.util.Collection var2 = var0.getRangeMarkers(var1);
//     java.util.List var3 = var0.getAnnotations();
//     java.lang.Object var4 = var0.clone();
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var9 = var8.brighter();
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var11 = var10.getDomainTickBandPaint();
//     java.awt.Stroke var12 = var10.getRangeCrosshairStroke();
//     java.awt.Font var14 = null;
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var18 = var17.brighter();
//     org.jfree.chart.text.TextMeasurer var21 = null;
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18, 0.5f, 1, var21);
//     int var23 = var18.getGreen();
//     java.awt.Stroke var24 = null;
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var8, var12, (java.awt.Paint)var18, var24, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var27 = var26.getLabelAnchor();
//     java.awt.Paint var28 = null;
//     var26.setOutlinePaint(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var26.getLabelOffset();
//     boolean var31 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var26);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     var0.setRangeCrosshairValue(10.0d, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     int var11 = var0.indexOf(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setAnchorValue(1.0d);
//     var13.clearDomainAxes();
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var18 = var17.getLabelOutlineStroke();
//     var13.setRangeGridlineStroke(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var23 = var22.getTickMarkStroke();
//     java.awt.Font var25 = var22.getTickLabelFont((java.lang.Comparable)100.0f);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     double var29 = var28.getRight();
//     org.jfree.chart.util.Size2D var32 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var39 = var38.brighter();
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var41 = var40.getDomainTickBandPaint();
//     java.awt.Stroke var42 = var40.getRangeCrosshairStroke();
//     java.awt.Font var44 = null;
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var48 = var47.brighter();
//     org.jfree.chart.text.TextMeasurer var51 = null;
//     org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var44, (java.awt.Paint)var48, 0.5f, 1, var51);
//     int var53 = var48.getGreen();
//     java.awt.Stroke var54 = null;
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var38, var42, (java.awt.Paint)var48, var54, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var57 = var56.getLabelAnchor();
//     java.lang.String var58 = var57.toString();
//     java.awt.geom.Rectangle2D var59 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var57);
//     java.awt.geom.Rectangle2D var60 = var28.createInsetRectangle(var59);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var62 = var61.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var63 = var61.getRangeAxis();
//     java.lang.Object var64 = var61.clone();
//     var61.setDomainZeroBaselineVisible(true);
//     java.awt.Color var69 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var70 = var69.brighter();
//     var61.setDomainCrosshairPaint((java.awt.Paint)var69);
//     org.jfree.chart.util.RectangleEdge var72 = var61.getDomainAxisEdge();
//     double var73 = var22.getCategoryStart(1, (-1), var60, var72);
//     java.awt.geom.Rectangle2D var74 = null;
//     org.jfree.chart.util.RectangleAnchor var75 = null;
//     java.awt.geom.Point2D var76 = org.jfree.chart.util.RectangleAnchor.coordinates(var74, var75);
//     org.jfree.chart.plot.PlotState var77 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var78 = null;
//     var13.draw(var20, var60, var76, var77, var78);
//     var0.drawBackground(var12, var60);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = var1.getLabelDistributor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var10 = var8.getPieLabelRecord(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    var0.setAnchorValue(Double.NEGATIVE_INFINITY, true);
    org.jfree.chart.plot.CategoryMarker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var1 = var0.getTickLabelFont();
//     double var2 = var0.getFixedAutoRange();
//     var0.setAutoTickUnitSelection(true, true);
//     var0.setNegativeArrowVisible(true);
//     boolean var8 = var0.isNegativeArrowVisible();
//     org.jfree.data.Range var11 = new org.jfree.data.Range((-1.0d), 0.0d);
//     var0.setRange(var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var15 = var13.getRangeAxis();
//     java.lang.Object var16 = var13.clone();
//     boolean var17 = var13.isRangeZoomable();
//     org.jfree.data.xy.XYDataset var18 = var13.getDataset();
//     boolean var19 = var0.equals((java.lang.Object)var13);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.awt.Stroke var25 = var23.getRangeCrosshairStroke();
//     var21.setOutlineStroke(var25);
//     var21.setLabelGap(100.0d);
//     java.awt.Paint var29 = var21.getLabelLinkPaint();
//     var20.setRangeGridlinePaint(var29);
//     java.awt.Paint var31 = var20.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Color var36 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var37 = var36.brighter();
//     var33.setAxisLinePaint((java.awt.Paint)var37);
//     var20.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var33);
//     int var40 = var33.getMaximumCategoryLabelLines();
//     boolean var41 = var0.equals((java.lang.Object)var33);
//     
//     // Checks the contract:  equals-hashcode on var13 and var23
//     assertTrue("Contract failed: equals-hashcode on var13 and var23", var13.equals(var23) ? var13.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var13
//     assertTrue("Contract failed: equals-hashcode on var23 and var13", var23.equals(var13) ? var23.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var8 = var7.getDomainTickBandPaint();
    java.awt.Stroke var9 = var7.getRangeCrosshairStroke();
    java.awt.Font var11 = null;
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 0.5f, 1, var18);
    int var20 = var15.getGreen();
    java.awt.Stroke var21 = null;
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var5, var9, (java.awt.Paint)var15, var21, 1.0f);
    org.jfree.chart.util.RectangleAnchor var24 = var23.getLabelAnchor();
    java.awt.Paint var25 = null;
    var23.setOutlinePaint(var25);
    org.jfree.chart.util.RectangleInsets var27 = var23.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var30 = var29.getTickLabelFont();
    org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("hi!", var30);
    var23.setLabelFont(var30);
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var34 = var33.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var35 = var33.getRangeAxis();
    java.lang.Object var36 = var33.clone();
    var33.setDomainZeroBaselineVisible(true);
    java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var42 = var41.brighter();
    var33.setDomainCrosshairPaint((java.awt.Paint)var41);
    var33.setRangeCrosshairValue(1.0d);
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var30, (org.jfree.chart.plot.Plot)var33, false);
    java.awt.Color var54 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var55 = var54.brighter();
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var55);
    org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("hi!", var30, (java.awt.Paint)var55);
    org.jfree.chart.text.TextFragment var58 = null;
    var57.removeFragment(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     var0.setAnchorValue(Double.NEGATIVE_INFINITY, true);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getDomainTickBandPaint();
//     java.awt.Stroke var8 = var6.getRangeCrosshairStroke();
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var0.setRangeAxis(255, var11, true);
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var18 = var17.brighter();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var20 = var19.getDomainTickBandPaint();
//     java.awt.Stroke var21 = var19.getRangeCrosshairStroke();
//     java.awt.Font var23 = null;
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var27 = var26.brighter();
//     org.jfree.chart.text.TextMeasurer var30 = null;
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var27, 0.5f, 1, var30);
//     int var32 = var27.getGreen();
//     java.awt.Stroke var33 = null;
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var17, var21, (java.awt.Paint)var27, var33, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var36 = var35.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var37 = var35.getLabelAnchor();
//     java.awt.Color var40 = java.awt.Color.getColor("hi!", (-1));
//     var35.setLabelPaint((java.awt.Paint)var40);
//     org.jfree.chart.util.Layer var42 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var35, var42);
//     
//     // Checks the contract:  equals-hashcode on var6 and var19
//     assertTrue("Contract failed: equals-hashcode on var6 and var19", var6.equals(var19) ? var6.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var6
//     assertTrue("Contract failed: equals-hashcode on var19 and var6", var19.equals(var6) ? var19.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    var3.setOutlineStroke(var7);
    var3.setLabelGap(100.0d);
    java.awt.Paint var11 = var3.getLabelLinkPaint();
    var2.setRangeGridlinePaint(var11);
    java.awt.Paint var13 = var2.getDomainGridlinePaint();
    boolean var14 = var1.equals((java.lang.Object)var2);
    java.awt.Paint var15 = var2.getRangeGridlinePaint();
    org.jfree.data.category.CategoryDataset var17 = var2.getDataset(15);
    var2.setWeight((-1));
    java.util.List var20 = var2.getCategories();
    double var21 = var2.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    var1.setLabelGap(100.0d);
    java.awt.Paint var9 = var1.getLabelLinkPaint();
    var0.setRangeGridlinePaint(var9);
    org.jfree.chart.plot.CategoryMarker var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    var0.setDomainZeroBaselineVisible(true);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var9 = var8.brighter();
    var0.setDomainCrosshairPaint((java.awt.Paint)var8);
    var0.setRangeCrosshairValue(1.0d);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var0.getRangeMarkers(var13);
    var0.setBackgroundImageAlignment((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     var22.setRangeAxis(var25);
//     org.jfree.chart.axis.AxisLocation var28 = var22.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     var22.setRenderer(var29, false);
//     var22.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement();
//     var33.clear();
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 0.0d, 100.0d);
//     var39.clear();
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var39);
//     org.jfree.chart.block.BlockContainer var42 = var41.getItemContainer();
//     java.awt.Paint var43 = var41.getBackgroundPaint();
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var45 = var44.getBaseSectionOutlinePaint();
//     boolean var46 = var44.getSectionOutlinesVisible();
//     java.awt.Color var49 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var50 = var49.brighter();
//     int var51 = var50.getTransparency();
//     var44.setBaseSectionOutlinePaint((java.awt.Paint)var50);
//     var44.setInteriorGap(0.0d);
//     var20.add((org.jfree.chart.block.Block)var41, (java.lang.Object)0.0d);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    var0.setRangeCrosshairValue((-1.0d), false);
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var11 = var10.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
    var13.removeLegend();
    boolean var15 = var13.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var17 = var16.getBaseSectionOutlinePaint();
    var13.setBackgroundPaint(var17);
    boolean var19 = var10.equals((java.lang.Object)var13);
    java.awt.Color var22 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var10.setLabelPaint((java.awt.Paint)var22);
    var10.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
    var10.setFixedDimension(1.0d);
    java.awt.Font var30 = var10.getTickLabelFont((java.lang.Comparable)0.5f);
    java.awt.Paint var31 = var10.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(4, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.event.RendererChangeEvent var12 = null;
//     var0.rendererChanged(var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(255, var16);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     int var19 = var14.getIndexOf(var18);
//     org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var20);
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var26 = var25.brighter();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var28 = var27.getDomainTickBandPaint();
//     java.awt.Stroke var29 = var27.getRangeCrosshairStroke();
//     java.awt.Font var31 = null;
//     java.awt.Color var34 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var35 = var34.brighter();
//     org.jfree.chart.text.TextMeasurer var38 = null;
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, (java.awt.Paint)var35, 0.5f, 1, var38);
//     int var40 = var35.getGreen();
//     java.awt.Stroke var41 = null;
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var25, var29, (java.awt.Paint)var35, var41, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var44 = var43.getLabelAnchor();
//     java.awt.Paint var45 = null;
//     var43.setOutlinePaint(var45);
//     java.lang.Object var47 = var43.clone();
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var43);
//     
//     // Checks the contract:  equals-hashcode on var3 and var27
//     assertTrue("Contract failed: equals-hashcode on var3 and var27", var3.equals(var27) ? var3.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var3
//     assertTrue("Contract failed: equals-hashcode on var27 and var3", var27.equals(var3) ? var27.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    var0.clear();

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = var1.getInfo();
    org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var23 = var21.getLabelAnchor();
    java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
    var21.setLabelPaint((java.awt.Paint)var26);
    java.awt.Color var34 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(100.0d, 10.0d, 1.0d, 90.0d, (java.awt.Paint)var34);
    java.awt.color.ColorSpace var36 = var34.getColorSpace();
    float[] var39 = new float[] { 1.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var40 = var26.getComponents(var36, var39);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "", "hi!", "hi!");
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "", "hi!", "hi!");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var15);
    java.awt.Image var17 = null;
    var15.setLogo(var17);
    var15.setInfo("Range[-1.0,0.0]");
    java.awt.Font var22 = null;
    java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var26 = var25.brighter();
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var26, 0.5f, 1, var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.text.TextBlockAnchor var34 = null;
    java.awt.Shape var38 = var30.calculateBounds(var31, 0.0f, 10.0f, var34, (-1.0f), 0.5f, Double.NEGATIVE_INFINITY);
    java.awt.Color var44 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var45 = var44.brighter();
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var47 = var46.getDomainTickBandPaint();
    java.awt.Stroke var48 = var46.getRangeCrosshairStroke();
    java.awt.Font var50 = null;
    java.awt.Color var53 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var54 = var53.brighter();
    org.jfree.chart.text.TextMeasurer var57 = null;
    org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var54, 0.5f, 1, var57);
    int var59 = var54.getGreen();
    java.awt.Stroke var60 = null;
    org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var44, var48, (java.awt.Paint)var54, var60, 1.0f);
    org.jfree.chart.util.RectangleAnchor var63 = var62.getLabelAnchor();
    java.awt.Paint var64 = null;
    var62.setOutlinePaint(var64);
    org.jfree.chart.util.RectangleInsets var66 = var62.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var68 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var69 = var68.getTickLabelFont();
    org.jfree.chart.text.TextFragment var70 = new org.jfree.chart.text.TextFragment("hi!", var69);
    var62.setLabelFont(var69);
    org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var73 = var72.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var74 = var72.getRangeAxis();
    java.lang.Object var75 = var72.clone();
    var72.setDomainZeroBaselineVisible(true);
    java.awt.Color var80 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var81 = var80.brighter();
    var72.setDomainCrosshairPaint((java.awt.Paint)var80);
    var72.setRangeCrosshairValue(1.0d);
    org.jfree.chart.JFreeChart var86 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var69, (org.jfree.chart.plot.Plot)var72, false);
    java.awt.Color var93 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var94 = var93.brighter();
    org.jfree.chart.block.BlockBorder var95 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var94);
    org.jfree.chart.text.TextLine var96 = new org.jfree.chart.text.TextLine("hi!", var69, (java.awt.Paint)var94);
    var30.addLine(var96);
    java.util.List var98 = var30.getLines();
    var15.setContributors(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-127), 1, 256);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getDomainTickBandPaint();
//     java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
//     var0.setOutlineStroke(var4);
//     var0.setLabelGap(100.0d);
//     java.awt.Paint var8 = var0.getLabelLinkPaint();
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var11 = var9.getSectionPaint((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     var9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.lang.Object var17 = var15.clone();
//     var15.clearRangeMarkers(100);
//     var15.mapDatasetToRangeAxis(10, 15);
//     int var23 = var15.getRangeAxisCount();
//     boolean var24 = var12.equals((java.lang.Object)var15);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var27 = var26.getTickLabelFont();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var30 = var28.getRangeAxis();
//     java.lang.Object var31 = var28.clone();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("RectangleAnchor.TOP_LEFT", var27, (org.jfree.chart.plot.Plot)var28, true);
//     var28.setWeight(15);
//     boolean var36 = var12.equals((java.lang.Object)15);
//     
//     // Checks the contract:  equals-hashcode on var17 and var31
//     assertTrue("Contract failed: equals-hashcode on var17 and var31", var17.equals(var31) ? var17.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var17
//     assertTrue("Contract failed: equals-hashcode on var31 and var17", var31.equals(var17) ? var31.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(4.0d, 100.0d, 0.05d, 0.14d);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     int var5 = var0.getIndexOf(var4);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var11 = var10.brighter();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getDomainTickBandPaint();
//     java.awt.Stroke var14 = var12.getRangeCrosshairStroke();
//     java.awt.Font var16 = null;
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20, 0.5f, 1, var23);
//     int var25 = var20.getGreen();
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var10, var14, (java.awt.Paint)var20, var26, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var29 = var28.getLabelAnchor();
//     java.awt.Paint var30 = null;
//     var28.setOutlinePaint(var30);
//     org.jfree.chart.util.RectangleInsets var32 = var28.getLabelOffset();
//     var28.setAlpha(0.5f);
//     java.lang.Object var35 = var28.clone();
//     boolean var36 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var28);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 100);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setCopyright("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(100, var3, true);
    var0.setRangeGridlinesVisible(true);
    org.jfree.chart.axis.AxisSpace var8 = null;
    var0.setFixedDomainAxisSpace(var8);
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var14 = var13.brighter();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var16 = var15.getDomainTickBandPaint();
    java.awt.Stroke var17 = var15.getRangeCrosshairStroke();
    java.awt.Font var19 = null;
    java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var23 = var22.brighter();
    org.jfree.chart.text.TextMeasurer var26 = null;
    org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23, 0.5f, 1, var26);
    int var28 = var23.getGreen();
    java.awt.Stroke var29 = null;
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var13, var17, (java.awt.Paint)var23, var29, 1.0f);
    org.jfree.chart.util.RectangleAnchor var32 = var31.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var33 = var31.getLabelAnchor();
    java.awt.Color var36 = java.awt.Color.getColor("hi!", (-1));
    var31.setLabelPaint((java.awt.Paint)var36);
    var0.setNoDataMessagePaint((java.awt.Paint)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     var19.setNotify(false);
//     java.awt.Paint var22 = var19.getBackgroundPaint();
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var24 = var23.getBaseSectionOutlinePaint();
//     boolean var25 = var23.getSectionOutlinesVisible();
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     int var30 = var29.getTransparency();
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var29);
//     boolean var32 = var23.getLabelLinksVisible();
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var35 = var34.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
//     var37.removeLegend();
//     boolean var39 = var37.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var41 = var40.getBaseSectionOutlinePaint();
//     var37.setBackgroundPaint(var41);
//     boolean var43 = var34.equals((java.lang.Object)var37);
//     java.awt.Color var46 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var34.setLabelPaint((java.awt.Paint)var46);
//     var23.setLabelLinkPaint((java.awt.Paint)var46);
//     var19.setItemPaint((java.awt.Paint)var46);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     var50.setRangeAxis(var53);
//     org.jfree.chart.axis.AxisLocation var56 = var50.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     var50.setRenderer(var57, false);
//     var50.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var61 = new org.jfree.chart.block.FlowArrangement();
//     var61.clear();
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.FlowArrangement var67 = new org.jfree.chart.block.FlowArrangement(var63, var64, 0.0d, 100.0d);
//     var67.clear();
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50, (org.jfree.chart.block.Arrangement)var61, (org.jfree.chart.block.Arrangement)var67);
//     org.jfree.chart.block.BlockContainer var70 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var61);
//     var19.setWrapper(var70);
//     
//     // Checks the contract:  equals-hashcode on var0 and var50
//     assertTrue("Contract failed: equals-hashcode on var0 and var50", var0.equals(var50) ? var0.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var0
//     assertTrue("Contract failed: equals-hashcode on var50 and var0", var50.equals(var0) ? var50.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var61
//     assertTrue("Contract failed: equals-hashcode on var11 and var61", var11.equals(var61) ? var11.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var67
//     assertTrue("Contract failed: equals-hashcode on var17 and var67", var17.equals(var67) ? var17.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var11
//     assertTrue("Contract failed: equals-hashcode on var61 and var11", var61.equals(var11) ? var61.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var17
//     assertTrue("Contract failed: equals-hashcode on var67 and var17", var67.equals(var17) ? var67.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    java.awt.Paint var4 = var0.getBackgroundPaint();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var8 = var7.brighter();
    var0.setLabelBackgroundPaint((java.awt.Paint)var8);
    var0.setIgnoreNullValues(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var1.setLabelPaint((java.awt.Paint)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var19 = var18.brighter();
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var21 = var20.getDomainTickBandPaint();
    java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
    java.awt.Font var24 = null;
    java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var28 = var27.brighter();
    org.jfree.chart.text.TextMeasurer var31 = null;
    org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
    int var33 = var28.getGreen();
    java.awt.Stroke var34 = null;
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
    org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
    java.awt.Paint var38 = null;
    var36.setOutlinePaint(var38);
    org.jfree.chart.util.RectangleInsets var40 = var36.getLabelOffset();
    var1.setLabelInsets(var40);
    float var42 = var1.getMaximumCategoryLabelWidthRatio();
    org.jfree.chart.util.RectangleInsets var43 = var1.getLabelInsets();
    int var44 = var1.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = var0.getMaximumDate();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     double var3 = var2.getLabelAngle();
//     org.jfree.chart.axis.DateTickUnit var4 = var2.getTickUnit();
//     var0.setTickUnit(var4);
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var7 = var6.getMaximumDate();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     double var9 = var8.getLabelAngle();
//     org.jfree.chart.axis.DateTickUnit var10 = var8.getTickUnit();
//     var6.setTickUnit(var10);
//     java.util.Date var12 = var0.calculateLowestVisibleTickValue(var10);
//     java.util.Date var13 = var0.getMaximumDate();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets();
//     double var17 = var16.getRight();
//     org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var27 = var26.brighter();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getDomainTickBandPaint();
//     java.awt.Stroke var30 = var28.getRangeCrosshairStroke();
//     java.awt.Font var32 = null;
//     java.awt.Color var35 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var36 = var35.brighter();
//     org.jfree.chart.text.TextMeasurer var39 = null;
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var32, (java.awt.Paint)var36, 0.5f, 1, var39);
//     int var41 = var36.getGreen();
//     java.awt.Stroke var42 = null;
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var26, var30, (java.awt.Paint)var36, var42, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var45 = var44.getLabelAnchor();
//     java.lang.String var46 = var45.toString();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var45);
//     java.awt.geom.Rectangle2D var48 = var16.createInsetRectangle(var47);
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var50 = var49.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var51 = var49.getRangeAxis();
//     java.lang.Object var52 = var49.clone();
//     var49.setDomainZeroBaselineVisible(true);
//     java.awt.Color var57 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var58 = var57.brighter();
//     var49.setDomainCrosshairPaint((java.awt.Paint)var57);
//     org.jfree.chart.util.RectangleEdge var60 = var49.getDomainAxisEdge();
//     double var61 = org.jfree.chart.util.RectangleEdge.coordinate(var48, var60);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     var62.setRenderer(255, var64);
//     org.jfree.chart.util.RectangleEdge var66 = var62.getRangeAxisEdge();
//     java.util.List var67 = var0.refreshTicks(var14, var15, var48, var66);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
    var1.setInteriorGap(0.0d);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    boolean var6 = var1.getDarkerSides();
    java.lang.String var7 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Pie 3D Plot"+ "'", var7.equals("Pie 3D Plot"));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var7 = var6.brighter();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var7);
//     org.jfree.chart.util.RectangleInsets var9 = var8.getInsets();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var13 = var11.getRangeAxis();
//     java.lang.Object var14 = var11.clone();
//     var11.setDomainZeroBaselineVisible(true);
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var20 = var19.brighter();
//     var11.setDomainCrosshairPaint((java.awt.Paint)var19);
//     org.jfree.chart.util.RectangleEdge var22 = var11.getDomainAxisEdge();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets();
//     double var25 = var24.getRight();
//     org.jfree.chart.util.Size2D var28 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var34 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var35 = var34.brighter();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var37 = var36.getDomainTickBandPaint();
//     java.awt.Stroke var38 = var36.getRangeCrosshairStroke();
//     java.awt.Font var40 = null;
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var44 = var43.brighter();
//     org.jfree.chart.text.TextMeasurer var47 = null;
//     org.jfree.chart.text.TextBlock var48 = org.jfree.chart.text.TextUtilities.createTextBlock("", var40, (java.awt.Paint)var44, 0.5f, 1, var47);
//     int var49 = var44.getGreen();
//     java.awt.Stroke var50 = null;
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var34, var38, (java.awt.Paint)var44, var50, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var53 = var52.getLabelAnchor();
//     java.lang.String var54 = var53.toString();
//     java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var28, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var53);
//     java.awt.geom.Rectangle2D var56 = var24.createInsetRectangle(var55);
//     org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var59 = var58.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var60 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var60);
//     var61.removeLegend();
//     boolean var63 = var61.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var64 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var65 = var64.getBaseSectionOutlinePaint();
//     var61.setBackgroundPaint(var65);
//     boolean var67 = var58.equals((java.lang.Object)var61);
//     java.util.List var68 = var61.getSubtitles();
//     var11.drawRangeTickBands(var23, var55, var68);
//     var8.draw(var10, var55);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    double var21 = var20.getFixedDimension();
    java.lang.Object var22 = var20.clone();
    java.awt.Paint var23 = var20.getTickMarkPaint();
    var0.setRangeGridlinePaint(var23);
    org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    var0.setDomainZeroBaselineVisible(true);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var9 = var8.brighter();
    var0.setDomainCrosshairPaint((java.awt.Paint)var8);
    var0.setRangeCrosshairValue(1.0d);
    org.jfree.chart.plot.MultiplePiePlot var13 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    var14.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)1.0d, var14, 100, 255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var20 = var14.getSubtitle(256);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var7 = var0.getDataset();
//     org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxisForDataset(0);
//     var0.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.AxisSpace var12 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var0.handleClick(4, (-1), var15);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isRangeZoomable();
//     int var2 = var0.getSeriesCount();
//     int var3 = var0.getSeriesCount();
//     java.awt.Font var4 = var0.getAngleLabelFont();
//     double var5 = var0.getMaxRadius();
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isRangeZoomable();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var5 = var4.getAngleLabelPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var9 = var8.getDomainTickBandPaint();
//     java.lang.Object var10 = var8.clone();
//     var8.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var13 = var8.getAxisOffset();
//     boolean var14 = var8.isRangeZeroBaselineVisible();
//     var8.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var18 = var8.getQuadrantOrigin();
//     var4.zoomDomainAxes(90.0d, var7, var18);
//     var0.zoomRangeAxes(90.0d, var3, var18);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     int var5 = var0.getIndexOf(var4);
//     java.awt.Paint var6 = var0.getRangeGridlinePaint();
//     double var7 = var0.getRangeCrosshairValue();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var0.setRenderer(256, var9, false);
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var18 = var17.getDomainTickBandPaint();
//     java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
//     java.awt.Font var21 = null;
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.text.TextMeasurer var28 = null;
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, 0.5f, 1, var28);
//     int var30 = var25.getGreen();
//     java.awt.Stroke var31 = null;
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var15, var19, (java.awt.Paint)var25, var31, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLabelAnchor();
//     var33.setValue(0.0d);
//     boolean var37 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var33);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-123));

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     java.awt.Paint var2 = var0.getLabelShadowPaint();
//     java.awt.Paint var4 = var0.getSectionOutlinePaint((java.lang.Comparable)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    java.lang.Object var10 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=255,b=255]", "Multiple Pie Plot", var3);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     var0.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
//     boolean var6 = var0.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var7 = var0.getDataset();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var0.getRenderer(1);
//     boolean var10 = var0.isDomainZeroBaselineVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var0.handleClick(1, (-127), var13);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var3 = var2.getDomainTickBandPaint();
    java.awt.Stroke var4 = var2.getRangeCrosshairStroke();
    var1.setBorderStroke(var4);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var9 = null;
    var6.setRangeAxis(var9);
    org.jfree.chart.axis.AxisLocation var12 = var6.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    var6.setRenderer(var13, false);
    var6.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement();
    var17.clear();
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.FlowArrangement var23 = new org.jfree.chart.block.FlowArrangement(var19, var20, 0.0d, 100.0d);
    var23.clear();
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var23);
    org.jfree.chart.block.BlockContainer var26 = var25.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var27 = var25.getLegendItemGraphicAnchor();
    var1.removeSubtitle((org.jfree.chart.title.Title)var25);
    org.jfree.chart.title.Title var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addSubtitle(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    boolean var1 = var0.isRangeZoomable();
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var3 = var2.getTickLabelFont();
    double var4 = var2.getFixedAutoRange();
    var2.setAutoTickUnitSelection(true, true);
    var2.setAxisLineVisible(false);
    org.jfree.data.Range var10 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAngleLabelPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleAnchor var6 = null;
//     java.awt.geom.Point2D var7 = org.jfree.chart.util.RectangleAnchor.coordinates(var5, var6);
//     var0.zoomDomainAxes(0.0d, 10.0d, var4, var7);
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getDomainTickBandPaint();
//     java.awt.Stroke var16 = var14.getRangeCrosshairStroke();
//     java.awt.Font var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, 0.5f, 1, var25);
//     int var27 = var22.getGreen();
//     java.awt.Stroke var28 = null;
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var12, var16, (java.awt.Paint)var22, var28, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var31 = var30.getLabelAnchor();
//     java.awt.Paint var32 = null;
//     var30.setOutlinePaint(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var30.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var37 = var36.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("hi!", var37);
//     var30.setLabelFont(var37);
//     java.lang.Object var40 = var30.clone();
//     boolean var41 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var30);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var11);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var21.setRangeAxis(var24);
//     org.jfree.chart.axis.AxisLocation var27 = var21.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var21.setRenderer(var28, false);
//     var21.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement();
//     var32.clear();
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, 0.0d, 100.0d);
//     var38.clear();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var38);
//     org.jfree.chart.block.BlockContainer var41 = var40.getItemContainer();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var51 = var50.brighter();
//     org.jfree.chart.block.BlockBorder var52 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var51);
//     org.jfree.chart.util.RectangleInsets var53 = var52.getInsets();
//     var43.setMargin(var53);
//     var41.add((org.jfree.chart.block.Block)var43);
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var57 = var56.getDomainTickBandPaint();
//     java.lang.Object var58 = var56.clone();
//     var56.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var61 = var56.getAxisOffset();
//     double var63 = var61.calculateBottomInset((-1.0d));
//     double var64 = var61.getTop();
//     double var65 = var61.getRight();
//     var41.setPadding(var61);
//     org.jfree.chart.axis.CategoryAxis3D var68 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var69 = var68.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var70 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var70);
//     var71.removeLegend();
//     boolean var73 = var71.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var74 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var75 = var74.getBaseSectionOutlinePaint();
//     var71.setBackgroundPaint(var75);
//     boolean var77 = var68.equals((java.lang.Object)var71);
//     java.awt.Color var80 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var68.setLabelPaint((java.awt.Paint)var80);
//     var68.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
//     var68.setFixedDimension(1.0d);
//     var20.add((org.jfree.chart.block.Block)var41, (java.lang.Object)var68);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var32
//     assertTrue("Contract failed: equals-hashcode on var11 and var32", var11.equals(var32) ? var11.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var38
//     assertTrue("Contract failed: equals-hashcode on var17 and var38", var17.equals(var38) ? var17.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var11
//     assertTrue("Contract failed: equals-hashcode on var32 and var11", var32.equals(var11) ? var32.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var17
//     assertTrue("Contract failed: equals-hashcode on var38 and var17", var38.equals(var17) ? var38.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     var3.setOutlineStroke(var7);
//     var3.setLabelGap(100.0d);
//     java.awt.Paint var11 = var3.getLabelLinkPaint();
//     var2.setRangeGridlinePaint(var11);
//     java.awt.Paint var13 = var2.getDomainGridlinePaint();
//     boolean var14 = var1.equals((java.lang.Object)var2);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var18.setRangeAxis(var21);
//     org.jfree.chart.axis.AxisLocation var24 = var18.getRangeAxisLocation(0);
//     org.jfree.chart.util.RectangleEdge var25 = var18.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     org.jfree.chart.axis.AxisSpace var27 = var1.reserveSpace(var15, (org.jfree.chart.plot.Plot)var16, var17, var25, var26);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeEvent var3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    java.awt.Paint var4 = var1.getBackgroundPaint();
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var10 = var9.brighter();
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, 0.5f, 1, var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 10.0f, var18, (-1.0f), 0.5f, Double.NEGATIVE_INFINITY);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var29 = var28.brighter();
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var31 = var30.getDomainTickBandPaint();
    java.awt.Stroke var32 = var30.getRangeCrosshairStroke();
    java.awt.Font var34 = null;
    java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var38 = var37.brighter();
    org.jfree.chart.text.TextMeasurer var41 = null;
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, (java.awt.Paint)var38, 0.5f, 1, var41);
    int var43 = var38.getGreen();
    java.awt.Stroke var44 = null;
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var28, var32, (java.awt.Paint)var38, var44, 1.0f);
    org.jfree.chart.util.RectangleAnchor var47 = var46.getLabelAnchor();
    java.awt.Paint var48 = null;
    var46.setOutlinePaint(var48);
    org.jfree.chart.util.RectangleInsets var50 = var46.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var53 = var52.getTickLabelFont();
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("hi!", var53);
    var46.setLabelFont(var53);
    org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var57 = var56.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var58 = var56.getRangeAxis();
    java.lang.Object var59 = var56.clone();
    var56.setDomainZeroBaselineVisible(true);
    java.awt.Color var64 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var65 = var64.brighter();
    var56.setDomainCrosshairPaint((java.awt.Paint)var64);
    var56.setRangeCrosshairValue(1.0d);
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var53, (org.jfree.chart.plot.Plot)var56, false);
    java.awt.Color var77 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var78 = var77.brighter();
    org.jfree.chart.block.BlockBorder var79 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var78);
    org.jfree.chart.text.TextLine var80 = new org.jfree.chart.text.TextLine("hi!", var53, (java.awt.Paint)var78);
    var14.addLine(var80);
    org.jfree.chart.util.HorizontalAlignment var82 = var14.getLineAlignment();
    var1.setTextAlignment(var82);
    var1.setExpandToFitSpace(false);
    java.awt.Paint var86 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Stroke var2 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    double var5 = var4.getFixedDimension();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.util.RectangleInsets var7 = var4.getLabelInsets();
    java.awt.Color var10 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var11 = var10.brighter();
    org.jfree.chart.util.ObjectList var13 = new org.jfree.chart.util.ObjectList(100);
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var15 = var14.getLegendItems();
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var17 = var16.getDomainTickBandPaint();
    java.awt.Stroke var18 = var16.getRangeCrosshairStroke();
    var14.setOutlineStroke(var18);
    int var20 = var13.indexOf((java.lang.Object)var18);
    boolean var21 = var10.equals((java.lang.Object)var18);
    var4.setTickMarkStroke(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis)var4, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     boolean var4 = var0.isRangeZoomable();
//     java.lang.Object var5 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var5
//     assertTrue("Contract failed: equals-hashcode on var3 and var5", var3.equals(var5) ? var3.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var3
//     assertTrue("Contract failed: equals-hashcode on var5 and var3", var5.equals(var3) ? var5.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     float var2 = var0.getForegroundAlpha();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.setAnchorValue(1.0d);
//     var5.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var13 = var12.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var17, var18);
//     var12.zoomDomainAxes(0.0d, 10.0d, var16, var19);
//     var5.zoomRangeAxes(0.05d, 0.0d, var11, var19);
//     var0.zoomRangeAxes(0.14d, var4, var19, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var5.setRenderer(255, var7);
//     org.jfree.chart.LegendItemCollection var9 = var5.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
//     org.jfree.chart.util.SortOrder var11 = var5.getColumnRenderingOrder();
//     var0.setRowRenderingOrder(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getLicenceText();
    var0.setName("poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var7 = var0.getDataset();
    boolean var8 = var0.isSubplot();
    var0.mapDatasetToRangeAxis(10, 10);
    org.jfree.chart.util.RectangleEdge var13 = var0.getDomainAxisEdge(10);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var0.zoomDomainAxes(104.0d, var15, var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var4 = var3.getBaseSectionOutlinePaint();
//     var3.setInteriorGap(0.0d);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.RectangleInsets var8 = new org.jfree.chart.util.RectangleInsets();
//     double var9 = var8.getRight();
//     org.jfree.chart.util.Size2D var12 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var19 = var18.brighter();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
//     java.awt.Font var24 = null;
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var28 = var27.brighter();
//     org.jfree.chart.text.TextMeasurer var31 = null;
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, (java.awt.Paint)var28, 0.5f, 1, var31);
//     int var33 = var28.getGreen();
//     java.awt.Stroke var34 = null;
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var18, var22, (java.awt.Paint)var28, var34, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
//     java.lang.String var38 = var37.toString();
//     java.awt.geom.Rectangle2D var39 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var37);
//     java.awt.geom.Rectangle2D var40 = var8.createInsetRectangle(var39);
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var42 = var41.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var43 = var41.getRangeAxis();
//     java.lang.Object var44 = var41.clone();
//     var41.setDomainZeroBaselineVisible(true);
//     java.awt.Color var49 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var50 = var49.brighter();
//     var41.setDomainCrosshairPaint((java.awt.Paint)var49);
//     org.jfree.chart.util.RectangleEdge var52 = var41.getDomainAxisEdge();
//     double var53 = org.jfree.chart.util.RectangleEdge.coordinate(var40, var52);
//     org.jfree.chart.plot.PiePlot3D var54 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var55 = var54.getBaseSectionOutlinePaint();
//     var54.setInteriorGap(0.0d);
//     java.awt.Paint var58 = var54.getBackgroundPaint();
//     var54.setSectionOutlinesVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.plot.PiePlotState var63 = var3.initialise(var7, var40, (org.jfree.chart.plot.PiePlot)var54, (java.lang.Integer)0, var62);
//     boolean var64 = var1.equals((java.lang.Object)var63);
//     org.jfree.chart.util.RectangleInsets var65 = new org.jfree.chart.util.RectangleInsets();
//     double var66 = var65.getRight();
//     org.jfree.chart.util.Size2D var69 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var75 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var76 = var75.brighter();
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var78 = var77.getDomainTickBandPaint();
//     java.awt.Stroke var79 = var77.getRangeCrosshairStroke();
//     java.awt.Font var81 = null;
//     java.awt.Color var84 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var85 = var84.brighter();
//     org.jfree.chart.text.TextMeasurer var88 = null;
//     org.jfree.chart.text.TextBlock var89 = org.jfree.chart.text.TextUtilities.createTextBlock("", var81, (java.awt.Paint)var85, 0.5f, 1, var88);
//     int var90 = var85.getGreen();
//     java.awt.Stroke var91 = null;
//     org.jfree.chart.plot.ValueMarker var93 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var75, var79, (java.awt.Paint)var85, var91, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var94 = var93.getLabelAnchor();
//     java.lang.String var95 = var94.toString();
//     java.awt.geom.Rectangle2D var96 = org.jfree.chart.util.RectangleAnchor.createRectangle(var69, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var94);
//     java.awt.geom.Rectangle2D var97 = var65.createInsetRectangle(var96);
//     var63.setPieArea(var97);
//     
//     // Checks the contract:  equals-hashcode on var12 and var69
//     assertTrue("Contract failed: equals-hashcode on var12 and var69", var12.equals(var69) ? var12.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var12
//     assertTrue("Contract failed: equals-hashcode on var69 and var12", var69.equals(var12) ? var69.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var77
//     assertTrue("Contract failed: equals-hashcode on var20 and var77", var20.equals(var77) ? var20.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var20
//     assertTrue("Contract failed: equals-hashcode on var77 and var20", var77.equals(var20) ? var77.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var93
//     assertTrue("Contract failed: equals-hashcode on var36 and var93", var36.equals(var93) ? var36.hashCode() == var93.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var93 and var36
//     assertTrue("Contract failed: equals-hashcode on var93 and var36", var93.equals(var36) ? var93.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.AbstractPieLabelDistributor var8 = var1.getLabelDistributor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var10 = var8.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    java.awt.Color var29 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var30 = var29.brighter();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var30);
    org.jfree.chart.util.RectangleInsets var32 = var31.getInsets();
    var22.setMargin(var32);
    var20.add((org.jfree.chart.block.Block)var22);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var36 = var35.getDomainTickBandPaint();
    java.lang.Object var37 = var35.clone();
    var35.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var40 = var35.getAxisOffset();
    double var42 = var40.calculateBottomInset((-1.0d));
    double var43 = var40.getTop();
    double var44 = var40.getRight();
    var20.setPadding(var40);
    java.awt.Graphics2D var46 = null;
    org.jfree.data.Range var47 = null;
    org.jfree.data.Range var48 = null;
    org.jfree.chart.block.RectangleConstraint var49 = new org.jfree.chart.block.RectangleConstraint(var47, var48);
    org.jfree.chart.block.RectangleConstraint var51 = var49.toFixedWidth((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var52 = var20.arrange(var46, var51);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var2 = var1.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
    java.lang.Object var4 = var1.clone();
    var1.setDomainZeroBaselineVisible(true);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var10 = var9.brighter();
    var1.setDomainCrosshairPaint((java.awt.Paint)var9);
    var1.setRangeCrosshairValue(1.0d);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var14);
    var15.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)1.0d, var15, 100, 255);
    org.jfree.chart.event.ChartProgressListener var20 = null;
    var15.addProgressListener(var20);
    org.jfree.chart.event.ChartProgressEvent var24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0f), var15, 100, 0);
    org.jfree.chart.JFreeChart var25 = var24.getChart();
    var24.setPercent(0);
    var24.setPercent(10);
    java.lang.String var30 = var24.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1.0]"+ "'", var30.equals("org.jfree.chart.event.ChartProgressEvent[source=-1.0]"));

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(1.0d, 10.0d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotOrientation var1 = var0.getOrientation();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var5 = var4.getDomainTickBandPaint();
//     java.lang.Object var6 = var4.clone();
//     var4.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var9 = var4.getAxisOffset();
//     boolean var10 = var4.isRangeZeroBaselineVisible();
//     var4.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var14 = var4.getQuadrantOrigin();
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = var4.getRenderer();
//     java.awt.geom.Point2D var16 = var4.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.draw(var2, var3, var16, var17, var18);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     var3.setOutlineStroke(var7);
//     var3.setLabelGap(100.0d);
//     java.awt.Paint var11 = var3.getLabelLinkPaint();
//     var2.setRangeGridlinePaint(var11);
//     java.awt.Paint var13 = var2.getDomainGridlinePaint();
//     boolean var14 = var1.equals((java.lang.Object)var2);
//     var2.setRangeGridlinesVisible(true);
//     org.jfree.chart.util.RectangleEdge var18 = var2.getDomainAxisEdge(4);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var20.getRangeMarkers(var21);
//     var20.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var26.setRenderer(255, var28);
//     org.jfree.chart.LegendItemCollection var30 = var26.getLegendItems();
//     var26.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation(15);
//     var20.setRangeAxisLocation(0, var34, true);
//     var2.setRangeAxisLocation(255, var34, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isRangeZoomable();
//     int var2 = var0.getSeriesCount();
//     int var3 = var0.getSeriesCount();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var7 = var6.getAngleLabelPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var11 = var10.getDomainTickBandPaint();
//     java.lang.Object var12 = var10.clone();
//     var10.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var15 = var10.getAxisOffset();
//     boolean var16 = var10.isRangeZeroBaselineVisible();
//     var10.setRangeCrosshairValue(10.0d, true);
//     java.awt.geom.Point2D var20 = var10.getQuadrantOrigin();
//     var6.zoomDomainAxes(90.0d, var9, var20);
//     var0.zoomRangeAxes(2.0d, var5, var20, false);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    int var5 = var0.getIndexOf(var4);
    java.awt.Paint var6 = var0.getRangeGridlinePaint();
    double var7 = var0.getRangeCrosshairValue();
    var0.setWeight((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    var21.setValue(0.0d);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var26 = var25.getDomainTickBandPaint();
    java.lang.Object var27 = var25.clone();
    var25.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var30 = var25.getAxisOffset();
    boolean var31 = var25.isRangeZeroBaselineVisible();
    var25.setRangeCrosshairValue(10.0d, true);
    org.jfree.chart.plot.Plot var35 = var25.getRootPlot();
    java.awt.Paint var36 = var25.getRangeTickBandPaint();
    var21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
//     boolean var12 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     double var14 = var13.getFixedDimension();
//     java.lang.Object var15 = var13.clone();
//     org.jfree.chart.util.RectangleInsets var16 = var13.getLabelInsets();
//     java.awt.Color var19 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var13.setTickMarkPaint((java.awt.Paint)var19);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var22 = var21.getDomainTickBandPaint();
//     java.lang.Object var23 = var21.clone();
//     var21.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var26 = var21.getAxisOffset();
//     boolean var27 = var21.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var28 = var21.getDataset();
//     java.awt.Paint var29 = var21.getRangeZeroBaselinePaint();
//     var13.setTickLabelPaint(var29);
//     boolean var31 = var0.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var3
//     assertTrue("Contract failed: equals-hashcode on var23 and var3", var23.equals(var3) ? var23.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.Layer var1 = null;
    java.util.Collection var2 = var0.getRangeMarkers(var1);
    java.util.List var3 = var0.getAnnotations();
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    var0.setRangeCrosshairValue(10.0d, true);
    java.awt.geom.Point2D var10 = var0.getQuadrantOrigin();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = var0.getRenderer();
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    double var14 = var13.getFixedDimension();
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var17 = var15.getSectionPaint((java.lang.Comparable)(short)(-1));
    boolean var18 = var13.hasListener((java.util.EventListener)var15);
    double var19 = var15.getLabelGap();
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var21 = var20.getBaseSectionOutlinePaint();
    var20.setInteriorGap(0.0d);
    java.awt.Paint var24 = var20.getBackgroundPaint();
    java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var28 = var27.brighter();
    int var29 = var28.getTransparency();
    var20.setLabelOutlinePaint((java.awt.Paint)var28);
    int var31 = var28.getGreen();
    var15.setLabelLinkPaint((java.awt.Paint)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(4, (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 255);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     java.awt.Paint var31 = null;
//     var29.setOutlinePaint(var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 100.0f);
//     var29.setOutlinePaint((java.awt.Paint)var36);
//     org.jfree.chart.util.Layer var38 = null;
//     var0.addRangeMarker(15, (org.jfree.chart.plot.Marker)var29, var38);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     var40.setRenderer(255, var42);
//     org.jfree.chart.LegendItemCollection var44 = var40.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var45 = var40.getDomainAxisLocation();
//     org.jfree.chart.util.SortOrder var46 = var40.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var46);
//     
//     // Checks the contract:  equals-hashcode on var0 and var40
//     assertTrue("Contract failed: equals-hashcode on var0 and var40", var0.equals(var40) ? var0.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var0
//     assertTrue("Contract failed: equals-hashcode on var40 and var0", var40.equals(var0) ? var40.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var44
//     assertTrue("Contract failed: equals-hashcode on var4 and var44", var4.equals(var44) ? var4.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var4
//     assertTrue("Contract failed: equals-hashcode on var44 and var4", var44.equals(var4) ? var44.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    boolean var2 = var0.getSectionOutlinesVisible();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    int var7 = var6.getTransparency();
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var6);
    org.jfree.chart.util.Rotation var9 = var0.getDirection();
    double var10 = var9.getFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     var0.setDomainZeroBaselineVisible(true);
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var9 = var8.brighter();
//     var0.setDomainCrosshairPaint((java.awt.Paint)var8);
//     var0.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.axis.AxisLocation var14 = var0.getRangeAxisLocation(10);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var16.setRenderer(255, var18);
//     org.jfree.chart.LegendItemCollection var20 = var16.getLegendItems();
//     org.jfree.chart.axis.AxisLocation var22 = var16.getDomainAxisLocation(100);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.lang.Object var25 = var23.clone();
//     var23.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var28 = var23.getAxisOffset();
//     boolean var29 = var23.isRangeZeroBaselineVisible();
//     java.awt.Stroke var30 = var23.getOutlineStroke();
//     org.jfree.chart.plot.PlotOrientation var31 = var23.getOrientation();
//     java.lang.Object var32 = null;
//     boolean var33 = var31.equals(var32);
//     org.jfree.chart.util.RectangleEdge var34 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var22, var31);
//     var0.setRangeAxisLocation(0, var22, false);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var2 = var0.getSectionPaint((java.lang.Comparable)(short)(-1));
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    java.awt.Stroke var5 = var0.getBaseSectionOutlineStroke();
    java.awt.Paint var7 = var0.getSectionOutlinePaint((java.lang.Comparable)(-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var4 = var3.getLegendItems();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     var3.setOutlineStroke(var7);
//     var3.setLabelGap(100.0d);
//     java.awt.Paint var11 = var3.getLabelLinkPaint();
//     var2.setRangeGridlinePaint(var11);
//     java.awt.Paint var13 = var2.getDomainGridlinePaint();
//     boolean var14 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var16 = var15.getDomainTickBandPaint();
//     java.awt.Stroke var17 = var15.getRangeCrosshairStroke();
//     var2.setDomainGridlineStroke(var17);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleAnchor var13 = null;
//     java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
//     var7.zoomDomainAxes(0.0d, 10.0d, var11, var14);
//     var0.zoomRangeAxes(0.05d, 0.0d, var6, var14);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var19 = var18.getLegendItems();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getDomainTickBandPaint();
//     java.awt.Stroke var22 = var20.getRangeCrosshairStroke();
//     var18.setOutlineStroke(var22);
//     var18.setLabelGap(100.0d);
//     java.awt.Paint var26 = var18.getLabelLinkPaint();
//     var17.setRangeGridlinePaint(var26);
//     java.awt.Paint var28 = var17.getDomainGridlinePaint();
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var17.rendererChanged(var29);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var31.setRenderer(255, var33);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     int var36 = var31.getIndexOf(var35);
//     org.jfree.chart.util.SortOrder var37 = var31.getColumnRenderingOrder();
//     var17.setColumnRenderingOrder(var37);
//     var0.setColumnRenderingOrder(var37);
//     
//     // Checks the contract:  equals-hashcode on var7 and var20
//     assertTrue("Contract failed: equals-hashcode on var7 and var20", var7.equals(var20) ? var7.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var7
//     assertTrue("Contract failed: equals-hashcode on var20 and var7", var20.equals(var7) ? var20.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var6 = var5.getDomainTickBandPaint();
    java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var13 = var12.brighter();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
    int var18 = var13.getGreen();
    java.awt.Stroke var19 = null;
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    java.awt.Paint var23 = null;
    var21.setOutlinePaint(var23);
    org.jfree.chart.util.RectangleInsets var25 = var21.getLabelOffset();
    var21.setValue(10.0d);
    org.jfree.chart.text.TextAnchor var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setLabelTextAnchor(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var2.clearCategoryLabelToolTips();
//     var2.setLabelToolTip("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var2.setTickLabelsVisible(true);
//     java.awt.Font var8 = var2.getLabelFont();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var10 = var9.getDomainTickBandPaint();
//     java.lang.Object var11 = var9.clone();
//     var9.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var14 = var9.getAxisOffset();
//     boolean var15 = var9.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var16 = var9.getDataset();
//     java.awt.Paint var17 = var9.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var8, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.util.Size2D var20 = var18.calculateDimensions(var19);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
//     boolean var12 = var0.isRangeGridlinesVisible();
//     var0.setDomainCrosshairValue(0.0d);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var16.setRangeAxis(var19);
//     org.jfree.chart.axis.AxisLocation var22 = var16.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     var16.setRenderer(var23, false);
//     var16.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement();
//     var27.clear();
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, 0.0d, 100.0d);
//     var33.clear();
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var27, (org.jfree.chart.block.Arrangement)var33);
//     var35.setNotify(false);
//     java.awt.Paint var38 = var35.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var39 = var35.getLegendItemGraphicPadding();
//     double var41 = var39.extendWidth(100.0d);
//     org.jfree.data.general.WaferMapDataset var42 = null;
//     org.jfree.chart.plot.WaferMapPlot var43 = new org.jfree.chart.plot.WaferMapPlot(var42);
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.util.Size2D var47 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var53 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var54 = var53.brighter();
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var56 = var55.getDomainTickBandPaint();
//     java.awt.Stroke var57 = var55.getRangeCrosshairStroke();
//     java.awt.Font var59 = null;
//     java.awt.Color var62 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var63 = var62.brighter();
//     org.jfree.chart.text.TextMeasurer var66 = null;
//     org.jfree.chart.text.TextBlock var67 = org.jfree.chart.text.TextUtilities.createTextBlock("", var59, (java.awt.Paint)var63, 0.5f, 1, var66);
//     int var68 = var63.getGreen();
//     java.awt.Stroke var69 = null;
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var53, var57, (java.awt.Paint)var63, var69, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var72 = var71.getLabelAnchor();
//     java.lang.String var73 = var72.toString();
//     java.awt.geom.Rectangle2D var74 = org.jfree.chart.util.RectangleAnchor.createRectangle(var47, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var72);
//     java.awt.geom.Point2D var75 = null;
//     org.jfree.chart.plot.PlotState var76 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     var43.draw(var44, var74, var75, var76, var77);
//     java.awt.geom.Rectangle2D var81 = var39.createOutsetRectangle(var74, false, false);
//     org.jfree.chart.plot.PlotRenderingInfo var82 = null;
//     var0.drawAnnotations(var15, var81, var82);
//     
//     // Checks the contract:  equals-hashcode on var55 and var0
//     assertTrue("Contract failed: equals-hashcode on var55 and var0", var55.equals(var0) ? var55.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var55 and var0.", var55.equals(var0) == var0.equals(var55));
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getFixedDimension();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getLabelInsets();
    java.awt.Color var6 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var0.setTickMarkPaint((java.awt.Paint)var6);
    var0.centerRange(4.0d);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var0.java2DToValue((-1.0d), var11, var12);
    var0.setLowerMargin(10.0d);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var18 = var17.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeEvent var19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var17);
    org.jfree.chart.util.RectangleInsets var20 = var17.getMargin();
    var0.setTickLabelInsets(var20);
    var0.setVerticalTickLabels(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.ValueAxis var4 = null;
    var0.setDomainAxis(var4);
    org.jfree.data.xy.XYDataset var6 = null;
    var0.setDataset(var6);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = var0.getRenderer(0);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var14.setRenderer(255, var16);
    org.jfree.chart.LegendItemCollection var18 = var14.getLegendItems();
    org.jfree.chart.axis.AxisLocation var19 = var14.getDomainAxisLocation();
    var0.setDomainAxisLocation(var19, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "", "hi!", "hi!");
    java.awt.Image var11 = null;
    org.jfree.chart.ui.ProjectInfo var15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var11, "", "hi!", "hi!");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var15);
    java.util.List var17 = var15.getContributors();
    var15.setLicenceText("Range[-1.0,0.0]");
    org.jfree.chart.ui.Library[] var20 = var15.getOptionalLibraries();
    java.lang.String var21 = var15.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "hi!"+ "'", var21.equals("hi!"));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var2 = var1.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeEvent var3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    java.awt.Paint var4 = var1.getBackgroundPaint();
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var10 = var9.brighter();
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, 0.5f, 1, var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 10.0f, var18, (-1.0f), 0.5f, Double.NEGATIVE_INFINITY);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var29 = var28.brighter();
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var31 = var30.getDomainTickBandPaint();
    java.awt.Stroke var32 = var30.getRangeCrosshairStroke();
    java.awt.Font var34 = null;
    java.awt.Color var37 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var38 = var37.brighter();
    org.jfree.chart.text.TextMeasurer var41 = null;
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, (java.awt.Paint)var38, 0.5f, 1, var41);
    int var43 = var38.getGreen();
    java.awt.Stroke var44 = null;
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var28, var32, (java.awt.Paint)var38, var44, 1.0f);
    org.jfree.chart.util.RectangleAnchor var47 = var46.getLabelAnchor();
    java.awt.Paint var48 = null;
    var46.setOutlinePaint(var48);
    org.jfree.chart.util.RectangleInsets var50 = var46.getLabelOffset();
    org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.Font var53 = var52.getTickLabelFont();
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("hi!", var53);
    var46.setLabelFont(var53);
    org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var57 = var56.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var58 = var56.getRangeAxis();
    java.lang.Object var59 = var56.clone();
    var56.setDomainZeroBaselineVisible(true);
    java.awt.Color var64 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var65 = var64.brighter();
    var56.setDomainCrosshairPaint((java.awt.Paint)var64);
    var56.setRangeCrosshairValue(1.0d);
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var53, (org.jfree.chart.plot.Plot)var56, false);
    java.awt.Color var77 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var78 = var77.brighter();
    org.jfree.chart.block.BlockBorder var79 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var78);
    org.jfree.chart.text.TextLine var80 = new org.jfree.chart.text.TextLine("hi!", var53, (java.awt.Paint)var78);
    var14.addLine(var80);
    org.jfree.chart.util.HorizontalAlignment var82 = var14.getLineAlignment();
    var1.setTextAlignment(var82);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var86 = var85.getVerticalAlignment();
    org.jfree.chart.block.FlowArrangement var89 = new org.jfree.chart.block.FlowArrangement(var82, var86, 0.14d, 0.0d);
    org.jfree.chart.plot.PiePlot3D var90 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var91 = var90.getBaseSectionOutlinePaint();
    boolean var92 = var90.getSectionOutlinesVisible();
    var90.setIgnoreZeroValues(true);
    boolean var95 = var86.equals((java.lang.Object)var90);
    double var96 = var90.getLabelGap();
    var90.setCircular(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.025d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     var0.setDomainAxis(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     var0.setDataset(var6);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var9, true);
//     boolean var12 = var9.getAutoRangeIncludesZero();
//     boolean var13 = var9.isNegativeArrowVisible();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     double var15 = var14.getFixedDimension();
//     java.lang.Object var16 = var14.clone();
//     org.jfree.chart.util.RectangleInsets var17 = var14.getLabelInsets();
//     java.awt.Color var20 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var14.setTickMarkPaint((java.awt.Paint)var20);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var23 = var22.getDomainTickBandPaint();
//     java.lang.Object var24 = var22.clone();
//     var22.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var27 = var22.getAxisOffset();
//     boolean var28 = var22.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var29 = var22.getDataset();
//     java.awt.Paint var30 = var22.getRangeZeroBaselinePaint();
//     var14.setTickLabelPaint(var30);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var33 = var32.getTickLabelFont();
//     double var34 = var32.getFixedAutoRange();
//     var32.setAutoTickUnitSelection(true, true);
//     var32.setNegativeArrowVisible(true);
//     boolean var40 = var32.isNegativeArrowVisible();
//     org.jfree.data.Range var43 = new org.jfree.data.Range((-1.0d), 0.0d);
//     var32.setRange(var43);
//     var14.setRangeWithMargins(var43);
//     var9.setRange(var43);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var0.", var22.equals(var0) == var0.equals(var22));
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.5f, 1, var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    java.awt.Shape var17 = var9.calculateBounds(var10, 0.0f, 1.0f, var13, 10.0f, 0.5f, 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3, true);
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var7 = var6.getBaseSectionOutlinePaint();
//     var6.setInteriorGap(0.0d);
//     java.awt.Paint var10 = var6.getLabelShadowPaint();
//     var6.setStartAngle((-1.0d));
//     java.awt.Paint var13 = var6.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var13);
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.awt.Stroke var16 = var15.getNextOutlineStroke();
//     var0.setDomainGridlineStroke(var16);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var0.handleClick((-1), 1, var20);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.block.BlockContainer var20 = var19.getItemContainer();
//     java.lang.Object var21 = var20.clone();
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     java.lang.Object var25 = var20.draw(var22, var23, (java.lang.Object)var24);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var1.removeLegend();
//     int var3 = var1.getBackgroundImageAlignment();
//     boolean var4 = var1.isBorderVisible();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets();
//     double var7 = var6.getRight();
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var17 = var16.brighter();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getDomainTickBandPaint();
//     java.awt.Stroke var20 = var18.getRangeCrosshairStroke();
//     java.awt.Font var22 = null;
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var26 = var25.brighter();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var26, 0.5f, 1, var29);
//     int var31 = var26.getGreen();
//     java.awt.Stroke var32 = null;
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var20, (java.awt.Paint)var26, var32, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getLabelAnchor();
//     java.lang.String var36 = var35.toString();
//     java.awt.geom.Rectangle2D var37 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var35);
//     java.awt.geom.Rectangle2D var38 = var6.createInsetRectangle(var37);
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     var1.draw(var5, var37, var39);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var1.removeLegend();
    int var3 = var1.getBackgroundImageAlignment();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var6 = var1.createBufferedImage(0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.Paint var1 = var0.getAngleLabelPaint();
//     boolean var2 = var0.isAngleGridlinesVisible();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     double var4 = var3.getLabelAngle();
//     org.jfree.chart.axis.DateTickUnit var5 = var3.getTickUnit();
//     var0.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var5);
//     double var7 = var0.getMaxRadius();
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    var0.clearDomainAxes();
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.removeLegend();
    boolean var7 = var5.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var9 = var8.getBaseSectionOutlinePaint();
    var5.setBackgroundPaint(var9);
    var0.setRangeGridlinePaint(var9);
    org.jfree.chart.plot.PlotOrientation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=0.05, height=0.025]");

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var6 = var5.brighter();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getDomainTickBandPaint();
//     java.awt.Stroke var9 = var7.getRangeCrosshairStroke();
//     java.awt.Font var11 = null;
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 0.5f, 1, var18);
//     int var20 = var15.getGreen();
//     java.awt.Stroke var21 = null;
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var5, var9, (java.awt.Paint)var15, var21, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var24 = var23.getLabelAnchor();
//     java.awt.Paint var25 = null;
//     var23.setOutlinePaint(var25);
//     org.jfree.chart.util.RectangleInsets var27 = var23.getLabelOffset();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var30 = var29.getTickLabelFont();
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("hi!", var30);
//     var23.setLabelFont(var30);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var34 = var33.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var35 = var33.getRangeAxis();
//     java.lang.Object var36 = var33.clone();
//     var33.setDomainZeroBaselineVisible(true);
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var42 = var41.brighter();
//     var33.setDomainCrosshairPaint((java.awt.Paint)var41);
//     var33.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", var30, (org.jfree.chart.plot.Plot)var33, false);
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var55 = var54.brighter();
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, (-1.0d), 0.05d, (java.awt.Paint)var55);
//     org.jfree.chart.text.TextLine var57 = new org.jfree.chart.text.TextLine("hi!", var30, (java.awt.Paint)var55);
//     org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("Range[0.0,1.05]");
//     var57.addFragment(var59);
//     org.jfree.chart.text.TextFragment var61 = var57.getLastTextFragment();
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.util.Size2D var63 = var57.calculateDimensions(var62);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var1 = var0.getBaseSectionOutlinePaint();
    var0.setInteriorGap(0.0d);
    java.awt.Paint var4 = var0.getLabelShadowPaint();
    boolean var5 = var0.getSectionOutlinesVisible();
    java.awt.Paint var6 = var0.getLabelLinkPaint();
    org.jfree.chart.urls.PieURLGenerator var7 = var0.getURLGenerator();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var12 = var11.brighter();
    org.jfree.chart.util.ObjectList var14 = new org.jfree.chart.util.ObjectList(100);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var18 = var17.getDomainTickBandPaint();
    java.awt.Stroke var19 = var17.getRangeCrosshairStroke();
    var15.setOutlineStroke(var19);
    int var21 = var14.indexOf((java.lang.Object)var19);
    boolean var22 = var11.equals((java.lang.Object)var19);
    var0.setSectionPaint((java.lang.Comparable)"null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.awt.Paint)var11);
    int var24 = var11.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var2 = var1.isBorderVisible();
    var1.setTextAntiAlias(false);
    org.jfree.chart.event.ChartChangeListener var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addChangeListener(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(255, var2);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(100);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis(10);
    java.awt.Paint var9 = var0.getDomainGridlinePaint();
    java.awt.Stroke var10 = var0.getDomainGridlineStroke();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var14 = null;
    var11.setRangeAxis(var14);
    org.jfree.chart.axis.AxisLocation var17 = var11.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    var11.setRenderer(var18, false);
    var11.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement();
    var22.clear();
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement(var24, var25, 0.0d, 100.0d);
    var28.clear();
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11, (org.jfree.chart.block.Arrangement)var22, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    double var32 = var31.getFixedDimension();
    java.lang.Object var33 = var31.clone();
    java.awt.Paint var34 = var31.getTickMarkPaint();
    var11.setRangeGridlinePaint(var34);
    var0.setDomainGridlinePaint(var34);
    org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
    double var39 = var38.getFixedDimension();
    var38.resizeRange(0.05d, (-1.0d));
    java.awt.Paint var43 = var38.getTickMarkPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-127), (org.jfree.chart.axis.ValueAxis)var38, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(255, var2);
//     org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
//     java.util.Iterator var5 = var4.iterator();
//     int var6 = var4.getItemCount();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     var7.setFixedLegendItems(var9);
//     var4.addAll(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("Range[0.0,1.05]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var3 = null;
//     float var4 = var1.calculateBaselineOffset(var2, var3);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("0,0,0,0,0,0,0,0,0,0,0,0", var1);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var1 = var0.getTickLabelFont();
//     double var2 = var0.getFixedAutoRange();
//     var0.setAutoTickUnitSelection(true, true);
//     var0.setNegativeArrowVisible(true);
//     boolean var8 = var0.isNegativeArrowVisible();
//     org.jfree.data.Range var11 = new org.jfree.data.Range((-1.0d), 0.0d);
//     var0.setRange(var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var15 = var13.getRangeAxis();
//     java.lang.Object var16 = var13.clone();
//     boolean var17 = var13.isRangeZoomable();
//     org.jfree.data.xy.XYDataset var18 = var13.getDataset();
//     boolean var19 = var0.equals((java.lang.Object)var13);
//     boolean var20 = var0.isInverted();
//     var0.zoomRange(0.0d, 4.0d);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var27 = var25.getRangeAxis();
//     java.lang.Object var28 = var25.clone();
//     var25.setDomainZeroBaselineVisible(true);
//     java.awt.Color var33 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var34 = var33.brighter();
//     var25.setDomainCrosshairPaint((java.awt.Paint)var33);
//     org.jfree.chart.util.RectangleEdge var36 = var25.getDomainAxisEdge();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets();
//     double var39 = var38.getRight();
//     org.jfree.chart.util.Size2D var42 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var48 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var49 = var48.brighter();
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var51 = var50.getDomainTickBandPaint();
//     java.awt.Stroke var52 = var50.getRangeCrosshairStroke();
//     java.awt.Font var54 = null;
//     java.awt.Color var57 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var58 = var57.brighter();
//     org.jfree.chart.text.TextMeasurer var61 = null;
//     org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("", var54, (java.awt.Paint)var58, 0.5f, 1, var61);
//     int var63 = var58.getGreen();
//     java.awt.Stroke var64 = null;
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var48, var52, (java.awt.Paint)var58, var64, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var67 = var66.getLabelAnchor();
//     java.lang.String var68 = var67.toString();
//     java.awt.geom.Rectangle2D var69 = org.jfree.chart.util.RectangleAnchor.createRectangle(var42, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var67);
//     java.awt.geom.Rectangle2D var70 = var38.createInsetRectangle(var69);
//     org.jfree.chart.axis.CategoryAxis3D var72 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var73 = var72.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var74 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var74);
//     var75.removeLegend();
//     boolean var77 = var75.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var78 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var79 = var78.getBaseSectionOutlinePaint();
//     var75.setBackgroundPaint(var79);
//     boolean var81 = var72.equals((java.lang.Object)var75);
//     java.util.List var82 = var75.getSubtitles();
//     var25.drawRangeTickBands(var37, var69, var82);
//     org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var85 = var84.getDomainTickBandPaint();
//     java.lang.Object var86 = var84.clone();
//     var84.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var89 = var84.getAxisOffset();
//     boolean var90 = var84.isRangeZeroBaselineVisible();
//     org.jfree.data.xy.XYDataset var91 = var84.getDataset();
//     org.jfree.chart.axis.ValueAxis var93 = var84.getRangeAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var94 = var84.getRangeAxisEdge();
//     double var95 = var0.java2DToValue(100.0d, var69, var94);
//     
//     // Checks the contract:  equals-hashcode on var13 and var50
//     assertTrue("Contract failed: equals-hashcode on var13 and var50", var13.equals(var50) ? var13.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var84
//     assertTrue("Contract failed: equals-hashcode on var13 and var84", var13.equals(var84) ? var13.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var13
//     assertTrue("Contract failed: equals-hashcode on var50 and var13", var50.equals(var13) ? var50.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var84
//     assertTrue("Contract failed: equals-hashcode on var50 and var84", var50.equals(var84) ? var50.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var13
//     assertTrue("Contract failed: equals-hashcode on var84 and var13", var84.equals(var13) ? var84.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var50
//     assertTrue("Contract failed: equals-hashcode on var84 and var50", var84.equals(var50) ? var84.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var28
//     assertTrue("Contract failed: equals-hashcode on var16 and var28", var16.equals(var28) ? var16.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var86
//     assertTrue("Contract failed: equals-hashcode on var16 and var86", var16.equals(var86) ? var16.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var16
//     assertTrue("Contract failed: equals-hashcode on var28 and var16", var28.equals(var16) ? var28.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var86
//     assertTrue("Contract failed: equals-hashcode on var28 and var86", var28.equals(var86) ? var28.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var16
//     assertTrue("Contract failed: equals-hashcode on var86 and var16", var86.equals(var16) ? var86.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var28
//     assertTrue("Contract failed: equals-hashcode on var86 and var28", var86.equals(var28) ? var86.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var4 = var3.getDomainTickBandPaint();
    java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
    var1.setOutlineStroke(var5);
    org.jfree.chart.util.Rotation var7 = var1.getDirection();
    var0.setDirection(var7);
    double var9 = var7.getFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getGPL();
    java.lang.String var2 = var0.getGPL();

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, 3.0d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    double var20 = var0.getAnchorValue();
    java.awt.Image var21 = null;
    var0.setBackgroundImage(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(1.0d);
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(var3);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7, false);
    var0.clearRangeMarkers();
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
    var11.clear();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
    var17.clear();
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    double var21 = var20.getFixedDimension();
    java.lang.Object var22 = var20.clone();
    java.awt.Paint var23 = var20.getTickMarkPaint();
    var0.setRangeGridlinePaint(var23);
    org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-123), var27, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
    var1.setInteriorGap(0.0d);
    java.awt.Paint var5 = var1.getLabelShadowPaint();
    boolean var6 = var1.getSectionOutlinesVisible();
    java.awt.Paint var7 = var1.getLabelLinkPaint();
    java.awt.Stroke var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    var9.setRenderer(255, var11);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    org.jfree.chart.axis.AxisLocation var15 = var9.getDomainAxisLocation(100);
    java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var21 = var20.brighter();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var23 = var22.getDomainTickBandPaint();
    java.awt.Stroke var24 = var22.getRangeCrosshairStroke();
    java.awt.Font var26 = null;
    java.awt.Color var29 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var30 = var29.brighter();
    org.jfree.chart.text.TextMeasurer var33 = null;
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, (java.awt.Paint)var30, 0.5f, 1, var33);
    int var35 = var30.getGreen();
    java.awt.Stroke var36 = null;
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var20, var24, (java.awt.Paint)var30, var36, 1.0f);
    org.jfree.chart.util.RectangleAnchor var39 = var38.getLabelAnchor();
    java.awt.Paint var40 = null;
    var38.setOutlinePaint(var40);
    java.awt.Color var45 = java.awt.Color.getHSBColor((-1.0f), 100.0f, 100.0f);
    var38.setOutlinePaint((java.awt.Paint)var45);
    org.jfree.chart.util.Layer var47 = null;
    var9.addRangeMarker(15, (org.jfree.chart.plot.Marker)var38, var47);
    java.awt.Color var52 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 100.0f);
    var38.setLabelPaint((java.awt.Paint)var52);
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var55 = var54.getBackgroundPaint();
    java.awt.Stroke var56 = var54.getDomainGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.2d, var7, var8, (java.awt.Paint)var52, var56, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.event.RendererChangeEvent var12 = null;
//     var0.rendererChanged(var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(255, var16);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     int var19 = var14.getIndexOf(var18);
//     org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var20);
//     org.jfree.chart.LegendItemCollection var22 = var0.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var1.setLabelPaint((java.awt.Paint)var13);
    var1.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
    java.awt.Font var19 = var1.getTickLabelFont((java.lang.Comparable)"Pie 3D Plot");
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var24 = var23.getDomainTickBandPaint();
    java.awt.Stroke var25 = var23.getRangeCrosshairStroke();
    var21.setOutlineStroke(var25);
    var21.setLabelGap(100.0d);
    java.awt.Paint var29 = var21.getLabelLinkPaint();
    var20.setRangeGridlinePaint(var29);
    java.awt.Paint var31 = var20.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Color var36 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var37 = var36.brighter();
    var33.setAxisLinePaint((java.awt.Paint)var37);
    var20.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var33);
    int var40 = var33.getMaximumCategoryLabelLines();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"Pie 3D Plot", (java.lang.Object)var33);
    java.lang.String var42 = var33.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     var19.setNotify(false);
//     java.awt.Paint var22 = var19.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var23 = var19.getLegendItemGraphicPadding();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var25 = var24.getDomainTickBandPaint();
//     java.lang.Object var26 = var24.clone();
//     var24.clearRangeMarkers(100);
//     org.jfree.chart.util.RectangleInsets var29 = var24.getAxisOffset();
//     double var30 = var29.getBottom();
//     var19.setLegendItemGraphicPadding(var29);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     var32.setRangeAxis(var35);
//     org.jfree.chart.axis.AxisLocation var38 = var32.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     var32.setRenderer(var39, false);
//     var32.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement();
//     var43.clear();
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.FlowArrangement var49 = new org.jfree.chart.block.FlowArrangement(var45, var46, 0.0d, 100.0d);
//     var49.clear();
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32, (org.jfree.chart.block.Arrangement)var43, (org.jfree.chart.block.Arrangement)var49);
//     var51.setNotify(false);
//     java.awt.Paint var54 = var51.getBackgroundPaint();
//     org.jfree.chart.util.RectangleInsets var55 = var51.getLegendItemGraphicPadding();
//     double var57 = var55.extendWidth(100.0d);
//     org.jfree.data.general.WaferMapDataset var58 = null;
//     org.jfree.chart.plot.WaferMapPlot var59 = new org.jfree.chart.plot.WaferMapPlot(var58);
//     java.awt.Graphics2D var60 = null;
//     org.jfree.chart.util.Size2D var63 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var69 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var70 = var69.brighter();
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var72 = var71.getDomainTickBandPaint();
//     java.awt.Stroke var73 = var71.getRangeCrosshairStroke();
//     java.awt.Font var75 = null;
//     java.awt.Color var78 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var79 = var78.brighter();
//     org.jfree.chart.text.TextMeasurer var82 = null;
//     org.jfree.chart.text.TextBlock var83 = org.jfree.chart.text.TextUtilities.createTextBlock("", var75, (java.awt.Paint)var79, 0.5f, 1, var82);
//     int var84 = var79.getGreen();
//     java.awt.Stroke var85 = null;
//     org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var69, var73, (java.awt.Paint)var79, var85, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var88 = var87.getLabelAnchor();
//     java.lang.String var89 = var88.toString();
//     java.awt.geom.Rectangle2D var90 = org.jfree.chart.util.RectangleAnchor.createRectangle(var63, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var88);
//     java.awt.geom.Point2D var91 = null;
//     org.jfree.chart.plot.PlotState var92 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var93 = null;
//     var59.draw(var60, var90, var91, var92, var93);
//     java.awt.geom.Rectangle2D var97 = var55.createOutsetRectangle(var90, false, false);
//     java.awt.geom.Rectangle2D var98 = var29.createOutsetRectangle(var97);
//     
//     // Checks the contract:  equals-hashcode on var0 and var32
//     assertTrue("Contract failed: equals-hashcode on var0 and var32", var0.equals(var32) ? var0.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var0
//     assertTrue("Contract failed: equals-hashcode on var32 and var0", var32.equals(var0) ? var32.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var43
//     assertTrue("Contract failed: equals-hashcode on var11 and var43", var11.equals(var43) ? var11.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var49
//     assertTrue("Contract failed: equals-hashcode on var17 and var49", var17.equals(var49) ? var17.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var11
//     assertTrue("Contract failed: equals-hashcode on var43 and var11", var43.equals(var11) ? var43.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var17
//     assertTrue("Contract failed: equals-hashcode on var49 and var17", var49.equals(var17) ? var49.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var71
//     assertTrue("Contract failed: equals-hashcode on var24 and var71", var24.equals(var71) ? var24.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var24
//     assertTrue("Contract failed: equals-hashcode on var71 and var24", var71.equals(var24) ? var71.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var3, "", "hi!", "hi!");
    java.util.List var8 = var7.getContributors();
    var7.setLicenceName("hi!");
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", var14, "", "hi!", "hi!");
    java.util.List var19 = var18.getContributors();
    java.lang.String var20 = var18.getInfo();
    var7.addLibrary((org.jfree.chart.ui.Library)var18);
    var18.setLicenceText("Multiple Pie Plot");
    org.jfree.chart.ui.Library[] var24 = var18.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "hi!"+ "'", var20.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var5 = var0.getAxisOffset();
    boolean var6 = var0.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var7 = var0.getDataset();
    org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxisForDataset(0);
    var0.setRangeCrosshairValue(3.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getWidthConstraintType();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var9);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1, var5, 0.0d, var7, var11);
    org.jfree.chart.plot.MultiplePiePlot var13 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    boolean var15 = var11.equals((java.lang.Object)var13);
    org.jfree.data.category.CategoryDataset var16 = null;
    var13.setDataset(var16);
    org.jfree.chart.util.TableOrder var18 = var13.getDataExtractOrder();
    org.jfree.data.category.CategoryDataset var19 = var13.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var1.removeLegend();
    int var3 = var1.getBackgroundImageAlignment();
    var1.setBorderVisible(false);
    boolean var6 = var1.isNotify();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var8 = var7.getDomainTickBandPaint();
    java.lang.Object var9 = var7.clone();
    var7.clearRangeMarkers(100);
    org.jfree.chart.util.RectangleInsets var12 = var7.getAxisOffset();
    boolean var13 = var7.isRangeZeroBaselineVisible();
    boolean var14 = var7.isRangeCrosshairVisible();
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var7.rendererChanged(var15);
    boolean var17 = var7.isDomainGridlinesVisible();
    var7.clearDomainMarkers();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAntiAlias((java.lang.Object)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)90.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isRangeZoomable();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Font var3 = var2.getTickLabelFont();
//     double var4 = var2.getFixedAutoRange();
//     var2.setAutoTickUnitSelection(true, true);
//     var2.setAxisLineVisible(false);
//     org.jfree.data.Range var10 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     double var12 = var11.getFixedDimension();
//     java.lang.Object var13 = var11.clone();
//     java.awt.Paint var14 = var11.getTickMarkPaint();
//     var0.setAngleLabelPaint(var14);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setAnchorValue(1.0d);
//     var18.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var31);
//     var25.zoomDomainAxes(0.0d, 10.0d, var29, var32);
//     var18.zoomRangeAxes(0.05d, 0.0d, var24, var32);
//     var0.zoomRangeAxes(3.0d, var17, var32);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
    java.lang.Object var3 = var0.clone();
    var0.setDomainZeroBaselineVisible(true);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var9 = var8.brighter();
    var0.setDomainCrosshairPaint((java.awt.Paint)var8);
    var0.setRangeCrosshairValue(1.0d);
    var0.mapDatasetToDomainAxis(15, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var12.setRenderer(255, var14);
//     org.jfree.chart.LegendItemCollection var16 = var12.getLegendItems();
//     java.util.Iterator var17 = var16.iterator();
//     int var18 = var16.getItemCount();
//     var0.setFixedLegendItems(var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    var0.setRangeAxis(100, var3, true);
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var7 = var6.getBaseSectionOutlinePaint();
    var6.setInteriorGap(0.0d);
    java.awt.Paint var10 = var6.getLabelShadowPaint();
    var6.setStartAngle((-1.0d));
    java.awt.Paint var13 = var6.getLabelLinkPaint();
    var0.setRangeGridlinePaint(var13);
    org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Stroke var16 = var15.getNextOutlineStroke();
    var0.setDomainGridlineStroke(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var19 = var0.getQuadrantPaint(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     double var5 = var4.getFixedDimension();
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var8 = var6.getSectionPaint((java.lang.Comparable)(short)(-1));
//     boolean var9 = var4.hasListener((java.util.EventListener)var6);
//     double var10 = var6.getLabelGap();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.general.WaferMapDataset var12 = null;
//     org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D(10.0d, 0.05d);
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var26 = var25.getDomainTickBandPaint();
//     java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
//     java.awt.Font var29 = null;
//     java.awt.Color var32 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var33 = var32.brighter();
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, (java.awt.Paint)var33, 0.5f, 1, var36);
//     int var38 = var33.getGreen();
//     java.awt.Stroke var39 = null;
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var23, var27, (java.awt.Paint)var33, var39, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var42 = var41.getLabelAnchor();
//     java.lang.String var43 = var42.toString();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, var42);
//     java.awt.geom.Point2D var45 = null;
//     org.jfree.chart.plot.PlotState var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     var13.draw(var14, var44, var45, var46, var47);
//     var6.drawBackgroundImage(var11, var44);
//     var0.drawBackground(var3, var44);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("Pie 3D Plot");

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getMargin();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var21.setRangeAxis(var24);
//     org.jfree.chart.axis.AxisLocation var27 = var21.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var21.setRenderer(var28, false);
//     var21.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement();
//     var32.clear();
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, 0.0d, 100.0d);
//     var38.clear();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var38);
//     java.awt.Color var44 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var45 = var44.brighter();
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var47 = var46.getDomainTickBandPaint();
//     java.awt.Stroke var48 = var46.getRangeCrosshairStroke();
//     java.awt.Font var50 = null;
//     java.awt.Color var53 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var54 = var53.brighter();
//     org.jfree.chart.text.TextMeasurer var57 = null;
//     org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("", var50, (java.awt.Paint)var54, 0.5f, 1, var57);
//     int var59 = var54.getGreen();
//     java.awt.Stroke var60 = null;
//     org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var44, var48, (java.awt.Paint)var54, var60, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var63 = var62.getLabelAnchor();
//     boolean var65 = var63.equals((java.lang.Object)100.0f);
//     var40.setLegendItemGraphicLocation(var63);
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var68 = var67.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var69 = var67.getRangeAxis();
//     java.lang.Object var70 = var67.clone();
//     var67.setDomainZeroBaselineVisible(true);
//     java.awt.Color var75 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var76 = var75.brighter();
//     var67.setDomainCrosshairPaint((java.awt.Paint)var75);
//     org.jfree.chart.util.RectangleEdge var78 = var67.getDomainAxisEdge();
//     boolean var79 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var78);
//     var40.setLegendItemGraphicEdge(var78);
//     org.jfree.chart.LegendItemSource[] var81 = var40.getSources();
//     var19.setSources(var81);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var32
//     assertTrue("Contract failed: equals-hashcode on var11 and var32", var11.equals(var32) ? var11.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var38
//     assertTrue("Contract failed: equals-hashcode on var17 and var38", var17.equals(var38) ? var17.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var11
//     assertTrue("Contract failed: equals-hashcode on var32 and var11", var32.equals(var11) ? var32.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var17
//     assertTrue("Contract failed: equals-hashcode on var38 and var17", var38.equals(var17) ? var38.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    var4.removeLegend();
    boolean var6 = var4.getAntiAlias();
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var8 = var7.getBaseSectionOutlinePaint();
    var4.setBackgroundPaint(var8);
    boolean var10 = var1.equals((java.lang.Object)var4);
    java.awt.Color var13 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
    var1.setLabelPaint((java.awt.Paint)var13);
    var1.addCategoryLabelToolTip((java.lang.Comparable)(short)100, "");
    var1.setFixedDimension(1.0d);
    java.lang.Comparable var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var23 = var22.getBaseSectionOutlinePaint();
    boolean var24 = var22.getSectionOutlinesVisible();
    java.awt.Color var27 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var28 = var27.brighter();
    int var29 = var28.getTransparency();
    var22.setBaseSectionOutlinePaint((java.awt.Paint)var28);
    var21.setDomainTickBandPaint((java.awt.Paint)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelPaint(var20, (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getDomainTickBandPaint();
    java.lang.Object var2 = var0.clone();
    var0.clearRangeMarkers(100);
    var0.clearDomainMarkers(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=100.0,l=100.0,b=-1.0,r=0.05]", "hi!", "ThreadContext", "RectangleAnchor.TOP_LEFT", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    var1.setPadding(10.0d, 10.0d, (-1.975d), 10.0d);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT");
    org.jfree.chart.util.VerticalAlignment var9 = var8.getVerticalAlignment();
    org.jfree.chart.event.TitleChangeEvent var10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var8);
    java.awt.Paint var11 = var8.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var12 = var8.getMargin();
    var1.setMargin(var12);
    java.lang.Object var14 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("poly", var1);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getDomainTickBandPaint();
//     java.awt.Stroke var7 = var5.getRangeCrosshairStroke();
//     java.awt.Font var9 = null;
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var13 = var12.brighter();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, 0.5f, 1, var16);
//     int var18 = var13.getGreen();
//     java.awt.Stroke var19 = null;
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var7, (java.awt.Paint)var13, var19, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
//     java.awt.Paint var23 = null;
//     var21.setOutlinePaint(var23);
//     java.lang.Class var25 = null;
//     java.util.EventListener[] var26 = var21.getListeners(var25);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.util.List var5 = null;
//     var0.drawDomainTickBands(var3, var4, var5);
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     double var9 = var8.getFixedDimension();
//     double var10 = var8.getLowerMargin();
//     var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var8);
//     java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var17 = var16.brighter();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var19 = var18.getDomainTickBandPaint();
//     java.awt.Stroke var20 = var18.getRangeCrosshairStroke();
//     java.awt.Font var22 = null;
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var26 = var25.brighter();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var26, 0.5f, 1, var29);
//     int var31 = var26.getGreen();
//     java.awt.Stroke var32 = null;
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var16, var20, (java.awt.Paint)var26, var32, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getLabelAnchor();
//     java.awt.Paint var36 = null;
//     var34.setOutlinePaint(var36);
//     java.lang.Object var38 = var34.clone();
//     java.awt.Stroke var39 = var34.getStroke();
//     org.jfree.chart.util.Layer var40 = null;
//     var0.addRangeMarker(4, (org.jfree.chart.plot.Marker)var34, var40);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var0.", var18.equals(var0) == var0.equals(var18));
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     double var1 = var0.getFixedDimension();
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var4 = var2.getSectionPaint((java.lang.Comparable)(short)(-1));
//     boolean var5 = var0.hasListener((java.util.EventListener)var2);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setAnchorValue(1.0d);
//     var6.setAnchorValue(Double.NEGATIVE_INFINITY, true);
//     var0.setPlot((org.jfree.chart.plot.Plot)var6);
//     var6.clearRangeMarkers(0);
//     var6.clearRangeMarkers();
//     var6.configureRangeAxes();
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var22 = var21.brighter();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var24 = var23.getDomainTickBandPaint();
//     java.awt.Stroke var25 = var23.getRangeCrosshairStroke();
//     java.awt.Font var27 = null;
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var31 = var30.brighter();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var31, 0.5f, 1, var34);
//     int var36 = var31.getGreen();
//     java.awt.Stroke var37 = null;
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var21, var25, (java.awt.Paint)var31, var37, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var40 = var39.getLabelAnchor();
//     java.awt.Paint var41 = null;
//     var39.setOutlinePaint(var41);
//     java.awt.Stroke var43 = var39.getStroke();
//     org.jfree.chart.util.Layer var44 = null;
//     boolean var45 = var6.removeDomainMarker(255, (org.jfree.chart.plot.Marker)var39, var44);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getDomainTickBandPaint();
//     float var2 = var0.getForegroundAlpha();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var6 = var5.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var7 = var5.getRangeAxis();
//     java.lang.Object var8 = var5.clone();
//     var5.setDomainZeroBaselineVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setAnchorValue(1.0d);
//     var13.clearDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var21 = var20.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
//     var20.zoomDomainAxes(0.0d, 10.0d, var24, var27);
//     var13.zoomRangeAxes(0.05d, 0.0d, var19, var27);
//     var5.zoomDomainAxes(0.05d, var12, var27);
//     var0.zoomRangeAxes(4.0d, var4, var27, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    var1.addCategoryLabelToolTip((java.lang.Comparable)(byte)10, "RectangleAnchor.TOP_LEFT");
    var1.setCategoryLabelPositionOffset((-123));
    var1.setMaximumCategoryLabelLines((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = var0.getRendererForDataset(var1);
    boolean var3 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getRangeAxis();
//     java.lang.Object var3 = var0.clone();
//     var0.setDomainZeroBaselineVisible(true);
//     var0.setRangeCrosshairVisible(true);
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var12 = var11.brighter();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var14 = var13.getDomainTickBandPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var21 = var20.brighter();
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, 0.5f, 1, var24);
//     int var26 = var21.getGreen();
//     java.awt.Stroke var27 = null;
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var11, var15, (java.awt.Paint)var21, var27, 1.0f);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getLabelAnchor();
//     java.awt.Paint var31 = null;
//     var29.setOutlinePaint(var31);
//     java.lang.Object var33 = var29.clone();
//     org.jfree.chart.util.Layer var34 = null;
//     boolean var35 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var29, var34);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var4 = var3.getDomainTickBandPaint();
//     java.awt.Stroke var5 = var3.getRangeCrosshairStroke();
//     var1.setOutlineStroke(var5);
//     var1.setLabelGap(100.0d);
//     java.awt.Paint var9 = var1.getLabelLinkPaint();
//     var0.setRangeGridlinePaint(var9);
//     java.awt.Paint var11 = var0.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var17 = var16.brighter();
//     var13.setAxisLinePaint((java.awt.Paint)var17);
//     var0.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var13);
//     java.lang.Object var20 = var0.clone();
//     var0.zoom(0.12d);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(1.0d);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(var3);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7, false);
//     var0.clearRangeMarkers();
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement();
//     var11.clear();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 0.0d, 100.0d);
//     var17.clear();
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var11, (org.jfree.chart.block.Arrangement)var17);
//     var19.setNotify(false);
//     java.awt.Paint var22 = var19.getBackgroundPaint();
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var24 = var23.getBaseSectionOutlinePaint();
//     boolean var25 = var23.getSectionOutlinesVisible();
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var29 = var28.brighter();
//     int var30 = var29.getTransparency();
//     var23.setBaseSectionOutlinePaint((java.awt.Paint)var29);
//     boolean var32 = var23.getLabelLinksVisible();
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var35 = var34.getTickMarkStroke();
//     org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
//     var37.removeLegend();
//     boolean var39 = var37.getAntiAlias();
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Paint var41 = var40.getBaseSectionOutlinePaint();
//     var37.setBackgroundPaint(var41);
//     boolean var43 = var34.equals((java.lang.Object)var37);
//     java.awt.Color var46 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", 0);
//     var34.setLabelPaint((java.awt.Paint)var46);
//     var23.setLabelLinkPaint((java.awt.Paint)var46);
//     var19.setItemPaint((java.awt.Paint)var46);
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var52 = var51.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var53 = var51.getRangeAxis();
//     java.lang.Object var54 = var51.clone();
//     var51.setDomainZeroBaselineVisible(true);
//     java.awt.Color var59 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var60 = var59.brighter();
//     var51.setDomainCrosshairPaint((java.awt.Paint)var59);
//     var51.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var64 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var64);
//     var65.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var69 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)1.0d, var65, 100, 255);
//     org.jfree.chart.event.ChartProgressListener var70 = null;
//     var65.addProgressListener(var70);
//     org.jfree.chart.event.ChartProgressEvent var74 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0f), var65, 100, 0);
//     var65.setBackgroundImageAlpha(1.0f);
//     var19.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var65);
//     
//     // Checks the contract:  equals-hashcode on var36 and var64
//     assertTrue("Contract failed: equals-hashcode on var36 and var64", var36.equals(var64) ? var36.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var36
//     assertTrue("Contract failed: equals-hashcode on var64 and var36", var64.equals(var36) ? var64.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", var1);
// 
//   }

}
