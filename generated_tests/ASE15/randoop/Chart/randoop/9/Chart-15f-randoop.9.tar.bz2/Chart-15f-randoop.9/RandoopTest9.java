
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    double var6 = var5.getWidth();
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("", var1);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 10.0d, 100.0d, var3);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setNoDataMessageFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var3.toUnconstrainedWidth();
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]"+ "'", var5.equals("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]"));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.Marker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var7 = var4.removeRangeMarker(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var3.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var5 = var3.getWidthConstraintType();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]"+ "'", var6.equals("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]"));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setBounds(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    java.awt.Paint var7 = var4.getDomainGridlinePaint();
    var4.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var4 = var3.getUpArrow();
//     var1.setDownArrow(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     int var13 = var11.indexOf(var12);
//     float var14 = var11.getBackgroundImageAlpha();
//     var11.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var18 = var11.getDomainAxis(0);
//     var11.setDomainGridlinesVisible(true);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     org.jfree.chart.axis.AxisSpace var23 = null;
//     org.jfree.chart.axis.AxisSpace var24 = var1.reserveSpace(var6, (org.jfree.chart.plot.Plot)var11, var21, var22, var23);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    var4.clear();

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
//     java.awt.Color var4 = var3.brighter();
//     java.awt.color.ColorSpace var5 = null;
//     float[] var6 = new float[] { };
//     float[] var7 = var3.getColorComponents(var5, var6);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var4 = var3.brighter();
    int var5 = var4.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    int var4 = var3.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0d, 1.0f, 100.0f);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerMargin(1.0d);
    java.awt.Shape var4 = var1.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var4.drawAnnotations(var10, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     int var20 = var18.indexOf(var19);
//     float var21 = var18.getBackgroundImageAlpha();
//     var18.clearDomainMarkers(0);
//     var18.clearAnnotations();
//     int var25 = var18.getDomainAxisCount();
//     boolean var26 = var18.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     var18.setRenderer(0, var28, true);
//     org.jfree.chart.axis.AxisSpace var31 = var18.getFixedRangeAxisSpace();
//     var18.configureRangeAxes();
//     org.jfree.chart.event.RendererChangeEvent var33 = null;
//     var18.rendererChanged(var33);
//     var4.setParent((org.jfree.chart.plot.Plot)var18);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", var1, 10.0f, (-1.0f), var4, 0.0d, var6);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    boolean var16 = var4.isDomainZeroBaselineVisible();
    java.awt.Stroke var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeCrosshairStroke(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    double var6 = var5.getWidth();
    var5.setHeight((-1.0d));
    double var9 = var5.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", var3);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var4.getRenderer(0);
    java.awt.Paint var8 = var4.getBackgroundPaint();
    var4.setNoDataMessage("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    var4.setDomainCrosshairValue((-1.0d), true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)100.0f, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setLowerMargin(1.0d);
    org.jfree.data.Range var18 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    int var20 = var4.getIndexOf(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     var4.clearAnnotations();
//     int var11 = var4.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
//     boolean var14 = var12.equals((java.lang.Object)0.0f);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var17 = var16.getUpArrow();
//     boolean var18 = var12.equals((java.lang.Object)var16);
//     java.util.Date var19 = null;
//     java.util.Date var20 = null;
//     var16.setRange(var19, var20);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     boolean var4 = var1.equals((java.lang.Object)"");
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     float var7 = var1.calculateBaselineOffset(var5, var6);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 10.0d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    var1.setNegativeArrowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var4 = var3.getUpArrow();
    var1.setDownArrow(var4);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement(var7, var8, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var11);
    double var13 = var12.getWidth();
    java.awt.geom.Rectangle2D var14 = var12.getBounds();
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var1.valueToJava2D((-1.0d), var14, var15);
    var1.setLowerMargin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var4.drawAnnotations(var10, var11, var12);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var4.zoomRangeAxes(0.0d, var15, var16, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var4.drawAnnotations(var10, var11, var12);
    boolean var15 = var4.equals((java.lang.Object)0.0d);
    org.jfree.chart.axis.ValueAxis var16 = var4.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var18 = var4.getDomainAxisLocation(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
    var4.setName("");
    var4.addOptionalLibrary("hi!");
    var4.setName("hi!");

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    double var6 = var5.getWidth();
    var5.setHeight((-1.0d));
    java.awt.Graphics2D var9 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, var11);
    org.jfree.chart.block.RectangleConstraint var13 = var12.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var14 = var13.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var15 = var13.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var16 = var5.arrange(var9, var13);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     double var6 = var5.getWidth();
//     java.awt.geom.Rectangle2D var7 = var5.getBounds();
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement(var8, var9, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     java.lang.Object var14 = var13.clone();
//     double var15 = var13.getContentXOffset();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     int var22 = var20.indexOf(var21);
//     float var23 = var20.getBackgroundImageAlpha();
//     var20.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var20.getDomainAxis(0);
//     var20.setDomainGridlinesVisible(true);
//     boolean var30 = var13.equals((java.lang.Object)var20);
//     var13.clear();
//     boolean var32 = var5.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    org.jfree.chart.plot.Marker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var4.removeRangeMarker(0, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    org.jfree.chart.event.RendererChangeEvent var19 = null;
    var4.rendererChanged(var19);
    java.awt.Stroke var21 = var4.getOutlineStroke();
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var26 = var25.getUpArrow();
    var23.setDownArrow(var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    int var34 = var32.indexOf(var33);
    float var35 = var32.getBackgroundImageAlpha();
    var32.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var39 = var32.getDomainAxis(0);
    var32.setDomainGridlinesVisible(true);
    java.awt.Color var45 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var32.setRangeCrosshairPaint((java.awt.Paint)var45);
    var23.setTickMarkPaint((java.awt.Paint)var45);
    var4.setNoDataMessagePaint((java.awt.Paint)var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeZeroBaselineVisible(true);
    org.jfree.chart.axis.ValueAxis var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxis((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    var4.setDomainCrosshairValue(10.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 100.0d, false);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    java.awt.Paint var6 = var4.getAngleGridlinePaint();
    java.awt.Paint var7 = var4.getRadiusGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisLocation var11 = null;
    var4.setRangeAxisLocation(10, var11, false);
    int var14 = var4.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    java.awt.Color var10 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var11 = var10.brighter();
    var1.setTickLabelPaint((java.awt.Paint)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var6.indexOf(var7);
    float var9 = var6.getBackgroundImageAlpha();
    var6.clearDomainMarkers(0);
    java.awt.Font var12 = var6.getNoDataMessageFont();
    java.awt.Color var16 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var17 = var16.brighter();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16, 100.0f, var19);
    java.awt.Paint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("", var12, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1, var1, var2);
    org.jfree.chart.JFreeChart var4 = var3.getChart();
    java.lang.Object var5 = var3.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
//     java.lang.Object var8 = var7.clone();
//     double var9 = var7.getContentXOffset();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     int var16 = var14.indexOf(var15);
//     float var17 = var14.getBackgroundImageAlpha();
//     var14.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var21 = var14.getDomainAxis(0);
//     var14.setDomainGridlinesVisible(true);
//     boolean var24 = var7.equals((java.lang.Object)var14);
//     java.awt.Stroke var25 = var14.getDomainGridlineStroke();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     int var33 = var31.indexOf(var32);
//     float var34 = var31.getBackgroundImageAlpha();
//     var31.clearDomainMarkers(0);
//     var31.clearAnnotations();
//     int var38 = var31.getDomainAxisCount();
//     boolean var39 = var31.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     var31.setRenderer(0, var41, true);
//     org.jfree.chart.axis.AxisSpace var44 = var31.getFixedRangeAxisSpace();
//     var31.configureRangeAxes();
//     org.jfree.chart.event.RendererChangeEvent var46 = null;
//     var31.rendererChanged(var46);
//     java.awt.Stroke var48 = var31.getOutlineStroke();
//     var1.setTickMarkStroke(var48);
//     
//     // Checks the contract:  equals-hashcode on var14 and var31
//     assertTrue("Contract failed: equals-hashcode on var14 and var31", var14.equals(var31) ? var14.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var14
//     assertTrue("Contract failed: equals-hashcode on var31 and var14", var31.equals(var14) ? var31.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 100.0d, 0.0d);
    boolean var6 = var4.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    boolean var5 = var2.isTickLabelsVisible();
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRange(var6, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedRangeAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var4.getRenderer(0);
//     java.awt.Paint var8 = var4.getBackgroundPaint();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var4.drawBackground(var9, var10);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var17 = var16.getUpArrow();
//     var14.setDownArrow(var17);
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.FlowArrangement var24 = new org.jfree.chart.block.FlowArrangement(var20, var21, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var25 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var24);
//     double var26 = var25.getWidth();
//     java.awt.geom.Rectangle2D var27 = var25.getBounds();
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var14.valueToJava2D((-1.0d), var27, var28);
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var34);
//     double var36 = var35.getWidth();
//     java.awt.geom.Rectangle2D var37 = var35.getBounds();
//     org.jfree.chart.util.RectangleAnchor var38 = null;
//     java.awt.geom.Point2D var39 = org.jfree.chart.util.RectangleAnchor.coordinates(var37, var38);
//     org.jfree.chart.plot.PlotState var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var4.draw(var12, var27, var39, var40, var41);
//     
//     // Checks the contract:  equals-hashcode on var24 and var34
//     assertTrue("Contract failed: equals-hashcode on var24 and var34", var24.equals(var34) ? var24.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var24
//     assertTrue("Contract failed: equals-hashcode on var34 and var24", var34.equals(var24) ? var34.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var35
//     assertTrue("Contract failed: equals-hashcode on var25 and var35", var25.equals(var35) ? var25.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var25
//     assertTrue("Contract failed: equals-hashcode on var35 and var25", var35.equals(var25) ? var35.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 10.0f, var4, 100.0d, 0.0f, 0.0f);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    boolean var5 = var2.isTickLabelsVisible();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    boolean var6 = var5.isEmpty();
    double var7 = var5.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var1.setTickUnit(var7);
    double var9 = var1.getFixedAutoRange();
    var1.setLowerMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    java.awt.Color var17 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var4.setRangeCrosshairPaint((java.awt.Paint)var17);
    org.jfree.chart.axis.AxisSpace var19 = null;
    var4.setFixedRangeAxisSpace(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeZeroBaselineVisible(true);
    org.jfree.chart.LegendItemCollection var16 = var4.getFixedLegendItems();
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var21);
    java.lang.Object var23 = var22.clone();
    double var24 = var22.getContentXOffset();
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    int var31 = var29.indexOf(var30);
    float var32 = var29.getBackgroundImageAlpha();
    var29.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var36 = var29.getDomainAxis(0);
    var29.setDomainGridlinesVisible(true);
    boolean var39 = var22.equals((java.lang.Object)var29);
    java.awt.Stroke var40 = var29.getDomainGridlineStroke();
    org.jfree.chart.plot.PlotOrientation var41 = var29.getOrientation();
    var4.setOrientation(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisLocation var11 = null;
    var4.setRangeAxisLocation(10, var11, false);
    double var14 = var4.getRangeCrosshairValue();
    var4.clearRangeAxes();
    java.awt.Paint var16 = var4.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    double var16 = var12.trimWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.LegendItemCollection var8 = var4.getFixedLegendItems();
    var4.setOutlineVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var4.zoomDomainAxes(10.0d, var12, var13, true);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var4.getRangeMarkers(var16);
    org.jfree.chart.axis.ValueAxis var18 = var4.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker((-1), var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.chart.plot.PlotOrientation var5 = var4.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setLowerMargin(1.0d);
    org.jfree.data.Range var18 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    java.lang.String var19 = var15.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var4.getRenderer(0);
    java.awt.Paint var8 = var4.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    org.jfree.chart.axis.ValueAxis[] var11 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var4.setDomainAxes(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.xy.XYDataset var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDataset((-33), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.plot.Marker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var6.removeRangeMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    boolean var7 = var4.isRangeZoomable();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var4.datasetChanged(var8);
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var4.axisChanged(var10);
    java.awt.Image var12 = null;
    var4.setBackgroundImage(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
    var4.setCopyright("");
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    java.lang.String var8 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    double var6 = var1.getFixedDimension();
    double var7 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", var1);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    var1.clear();

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.FlowArrangement var14 = new org.jfree.chart.block.FlowArrangement(var10, var11, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var14);
//     double var16 = var15.getWidth();
//     java.awt.geom.Rectangle2D var17 = var15.getBounds();
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     var8.draw(var9, var17, var18);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
//     java.awt.Color var4 = var3.brighter();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     org.jfree.data.xy.XYDataset var10 = null;
//     int var11 = var9.indexOf(var10);
//     float var12 = var9.getBackgroundImageAlpha();
//     var9.clearDomainMarkers(0);
//     var9.clearAnnotations();
//     int var16 = var9.getDomainAxisCount();
//     boolean var17 = var9.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var9.setRenderer(0, var19, true);
//     org.jfree.chart.axis.AxisSpace var22 = var9.getFixedRangeAxisSpace();
//     var9.configureRangeAxes();
//     org.jfree.chart.event.RendererChangeEvent var24 = null;
//     var9.rendererChanged(var24);
//     java.awt.Stroke var26 = var9.getOutlineStroke();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     int var33 = var31.indexOf(var32);
//     float var34 = var31.getBackgroundImageAlpha();
//     var31.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var38 = var31.getDomainAxis(0);
//     var31.setDomainGridlinesVisible(true);
//     var31.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var43 = null;
//     var31.setFixedDomainAxisSpace(var43, true);
//     org.jfree.chart.util.RectangleEdge var47 = var31.getDomainAxisEdge(10);
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     int var54 = var52.indexOf(var53);
//     float var55 = var52.getBackgroundImageAlpha();
//     var52.clearDomainMarkers(0);
//     var52.clearAnnotations();
//     int var59 = var52.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var60 = var52.getAxisOffset();
//     boolean var62 = var60.equals((java.lang.Object)0.0f);
//     org.jfree.chart.util.UnitType var63 = var60.getUnitType();
//     var31.setInsets(var60);
//     org.jfree.chart.block.LineBorder var65 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var4, var26, var60);
//     
//     // Checks the contract:  equals-hashcode on var9 and var52
//     assertTrue("Contract failed: equals-hashcode on var9 and var52", var9.equals(var52) ? var9.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var9
//     assertTrue("Contract failed: equals-hashcode on var52 and var9", var52.equals(var9) ? var52.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    org.jfree.chart.plot.Plot var19 = var4.getRootPlot();
    boolean var20 = var4.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.LegendItemCollection var8 = var4.getFixedLegendItems();
//     int var9 = var4.getDomainAxisCount();
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     boolean var12 = var4.removeDomainMarker(var10, var11);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    java.lang.Object var2 = var1.clone();
    boolean var3 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var1.setTickUnit(var7);
    var1.setAxisLineVisible(false);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("hi!");
    var12.setLowerMargin(1.0d);
    double var15 = var12.getUpperMargin();
    java.util.Date var16 = var12.getMaximumDate();
    var1.setMinimumDate(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    java.awt.Stroke var7 = var6.getRangeCrosshairStroke();
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var6.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var1.clearCategoryLabelToolTips();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     int var10 = var8.indexOf(var9);
//     float var11 = var8.getBackgroundImageAlpha();
//     var8.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var15 = var8.getDomainAxis(0);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     int var23 = var21.indexOf(var22);
//     float var24 = var21.getBackgroundImageAlpha();
//     var21.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var28 = var21.getDomainAxis(0);
//     var21.setDomainGridlinesVisible(true);
//     var21.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var33 = null;
//     var21.setFixedDomainAxisSpace(var33, true);
//     org.jfree.chart.util.RectangleEdge var37 = var21.getDomainAxisEdge(10);
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     org.jfree.chart.axis.AxisSpace var39 = var1.reserveSpace(var3, (org.jfree.chart.plot.Plot)var8, var16, var37, var38);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var1.clearCategoryLabelToolTips();
    var1.setMaximumCategoryLabelWidthRatio(100.0f);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.Marker var6 = null;
//     org.jfree.chart.util.Layer var7 = null;
//     boolean var8 = var4.removeDomainMarker(100, var6, var7);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    org.jfree.data.xy.XYDataset var23 = null;
    int var24 = var22.indexOf(var23);
    float var25 = var22.getBackgroundImageAlpha();
    var22.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var29 = var22.getDomainAxis(0);
    var22.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setLowerMargin(1.0d);
    org.jfree.data.Range var36 = var22.getDataRange((org.jfree.chart.axis.ValueAxis)var33);
    java.awt.Color var40 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var33.setTickLabelPaint((java.awt.Paint)var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setQuadrantPaint((-1), (java.awt.Paint)var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerMargin(1.0d);
    double var4 = var1.getUpperMargin();
    var1.setLabel("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setLowerMargin(1.0d);
    org.jfree.data.Range var18 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    java.awt.Color var22 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var15.setTickLabelPaint((java.awt.Paint)var22);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    var25.setLowerMargin(1.0d);
    double var28 = var25.getUpperMargin();
    java.util.Date var29 = var25.getMaximumDate();
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var34);
    double var36 = var35.getWidth();
    java.awt.geom.Rectangle2D var37 = var35.getBounds();
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    org.jfree.data.xy.XYDataset var43 = null;
    int var44 = var42.indexOf(var43);
    float var45 = var42.getBackgroundImageAlpha();
    var42.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var49 = var42.getDomainAxis(0);
    var42.setDomainGridlinesVisible(true);
    var42.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var54 = null;
    var42.setFixedDomainAxisSpace(var54, true);
    org.jfree.chart.util.RectangleEdge var58 = var42.getDomainAxisEdge(10);
    double var59 = var15.dateToJava2D(var29, var37, var58);
    boolean var60 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    double var7 = var5.getContentXOffset();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var12.indexOf(var13);
    float var15 = var12.getBackgroundImageAlpha();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis(0);
    var12.setDomainGridlinesVisible(true);
    boolean var22 = var5.equals((java.lang.Object)var12);
    float var23 = var12.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    double var7 = var5.getContentXOffset();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var12.indexOf(var13);
    float var15 = var12.getBackgroundImageAlpha();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis(0);
    var12.setDomainGridlinesVisible(true);
    boolean var22 = var5.equals((java.lang.Object)var12);
    var5.clear();
    double var24 = var5.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = var4.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    var4.setRadiusGridlinesVisible(true);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
    var4.setName("");
    var4.setInfo("hi!");

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     float var5 = var1.calculateBaselineOffset(var3, var4);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 1.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    var1.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     var1.zoomRange((-1.0d), (-1.0d));
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("hi!");
//     var6.setLowerMargin(1.0d);
//     double var9 = var6.getUpperMargin();
//     java.util.Date var10 = var6.getMaximumDate();
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     int var17 = var15.indexOf(var16);
//     boolean var18 = var15.isRangeZoomable();
//     org.jfree.data.general.DatasetChangeEvent var19 = null;
//     var15.datasetChanged(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var22, var23, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var26);
//     double var28 = var27.getWidth();
//     java.awt.geom.Rectangle2D var29 = var27.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var15.drawAnnotations(var21, var29, var30);
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var1.dateToJava2D(var10, var29, var32);
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
//     double var41 = var40.getWidth();
//     java.awt.geom.Rectangle2D var42 = var40.getBounds();
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
//     org.jfree.data.xy.XYDataset var48 = null;
//     int var49 = var47.indexOf(var48);
//     float var50 = var47.getBackgroundImageAlpha();
//     var47.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var54 = var47.getDomainAxis(0);
//     var47.setDomainGridlinesVisible(true);
//     var47.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var59 = null;
//     var47.setFixedDomainAxisSpace(var59, true);
//     org.jfree.chart.util.RectangleEdge var63 = var47.getDomainAxisEdge(10);
//     double var64 = var1.lengthToJava2D(1.0d, var42, var63);
//     
//     // Checks the contract:  equals-hashcode on var26 and var39
//     assertTrue("Contract failed: equals-hashcode on var26 and var39", var26.equals(var39) ? var26.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var26
//     assertTrue("Contract failed: equals-hashcode on var39 and var26", var39.equals(var26) ? var39.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var40
//     assertTrue("Contract failed: equals-hashcode on var27 and var40", var27.equals(var40) ? var27.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var27
//     assertTrue("Contract failed: equals-hashcode on var40 and var27", var40.equals(var27) ? var40.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    double var7 = var5.getContentXOffset();
    double var8 = var5.getHeight();
    org.jfree.chart.block.Arrangement var9 = var5.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    boolean var5 = var2.getAutoRangeStickyZero();
    var2.resizeRange(1.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     boolean var9 = var8.isBorderVisible();
//     org.jfree.chart.event.TitleChangeEvent var10 = null;
//     var8.titleChanged(var10);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var3.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var6 = var3.toFixedHeight(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    boolean var9 = var8.isBorderVisible();
    org.jfree.chart.title.Title var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addSubtitle(0, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    java.awt.Paint var6 = var4.getAngleGridlinePaint();
    java.lang.Object var7 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.lang.Object var6 = var5.clone();
//     double var7 = var5.getContentXOffset();
//     double var8 = var5.getHeight();
//     boolean var9 = var5.isEmpty();
//     java.lang.Object var10 = var5.clone();
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }
// 
// 
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var6.indexOf(var7);
//     float var9 = var6.getBackgroundImageAlpha();
//     var6.clearDomainMarkers(0);
//     java.awt.Font var12 = var6.getNoDataMessageFont();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     int var20 = var18.indexOf(var19);
//     float var21 = var18.getBackgroundImageAlpha();
//     var18.clearDomainMarkers(0);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     var18.drawAnnotations(var24, var25, var26);
//     boolean var29 = var18.equals((java.lang.Object)0.0d);
//     org.jfree.chart.axis.ValueAxis var30 = var18.getDomainAxis();
//     java.awt.Paint var31 = var18.getDomainGridlinePaint();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var31, (-1.0f), 0, var34);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    org.jfree.chart.title.Title var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.addSubtitle(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", var1, var2, var3);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerMargin(1.0d);
    double var4 = var1.getUpperMargin();
    var1.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    java.awt.Paint var7 = var4.getDomainGridlinePaint();
    org.jfree.chart.plot.Marker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    int var19 = var4.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.axis.ValueAxis var10 = var6.getRangeAxisForDataset(1);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     int var17 = var15.indexOf(var16);
//     float var18 = var15.getBackgroundImageAlpha();
//     var15.clearDomainMarkers(0);
//     var15.clearAnnotations();
//     int var22 = var15.getDomainAxisCount();
//     boolean var23 = var15.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     var15.setRenderer(0, var25, true);
//     org.jfree.chart.axis.AxisSpace var28 = var15.getFixedRangeAxisSpace();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var33 = var32.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var29, var30, (org.jfree.chart.axis.ValueAxis)var32, var34);
//     var35.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
//     boolean var38 = var37.isBorderVisible();
//     java.util.List var39 = var37.getSubtitles();
//     var15.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var37);
//     org.jfree.chart.event.ChartProgressEvent var43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var6, var37, 1, (-1));
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var37
//     assertTrue("Contract failed: equals-hashcode on var8 and var37", var8.equals(var37) ? var8.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var8
//     assertTrue("Contract failed: equals-hashcode on var37 and var8", var37.equals(var8) ? var37.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    java.util.List var17 = var4.getAnnotations();
    org.jfree.chart.axis.ValueAxis var19 = var4.getDomainAxisForDataset(0);
    org.jfree.chart.util.RectangleInsets var20 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     boolean var9 = var8.isBorderVisible();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     int var17 = var15.indexOf(var16);
//     float var18 = var15.getBackgroundImageAlpha();
//     var15.clearDomainMarkers(0);
//     var15.clearAnnotations();
//     int var22 = var15.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var23 = var15.getAxisOffset();
//     boolean var25 = var23.equals((java.lang.Object)0.0f);
//     double var26 = var23.getRight();
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var31 = var30.getUpArrow();
//     var28.setDownArrow(var31);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var39 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var38);
//     double var40 = var39.getWidth();
//     java.awt.geom.Rectangle2D var41 = var39.getBounds();
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var28.valueToJava2D((-1.0d), var41, var42);
//     java.awt.geom.Rectangle2D var44 = var23.createInsetRectangle(var41);
//     org.jfree.data.xy.XYDataset var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
//     org.jfree.chart.axis.AxisSpace var50 = var49.getFixedRangeAxisSpace();
//     java.lang.Object var51 = var49.clone();
//     java.awt.geom.Point2D var52 = var49.getQuadrantOrigin();
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     var8.draw(var10, var41, var52, var53);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var4.setFixedDomainAxisSpace(var16, true);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    int var29 = var27.indexOf(var28);
    java.awt.Paint var30 = var27.getDomainGridlinePaint();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d, var30);
    org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(var30);
    var4.setDomainTickBandPaint(var30);
    org.jfree.data.general.DatasetChangeEvent var34 = null;
    var4.datasetChanged(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.lang.Object var6 = var5.clone();
//     double var7 = var5.getContentXOffset();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     int var14 = var12.indexOf(var13);
//     float var15 = var12.getBackgroundImageAlpha();
//     var12.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis(0);
//     var12.setDomainGridlinesVisible(true);
//     boolean var22 = var5.equals((java.lang.Object)var12);
//     java.lang.Object var23 = var5.clone();
//     
//     // Checks the contract:  equals-hashcode on var6 and var23
//     assertTrue("Contract failed: equals-hashcode on var6 and var23", var6.equals(var23) ? var6.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var6
//     assertTrue("Contract failed: equals-hashcode on var23 and var6", var23.equals(var6) ? var23.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setDomainCrosshairValue(0.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    java.util.List var17 = var4.getAnnotations();
    java.util.List var18 = var4.getAnnotations();
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var4.getDomainMarkers(100, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    org.jfree.chart.title.Title var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.addSubtitle(100, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    boolean var5 = var2.getAutoRangeStickyZero();
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setDefaultAutoRange(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     int var7 = var5.indexOf(var6);
//     float var8 = var5.getBackgroundImageAlpha();
//     var5.clearDomainMarkers(0);
//     java.awt.Font var11 = var5.getNoDataMessageFont();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var11);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.text.TextAnchor var14 = null;
//     float var15 = var12.calculateBaselineOffset(var13, var14);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var1.setTickUnit(var7);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var11 = var10.getTickUnit();
    java.util.Date var12 = var1.calculateLowestVisibleTickValue(var11);
    org.jfree.chart.axis.Timeline var13 = null;
    var1.setTimeline(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    java.awt.Graphics2D var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var15.indexOf(var16);
    float var18 = var15.getBackgroundImageAlpha();
    var15.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var22 = var15.getDomainAxis(0);
    var15.setDomainGridlinesVisible(true);
    var15.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var15.setFixedDomainAxisSpace(var27, true);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var33 = var32.getUpArrow();
    var15.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var32, true);
    var32.resizeRange(0.0d);
    org.jfree.chart.util.HorizontalAlignment var39 = null;
    org.jfree.chart.util.VerticalAlignment var40 = null;
    org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var43);
    double var45 = var44.getWidth();
    java.awt.geom.Rectangle2D var46 = var44.getBounds();
    org.jfree.chart.util.RectangleEdge var47 = null;
    double var48 = var32.lengthToJava2D(1.0d, var46, var47);
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var53 = var52.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var49, var50, (org.jfree.chart.axis.ValueAxis)var52, var54);
    var55.clearRangeMarkers();
    org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var55);
    boolean var58 = var57.isBorderVisible();
    java.util.List var59 = var57.getSubtitles();
    var4.drawRangeTickBands(var10, var46, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    boolean var9 = var8.isBorderVisible();
    boolean var10 = var8.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var5.indexOf(var6);
    float var8 = var5.getBackgroundImageAlpha();
    var5.clearDomainMarkers(0);
    java.awt.Font var11 = var5.getNoDataMessageFont();
    java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var16 = var15.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 100.0f, var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.util.Size2D var21 = var19.calculateDimensions(var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.text.TextBlockAnchor var25 = null;
    java.awt.Shape var29 = var19.calculateBounds(var22, 1.0f, (-1.0f), var25, 0.0f, 0.0f, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedRangeAxisSpace();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var4.getRenderer(0);
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     boolean var11 = var4.removeDomainMarker(100, var9, var10);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), (-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2097352));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    org.jfree.data.general.PieDataset var2 = null;
    java.lang.String var4 = var1.generateSectionLabel(var2, (java.lang.Comparable)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     boolean var11 = var6.removeDomainMarker(100, var9, var10);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    var6.setRangeCrosshairValue((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var17 = var16.getUpArrow();
    boolean var18 = var12.equals((java.lang.Object)var16);
    java.text.DateFormat var19 = null;
    var16.setDateFormatOverride(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var7.indexOf(var8);
    float var10 = var7.getBackgroundImageAlpha();
    var7.clearDomainMarkers(0);
    java.awt.Font var13 = var7.getNoDataMessageFont();
    java.awt.Color var17 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var18 = var17.brighter();
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var17, 100.0f, var20);
    var1.setTickLabelFont(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    org.jfree.chart.util.UnitType var15 = var12.getUnitType();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    int var22 = var20.indexOf(var21);
    float var23 = var20.getBackgroundImageAlpha();
    var20.clearDomainMarkers(0);
    var20.clearAnnotations();
    int var27 = var20.getDomainAxisCount();
    boolean var28 = var20.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var20.setRenderer(0, var30, true);
    org.jfree.chart.axis.AxisSpace var33 = var20.getFixedRangeAxisSpace();
    var20.configureRangeAxes();
    org.jfree.chart.event.RendererChangeEvent var35 = null;
    var20.rendererChanged(var35);
    java.awt.Stroke var37 = var20.getOutlineStroke();
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var42 = var41.getUpArrow();
    var39.setDownArrow(var42);
    org.jfree.data.xy.XYDataset var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
    org.jfree.data.xy.XYDataset var49 = null;
    int var50 = var48.indexOf(var49);
    float var51 = var48.getBackgroundImageAlpha();
    var48.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var55 = var48.getDomainAxis(0);
    var48.setDomainGridlinesVisible(true);
    java.awt.Color var61 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var48.setRangeCrosshairPaint((java.awt.Paint)var61);
    var39.setTickMarkPaint((java.awt.Paint)var61);
    var20.setNoDataMessagePaint((java.awt.Paint)var61);
    org.jfree.chart.block.BlockBorder var65 = new org.jfree.chart.block.BlockBorder(var12, (java.awt.Paint)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     var4.clearAnnotations();
//     int var11 = var4.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
//     double var13 = var12.getBottom();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     int var20 = var18.indexOf(var19);
//     boolean var21 = var18.isRangeZoomable();
//     org.jfree.data.general.DatasetChangeEvent var22 = null;
//     var18.datasetChanged(var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var29);
//     double var31 = var30.getWidth();
//     java.awt.geom.Rectangle2D var32 = var30.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     var18.drawAnnotations(var24, var32, var33);
//     java.awt.geom.Rectangle2D var37 = var12.createOutsetRectangle(var32, true, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    java.awt.Color var17 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var4.setRangeCrosshairPaint((java.awt.Paint)var17);
    int var19 = var4.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    org.jfree.chart.plot.Plot var30 = var26.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var4.setFixedDomainAxisSpace(var16, true);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    int var29 = var27.indexOf(var28);
    java.awt.Paint var30 = var27.getDomainGridlinePaint();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d, var30);
    org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(var30);
    var4.setDomainTickBandPaint(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var34 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     int var7 = var5.indexOf(var6);
//     float var8 = var5.getBackgroundImageAlpha();
//     var5.clearDomainMarkers(0);
//     java.awt.Font var11 = var5.getNoDataMessageFont();
//     java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
//     java.awt.Color var16 = var15.brighter();
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 100.0f, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     int var26 = var24.indexOf(var25);
//     float var27 = var24.getBackgroundImageAlpha();
//     var24.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var31 = var24.getDomainAxis(0);
//     var24.setDomainGridlinesVisible(true);
//     boolean var34 = var19.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.data.xy.XYDataset var12 = null;
    int var13 = var11.indexOf(var12);
    float var14 = var11.getBackgroundImageAlpha();
    var11.clearDomainMarkers(0);
    var11.clearAnnotations();
    int var18 = var11.getDomainAxisCount();
    boolean var19 = var11.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var11.setRenderer(0, var21, true);
    org.jfree.chart.axis.AxisSpace var24 = var11.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var11.getDomainAxisLocation();
    var6.setDomainAxisLocation(var25);
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var29 = var6.removeRangeMarker(var27, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var4.drawAnnotations(var10, var11, var12);
//     boolean var15 = var4.equals((java.lang.Object)0.0d);
//     org.jfree.chart.axis.ValueAxis var16 = var4.getDomainAxis();
//     java.awt.Paint var17 = var4.getDomainGridlinePaint();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var4.removeDomainMarker(var18, var19);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var5.indexOf(var6);
    float var8 = var5.getBackgroundImageAlpha();
    var5.clearDomainMarkers(0);
    java.awt.Font var11 = var5.getNoDataMessageFont();
    java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var16 = var15.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 100.0f, var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.util.Size2D var21 = var19.calculateDimensions(var20);
    double var22 = var21.getWidth();
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 1.0d, 0.0d, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 0.0d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedDomainAxisSpace(var7);
    var6.setWeight(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    org.jfree.chart.event.RendererChangeEvent var19 = null;
    var4.rendererChanged(var19);
    boolean var21 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    double var14 = var12.calculateLeftInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var5.indexOf(var6);
    float var8 = var5.getBackgroundImageAlpha();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var12 = var5.getDomainAxis(0);
    var5.setDomainGridlinesVisible(true);
    var5.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var17 = null;
    var5.setFixedDomainAxisSpace(var17, true);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var23 = var22.getUpArrow();
    var5.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var22, true);
    var22.resizeRange(0.0d);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var32 = var31.getUpArrow();
    var29.setDownArrow(var32);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
    org.jfree.data.xy.XYDataset var39 = null;
    int var40 = var38.indexOf(var39);
    float var41 = var38.getBackgroundImageAlpha();
    var38.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var45 = var38.getDomainAxis(0);
    var38.setDomainGridlinesVisible(true);
    java.awt.Color var51 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var38.setRangeCrosshairPaint((java.awt.Paint)var51);
    var29.setTickMarkPaint((java.awt.Paint)var51);
    java.awt.Color var54 = var51.brighter();
    var22.setTickLabelPaint((java.awt.Paint)var54);
    java.util.TimeZone var56 = var22.getTimeZone();
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     boolean var7 = var4.isRangeZoomable();
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var4.datasetChanged(var8);
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var4.axisChanged(var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     int var13 = var4.getDomainAxisIndex(var12);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     int var21 = var19.indexOf(var20);
//     float var22 = var19.getBackgroundImageAlpha();
//     var19.clearDomainMarkers(0);
//     var19.clearAnnotations();
//     int var26 = var19.getDomainAxisCount();
//     boolean var27 = var19.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     var19.setRenderer(0, var29, true);
//     org.jfree.chart.axis.AxisSpace var32 = var19.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var33 = var19.getDomainAxisLocation();
//     var4.setDomainAxisLocation(100, var33);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var4.", var19.equals(var4) == var4.equals(var19));
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var12.indexOf(var13);
    float var15 = var12.getBackgroundImageAlpha();
    var12.clearDomainMarkers(0);
    java.awt.Font var18 = var12.getNoDataMessageFont();
    org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("", var18);
    var1.setLabelFont(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var4 = var3.getUpArrow();
//     var1.setDownArrow(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.data.xy.XYDataset var11 = null;
//     int var12 = var10.indexOf(var11);
//     float var13 = var10.getBackgroundImageAlpha();
//     var10.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var17 = var10.getDomainAxis(0);
//     var10.setDomainGridlinesVisible(true);
//     java.awt.Color var23 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
//     var10.setRangeCrosshairPaint((java.awt.Paint)var23);
//     var1.setTickMarkPaint((java.awt.Paint)var23);
//     java.awt.Color var26 = var23.brighter();
//     java.awt.Color var27 = var23.darker();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     int var34 = var32.indexOf(var33);
//     float var35 = var32.getBackgroundImageAlpha();
//     org.jfree.chart.LegendItemCollection var36 = var32.getFixedLegendItems();
//     var32.setOutlineVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     java.awt.geom.Point2D var41 = null;
//     var32.zoomDomainAxes(10.0d, var40, var41, true);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.data.xy.XYDataset var49 = null;
//     int var50 = var48.indexOf(var49);
//     float var51 = var48.getBackgroundImageAlpha();
//     var48.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var55 = var48.getDomainAxis(0);
//     var48.setDomainGridlinesVisible(true);
//     var48.setRangeCrosshairVisible(true);
//     java.awt.Stroke var60 = var48.getRangeGridlineStroke();
//     var32.setDomainGridlineStroke(var60);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
//     org.jfree.data.xy.XYDataset var67 = null;
//     int var68 = var66.indexOf(var67);
//     float var69 = var66.getBackgroundImageAlpha();
//     var66.clearDomainMarkers(0);
//     var66.clearAnnotations();
//     int var73 = var66.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var74 = var66.getAxisOffset();
//     boolean var76 = var74.equals((java.lang.Object)0.0f);
//     org.jfree.chart.util.UnitType var77 = var74.getUnitType();
//     org.jfree.chart.block.LineBorder var78 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var23, var60, var74);
//     
//     // Checks the contract:  equals-hashcode on var32 and var66
//     assertTrue("Contract failed: equals-hashcode on var32 and var66", var32.equals(var66) ? var32.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var32
//     assertTrue("Contract failed: equals-hashcode on var66 and var32", var66.equals(var32) ? var66.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    java.awt.Stroke var7 = var6.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisSpace var8 = null;
    var6.setFixedDomainAxisSpace(var8);
    org.jfree.chart.LegendItemCollection var10 = null;
    var6.setFixedLegendItems(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    boolean var30 = var26.isBorderVisible();
    org.jfree.chart.title.Title var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.addSubtitle(1, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     var6.clearRangeMarkers();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     int var16 = var14.indexOf(var15);
//     float var17 = var14.getBackgroundImageAlpha();
//     var14.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var21 = var14.getDomainAxis(0);
//     var14.setDomainGridlinesVisible(true);
//     var14.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     var14.setFixedDomainAxisSpace(var26, true);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var32 = var31.getUpArrow();
//     var14.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var31, true);
//     var31.resizeRange(0.0d);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.FlowArrangement var42 = new org.jfree.chart.block.FlowArrangement(var38, var39, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var43 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var42);
//     double var44 = var43.getWidth();
//     java.awt.geom.Rectangle2D var45 = var43.getBounds();
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var31.lengthToJava2D(1.0d, var45, var46);
//     var8.draw(var9, var45);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    org.jfree.chart.util.UnitType var15 = var12.getUnitType();
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(var15, 0.0d, (-1.0d), 0.0d, (-1.0d));
    double var22 = var20.calculateRightOutset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1.0d));

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.LegendItemCollection var8 = var4.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1, var1, var2);
    org.jfree.chart.JFreeChart var4 = var3.getChart();
    org.jfree.chart.event.ChartChangeEventType var5 = var3.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    boolean var30 = var26.isBorderVisible();
    var26.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var4.setFixedDomainAxisSpace(var16, true);
    org.jfree.chart.util.RectangleEdge var20 = var4.getDomainAxisEdge(10);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.data.xy.XYDataset var26 = null;
    int var27 = var25.indexOf(var26);
    float var28 = var25.getBackgroundImageAlpha();
    var25.clearDomainMarkers(0);
    var25.clearAnnotations();
    int var32 = var25.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var33 = var25.getAxisOffset();
    boolean var35 = var33.equals((java.lang.Object)0.0f);
    org.jfree.chart.util.UnitType var36 = var33.getUnitType();
    var4.setInsets(var33);
    double var39 = var33.calculateBottomOutset(1.0d);
    double var41 = var33.calculateTopOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var4.drawAnnotations(var10, var11, var12);
    boolean var15 = var4.equals((java.lang.Object)0.0d);
    org.jfree.chart.axis.ValueAxis var16 = var4.getDomainAxis();
    java.awt.Paint var17 = var4.getDomainGridlinePaint();
    org.jfree.chart.axis.AxisLocation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    java.awt.Paint var7 = var4.getDomainGridlinePaint();
    java.awt.Font var8 = var4.getNoDataMessageFont();
    org.jfree.chart.LegendItemCollection var9 = var4.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    java.lang.Object var8 = var6.clone();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var6.zoomRangeAxes(10.0d, var10, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisLocation var11 = null;
    var4.setRangeAxisLocation(10, var11, false);
    double var14 = var4.getRangeCrosshairValue();
    org.jfree.data.general.DatasetChangeEvent var15 = null;
    var4.datasetChanged(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.block.Arrangement var6 = var5.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.lang.Object var6 = var5.clone();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     int var14 = var12.indexOf(var13);
//     float var15 = var12.getBackgroundImageAlpha();
//     var12.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis(0);
//     var12.setDomainGridlinesVisible(true);
//     var12.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var12.setFixedDomainAxisSpace(var24, true);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var30 = var29.getUpArrow();
//     var12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var29, true);
//     var29.resizeRange(0.0d);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var41 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var40);
//     double var42 = var41.getWidth();
//     java.awt.geom.Rectangle2D var43 = var41.getBounds();
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var29.lengthToJava2D(1.0d, var43, var44);
//     var5.draw(var7, var43);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    double var13 = var12.getBottom();
    double var15 = var12.calculateLeftOutset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4.0d);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    java.lang.Object var13 = var4.clone();
    java.awt.Stroke var14 = var4.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var4.drawAnnotations(var10, var11, var12);
    boolean var15 = var4.equals((java.lang.Object)0.0d);
    org.jfree.chart.axis.ValueAxis var16 = var4.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var17 = var4.getDomainAxisLocation();
    org.jfree.chart.annotations.XYAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, var3);
    org.jfree.chart.block.RectangleConstraint var5 = var4.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var7 = var5.getWidthConstraintType();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, var11);
    org.jfree.chart.block.RectangleConstraint var13 = var12.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var14 = var13.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var15 = var13.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1, var7, (-1.0d), var9, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedRangeAxisSpace();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.LegendItemCollection var7 = var4.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.lang.Object var2 = var1.clone();
    java.lang.String var3 = var1.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "hi!"+ "'", var3.equals("hi!"));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var6.setRenderer(100, var8, true);
    org.jfree.chart.axis.AxisLocation var11 = var6.getRangeAxisLocation();
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.AxisSpace var19 = var18.getFixedRangeAxisSpace();
    java.lang.Object var20 = var18.clone();
    java.awt.geom.Point2D var21 = var18.getQuadrantOrigin();
    var6.zoomRangeAxes(0.0d, var13, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var4.setFixedDomainAxisSpace(var16, true);
    org.jfree.chart.util.RectangleEdge var20 = var4.getDomainAxisEdge(10);
    boolean var21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.data.xy.XYDataset var12 = null;
    int var13 = var11.indexOf(var12);
    float var14 = var11.getBackgroundImageAlpha();
    var11.clearDomainMarkers(0);
    var11.clearAnnotations();
    int var18 = var11.getDomainAxisCount();
    boolean var19 = var11.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var11.setRenderer(0, var21, true);
    org.jfree.chart.axis.AxisSpace var24 = var11.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var11.getDomainAxisLocation();
    var6.setDomainAxisLocation(var25);
    java.awt.Paint var27 = var6.getDomainGridlinePaint();
    var6.setWeight(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisLocation var11 = null;
//     var4.setRangeAxisLocation(10, var11, false);
//     double var14 = var4.getRangeCrosshairValue();
//     var4.clearRangeAxes();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     int var23 = var21.indexOf(var22);
//     boolean var24 = var21.isRangeZoomable();
//     org.jfree.data.general.DatasetChangeEvent var25 = null;
//     var21.datasetChanged(var25);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var32);
//     double var34 = var33.getWidth();
//     java.awt.geom.Rectangle2D var35 = var33.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var21.drawAnnotations(var27, var35, var36);
//     org.jfree.chart.entity.ChartEntity var40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var35, "RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", "");
//     var4.drawBackgroundImage(var16, var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    org.jfree.data.xy.XYDataset var10 = null;
    int var11 = var9.indexOf(var10);
    float var12 = var9.getBackgroundImageAlpha();
    var9.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var16 = var9.getDomainAxis(0);
    var9.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLowerMargin(1.0d);
    org.jfree.data.Range var23 = var9.getDataRange((org.jfree.chart.axis.ValueAxis)var20);
    java.awt.Color var27 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var20.setTickLabelPaint((java.awt.Paint)var27);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    var30.setLowerMargin(1.0d);
    double var33 = var30.getUpperMargin();
    java.util.Date var34 = var30.getMaximumDate();
    org.jfree.chart.util.HorizontalAlignment var35 = null;
    org.jfree.chart.util.VerticalAlignment var36 = null;
    org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
    double var41 = var40.getWidth();
    java.awt.geom.Rectangle2D var42 = var40.getBounds();
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    org.jfree.data.xy.XYDataset var48 = null;
    int var49 = var47.indexOf(var48);
    float var50 = var47.getBackgroundImageAlpha();
    var47.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var54 = var47.getDomainAxis(0);
    var47.setDomainGridlinesVisible(true);
    var47.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var59 = null;
    var47.setFixedDomainAxisSpace(var59, true);
    org.jfree.chart.util.RectangleEdge var63 = var47.getDomainAxisEdge(10);
    double var64 = var20.dateToJava2D(var34, var42, var63);
    var2.setMaximumDate(var34);
    var2.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.lang.Object var6 = var5.clone();
    double var7 = var5.getContentXOffset();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var12.indexOf(var13);
    float var15 = var12.getBackgroundImageAlpha();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis(0);
    var12.setDomainGridlinesVisible(true);
    boolean var22 = var5.equals((java.lang.Object)var12);
    var5.clear();
    var5.setWidth(0.0d);
    org.jfree.chart.util.RectangleInsets var26 = var5.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    org.jfree.chart.util.RectangleInsets var12 = var4.getAxisOffset();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    org.jfree.chart.util.UnitType var15 = var12.getUnitType();
    boolean var17 = var15.equals((java.lang.Object)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var1.setTickUnit(var7);
    var1.setAxisLineVisible(false);
    java.lang.String var11 = var1.getLabelToolTip();
    org.jfree.data.Range var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var12, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    boolean var16 = var4.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var4.setFixedRangeAxisSpace(var17, true);
    org.jfree.chart.axis.ValueAxis var21 = var4.getRangeAxisForDataset(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    java.lang.Object var2 = var1.clone();
    org.jfree.data.RangeType var3 = var1.getRangeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setLowerMargin(1.0d);
    double var4 = var1.getUpperMargin();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var5, (org.jfree.chart.axis.ValueAxis)var7, var8);
    int var10 = var9.getSeriesCount();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var19.indexOf(var20);
    java.awt.Paint var22 = var19.getDomainGridlinePaint();
    org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d, var22);
    var9.setRadiusGridlinePaint(var22);
    var1.setLabelPaint(var22);
    double var26 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    java.awt.Stroke var7 = var6.getRangeCrosshairStroke();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var12 = var11.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var8, var9, (org.jfree.chart.axis.ValueAxis)var11, var13);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var19.indexOf(var20);
    float var22 = var19.getBackgroundImageAlpha();
    var19.clearDomainMarkers(0);
    var19.clearAnnotations();
    int var26 = var19.getDomainAxisCount();
    boolean var27 = var19.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    var19.setRenderer(0, var29, true);
    org.jfree.chart.axis.AxisSpace var32 = var19.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var33 = var19.getDomainAxisLocation();
    var14.setDomainAxisLocation(var33);
    java.awt.Paint var35 = var14.getDomainGridlinePaint();
    var6.setRangeCrosshairPaint(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    double var2 = var1.getFixedAutoRange();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     boolean var7 = var4.isRangeZoomable();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     int var14 = var12.indexOf(var13);
//     float var15 = var12.getBackgroundImageAlpha();
//     var12.clearDomainMarkers(0);
//     var12.clearAnnotations();
//     int var19 = var12.getDomainAxisCount();
//     boolean var20 = var12.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     var12.setRenderer(0, var22, true);
//     java.util.List var25 = var12.getAnnotations();
//     org.jfree.chart.axis.AxisLocation var26 = var12.getDomainAxisLocation();
//     var4.setDomainAxisLocation(var26, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)'a', 10.0d, (-2097352));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     org.jfree.chart.axis.AxisSpace var7 = null;
//     var6.setFixedDomainAxisSpace(var7);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var15);
//     double var17 = var16.getWidth();
//     java.awt.geom.Rectangle2D var18 = var16.getBounds();
//     org.jfree.chart.util.RectangleAnchor var19 = null;
//     java.awt.geom.Point2D var20 = org.jfree.chart.util.RectangleAnchor.coordinates(var18, var19);
//     var6.zoomRangeAxes(100.0d, var10, var20, true);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    java.lang.Object var8 = var6.clone();
    org.jfree.data.category.CategoryDataset var9 = var6.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.chart.axis.AxisSpace var7 = null;
    var6.setFixedDomainAxisSpace(var7);
    var6.setAnchorValue(10.0d);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = var6.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var5.indexOf(var6);
    float var8 = var5.getBackgroundImageAlpha();
    var5.clearDomainMarkers(0);
    java.awt.Font var11 = var5.getNoDataMessageFont();
    java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var16 = var15.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 100.0f, var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.util.Size2D var21 = var19.calculateDimensions(var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.text.TextBlockAnchor var25 = null;
    var19.draw(var22, 10.0f, 100.0f, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var6.indexOf(var7);
    float var9 = var6.getBackgroundImageAlpha();
    var6.clearDomainMarkers(0);
    java.awt.Font var12 = var6.getNoDataMessageFont();
    java.awt.Color var16 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var17 = var16.brighter();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16, 100.0f, var19);
    org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]", var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var4 = var3.getUpArrow();
    var1.setDownArrow(var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = null;
    int var12 = var10.indexOf(var11);
    float var13 = var10.getBackgroundImageAlpha();
    var10.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var17 = var10.getDomainAxis(0);
    var10.setDomainGridlinesVisible(true);
    java.awt.Color var23 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var10.setRangeCrosshairPaint((java.awt.Paint)var23);
    var1.setTickMarkPaint((java.awt.Paint)var23);
    float[] var27 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var28 = var23.getRGBComponents(var27);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    boolean var9 = var8.isBorderVisible();
    boolean var10 = var8.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    boolean var9 = var8.isBorderVisible();
    boolean var10 = var8.isBorderVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     int var13 = var11.indexOf(var12);
//     float var14 = var11.getBackgroundImageAlpha();
//     var11.clearDomainMarkers(0);
//     var11.clearAnnotations();
//     int var18 = var11.getDomainAxisCount();
//     boolean var19 = var11.isDomainCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     var11.setRenderer(0, var21, true);
//     org.jfree.chart.axis.AxisSpace var24 = var11.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var25 = var11.getDomainAxisLocation();
//     var6.setDomainAxisLocation(var25);
//     java.awt.Paint var27 = var6.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis[] var28 = null;
//     var6.setRangeAxes(var28);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var4 = var3.getUpArrow();
    var1.setDownArrow(var4);
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.data.xy.XYDataset var11 = null;
    int var12 = var10.indexOf(var11);
    float var13 = var10.getBackgroundImageAlpha();
    var10.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var17 = var10.getDomainAxis(0);
    var10.setDomainGridlinesVisible(true);
    java.awt.Color var23 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var10.setRangeCrosshairPaint((java.awt.Paint)var23);
    var1.setTickMarkPaint((java.awt.Paint)var23);
    java.awt.Color var26 = var23.brighter();
    java.awt.Color var27 = var23.darker();
    int var28 = var23.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.xy.XYDataset var5 = null;
//     int var6 = var4.indexOf(var5);
//     float var7 = var4.getBackgroundImageAlpha();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
//     var4.setDomainGridlinesVisible(true);
//     var4.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     var4.setFixedDomainAxisSpace(var16, true);
//     org.jfree.chart.util.RectangleEdge var20 = var4.getDomainAxisEdge(10);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     int var27 = var25.indexOf(var26);
//     float var28 = var25.getBackgroundImageAlpha();
//     var25.clearDomainMarkers(0);
//     var25.clearAnnotations();
//     int var32 = var25.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var33 = var25.getAxisOffset();
//     boolean var35 = var33.equals((java.lang.Object)0.0f);
//     org.jfree.chart.util.UnitType var36 = var33.getUnitType();
//     var4.setInsets(var33);
//     org.jfree.chart.plot.Marker var38 = null;
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var4.removeDomainMarker(var38, var39);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.renderer.PolarItemRenderer var3 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
//     int var5 = var4.getSeriesCount();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     int var16 = var14.indexOf(var15);
//     java.awt.Paint var17 = var14.getDomainGridlinePaint();
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d, var17);
//     var4.setRadiusGridlinePaint(var17);
//     org.jfree.chart.plot.DrawingSupplier var20 = null;
//     var4.setDrawingSupplier(var20);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateTickUnit var26 = var25.getTickUnit();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     int var34 = var32.indexOf(var33);
//     float var35 = var32.getBackgroundImageAlpha();
//     var32.clearDomainMarkers(0);
//     var32.clearAnnotations();
//     int var39 = var32.getDomainAxisCount();
//     org.jfree.chart.util.RectangleInsets var40 = var32.getAxisOffset();
//     boolean var42 = var40.equals((java.lang.Object)0.0f);
//     double var43 = var40.getRight();
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("hi!");
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var48 = var47.getUpArrow();
//     var45.setDownArrow(var48);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var56 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var55);
//     double var57 = var56.getWidth();
//     java.awt.geom.Rectangle2D var58 = var56.getBounds();
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var45.valueToJava2D((-1.0d), var58, var59);
//     java.awt.geom.Rectangle2D var61 = var40.createInsetRectangle(var58);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
//     org.jfree.data.xy.XYDataset var67 = null;
//     int var68 = var66.indexOf(var67);
//     float var69 = var66.getBackgroundImageAlpha();
//     var66.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var73 = var66.getDomainAxis(0);
//     var66.setDomainGridlinesVisible(true);
//     var66.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var78 = null;
//     var66.setFixedDomainAxisSpace(var78, true);
//     org.jfree.chart.util.RectangleEdge var82 = var66.getDomainAxisEdge(10);
//     double var83 = var25.lengthToJava2D(0.0d, var61, var82);
//     java.awt.Point var84 = var4.translateValueThetaRadiusToJava2D(1.0d, 10.0d, var61);
//     
//     // Checks the contract:  equals-hashcode on var14 and var32
//     assertTrue("Contract failed: equals-hashcode on var14 and var32", var14.equals(var32) ? var14.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var14
//     assertTrue("Contract failed: equals-hashcode on var32 and var14", var32.equals(var14) ? var32.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    var4.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var16 = null;
    var4.setFixedDomainAxisSpace(var16, true);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    int var29 = var27.indexOf(var28);
    java.awt.Paint var30 = var27.getDomainGridlinePaint();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), 1.0d, 0.0d, var30);
    org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder(var30);
    var4.setDomainTickBandPaint(var30);
    java.awt.Image var34 = null;
    var4.setBackgroundImage(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var10);
    java.lang.Object var12 = var11.clone();
    double var13 = var11.getContentXOffset();
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.data.xy.XYDataset var19 = null;
    int var20 = var18.indexOf(var19);
    float var21 = var18.getBackgroundImageAlpha();
    var18.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var25 = var18.getDomainAxis(0);
    var18.setDomainGridlinesVisible(true);
    boolean var28 = var11.equals((java.lang.Object)var18);
    java.awt.Stroke var29 = var18.getDomainGridlineStroke();
    var4.setAngleGridlineStroke(var29);
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.data.Range var32 = var4.getDataRange(var31);
    java.awt.Paint var33 = var4.getAngleGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var22 = var21.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var23);
    var24.clearRangeMarkers();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
    boolean var27 = var26.isBorderVisible();
    java.util.List var28 = var26.getSubtitles();
    var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    boolean var30 = var26.isBorderVisible();
    var26.setTextAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var3, var4);
    java.awt.Shape var6 = var1.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var1.setTickUnit(var7);
    org.jfree.chart.plot.Plot var9 = var1.getPlot();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var12 = var11.getTickUnit();
    java.util.Date var13 = var1.calculateLowestVisibleTickValue(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    var4.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    java.lang.Object var13 = var4.clone();
    java.awt.Stroke var14 = var4.getDomainZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.util.SortOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setRowRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
    var4.setCopyright("");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
    var11.setCopyright("");
    var4.addLibrary((org.jfree.chart.ui.Library)var11);
    java.lang.String var15 = var4.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.axis.CategoryAxis var9 = var6.getDomainAxisForDataset((-33));
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var11.clearCategoryLabelToolTips();
    int var13 = var11.getCategoryLabelPositionOffset();
    java.util.List var14 = var6.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var11);
    int var15 = var11.getCategoryLabelPositionOffset();
    var11.addCategoryLabelToolTip((java.lang.Comparable)false, "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var5.indexOf(var6);
    float var8 = var5.getBackgroundImageAlpha();
    var5.clearDomainMarkers(0);
    java.awt.Font var11 = var5.getNoDataMessageFont();
    java.awt.Color var15 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var16 = var15.brighter();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, (java.awt.Paint)var15, 100.0f, var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.util.Size2D var21 = var19.calculateDimensions(var20);
    double var22 = var21.getWidth();
    double var23 = var21.getWidth();
    org.jfree.chart.util.RectangleAnchor var26 = null;
    java.awt.geom.Rectangle2D var27 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 100.0d, 10.0d, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    java.awt.Color var14 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    java.awt.Color var15 = var14.brighter();
    var4.setRangeCrosshairPaint((java.awt.Paint)var15);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var21 = var20.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var17, var18, (org.jfree.chart.axis.ValueAxis)var20, var22);
    var23.clearRangeMarkers();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    boolean var26 = var25.isBorderVisible();
    var25.setBackgroundImageAlignment((-33));
    org.jfree.chart.title.TextTitle var29 = var25.getTitle();
    var4.addChangeListener((org.jfree.chart.event.PlotChangeListener)var25);
    java.awt.Paint var31 = var25.getBorderPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    java.awt.Stroke var5 = var4.getRadiusGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");
//     org.jfree.chart.renderer.PolarItemRenderer var3 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
//     java.lang.String var5 = var2.getLabelToolTip();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("hi!");
//     var8.zoomRange((-1.0d), (-1.0d));
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("hi!");
//     var13.setLowerMargin(1.0d);
//     double var16 = var13.getUpperMargin();
//     java.util.Date var17 = var13.getMaximumDate();
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.data.xy.XYDataset var23 = null;
//     int var24 = var22.indexOf(var23);
//     boolean var25 = var22.isRangeZoomable();
//     org.jfree.data.general.DatasetChangeEvent var26 = null;
//     var22.datasetChanged(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, 10.0d, 1.0d);
//     org.jfree.chart.block.BlockContainer var34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var33);
//     double var35 = var34.getWidth();
//     java.awt.geom.Rectangle2D var36 = var34.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     var22.drawAnnotations(var28, var36, var37);
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var8.dateToJava2D(var17, var36, var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.data.xy.XYDataset var46 = null;
//     int var47 = var45.indexOf(var46);
//     float var48 = var45.getBackgroundImageAlpha();
//     var45.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var52 = var45.getDomainAxis(0);
//     var45.setDomainGridlinesVisible(true);
//     var45.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var57 = null;
//     var45.setFixedDomainAxisSpace(var57, true);
//     org.jfree.chart.util.RectangleEdge var61 = var45.getDomainAxisEdge(10);
//     double var62 = var2.java2DToValue(0.0d, var36, var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == Double.NaN);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.data.xy.XYDataset var12 = null;
    int var13 = var11.indexOf(var12);
    float var14 = var11.getBackgroundImageAlpha();
    var11.clearDomainMarkers(0);
    var11.clearAnnotations();
    int var18 = var11.getDomainAxisCount();
    boolean var19 = var11.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var11.setRenderer(0, var21, true);
    org.jfree.chart.axis.AxisSpace var24 = var11.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var11.getDomainAxisLocation();
    var6.setDomainAxisLocation(var25);
    boolean var27 = var6.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var10);
    java.lang.Object var12 = var11.clone();
    double var13 = var11.getContentXOffset();
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.data.xy.XYDataset var19 = null;
    int var20 = var18.indexOf(var19);
    float var21 = var18.getBackgroundImageAlpha();
    var18.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var25 = var18.getDomainAxis(0);
    var18.setDomainGridlinesVisible(true);
    boolean var28 = var11.equals((java.lang.Object)var18);
    java.awt.Stroke var29 = var18.getDomainGridlineStroke();
    var4.setAngleGridlineStroke(var29);
    var4.removeCornerTextItem("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var11 = var4.getDomainAxis(0);
    var4.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setLowerMargin(1.0d);
    org.jfree.data.Range var18 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    org.jfree.chart.axis.ValueAxis var19 = null;
    var4.setRangeAxis(var19);
    var4.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    java.awt.Paint var6 = var4.getAngleGridlinePaint();
    var4.addCornerTextItem("");
    var4.setRadiusGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "", "");
//     var4.setName("");
//     var4.addOptionalLibrary("hi!");
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     int var15 = var13.indexOf(var14);
//     float var16 = var13.getBackgroundImageAlpha();
//     var13.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var20 = var13.getDomainAxis(0);
//     var13.setDomainGridlinesVisible(true);
//     var13.setRangeCrosshairVisible(true);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var13.setFixedDomainAxisSpace(var25, true);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
//     java.awt.Shape var31 = var30.getUpArrow();
//     var13.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var30, true);
//     boolean var34 = var4.equals((java.lang.Object)true);
//     var4.setName("hi!");
//     org.jfree.chart.ui.Library var37 = null;
//     var4.addOptionalLibrary(var37);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var3.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var5 = var3.getWidthConstraintType();
    org.jfree.chart.block.LengthConstraintType var6 = var3.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var4 = var3.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var5);
    var6.clearRangeMarkers();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    java.lang.Object var9 = var6.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.NONE: width=10.0, height=0.0]");

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    int var6 = var4.indexOf(var5);
    float var7 = var4.getBackgroundImageAlpha();
    var4.clearDomainMarkers(0);
    var4.clearAnnotations();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainCrosshairVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(0, var14, true);
    org.jfree.chart.axis.AxisSpace var17 = var4.getFixedRangeAxisSpace();
    var4.configureRangeAxes();
    org.jfree.chart.event.RendererChangeEvent var19 = null;
    var4.rendererChanged(var19);
    java.awt.Stroke var21 = var4.getOutlineStroke();
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("hi!");
    java.awt.Shape var26 = var25.getUpArrow();
    var23.setDownArrow(var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    int var34 = var32.indexOf(var33);
    float var35 = var32.getBackgroundImageAlpha();
    var32.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var39 = var32.getDomainAxis(0);
    var32.setDomainGridlinesVisible(true);
    java.awt.Color var45 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var32.setRangeCrosshairPaint((java.awt.Paint)var45);
    var23.setTickMarkPaint((java.awt.Paint)var45);
    var4.setNoDataMessagePaint((java.awt.Paint)var45);
    double var49 = var4.getDomainCrosshairValue();
    org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    int var5 = var4.getSeriesCount();
    java.awt.Paint var6 = var4.getAngleGridlinePaint();
    java.awt.Font var7 = var4.getAngleLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.renderer.PolarItemRenderer var3 = null;
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var3);
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
    org.jfree.data.xy.XYDataset var10 = null;
    int var11 = var9.indexOf(var10);
    float var12 = var9.getBackgroundImageAlpha();
    var9.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var16 = var9.getDomainAxis(0);
    var9.setDomainGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setLowerMargin(1.0d);
    org.jfree.data.Range var23 = var9.getDataRange((org.jfree.chart.axis.ValueAxis)var20);
    java.awt.Color var27 = java.awt.Color.getHSBColor(10.0f, 1.0f, 1.0f);
    var20.setTickLabelPaint((java.awt.Paint)var27);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
    var30.setLowerMargin(1.0d);
    double var33 = var30.getUpperMargin();
    java.util.Date var34 = var30.getMaximumDate();
    org.jfree.chart.util.HorizontalAlignment var35 = null;
    org.jfree.chart.util.VerticalAlignment var36 = null;
    org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 10.0d, 1.0d);
    org.jfree.chart.block.BlockContainer var40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var39);
    double var41 = var40.getWidth();
    java.awt.geom.Rectangle2D var42 = var40.getBounds();
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
    org.jfree.data.xy.XYDataset var48 = null;
    int var49 = var47.indexOf(var48);
    float var50 = var47.getBackgroundImageAlpha();
    var47.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var54 = var47.getDomainAxis(0);
    var47.setDomainGridlinesVisible(true);
    var47.setRangeCrosshairVisible(true);
    org.jfree.chart.axis.AxisSpace var59 = null;
    var47.setFixedDomainAxisSpace(var59, true);
    org.jfree.chart.util.RectangleEdge var63 = var47.getDomainAxisEdge(10);
    double var64 = var20.dateToJava2D(var34, var42, var63);
    var2.setMaximumDate(var34);
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.DateAxis var69 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.DateTickUnit var70 = var69.getTickUnit();
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var66, var67, (org.jfree.chart.axis.ValueAxis)var69, var71);
    var72.clearRangeMarkers();
    org.jfree.chart.JFreeChart var74 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var72);
    org.jfree.chart.axis.ValueAxis var75 = var72.getRangeAxis();
    var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

}
