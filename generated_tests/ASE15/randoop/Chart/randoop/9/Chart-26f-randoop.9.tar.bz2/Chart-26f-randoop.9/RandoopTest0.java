
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     var0.drawItem(var1, var2, var3, var4, var5, var6, var7, 10, (-1), 1);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity(var0, var1, "", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(var0, var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getBaseURLGenerator();
    org.jfree.data.category.CategoryDataset var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = var0.findRangeBounds(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var0.drawRangeGridline(var3, var4, var5, var6, (-1.0d));
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 10.0f, 100.0f, var4, 100.0d, 100.0f, 100.0f);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var8.getBaseNegativeItemLabelPosition();
//     boolean var13 = var8.isSeriesVisible(10);
//     java.awt.Paint var14 = var8.getBasePaint();
//     var0.setSeriesPaint(100, var14, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
//     
//     // Checks the contract:  equals-hashcode on var3 and var11
//     assertTrue("Contract failed: equals-hashcode on var3 and var11", var3.equals(var11) ? var3.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var3
//     assertTrue("Contract failed: equals-hashcode on var11 and var3", var11.equals(var3) ? var11.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(100, var1);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.lang.Number[] var0 = null;
//     java.lang.Number[][] var1 = new java.lang.Number[][] { var0};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 10.0f, 10.0d, 100.0f, 100.0f);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.axis.AxisState var8 = var1.draw(var2, 10.0d, var4, var5, var6, var7);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setLabelURL("");

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
//     org.jfree.chart.renderer.category.StackedBarRenderer var10 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var10.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var10.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var16 = var10.getItemStroke((-1), 100);
//     var0.setBaseStroke(var16, false);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var3
//     assertTrue("Contract failed: equals-hashcode on var13 and var3", var13.equals(var3) ? var13.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)(byte)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var5);
//     java.awt.Paint var7 = var6.getOutlinePaint();
//     var6.setBackgroundAlpha(100.0f);
//     boolean var10 = var4.hasListener((java.util.EventListener)var6);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
//     var13.setLeft(1.0d);
//     org.jfree.chart.axis.AxisSpace var16 = var1.reserveSpace(var2, (org.jfree.chart.plot.Plot)var6, var11, var12, var13);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemLabelGenerator(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNoDataMessageFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var6 = var0.getItemStroke((-1), 100);
    java.io.ObjectOutputStream var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.renderer.category.StackedBarRenderer var10 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var10.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var10.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
//     java.awt.Shape var15 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 0.0f, var8, 0.0d, var14);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    org.jfree.chart.block.Arrangement var7 = null;
    org.jfree.chart.block.Arrangement var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var3 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
    org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var9 = var6.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var12 = new org.jfree.chart.labels.ItemLabelPosition(var0, var5, var10, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, (-1.0d), var2);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "");
    java.awt.Font var11 = null;
    org.jfree.data.general.WaferMapDataset var12 = null;
    org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var12);
    java.awt.Paint var14 = var13.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, var14, 0.0f, 0, var17);
    org.jfree.chart.renderer.category.StackedBarRenderer var20 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var23 = var20.getBaseNegativeItemLabelPosition();
    boolean var25 = var20.isSeriesVisible(10);
    java.awt.Paint var26 = var20.getBasePaint();
    java.awt.Paint var29 = var20.getItemLabelPaint(0, 1);
    org.jfree.chart.renderer.category.StackedBarRenderer var30 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var33 = var30.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var36 = var30.getItemStroke((-1), 100);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.LegendItemEntity var40 = new org.jfree.chart.entity.LegendItemEntity(var39);
    org.jfree.chart.renderer.category.StackedBarRenderer var41 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var43 = var41.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var44 = var41.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var47 = var41.getItemStroke((-1), 100);
    java.awt.Font var49 = null;
    org.jfree.data.general.WaferMapDataset var50 = null;
    org.jfree.chart.plot.WaferMapPlot var51 = new org.jfree.chart.plot.WaferMapPlot(var50);
    java.awt.Paint var52 = var51.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var55 = null;
    org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, var52, 0.0f, 0, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", false, var6, false, var14, true, var29, var36, false, var39, var47, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setRangeCrosshairStroke(var10);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var0.drawOutline(var13, var14);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    int var7 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 0, 0);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var8.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var14 = var8.getItemStroke((-1), 100);
//     boolean var15 = var7.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.category.StackedBarRenderer var16 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var16.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var16.getBaseNegativeItemLabelPosition();
//     boolean var21 = var16.isSeriesVisible(10);
//     java.awt.Paint var22 = var16.getBasePaint();
//     java.awt.Paint var25 = var16.getItemLabelPaint(0, 1);
//     java.awt.Stroke var26 = null;
//     org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker(100.0d, 100.0d, (java.awt.Paint)var5, var14, var25, var26, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
    boolean var7 = var2.isSeriesVisible(10);
    java.awt.Paint var8 = var2.getBasePaint();
    java.awt.Stroke var10 = var2.getSeriesStroke(10);
    java.awt.Paint var13 = var2.getItemLabelPaint(10, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var1, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.plot.CategoryMarker var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)10.0f, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition(var0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 0, 0);
//     org.jfree.chart.text.TextMeasurer var8 = null;
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, (java.awt.Paint)var5, 1.0f, 10, var8);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.util.Date var1 = null;
//     java.util.Date var2 = null;
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("", var1, var2);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
//     java.awt.Paint var11 = var0.lookupSeriesFillPaint(10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var15 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var15.setSeriesLinesVisible(1, true);
//     java.lang.Object var19 = var15.clone();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var22 = var21.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.Marker var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var15.drawRangeMarker(var20, var21, var23, var24, var25);
//     org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
//     boolean var31 = var27.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var32 = null;
//     var27.setBaseURLGenerator(var32);
//     var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var27, false);
//     var21.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var40 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var40.setSeriesLinesVisible(1, true);
//     java.lang.Object var44 = var40.clone();
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var47 = var46.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.plot.Marker var49 = null;
//     java.awt.geom.Rectangle2D var50 = null;
//     var40.drawRangeMarker(var45, var46, var48, var49, var50);
//     org.jfree.chart.renderer.category.StackedBarRenderer var52 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var54 = var52.getSeriesItemLabelGenerator(100);
//     boolean var56 = var52.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var57 = null;
//     var52.setBaseURLGenerator(var57);
//     var46.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var52, false);
//     var46.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var65 = var46.getDataRange((org.jfree.chart.axis.ValueAxis)var64);
//     org.jfree.data.category.CategoryDataset var66 = null;
//     var0.drawItem(var12, var13, var14, var21, var39, (org.jfree.chart.axis.ValueAxis)var64, var66, 2, 100, 0);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    java.awt.Stroke var5 = var0.getItemStroke(0, 0);
    double var6 = var0.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     long var5 = var3.toMillisecond((-1L));
//     java.util.Date var6 = null;
//     long var7 = var3.getTime(var6);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Jan"+ "'", var2.equals("Jan"));

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Paint var2 = var1.getSeparatorPaint();
//     double var3 = var1.getMaximumExplodePercent();
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.axis.Axis var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "");
//     org.jfree.chart.entity.AxisLabelEntity var7 = new org.jfree.chart.entity.AxisLabelEntity(var0, var2, "TextAnchor.CENTER", "");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var8 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var9 = null;
//     java.lang.String var10 = var7.getImageMapAreaTag(var8, var9);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 1.0d, 2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeCrosshairStroke(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.lang.Object var3 = null;
//     java.lang.Object var4 = var0.draw(var1, var2, var3);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, (-1.0d));
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, (-1.0d));
    double var5 = var4.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.CENTER", "hi!", var3);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var6 = var0.getItemStroke((-1), 100);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var8.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var10 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var11 = var10.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var12.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var18 = var12.getItemStroke((-1), 100);
//     boolean var19 = var11.equals((java.lang.Object)var18);
//     var8.setRangeCrosshairStroke(var18);
//     var0.setSeriesOutlineStroke(2, var18);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     java.awt.geom.Rectangle2D var9 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), 10.0f, var8);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), (java.awt.Paint)var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var12.setLeft(1.0d);
    var6.setFixedDomainAxisSpace(var12);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    boolean var18 = var17.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var20 = var17.getRangeAxisEdge(100);
    var12.ensureAtLeast((-1.0d), var20);
    java.lang.Object var22 = var12.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getBaseNegativeItemLabelPosition();
    boolean var6 = var1.isSeriesVisible(10);
    java.awt.Paint var7 = var1.getBasePaint();
    java.awt.Paint var10 = var1.getItemLabelPaint(0, 1);
    boolean var11 = var0.equals((java.lang.Object)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setBaseLinesVisible(false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var4 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var4.setSeriesLinesVisible(1, true);
//     java.lang.Object var8 = var4.clone();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var11 = var10.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var4.drawRangeMarker(var9, var10, var12, var13, var14);
//     org.jfree.chart.renderer.category.StackedBarRenderer var16 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var16.getSeriesItemLabelGenerator(100);
//     boolean var20 = var16.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var16.setBaseURLGenerator(var21);
//     var10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
//     java.awt.geom.Rectangle2D var25 = null;
//     var0.drawDomainGridline(var3, var10, var25, 0.0d);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 1.0d);
//     var4.clear();
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var7 = var6.getArrangement();
//     org.jfree.chart.util.RectangleInsets var8 = var6.getPadding();
//     boolean var9 = var6.isEmpty();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = null;
//     org.jfree.chart.util.Size2D var12 = var4.arrange(var6, var10, var11);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    var1.setLabelInsets(var7);
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var7.createInsetRectangle(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.chart.ChartColor var7 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    float[] var10 = new float[] { (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var3.getColorComponents(var8, var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var4 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var4.setSeriesLinesVisible(1, true);
//     java.lang.Object var8 = var4.clone();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var11 = var10.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.Marker var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var4.drawRangeMarker(var9, var10, var12, var13, var14);
//     org.jfree.chart.renderer.category.StackedBarRenderer var16 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var16.getSeriesItemLabelGenerator(100);
//     boolean var20 = var16.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var21 = null;
//     var16.setBaseURLGenerator(var21);
//     var10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
//     boolean var30 = var26.equals((java.lang.Object)var27);
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var32 = var31.getInsets();
//     var26.setLabelInsets(var32);
//     java.awt.Paint var35 = var26.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var36.setSeriesLinesVisible(1, true);
//     java.lang.Object var40 = var36.clone();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var43 = var42.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.Marker var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var36.drawRangeMarker(var41, var42, var44, var45, var46);
//     org.jfree.chart.renderer.category.StackedBarRenderer var48 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var50 = var48.getSeriesItemLabelGenerator(100);
//     boolean var52 = var48.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var53 = null;
//     var48.setBaseURLGenerator(var53);
//     var42.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var48, false);
//     var42.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var61 = var42.getDataRange((org.jfree.chart.axis.ValueAxis)var60);
//     double var62 = var60.getFixedAutoRange();
//     org.jfree.data.category.CategoryDataset var63 = null;
//     var0.drawItem(var1, var2, var3, var10, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var60, var63, 10, 1, 2);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var5 = var4.getRed();
//     org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
//     var6.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
//     var6.setMinimumBarLength(1.0d);
//     java.awt.Stroke var15 = var6.getBaseStroke();
//     org.jfree.chart.axis.Axis var20 = null;
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity(var22, "");
//     org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity(var20, var22, "TextAnchor.CENTER", "");
//     org.jfree.chart.ChartColor var31 = new org.jfree.chart.ChartColor(0, 0, 0);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     java.awt.Paint var34 = var33.getSeparatorPaint();
//     org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var37 = var36.getTickMarkStroke();
//     var33.setBaseSectionOutlineStroke(var37);
//     org.jfree.chart.renderer.category.StackedBarRenderer var39 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = var39.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var42 = var39.getBaseNegativeItemLabelPosition();
//     boolean var44 = var39.isSeriesVisible(10);
//     java.awt.Paint var45 = var39.getBasePaint();
//     java.awt.Paint var48 = var39.getItemLabelPaint(0, 1);
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var22, (java.awt.Paint)var31, var37, var48);
//     org.jfree.chart.renderer.category.StackedBarRenderer var50 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var52 = var50.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var53 = var50.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var56 = var50.getItemStroke((-1), 100);
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint)var4, var15, (java.awt.Paint)var31, var56, 1.0f);
//     
//     // Checks the contract:  equals-hashcode on var42 and var53
//     assertTrue("Contract failed: equals-hashcode on var42 and var53", var42.equals(var53) ? var42.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var42
//     assertTrue("Contract failed: equals-hashcode on var53 and var42", var53.equals(var42) ? var53.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(100);
//     org.jfree.chart.event.PlotChangeEvent var4 = null;
//     var0.notifyListeners(var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.draw(var6, var7, var8, var9, var10);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
    java.lang.Object var3 = null;
    int var4 = var2.compareTo(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var5 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     java.awt.image.BufferedImage var14 = var11.createBufferedImage(2, 100);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    var6.clearDomainMarkers((-1));
    org.jfree.chart.plot.DatasetRenderingOrder var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDatasetRenderingOrder(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("ERROR : Relative To String", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     double var1 = var0.getContentYOffset();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.draw(var2, var3);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, 1.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    boolean var7 = org.jfree.chart.util.ShapeUtilities.equal(var2, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    java.awt.Font var5 = null;
    org.jfree.data.general.WaferMapDataset var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
    java.awt.Paint var8 = var7.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
    java.util.List var13 = var12.getLines();
    var3.addExceptions(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var3.containsDomainRange(1L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.util.EventListener var7 = null;
//     boolean var8 = var0.hasListener(var7);
//     double var9 = var0.getBase();
//     java.awt.Shape var11 = var0.lookupSeriesShape((-1));
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var12.getBaseNegativeItemLabelPosition();
//     boolean var17 = var12.isSeriesVisible(10);
//     java.awt.Paint var18 = var12.getBasePaint();
//     java.util.EventListener var19 = null;
//     boolean var20 = var12.hasListener(var19);
//     var12.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var23 = var12.getBaseNegativeItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var3
//     assertTrue("Contract failed: equals-hashcode on var23 and var3", var23.equals(var3) ? var23.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    boolean var4 = var0.isSeriesVisible(0);
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.data.general.DatasetChangeEvent var6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var4, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var8);
//     java.awt.Paint var10 = var9.getOutlinePaint();
//     var1.setLabelPaint(var10);
//     
//     // Checks the contract:  equals-hashcode on var3 and var9
//     assertTrue("Contract failed: equals-hashcode on var3 and var9", var3.equals(var9) ? var3.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var3
//     assertTrue("Contract failed: equals-hashcode on var9 and var3", var9.equals(var3) ? var9.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getSeriesPositiveItemLabelPosition(2);
//     org.jfree.chart.labels.ItemLabelPosition var6 = var0.getBasePositiveItemLabelPosition();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var11 = var10.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var14 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var14.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var20 = var14.getItemStroke((-1), 100);
//     boolean var21 = var13.equals((java.lang.Object)var20);
//     var10.setRangeCrosshairStroke(var20);
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var26 = null;
//     org.jfree.chart.plot.WaferMapPlot var27 = new org.jfree.chart.plot.WaferMapPlot(var26);
//     java.awt.Paint var28 = var27.getOutlinePaint();
//     var27.setBackgroundAlpha(100.0f);
//     boolean var31 = var25.hasListener((java.util.EventListener)var27);
//     var10.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var25);
//     boolean var33 = var10.isRangeZoomable();
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var36 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var38 = var36.getSeriesItemLabelGenerator(100);
//     boolean var39 = var35.equals((java.lang.Object)var36);
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var42 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var44 = var42.getSeriesItemLabelGenerator(100);
//     boolean var45 = var41.equals((java.lang.Object)var42);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var47 = var46.getInsets();
//     var41.setLabelInsets(var47);
//     var35.setLabelInsets(var47);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.data.category.CategoryDataset var51 = null;
//     var0.drawItem(var7, var8, var9, var10, (org.jfree.chart.axis.CategoryAxis)var35, var50, var51, 2, 0, 0);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.Title var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addSubtitle(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.LegendTitle var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addLegend(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.CENTER", var1, (-1.0f), 10.0f, var8, 10.0d, 10.0f, (-1.0f));
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.RIGHT", "Jan", var3);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setRangeCrosshairStroke(var10);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var15 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var17 = var15.getSeriesItemLabelGenerator(100);
//     boolean var18 = var14.equals((java.lang.Object)var15);
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var20 = var19.getInsets();
//     var14.setLabelInsets(var20);
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var14);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot(var24);
//     java.awt.Font var26 = var25.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var27 = null;
//     org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot(var27);
//     java.awt.Paint var29 = var28.getOutlinePaint();
//     var28.setBackgroundAlpha(100.0f);
//     float var32 = var28.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("Jan", var26, (org.jfree.chart.plot.Plot)var28, true);
//     var22.setChart(var34);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var34);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     var3.setBackgroundAlpha(100.0f);
//     boolean var7 = var1.hasListener((java.util.EventListener)var3);
//     var1.setTickLabelsVisible(true);
//     org.jfree.chart.axis.CategoryAnchor var10 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var14 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var14.setSeriesLinesVisible(1, true);
//     java.lang.Object var18 = var14.clone();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var21 = var20.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.Marker var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     var14.drawRangeMarker(var19, var20, var22, var23, var24);
//     org.jfree.chart.axis.AxisSpace var26 = new org.jfree.chart.axis.AxisSpace();
//     var26.setLeft(1.0d);
//     var20.setFixedDomainAxisSpace(var26);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var32 = var31.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var34 = var31.getRangeAxisEdge(100);
//     var26.ensureAtLeast((-1.0d), var34);
//     double var36 = var1.getCategoryJava2DCoordinate(var10, 1, 10, var13, var34);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var1.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     boolean var12 = var1.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.urls.PieURLGenerator var13 = var11.getURLGenerator();
//     double var14 = var11.getMaximumExplodePercent();
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDomainGridlinesVisible(true);
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, var4, var5);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var5 = var4.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var7 = var4.getRangeAxisEdge(100);
//     double var8 = var0.valueToJava2D(1.0E-5d, var3, var7);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, var1);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getSeriesPositiveItemLabelPosition(2);
    double var6 = var5.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     boolean var5 = var0.getBaseShapesVisible();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var8 = var7.isDomainGridlinesVisible();
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackground(var6, var7, var9);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("ERROR : Relative To String", var1, var2);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.axis.MarkerAxisBand var26 = null;
    var24.setMarkerBand(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setRangeWithMargins(100.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Font var5 = var4.getLabelFont();
    org.jfree.data.general.WaferMapDataset var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
    java.awt.Paint var8 = var7.getOutlinePaint();
    var7.setBackgroundAlpha(100.0f);
    float var11 = var7.getForegroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("Jan", var5, (org.jfree.chart.plot.Plot)var7, true);
    org.jfree.chart.event.ChartProgressListener var14 = null;
    var13.removeProgressListener(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var2 = var1.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     boolean var16 = var12.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
//     var6.setRangeCrosshairValue(0.0d, true);
//     var6.setForegroundAlpha(0.0f);
//     org.jfree.chart.plot.Marker var26 = null;
//     var6.addRangeMarker(var26);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow((java.lang.Comparable)1.0E-5d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var2 = var1.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var1.getRowKey(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(0);
    var0.setIncludeBaseInRange(false);
    var0.setRenderAsPercentages(true);
    java.awt.Paint var11 = var0.getItemLabelPaint(100, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    var24.setAutoRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
//     java.awt.Paint var12 = var0.getItemOutlinePaint(0, 0);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainAxes();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     java.awt.Paint var18 = var17.getSeparatorPaint();
//     var14.setOutlinePaint(var18);
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawBackground(var13, var14, var20);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Jan", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
    boolean var11 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
    var7.setLabelInsets(var13);
    var1.setLabelInsets(var13);
    java.awt.geom.Rectangle2D var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var19 = var13.createOutsetRectangle(var16, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2);
//     org.jfree.data.time.SerialDate var2 = null;
//     org.jfree.data.time.SerialDate var3 = var1.getEndOfCurrentMonth(var2);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(1);
    int var2 = var1.size();
    boolean var4 = var1.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var3 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getSeriesItemLabelGenerator(100);
    boolean var6 = var2.equals((java.lang.Object)var3);
    org.jfree.chart.block.LineBorder var7 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
    var2.setLabelInsets(var8);
    java.awt.Paint var11 = var2.getTickLabelPaint((java.lang.Comparable)1.0f);
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var16 = var15.getColorSpace();
    org.jfree.chart.renderer.category.GanttRenderer var17 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var18 = var17.getCompletePaint();
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var23 = var22.getColorSpace();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var11, (java.awt.Paint)var15, var18, (java.awt.Paint)var22);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var25);
    org.jfree.data.Range var27 = var24.findRangeBounds((org.jfree.data.category.CategoryDataset)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var29 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var25, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var3.notifyListeners(var4);
    org.jfree.chart.renderer.category.LineRenderer3D var6 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var6.setSeriesLinesVisible(1, true);
    java.lang.Object var10 = var6.clone();
    boolean var11 = var6.getBaseShapesVisible();
    java.lang.Boolean var13 = var6.getSeriesCreateEntities(100);
    java.awt.Paint var16 = var6.getItemFillPaint(0, 0);
    var3.setBasePaint(var16);
    boolean var18 = var0.equals((java.lang.Object)var16);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var21 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var19, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.awt.Font var5 = var1.getLabelFont();
    java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
    int var8 = var1.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(100, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var1, var2);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Paint var2 = var1.getSeparatorPaint();
//     org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var5 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var5.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var5.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var11 = var5.getItemStroke((-1), 100);
//     boolean var12 = var4.equals((java.lang.Object)var11);
//     var1.setInsets(var4);
//     java.awt.geom.Rectangle2D var14 = null;
//     var4.trim(var14);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setRangeCrosshairStroke(var10);
//     org.jfree.chart.plot.Marker var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     var0.addRangeMarker(0, var14, var15);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 0.0f, 0, var7);
//     java.util.List var9 = var8.getLines();
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var13 = null;
//     org.jfree.chart.plot.WaferMapPlot var14 = new org.jfree.chart.plot.WaferMapPlot(var13);
//     var12.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     java.awt.Font var16 = var12.getLabelFont();
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var19 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getSeriesItemLabelGenerator(100);
//     boolean var22 = var18.equals((java.lang.Object)var19);
//     org.jfree.chart.block.LineBorder var23 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var24 = var23.getInsets();
//     var18.setLabelInsets(var24);
//     java.awt.Paint var27 = var18.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var31 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var32 = var31.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var33 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var34 = var33.getCompletePaint();
//     org.jfree.chart.ChartColor var38 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var39 = var38.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var27, (java.awt.Paint)var31, var34, (java.awt.Paint)var38);
//     var8.addLine("hi!", var16, var27);
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var3
//     assertTrue("Contract failed: equals-hashcode on var14 and var3", var14.equals(var3) ? var14.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2);
    java.lang.String var3 = var2.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "1-January-1900"+ "'", var3.equals("1-January-1900"));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearDomainAxes();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    java.awt.Paint var12 = var11.getSeparatorPaint();
    var8.setOutlinePaint(var12);
    var7.setRadiusGridlinePaint(var12);
    org.jfree.chart.axis.Axis var20 = null;
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity(var22, "");
    org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity(var20, var22, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var31 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
    java.awt.Paint var34 = var33.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var37 = var36.getTickMarkStroke();
    var33.setBaseSectionOutlineStroke(var37);
    org.jfree.chart.renderer.category.StackedBarRenderer var39 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var41 = var39.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var42 = var39.getBaseNegativeItemLabelPosition();
    boolean var44 = var39.isSeriesVisible(10);
    java.awt.Paint var45 = var39.getBasePaint();
    java.awt.Paint var48 = var39.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var22, (java.awt.Paint)var31, var37, var48);
    org.jfree.data.general.Dataset var50 = null;
    var49.setDataset(var50);
    java.awt.Paint var52 = var49.getLinePaint();
    org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var55 = var54.getTickMarkStroke();
    org.jfree.chart.renderer.category.StackedBarRenderer var57 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var59 = var57.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var60 = var57.getBaseNegativeItemLabelPosition();
    boolean var62 = var57.isSeriesVisible(10);
    java.awt.Paint var63 = var57.getBasePaint();
    java.util.EventListener var64 = null;
    boolean var65 = var57.hasListener(var64);
    double var66 = var57.getBase();
    java.awt.Shape var68 = var57.lookupSeriesShape((-1));
    org.jfree.chart.renderer.category.StackedBarRenderer var69 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var71 = var69.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var72 = var69.getBaseNegativeItemLabelPosition();
    boolean var74 = var69.isSeriesVisible(10);
    java.awt.Font var76 = var69.getSeriesItemLabelFont(0);
    java.awt.Stroke var77 = var69.getBaseOutlineStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var80 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    org.jfree.chart.event.RendererChangeEvent var81 = null;
    var80.notifyListeners(var81);
    org.jfree.chart.renderer.category.LineRenderer3D var83 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var83.setSeriesLinesVisible(1, true);
    java.lang.Object var87 = var83.clone();
    boolean var88 = var83.getBaseShapesVisible();
    java.lang.Boolean var90 = var83.getSeriesCreateEntities(100);
    java.awt.Paint var93 = var83.getItemFillPaint(0, 0);
    var80.setBasePaint(var93);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var95 = new org.jfree.chart.LegendItem(var0, "TextAnchor.CENTER", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Jan", false, var5, true, var12, false, var52, var55, false, var68, var77, var93);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var0.getLegendItemToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getStdDevValue(0, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var2 = null;
//     var0.setMarkerBand(var2);
//     java.text.NumberFormat var4 = var0.getNumberFormatOverride();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.util.HorizontalAlignment var7 = null;
//     org.jfree.chart.util.VerticalAlignment var8 = null;
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 10.0d, 1.0d);
//     var11.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13);
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var13, (java.lang.Comparable)100.0f);
//     var16.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, 1.0d);
//     var27.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var29);
//     org.jfree.chart.title.LegendItemBlockContainer var32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var27, (org.jfree.data.general.Dataset)var29, (java.lang.Comparable)100.0f);
//     var32.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var38 = var32.getBounds();
//     org.jfree.chart.renderer.category.LineRenderer3D var39 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var39.setSeriesLinesVisible(1, true);
//     java.lang.Object var43 = var39.clone();
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var46 = var45.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.plot.Marker var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     var39.drawRangeMarker(var44, var45, var47, var48, var49);
//     org.jfree.chart.axis.AxisSpace var51 = new org.jfree.chart.axis.AxisSpace();
//     var51.setLeft(1.0d);
//     var45.setFixedDomainAxisSpace(var51);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var57 = var56.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var59 = var56.getRangeAxisEdge(100);
//     var51.ensureAtLeast((-1.0d), var59);
//     boolean var61 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var59);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.axis.AxisState var63 = var0.draw(var5, 0.2d, var22, var38, var59, var62);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     org.jfree.data.Range var4 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
//     org.jfree.chart.util.HorizontalAlignment var7 = null;
//     org.jfree.chart.util.VerticalAlignment var8 = null;
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 10.0d, 1.0d);
//     var11.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var13);
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var13, (java.lang.Comparable)100.0f);
//     var16.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var22 = var16.getBounds();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainAxes();
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
//     boolean var30 = var26.equals((java.lang.Object)var27);
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var32 = var31.getInsets();
//     var26.setLabelInsets(var32);
//     org.jfree.chart.renderer.category.LineRenderer3D var34 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var34.setSeriesLinesVisible(1, true);
//     java.lang.Object var38 = var34.clone();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var41 = var40.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.Marker var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     var34.drawRangeMarker(var39, var40, var42, var43, var44);
//     org.jfree.chart.renderer.category.StackedBarRenderer var46 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var48 = var46.getSeriesItemLabelGenerator(100);
//     boolean var50 = var46.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var51 = null;
//     var46.setBaseURLGenerator(var51);
//     var40.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var46, false);
//     var40.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var59 = var40.getDataRange((org.jfree.chart.axis.ValueAxis)var58);
//     org.jfree.data.Range var60 = null;
//     org.jfree.data.Range var62 = org.jfree.data.Range.expandToInclude(var60, (-1.0d));
//     org.jfree.data.Range var64 = org.jfree.data.Range.expandToInclude(var62, (-1.0d));
//     var58.setRangeWithMargins(var64, true, false);
//     org.jfree.chart.renderer.category.StackedBarRenderer var68 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var70 = var68.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var71 = var68.getBaseNegativeItemLabelPosition();
//     boolean var73 = var68.isSeriesVisible(10);
//     java.awt.Paint var74 = var68.getBasePaint();
//     java.awt.Paint var75 = var68.getBasePaint();
//     var58.setTickLabelPaint(var75);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var77 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     var1.drawItem(var5, var6, var22, var23, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.data.category.CategoryDataset)var77, 0, 100, 0);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.Axis var4 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "");
    org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity(var4, var6, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    java.awt.Paint var18 = var17.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var17.setBaseSectionOutlineStroke(var21);
    org.jfree.chart.renderer.category.StackedBarRenderer var23 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var26 = var23.getBaseNegativeItemLabelPosition();
    boolean var28 = var23.isSeriesVisible(10);
    java.awt.Paint var29 = var23.getBasePaint();
    java.awt.Paint var32 = var23.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var6, (java.awt.Paint)var15, var21, var32);
    float[] var36 = new float[] { 0.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var37 = var15.getRGBColorComponents(var36);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     var0.zoomRangeAxes(0.0d, var2, var3);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var3 = var0.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Jan");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 0.05d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextAnchor.CENTER", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.awt.Stroke var8 = var0.getSeriesStroke(10);
    double var9 = var0.getMaximumBarWidth();
    var0.setItemMargin(1.0d);
    boolean var14 = var0.isItemLabelVisible(10, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "");
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    boolean var12 = var11.isNotify();
    org.jfree.chart.ChartRenderingInfo var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var18 = var11.createBufferedImage(4, 0, (-1.0d), 1.0E-5d, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     var0.setBaseShape(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var0.drawOutline(var5, var6, var7);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     java.awt.RenderingHints var23 = null;
//     var21.setRenderingHints(var23);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("RectangleEdge.RIGHT", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var12.setLeft(1.0d);
//     var6.setFixedDomainAxisSpace(var12);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var18 = var17.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var20 = var17.getRangeAxisEdge(100);
//     var12.ensureAtLeast((-1.0d), var20);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 1.0d);
//     var26.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var28);
//     org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var26, (org.jfree.data.general.Dataset)var28, (java.lang.Comparable)100.0f);
//     var31.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var39 = var38.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var40 = null;
//     var38.setMarkerBand(var40);
//     java.text.NumberFormat var42 = var38.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement(var44, var45, 10.0d, 1.0d);
//     var48.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var51 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var50);
//     org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var48, (org.jfree.data.general.Dataset)var50, (java.lang.Comparable)100.0f);
//     var53.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var59 = var53.getBounds();
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var38.lengthToJava2D(0.0d, var59, var60);
//     java.awt.geom.Rectangle2D var62 = var12.shrink(var37, var59);
//     
//     // Checks the contract:  equals-hashcode on var26 and var48
//     assertTrue("Contract failed: equals-hashcode on var26 and var48", var26.equals(var48) ? var26.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var26
//     assertTrue("Contract failed: equals-hashcode on var48 and var26", var48.equals(var26) ? var48.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var50
//     assertTrue("Contract failed: equals-hashcode on var28 and var50", var28.equals(var50) ? var28.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var28
//     assertTrue("Contract failed: equals-hashcode on var50 and var28", var50.equals(var28) ? var50.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    boolean var1 = var0.isTickLabelsVisible();
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRightArrow(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Stroke var8 = var0.getSeriesStroke(10);
//     java.awt.Paint var11 = var0.getItemLabelPaint(10, 100);
//     double var12 = var0.getUpperClip();
//     var0.setSeriesCreateEntities(1, (java.lang.Boolean)true, true);
//     org.jfree.chart.renderer.category.GanttRenderer var18 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var19 = var18.getCompletePaint();
//     var0.setSeriesFillPaint(1, var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
//     java.awt.Paint var23 = var22.getSeparatorPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var24 = var22.getLegendLabelGenerator();
//     java.awt.Stroke var25 = var22.getLabelLinkStroke();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var28 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var30 = var28.getSeriesItemLabelGenerator(100);
//     boolean var31 = var27.equals((java.lang.Object)var28);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var34 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getSeriesItemLabelGenerator(100);
//     boolean var37 = var33.equals((java.lang.Object)var34);
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var39 = var38.getInsets();
//     var33.setLabelInsets(var39);
//     var27.setLabelInsets(var39);
//     org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder(var19, var25, var39);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var0.", var28.equals(var0) == var0.equals(var28));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var0.", var34.equals(var0) == var0.equals(var34));
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 0.05d, 0.2d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setCategoryMargin(0.0d);
    float var4 = var1.getTickMarkOutsideLength();
    org.jfree.chart.axis.CategoryLabelPositions var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "");
    org.jfree.chart.entity.AxisLabelEntity var7 = new org.jfree.chart.entity.AxisLabelEntity(var0, var2, "TextAnchor.CENTER", "");
    org.jfree.chart.axis.Axis var8 = var7.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
//     java.awt.Paint var12 = var0.getItemOutlinePaint(0, 0);
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     org.jfree.chart.renderer.category.GanttRenderer var14 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var15 = var14.getCompletePaint();
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     java.awt.Stroke[] var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var18 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var18.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var18.getBaseNegativeItemLabelPosition();
//     boolean var23 = var18.isSeriesVisible(10);
//     java.awt.Font var25 = var18.getSeriesItemLabelFont(0);
//     java.awt.Stroke var26 = var18.getBaseOutlineStroke();
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Shape[] var28 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var16, var17, var27, var28);
//     
//     // Checks the contract:  equals-hashcode on var3 and var21
//     assertTrue("Contract failed: equals-hashcode on var3 and var21", var3.equals(var21) ? var3.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var3
//     assertTrue("Contract failed: equals-hashcode on var21 and var3", var21.equals(var3) ? var21.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Paint var2 = var1.getOutlinePaint();
//     var1.setBackgroundAlpha(100.0f);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     java.awt.Font var8 = var7.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var9 = null;
//     org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var9);
//     java.awt.Paint var11 = var10.getOutlinePaint();
//     var10.setBackgroundAlpha(100.0f);
//     float var14 = var10.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("Jan", var8, (org.jfree.chart.plot.Plot)var10, true);
//     boolean var17 = var16.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0f, var16, (-1), (-1));
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.awt.Paint var7 = var0.getBasePaint();
    boolean var8 = var0.getRenderAsPercentages();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var3 = var2.clone();
//     var0.addAll(var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.awt.Stroke var5 = var1.getAxisLineStroke();
    double var6 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    java.awt.Paint var4 = var3.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 0.0f, 0, var7);
    org.jfree.chart.axis.AxisSpace var9 = new org.jfree.chart.axis.AxisSpace();
    boolean var10 = var8.equals((java.lang.Object)var9);
    org.jfree.chart.text.TextLine var11 = var8.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, (-1.0d));
//     boolean var12 = var8.equals((java.lang.Object)(-1.0d));
//     java.awt.geom.Rectangle2D var13 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 100.0f, 2.0f, var8);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("poly");

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Paint var9 = var8.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var10 = var8.getLegendLabelGenerator();
    java.awt.Stroke var11 = var8.getLabelLinkStroke();
    var0.setBaseStroke(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "0.2", var2);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var6 = var5.getRed();
//     java.awt.Color var7 = java.awt.Color.getColor("Jan", (java.awt.Color)var5);
//     java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString((java.awt.Color)var5);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     java.awt.Paint var11 = var10.getSeparatorPaint();
//     double var12 = var10.getLabelGap();
//     java.awt.Stroke var13 = var10.getSeparatorStroke();
//     org.jfree.chart.plot.CategoryMarker var14 = new org.jfree.chart.plot.CategoryMarker(var0, (java.awt.Paint)var5, var13);
//     
//     // Checks the contract:  var14.equals(var14)
//     assertTrue("Contract failed: var14.equals(var14)", var14.equals(var14));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     boolean var12 = var11.isNotify();
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
//     java.awt.Font var16 = var15.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var17);
//     java.awt.Paint var19 = var18.getOutlinePaint();
//     var18.setBackgroundAlpha(100.0f);
//     float var22 = var18.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("Jan", var16, (org.jfree.chart.plot.Plot)var18, true);
//     boolean var25 = var24.isNotify();
//     java.awt.RenderingHints var26 = var24.getRenderingHints();
//     var11.setRenderingHints(var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var24
//     assertTrue("Contract failed: equals-hashcode on var11 and var24", var11.equals(var24) ? var11.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var11
//     assertTrue("Contract failed: equals-hashcode on var24 and var11", var24.equals(var11) ? var24.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    var1.setLabelInsets(var7);
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var1 = var0.getArrangement();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
//     boolean var3 = var0.isEmpty();
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     double var7 = var5.calculateBottomInset((-1.0d));
//     double var8 = var5.getBottom();
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var10 = var9.getArrangement();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var13 = null;
//     var11.setMarkerBand(var13);
//     java.text.NumberFormat var15 = var11.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 10.0d, 1.0d);
//     var21.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var23);
//     org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var21, (org.jfree.data.general.Dataset)var23, (java.lang.Comparable)100.0f);
//     var26.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var32 = var26.getBounds();
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var11.lengthToJava2D(0.0d, var32, var33);
//     var9.setBounds(var32);
//     java.awt.geom.Rectangle2D var38 = var5.createOutsetRectangle(var32, true, false);
//     var0.setBounds(var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.chart.block.LineBorder var10 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var11 = var10.getInsets();
//     double var13 = var11.calculateBottomInset((-1.0d));
//     double var14 = var11.getBottom();
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var16 = var15.getArrangement();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var19 = null;
//     var17.setMarkerBand(var19);
//     java.text.NumberFormat var21 = var17.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, 1.0d);
//     var27.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var29);
//     org.jfree.chart.title.LegendItemBlockContainer var32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var27, (org.jfree.data.general.Dataset)var29, (java.lang.Comparable)100.0f);
//     var32.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var38 = var32.getBounds();
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var17.lengthToJava2D(0.0d, var38, var39);
//     var15.setBounds(var38);
//     java.awt.geom.Rectangle2D var44 = var11.createOutsetRectangle(var38, true, false);
//     org.jfree.chart.entity.AxisLabelEntity var47 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, (java.awt.Shape)var44, "poly", "0.2");
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     java.awt.Paint var10 = var1.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var15 = var14.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var16 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var17 = var16.getCompletePaint();
//     org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var10, (java.awt.Paint)var14, var17, (java.awt.Paint)var21);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var25 = null;
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var28 = null;
//     var26.setMarkerBand(var28);
//     java.text.NumberFormat var30 = var26.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 10.0d, 1.0d);
//     var36.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var38);
//     org.jfree.chart.title.LegendItemBlockContainer var41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var36, (org.jfree.data.general.Dataset)var38, (java.lang.Comparable)100.0f);
//     var41.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var47 = var41.getBounds();
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var26.lengthToJava2D(0.0d, var47, var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var51 = var50.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var52 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var53 = var52.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var54 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var56 = var54.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var57 = var54.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var60 = var54.getItemStroke((-1), 100);
//     boolean var61 = var53.equals((java.lang.Object)var60);
//     var50.setRangeCrosshairStroke(var60);
//     int var63 = var50.getDatasetCount();
//     org.jfree.chart.axis.AxisSpace var64 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.AxisSpace var65 = new org.jfree.chart.axis.AxisSpace();
//     double var66 = var65.getBottom();
//     var64.ensureAtLeast(var65);
//     var50.setFixedRangeAxisSpace(var65);
//     org.jfree.chart.axis.CategoryAxis3D var70 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var71 = null;
//     org.jfree.chart.plot.WaferMapPlot var72 = new org.jfree.chart.plot.WaferMapPlot(var71);
//     var70.addChangeListener((org.jfree.chart.event.AxisChangeListener)var72);
//     java.awt.Font var74 = var70.getLabelFont();
//     java.lang.String var76 = var70.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var70.setAxisLineVisible(true);
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var80 = null;
//     var79.setNumberFormatOverride(var80);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var82 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     var23.drawItem(var24, var25, var47, var50, (org.jfree.chart.axis.CategoryAxis)var70, (org.jfree.chart.axis.ValueAxis)var79, (org.jfree.data.category.CategoryDataset)var82, 100, 4, 0);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var11 = var10.getRed();
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var12.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
//     boolean var17 = var10.equals((java.lang.Object)var16);
//     org.jfree.chart.axis.NumberTick var19 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0f, "org.jfree.chart.ChartColor[r=0,g=0,b=0]", var6, var16, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
    java.lang.Object var3 = null;
    int var4 = var2.compareTo(var3);
    int var6 = var2.compareTo((java.lang.Object)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var6 = var5.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var8 = var5.getRangeAxisEdge(100);
//     org.jfree.chart.event.PlotChangeEvent var9 = null;
//     var5.notifyListeners(var9);
//     org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     double var14 = var12.calculateBottomInset((-1.0d));
//     double var15 = var12.getBottom();
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var17 = var16.getArrangement();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var20 = null;
//     var18.setMarkerBand(var20);
//     java.text.NumberFormat var22 = var18.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 10.0d, 1.0d);
//     var28.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var30);
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var28, (org.jfree.data.general.Dataset)var30, (java.lang.Comparable)100.0f);
//     var33.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var39 = var33.getBounds();
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var18.lengthToJava2D(0.0d, var39, var40);
//     var16.setBounds(var39);
//     java.awt.geom.Rectangle2D var45 = var12.createOutsetRectangle(var39, true, false);
//     var3.drawOutline(var4, var5, var39);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     var0.setBackgroundAlpha((-1.0f));
//     java.awt.Font var10 = var0.getAngleLabelFont();
//     double var11 = var0.getMaxRadius();
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var3 = var2.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var6.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var12 = var6.getItemStroke((-1), 100);
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     var2.setRangeCrosshairStroke(var12);
//     org.jfree.chart.LegendItemCollection var15 = var2.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     boolean var17 = var16.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var18 = var16.getMarkerBand();
//     org.jfree.chart.plot.Marker var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawRangeMarker(var1, var2, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     java.lang.Boolean var23 = var0.getSeriesShapesVisible(0);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var26 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var27 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var28 = var27.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var29 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var32 = var29.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var35 = var29.getItemStroke((-1), 100);
//     boolean var36 = var28.equals((java.lang.Object)var35);
//     var25.setRangeCrosshairStroke(var35);
//     int var38 = var25.getDatasetCount();
//     org.jfree.chart.renderer.category.StackedBarRenderer var40 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var42 = var40.getSeriesItemLabelGenerator(100);
//     var40.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
//     var40.setMinimumBarLength(1.0d);
//     java.awt.Stroke var49 = var40.getBaseStroke();
//     int var50 = var40.getColumnCount();
//     var25.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40, false);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var54 = var53.getNumberFormatOverride();
//     java.awt.geom.Rectangle2D var55 = null;
//     var0.drawRangeGridline(var24, var25, (org.jfree.chart.axis.ValueAxis)var53, var55, 0.0d);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var1.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     boolean var12 = var1.hasListener((java.util.EventListener)var11);
//     var1.setVisible(false);
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearDomainAxes();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     java.awt.Paint var20 = var19.getSeparatorPaint();
//     var16.setOutlinePaint(var20);
//     var15.setRadiusGridlinePaint(var20);
//     var15.setBackgroundAlpha((-1.0f));
//     java.awt.Font var25 = var15.getAngleLabelFont();
//     var1.setTickLabelFont(var25);
//     
//     // Checks the contract:  equals-hashcode on var11 and var19
//     assertTrue("Contract failed: equals-hashcode on var11 and var19", var11.equals(var19) ? var11.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var11
//     assertTrue("Contract failed: equals-hashcode on var19 and var11", var19.equals(var11) ? var19.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var2);
    org.jfree.data.Range var4 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
    boolean var11 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
    var7.setLabelInsets(var13);
    java.awt.Paint var16 = var7.getTickLabelPaint((java.lang.Comparable)1.0f);
    org.jfree.chart.ChartColor var20 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var21 = var20.getColorSpace();
    org.jfree.chart.renderer.category.GanttRenderer var22 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var23 = var22.getCompletePaint();
    org.jfree.chart.ChartColor var27 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var28 = var27.getColorSpace();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var29 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var16, (java.awt.Paint)var20, var23, (java.awt.Paint)var27);
    var1.setSeriesPaint(100, (java.awt.Paint)var20, true);
    org.jfree.chart.renderer.AreaRendererEndType var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setEndType(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("black");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 0.0f, 0, var7);
//     org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var9.setSeriesLinesVisible(1, true);
//     java.lang.Object var13 = var9.clone();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var16 = var15.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.Marker var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawRangeMarker(var14, var15, var17, var18, var19);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var23);
//     var22.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
//     java.awt.Font var26 = var22.getLabelFont();
//     var9.setBaseItemLabelFont(var26);
//     boolean var28 = var8.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     org.jfree.chart.plot.Plot var23 = var21.getPlot();
//     var21.setTextAntiAlias(true);
//     java.awt.Image var26 = null;
//     var21.setBackgroundImage(var26);
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var30 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(100);
//     boolean var33 = var29.equals((java.lang.Object)var30);
//     org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
//     var29.setLabelInsets(var35);
//     java.awt.Paint var38 = var29.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var42 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var43 = var42.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var44 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var45 = var44.getCompletePaint();
//     org.jfree.chart.ChartColor var49 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var51 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var38, (java.awt.Paint)var42, var45, (java.awt.Paint)var49);
//     var21.setBorderPaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var2.notifyListeners(var3);
    boolean var5 = var2.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainAxes();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Paint var5 = var4.getSeparatorPaint();
    var1.setOutlinePaint(var5);
    var0.setRadiusGridlinePaint(var5);
    var0.setBackgroundAlpha((-1.0f));
    java.awt.Font var10 = var0.getAngleLabelFont();
    org.jfree.chart.axis.ValueAxis var11 = var0.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStartValue(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     long var5 = var3.toTimelineValue((-1L));
//     long var7 = var3.getTimeFromLong((-1L));
//     var3.addBaseTimelineException(10L);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainAxes();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     var0.setFixedLegendItems(var2);
//     org.jfree.chart.LegendItemCollection var4 = new org.jfree.chart.LegendItemCollection();
//     var2.addAll(var4);
//     
//     // Checks the contract:  equals-hashcode on var2 and var4
//     assertTrue("Contract failed: equals-hashcode on var2 and var4", var2.equals(var4) ? var2.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var2
//     assertTrue("Contract failed: equals-hashcode on var4 and var2", var4.equals(var2) ? var4.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     java.lang.Object var23 = var9.getSource();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     java.awt.Font var27 = var26.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var28 = null;
//     org.jfree.chart.plot.WaferMapPlot var29 = new org.jfree.chart.plot.WaferMapPlot(var28);
//     java.awt.Paint var30 = var29.getOutlinePaint();
//     var29.setBackgroundAlpha(100.0f);
//     float var33 = var29.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("Jan", var27, (org.jfree.chart.plot.Plot)var29, true);
//     var9.setChart(var35);
//     
//     // Checks the contract:  equals-hashcode on var12 and var26
//     assertTrue("Contract failed: equals-hashcode on var12 and var26", var12.equals(var26) ? var12.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var12
//     assertTrue("Contract failed: equals-hashcode on var26 and var12", var26.equals(var12) ? var26.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var29
//     assertTrue("Contract failed: equals-hashcode on var15 and var29", var15.equals(var29) ? var15.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var15
//     assertTrue("Contract failed: equals-hashcode on var29 and var15", var29.equals(var15) ? var29.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var35
//     assertTrue("Contract failed: equals-hashcode on var21 and var35", var21.equals(var35) ? var21.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var21
//     assertTrue("Contract failed: equals-hashcode on var35 and var21", var35.equals(var21) ? var35.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.data.general.Dataset var3 = null;
    var2.setDataset(var3);
    org.jfree.data.time.TimePeriodFormatException var6 = new org.jfree.data.time.TimePeriodFormatException("TextAnchor.CENTER");
    java.lang.Throwable[] var7 = var6.getSuppressed();
    boolean var8 = var2.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var5 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var5.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var8 = var5.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var11 = var5.getItemStroke((-1), 100);
    boolean var12 = var4.equals((java.lang.Object)var11);
    var1.setInsets(var4);
    org.jfree.chart.event.PlotChangeEvent var14 = null;
    var1.notifyListeners(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 10);
    org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var3.setSeriesLinesVisible(1, true);
    java.lang.Object var7 = var3.clone();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    boolean var10 = var9.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.Marker var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var3.drawRangeMarker(var8, var9, var11, var12, var13);
    int var15 = var2.compareTo((java.lang.Object)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var16 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("0.2", var1);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     java.awt.Paint var8 = var0.getRadiusGridlinePaint();
//     java.awt.Stroke var9 = var0.getRadiusGridlineStroke();
//     double var10 = var0.getMaxRadius();
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    java.awt.Paint var4 = var3.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 0.0f, 0, var7);
    java.util.List var9 = var8.getLines();
    java.awt.Font var11 = null;
    org.jfree.chart.block.LineBorder var12 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
    java.awt.Paint var14 = var12.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addLine("org.jfree.chart.ChartColor[r=0,g=0,b=0]", var11, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
    double var4 = var3.getXOffset();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var9 = null;
    var7.setMarkerBand(var9);
    java.text.NumberFormat var11 = var7.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 10.0d, 1.0d);
    var17.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var19);
    org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var17, (org.jfree.data.general.Dataset)var19, (java.lang.Comparable)100.0f);
    var22.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var28 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var7.lengthToJava2D(0.0d, var28, var29);
    org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var31.setSeriesLinesVisible(1, true);
    java.lang.Object var35 = var31.clone();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    boolean var38 = var37.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.Marker var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    var31.drawRangeMarker(var36, var37, var39, var40, var41);
    org.jfree.chart.renderer.category.StackedBarRenderer var43 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var45 = var43.getSeriesItemLabelGenerator(100);
    boolean var47 = var43.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var48 = null;
    var43.setBaseURLGenerator(var48);
    var37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var43, false);
    var37.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var57 = null;
    org.jfree.chart.plot.WaferMapPlot var58 = new org.jfree.chart.plot.WaferMapPlot(var57);
    var56.addChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
    var56.setLabelAngle(0.0d);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.NumberTickUnit var63 = var62.getTickUnit();
    org.jfree.data.RangeType var64 = var62.getRangeType();
    boolean var65 = var62.isAutoTickUnitSelection();
    org.jfree.chart.axis.TickUnitSource var66 = var62.getStandardTickUnits();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var70 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
    double var71 = var70.getXOffset();
    org.jfree.chart.renderer.category.LineRenderer3D var72 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var72.setSeriesLinesVisible(1, true);
    java.lang.Object var76 = var72.clone();
    java.awt.Graphics2D var77 = null;
    org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
    boolean var79 = var78.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var80 = null;
    org.jfree.chart.plot.Marker var81 = null;
    java.awt.geom.Rectangle2D var82 = null;
    var72.drawRangeMarker(var77, var78, var80, var81, var82);
    var78.clearDomainMarkers((-1));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var86 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var87 = var86.clone();
    var78.setDataset((org.jfree.data.category.CategoryDataset)var86);
    org.jfree.data.Range var89 = var70.findRangeBounds((org.jfree.data.category.CategoryDataset)var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.drawItem(var5, var6, var28, var37, (org.jfree.chart.axis.CategoryAxis)var56, (org.jfree.chart.axis.ValueAxis)var62, (org.jfree.data.category.CategoryDataset)var86, 10, 100, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     java.awt.Paint var8 = var0.getRadiusGridlinePaint();
//     java.awt.Stroke var9 = var0.getRadiusGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var0.zoomRangeAxes(100.0d, 10.0d, var12, var13);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    java.awt.Paint var4 = var3.getOutlinePaint();
    var3.setBackgroundAlpha(100.0f);
    boolean var7 = var1.hasListener((java.util.EventListener)var3);
    java.lang.Comparable var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.clearDomainAxes();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Paint var14 = var13.getSeparatorPaint();
    var10.setOutlinePaint(var14);
    var9.setRadiusGridlinePaint(var14);
    var9.setBackgroundAlpha((-1.0f));
    java.awt.Font var19 = var9.getAngleLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var8, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "");
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.0d, (-1.0f), (-1.0f));
    java.io.ObjectOutputStream var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    java.awt.Graphics2D var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    boolean var30 = var6.render(var26, var27, 2, var29);
    org.jfree.chart.renderer.category.LineRenderer3D var32 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var32.setSeriesLinesVisible(1, true);
    var6.setRenderer(4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32, false);
    org.jfree.chart.annotations.CategoryAnnotation var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
//     java.lang.Object var3 = var2.clone();
//     java.lang.Object var4 = var2.clone();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     org.jfree.chart.event.ChartProgressListener var12 = null;
//     var11.removeProgressListener(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var16 = var15.getArrangement();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var19 = null;
//     var17.setMarkerBand(var19);
//     java.text.NumberFormat var21 = var17.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 10.0d, 1.0d);
//     var27.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var29);
//     org.jfree.chart.title.LegendItemBlockContainer var32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var27, (org.jfree.data.general.Dataset)var29, (java.lang.Comparable)100.0f);
//     var32.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var38 = var32.getBounds();
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var17.lengthToJava2D(0.0d, var38, var39);
//     var15.setBounds(var38);
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     var11.draw(var14, var38, var42);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     java.awt.Paint var10 = var1.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var15 = var14.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var16 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var17 = var16.getCompletePaint();
//     org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var10, (java.awt.Paint)var14, var17, (java.awt.Paint)var21);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot(var24);
//     java.awt.Font var28 = null;
//     org.jfree.data.general.WaferMapDataset var29 = null;
//     org.jfree.chart.plot.WaferMapPlot var30 = new org.jfree.chart.plot.WaferMapPlot(var29);
//     java.awt.Paint var31 = var30.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var28, var31, 0.0f, 0, var34);
//     var25.setSectionPaint((java.lang.Comparable)(-1.0d), var31);
//     double var37 = var25.getInnerSeparatorExtension();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var41 = var40.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var43 = var42.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var44 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var46 = var44.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var44.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var50 = var44.getItemStroke((-1), 100);
//     boolean var51 = var43.equals((java.lang.Object)var50);
//     var40.setRangeCrosshairStroke(var50);
//     org.jfree.chart.LegendItemCollection var53 = var40.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     boolean var55 = var54.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var56 = var54.getMarkerBand();
//     org.jfree.chart.plot.Marker var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     var38.drawRangeMarker(var39, var40, (org.jfree.chart.axis.ValueAxis)var54, var57, var58);
//     java.awt.Paint var60 = var38.getBaseOutlinePaint();
//     var25.setLabelPaint(var60);
//     var23.setNegativeBarPaint(var60);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var3.getPreviousDayOfWeek(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var8 = var7.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getRangeAxisEdge(100);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var7.notifyListeners(var11);
//     var7.clearRangeMarkers();
//     org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var15 = var14.getInsets();
//     double var17 = var15.calculateBottomInset((-1.0d));
//     double var18 = var15.getBottom();
//     org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var20 = var19.getArrangement();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var23 = null;
//     var21.setMarkerBand(var23);
//     java.text.NumberFormat var25 = var21.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 10.0d, 1.0d);
//     var31.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var33);
//     org.jfree.chart.title.LegendItemBlockContainer var36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var31, (org.jfree.data.general.Dataset)var33, (java.lang.Comparable)100.0f);
//     var36.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var42 = var36.getBounds();
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var21.lengthToJava2D(0.0d, var42, var43);
//     var19.setBounds(var42);
//     java.awt.geom.Rectangle2D var48 = var15.createOutsetRectangle(var42, true, false);
//     var3.drawOutline(var6, var7, var48);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(10, 10);
    org.jfree.chart.renderer.category.LineRenderer3D var5 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var5.setSeriesLinesVisible(1, true);
    java.lang.Object var9 = var5.clone();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    boolean var12 = var11.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.Marker var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    var5.drawRangeMarker(var10, var11, var13, var14, var15);
    int var17 = var4.compareTo((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(2, (java.lang.Comparable)var17, (java.lang.Number)(byte)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Font var2 = var1.getLabelFont();
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var1.markerChanged(var3);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var8 = null;
    var6.setMarkerBand(var8);
    java.text.NumberFormat var10 = var6.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 10.0d, 1.0d);
    var16.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var18);
    org.jfree.chart.title.LegendItemBlockContainer var21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, (org.jfree.data.general.Dataset)var18, (java.lang.Comparable)100.0f);
    var21.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var27 = var21.getBounds();
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var6.lengthToJava2D(0.0d, var27, var28);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
    java.awt.Paint var32 = var31.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var34 = var33.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var35 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var37 = var35.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var38 = var35.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var41 = var35.getItemStroke((-1), 100);
    boolean var42 = var34.equals((java.lang.Object)var41);
    var31.setInsets(var34);
    var31.setShadowYOffset(1.0d);
    org.jfree.chart.labels.PieToolTipGenerator var46 = var31.getToolTipGenerator();
    java.awt.Shape var47 = var31.getLegendItemShape();
    org.jfree.chart.plot.PlotRenderingInfo var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var50 = var1.initialise(var5, var27, (org.jfree.chart.plot.PiePlot)var31, (java.lang.Integer)(-1), var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.KeyToGroupMap var1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(short)100);
    var1.mapKeyToGroup((java.lang.Comparable)(byte)0, (java.lang.Comparable)0);
    int var5 = var1.getGroupCount();
    int var7 = var1.getGroupIndex((java.lang.Comparable)0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var2 = var0.getFixedDomainAxisSpace();
    boolean var3 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.ValueAxis var5 = var0.getRangeAxis(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("TextAnchor.CENTER");
    org.jfree.data.category.CategoryDataset var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel(var2, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.ColumnArrangement var5 = new org.jfree.chart.block.ColumnArrangement(var1, var2, 10.0d, 1.0d);
    var5.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, (org.jfree.data.general.Dataset)var7, (java.lang.Comparable)100.0f);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("ERROR : Relative To String");
    boolean var13 = var7.equals((java.lang.Object)"ERROR : Relative To String");
    java.lang.Number var16 = var7.getStdDevValue((java.lang.Comparable)0L, (java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var18 = var0.generateColumnLabel((org.jfree.data.category.CategoryDataset)var7, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var3.drawBackground(var5, var6);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.chart.event.MarkerChangeEvent var5 = null;
//     var3.markerChanged(var5);
//     boolean var7 = var0.equals((java.lang.Object)var3);
//     double var8 = var3.getMaximumExplodePercent();
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    boolean var26 = var24.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStartValue((java.lang.Comparable)(short)(-1), (java.lang.Comparable)'4');
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)100.0d);
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var7, (java.lang.Comparable)(byte)100);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 10.0d, 1.0d);
//     var15.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var17);
//     org.jfree.chart.title.LegendItemBlockContainer var20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var15, (org.jfree.data.general.Dataset)var17, (java.lang.Comparable)100.0f);
//     var20.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var26 = var20.getBounds();
//     org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
//     java.awt.Stroke var32 = var27.getItemStroke(0, 0);
//     java.awt.Paint var35 = var27.getItemPaint(1, 1);
//     java.lang.Object var36 = var9.draw(var10, var26, (java.lang.Object)var35);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     java.awt.Paint var10 = var1.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var15 = var14.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var16 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var17 = var16.getCompletePaint();
//     org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var10, (java.awt.Paint)var14, var17, (java.awt.Paint)var21);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var24);
//     org.jfree.data.Range var26 = var23.findRangeBounds((org.jfree.data.category.CategoryDataset)var24);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var27, (java.lang.Comparable)100.0d);
//     org.jfree.data.Range var30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var27);
//     org.jfree.data.Range var31 = var23.findRangeBounds((org.jfree.data.category.CategoryDataset)var27);
//     
//     // Checks the contract:  equals-hashcode on var24 and var27
//     assertTrue("Contract failed: equals-hashcode on var24 and var27", var24.equals(var27) ? var24.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var24
//     assertTrue("Contract failed: equals-hashcode on var27 and var24", var27.equals(var24) ? var27.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var1.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     boolean var12 = var1.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.urls.PieURLGenerator var13 = var11.getURLGenerator();
//     var11.setIgnoreNullValues(false);
//     java.lang.Comparable var16 = null;
//     double var17 = var11.getExplodePercent(var16);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, (-1.0d));
    boolean var10 = var6.equals((java.lang.Object)(-1.0d));
    org.jfree.chart.axis.CategoryLabelWidthType var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var14 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var6, Double.NaN, var12, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.util.EventListener var7 = null;
    boolean var8 = var0.hasListener(var7);
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var14 = var13.getTickMarkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-1), var14, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "RectangleEdge.RIGHT", "");
    org.jfree.chart.ui.Library[] var5 = var4.getOptionalLibraries();
    boolean var7 = var4.equals((java.lang.Object)(short)10);
    java.lang.String var8 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleEdge.RIGHT"+ "'", var8.equals("RectangleEdge.RIGHT"));

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(10, 10);
    java.lang.Object var4 = null;
    int var5 = var3.compareTo(var4);
    org.jfree.data.general.SeriesChangeEvent var6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var5);
    var0.seriesChanged(var6);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var0.getStartValue((java.lang.Comparable)Double.NaN, (java.lang.Comparable)var12, 4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();
    org.jfree.chart.renderer.category.StackedBarRenderer var3 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var3.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var8 = var3.getSeriesPositiveItemLabelPosition(2);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var3);
    org.jfree.chart.renderer.category.GanttRenderer var11 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var12 = var11.getCompletePaint();
    java.awt.Paint var13 = var11.getIncompletePaint();
    var3.setSeriesItemLabelPaint(2, var13, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var25 = var24.getInsets();
//     double var27 = var25.calculateBottomInset((-1.0d));
//     double var28 = var25.getBottom();
//     org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var30 = var29.getArrangement();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var33 = null;
//     var31.setMarkerBand(var33);
//     java.text.NumberFormat var35 = var31.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 10.0d, 1.0d);
//     var41.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var43 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var43);
//     org.jfree.chart.title.LegendItemBlockContainer var46 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, (org.jfree.data.general.Dataset)var43, (java.lang.Comparable)100.0f);
//     var46.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var52 = var46.getBounds();
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     double var54 = var31.lengthToJava2D(0.0d, var52, var53);
//     var29.setBounds(var52);
//     java.awt.geom.Rectangle2D var58 = var25.createOutsetRectangle(var52, true, false);
//     java.awt.geom.Point2D var59 = null;
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     var21.draw(var23, var58, var59, var60);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Paint var2 = var1.getSeparatorPaint();
//     double var3 = var1.getLabelGap();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     var1.setLegendItemShape(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var10 = null;
//     org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot(var10);
//     var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
//     java.awt.Font var13 = var9.getLabelFont();
//     java.lang.String var15 = var9.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var9.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
//     boolean var20 = var9.hasListener((java.util.EventListener)var19);
//     org.jfree.chart.renderer.category.LineRenderer3D var23 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var23.setSeriesLinesVisible(1, true);
//     java.lang.Object var27 = var23.clone();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var30 = var29.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.plot.Marker var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var23.drawRangeMarker(var28, var29, var31, var32, var33);
//     org.jfree.chart.renderer.category.StackedBarRenderer var35 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var37 = var35.getSeriesItemLabelGenerator(100);
//     boolean var39 = var35.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var40 = null;
//     var35.setBaseURLGenerator(var40);
//     var29.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var35, false);
//     var29.setRangeCrosshairValue(0.0d, true);
//     var29.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.util.HorizontalAlignment var50 = null;
//     org.jfree.chart.util.VerticalAlignment var51 = null;
//     org.jfree.chart.block.ColumnArrangement var54 = new org.jfree.chart.block.ColumnArrangement(var50, var51, 10.0d, 1.0d);
//     var54.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var56 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var56);
//     org.jfree.chart.title.LegendItemBlockContainer var59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var54, (org.jfree.data.general.Dataset)var56, (java.lang.Comparable)100.0f);
//     var59.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var65 = var59.getBounds();
//     java.awt.geom.Point2D var66 = null;
//     org.jfree.chart.plot.PlotState var67 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var68 = null;
//     var29.draw(var49, var65, var66, var67, var68);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var71 = var70.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var73 = var70.getRangeAxisEdge(100);
//     double var74 = var9.getCategoryStart(4, 100, var65, var73);
//     var1.drawOutline(var7, var65);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.data.Range var26 = null;
    org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, (-1.0d));
    org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, (-1.0d));
    var24.setRangeWithMargins(var30, true, false);
    org.jfree.chart.renderer.category.StackedBarRenderer var34 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var37 = var34.getBaseNegativeItemLabelPosition();
    boolean var39 = var34.isSeriesVisible(10);
    java.awt.Paint var40 = var34.getBasePaint();
    java.awt.Paint var41 = var34.getBasePaint();
    var24.setTickLabelPaint(var41);
    boolean var43 = var24.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     double var7 = var4.getRangeLowerBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var9 = var4.getRowKey(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     double var4 = var3.getXOffset();
//     org.jfree.chart.renderer.category.LineRenderer3D var5 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var5.setSeriesLinesVisible(1, true);
//     java.lang.Object var9 = var5.clone();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var5.drawRangeMarker(var10, var11, var13, var14, var15);
//     var11.clearDomainMarkers((-1));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var20 = var19.clone();
//     var11.setDataset((org.jfree.data.category.CategoryDataset)var19);
//     org.jfree.data.Range var22 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var19);
//     org.jfree.chart.axis.AxisState var24 = new org.jfree.chart.axis.AxisState(10.0d);
//     var24.cursorLeft(10.0d);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var29 = var28.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var31 = var28.getRangeAxisEdge(100);
//     var24.moveCursor(1.0E-5d, var31);
//     boolean var33 = var3.equals((java.lang.Object)1.0E-5d);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    var1.setLabelInsets(var7);
    java.awt.Paint var10 = var1.getTickLabelPaint((java.lang.Comparable)1.0f);
    org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var15 = var14.getColorSpace();
    org.jfree.chart.renderer.category.GanttRenderer var16 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var17 = var16.getCompletePaint();
    org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var22 = var21.getColorSpace();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var10, (java.awt.Paint)var14, var17, (java.awt.Paint)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setSeriesVisibleInLegend((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var3 = var2.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var6.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var12 = var6.getItemStroke((-1), 100);
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     var2.setRangeCrosshairStroke(var12);
//     org.jfree.chart.LegendItemCollection var15 = var2.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     boolean var17 = var16.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var18 = var16.getMarkerBand();
//     org.jfree.chart.plot.Marker var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawRangeMarker(var1, var2, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var2.handleClick(2, 0, var24);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((-1));
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    boolean var5 = var4.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var8.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var14 = var8.getItemStroke((-1), 100);
    boolean var15 = var7.equals((java.lang.Object)var14);
    var4.setRangeCrosshairStroke(var14);
    int var17 = var4.getDatasetCount();
    org.jfree.chart.renderer.category.StackedBarRenderer var19 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getSeriesItemLabelGenerator(100);
    var19.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
    var19.setMinimumBarLength(1.0d);
    java.awt.Stroke var28 = var19.getBaseStroke();
    int var29 = var19.getColumnCount();
    var4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    var0.setObject((java.lang.Comparable)' ', (java.lang.Object)var4);
    org.jfree.chart.axis.AxisLocation var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(var33, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     boolean var16 = var12.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
//     var6.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var28 = var26.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.StackedBarRenderer var29 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getSeriesItemLabelGenerator(100);
//     var29.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
//     var26.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var29, false);
//     var29.setAutoPopulateSeriesPaint(false);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var29, false);
//     
//     // Checks the contract:  equals-hashcode on var6 and var26
//     assertTrue("Contract failed: equals-hashcode on var6 and var26", var6.equals(var26) ? var6.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var6
//     assertTrue("Contract failed: equals-hashcode on var26 and var6", var26.equals(var6) ? var26.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var29.", var12.equals(var29) == var29.equals(var12));
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.TaskSeries var7 = var4.getSeries(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     var0.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var0.zoomRangeAxes((-1.0d), 1.0d, var12, var13);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     org.jfree.chart.plot.Plot var23 = var21.getPlot();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var27 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var28);
//     org.jfree.data.Range var30 = var27.findRangeBounds((org.jfree.data.category.CategoryDataset)var28);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var34 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getSeriesItemLabelGenerator(100);
//     boolean var37 = var33.equals((java.lang.Object)var34);
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var39 = var38.getInsets();
//     var33.setLabelInsets(var39);
//     java.awt.Paint var42 = var33.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var46 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var47 = var46.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var48 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var49 = var48.getCompletePaint();
//     org.jfree.chart.ChartColor var53 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var54 = var53.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var55 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var42, (java.awt.Paint)var46, var49, (java.awt.Paint)var53);
//     var27.setSeriesPaint(100, (java.awt.Paint)var46, true);
//     var24.setSeriesItemLabelPaint(100, (java.awt.Paint)var46, false);
//     var21.setBorderPaint((java.awt.Paint)var46);
//     
//     // Checks the contract:  equals-hashcode on var6 and var38
//     assertTrue("Contract failed: equals-hashcode on var6 and var38", var6.equals(var38) ? var6.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var6
//     assertTrue("Contract failed: equals-hashcode on var38 and var6", var38.equals(var6) ? var38.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(0, 0, 0);
    int var5 = var4.getRed();
    java.awt.Color var6 = java.awt.Color.getColor("Jan", (java.awt.Color)var4);
    java.lang.String var7 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    int var8 = var6.getRed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "black"+ "'", var7.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var4.getEndValue((java.lang.Comparable)0L, (java.lang.Comparable)2.0f, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 1.0d);
    var4.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var6, (java.lang.Comparable)100.0f);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("ERROR : Relative To String");
    boolean var12 = var6.equals((java.lang.Object)"ERROR : Relative To String");
    java.lang.Number var15 = var6.getStdDevValue((java.lang.Comparable)0L, (java.lang.Comparable)100.0d);
    org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var6.getValue(4, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == true);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var2 = var0.getFixedLegendItems();
//     var0.zoom(1.0d);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.awt.Font var13 = var12.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     java.awt.Paint var16 = var15.getOutlinePaint();
//     var15.setBackgroundAlpha(100.0f);
//     float var19 = var15.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
//     var9.setChart(var21);
//     org.jfree.chart.plot.Plot var23 = var21.getPlot();
//     var21.setTextAntiAlias(true);
//     java.awt.Image var26 = null;
//     var21.setBackgroundImage(var26);
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var30 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(100);
//     boolean var33 = var29.equals((java.lang.Object)var30);
//     org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
//     var29.setLabelInsets(var35);
//     java.awt.Paint var38 = var29.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var42 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var43 = var42.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var44 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var45 = var44.getCompletePaint();
//     org.jfree.chart.ChartColor var49 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var51 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var38, (java.awt.Paint)var42, var45, (java.awt.Paint)var49);
//     var21.setBackgroundPaint((java.awt.Paint)var49);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    var11.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var20 = var11.createBufferedImage(100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     boolean var16 = var12.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
//     var6.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.renderer.category.LineRenderer3D var24 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var24.setSeriesLinesVisible(1, true);
//     java.lang.Object var28 = var24.clone();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var31 = var30.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.Marker var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var24.drawRangeMarker(var29, var30, var32, var33, var34);
//     org.jfree.chart.renderer.category.StackedBarRenderer var36 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var38 = var36.getSeriesItemLabelGenerator(100);
//     boolean var40 = var36.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var41 = null;
//     var36.setBaseURLGenerator(var41);
//     var30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var36, false);
//     var30.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var49 = var30.getDataRange((org.jfree.chart.axis.ValueAxis)var48);
//     org.jfree.data.Range var50 = null;
//     org.jfree.data.Range var52 = org.jfree.data.Range.expandToInclude(var50, (-1.0d));
//     org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, (-1.0d));
//     var48.setRangeWithMargins(var54, true, false);
//     org.jfree.chart.renderer.category.StackedBarRenderer var58 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var60 = var58.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var61 = var58.getBaseNegativeItemLabelPosition();
//     boolean var63 = var58.isSeriesVisible(10);
//     java.awt.Paint var64 = var58.getBasePaint();
//     java.awt.Paint var65 = var58.getBasePaint();
//     var48.setTickLabelPaint(var65);
//     var48.setTickMarksVisible(false);
//     org.jfree.data.Range var69 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getBaseURLGenerator();
    java.lang.Boolean var6 = null;
    var0.setSeriesCreateEntities(100, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var3);
//     var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     java.awt.Font var6 = var2.getLabelFont();
//     org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("RectangleEdge.RIGHT", var6);
//     org.jfree.chart.text.TextFragment var8 = var7.getFirstTextFragment();
//     org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var9.setSeriesLinesVisible(1, true);
//     java.lang.Object var13 = var9.clone();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var16 = var15.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.Marker var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawRangeMarker(var14, var15, var17, var18, var19);
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var23);
//     var22.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
//     java.awt.Font var26 = var22.getLabelFont();
//     var9.setBaseItemLabelFont(var26);
//     boolean var28 = var8.equals((java.lang.Object)var9);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     java.lang.String var2 = var1.toString();
//     org.jfree.chart.block.LengthConstraintType var3 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var10 = var8.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
//     org.jfree.chart.block.LengthConstraintType var11 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.2d, (org.jfree.data.Range)var1, var3, 0.2d, var10, var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.zoom(0.05d);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
    var0.setRange(var3, true, false);
    double var9 = var0.getUpperBound();
    var0.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Font var14 = null;
//     org.jfree.data.general.WaferMapDataset var15 = null;
//     org.jfree.chart.plot.WaferMapPlot var16 = new org.jfree.chart.plot.WaferMapPlot(var15);
//     java.awt.Paint var17 = var16.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var20 = null;
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var17, 0.0f, 0, var20);
//     var11.setSectionPaint((java.lang.Comparable)(-1.0d), var17);
//     double var23 = var11.getInnerSeparatorExtension();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var27 = var26.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var28 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var29 = var28.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var30 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var30.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var36 = var30.getItemStroke((-1), 100);
//     boolean var37 = var29.equals((java.lang.Object)var36);
//     var26.setRangeCrosshairStroke(var36);
//     org.jfree.chart.LegendItemCollection var39 = var26.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     boolean var41 = var40.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var42 = var40.getMarkerBand();
//     org.jfree.chart.plot.Marker var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     var24.drawRangeMarker(var25, var26, (org.jfree.chart.axis.ValueAxis)var40, var43, var44);
//     java.awt.Paint var46 = var24.getBaseOutlinePaint();
//     var11.setLabelPaint(var46);
//     boolean var48 = var1.hasListener((java.util.EventListener)var11);
//     
//     // Checks the contract:  equals-hashcode on var6 and var28
//     assertTrue("Contract failed: equals-hashcode on var6 and var28", var6.equals(var28) ? var6.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var6
//     assertTrue("Contract failed: equals-hashcode on var28 and var6", var28.equals(var6) ? var28.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
//     java.awt.Paint var12 = var0.getItemOutlinePaint(0, 0);
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     org.jfree.chart.renderer.category.StackedBarRenderer var14 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var14.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBaseNegativeItemLabelPosition();
//     boolean var19 = var14.isSeriesVisible(10);
//     java.awt.Paint var20 = var14.getBasePaint();
//     java.awt.Paint var23 = var14.getItemLabelPaint(0, 1);
//     java.awt.Paint var26 = var14.getItemOutlinePaint(0, 0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = null;
//     var14.setSeriesItemLabelGenerator(0, var28, false);
//     java.awt.Paint var32 = var14.lookupSeriesOutlinePaint(1);
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Stroke[] var34 = null;
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     java.awt.Font var39 = null;
//     org.jfree.data.general.WaferMapDataset var40 = null;
//     org.jfree.chart.plot.WaferMapPlot var41 = new org.jfree.chart.plot.WaferMapPlot(var40);
//     java.awt.Paint var42 = var41.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var45 = null;
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var39, var42, 0.0f, 0, var45);
//     var36.setSectionPaint((java.lang.Comparable)(-1.0d), var42);
//     double var48 = var36.getInnerSeparatorExtension();
//     boolean var49 = var36.isCircular();
//     java.awt.Stroke var50 = var36.getLabelLinkStroke();
//     java.awt.Stroke[] var51 = new java.awt.Stroke[] { var50};
//     org.jfree.chart.axis.Axis var56 = null;
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     org.jfree.chart.entity.ChartEntity var60 = new org.jfree.chart.entity.ChartEntity(var58, "");
//     org.jfree.chart.entity.AxisLabelEntity var63 = new org.jfree.chart.entity.AxisLabelEntity(var56, var58, "TextAnchor.CENTER", "");
//     org.jfree.chart.ChartColor var67 = new org.jfree.chart.ChartColor(0, 0, 0);
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.RingPlot var69 = new org.jfree.chart.plot.RingPlot(var68);
//     java.awt.Paint var70 = var69.getSeparatorPaint();
//     org.jfree.chart.axis.CategoryAxis3D var72 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var73 = var72.getTickMarkStroke();
//     var69.setBaseSectionOutlineStroke(var73);
//     org.jfree.chart.renderer.category.StackedBarRenderer var75 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var77 = var75.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var78 = var75.getBaseNegativeItemLabelPosition();
//     boolean var80 = var75.isSeriesVisible(10);
//     java.awt.Paint var81 = var75.getBasePaint();
//     java.awt.Paint var84 = var75.getItemLabelPaint(0, 1);
//     org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var58, (java.awt.Paint)var67, var73, var84);
//     java.awt.Shape var86 = var85.getShape();
//     java.awt.Shape[] var87 = new java.awt.Shape[] { var86};
//     org.jfree.chart.plot.DefaultDrawingSupplier var88 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var33, var34, var51, var87);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var78
//     assertTrue("Contract failed: equals-hashcode on var3 and var78", var3.equals(var78) ? var3.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var78
//     assertTrue("Contract failed: equals-hashcode on var17 and var78", var17.equals(var78) ? var17.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var3
//     assertTrue("Contract failed: equals-hashcode on var78 and var3", var78.equals(var3) ? var78.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var17
//     assertTrue("Contract failed: equals-hashcode on var78 and var17", var78.equals(var17) ? var78.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeCrosshairStroke(var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.plot.WaferMapPlot var17 = new org.jfree.chart.plot.WaferMapPlot(var16);
    java.awt.Paint var18 = var17.getOutlinePaint();
    var17.setBackgroundAlpha(100.0f);
    boolean var21 = var15.hasListener((java.util.EventListener)var17);
    var0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var15);
    java.awt.Paint var23 = var0.getDomainGridlinePaint();
    var0.configureDomainAxes();
    var0.setAnchorValue(Double.NaN, true);
    org.jfree.chart.axis.AxisLocation var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var28, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    org.jfree.data.KeyedObjects var3 = new org.jfree.data.KeyedObjects();
    java.util.List var4 = var3.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var3);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    boolean var12 = var11.isNotify();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    org.jfree.chart.title.Title var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addSubtitle(0, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    boolean var12 = var11.isNotify();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    org.jfree.chart.ChartRenderingInfo var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var18 = var11.createBufferedImage(10, 30, 0, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    var2.setNoDataMessage("");
    java.awt.Paint var5 = var2.getBaseSectionOutlinePaint();
    org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
    java.awt.Stroke var11 = var6.getItemStroke(0, 0);
    org.jfree.chart.plot.CategoryMarker var12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)"", var5, var11);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    boolean var14 = var13.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var16 = var13.getRangeAxisEdge(100);
    org.jfree.chart.event.PlotChangeEvent var17 = null;
    var13.notifyListeners(var17);
    var13.clearRangeMarkers();
    var12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var13);
    org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(10, 4, 10);
    var12.setPaint((java.awt.Paint)var24);
    org.jfree.chart.axis.Axis var30 = null;
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var32, "");
    org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity(var30, var32, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var41 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
    java.awt.Paint var44 = var43.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var47 = var46.getTickMarkStroke();
    var43.setBaseSectionOutlineStroke(var47);
    org.jfree.chart.renderer.category.StackedBarRenderer var49 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var51 = var49.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var52 = var49.getBaseNegativeItemLabelPosition();
    boolean var54 = var49.isSeriesVisible(10);
    java.awt.Paint var55 = var49.getBasePaint();
    java.awt.Paint var58 = var49.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var32, (java.awt.Paint)var41, var47, var58);
    org.jfree.data.general.Dataset var60 = null;
    var59.setDataset(var60);
    java.awt.Paint var62 = var59.getLinePaint();
    var12.setPaint(var62);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var12.notifyListeners(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     long var2 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Font var7 = var0.getSeriesItemLabelFont(0);
    var0.setSeriesVisible(1, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     boolean var5 = var0.getBaseShapesVisible();
//     java.lang.Boolean var7 = var0.getSeriesCreateEntities(100);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var10 = var9.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var13 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var15 = var13.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var13.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var19 = var13.getItemStroke((-1), 100);
//     boolean var20 = var12.equals((java.lang.Object)var19);
//     var9.setRangeCrosshairStroke(var19);
//     org.jfree.chart.renderer.category.LineRenderer3D var22 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var22.setSeriesLinesVisible(1, true);
//     java.lang.Object var26 = var22.clone();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var29 = var28.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.plot.Marker var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var22.drawRangeMarker(var27, var28, var30, var31, var32);
//     org.jfree.chart.renderer.category.StackedBarRenderer var34 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getSeriesItemLabelGenerator(100);
//     boolean var38 = var34.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var39 = null;
//     var34.setBaseURLGenerator(var39);
//     var28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var34, false);
//     var28.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var47 = var28.getDataRange((org.jfree.chart.axis.ValueAxis)var46);
//     double var48 = var46.getFixedAutoRange();
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     java.util.Date var50 = var49.getEnd();
//     org.jfree.chart.plot.CategoryMarker var51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var50);
//     java.awt.Stroke var52 = var51.getStroke();
//     org.jfree.chart.block.LineBorder var53 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var54 = var53.getInsets();
//     double var56 = var54.calculateBottomInset((-1.0d));
//     double var57 = var54.getBottom();
//     org.jfree.chart.block.BlockContainer var58 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var59 = var58.getArrangement();
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var61 = var60.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var62 = null;
//     var60.setMarkerBand(var62);
//     java.text.NumberFormat var64 = var60.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var66 = null;
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.ColumnArrangement var70 = new org.jfree.chart.block.ColumnArrangement(var66, var67, 10.0d, 1.0d);
//     var70.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var72 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var73 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var72);
//     org.jfree.chart.title.LegendItemBlockContainer var75 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var70, (org.jfree.data.general.Dataset)var72, (java.lang.Comparable)100.0f);
//     var75.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var81 = var75.getBounds();
//     org.jfree.chart.util.RectangleEdge var82 = null;
//     double var83 = var60.lengthToJava2D(0.0d, var81, var82);
//     var58.setBounds(var81);
//     java.awt.geom.Rectangle2D var87 = var54.createOutsetRectangle(var81, true, false);
//     var0.drawRangeMarker(var8, var9, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.plot.Marker)var51, var81);
//     
//     // Checks the contract:  equals-hashcode on var11 and var53
//     assertTrue("Contract failed: equals-hashcode on var11 and var53", var11.equals(var53) ? var11.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var11
//     assertTrue("Contract failed: equals-hashcode on var53 and var11", var53.equals(var11) ? var53.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.util.List var1 = var0.getKeys();
//     java.lang.Comparable var2 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var5.notifyListeners(var6);
//     org.jfree.chart.renderer.category.LineRenderer3D var8 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var8.setSeriesLinesVisible(1, true);
//     java.lang.Object var12 = var8.clone();
//     boolean var13 = var8.getBaseShapesVisible();
//     java.lang.Boolean var15 = var8.getSeriesCreateEntities(100);
//     java.awt.Paint var18 = var8.getItemFillPaint(0, 0);
//     var5.setBasePaint(var18);
//     var0.addObject(var2, (java.lang.Object)var5);
//     java.lang.Comparable var22 = var0.getKey((-1));
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.previous();
//     long var25 = var23.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var23.next();
//     int var27 = var0.getIndex((java.lang.Comparable)var23);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    org.jfree.chart.title.TextTitle var16 = null;
    var11.setTitle(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(0, 0, 0);
    int var5 = var4.getRed();
    java.awt.Color var6 = java.awt.Color.getColor("Jan", (java.awt.Color)var4);
    float[] var7 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var4.getColorComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Paint var2 = var1.getSeparatorPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelGenerator();
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var7 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getSeriesItemLabelGenerator(100);
//     boolean var10 = var6.equals((java.lang.Object)var7);
//     org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     var6.setLabelInsets(var12);
//     java.awt.Paint var15 = var6.getTickLabelPaint((java.lang.Comparable)1.0f);
//     var1.setLabelLinkPaint(var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     java.awt.Paint var19 = var18.getSeparatorPaint();
//     double var20 = var18.getLabelGap();
//     java.awt.Stroke var21 = var18.getSeparatorStroke();
//     var1.setBaseSectionOutlineStroke(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    double var3 = var1.getLabelGap();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    var1.setLegendItemShape(var5);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, 1.0d);
    var12.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var14);
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)100.0f);
    var17.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var23 = var17.getBounds();
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot(var24);
    java.awt.Paint var26 = var25.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var27 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var28 = var27.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var29 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var32 = var29.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var35 = var29.getItemStroke((-1), 100);
    boolean var36 = var28.equals((java.lang.Object)var35);
    var25.setInsets(var28);
    var25.setShadowYOffset(1.0d);
    org.jfree.chart.labels.PieToolTipGenerator var40 = var25.getToolTipGenerator();
    java.awt.Shape var41 = var25.getLegendItemShape();
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var44 = var1.initialise(var7, var23, (org.jfree.chart.plot.PiePlot)var25, (java.lang.Integer)10, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    java.awt.Color var2 = java.awt.Color.getColor("RectangleEdge.RIGHT", 30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.awt.Font var2 = null;
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var3);
//     java.awt.Paint var5 = var4.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var8 = null;
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var5, 0.0f, 0, var8);
//     java.util.List var10 = var9.getLines();
//     org.jfree.chart.text.TextLine var11 = var9.getLastLine();
//     org.jfree.chart.renderer.category.LineRenderer3D var12 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var12.setBaseLinesVisible(false);
//     boolean var17 = var12.getItemShapeFilled(0, 100);
//     boolean var18 = var12.getBaseLinesVisible();
//     boolean var19 = var9.equals((java.lang.Object)var12);
//     org.jfree.chart.text.TextBlockAnchor var20 = null;
//     java.awt.Font var23 = null;
//     org.jfree.data.general.WaferMapDataset var24 = null;
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var24);
//     java.awt.Paint var26 = var25.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, var26, 0.0f, 0, var29);
//     java.util.List var31 = var30.getLines();
//     org.jfree.chart.text.TextLine var32 = var30.getLastLine();
//     org.jfree.chart.text.TextBlockAnchor var33 = null;
//     org.jfree.chart.ChartColor var37 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var38 = var37.getRed();
//     org.jfree.chart.renderer.category.StackedBarRenderer var39 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = var39.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var42 = var39.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var43 = var42.getRotationAnchor();
//     boolean var44 = var37.equals((java.lang.Object)var43);
//     org.jfree.chart.axis.CategoryTick var46 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)10, var30, var33, var43, 0.0d);
//     org.jfree.chart.axis.CategoryTick var48 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)1.0E-8d, var9, var20, var43, 1.0E-5d);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.axis.Axis var4 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "");
    org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity(var4, var6, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    java.awt.Paint var18 = var17.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var17.setBaseSectionOutlineStroke(var21);
    org.jfree.chart.renderer.category.StackedBarRenderer var23 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var26 = var23.getBaseNegativeItemLabelPosition();
    boolean var28 = var23.isSeriesVisible(10);
    java.awt.Paint var29 = var23.getBasePaint();
    java.awt.Paint var32 = var23.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var6, (java.awt.Paint)var15, var21, var32);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    org.jfree.chart.renderer.category.StackedAreaRenderer var37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var38);
    org.jfree.data.Range var40 = var37.findRangeBounds((org.jfree.data.category.CategoryDataset)var38);
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var44 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var46 = var44.getSeriesItemLabelGenerator(100);
    boolean var47 = var43.equals((java.lang.Object)var44);
    org.jfree.chart.block.LineBorder var48 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var49 = var48.getInsets();
    var43.setLabelInsets(var49);
    java.awt.Paint var52 = var43.getTickLabelPaint((java.lang.Comparable)1.0f);
    org.jfree.chart.ChartColor var56 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var57 = var56.getColorSpace();
    org.jfree.chart.renderer.category.GanttRenderer var58 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var59 = var58.getCompletePaint();
    org.jfree.chart.ChartColor var63 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var64 = var63.getColorSpace();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var65 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var52, (java.awt.Paint)var56, var59, (java.awt.Paint)var63);
    var37.setSeriesPaint(100, (java.awt.Paint)var56, true);
    var34.setSeriesItemLabelPaint(100, (java.awt.Paint)var56, false);
    org.jfree.chart.ChartColor var73 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var74 = var73.getColorSpace();
    float[] var75 = null;
    float[] var76 = var56.getColorComponents(var74, var75);
    float[] var77 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var78 = var15.getComponents(var74, var77);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    org.jfree.chart.axis.Axis var25 = null;
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var27, "");
    org.jfree.chart.entity.AxisLabelEntity var32 = new org.jfree.chart.entity.AxisLabelEntity(var25, var27, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
    java.awt.Paint var39 = var38.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var42 = var41.getTickMarkStroke();
    var38.setBaseSectionOutlineStroke(var42);
    org.jfree.chart.renderer.category.StackedBarRenderer var44 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var46 = var44.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var47 = var44.getBaseNegativeItemLabelPosition();
    boolean var49 = var44.isSeriesVisible(10);
    java.awt.Paint var50 = var44.getBasePaint();
    java.awt.Paint var53 = var44.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var27, (java.awt.Paint)var36, var42, var53);
    var6.setRangeGridlineStroke(var42);
    org.jfree.chart.annotations.CategoryAnnotation var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addAnnotation(var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var4 = var3.getColorSpace();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    org.jfree.chart.renderer.category.StackedAreaRenderer var8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    org.jfree.data.Range var11 = var8.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var15 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = var15.getSeriesItemLabelGenerator(100);
    boolean var18 = var14.equals((java.lang.Object)var15);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var20 = var19.getInsets();
    var14.setLabelInsets(var20);
    java.awt.Paint var23 = var14.getTickLabelPaint((java.lang.Comparable)1.0f);
    org.jfree.chart.ChartColor var27 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var28 = var27.getColorSpace();
    org.jfree.chart.renderer.category.GanttRenderer var29 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Paint var30 = var29.getCompletePaint();
    org.jfree.chart.ChartColor var34 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var35 = var34.getColorSpace();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var36 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var23, (java.awt.Paint)var27, var30, (java.awt.Paint)var34);
    var8.setSeriesPaint(100, (java.awt.Paint)var27, true);
    var5.setSeriesItemLabelPaint(100, (java.awt.Paint)var27, false);
    org.jfree.chart.ChartColor var44 = new org.jfree.chart.ChartColor(0, 0, 0);
    java.awt.color.ColorSpace var45 = var44.getColorSpace();
    float[] var46 = null;
    float[] var47 = var27.getColorComponents(var45, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var48 = var3.getComponents(var47);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.05d, 1.0E-5d, var3);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getBaseURLGenerator();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Paint var7 = var6.getSeparatorPaint();
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var10 = var9.getTickMarkStroke();
//     var6.setBaseSectionOutlineStroke(var10);
//     var0.setBaseOutlineStroke(var10, true);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var15 = null;
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot(var18);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var19);
//     java.awt.Font var21 = var17.getLabelFont();
//     java.lang.String var23 = var17.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var17.setTickMarkInsideLength(100.0f);
//     org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var29 = var28.getArrangement();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var31 = var30.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var32 = null;
//     var30.setMarkerBand(var32);
//     java.text.NumberFormat var34 = var30.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 10.0d, 1.0d);
//     var40.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var42);
//     org.jfree.chart.title.LegendItemBlockContainer var45 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var40, (org.jfree.data.general.Dataset)var42, (java.lang.Comparable)100.0f);
//     var45.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var51 = var45.getBounds();
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     double var53 = var30.lengthToJava2D(0.0d, var51, var52);
//     var28.setBounds(var51);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var56 = var55.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var58 = var55.getRangeAxisEdge(100);
//     double var59 = var17.getCategoryEnd(1, (-1), var51, var58);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var62 = var60.getFixedDomainAxisSpace();
//     boolean var63 = var60.isRangeCrosshairVisible();
//     var60.clearAnnotations();
//     org.jfree.chart.axis.CategoryAxis3D var66 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var67 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var69 = var67.getSeriesItemLabelGenerator(100);
//     boolean var70 = var66.equals((java.lang.Object)var67);
//     var66.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var76 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var77 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var78 = var76.findRangeBounds((org.jfree.data.category.CategoryDataset)var77);
//     double var80 = var77.getRangeLowerBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.drawItem(var14, var15, var51, var60, (org.jfree.chart.axis.CategoryAxis)var66, (org.jfree.chart.axis.ValueAxis)var72, (org.jfree.data.category.CategoryDataset)var77, 0, 1, 10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == Double.NaN);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.axis.Axis var4 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "");
    org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity(var4, var6, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    java.awt.Paint var18 = var17.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var17.setBaseSectionOutlineStroke(var21);
    org.jfree.chart.renderer.category.StackedBarRenderer var23 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var26 = var23.getBaseNegativeItemLabelPosition();
    boolean var28 = var23.isSeriesVisible(10);
    java.awt.Paint var29 = var23.getBasePaint();
    java.awt.Paint var32 = var23.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var6, (java.awt.Paint)var15, var21, var32);
    java.io.ObjectOutputStream var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var6, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var3.setSeriesLinesVisible(1, true);
//     java.lang.Object var7 = var3.clone();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var10 = var9.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.Marker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var3.drawRangeMarker(var8, var9, var11, var12, var13);
//     var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var9.handleClick(2, 10, var18);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelGenerator();
    java.awt.Font var4 = var1.getLabelFont();
    java.awt.Shape var5 = var1.getLegendItemShape();
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(10, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getEndValue((java.lang.Comparable)1.0E-5d, (java.lang.Comparable)10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var3 = var2.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var6.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var12 = var6.getItemStroke((-1), 100);
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     var2.setRangeCrosshairStroke(var12);
//     org.jfree.chart.LegendItemCollection var15 = var2.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     boolean var17 = var16.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var18 = var16.getMarkerBand();
//     org.jfree.chart.plot.Marker var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawRangeMarker(var1, var2, (org.jfree.chart.axis.ValueAxis)var16, var19, var20);
//     org.jfree.chart.LegendItem var24 = var0.getLegendItem(2, 4);
//     org.jfree.chart.renderer.category.StackedBarRenderer var25 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var25.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var25.getBaseNegativeItemLabelPosition();
//     boolean var30 = var25.isSeriesVisible(10);
//     java.awt.Paint var31 = var25.getBasePaint();
//     java.awt.Paint var34 = var25.getItemLabelPaint(0, 1);
//     java.awt.Paint var36 = var25.lookupSeriesFillPaint(10);
//     var0.setBaseFillPaint(var36, false);
//     
//     // Checks the contract:  equals-hashcode on var9 and var28
//     assertTrue("Contract failed: equals-hashcode on var9 and var28", var9.equals(var28) ? var9.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
    java.awt.Paint var12 = var0.getItemOutlinePaint(0, 0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(0, var14, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
    var0.setBaseItemLabelGenerator(var17, false);
    boolean var20 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.awt.Paint var9 = var0.getItemLabelPaint(0, 1);
    java.awt.Paint var12 = var0.getItemOutlinePaint(0, 0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(0, var14, false);
    java.awt.Stroke var18 = null;
    var0.setSeriesOutlineStroke(0, var18);
    org.jfree.chart.util.GradientPaintTransformer var20 = var0.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     java.awt.Font var3 = null;
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var6, 0.0f, 0, var9);
//     java.util.List var11 = var10.getLines();
//     org.jfree.chart.text.TextLine var12 = var10.getLastLine();
//     org.jfree.chart.text.TextBlockAnchor var13 = null;
//     org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var18 = var17.getRed();
//     org.jfree.chart.renderer.category.StackedBarRenderer var19 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var22 = var19.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var23 = var22.getRotationAnchor();
//     boolean var24 = var17.equals((java.lang.Object)var23);
//     org.jfree.chart.axis.CategoryTick var26 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)10, var10, var13, var23, 0.0d);
//     org.jfree.chart.text.TextBlockAnchor var27 = null;
//     org.jfree.chart.text.TextLine var28 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var32 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var35 = var32.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var36 = var35.getRotationAnchor();
//     org.jfree.data.Range var37 = null;
//     org.jfree.data.Range var39 = org.jfree.data.Range.expandToInclude(var37, (-1.0d));
//     boolean var40 = var36.equals((java.lang.Object)(-1.0d));
//     var28.draw(var29, 100.0f, 2.0f, var36, 0.0f, (-1.0f), 10.0d);
//     org.jfree.chart.axis.CategoryTick var46 = new org.jfree.chart.axis.CategoryTick(var0, var10, var27, var36, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var22 and var35
//     assertTrue("Contract failed: equals-hashcode on var22 and var35", var22.equals(var35) ? var22.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var22
//     assertTrue("Contract failed: equals-hashcode on var35 and var22", var35.equals(var22) ? var35.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     java.awt.Paint var8 = var7.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
//     java.util.List var13 = var12.getLines();
//     var3.addExceptions(var13);
//     long var17 = var3.getExceptionSegmentCount(10L, 1L);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     java.util.Date var19 = var18.getEnd();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     java.util.Date var21 = var20.getEnd();
//     boolean var22 = var3.containsDomainRange(var19, var21);
//     java.util.TimeZone var23 = null;
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(var21, var23);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var16 = var11.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    java.awt.Paint var2 = var1.getOutlinePaint();
    org.jfree.chart.plot.Plot var3 = var1.getRootPlot();
    java.awt.Image var4 = var3.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.title.LegendTitle var12 = var11.getLegend();
    org.jfree.chart.util.VerticalAlignment var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setVerticalAlignment(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    java.awt.Font var2 = null;
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var3);
    java.awt.Paint var5 = var4.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var5, 0.0f, 0, var8);
    java.util.List var10 = var9.getLines();
    org.jfree.chart.text.TextLine var11 = var9.getLastLine();
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    org.jfree.chart.ChartColor var16 = new org.jfree.chart.ChartColor(0, 0, 0);
    int var17 = var16.getRed();
    org.jfree.chart.renderer.category.StackedBarRenderer var18 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var18.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var21 = var18.getBaseNegativeItemLabelPosition();
    org.jfree.chart.text.TextAnchor var22 = var21.getRotationAnchor();
    boolean var23 = var16.equals((java.lang.Object)var22);
    org.jfree.chart.axis.CategoryTick var25 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)10, var9, var12, var22, 0.0d);
    org.jfree.chart.util.HorizontalAlignment var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setLineAlignment(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var4 = null;
//     var2.setMarkerBand(var4);
//     java.text.NumberFormat var6 = var2.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, 1.0d);
//     var12.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var14);
//     org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)100.0f);
//     var17.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var23 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var2.lengthToJava2D(0.0d, var23, var24);
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var26.setSeriesLinesVisible(1, true);
//     java.lang.Object var30 = var26.clone();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var33 = var32.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.Marker var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     var26.drawRangeMarker(var31, var32, var34, var35, var36);
//     org.jfree.chart.renderer.category.StackedBarRenderer var38 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var40 = var38.getSeriesItemLabelGenerator(100);
//     boolean var42 = var38.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var43 = null;
//     var38.setBaseURLGenerator(var43);
//     var32.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var38, false);
//     var32.setRangeCrosshairValue(0.0d, true);
//     var32.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.util.HorizontalAlignment var53 = null;
//     org.jfree.chart.util.VerticalAlignment var54 = null;
//     org.jfree.chart.block.ColumnArrangement var57 = new org.jfree.chart.block.ColumnArrangement(var53, var54, 10.0d, 1.0d);
//     var57.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var59 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var59);
//     org.jfree.chart.title.LegendItemBlockContainer var62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var57, (org.jfree.data.general.Dataset)var59, (java.lang.Comparable)100.0f);
//     var62.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var68 = var62.getBounds();
//     java.awt.geom.Point2D var69 = null;
//     org.jfree.chart.plot.PlotState var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var32.draw(var52, var68, var69, var70, var71);
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var75 = var0.initialise(var1, var23, var32, 30, var74);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     long var5 = var3.toMillisecond((-1L));
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     java.util.Date var7 = var6.getEnd();
//     boolean var8 = var3.containsDomainValue(var7);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var7, var9);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.title.LegendTitle var12 = var11.getLegend();
    var12.setNotify(true);
    org.jfree.chart.util.RectangleAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setLegendItemGraphicAnchor(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var2 = null;
//     var0.setMarkerBand(var2);
//     java.text.NumberFormat var4 = var0.getNumberFormatOverride();
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, (-1.0d));
//     var0.setRange(var7);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setDomainGridlinesVisible(true);
//     org.jfree.chart.util.RectangleEdge var14 = var11.getDomainAxisEdge();
//     double var15 = var0.valueToJava2D(1.0E-8d, var10, var14);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var8 = var2.getItemStroke((-1), 100);
//     boolean var9 = var1.equals((java.lang.Object)var8);
//     double var11 = var1.extendWidth(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    java.awt.Stroke var1 = var0.getGroupStroke();
    java.awt.Paint var2 = var0.getGroupPaint();
    javax.swing.Icon var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMinIcon(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "RectangleEdge.RIGHT", "");
    var4.setInfo("0,-1,1,1,-1,1,-1,1");
    var4.setCopyright("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    var4.addOptionalLibrary("Jan");

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    var1.setLabelInsets(var7);
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
    java.awt.Font var13 = var12.getLabelFont();
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
    java.awt.Paint var16 = var15.getOutlinePaint();
    var15.setBackgroundAlpha(100.0f);
    float var19 = var15.getForegroundAlpha();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
    var9.setChart(var21);
    org.jfree.chart.plot.Plot var23 = var21.getPlot();
    var21.setTextAntiAlias(true);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    boolean var27 = var26.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var29 = var26.getRangeAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setTextAntiAlias((java.lang.Object)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setBaseLinesVisible(false);
    boolean var5 = var0.getItemShapeFilled(0, 100);
    boolean var6 = var0.getBaseLinesVisible();
    var0.setSeriesVisible(0, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    double var3 = var1.getLabelGap();
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.data.general.DatasetChangeEvent var6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-1.0d), var5);
    java.lang.Object var7 = var6.getSource();
    boolean var8 = var1.equals((java.lang.Object)var6);
    var1.setMinimumArcAngleToDraw(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    var3.addChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    java.awt.Font var7 = var3.getLabelFont();
    org.jfree.chart.text.TextLine var8 = new org.jfree.chart.text.TextLine("RectangleEdge.RIGHT", var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(0, 0, 0);
    int var14 = var13.getRed();
    java.awt.Color var15 = java.awt.Color.getColor("Jan", (java.awt.Color)var13);
    java.lang.String var16 = org.jfree.chart.util.PaintUtilities.colorToString(var15);
    org.jfree.chart.util.RectangleEdge var17 = null;
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.LineBorder var20 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var21 = var20.getInsets();
    double var23 = var21.calculateBottomInset((-1.0d));
    double var24 = var21.getBottom();
    org.jfree.chart.block.BlockContainer var25 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.Arrangement var26 = var25.getArrangement();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var28 = var27.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var29 = null;
    var27.setMarkerBand(var29);
    java.text.NumberFormat var31 = var27.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var33 = null;
    org.jfree.chart.util.VerticalAlignment var34 = null;
    org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 10.0d, 1.0d);
    var37.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var39);
    org.jfree.chart.title.LegendItemBlockContainer var42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var37, (org.jfree.data.general.Dataset)var39, (java.lang.Comparable)100.0f);
    var42.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var48 = var42.getBounds();
    org.jfree.chart.util.RectangleEdge var49 = null;
    double var50 = var27.lengthToJava2D(0.0d, var48, var49);
    var25.setBounds(var48);
    java.awt.geom.Rectangle2D var54 = var21.createOutsetRectangle(var48, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("ERROR : Relative To String", var7, (java.awt.Paint)var15, var17, var18, var19, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "black"+ "'", var16.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     double var4 = var3.getXOffset();
//     org.jfree.chart.renderer.category.LineRenderer3D var5 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var5.setSeriesLinesVisible(1, true);
//     java.lang.Object var9 = var5.clone();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var12 = var11.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.Marker var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var5.drawRangeMarker(var10, var11, var13, var14, var15);
//     var11.clearDomainMarkers((-1));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Object var20 = var19.clone();
//     var11.setDataset((org.jfree.data.category.CategoryDataset)var19);
//     org.jfree.data.Range var22 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var19);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
//     boolean var24 = var19.equals((java.lang.Object)var23);
//     org.jfree.chart.ChartColor var30 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var31 = var30.getRed();
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var36 = null;
//     var34.setMarkerBand(var36);
//     java.text.NumberFormat var38 = var34.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 10.0d, 1.0d);
//     var44.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var46);
//     org.jfree.chart.title.LegendItemBlockContainer var49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var44, (org.jfree.data.general.Dataset)var46, (java.lang.Comparable)100.0f);
//     var49.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var55 = var49.getBounds();
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var34.lengthToJava2D(0.0d, var55, var56);
//     java.awt.geom.AffineTransform var58 = null;
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot(var60);
//     java.awt.Font var62 = var61.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var63 = null;
//     org.jfree.chart.plot.WaferMapPlot var64 = new org.jfree.chart.plot.WaferMapPlot(var63);
//     java.awt.Paint var65 = var64.getOutlinePaint();
//     var64.setBackgroundAlpha(100.0f);
//     float var68 = var64.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("Jan", var62, (org.jfree.chart.plot.Plot)var64, true);
//     boolean var71 = var70.isNotify();
//     java.awt.RenderingHints var72 = var70.getRenderingHints();
//     java.awt.PaintContext var73 = var30.createContext(var32, var33, var55, var58, var72);
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
//     var74.setDomainGridlinesVisible(true);
//     org.jfree.chart.util.RectangleEdge var77 = var74.getDomainAxisEdge();
//     double var78 = var23.getCategoryStart(30, 10, (java.awt.geom.Rectangle2D)var33, var77);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    var11.setNotify(false);
    java.awt.RenderingHints var18 = var11.getRenderingHints();
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelGenerator();
    org.jfree.chart.plot.AbstractPieLabelDistributor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getBasePaint();
    java.awt.Stroke var8 = var0.getSeriesStroke(10);
    java.awt.Paint var11 = var0.getItemLabelPaint(10, 100);
    double var12 = var0.getUpperClip();
    boolean var13 = var0.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Font var7 = var0.getSeriesItemLabelFont(0);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var0.getSeriesURLGenerator(10);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    var0.setBaseShape(var3);
    boolean var5 = var0.getUseOutlinePaint();
    boolean var8 = var0.isItemLabelVisible(2, 100);
    var0.setBaseSeriesVisibleInLegend(true, false);
    java.awt.Paint var13 = var0.lookupSeriesPaint(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    double var3 = var1.getLabelGap();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    var1.setLegendItemShape(var5);
    double var7 = var1.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var5, "");
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    java.awt.Font var12 = null;
    org.jfree.data.general.WaferMapDataset var13 = null;
    org.jfree.chart.plot.WaferMapPlot var14 = new org.jfree.chart.plot.WaferMapPlot(var13);
    java.awt.Paint var15 = var14.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var15, 0.0f, 0, var18);
    var9.setSectionPaint((java.lang.Comparable)(-1.0d), var15);
    double var21 = var9.getInnerSeparatorExtension();
    boolean var22 = var9.isCircular();
    java.awt.Stroke var23 = var9.getLabelLinkStroke();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    boolean var25 = var24.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var26 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var28 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var30 = var28.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var31 = var28.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var34 = var28.getItemStroke((-1), 100);
    boolean var35 = var27.equals((java.lang.Object)var34);
    var24.setRangeCrosshairStroke(var34);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var40 = null;
    org.jfree.chart.plot.WaferMapPlot var41 = new org.jfree.chart.plot.WaferMapPlot(var40);
    java.awt.Paint var42 = var41.getOutlinePaint();
    var41.setBackgroundAlpha(100.0f);
    boolean var45 = var39.hasListener((java.util.EventListener)var41);
    var24.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var39);
    java.awt.Paint var47 = var24.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem(var0, "ERROR : Relative To String", "0.2", "", var5, var23, var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Paint var4 = var3.getSeparatorPaint();
    var0.setOutlinePaint(var4);
    org.jfree.chart.renderer.category.StackedBarRenderer var7 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(0);
    var0.setRangeGridlineStroke(var9);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairPaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     double var7 = var4.getRangeLowerBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var9 = var4.getColumnKey((-1));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.RectangleAnchor var8 = null;
//     java.awt.geom.Rectangle2D var9 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, 10.0d, (-1.0d), var8);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     boolean var13 = var5.equals((java.lang.Object)false);
//     org.jfree.chart.util.Size2D var14 = var4.calculateConstrainedSize(var5);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     java.awt.Paint var8 = var7.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
//     java.util.List var13 = var12.getLines();
//     var3.addExceptions(var13);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var16 = var3.getSegment((-1L));
//     org.jfree.chart.axis.SegmentedTimeline var20 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     long var22 = var20.toTimelineValue((-1L));
//     var3.setBaseTimeline(var20);
//     java.util.Date var24 = null;
//     boolean var25 = var3.containsDomainValue(var24);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     var6.clearDomainMarkers((-1));
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var6.drawBackground(var14, var15);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
    double var4 = var3.getXOffset();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    boolean var8 = var7.isDomainGridlinesVisible();
    var7.setAnchorValue(1.0d, true);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var14 = null;
    var12.setMarkerBand(var14);
    var12.setInverted(true);
    org.jfree.data.Range var18 = var7.getDataRange((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.chart.renderer.category.LineRenderer3D var19 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var19.setSeriesLinesVisible(1, true);
    java.lang.Object var23 = var19.clone();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    boolean var26 = var25.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.plot.Marker var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var19.drawRangeMarker(var24, var25, var27, var28, var29);
    org.jfree.chart.renderer.category.StackedBarRenderer var31 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var33 = var31.getSeriesItemLabelGenerator(100);
    boolean var35 = var31.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var36 = null;
    var31.setBaseURLGenerator(var36);
    var25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
    var25.setRangeCrosshairValue(0.0d, true);
    var25.setForegroundAlpha(0.0f);
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.util.HorizontalAlignment var46 = null;
    org.jfree.chart.util.VerticalAlignment var47 = null;
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 10.0d, 1.0d);
    var50.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var52);
    org.jfree.chart.title.LegendItemBlockContainer var55 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var50, (org.jfree.data.general.Dataset)var52, (java.lang.Comparable)100.0f);
    var55.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var61 = var55.getBounds();
    java.awt.geom.Point2D var62 = null;
    org.jfree.chart.plot.PlotState var63 = null;
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    var25.draw(var45, var61, var62, var63, var64);
    var3.drawRangeGridline(var5, var6, (org.jfree.chart.axis.ValueAxis)var12, var61, Double.NaN);
    java.awt.Paint var68 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setBaseItemLabelPaint(var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelGenerator();
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var7 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getSeriesItemLabelGenerator(100);
    boolean var10 = var6.equals((java.lang.Object)var7);
    org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
    var6.setLabelInsets(var12);
    java.awt.Paint var15 = var6.getTickLabelPaint((java.lang.Comparable)1.0f);
    var1.setLabelLinkPaint(var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var21 = null;
    var19.setMarkerBand(var21);
    java.text.NumberFormat var23 = var19.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 10.0d, 1.0d);
    var29.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var31);
    org.jfree.chart.title.LegendItemBlockContainer var34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var29, (org.jfree.data.general.Dataset)var31, (java.lang.Comparable)100.0f);
    var34.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var40 = var34.getBounds();
    org.jfree.chart.util.RectangleEdge var41 = null;
    double var42 = var19.lengthToJava2D(0.0d, var40, var41);
    var18.setChartArea(var40);
    org.jfree.data.general.PieDataset var44 = null;
    org.jfree.chart.plot.RingPlot var45 = new org.jfree.chart.plot.RingPlot(var44);
    java.awt.Paint var46 = var45.getSeparatorPaint();
    double var47 = var45.getLabelGap();
    org.jfree.data.general.Dataset var49 = null;
    org.jfree.data.general.DatasetChangeEvent var50 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-1.0d), var49);
    java.lang.Object var51 = var50.getSource();
    boolean var52 = var45.equals((java.lang.Object)var50);
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var55 = var1.initialise(var17, var40, (org.jfree.chart.plot.PiePlot)var45, (java.lang.Integer)2, var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-1.0d)+ "'", var51.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainAxes();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Paint var4 = var3.getSeparatorPaint();
//     var0.setOutlinePaint(var4);
//     org.jfree.chart.renderer.category.StackedBarRenderer var7 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
//     java.awt.Stroke var9 = var7.lookupSeriesStroke(0);
//     var0.setRangeGridlineStroke(var9);
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
//     var13.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
//     java.awt.Font var17 = var13.getLabelFont();
//     java.lang.String var19 = var13.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var13);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     double var26 = var25.getXOffset();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var30 = var29.isDomainGridlinesVisible();
//     var29.setAnchorValue(1.0d, true);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var36 = null;
//     var34.setMarkerBand(var36);
//     var34.setInverted(true);
//     org.jfree.data.Range var40 = var29.getDataRange((org.jfree.chart.axis.ValueAxis)var34);
//     org.jfree.chart.renderer.category.LineRenderer3D var41 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var41.setSeriesLinesVisible(1, true);
//     java.lang.Object var45 = var41.clone();
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var48 = var47.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.Marker var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     var41.drawRangeMarker(var46, var47, var49, var50, var51);
//     org.jfree.chart.renderer.category.StackedBarRenderer var53 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var55 = var53.getSeriesItemLabelGenerator(100);
//     boolean var57 = var53.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var58 = null;
//     var53.setBaseURLGenerator(var58);
//     var47.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var53, false);
//     var47.setRangeCrosshairValue(0.0d, true);
//     var47.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.util.HorizontalAlignment var68 = null;
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var68, var69, 10.0d, 1.0d);
//     var72.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var74 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var75 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var74);
//     org.jfree.chart.title.LegendItemBlockContainer var77 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var72, (org.jfree.data.general.Dataset)var74, (java.lang.Comparable)100.0f);
//     var77.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var83 = var77.getBounds();
//     java.awt.geom.Point2D var84 = null;
//     org.jfree.chart.plot.PlotState var85 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     var47.draw(var67, var83, var84, var85, var86);
//     var25.drawRangeGridline(var27, var28, (org.jfree.chart.axis.ValueAxis)var34, var83, Double.NaN);
//     var0.drawBackground(var21, var83);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Font var4 = var3.getLabelFont();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var5);
    java.awt.Paint var7 = var6.getOutlinePaint();
    var6.setBackgroundAlpha(100.0f);
    float var10 = var6.getForegroundAlpha();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("Jan", var4, (org.jfree.chart.plot.Plot)var6, true);
    org.jfree.chart.title.LegendTitle var13 = var12.getLegend();
    org.jfree.chart.renderer.category.StackedBarRenderer var15 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var13, (java.lang.Object)true);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     java.awt.Paint var8 = var7.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
//     java.util.List var13 = var12.getLines();
//     var3.addExceptions(var13);
//     long var17 = var3.getExceptionSegmentCount(10L, 1L);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     java.util.Date var19 = var18.getEnd();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     java.util.Date var21 = var20.getEnd();
//     boolean var22 = var3.containsDomainRange(var19, var21);
//     java.util.Date var23 = null;
//     boolean var24 = var3.containsDomainValue(var23);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    boolean var2 = var0.containsKey("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    java.awt.Paint var2 = var1.getOutlinePaint();
    var1.setBackgroundAlpha(100.0f);
    org.jfree.chart.event.RendererChangeEvent var5 = null;
    var1.rendererChanged(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.2d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.lang.Object var1 = var0.clone();
    var0.setExplodePercent((java.lang.Comparable)1.0f, 100.0d);
    var0.setLabelLinkMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     boolean var16 = var12.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
//     var6.setRangeCrosshairValue(0.0d, true);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.Range var25 = var6.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     boolean var30 = var6.render(var26, var27, 2, var29);
//     org.jfree.chart.renderer.category.LineRenderer3D var32 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var32.setSeriesLinesVisible(1, true);
//     var6.setRenderer(4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32, false);
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var41 = null;
//     org.jfree.chart.plot.WaferMapPlot var42 = new org.jfree.chart.plot.WaferMapPlot(var41);
//     var40.addChangeListener((org.jfree.chart.event.AxisChangeListener)var42);
//     java.awt.Font var44 = var40.getLabelFont();
//     org.jfree.chart.ChartRenderingInfo var47 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var49 = var48.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var50 = null;
//     var48.setMarkerBand(var50);
//     java.text.NumberFormat var52 = var48.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var54 = null;
//     org.jfree.chart.util.VerticalAlignment var55 = null;
//     org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement(var54, var55, 10.0d, 1.0d);
//     var58.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var60 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var61 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var60);
//     org.jfree.chart.title.LegendItemBlockContainer var63 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var58, (org.jfree.data.general.Dataset)var60, (java.lang.Comparable)100.0f);
//     var63.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var69 = var63.getBounds();
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     double var71 = var48.lengthToJava2D(0.0d, var69, var70);
//     var47.setChartArea(var69);
//     org.jfree.chart.util.RectangleEdge var73 = null;
//     double var74 = var40.getCategoryStart(1, 0, var69, var73);
//     var32.setSeriesShape(2, (java.awt.Shape)var69);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var32.", var0.equals(var32) == var32.equals(var0));
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
    org.jfree.chart.block.LengthConstraintType var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var10 = null;
    var8.setMarkerBand(var10);
    java.text.NumberFormat var12 = var8.getNumberFormatOverride();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, (-1.0d));
    var8.setRange(var15);
    org.jfree.chart.block.LengthConstraintType var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, var5, var6, 100.0d, var15, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     var0.setBackgroundAlpha((-1.0f));
//     var0.zoom(100.0d);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var1 = var0.getArrangement();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var4 = null;
//     var2.setMarkerBand(var4);
//     java.text.NumberFormat var6 = var2.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, 1.0d);
//     var12.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var14);
//     org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)100.0f);
//     var17.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var23 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var2.lengthToJava2D(0.0d, var23, var24);
//     var0.setBounds(var23);
//     org.jfree.chart.block.Arrangement var27 = var0.getArrangement();
//     org.jfree.chart.renderer.category.LineRenderer3D var28 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var28.setSeriesLinesVisible(1, true);
//     java.lang.Object var32 = var28.clone();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var34.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.Marker var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     var28.drawRangeMarker(var33, var34, var36, var37, var38);
//     org.jfree.chart.renderer.category.StackedBarRenderer var40 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var42 = var40.getSeriesItemLabelGenerator(100);
//     boolean var44 = var40.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var45 = null;
//     var40.setBaseURLGenerator(var45);
//     var34.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var40, false);
//     var34.setRangeCrosshairValue(0.0d, true);
//     var34.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.ColumnArrangement var59 = new org.jfree.chart.block.ColumnArrangement(var55, var56, 10.0d, 1.0d);
//     var59.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var61 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var61);
//     org.jfree.chart.title.LegendItemBlockContainer var64 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var59, (org.jfree.data.general.Dataset)var61, (java.lang.Comparable)100.0f);
//     var64.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var70 = var64.getBounds();
//     java.awt.geom.Point2D var71 = null;
//     org.jfree.chart.plot.PlotState var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var34.draw(var54, var70, var71, var72, var73);
//     var0.setBounds(var70);
//     
//     // Checks the contract:  equals-hashcode on var12 and var59
//     assertTrue("Contract failed: equals-hashcode on var12 and var59", var12.equals(var59) ? var12.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var12
//     assertTrue("Contract failed: equals-hashcode on var59 and var12", var59.equals(var12) ? var59.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var61
//     assertTrue("Contract failed: equals-hashcode on var14 and var61", var14.equals(var61) ? var14.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var14
//     assertTrue("Contract failed: equals-hashcode on var61 and var14", var61.equals(var14) ? var61.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var64
//     assertTrue("Contract failed: equals-hashcode on var17 and var64", var17.equals(var64) ? var17.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var17
//     assertTrue("Contract failed: equals-hashcode on var64 and var17", var64.equals(var17) ? var64.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.awt.Font var5 = var1.getLabelFont();
    java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
    var1.setTickMarkInsideLength(100.0f);
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.Arrangement var13 = var12.getArrangement();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var16 = null;
    var14.setMarkerBand(var16);
    java.text.NumberFormat var18 = var14.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 10.0d, 1.0d);
    var24.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26);
    org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, (org.jfree.data.general.Dataset)var26, (java.lang.Comparable)100.0f);
    var29.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var35 = var29.getBounds();
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var14.lengthToJava2D(0.0d, var35, var36);
    var12.setBounds(var35);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    boolean var40 = var39.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var42 = var39.getRangeAxisEdge(100);
    double var43 = var1.getCategoryEnd(1, (-1), var35, var42);
    java.lang.Object var44 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("org.jfree.chart.ChartColor[r=0,g=0,b=0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Paint var2 = var1.getOutlinePaint();
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var1.rendererChanged(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var8);
//     var7.addChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     java.awt.Font var11 = var7.getLabelFont();
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var17 = null;
//     var15.setMarkerBand(var17);
//     java.text.NumberFormat var19 = var15.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 10.0d, 1.0d);
//     var25.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var27);
//     org.jfree.chart.title.LegendItemBlockContainer var30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var25, (org.jfree.data.general.Dataset)var27, (java.lang.Comparable)100.0f);
//     var30.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var36 = var30.getBounds();
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var15.lengthToJava2D(0.0d, var36, var37);
//     var14.setChartArea(var36);
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var7.getCategoryStart(1, 0, var36, var40);
//     java.awt.geom.Point2D var42 = null;
//     org.jfree.chart.plot.PlotState var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var1.draw(var5, var36, var42, var43, var44);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    long var5 = var3.toMillisecond((-1L));
    boolean var7 = var3.containsDomainValue((-1L));
    org.jfree.chart.axis.SegmentedTimeline var11 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    java.awt.Font var13 = null;
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
    java.awt.Paint var16 = var15.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var16, 0.0f, 0, var19);
    java.util.List var21 = var20.getLines();
    var11.addExceptions(var21);
    long var25 = var11.getExceptionSegmentCount(10L, 1L);
    var3.setBaseTimeline(var11);
    java.lang.Object var27 = var3.clone();
    int var28 = var3.getSegmentsIncluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 100);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var2 = null;
    var0.setMarkerBand(var2);
    var0.setInverted(true);
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var15 = var11.equals((java.lang.Object)var12);
    org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var17 = var16.getInsets();
    var11.setLabelInsets(var17);
    var11.setTickMarksVisible(false);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    java.awt.Paint var23 = var22.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var26 = var25.getTickMarkStroke();
    var22.setBaseSectionOutlineStroke(var26);
    java.awt.Font var28 = var22.getLabelFont();
    var11.setTickLabelFont(var28);
    org.jfree.chart.axis.MarkerAxisBand var30 = new org.jfree.chart.axis.MarkerAxisBand(var0, 1.0E-5d, 1.0d, 0.0d, 0.05d, var28);
    java.awt.Shape var31 = var0.getRightArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var1.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getBaseNegativeItemLabelPosition();
    boolean var6 = var1.isSeriesVisible(10);
    java.awt.Paint var7 = var1.getBasePaint();
    java.awt.Paint var10 = var1.getItemLabelPaint(0, 1);
    boolean var11 = var0.equals((java.lang.Object)0);
    java.lang.Comparable var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var15 = null;
    var13.setMarkerBand(var15);
    java.text.NumberFormat var17 = var13.getNumberFormatOverride();
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, (-1.0d));
    var13.setRange(var20);
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var23 = org.jfree.data.Range.combine(var20, var22);
    var0.setObject(var12, (java.lang.Object)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     org.jfree.chart.title.LegendTitle var12 = var11.getLegend();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     java.awt.Font var17 = var16.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot(var18);
//     java.awt.Paint var20 = var19.getOutlinePaint();
//     var19.setBackgroundAlpha(100.0f);
//     float var23 = var19.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("Jan", var17, (org.jfree.chart.plot.Plot)var19, true);
//     org.jfree.chart.title.LegendTitle var26 = var25.getLegend();
//     var26.setNotify(true);
//     var11.addSubtitle(0, (org.jfree.chart.title.Title)var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.setWidth(10.0d);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    var3.setWidth(10.0d);
    org.jfree.chart.util.RectangleInsets var6 = var3.getMargin();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Font var9 = var8.getLabelFont();
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var8.markerChanged(var10);
    var8.setLabelLinkMargin(1.0E-5d);
    java.awt.Image var14 = null;
    var8.setBackgroundImage(var14);
    java.awt.Paint var16 = var8.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var3, (java.lang.Object)var16);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var6 = var0.getItemStroke((-1), 100);
//     var0.setBaseItemLabelsVisible(false);
//     org.jfree.chart.renderer.category.StackedBarRenderer var9 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var9.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var9.getBaseNegativeItemLabelPosition();
//     boolean var14 = var9.isSeriesVisible(10);
//     java.awt.Paint var15 = var9.getBasePaint();
//     java.awt.Stroke var17 = var9.getSeriesStroke(10);
//     java.awt.Paint var20 = var9.getItemLabelPaint(10, 100);
//     double var21 = var9.getUpperClip();
//     org.jfree.chart.util.GradientPaintTransformer var22 = var9.getGradientPaintTransformer();
//     var0.setGradientPaintTransformer(var22);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.awt.Stroke var8 = var0.getSeriesStroke(10);
//     java.awt.Paint var11 = var0.getItemLabelPaint(10, 100);
//     org.jfree.chart.renderer.category.LineRenderer3D var13 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
//     var13.setBaseShape(var16);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var22);
//     var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     java.awt.Font var25 = var21.getLabelFont();
//     org.jfree.chart.axis.Axis var30 = null;
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
//     org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var32, "");
//     org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity(var30, var32, "TextAnchor.CENTER", "");
//     org.jfree.chart.ChartColor var41 = new org.jfree.chart.ChartColor(0, 0, 0);
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
//     java.awt.Paint var44 = var43.getSeparatorPaint();
//     org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Stroke var47 = var46.getTickMarkStroke();
//     var43.setBaseSectionOutlineStroke(var47);
//     org.jfree.chart.renderer.category.StackedBarRenderer var49 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var51 = var49.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var52 = var49.getBaseNegativeItemLabelPosition();
//     boolean var54 = var49.isSeriesVisible(10);
//     java.awt.Paint var55 = var49.getBasePaint();
//     java.awt.Paint var58 = var49.getItemLabelPaint(0, 1);
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var32, (java.awt.Paint)var41, var47, var58);
//     org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("ERROR : Relative To String", var25, var58);
//     var13.setSeriesItemLabelFont(0, var25);
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var63 = var62.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var64 = null;
//     var62.setMarkerBand(var64);
//     var62.setInverted(true);
//     double var68 = var62.getAutoRangeMinimumSize();
//     java.awt.Paint var69 = var62.getTickMarkPaint();
//     org.jfree.chart.text.TextBlock var70 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var25, var69);
//     var0.setBaseItemLabelFont(var25, true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var52
//     assertTrue("Contract failed: equals-hashcode on var3 and var52", var3.equals(var52) ? var3.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var3
//     assertTrue("Contract failed: equals-hashcode on var52 and var3", var52.equals(var3) ? var52.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    java.text.NumberFormat var7 = var3.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 10.0d, 1.0d);
    var13.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.title.LegendItemBlockContainer var18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, (org.jfree.data.general.Dataset)var15, (java.lang.Comparable)100.0f);
    var18.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var24 = var18.getBounds();
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var3.lengthToJava2D(0.0d, var24, var25);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    boolean var28 = var27.isDomainGridlinesVisible();
    var27.setAnchorValue(1.0d, true);
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var34 = null;
    var32.setMarkerBand(var34);
    var32.setInverted(true);
    org.jfree.data.Range var38 = var27.getDataRange((org.jfree.chart.axis.ValueAxis)var32);
    org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var41 = null;
    org.jfree.chart.plot.WaferMapPlot var42 = new org.jfree.chart.plot.WaferMapPlot(var41);
    var40.addChangeListener((org.jfree.chart.event.AxisChangeListener)var42);
    java.awt.Stroke var44 = var40.getAxisLineStroke();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var46 = var45.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var47 = null;
    var45.setMarkerBand(var47);
    var45.setInverted(true);
    org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var57 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var59 = var57.getSeriesItemLabelGenerator(100);
    boolean var60 = var56.equals((java.lang.Object)var57);
    org.jfree.chart.block.LineBorder var61 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var62 = var61.getInsets();
    var56.setLabelInsets(var62);
    var56.setTickMarksVisible(false);
    org.jfree.data.general.PieDataset var66 = null;
    org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
    java.awt.Paint var68 = var67.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var70 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var71 = var70.getTickMarkStroke();
    var67.setBaseSectionOutlineStroke(var71);
    java.awt.Font var73 = var67.getLabelFont();
    var56.setTickLabelFont(var73);
    org.jfree.chart.axis.MarkerAxisBand var75 = new org.jfree.chart.axis.MarkerAxisBand(var45, 1.0E-5d, 1.0d, 0.0d, 0.05d, var73);
    boolean var76 = var45.isAutoRange();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var77 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var78 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var24, var27, (org.jfree.chart.axis.CategoryAxis)var40, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.data.category.CategoryDataset)var77, (-1), 0, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     boolean var5 = var1.equals((java.lang.Object)var2);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     var1.setLabelInsets(var7);
//     java.awt.Paint var10 = var1.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var15 = var14.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var16 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var17 = var16.getCompletePaint();
//     org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var22 = var21.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var10, (java.awt.Paint)var14, var17, (java.awt.Paint)var21);
//     org.jfree.chart.renderer.category.GanttRenderer var24 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var25 = var24.getCompletePaint();
//     java.awt.Paint var26 = var24.getIncompletePaint();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     var29.setNoDataMessage("");
//     java.awt.Paint var32 = var29.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.category.StackedBarRenderer var33 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getSeriesItemLabelGenerator(100);
//     java.awt.Stroke var38 = var33.getItemStroke(0, 0);
//     org.jfree.chart.plot.CategoryMarker var39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)"", var32, var38);
//     org.jfree.chart.block.LineBorder var40 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var41 = var40.getInsets();
//     double var42 = var41.getTop();
//     org.jfree.chart.block.LineBorder var43 = new org.jfree.chart.block.LineBorder(var26, var38, var41);
//     var23.setFirstBarPaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var6 and var40
//     assertTrue("Contract failed: equals-hashcode on var6 and var40", var6.equals(var40) ? var6.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var6
//     assertTrue("Contract failed: equals-hashcode on var40 and var6", var40.equals(var6) ? var40.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var6 = null;
    var4.setMarkerBand(var6);
    var4.setInverted(true);
    java.awt.Shape var10 = var4.getLeftArrow();
    org.jfree.chart.renderer.category.StackedBarRenderer var11 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var11.getBaseNegativeItemLabelPosition();
    boolean var16 = var11.isSeriesVisible(10);
    java.awt.Paint var17 = var11.getBasePaint();
    java.awt.Paint var18 = var11.getBasePaint();
    org.jfree.chart.renderer.category.StackedBarRenderer var19 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var22 = var19.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var25 = var19.getItemStroke((-1), 100);
    org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var26.setSeriesLinesVisible(1, true);
    java.lang.Object var30 = var26.clone();
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    boolean var33 = var32.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.plot.Marker var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    var26.drawRangeMarker(var31, var32, var34, var35, var36);
    org.jfree.chart.renderer.category.StackedBarRenderer var38 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var40 = var38.getSeriesItemLabelGenerator(100);
    boolean var42 = var38.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var43 = null;
    var38.setBaseURLGenerator(var43);
    var32.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var38, false);
    var32.setRangeCrosshairValue(0.0d, true);
    org.jfree.data.general.PieDataset var51 = null;
    org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
    var52.setNoDataMessage("");
    java.awt.Paint var55 = var52.getBaseSectionOutlinePaint();
    org.jfree.chart.renderer.category.StackedBarRenderer var56 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var58 = var56.getSeriesItemLabelGenerator(100);
    java.awt.Stroke var61 = var56.getItemStroke(0, 0);
    org.jfree.chart.plot.CategoryMarker var62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)"", var55, var61);
    var32.addRangeMarker((org.jfree.chart.plot.Marker)var62);
    org.jfree.chart.renderer.category.StackedBarRenderer var64 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var66 = var64.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var67 = var64.getBaseNegativeItemLabelPosition();
    boolean var69 = var64.isSeriesVisible(10);
    java.awt.Font var71 = var64.getSeriesItemLabelFont(0);
    java.awt.Stroke var72 = var64.getBaseOutlineStroke();
    var62.setOutlineStroke(var72);
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
    var74.clearDomainAxes();
    org.jfree.data.general.PieDataset var76 = null;
    org.jfree.chart.plot.RingPlot var77 = new org.jfree.chart.plot.RingPlot(var76);
    java.awt.Paint var78 = var77.getSeparatorPaint();
    var74.setOutlinePaint(var78);
    java.awt.Paint var80 = var74.getRangeGridlinePaint();
    var62.setLabelPaint(var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem(var0, "Jan", "org.jfree.chart.ChartColor[r=0,g=0,b=0]", "0.2", var10, var18, var25, var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.util.Iterator var1 = var0.iterator();
    int var2 = var0.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2);
    java.lang.String var2 = var1.toString();
    var1.setDescription("0.2");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "1-January-1900"+ "'", var2.equals("1-January-1900"));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    int var6 = var4.getColumnCount();
    org.jfree.data.gantt.TaskSeries var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    long var5 = var3.toMillisecond((-1L));
    boolean var7 = var3.containsDomainValue((-1L));
    org.jfree.chart.axis.SegmentedTimeline var11 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    java.awt.Font var13 = null;
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
    java.awt.Paint var16 = var15.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var16, 0.0f, 0, var19);
    java.util.List var21 = var20.getLines();
    var11.addExceptions(var21);
    long var25 = var11.getExceptionSegmentCount(10L, 1L);
    var3.setBaseTimeline(var11);
    java.lang.Object var27 = var3.clone();
    var3.setStartTime(1420099199999L);
    long var30 = var3.getSegmentsExcludedSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100L);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    var1.setLabelInsets(var7);
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
    java.awt.Font var13 = var12.getLabelFont();
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var14);
    java.awt.Paint var16 = var15.getOutlinePaint();
    var15.setBackgroundAlpha(100.0f);
    float var19 = var15.getForegroundAlpha();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Jan", var13, (org.jfree.chart.plot.Plot)var15, true);
    var9.setChart(var21);
    java.lang.String var23 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0f);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var2 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var8.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var14 = var8.getItemStroke((-1), 100);
//     boolean var15 = var7.equals((java.lang.Object)var14);
//     var4.setInsets(var7);
//     var4.setShadowYOffset(1.0d);
//     boolean var19 = var4.getLabelLinksVisible();
//     boolean var20 = var2.equals((java.lang.Object)var4);
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var21.setSeriesLinesVisible(1, true);
//     java.lang.Object var25 = var21.clone();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var28 = var27.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.plot.Marker var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     var21.drawRangeMarker(var26, var27, var29, var30, var31);
//     org.jfree.chart.renderer.category.StackedBarRenderer var33 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getSeriesItemLabelGenerator(100);
//     boolean var37 = var33.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var38 = null;
//     var33.setBaseURLGenerator(var38);
//     var27.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var33, false);
//     var27.setRangeCrosshairValue(0.0d, true);
//     var27.setForegroundAlpha(0.0f);
//     org.jfree.chart.util.RectangleEdge var47 = var27.getRangeAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var48 = var2.getLabelPosition(var47);
//     org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var48);
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month(10, 10);
//     java.lang.Object var53 = null;
//     int var54 = var52.compareTo(var53);
//     long var55 = var52.getMiddleMillisecond();
//     boolean var56 = var49.equals((java.lang.Object)var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-61826817600001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.axis.Axis var4 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "");
    org.jfree.chart.entity.AxisLabelEntity var11 = new org.jfree.chart.entity.AxisLabelEntity(var4, var6, "TextAnchor.CENTER", "");
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    java.awt.Paint var18 = var17.getSeparatorPaint();
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Stroke var21 = var20.getTickMarkStroke();
    var17.setBaseSectionOutlineStroke(var21);
    org.jfree.chart.renderer.category.StackedBarRenderer var23 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var26 = var23.getBaseNegativeItemLabelPosition();
    boolean var28 = var23.isSeriesVisible(10);
    java.awt.Paint var29 = var23.getBasePaint();
    java.awt.Paint var32 = var23.getItemLabelPaint(0, 1);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("Jan", "TextAnchor.CENTER", "TextAnchor.CENTER", "RectangleEdge.RIGHT", var6, (java.awt.Paint)var15, var21, var32);
    java.awt.Shape var34 = var33.getShape();
    boolean var35 = var33.isShapeOutlineVisible();
    java.lang.Comparable var36 = var33.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("0,-1,1,1,-1,1,-1,1");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    boolean var12 = var11.isNotify();
    var11.fireChartChanged();
    org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var11.createBufferedImage(0, 4, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.awt.Font var5 = var1.getLabelFont();
    java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
    var1.setAxisLineVisible(true);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    boolean var12 = var1.hasListener((java.util.EventListener)var11);
    org.jfree.chart.renderer.category.LineRenderer3D var15 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var15.setSeriesLinesVisible(1, true);
    java.lang.Object var19 = var15.clone();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    boolean var22 = var21.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var15.drawRangeMarker(var20, var21, var23, var24, var25);
    org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
    boolean var31 = var27.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var32 = null;
    var27.setBaseURLGenerator(var32);
    var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var27, false);
    var21.setRangeCrosshairValue(0.0d, true);
    var21.setForegroundAlpha(0.0f);
    java.awt.Graphics2D var41 = null;
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 10.0d, 1.0d);
    var46.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.chart.title.LegendItemBlockContainer var51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var46, (org.jfree.data.general.Dataset)var48, (java.lang.Comparable)100.0f);
    var51.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var57 = var51.getBounds();
    java.awt.geom.Point2D var58 = null;
    org.jfree.chart.plot.PlotState var59 = null;
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    var21.draw(var41, var57, var58, var59, var60);
    org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
    boolean var63 = var62.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var65 = var62.getRangeAxisEdge(100);
    double var66 = var1.getCategoryStart(4, 100, var57, var65);
    boolean var67 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    boolean var5 = var0.getBaseShapesVisible();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    boolean var8 = var7.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var11 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var11.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var17 = var11.getItemStroke((-1), 100);
    boolean var18 = var10.equals((java.lang.Object)var17);
    var7.setRangeCrosshairStroke(var17);
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var23 = null;
    org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var23);
    java.awt.Paint var25 = var24.getOutlinePaint();
    var24.setBackgroundAlpha(100.0f);
    boolean var28 = var22.hasListener((java.util.EventListener)var24);
    var7.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var22);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var31 = var30.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var32 = null;
    var30.setMarkerBand(var32);
    var30.setInverted(true);
    boolean var36 = var30.isVisible();
    org.jfree.chart.plot.Marker var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var0.drawRangeMarker(var6, var7, (org.jfree.chart.axis.ValueAxis)var30, var37, var38);
    org.jfree.data.time.Month var40 = new org.jfree.data.time.Month();
    java.util.Date var41 = var40.getEnd();
    org.jfree.chart.plot.CategoryMarker var42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var41);
    java.awt.Stroke var43 = var42.getStroke();
    var42.setAlpha(1.0f);
    org.jfree.chart.util.Layer var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(var42, var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    double var3 = var1.getLabelGap();
    var1.setMinimumArcAngleToDraw(0.35d);
    var1.setInnerSeparatorExtension(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var1.setTickMarkInsideLength(100.0f);
//     org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var13 = var12.getArrangement();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var16 = null;
//     var14.setMarkerBand(var16);
//     java.text.NumberFormat var18 = var14.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 10.0d, 1.0d);
//     var24.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26);
//     org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, (org.jfree.data.general.Dataset)var26, (java.lang.Comparable)100.0f);
//     var29.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var35 = var29.getBounds();
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var14.lengthToJava2D(0.0d, var35, var36);
//     var12.setBounds(var35);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var40 = var39.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var42 = var39.getRangeAxisEdge(100);
//     double var43 = var1.getCategoryEnd(1, (-1), var35, var42);
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.clearDomainAxes();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     java.awt.Paint var50 = var49.getSeparatorPaint();
//     var46.setOutlinePaint(var50);
//     var45.setRadiusGridlinePaint(var50);
//     var45.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     java.awt.geom.Point2D var57 = null;
//     var45.zoomDomainAxes(0.05d, var56, var57);
//     java.awt.Font var59 = var45.getAngleLabelFont();
//     var1.setTickLabelFont((java.lang.Comparable)"org.jfree.chart.ChartColor[r=0,g=0,b=0]", var59);
//     
//     // Checks the contract:  equals-hashcode on var39 and var46
//     assertTrue("Contract failed: equals-hashcode on var39 and var46", var39.equals(var46) ? var39.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var39
//     assertTrue("Contract failed: equals-hashcode on var46 and var39", var46.equals(var39) ? var46.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     var3.setBackgroundAlpha(100.0f);
//     boolean var7 = var1.hasListener((java.util.EventListener)var3);
//     double var8 = var1.getFixedDimension();
//     java.lang.Object var9 = var1.clone();
//     var1.setCategoryMargin(1.0d);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainAxes();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     java.awt.Paint var17 = var16.getSeparatorPaint();
//     var13.setOutlinePaint(var17);
//     org.jfree.chart.util.RectangleEdge var20 = var13.getRangeAxisEdge(2);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var22 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var22.setSeriesLinesVisible(1, true);
//     java.lang.Object var26 = var22.clone();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var29 = var28.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.plot.Marker var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var22.drawRangeMarker(var27, var28, var30, var31, var32);
//     org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
//     var34.setLeft(1.0d);
//     var28.setFixedDomainAxisSpace(var34);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var40 = var39.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var42 = var39.getRangeAxisEdge(100);
//     var34.ensureAtLeast((-1.0d), var42);
//     java.lang.String var44 = var42.toString();
//     org.jfree.chart.axis.AxisSpace var45 = new org.jfree.chart.axis.AxisSpace();
//     double var46 = var45.getBottom();
//     org.jfree.chart.axis.AxisSpace var47 = var1.reserveSpace(var12, (org.jfree.chart.plot.Plot)var13, var21, var42, var45);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var2 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Paint var5 = var4.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var8 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var8.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var8.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var14 = var8.getItemStroke((-1), 100);
    boolean var15 = var7.equals((java.lang.Object)var14);
    var4.setInsets(var7);
    var4.setShadowYOffset(1.0d);
    boolean var19 = var4.getLabelLinksVisible();
    boolean var20 = var2.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var21.setSeriesLinesVisible(1, true);
    java.lang.Object var25 = var21.clone();
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    boolean var28 = var27.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.Marker var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var21.drawRangeMarker(var26, var27, var29, var30, var31);
    org.jfree.chart.renderer.category.StackedBarRenderer var33 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getSeriesItemLabelGenerator(100);
    boolean var37 = var33.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var38 = null;
    var33.setBaseURLGenerator(var38);
    var27.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var33, false);
    var27.setRangeCrosshairValue(0.0d, true);
    var27.setForegroundAlpha(0.0f);
    org.jfree.chart.util.RectangleEdge var47 = var27.getRangeAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var48 = var2.getLabelPosition(var47);
    org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var48);
    org.jfree.chart.block.BlockContainer var50 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.Arrangement var51 = var50.getArrangement();
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var53 = var52.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var54 = null;
    var52.setMarkerBand(var54);
    java.text.NumberFormat var56 = var52.getNumberFormatOverride();
    org.jfree.chart.util.HorizontalAlignment var58 = null;
    org.jfree.chart.util.VerticalAlignment var59 = null;
    org.jfree.chart.block.ColumnArrangement var62 = new org.jfree.chart.block.ColumnArrangement(var58, var59, 10.0d, 1.0d);
    var62.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var64 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var65 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var64);
    org.jfree.chart.title.LegendItemBlockContainer var67 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var62, (org.jfree.data.general.Dataset)var64, (java.lang.Comparable)100.0f);
    var67.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var73 = var67.getBounds();
    org.jfree.chart.util.RectangleEdge var74 = null;
    double var75 = var52.lengthToJava2D(0.0d, var73, var74);
    var50.setBounds(var73);
    boolean var77 = var49.equals((java.lang.Object)var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.awt.Font var5 = var1.getLabelFont();
    java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
    var1.setTickMarkInsideLength(100.0f);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.Arrangement var13 = var12.getArrangement();
    boolean var14 = var11.equals((java.lang.Object)var13);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset();
    boolean var16 = var1.hasListener((java.util.EventListener)var11);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
    double var23 = var22.getXOffset();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    boolean var27 = var26.isDomainGridlinesVisible();
    var26.setAnchorValue(1.0d, true);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var33 = null;
    var31.setMarkerBand(var33);
    var31.setInverted(true);
    org.jfree.data.Range var37 = var26.getDataRange((org.jfree.chart.axis.ValueAxis)var31);
    org.jfree.chart.renderer.category.LineRenderer3D var38 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var38.setSeriesLinesVisible(1, true);
    java.lang.Object var42 = var38.clone();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    boolean var45 = var44.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.plot.Marker var47 = null;
    java.awt.geom.Rectangle2D var48 = null;
    var38.drawRangeMarker(var43, var44, var46, var47, var48);
    org.jfree.chart.renderer.category.StackedBarRenderer var50 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var52 = var50.getSeriesItemLabelGenerator(100);
    boolean var54 = var50.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var55 = null;
    var50.setBaseURLGenerator(var55);
    var44.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var50, false);
    var44.setRangeCrosshairValue(0.0d, true);
    var44.setForegroundAlpha(0.0f);
    java.awt.Graphics2D var64 = null;
    org.jfree.chart.util.HorizontalAlignment var65 = null;
    org.jfree.chart.util.VerticalAlignment var66 = null;
    org.jfree.chart.block.ColumnArrangement var69 = new org.jfree.chart.block.ColumnArrangement(var65, var66, 10.0d, 1.0d);
    var69.clear();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var71 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var72 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var71);
    org.jfree.chart.title.LegendItemBlockContainer var74 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var69, (org.jfree.data.general.Dataset)var71, (java.lang.Comparable)100.0f);
    var74.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
    java.awt.geom.Rectangle2D var80 = var74.getBounds();
    java.awt.geom.Point2D var81 = null;
    org.jfree.chart.plot.PlotState var82 = null;
    org.jfree.chart.plot.PlotRenderingInfo var83 = null;
    var44.draw(var64, var80, var81, var82, var83);
    var22.drawRangeGridline(var24, var25, (org.jfree.chart.axis.ValueAxis)var31, var80, Double.NaN);
    org.jfree.chart.axis.AxisState var88 = new org.jfree.chart.axis.AxisState(10.0d);
    var88.cursorLeft(10.0d);
    org.jfree.chart.plot.CategoryPlot var92 = new org.jfree.chart.plot.CategoryPlot();
    boolean var93 = var92.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var95 = var92.getRangeAxisEdge(100);
    var88.moveCursor(1.0E-5d, var95);
    double var97 = var1.getCategoryEnd((-460), 100, var80, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.0d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setBaseLinesVisible(false);
    boolean var5 = var0.getItemShapeFilled(0, 100);
    boolean var6 = var0.getBaseLinesVisible();
    java.awt.Paint var8 = var0.getSeriesOutlinePaint(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
//     org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(10, 10);
//     java.lang.Object var10 = null;
//     int var11 = var9.compareTo(var10);
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
//     var6.seriesChanged(var12);
//     var4.seriesChanged(var12);
//     
//     // Checks the contract:  equals-hashcode on var4 and var6
//     assertTrue("Contract failed: equals-hashcode on var4 and var6", var4.equals(var6) ? var4.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var4
//     assertTrue("Contract failed: equals-hashcode on var6 and var4", var6.equals(var4) ? var6.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.KeyToGroupMap var2 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(short)100);
//     var2.mapKeyToGroup((java.lang.Comparable)(byte)0, (java.lang.Comparable)0);
//     var0.setSeriesToGroupMap(var2);
//     org.jfree.data.KeyToGroupMap var8 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(short)100);
//     var8.mapKeyToGroup((java.lang.Comparable)(byte)0, (java.lang.Comparable)0);
//     var0.setSeriesToGroupMap(var8);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(100);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    var0.setRangeCrosshairValue(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainAxes();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Paint var5 = var4.getSeparatorPaint();
    var1.setOutlinePaint(var5);
    var0.setRadiusGridlinePaint(var5);
    java.awt.Paint var8 = var0.getRadiusGridlinePaint();
    org.jfree.data.general.DatasetChangeEvent var9 = null;
    var0.datasetChanged(var9);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
    org.jfree.chart.axis.MarkerAxisBand var13 = null;
    var11.setMarkerBand(var13);
    var11.setInverted(true);
    double var17 = var11.getAutoRangeMinimumSize();
    java.awt.Paint var18 = var11.getTickMarkPaint();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.data.xy.XYDataset var20 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(100);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    boolean var7 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.event.PlotChangeEvent var8 = null;
    var0.notifyListeners(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(4);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
    var0.setMinimumBarLength(1.0d);
    var0.setBaseSeriesVisibleInLegend(false, false);
    java.awt.Shape var13 = var0.lookupSeriesShape((-1));
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var0.setBaseToolTipGenerator(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    var11.setNotify(false);
    java.awt.RenderingHints var18 = var11.getRenderingHints();
    var11.setBackgroundImageAlpha(2.0f);
    java.lang.Object var21 = var11.clone();
    org.jfree.data.DefaultKeyedValues2D var23 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var24 = var23.getColumnCount();
    int var25 = var23.getColumnCount();
    org.jfree.chart.axis.NumberTickUnit var27 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
    var23.removeColumn((java.lang.Comparable)var27);
    var23.clear();
    java.util.List var30 = var23.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setTextAntiAlias((java.lang.Object)var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     var3.setBackgroundAlpha(100.0f);
//     boolean var7 = var1.hasListener((java.util.EventListener)var3);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     org.jfree.chart.plot.PlotState var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var3.draw(var8, var9, var10, var11, var12);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.0d, 1.0E-5d);
//     java.awt.Font var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     java.awt.Paint var8 = var7.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
//     java.util.List var13 = var12.getLines();
//     org.jfree.chart.text.TextLine var14 = var12.getLastLine();
//     org.jfree.chart.text.TextBlockAnchor var15 = null;
//     org.jfree.chart.ChartColor var19 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var20 = var19.getRed();
//     org.jfree.chart.renderer.category.StackedBarRenderer var21 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var21.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var21.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var25 = var24.getRotationAnchor();
//     boolean var26 = var19.equals((java.lang.Object)var25);
//     org.jfree.chart.axis.CategoryTick var28 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(byte)10, var12, var15, var25, 0.0d);
//     boolean var29 = var2.equals((java.lang.Object)var12);
//     java.lang.String var30 = var2.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("0,-1,1,1,-1,1,-1,1");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainGridlinesVisible(true);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    boolean var4 = var3.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var5 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var6 = var5.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var7 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var10 = var7.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var13 = var7.getItemStroke((-1), 100);
    boolean var14 = var6.equals((java.lang.Object)var13);
    var3.setRangeCrosshairStroke(var13);
    int var16 = var3.getDatasetCount();
    org.jfree.chart.renderer.category.StackedBarRenderer var18 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var18.getSeriesItemLabelGenerator(100);
    var18.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
    var18.setMinimumBarLength(1.0d);
    java.awt.Stroke var27 = var18.getBaseStroke();
    int var28 = var18.getColumnCount();
    var3.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18, false);
    org.jfree.chart.axis.AxisLocation var32 = null;
    var3.setDomainAxisLocation(2, var32, false);
    org.jfree.chart.util.SortOrder var35 = var3.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var35);
    var0.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.awt.Font var5 = var1.getLabelFont();
//     java.lang.String var7 = var1.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var1.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     boolean var12 = var1.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.renderer.category.LineRenderer3D var15 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var15.setSeriesLinesVisible(1, true);
//     java.lang.Object var19 = var15.clone();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var22 = var21.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.Marker var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var15.drawRangeMarker(var20, var21, var23, var24, var25);
//     org.jfree.chart.renderer.category.StackedBarRenderer var27 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var27.getSeriesItemLabelGenerator(100);
//     boolean var31 = var27.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var32 = null;
//     var27.setBaseURLGenerator(var32);
//     var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var27, false);
//     var21.setRangeCrosshairValue(0.0d, true);
//     var21.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 10.0d, 1.0d);
//     var46.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var48);
//     org.jfree.chart.title.LegendItemBlockContainer var51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var46, (org.jfree.data.general.Dataset)var48, (java.lang.Comparable)100.0f);
//     var51.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var57 = var51.getBounds();
//     java.awt.geom.Point2D var58 = null;
//     org.jfree.chart.plot.PlotState var59 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     var21.draw(var41, var57, var58, var59, var60);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var63 = var62.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var65 = var62.getRangeAxisEdge(100);
//     double var66 = var1.getCategoryStart(4, 100, var57, var65);
//     org.jfree.data.time.Month var69 = new org.jfree.data.time.Month(10, 10);
//     org.jfree.chart.renderer.category.LineRenderer3D var70 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var70.setSeriesLinesVisible(1, true);
//     java.lang.Object var74 = var70.clone();
//     java.awt.Graphics2D var75 = null;
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var77 = var76.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.plot.Marker var79 = null;
//     java.awt.geom.Rectangle2D var80 = null;
//     var70.drawRangeMarker(var75, var76, var78, var79, var80);
//     int var82 = var69.compareTo((java.lang.Object)var75);
//     int var83 = var69.getMonth();
//     java.awt.Font var84 = var1.getTickLabelFont((java.lang.Comparable)var69);
//     
//     // Checks the contract:  equals-hashcode on var62 and var76
//     assertTrue("Contract failed: equals-hashcode on var62 and var76", var62.equals(var76) ? var62.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var62
//     assertTrue("Contract failed: equals-hashcode on var76 and var62", var76.equals(var62) ? var76.hashCode() == var62.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
    var0.setRange(var3, true, false);
    org.jfree.chart.util.RectangleInsets var9 = var0.getTickLabelInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var3 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getSeriesItemLabelGenerator(100);
//     boolean var6 = var2.equals((java.lang.Object)var3);
//     org.jfree.chart.block.LineBorder var7 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
//     var2.setLabelInsets(var8);
//     java.awt.Paint var11 = var2.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var16 = var15.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var17 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var18 = var17.getCompletePaint();
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var11, (java.awt.Paint)var15, var18, (java.awt.Paint)var22);
//     int var25 = var22.getBlue();
//     int var26 = var0.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.RegularTimePeriod var27 = var0.next();
//     java.util.Calendar var28 = null;
//     var0.peg(var28);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();
    org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
    var0.setFixedLegendItems(var2);
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var1 = var0.getArrangement();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
//     boolean var3 = var0.isEmpty();
//     org.jfree.chart.block.Arrangement var4 = var0.getArrangement();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var8);
//     var7.addChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     java.awt.Font var11 = var7.getLabelFont();
//     java.lang.String var13 = var7.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var7.setAxisLineVisible(true);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     boolean var18 = var7.hasListener((java.util.EventListener)var17);
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var21.setSeriesLinesVisible(1, true);
//     java.lang.Object var25 = var21.clone();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var28 = var27.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.plot.Marker var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     var21.drawRangeMarker(var26, var27, var29, var30, var31);
//     org.jfree.chart.renderer.category.StackedBarRenderer var33 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var33.getSeriesItemLabelGenerator(100);
//     boolean var37 = var33.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var38 = null;
//     var33.setBaseURLGenerator(var38);
//     var27.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var33, false);
//     var27.setRangeCrosshairValue(0.0d, true);
//     var27.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, 10.0d, 1.0d);
//     var52.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var54 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var55 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var54);
//     org.jfree.chart.title.LegendItemBlockContainer var57 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var52, (org.jfree.data.general.Dataset)var54, (java.lang.Comparable)100.0f);
//     var57.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var63 = var57.getBounds();
//     java.awt.geom.Point2D var64 = null;
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var27.draw(var47, var63, var64, var65, var66);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var69 = var68.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var71 = var68.getRangeAxisEdge(100);
//     double var72 = var7.getCategoryStart(4, 100, var63, var71);
//     var0.draw(var5, var63);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
//     boolean var5 = var0.isSeriesVisible(10);
//     java.awt.Paint var6 = var0.getBasePaint();
//     java.util.EventListener var7 = null;
//     boolean var8 = var0.hasListener(var7);
//     var0.setAutoPopulateSeriesPaint(false);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearDomainAxes();
//     org.jfree.chart.renderer.category.StackedBarRenderer var15 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var17 = var15.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var15.getSeriesPositiveItemLabelPosition(2);
//     var12.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     boolean var22 = var12.isSubplot();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var25 = null;
//     var23.setMarkerBand(var25);
//     java.text.NumberFormat var27 = var23.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 10.0d, 1.0d);
//     var33.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var35 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var35);
//     org.jfree.chart.title.LegendItemBlockContainer var38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var33, (org.jfree.data.general.Dataset)var35, (java.lang.Comparable)100.0f);
//     var38.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var44 = var38.getBounds();
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var23.lengthToJava2D(0.0d, var44, var45);
//     var0.drawOutline(var11, var12, var44);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Font var4 = null;
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var5);
//     java.awt.Paint var7 = var6.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, var7, 0.0f, 0, var10);
//     var1.setSectionPaint((java.lang.Comparable)(-1.0d), var7);
//     double var13 = var1.getInnerSeparatorExtension();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var17 = var16.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var20 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var23 = var20.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var26 = var20.getItemStroke((-1), 100);
//     boolean var27 = var19.equals((java.lang.Object)var26);
//     var16.setRangeCrosshairStroke(var26);
//     org.jfree.chart.LegendItemCollection var29 = var16.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     boolean var31 = var30.isTickLabelsVisible();
//     org.jfree.chart.axis.MarkerAxisBand var32 = var30.getMarkerBand();
//     org.jfree.chart.plot.Marker var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var14.drawRangeMarker(var15, var16, (org.jfree.chart.axis.ValueAxis)var30, var33, var34);
//     java.awt.Paint var36 = var14.getBaseOutlinePaint();
//     var1.setLabelPaint(var36);
//     org.jfree.chart.util.RectangleInsets var38 = var1.getInsets();
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     java.awt.Paint var41 = var40.getSeparatorPaint();
//     org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var43 = var42.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var44 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var46 = var44.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var44.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var50 = var44.getItemStroke((-1), 100);
//     boolean var51 = var43.equals((java.lang.Object)var50);
//     var40.setInsets(var43);
//     var40.setShadowYOffset(1.0d);
//     org.jfree.chart.labels.PieToolTipGenerator var55 = var40.getToolTipGenerator();
//     java.awt.Stroke var57 = var40.getSectionOutlineStroke((java.lang.Comparable)(byte)100);
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.RingPlot var59 = new org.jfree.chart.plot.RingPlot(var58);
//     java.awt.Paint var60 = var59.getSeparatorPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var61 = var59.getLegendLabelGenerator();
//     var40.setLabelGenerator(var61);
//     var1.setLegendLabelToolTipGenerator(var61);
//     
//     // Checks the contract:  equals-hashcode on var18 and var42
//     assertTrue("Contract failed: equals-hashcode on var18 and var42", var18.equals(var42) ? var18.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var18
//     assertTrue("Contract failed: equals-hashcode on var42 and var18", var42.equals(var18) ? var42.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var47
//     assertTrue("Contract failed: equals-hashcode on var23 and var47", var23.equals(var47) ? var23.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var23
//     assertTrue("Contract failed: equals-hashcode on var47 and var23", var47.equals(var23) ? var47.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     java.awt.Paint var8 = var0.getRadiusGridlinePaint();
//     boolean var9 = var0.isRangeZoomable();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var0.zoomRangeAxes(10.0d, 0.2d, var12, var13);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.Object var3 = var2.clone();
    var2.setURLText("org.jfree.chart.ChartColor[r=0,g=0,b=0]");
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setArea(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.util.List var1 = var0.getKeys();
//     java.lang.Comparable var2 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var5.notifyListeners(var6);
//     org.jfree.chart.renderer.category.LineRenderer3D var8 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var8.setSeriesLinesVisible(1, true);
//     java.lang.Object var12 = var8.clone();
//     boolean var13 = var8.getBaseShapesVisible();
//     java.lang.Boolean var15 = var8.getSeriesCreateEntities(100);
//     java.awt.Paint var18 = var8.getItemFillPaint(0, 0);
//     var5.setBasePaint(var18);
//     var0.addObject(var2, (java.lang.Object)var5);
//     int var22 = var0.getIndex((java.lang.Comparable)"");
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Font var7 = var0.getSeriesItemLabelFont(0);
    java.awt.Stroke var8 = var0.getBaseOutlineStroke();
    java.awt.Paint var10 = var0.lookupSeriesFillPaint(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     java.awt.Paint var8 = var7.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
//     java.util.List var13 = var12.getLines();
//     var3.addExceptions(var13);
//     long var17 = var3.getExceptionSegmentCount(10L, 1L);
//     boolean var19 = var3.containsDomainValue(1417420800000L);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var21 = var3.getSegment(1L);
//     org.jfree.chart.axis.SegmentedTimeline var25 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var27 = null;
//     org.jfree.data.general.WaferMapDataset var28 = null;
//     org.jfree.chart.plot.WaferMapPlot var29 = new org.jfree.chart.plot.WaferMapPlot(var28);
//     java.awt.Paint var30 = var29.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var33 = null;
//     org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, var30, 0.0f, 0, var33);
//     java.util.List var35 = var34.getLines();
//     var25.addExceptions(var35);
//     long var39 = var25.getExceptionSegmentCount(10L, 1L);
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month();
//     java.util.Date var41 = var40.getEnd();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     java.util.Date var43 = var42.getEnd();
//     boolean var44 = var25.containsDomainRange(var41, var43);
//     boolean var45 = var3.containsDomainValue(var43);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Paint var3 = var2.getSeparatorPaint();
//     org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var6 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var6.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var6.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var12 = var6.getItemStroke((-1), 100);
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     var2.setInsets(var5);
//     var2.setShadowYOffset(1.0d);
//     boolean var17 = var2.getLabelLinksVisible();
//     boolean var18 = var0.equals((java.lang.Object)var2);
//     org.jfree.chart.renderer.category.LineRenderer3D var19 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var19.setSeriesLinesVisible(1, true);
//     java.lang.Object var23 = var19.clone();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var26 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.Marker var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var19.drawRangeMarker(var24, var25, var27, var28, var29);
//     org.jfree.chart.renderer.category.StackedBarRenderer var31 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var33 = var31.getSeriesItemLabelGenerator(100);
//     boolean var35 = var31.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var36 = null;
//     var31.setBaseURLGenerator(var36);
//     var25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
//     var25.setRangeCrosshairValue(0.0d, true);
//     var25.setForegroundAlpha(0.0f);
//     org.jfree.chart.util.RectangleEdge var45 = var25.getRangeAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var46 = var0.getLabelPosition(var45);
//     org.jfree.chart.axis.CategoryLabelPositions var47 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.RingPlot var49 = new org.jfree.chart.plot.RingPlot(var48);
//     java.awt.Paint var50 = var49.getSeparatorPaint();
//     org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var52 = var51.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var53 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var55 = var53.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var56 = var53.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var59 = var53.getItemStroke((-1), 100);
//     boolean var60 = var52.equals((java.lang.Object)var59);
//     var49.setInsets(var52);
//     var49.setShadowYOffset(1.0d);
//     boolean var64 = var49.getLabelLinksVisible();
//     boolean var65 = var47.equals((java.lang.Object)var49);
//     org.jfree.chart.renderer.category.LineRenderer3D var66 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var66.setSeriesLinesVisible(1, true);
//     java.lang.Object var70 = var66.clone();
//     java.awt.Graphics2D var71 = null;
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var73 = var72.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.plot.Marker var75 = null;
//     java.awt.geom.Rectangle2D var76 = null;
//     var66.drawRangeMarker(var71, var72, var74, var75, var76);
//     org.jfree.chart.renderer.category.StackedBarRenderer var78 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var80 = var78.getSeriesItemLabelGenerator(100);
//     boolean var82 = var78.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var83 = null;
//     var78.setBaseURLGenerator(var83);
//     var72.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var78, false);
//     var72.setRangeCrosshairValue(0.0d, true);
//     var72.setForegroundAlpha(0.0f);
//     org.jfree.chart.util.RectangleEdge var92 = var72.getRangeAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var93 = var47.getLabelPosition(var92);
//     org.jfree.chart.axis.CategoryLabelPosition var94 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPosition var95 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var96 = new org.jfree.chart.axis.CategoryLabelPositions(var46, var93, var94, var95);
//     
//     // Checks the contract:  equals-hashcode on var2 and var49
//     assertTrue("Contract failed: equals-hashcode on var2 and var49", var2.equals(var49) ? var2.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var2
//     assertTrue("Contract failed: equals-hashcode on var49 and var2", var49.equals(var2) ? var49.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var51
//     assertTrue("Contract failed: equals-hashcode on var4 and var51", var4.equals(var51) ? var4.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var4
//     assertTrue("Contract failed: equals-hashcode on var51 and var4", var51.equals(var4) ? var51.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var56
//     assertTrue("Contract failed: equals-hashcode on var9 and var56", var9.equals(var56) ? var9.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var9
//     assertTrue("Contract failed: equals-hashcode on var56 and var9", var56.equals(var9) ? var56.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var72
//     assertTrue("Contract failed: equals-hashcode on var25 and var72", var25.equals(var72) ? var25.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var25
//     assertTrue("Contract failed: equals-hashcode on var72 and var25", var72.equals(var25) ? var72.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(0L, (-61826817600001L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("black", var1, (-1.0f), 0.0f, 0.0d, 10.0f, 1.0f);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    int var6 = var4.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var10 = null;
    org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot(var10);
    var9.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    java.awt.Font var13 = var9.getLabelFont();
    org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("RectangleEdge.RIGHT", var13);
    org.jfree.chart.text.TextFragment var15 = var14.getFirstTextFragment();
    boolean var16 = var4.equals((java.lang.Object)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var4.getValue((java.lang.Comparable)"poly", (java.lang.Comparable)1.0f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isDomainGridlinesVisible();
//     var0.setAnchorValue(1.0d, true);
//     int var5 = var0.getWeight();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(0, 0, 0);
//     int var11 = var10.getRed();
//     java.awt.image.ColorModel var12 = null;
//     java.awt.Rectangle var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var16 = null;
//     var14.setMarkerBand(var16);
//     java.text.NumberFormat var18 = var14.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 10.0d, 1.0d);
//     var24.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var26);
//     org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, (org.jfree.data.general.Dataset)var26, (java.lang.Comparable)100.0f);
//     var29.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var35 = var29.getBounds();
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var14.lengthToJava2D(0.0d, var35, var36);
//     java.awt.geom.AffineTransform var38 = null;
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.RingPlot var41 = new org.jfree.chart.plot.RingPlot(var40);
//     java.awt.Font var42 = var41.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.plot.WaferMapPlot var44 = new org.jfree.chart.plot.WaferMapPlot(var43);
//     java.awt.Paint var45 = var44.getOutlinePaint();
//     var44.setBackgroundAlpha(100.0f);
//     float var48 = var44.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("Jan", var42, (org.jfree.chart.plot.Plot)var44, true);
//     boolean var51 = var50.isNotify();
//     java.awt.RenderingHints var52 = var50.getRenderingHints();
//     java.awt.PaintContext var53 = var10.createContext(var12, var13, var35, var38, var52);
//     var0.drawOutline(var6, var35);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.CategoryLabelPositions var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setStroke((-460), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "");
    org.jfree.chart.entity.AxisLabelEntity var7 = new org.jfree.chart.entity.AxisLabelEntity(var0, var2, "TextAnchor.CENTER", "");
    java.awt.Shape var8 = var7.getArea();
    var7.setToolTipText("12/31/69");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.getSubIntervalCount(10, 30);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    int var1 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var3 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearDomainAxes();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     java.awt.Paint var17 = var16.getSeparatorPaint();
//     var13.setOutlinePaint(var17);
//     var12.setRadiusGridlinePaint(var17);
//     java.awt.Paint var20 = var12.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var21 = null;
//     var12.datasetChanged(var21);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var25 = null;
//     var23.setMarkerBand(var25);
//     java.text.NumberFormat var27 = var23.getNumberFormatOverride();
//     java.awt.Stroke var28 = var23.getAxisLineStroke();
//     var12.setRadiusGridlineStroke(var28);
//     var11.setBorderStroke(var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setSeriesLinesVisible(1, true);
//     java.lang.Object var4 = var0.clone();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var7 = var6.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.Marker var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawRangeMarker(var5, var6, var8, var9, var10);
//     org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
//     boolean var16 = var12.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = null;
//     var12.setBaseURLGenerator(var17);
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
//     var6.setRangeCrosshairValue(0.0d, true);
//     var6.setForegroundAlpha(0.0f);
//     java.awt.Stroke var26 = var6.getDomainGridlineStroke();
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 10.0d, 1.0d);
//     var32.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var34);
//     org.jfree.chart.title.LegendItemBlockContainer var37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, (org.jfree.data.general.Dataset)var34, (java.lang.Comparable)100.0f);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("ERROR : Relative To String");
//     boolean var40 = var34.equals((java.lang.Object)"ERROR : Relative To String");
//     java.lang.Number var43 = var34.getStdDevValue((java.lang.Comparable)0L, (java.lang.Comparable)100.0d);
//     org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var34);
//     double var46 = var34.getRangeUpperBound(true);
//     var6.setDataset(0, (org.jfree.data.category.CategoryDataset)var34);
//     org.jfree.chart.plot.CategoryMarker var48 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.addDomainMarker(var48);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == Double.NaN);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainAxes();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
//     java.awt.Paint var5 = var4.getSeparatorPaint();
//     var1.setOutlinePaint(var5);
//     var0.setRadiusGridlinePaint(var5);
//     java.awt.Paint var8 = var0.getRadiusGridlinePaint();
//     org.jfree.data.general.DatasetChangeEvent var9 = null;
//     var0.datasetChanged(var9);
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.Point var14 = var0.translateValueThetaRadiusToJava2D(1.0E-8d, 0.0d, var13);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    var0.setBaseShape(var3);
    boolean var5 = var0.getUseOutlinePaint();
    boolean var8 = var0.isItemLabelVisible(2, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeCrosshairStroke(var10);
    int var13 = var0.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    double var16 = var15.getBottom();
    var14.ensureAtLeast(var15);
    var0.setFixedRangeAxisSpace(var15);
    double var19 = var15.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer var14 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var14.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var18 = var17.getRotationAnchor();
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, (-1.0d));
//     boolean var22 = var18.equals((java.lang.Object)(-1.0d));
//     var10.draw(var11, 100.0f, 2.0f, var18, 0.0f, (-1.0f), 10.0d);
//     java.awt.Shape var27 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.0f, 10.0f, var8, 1.0d, var18);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.chart.plot.CategoryMarker var2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var1);
//     java.awt.Stroke var3 = var2.getStroke();
//     java.lang.Class var4 = null;
//     java.util.EventListener[] var5 = var2.getListeners(var4);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    int var2 = var1.getColumnCount();
    java.lang.Comparable var3 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeValue(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(100);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     org.jfree.chart.title.LegendTitle var12 = var11.getLegend();
//     var12.setNotify(true);
//     var12.setHeight(Double.NaN);
//     java.awt.Paint var17 = var12.getBackgroundPaint();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     java.awt.Font var21 = var20.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var22);
//     java.awt.Paint var24 = var23.getOutlinePaint();
//     var23.setBackgroundAlpha(100.0f);
//     float var27 = var23.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("Jan", var21, (org.jfree.chart.plot.Plot)var23, true);
//     org.jfree.chart.title.LegendTitle var30 = var29.getLegend();
//     java.util.List var31 = var29.getSubtitles();
//     var12.addChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    java.lang.String var1 = var0.getGPL();
    java.lang.String var2 = var0.getLGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var1 = var0.getArrangement();
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setPadding(var3);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot(var13);
//     org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var16 = var15.getArrangement();
//     boolean var17 = var14.equals((java.lang.Object)var16);
//     var0.setArrangement(var16);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
//     int var1 = var0.getItemCount();
//     org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var2.getSeriesPositiveItemLabelPosition(2);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var2.getBasePositiveItemLabelPosition();
//     var2.setRenderAsPercentages(false);
//     boolean var11 = var0.equals((java.lang.Object)false);
//     org.jfree.data.DefaultKeyedValues var12 = new org.jfree.data.DefaultKeyedValues();
//     int var13 = var12.getItemCount();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.setDomainGridlinesVisible(true);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var18 = var17.isDomainGridlinesVisible();
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var20 = var19.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var21 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var21.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var21.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var27 = var21.getItemStroke((-1), 100);
//     boolean var28 = var20.equals((java.lang.Object)var27);
//     var17.setRangeCrosshairStroke(var27);
//     int var30 = var17.getDatasetCount();
//     org.jfree.chart.renderer.category.StackedBarRenderer var32 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var32.getSeriesItemLabelGenerator(100);
//     var32.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
//     var32.setMinimumBarLength(1.0d);
//     java.awt.Stroke var41 = var32.getBaseStroke();
//     int var42 = var32.getColumnCount();
//     var17.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32, false);
//     org.jfree.chart.axis.AxisLocation var46 = null;
//     var17.setDomainAxisLocation(2, var46, false);
//     org.jfree.chart.util.SortOrder var49 = var17.getColumnRenderingOrder();
//     var14.setRowRenderingOrder(var49);
//     var12.sortByValues(var49);
//     var0.sortByKeys(var49);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var24
//     assertTrue("Contract failed: equals-hashcode on var8 and var24", var8.equals(var24) ? var8.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var8
//     assertTrue("Contract failed: equals-hashcode on var24 and var8", var24.equals(var8) ? var24.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "");
    org.jfree.chart.entity.AxisLabelEntity var7 = new org.jfree.chart.entity.AxisLabelEntity(var0, var2, "TextAnchor.CENTER", "");
    var7.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var5 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var5.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var8 = var5.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var11 = var5.getItemStroke((-1), 100);
    boolean var12 = var4.equals((java.lang.Object)var11);
    var1.setInsets(var4);
    var1.setShadowYOffset(1.0d);
    double var16 = var1.getLabelGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var2 = null;
//     var0.setMarkerBand(var2);
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.NumberTickUnit var5 = var4.getTickUnit();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var8 = null;
//     var6.setMarkerBand(var8);
//     java.text.NumberFormat var10 = var6.getNumberFormatOverride();
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, (-1.0d));
//     var6.setRange(var13);
//     var4.setRange(var13);
//     var0.setRangeWithMargins(var13, false, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var3 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var3.getSeriesItemLabelGenerator(100);
//     boolean var6 = var2.equals((java.lang.Object)var3);
//     org.jfree.chart.block.LineBorder var7 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var8 = var7.getInsets();
//     var2.setLabelInsets(var8);
//     java.awt.Paint var11 = var2.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var16 = var15.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var17 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var18 = var17.getCompletePaint();
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var23 = var22.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var24 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var11, (java.awt.Paint)var15, var18, (java.awt.Paint)var22);
//     int var25 = var22.getBlue();
//     int var26 = var0.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.RegularTimePeriod var27 = var0.next();
//     long var28 = var27.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1435867199999L);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)false, false);
    var0.setMinimumBarLength(1.0d);
    var0.setBaseSeriesVisibleInLegend(false, false);
    java.awt.Shape var13 = var0.lookupSeriesShape((-1));
    java.awt.Stroke var15 = var0.getSeriesOutlineStroke(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
//     java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setSeriesOutlineStroke(4, var10, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer var14 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var14.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBaseNegativeItemLabelPosition();
//     boolean var19 = var14.isSeriesVisible(10);
//     java.awt.Paint var20 = var14.getBasePaint();
//     java.awt.Paint var23 = var14.getItemLabelPaint(0, 1);
//     var0.setIncompletePaint(var23);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearDomainAxes();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
//     java.awt.Paint var6 = var5.getSeparatorPaint();
//     var2.setOutlinePaint(var6);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     boolean var9 = var8.isTickLabelsVisible();
//     var8.setTickMarksVisible(false);
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawRangeGridline(var1, var2, (org.jfree.chart.axis.ValueAxis)var8, var12, 1.0d);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
    java.awt.Font var5 = null;
    org.jfree.data.general.WaferMapDataset var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
    java.awt.Paint var8 = var7.getOutlinePaint();
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var8, 0.0f, 0, var11);
    java.util.List var13 = var12.getLines();
    var3.addExceptions(var13);
    int var15 = var3.getSegmentsExcluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.chart.event.MarkerChangeEvent var5 = null;
//     var3.markerChanged(var5);
//     boolean var7 = var0.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
//     double var12 = var10.calculateBottomInset((-1.0d));
//     double var13 = var10.getBottom();
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var15 = var14.getArrangement();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var18 = null;
//     var16.setMarkerBand(var18);
//     java.text.NumberFormat var20 = var16.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 10.0d, 1.0d);
//     var26.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var28);
//     org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var26, (org.jfree.data.general.Dataset)var28, (java.lang.Comparable)100.0f);
//     var31.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var37 = var31.getBounds();
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var16.lengthToJava2D(0.0d, var37, var38);
//     var14.setBounds(var37);
//     java.awt.geom.Rectangle2D var43 = var10.createOutsetRectangle(var37, true, false);
//     var0.draw(var8, var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Font var3 = var2.getLabelFont();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
    java.awt.Paint var6 = var5.getOutlinePaint();
    var5.setBackgroundAlpha(100.0f);
    float var9 = var5.getForegroundAlpha();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
    org.jfree.chart.event.ChartProgressListener var12 = null;
    var11.removeProgressListener(var12);
    org.jfree.chart.title.TextTitle var14 = null;
    var11.setTitle(var14);
    var11.setNotify(false);
    java.awt.RenderingHints var18 = var11.getRenderingHints();
    var11.setBackgroundImageAlpha(2.0f);
    var11.setTitle("0.2");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var25 = var11.createBufferedImage(4, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 10.0f);
    var0.setBaseShape(var3);
    boolean var5 = var0.getUseOutlinePaint();
    boolean var8 = var0.isItemLabelVisible(2, 100);
    var0.setBaseSeriesVisibleInLegend(true, false);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("org.jfree.chart.ChartColor[r=0,g=0,b=0]", var1);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getURLText();
//     java.awt.Paint var2 = var0.getPaint();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var6);
//     var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     java.awt.Font var9 = var5.getLabelFont();
//     java.lang.String var11 = var5.getCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     var5.setTickMarkInsideLength(100.0f);
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var17 = var16.getArrangement();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var20 = null;
//     var18.setMarkerBand(var20);
//     java.text.NumberFormat var22 = var18.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 10.0d, 1.0d);
//     var28.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var30);
//     org.jfree.chart.title.LegendItemBlockContainer var33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var28, (org.jfree.data.general.Dataset)var30, (java.lang.Comparable)100.0f);
//     var33.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var39 = var33.getBounds();
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var18.lengthToJava2D(0.0d, var39, var40);
//     var16.setBounds(var39);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var44 = var43.isDomainGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var46 = var43.getRangeAxisEdge(100);
//     double var47 = var5.getCategoryEnd(1, (-1), var39, var46);
//     org.jfree.chart.axis.SegmentedTimeline var51 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     java.awt.Font var53 = null;
//     org.jfree.data.general.WaferMapDataset var54 = null;
//     org.jfree.chart.plot.WaferMapPlot var55 = new org.jfree.chart.plot.WaferMapPlot(var54);
//     java.awt.Paint var56 = var55.getOutlinePaint();
//     org.jfree.chart.text.TextMeasurer var59 = null;
//     org.jfree.chart.text.TextBlock var60 = org.jfree.chart.text.TextUtilities.createTextBlock("", var53, var56, 0.0f, 0, var59);
//     java.util.List var61 = var60.getLines();
//     var51.addExceptions(var61);
//     long var65 = var51.getExceptionSegmentCount(10L, 1L);
//     java.util.List var66 = var51.getExceptionSegments();
//     var51.addException(1417420800000L, 1388563200000L);
//     java.lang.Object var70 = var0.draw(var3, var39, (java.lang.Object)var51);
//     
//     // Checks the contract:  equals-hashcode on var7 and var55
//     assertTrue("Contract failed: equals-hashcode on var7 and var55", var7.equals(var55) ? var7.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var7
//     assertTrue("Contract failed: equals-hashcode on var55 and var7", var55.equals(var7) ? var55.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    boolean var5 = var1.equals((java.lang.Object)var2);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    java.awt.Font var9 = var8.getLabelFont();
    org.jfree.data.general.WaferMapDataset var10 = null;
    org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot(var10);
    java.awt.Paint var12 = var11.getOutlinePaint();
    var11.setBackgroundAlpha(100.0f);
    float var15 = var11.getForegroundAlpha();
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("Jan", var9, (org.jfree.chart.plot.Plot)var11, true);
    var1.setTickLabelFont(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0f);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setSeriesLinesVisible(1, true);
    java.lang.Object var4 = var0.clone();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    boolean var7 = var6.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.Marker var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeMarker(var5, var6, var8, var9, var10);
    org.jfree.chart.renderer.category.StackedBarRenderer var12 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getSeriesItemLabelGenerator(100);
    boolean var16 = var12.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17);
    var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    var6.setRangeCrosshairValue(0.0d, true);
    var6.setForegroundAlpha(0.0f);
    org.jfree.chart.axis.ValueAxis var27 = var6.getRangeAxisForDataset(0);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
    double var32 = var31.getXOffset();
    org.jfree.chart.renderer.category.LineRenderer3D var33 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var33.setSeriesLinesVisible(1, true);
    java.lang.Object var37 = var33.clone();
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    boolean var40 = var39.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.plot.Marker var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    var33.drawRangeMarker(var38, var39, var41, var42, var43);
    var39.clearDomainMarkers((-1));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var47 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Object var48 = var47.clone();
    var39.setDataset((org.jfree.data.category.CategoryDataset)var47);
    org.jfree.data.Range var50 = var31.findRangeBounds((org.jfree.data.category.CategoryDataset)var47);
    var6.setDataset((org.jfree.data.category.CategoryDataset)var47);
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var54 = null;
    org.jfree.chart.plot.WaferMapPlot var55 = new org.jfree.chart.plot.WaferMapPlot(var54);
    java.awt.Paint var56 = var55.getOutlinePaint();
    var55.setBackgroundAlpha(100.0f);
    boolean var59 = var53.hasListener((java.util.EventListener)var55);
    var53.setTickLabelsVisible(true);
    var53.setMaximumCategoryLabelWidthRatio(1.0f);
    var53.setUpperMargin(0.0d);
    org.jfree.chart.renderer.category.LineRenderer3D var66 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var66.setSeriesLinesVisible(1, true);
    java.lang.Object var70 = var66.clone();
    java.awt.Graphics2D var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
    boolean var73 = var72.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var74 = null;
    org.jfree.chart.plot.Marker var75 = null;
    java.awt.geom.Rectangle2D var76 = null;
    var66.drawRangeMarker(var71, var72, var74, var75, var76);
    org.jfree.chart.renderer.category.StackedBarRenderer var78 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var80 = var78.getSeriesItemLabelGenerator(100);
    boolean var82 = var78.isSeriesVisible(0);
    org.jfree.chart.urls.CategoryURLGenerator var83 = null;
    var78.setBaseURLGenerator(var83);
    var72.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var78, false);
    var72.setRangeCrosshairValue(0.0d, true);
    org.jfree.chart.axis.NumberAxis var90 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var91 = var72.getDataRange((org.jfree.chart.axis.ValueAxis)var90);
    org.jfree.chart.text.TextFragment var93 = new org.jfree.chart.text.TextFragment("WMAP_Plot");
    org.jfree.chart.renderer.category.StackedBarRenderer var94 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var96 = var94.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var97 = var94.getBaseNegativeItemLabelPosition();
    boolean var98 = var93.equals((java.lang.Object)var94);
    org.jfree.chart.plot.CategoryPlot var99 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var47, (org.jfree.chart.axis.CategoryAxis)var53, (org.jfree.chart.axis.ValueAxis)var90, (org.jfree.chart.renderer.category.CategoryItemRenderer)var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setBaseLinesVisible(false);
    boolean var5 = var0.getItemShapeFilled(0, 100);
    var0.setBaseShapesFilled(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var3);
//     org.jfree.chart.util.Size2D var7 = var0.arrange(var1, var6);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 1.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)100.0d);
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var7, (java.lang.Comparable)(byte)100);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var9.draw(var10, var11);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(0, 0, var2);
//     org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 100, 1);
//     long var9 = var7.toMillisecond((-1L));
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     java.util.Date var11 = var10.getEnd();
//     boolean var12 = var7.containsDomainValue(var11);
//     java.util.TimeZone var13 = null;
//     java.util.Date var14 = var3.rollDate(var11, var13);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    int var1 = var0.getItemCount();
    org.jfree.chart.renderer.category.StackedBarRenderer var2 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getBaseNegativeItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var7 = var2.getSeriesPositiveItemLabelPosition(2);
    org.jfree.chart.labels.ItemLabelPosition var8 = var2.getBasePositiveItemLabelPosition();
    var2.setRenderAsPercentages(false);
    boolean var11 = var0.equals((java.lang.Object)false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var0.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Paint var2 = var1.getSeparatorPaint();
    double var3 = var1.getLabelGap();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    var1.setLegendItemShape(var5);
    var1.setMinimumArcAngleToDraw(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBaseNegativeItemLabelPosition();
    boolean var5 = var0.isSeriesVisible(10);
    java.awt.Font var7 = var0.getSeriesItemLabelFont(0);
    org.jfree.chart.urls.CategoryURLGenerator var9 = var0.getSeriesURLGenerator(10);
    java.lang.Boolean var11 = var0.getSeriesItemLabelsVisible(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.05d, 10.0d, true);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    java.awt.Paint var8 = var7.getSeparatorPaint();
    org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var11 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var11.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var17 = var11.getItemStroke((-1), 100);
    boolean var18 = var10.equals((java.lang.Object)var17);
    var7.setInsets(var10);
    var7.setShadowYOffset(1.0d);
    org.jfree.chart.labels.PieToolTipGenerator var22 = var7.getToolTipGenerator();
    double var23 = var7.getLabelLinkMargin();
    boolean var24 = var4.hasListener((java.util.EventListener)var7);
    java.lang.Comparable var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var28 = var4.getStartValue(var25, (java.lang.Comparable)2.0d, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = null;
    var0.setBoolean(15, var2);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     java.awt.Font var3 = var2.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var4);
//     java.awt.Paint var6 = var5.getOutlinePaint();
//     var5.setBackgroundAlpha(100.0f);
//     float var9 = var5.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("Jan", var3, (org.jfree.chart.plot.Plot)var5, true);
//     org.jfree.chart.title.LegendTitle var12 = var11.getLegend();
//     var12.setNotify(true);
//     org.jfree.chart.util.RectangleInsets var15 = var12.getItemLabelPadding();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     java.awt.Font var21 = var20.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var22);
//     java.awt.Paint var24 = var23.getOutlinePaint();
//     var23.setBackgroundAlpha(100.0f);
//     float var27 = var23.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("Jan", var21, (org.jfree.chart.plot.Plot)var23, true);
//     org.jfree.chart.title.LegendTitle var30 = var29.getLegend();
//     var30.setNotify(true);
//     org.jfree.chart.util.RectangleInsets var33 = var30.getItemLabelPadding();
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.data.general.WaferMapDataset var36 = null;
//     org.jfree.chart.plot.WaferMapPlot var37 = new org.jfree.chart.plot.WaferMapPlot(var36);
//     var35.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
//     java.awt.Font var39 = var35.getLabelFont();
//     org.jfree.chart.ChartRenderingInfo var42 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var44 = var43.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var45 = null;
//     var43.setMarkerBand(var45);
//     java.text.NumberFormat var47 = var43.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var49, var50, 10.0d, 1.0d);
//     var53.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var55 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var55);
//     org.jfree.chart.title.LegendItemBlockContainer var58 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var53, (org.jfree.data.general.Dataset)var55, (java.lang.Comparable)100.0f);
//     var58.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var64 = var58.getBounds();
//     org.jfree.chart.util.RectangleEdge var65 = null;
//     double var66 = var43.lengthToJava2D(0.0d, var64, var65);
//     var42.setChartArea(var64);
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     double var69 = var35.getCategoryStart(1, 0, var64, var68);
//     java.awt.geom.Rectangle2D var70 = var33.createInsetRectangle(var64);
//     java.awt.geom.Point2D var71 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, 0.0d, var70);
//     java.awt.geom.Rectangle2D var72 = var15.createOutsetRectangle(var70);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 10.0d, 1.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)100.0d);
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var7, (java.lang.Comparable)(byte)100);
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var7);
    double var11 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "RectangleEdge.RIGHT", "");
    java.lang.String var5 = var4.getVersion();
    java.lang.Object var6 = null;
    boolean var7 = var4.equals(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge(100);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    boolean var7 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisLocation var8 = var0.getRangeAxisLocation();
    org.jfree.chart.event.PlotChangeEvent var9 = null;
    var0.notifyListeners(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.NumberTickUnit var1 = var0.getTickUnit();
    org.jfree.data.RangeType var2 = var0.getRangeType();
    boolean var3 = var0.isAutoTickUnitSelection();
    org.jfree.chart.axis.TickUnitSource var4 = var0.getStandardTickUnits();
    var0.setTickMarkOutsideLength(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var5 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     double var7 = var4.getRangeLowerBound(true);
//     boolean var8 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isDomainGridlinesVisible();
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
    org.jfree.chart.renderer.category.StackedBarRenderer var4 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var4.getSeriesItemLabelGenerator(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var4.getBaseNegativeItemLabelPosition();
    java.awt.Stroke var10 = var4.getItemStroke((-1), 100);
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeCrosshairStroke(var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.plot.WaferMapPlot var17 = new org.jfree.chart.plot.WaferMapPlot(var16);
    java.awt.Paint var18 = var17.getOutlinePaint();
    var17.setBackgroundAlpha(100.0f);
    boolean var21 = var15.hasListener((java.util.EventListener)var17);
    var0.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var15);
    boolean var23 = var0.isRangeZoomable();
    boolean var24 = var0.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, (-1.0d));
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, (-1.0d));
    var0.setRange(var3, true, false);
    org.jfree.chart.util.RectangleInsets var9 = var0.getTickLabelInsets();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    java.awt.Font var12 = var11.getLabelFont();
    org.jfree.chart.event.MarkerChangeEvent var13 = null;
    var11.markerChanged(var13);
    var11.setLabelLinkMargin(1.0E-5d);
    java.awt.Image var17 = null;
    var11.setBackgroundImage(var17);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var20 = null;
    org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, (-1.0d));
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, (-1.0d));
    var19.setRange(var22, true, false);
    org.jfree.chart.util.RectangleInsets var28 = var19.getTickLabelInsets();
    var11.setInsets(var28, false);
    var0.setTickLabelInsets(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.Arrangement var1 = var0.getArrangement();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var4 = null;
//     var2.setMarkerBand(var4);
//     java.text.NumberFormat var6 = var2.getNumberFormatOverride();
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 10.0d, 1.0d);
//     var12.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var14);
//     org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, (org.jfree.data.general.Dataset)var14, (java.lang.Comparable)100.0f);
//     var17.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var23 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var2.lengthToJava2D(0.0d, var23, var24);
//     var0.setBounds(var23);
//     org.jfree.chart.block.Arrangement var27 = var0.getArrangement();
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var30 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(100);
//     boolean var33 = var29.equals((java.lang.Object)var30);
//     org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
//     var29.setLabelInsets(var35);
//     java.awt.Paint var38 = var29.getTickLabelPaint((java.lang.Comparable)1.0f);
//     org.jfree.chart.ChartColor var42 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var43 = var42.getColorSpace();
//     org.jfree.chart.renderer.category.GanttRenderer var44 = new org.jfree.chart.renderer.category.GanttRenderer();
//     java.awt.Paint var45 = var44.getCompletePaint();
//     org.jfree.chart.ChartColor var49 = new org.jfree.chart.ChartColor(0, 0, 0);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var51 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var38, (java.awt.Paint)var42, var45, (java.awt.Paint)var49);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var52);
//     org.jfree.data.Range var54 = var51.findRangeBounds((org.jfree.data.category.CategoryDataset)var52);
//     org.jfree.data.general.PieDataset var56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var52, (java.lang.Comparable)0);
//     org.jfree.chart.title.LegendItemBlockContainer var58 = new org.jfree.chart.title.LegendItemBlockContainer(var27, (org.jfree.data.general.Dataset)var52, (java.lang.Comparable)0);
//     
//     // Checks the contract:  equals-hashcode on var14 and var52
//     assertTrue("Contract failed: equals-hashcode on var14 and var52", var14.equals(var52) ? var14.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var14
//     assertTrue("Contract failed: equals-hashcode on var52 and var14", var52.equals(var14) ? var52.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(10.0d, 0.0d, true);
//     double var4 = var3.getXOffset();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var8 = var7.isDomainGridlinesVisible();
//     var7.setAnchorValue(1.0d, true);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
//     org.jfree.chart.axis.MarkerAxisBand var14 = null;
//     var12.setMarkerBand(var14);
//     var12.setInverted(true);
//     org.jfree.data.Range var18 = var7.getDataRange((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.renderer.category.LineRenderer3D var19 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var19.setSeriesLinesVisible(1, true);
//     java.lang.Object var23 = var19.clone();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var26 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.Marker var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var19.drawRangeMarker(var24, var25, var27, var28, var29);
//     org.jfree.chart.renderer.category.StackedBarRenderer var31 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var33 = var31.getSeriesItemLabelGenerator(100);
//     boolean var35 = var31.isSeriesVisible(0);
//     org.jfree.chart.urls.CategoryURLGenerator var36 = null;
//     var31.setBaseURLGenerator(var36);
//     var25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var31, false);
//     var25.setRangeCrosshairValue(0.0d, true);
//     var25.setForegroundAlpha(0.0f);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.util.HorizontalAlignment var46 = null;
//     org.jfree.chart.util.VerticalAlignment var47 = null;
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 10.0d, 1.0d);
//     var50.clear();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var52);
//     org.jfree.chart.title.LegendItemBlockContainer var55 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var50, (org.jfree.data.general.Dataset)var52, (java.lang.Comparable)100.0f);
//     var55.setPadding(0.0d, 0.05d, 100.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var61 = var55.getBounds();
//     java.awt.geom.Point2D var62 = null;
//     org.jfree.chart.plot.PlotState var63 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     var25.draw(var45, var61, var62, var63, var64);
//     var3.drawRangeGridline(var5, var6, (org.jfree.chart.axis.ValueAxis)var12, var61, Double.NaN);
//     org.jfree.chart.renderer.category.StackedBarRenderer var68 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var70 = var68.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var71 = var68.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelPosition var73 = var68.getSeriesPositiveItemLabelPosition(2);
//     var3.setPositiveItemLabelPositionFallback(var73);
//     org.jfree.chart.renderer.category.StackedBarRenderer var75 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var77 = var75.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.renderer.category.StackedBarRenderer var78 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var80 = var78.getSeriesItemLabelGenerator(100);
//     org.jfree.chart.labels.ItemLabelPosition var81 = var78.getBaseNegativeItemLabelPosition();
//     boolean var83 = var78.isSeriesVisible(10);
//     java.awt.Paint var84 = var78.getBasePaint();
//     java.util.EventListener var85 = null;
//     boolean var86 = var78.hasListener(var85);
//     var78.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var89 = var78.getBaseNegativeItemLabelPosition();
//     var75.setPositiveItemLabelPositionFallback(var89);
//     var3.setNegativeItemLabelPositionFallback(var89);
//     
//     // Checks the contract:  equals-hashcode on var71 and var81
//     assertTrue("Contract failed: equals-hashcode on var71 and var81", var71.equals(var81) ? var71.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var89
//     assertTrue("Contract failed: equals-hashcode on var71 and var89", var71.equals(var89) ? var71.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var81
//     assertTrue("Contract failed: equals-hashcode on var73 and var81", var73.equals(var81) ? var73.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var89
//     assertTrue("Contract failed: equals-hashcode on var73 and var89", var73.equals(var89) ? var73.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var71
//     assertTrue("Contract failed: equals-hashcode on var81 and var71", var81.equals(var71) ? var81.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var73
//     assertTrue("Contract failed: equals-hashcode on var81 and var73", var81.equals(var73) ? var81.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var71
//     assertTrue("Contract failed: equals-hashcode on var89 and var71", var89.equals(var71) ? var89.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var73
//     assertTrue("Contract failed: equals-hashcode on var89 and var73", var89.equals(var73) ? var89.hashCode() == var73.hashCode() : true);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getURLText();
    java.awt.Paint var2 = var0.getPaint();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPadding(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Font var4 = var3.getLabelFont();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var5);
//     java.awt.Paint var7 = var6.getOutlinePaint();
//     var6.setBackgroundAlpha(100.0f);
//     float var10 = var6.getForegroundAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("Jan", var4, (org.jfree.chart.plot.Plot)var6, true);
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("12/31/69", var4);
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var16 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var16.getSeriesItemLabelGenerator(100);
//     boolean var19 = var15.equals((java.lang.Object)var16);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.renderer.category.StackedBarRenderer var22 = new org.jfree.chart.renderer.category.StackedBarRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var22.getSeriesItemLabelGenerator(100);
//     boolean var25 = var21.equals((java.lang.Object)var22);
//     org.jfree.chart.block.LineBorder var26 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var27 = var26.getInsets();
//     var21.setLabelInsets(var27);
//     var15.setLabelInsets(var27);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     java.awt.Font var32 = var31.getLabelFont();
//     var15.setTickLabelFont(var32);
//     var13.setFont(var32);
//     
//     // Checks the contract:  equals-hashcode on var3 and var31
//     assertTrue("Contract failed: equals-hashcode on var3 and var31", var3.equals(var31) ? var3.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var3
//     assertTrue("Contract failed: equals-hashcode on var31 and var3", var31.equals(var3) ? var31.hashCode() == var3.hashCode() : true);
// 
//   }

}
