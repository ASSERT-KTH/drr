
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(var0, 1, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var0, var1, var2);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem(var0, "", "", "", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var2 = var0.getTickLabelFont(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.util.TimeZone var0 = null;
    java.util.Locale var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     org.jfree.chart.axis.AxisState var8 = var0.draw(var1, 100.0d, var3, var4, var5, var7);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance(var0);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.util.List var4 = null;
//     var1.mapDatasetToRangeAxes(10, var4);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var1);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.awt.Image var0 = null;
//     java.io.ObjectOutputStream var1 = null;
//     org.jfree.chart.util.SerialUtilities.writeImage(var0, var1);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.plot.DrawingSupplier var7 = var6.getDrawingSupplier();
//     java.awt.Paint var8 = var6.getRangeZeroBaselinePaint();
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke[] var12 = null;
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var9, var11, var12, var14);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var1.parse("");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 0.0d, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(var2, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getCategoryMiddle(0, (-1), var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.category.CategoryDataset var2 = var1.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    java.awt.Paint var5 = var3.getRangeZeroBaselinePaint();
    java.awt.Stroke var6 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var9 = null;
    var7.setSeriesItemLabelGenerator(100, var9);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
    var7.setSeriesItemLabelPaint(1, var22, false);
    java.awt.Stroke var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker(100.0d, 100.0d, var5, var6, var22, var26, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems(var0, 10, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.geom.Point2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setQuadrantOrigin(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var0.setSeriesItemLabelPaint(1, var15, false);
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var15};
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     java.awt.Paint var30 = var28.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var26, var30);
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var30};
//     java.awt.Stroke var33 = null;
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
//     java.awt.Stroke[] var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     java.awt.geom.Rectangle2D var38 = var37.getDataArea();
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var19, var32, var34, var35, var39);
//     
//     // Checks the contract:  equals-hashcode on var10 and var25
//     assertTrue("Contract failed: equals-hashcode on var10 and var25", var10.equals(var25) ? var10.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var10
//     assertTrue("Contract failed: equals-hashcode on var25 and var10", var25.equals(var10) ? var25.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var37
//     assertTrue("Contract failed: equals-hashcode on var25 and var37", var25.equals(var37) ? var25.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var25
//     assertTrue("Contract failed: equals-hashcode on var37 and var25", var37.equals(var25) ? var37.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var28
//     assertTrue("Contract failed: equals-hashcode on var13 and var28", var13.equals(var28) ? var13.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var13
//     assertTrue("Contract failed: equals-hashcode on var28 and var13", var28.equals(var13) ? var28.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var29
//     assertTrue("Contract failed: equals-hashcode on var14 and var29", var14.equals(var29) ? var14.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var14
//     assertTrue("Contract failed: equals-hashcode on var29 and var14", var29.equals(var14) ? var29.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var31
//     assertTrue("Contract failed: equals-hashcode on var16 and var31", var16.equals(var31) ? var16.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var16
//     assertTrue("Contract failed: equals-hashcode on var31 and var16", var31.equals(var16) ? var31.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var8 = null;
//     var6.setSeriesItemLabelGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     java.awt.Paint var21 = var19.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var17, var21);
//     var6.setSeriesItemLabelPaint(1, var21, false);
//     var1.setQuadrantPaint(0, var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type java.lang.StringIndexOutOfBoundsException");
    } catch (java.lang.StringIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var1.drawBackground(var4, var11);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     org.jfree.chart.RenderingSource var17 = null;
//     var1.select(0.0d, (-1.0d), var11, var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
//     java.awt.Font var12 = null;
//     var11.setLabelFont(var12);
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var16 = null;
//     var14.setSeriesItemLabelGenerator(100, var16);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var27 = new org.jfree.chart.plot.CombinedRangeXYPlot(var26);
//     org.jfree.chart.plot.DrawingSupplier var28 = var27.getDrawingSupplier();
//     java.awt.Paint var29 = var27.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var25, var29);
//     var14.setSeriesItemLabelPaint(1, var29, false);
//     var11.setLabelPaint(var29);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var27
//     assertTrue("Contract failed: equals-hashcode on var8 and var27", var8.equals(var27) ? var8.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var8
//     assertTrue("Contract failed: equals-hashcode on var27 and var8", var27.equals(var8) ? var27.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var28
//     assertTrue("Contract failed: equals-hashcode on var9 and var28", var9.equals(var28) ? var9.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
//     org.jfree.data.xy.XYDataset var4 = null;
//     java.lang.String var7 = var3.generateLabelString(var4, 0, 1);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    var1.configureRangeAxes();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.axis.AxisLocation var9 = var8.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAxisLocation((-1), var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesPositiveItemLabelPosition(0);
//     var0.setSeriesNegativeItemLabelPosition(0, var6);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
//     
//     // Checks the contract:  equals-hashcode on var2 and var6
//     assertTrue("Contract failed: equals-hashcode on var2 and var6", var2.equals(var6) ? var2.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var2
//     assertTrue("Contract failed: equals-hashcode on var6 and var2", var6.equals(var2) ? var6.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100L);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    int var2 = var1.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
//     var1.setDomainGridlinePaint(var6);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-123));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    var0.setAutoPopulateSeriesFillPaint(true);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var5 = var3.getRangeAxis();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     org.jfree.chart.axis.AxisSpace var13 = var0.reserveSpace(var1, (org.jfree.chart.plot.Plot)var3, var6, var11, var12);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("SerialDate.weekInMonthToString(): invalid code.", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    var1.configureRangeAxes();
    org.jfree.chart.plot.XYPlot var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var6, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var16 = var13.getDomainAxisEdge();
//     double var17 = org.jfree.chart.util.RectangleEdge.coordinate(var6, var16);
//     
//     // Checks the contract:  equals-hashcode on var8 and var13
//     assertTrue("Contract failed: equals-hashcode on var8 and var13", var8.equals(var13) ? var8.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var8
//     assertTrue("Contract failed: equals-hashcode on var13 and var8", var13.equals(var8) ? var13.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var14
//     assertTrue("Contract failed: equals-hashcode on var9 and var14", var9.equals(var14) ? var9.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var9
//     assertTrue("Contract failed: equals-hashcode on var14 and var9", var14.equals(var9) ? var14.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var1 = var0.getTickMarkInsideLength();
//     var0.setLabel("");
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var13, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var23 = var20.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var24 = org.jfree.chart.util.RectangleEdge.opposite(var23);
//     double var25 = var0.getCategoryJava2DCoordinate(var4, 0, 4, var13, var23);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     java.text.NumberFormat var0 = java.text.NumberFormat.getCurrencyInstance();
//     int var1 = var0.getMinimumIntegerDigits();
//     var0.setMaximumIntegerDigits(4);
//     java.text.ParsePosition var5 = null;
//     java.lang.Object var6 = var0.parseObject("SerialDate.weekInMonthToString(): invalid code.", var5);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     java.util.Date var2 = null;
//     org.jfree.chart.ChartRenderingInfo var3 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = new org.jfree.chart.plot.PlotRenderingInfo(var3);
//     java.awt.geom.Rectangle2D var5 = var4.getDataArea();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var11 = org.jfree.chart.util.RectangleEdge.opposite(var10);
//     double var12 = var0.dateToJava2D(var2, var5, var11);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    var0.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    java.awt.Shape var14 = var0.lookupLegendShape(100);
    org.jfree.data.category.CategoryDataset var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var20 = new org.jfree.chart.entity.CategoryItemEntity(var14, "", "SerialDate.weekInMonthToString(): invalid code.", var17, (java.lang.Comparable)10L, (java.lang.Comparable)"hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     boolean var10 = var0.getItemVisible(10, 100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var13 = null;
//     var11.setSeriesItemLabelGenerator(100, var13);
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.awt.geom.Rectangle2D var22 = var21.getDataArea();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     java.awt.Paint var26 = var24.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var22, var26);
//     var11.setSeriesItemLabelPaint(1, var26, false);
//     var0.setBaseFillPaint(var26, true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = null;
//     java.awt.Font var5 = null;
//     org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 10.0d, 10.0d, 1.0d, 100.0d, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     java.awt.Paint var18 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var14, var18);
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.awt.geom.Rectangle2D var22 = var21.getDataArea();
//     var6.draw(var7, var14, var22, 10.0d, (-1.0d));
//     
//     // Checks the contract:  equals-hashcode on var13 and var21
//     assertTrue("Contract failed: equals-hashcode on var13 and var21", var13.equals(var21) ? var13.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var13
//     assertTrue("Contract failed: equals-hashcode on var21 and var13", var21.equals(var13) ? var21.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var14 = var11.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.util.RectangleEdge.opposite(var14);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     org.jfree.chart.axis.AxisState var18 = var1.draw(var2, (-1.0d), var6, var9, var15, var17);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = null;
//     org.jfree.chart.ChartRenderingInfo var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var2);
//     java.awt.geom.Rectangle2D var4 = var3.getDataArea();
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.dateToJava2D(var1, var4, var5);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    java.awt.Font var17 = null;
    var16.setLabelFont(var17);
    java.awt.Shape var19 = var16.getLine();
    java.awt.Paint var21 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    java.awt.geom.Rectangle2D var29 = var28.getDataArea();
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var31 = new org.jfree.chart.plot.CombinedRangeXYPlot(var30);
    org.jfree.chart.plot.DrawingSupplier var32 = var31.getDrawingSupplier();
    java.awt.Paint var33 = var31.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var29, var33);
    java.awt.Font var35 = null;
    var34.setLabelFont(var35);
    java.awt.Shape var37 = var34.getLine();
    java.awt.Paint var38 = var34.getFillPaint();
    org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var43 = var39.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.ChartRenderingInfo var45 = null;
    org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
    java.awt.geom.Rectangle2D var47 = var46.getDataArea();
    org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var52 = var48.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var55 = null;
    var53.setSeriesItemLabelGenerator(100, var55);
    org.jfree.chart.ChartRenderingInfo var62 = null;
    org.jfree.chart.plot.PlotRenderingInfo var63 = new org.jfree.chart.plot.PlotRenderingInfo(var62);
    java.awt.geom.Rectangle2D var64 = var63.getDataArea();
    org.jfree.chart.axis.ValueAxis var65 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var66 = new org.jfree.chart.plot.CombinedRangeXYPlot(var65);
    org.jfree.chart.plot.DrawingSupplier var67 = var66.getDrawingSupplier();
    java.awt.Paint var68 = var66.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var64, var68);
    var53.setSeriesItemLabelPaint(1, var68, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("", "", "SerialDate.weekInMonthToString(): invalid code.", "", true, var19, true, var21, true, var38, var43, true, (java.awt.Shape)var47, var52, var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     var1.setDomainMinorGridlinesVisible(true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var8 = null;
//     var6.setSeriesItemLabelGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     java.awt.Paint var21 = var19.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var17, var21);
//     var6.setSeriesItemLabelPaint(1, var21, false);
//     var1.setOutlinePaint(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("SerialDate.weekInMonthToString(): invalid code.", var1, (-1.0f), 0.0f, var4);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getDataArea();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot(var8);
//     org.jfree.chart.plot.DrawingSupplier var10 = var9.getDrawingSupplier();
//     java.awt.Paint var11 = var9.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var7, var11);
//     boolean var13 = org.jfree.chart.util.LineUtilities.clipLine(var0, var7);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    java.awt.Paint var15 = var11.getFillPaint();
    java.lang.String var16 = var11.getURLText();
    int var17 = var11.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     var1.handleClick(0, 1, var8);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.axis.AxisLocation var14 = var13.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var15 = org.jfree.chart.axis.AxisLocation.getOpposite(var14);
//     var1.setRangeAxisLocation(10, var15);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var1.", var13.equals(var1) == var1.equals(var13));
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    var2.setRangeWithMargins(var5);
    org.jfree.chart.block.LengthConstraintType var7 = null;
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    org.jfree.chart.block.LengthConstraintType var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(2.88E7d, var5, var7, 10.0d, var9, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.mapDatasetToDomainAxis((-1), 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.event.AxisChangeEvent var31 = null;
    var30.axisChanged(var31);
    var30.clearDomainMarkers();
    org.jfree.chart.annotations.CategoryAnnotation var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var35 = var30.removeAnnotation(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    org.jfree.chart.JFreeChart var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var4 = new org.jfree.chart.entity.JFreeChartEntity(var1, var2, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 0.0d);
    org.jfree.chart.block.LengthConstraintType var4 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    org.jfree.chart.block.LengthConstraintType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var3, var4, 2.88E7d, var6, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var27 = var26.getTickMarkInsideLength();
//     int var28 = var26.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var31 = null;
//     org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
//     var30.setRangeWithMargins(var33);
//     var30.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var37 = var30.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var39 = var38.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var41 = new org.jfree.chart.plot.CombinedRangeXYPlot(var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var41.getDrawingSupplier();
//     var41.setDomainZeroBaselineVisible(false);
//     var38.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var41);
//     var38.setDefaultEntityRadius((-1));
//     java.awt.Stroke var49 = null;
//     var38.setSeriesStroke(1, var49);
//     java.awt.Shape var52 = var38.lookupLegendShape(100);
//     var30.setDownArrow(var52);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var25, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var54);
//     var55.setWeight((-123));
//     java.lang.Comparable var58 = null;
//     var55.setDomainCrosshairColumnKey(var58);
//     org.jfree.chart.entity.PlotEntity var61 = new org.jfree.chart.entity.PlotEntity(var23, (org.jfree.chart.plot.Plot)var55, "");
//     
//     // Checks the contract:  equals-hashcode on var12 and var41
//     assertTrue("Contract failed: equals-hashcode on var12 and var41", var12.equals(var41) ? var12.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var12
//     assertTrue("Contract failed: equals-hashcode on var41 and var12", var41.equals(var12) ? var41.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var42
//     assertTrue("Contract failed: equals-hashcode on var13 and var42", var13.equals(var42) ? var13.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var13
//     assertTrue("Contract failed: equals-hashcode on var42 and var13", var42.equals(var13) ? var42.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.event.PlotChangeEvent var5 = null;
//     var4.plotChanged(var5);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     java.lang.String var8 = var1.getLabelToolTip();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var10.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var17 = var10.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var21.setDomainZeroBaselineVisible(false);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     var18.setDefaultEntityRadius((-1));
//     java.awt.Stroke var29 = null;
//     var18.setSeriesStroke(1, var29);
//     java.awt.Shape var32 = var18.lookupLegendShape(100);
//     var10.setDownArrow(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var10, var34);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0d, (-1.0d), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.util.Date var1 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getDataArea();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var8, var12);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var18 = var15.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     double var20 = var0.dateToJava2D(var1, var8, var19);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var30.axisChanged(var31);
//     var30.clearDomainMarkers();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.axis.AxisLocation var36 = var35.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var37 = org.jfree.chart.axis.AxisLocation.getOpposite(var36);
//     var30.setDomainAxisLocation(var37, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var35
//     assertTrue("Contract failed: equals-hashcode on var16 and var35", var16.equals(var35) ? var16.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var16
//     assertTrue("Contract failed: equals-hashcode on var35 and var16", var35.equals(var16) ? var35.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 2.88E7d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot(var31);
//     org.jfree.chart.plot.DrawingSupplier var33 = var32.getDrawingSupplier();
//     var32.setDomainZeroBaselineVisible(false);
//     java.lang.Object var36 = var32.clone();
//     org.jfree.data.xy.XYDataset var38 = var32.getDataset(0);
//     var5.setPlot((org.jfree.chart.plot.Plot)var32);
//     
//     // Checks the contract:  equals-hashcode on var16 and var32
//     assertTrue("Contract failed: equals-hashcode on var16 and var32", var16.equals(var32) ? var16.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var16
//     assertTrue("Contract failed: equals-hashcode on var32 and var16", var32.equals(var16) ? var32.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
    java.awt.Font var24 = null;
    var23.setLabelFont(var24);
    java.awt.Shape var26 = var23.getLine();
    java.awt.Paint var27 = var23.getFillPaint();
    var0.setSeriesPaint(0, var27);
    var0.setShadowYOffset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    float var1 = var0.getTickMarkInsideLength();
    java.lang.String var2 = var0.getLabelToolTip();
    var0.setLabelAngle(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
//     org.jfree.chart.event.RendererChangeEvent var4 = null;
//     var1.rendererChanged(var4);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.TableOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
    float var40 = var39.getTickMarkInsideLength();
    boolean var41 = var39.isTickLabelsVisible();
    int var42 = var30.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var39);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
    org.jfree.chart.plot.DrawingSupplier var46 = var45.getDrawingSupplier();
    java.lang.Object var47 = var45.clone();
    java.util.List var48 = var45.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.mapDatasetToRangeAxes(0, var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.awt.Color var0 = null;
//     java.lang.String var1 = org.jfree.chart.util.PaintUtilities.colorToString(var0);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    java.awt.Paint var34 = var30.getRangeGridlinePaint();
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
    org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
    java.lang.Object var39 = var37.clone();
    java.util.List var40 = var37.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.mapDatasetToRangeAxes(1, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    java.lang.String var5 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "ChartEntity: tooltip = "+ "'", var5.equals("ChartEntity: tooltip = "));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     java.awt.Paint var18 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var14, var18);
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     java.awt.Paint var30 = var28.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var26, var30);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
//     java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var36 = var33.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     org.jfree.chart.axis.AxisState var39 = var1.draw(var6, 0.0d, var14, var26, var36, var38);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     org.jfree.chart.axis.PeriodAxis var33 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var34 = null;
//     org.jfree.data.Range var36 = org.jfree.data.Range.expandToInclude(var34, 0.0d);
//     var33.setRangeWithMargins(var36);
//     var33.setNegativeArrowVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var33, var40);
//     
//     // Checks the contract:  equals-hashcode on var31 and var41
//     assertTrue("Contract failed: equals-hashcode on var31 and var41", var31.equals(var41) ? var31.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var31
//     assertTrue("Contract failed: equals-hashcode on var41 and var31", var41.equals(var31) ? var41.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTimeZone(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     var4.setDomainZeroBaselineVisible(false);
//     var0.setPlot((org.jfree.chart.plot.XYPlot)var4);
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var11 = null;
//     var9.setSeriesItemLabelGenerator(100, var11);
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getDataArea();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     java.awt.Paint var24 = var22.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var20, var24);
//     var9.setSeriesItemLabelPaint(1, var24, false);
//     var0.setBaseLegendTextPaint(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var5 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var6 = null;
    java.lang.String var7 = var4.getImageMapAreaTag(var5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + ""+ "'", var7.equals(""));

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var12 = null;
//     var10.setSeriesItemLabelGenerator(100, var12);
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getDataArea();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     java.awt.Paint var25 = var23.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var21, var25);
//     var10.setSeriesItemLabelPaint(1, var25, false);
//     var1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var10, true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var2 = var1.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     var4.setDomainZeroBaselineVisible(false);
//     var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var4);
//     var1.setDefaultEntityRadius((-1));
//     java.awt.Stroke var12 = null;
//     var1.setSeriesStroke(1, var12);
//     java.awt.Shape var15 = var1.lookupLegendShape(100);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var15, 2.88E7d, 100.0f, 0.0f);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     var4.setDomainZeroBaselineVisible(false);
//     var0.setPlot((org.jfree.chart.plot.XYPlot)var4);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
//     var4.setRangeCrosshairPaint(var12);
//     
//     // Checks the contract:  equals-hashcode on var5 and var11
//     assertTrue("Contract failed: equals-hashcode on var5 and var11", var5.equals(var11) ? var5.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var5
//     assertTrue("Contract failed: equals-hashcode on var11 and var5", var11.equals(var5) ? var11.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(0, 0, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     var1.setDomainMinorGridlinesVisible(true);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var8 = var7.getTickMarkInsideLength();
//     int var9 = var7.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
//     var11.setRangeWithMargins(var14);
//     var11.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var18 = var11.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var20 = var19.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     var22.setDomainZeroBaselineVisible(false);
//     var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
//     var19.setDefaultEntityRadius((-1));
//     java.awt.Stroke var30 = null;
//     var19.setSeriesStroke(1, var30);
//     java.awt.Shape var33 = var19.lookupLegendShape(100);
//     var11.setDownArrow(var33);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var35);
//     var36.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     java.awt.geom.Point2D var43 = null;
//     var36.panDomainAxes(100.0d, var41, var43);
//     java.awt.Stroke var45 = var36.getRangeMinorGridlineStroke();
//     var1.setDomainGridlineStroke(var45);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var1 = var0.getTickMarkInsideLength();
//     var0.setLabel("");
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var14 = var11.getDomainAxisEdge();
//     double var15 = var0.getCategorySeriesMiddle((-123), 10, 0, 0, 0.0d, var9, var14);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     java.awt.Paint var5 = var3.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var6 = var3.getDomainAxisEdge();
//     var0.ensureAtLeast(100.0d, var6);
//     var0.setRight(4.0d);
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getDataArea();
//     org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var12, "");
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     double var17 = var16.getDomainCrosshairValue();
//     boolean var18 = var16.isSubplot();
//     org.jfree.chart.util.RectangleEdge var20 = var16.getDomainAxisEdge(1);
//     var16.setForegroundAlpha(1.0f);
//     org.jfree.chart.util.RectangleEdge var23 = var16.getRangeAxisEdge();
//     java.awt.geom.Rectangle2D var24 = var0.reserved(var12, var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var3
//     assertTrue("Contract failed: equals-hashcode on var16 and var3", var16.equals(var3) ? var16.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getIntegerInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
    java.awt.Font var7 = null;
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    float var10 = var9.getTickMarkInsideLength();
    int var11 = var9.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 0.0d);
    var13.setRangeWithMargins(var16);
    var13.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var20 = var13.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var22 = var21.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
    org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
    var24.setDomainZeroBaselineVisible(false);
    var21.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
    var21.setDefaultEntityRadius((-1));
    java.awt.Stroke var32 = null;
    var21.setSeriesStroke(1, var32);
    java.awt.Shape var35 = var21.lookupLegendShape(100);
    var13.setDownArrow(var35);
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var8, (org.jfree.chart.axis.CategoryAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var37);
    var38.setWeight((-123));
    var38.clearDomainAxes();
    java.awt.Paint var42 = var38.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addLine("hi!", var7, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(var0, 100.0d, 10.0d, 4, (java.lang.Comparable)'4');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var3 = var1.getPieLabelRecord(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
    var1.setRangeAxisLocation(0, var9, true);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
    org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
    java.lang.Object var16 = var14.clone();
    java.util.List var17 = var14.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.mapDatasetToDomainAxes((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var5 = var1.getDomainAxis();
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     var7.setLowerMargin((-1.0d));
//     var7.setAxisLineVisible(false);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
//     java.awt.Font var24 = null;
//     var23.setLabelFont(var24);
//     java.awt.Shape var26 = var23.getLine();
//     java.awt.Paint var27 = var23.getFillPaint();
//     var7.setAxisLinePaint(var27);
//     var1.setQuadrantPaint(0, var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var1.setRangeWithMargins(var29);
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var33 = var32.getRightArrow();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var36 = var35.getTickMarkInsideLength();
//     int var37 = var35.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var40 = null;
//     org.jfree.data.Range var42 = org.jfree.data.Range.expandToInclude(var40, 0.0d);
//     var39.setRangeWithMargins(var42);
//     var39.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var46 = var39.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var48 = var47.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot(var49);
//     org.jfree.chart.plot.DrawingSupplier var51 = var50.getDrawingSupplier();
//     var50.setDomainZeroBaselineVisible(false);
//     var47.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var50);
//     var47.setDefaultEntityRadius((-1));
//     java.awt.Stroke var58 = null;
//     var47.setSeriesStroke(1, var58);
//     java.awt.Shape var61 = var47.lookupLegendShape(100);
//     var39.setDownArrow(var61);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var34, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var63);
//     var64.setWeight((-123));
//     var64.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var68 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var72 = var68.getItemOutlineStroke(0, 0, true);
//     var64.setRangeGridlineStroke(var72);
//     var32.setAxisLineStroke(var72);
//     var1.setTickMarkStroke(var72);
//     
//     // Checks the contract:  equals-hashcode on var12 and var50
//     assertTrue("Contract failed: equals-hashcode on var12 and var50", var12.equals(var50) ? var12.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var12
//     assertTrue("Contract failed: equals-hashcode on var50 and var12", var50.equals(var12) ? var50.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var51
//     assertTrue("Contract failed: equals-hashcode on var13 and var51", var13.equals(var51) ? var13.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var13
//     assertTrue("Contract failed: equals-hashcode on var51 and var13", var51.equals(var13) ? var51.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(-1L));
    org.jfree.data.xy.XYDataItem var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var6 = var2.addOrUpdate(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var26.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var33 = var26.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var35 = var34.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     var37.setDomainZeroBaselineVisible(false);
//     var34.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var37);
//     var34.setDefaultEntityRadius((-1));
//     java.awt.Stroke var45 = null;
//     var34.setSeriesStroke(1, var45);
//     java.awt.Shape var48 = var34.lookupLegendShape(100);
//     var26.setDownArrow(var48);
//     var1.setDownArrow(var48);
//     
//     // Checks the contract:  equals-hashcode on var12 and var37
//     assertTrue("Contract failed: equals-hashcode on var12 and var37", var12.equals(var37) ? var12.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var12
//     assertTrue("Contract failed: equals-hashcode on var37 and var12", var37.equals(var12) ? var37.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     java.awt.geom.Point2D var16 = null;
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     org.jfree.chart.renderer.xy.XYItemRendererState var20 = new org.jfree.chart.renderer.xy.XYItemRendererState(var19);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var23 = var22.getTickMarkInsideLength();
//     int var24 = var22.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var26.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var33 = var26.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var35 = var34.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     var37.setDomainZeroBaselineVisible(false);
//     var34.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var37);
//     var34.setDefaultEntityRadius((-1));
//     java.awt.Stroke var45 = null;
//     var34.setSeriesStroke(1, var45);
//     java.awt.Shape var48 = var34.lookupLegendShape(100);
//     var26.setDownArrow(var48);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var50);
//     org.jfree.chart.util.RectangleEdge var52 = var51.getRangeAxisEdge();
//     boolean var53 = var19.equals((java.lang.Object)var51);
//     var1.draw(var12, var15, var16, var17, var19);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 2.88E7d, 0.0d, 2.88E7d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesPaint(0);
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var4 = var3.getRightArrow();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var7 = var6.getTickMarkInsideLength();
//     int var8 = var6.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var10.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var17 = var10.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var21.setDomainZeroBaselineVisible(false);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     var18.setDefaultEntityRadius((-1));
//     java.awt.Stroke var29 = null;
//     var18.setSeriesStroke(1, var29);
//     java.awt.Shape var32 = var18.lookupLegendShape(100);
//     var10.setDownArrow(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
//     var35.setWeight((-123));
//     var35.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var43 = var39.getItemOutlineStroke(0, 0, true);
//     var35.setRangeGridlineStroke(var43);
//     var3.setAxisLineStroke(var43);
//     org.jfree.chart.plot.WaferMapPlot var46 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis3D var48 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var49 = var48.getTickMarkInsideLength();
//     int var50 = var48.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var53 = null;
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var53, 0.0d);
//     var52.setRangeWithMargins(var55);
//     var52.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var59 = var52.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var61 = var60.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var63 = new org.jfree.chart.plot.CombinedRangeXYPlot(var62);
//     org.jfree.chart.plot.DrawingSupplier var64 = var63.getDrawingSupplier();
//     var63.setDomainZeroBaselineVisible(false);
//     var60.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var63);
//     var60.setDefaultEntityRadius((-1));
//     java.awt.Stroke var71 = null;
//     var60.setSeriesStroke(1, var71);
//     java.awt.Shape var74 = var60.lookupLegendShape(100);
//     var52.setDownArrow(var74);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var76 = null;
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var47, (org.jfree.chart.axis.CategoryAxis)var48, (org.jfree.chart.axis.ValueAxis)var52, var76);
//     org.jfree.chart.axis.CategoryAxis3D var78 = new org.jfree.chart.axis.CategoryAxis3D();
//     var78.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var81 = var78.getTickLabelInsets();
//     var77.setAxisOffset(var81);
//     var46.setInsets(var81, false);
//     org.jfree.chart.block.LineBorder var85 = new org.jfree.chart.block.LineBorder(var2, var43, var81);
//     
//     // Checks the contract:  equals-hashcode on var21 and var63
//     assertTrue("Contract failed: equals-hashcode on var21 and var63", var21.equals(var63) ? var21.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var21
//     assertTrue("Contract failed: equals-hashcode on var63 and var21", var63.equals(var21) ? var63.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var64
//     assertTrue("Contract failed: equals-hashcode on var22 and var64", var22.equals(var64) ? var22.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var22
//     assertTrue("Contract failed: equals-hashcode on var64 and var22", var64.equals(var22) ? var64.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var0.calculateHighestVisibleTickValue(var5);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (-123));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getDataArea();
//     java.awt.geom.Point2D var37 = null;
//     var30.panDomainAxes(100.0d, var35, var37);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var40 = var39.getTickMarkInsideLength();
//     boolean var41 = var39.isTickLabelsVisible();
//     int var42 = var30.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var39);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot(var43);
//     org.jfree.chart.axis.AxisLocation var45 = var44.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var46 = org.jfree.chart.axis.AxisLocation.getOpposite(var45);
//     var30.setDomainAxisLocation(var46, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var44
//     assertTrue("Contract failed: equals-hashcode on var16 and var44", var16.equals(var44) ? var16.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var16
//     assertTrue("Contract failed: equals-hashcode on var44 and var16", var44.equals(var16) ? var44.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    var1.handleClick(0, 1, var8);
    org.jfree.chart.plot.Marker var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var13 = var1.removeRangeMarker(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
//     org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
//     java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var9, var13);
//     var1.drawOutline(var2, var9);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 5, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(10, var1);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     var1.setRangePannable(true);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     var1.drawBackground(var8, var11);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.axis.AxisLocation var36 = var35.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var37 = org.jfree.chart.axis.AxisLocation.getOpposite(var36);
//     var30.setRangeAxisLocation(var36);
//     
//     // Checks the contract:  equals-hashcode on var16 and var35
//     assertTrue("Contract failed: equals-hashcode on var16 and var35", var16.equals(var35) ? var16.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var16
//     assertTrue("Contract failed: equals-hashcode on var35 and var16", var35.equals(var16) ? var35.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Paint var2 = var1.getAggregatedItemsPaint();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var9, var13);
    java.awt.Font var15 = null;
    var14.setLabelFont(var15);
    java.awt.Shape var17 = var14.getLine();
    var1.setLegendItemShape(var17);
    org.jfree.chart.JFreeChart var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var22 = new org.jfree.chart.entity.JFreeChartEntity(var17, var19, "hi!", "ChartEntity: tooltip = ");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesPaint(0);
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
//     var8.setRangeWithMargins(var11);
//     boolean var13 = var4.equals((java.lang.Object)var11);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var14 = var4.getLegendItemToolTipGenerator();
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.awt.geom.Rectangle2D var22 = var21.getDataArea();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     java.awt.Paint var26 = var24.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var22, var26);
//     java.awt.Font var28 = null;
//     var27.setLabelFont(var28);
//     java.awt.Shape var30 = var27.getLine();
//     java.awt.Paint var31 = var27.getFillPaint();
//     var4.setSeriesPaint(0, var31);
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var31};
//     java.awt.Paint[] var34 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var39 = var35.getItemOutlineStroke(0, 0, true);
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var42 = var41.getRightArrow();
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var45 = var44.getTickMarkInsideLength();
//     int var46 = var44.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var49 = null;
//     org.jfree.data.Range var51 = org.jfree.data.Range.expandToInclude(var49, 0.0d);
//     var48.setRangeWithMargins(var51);
//     var48.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var55 = var48.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var56 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var57 = var56.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var59 = new org.jfree.chart.plot.CombinedRangeXYPlot(var58);
//     org.jfree.chart.plot.DrawingSupplier var60 = var59.getDrawingSupplier();
//     var59.setDomainZeroBaselineVisible(false);
//     var56.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var59);
//     var56.setDefaultEntityRadius((-1));
//     java.awt.Stroke var67 = null;
//     var56.setSeriesStroke(1, var67);
//     java.awt.Shape var70 = var56.lookupLegendShape(100);
//     var48.setDownArrow(var70);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var43, (org.jfree.chart.axis.CategoryAxis)var44, (org.jfree.chart.axis.ValueAxis)var48, var72);
//     var73.setWeight((-123));
//     var73.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var77 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var81 = var77.getItemOutlineStroke(0, 0, true);
//     var73.setRangeGridlineStroke(var81);
//     var41.setAxisLineStroke(var81);
//     java.awt.Stroke[] var84 = new java.awt.Stroke[] { var81};
//     org.jfree.chart.axis.DateAxis var85 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var86 = var85.getRightArrow();
//     java.awt.Shape[] var87 = new java.awt.Shape[] { var86};
//     org.jfree.chart.plot.DefaultDrawingSupplier var88 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var33, var34, var40, var84, var87);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var4
//     assertTrue("Contract failed: equals-hashcode on var35 and var4", var35.equals(var4) ? var35.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var4
//     assertTrue("Contract failed: equals-hashcode on var77 and var4", var77.equals(var4) ? var77.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var4.", var35.equals(var4) == var4.equals(var35));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var77 and var4.", var77.equals(var4) == var4.equals(var77));
//     
//     // Checks the contract:  equals-hashcode on var24 and var59
//     assertTrue("Contract failed: equals-hashcode on var24 and var59", var24.equals(var59) ? var24.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var24
//     assertTrue("Contract failed: equals-hashcode on var59 and var24", var59.equals(var24) ? var59.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var60
//     assertTrue("Contract failed: equals-hashcode on var25 and var60", var25.equals(var60) ? var25.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var25
//     assertTrue("Contract failed: equals-hashcode on var60 and var25", var60.equals(var25) ? var60.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var5 = var1.getDomainAxis();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var7 = var1.getDomainAxisForDataset(5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    long var2 = var1.getMaximumItemAge();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    var8.setRangeWithMargins(var11);
    var4.setDomainAxis((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.data.time.RegularTimePeriod var14 = var8.getFirst();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(var14, (java.lang.Number)1.0f);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot(var31);
//     org.jfree.chart.plot.DrawingSupplier var33 = var32.getDrawingSupplier();
//     java.awt.Paint var34 = var32.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var37 = null;
//     org.jfree.data.Range var39 = org.jfree.data.Range.expandToInclude(var37, 0.0d);
//     var36.setRangeWithMargins(var39);
//     var32.setDomainAxis((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.getFirst();
//     var30.setDomainCrosshairRowKey((java.lang.Comparable)var42);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    float var1 = var0.getTickMarkInsideLength();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var3.plotChanged(var4);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addDomainMarker((-123), var8, var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var5 = null;
//     var3.setSeriesItemLabelGenerator(100, var5);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     java.awt.Paint var18 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var14, var18);
//     var3.setSeriesItemLabelPaint(1, var18, false);
//     boolean var22 = var3.getAutoPopulateSeriesShape();
//     boolean var23 = var2.equals((java.lang.Object)var3);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var9.setRangeWithMargins(var12);
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.data.time.RegularTimePeriod var15 = var9.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var17 = var3.addOrUpdate(var15, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var3.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, (-1.0f), var4, 0.05d, var6);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.lang.Comparable var33 = null;
    var30.setDomainCrosshairColumnKey(var33);
    var30.setWeight(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
    java.awt.Paint var4 = var1.getDomainTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisLocation var8 = var4.getRangeAxisLocation();
//     var1.setDomainAxisLocation(1, var8);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var1.", var4.equals(var1) == var1.equals(var4));
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var7 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var8 = null;
    java.lang.String var9 = var6.getImageMapAreaTag(var7, var8);
    java.lang.String var10 = var6.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0,0,1,1"+ "'", var10.equals("0,0,1,1"));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getNumberFormat();
    var1.setMinimumFractionDigits(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.util.Iterator var1 = var0.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.JFreeChart var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var6 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape)var2, var3, "SerialDate.weekInMonthToString(): invalid code.", "0,0,1,1");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getDataArea();
//     java.awt.geom.Point2D var37 = null;
//     var30.panDomainAxes(100.0d, var35, var37);
//     java.awt.Stroke var39 = var30.getRangeMinorGridlineStroke();
//     org.jfree.chart.LegendItemCollection var40 = var30.getFixedLegendItems();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.axis.AxisLocation var44 = var43.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var45 = org.jfree.chart.axis.AxisLocation.getOpposite(var44);
//     var30.setDomainAxisLocation(0, var45);
//     
//     // Checks the contract:  equals-hashcode on var16 and var43
//     assertTrue("Contract failed: equals-hashcode on var16 and var43", var16.equals(var43) ? var16.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var16
//     assertTrue("Contract failed: equals-hashcode on var43 and var16", var43.equals(var16) ? var43.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.util.LineUtilities var0 = new org.jfree.chart.util.LineUtilities();

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var5 = var3.getTimePeriod(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     java.awt.Paint var5 = var3.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var6 = var3.getDomainAxisEdge();
//     var0.ensureAtLeast(100.0d, var6);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.entity.EntityCollection var9 = null;
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getChartArea();
//     java.awt.geom.Rectangle2D var12 = var0.shrink(var8, var11);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     java.awt.Paint var4 = var0.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getDataArea();
//     var0.setBaseLegendShape((java.awt.Shape)var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = null;
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     var12.setRangeWithMargins(var15);
//     var12.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var19 = var12.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var21 = var20.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     var23.setDomainZeroBaselineVisible(false);
//     var20.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
//     var20.setDefaultEntityRadius((-1));
//     java.awt.Stroke var31 = null;
//     var20.setSeriesStroke(1, var31);
//     java.awt.Shape var34 = var20.lookupLegendShape(100);
//     var12.setDownArrow(var34);
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
//     var37.setRangeWithMargins(var40);
//     var12.setRangeWithMargins(var40);
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getDataArea();
//     org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var48, "");
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var48, "");
//     var0.drawDomainGridLine(var9, var10, (org.jfree.chart.axis.ValueAxis)var12, var48, 1.0d);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     var0.setDefaultEntityRadius((-1));
//     java.lang.Boolean var11 = var0.getSeriesCreateEntities(100);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var15 = var14.getTickMarkInsideLength();
//     int var16 = var14.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
//     var18.setRangeWithMargins(var21);
//     var18.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var25 = var18.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var27 = var26.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot(var28);
//     org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
//     var29.setDomainZeroBaselineVisible(false);
//     var26.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var29);
//     var26.setDefaultEntityRadius((-1));
//     java.awt.Stroke var37 = null;
//     var26.setSeriesStroke(1, var37);
//     java.awt.Shape var40 = var26.lookupLegendShape(100);
//     var18.setDownArrow(var40);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var42);
//     java.awt.Font var45 = var14.getTickLabelFont((java.lang.Comparable)4.0d);
//     var0.setLegendTextFont(0, var45);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
//     
//     // Checks the contract:  equals-hashcode on var3 and var29
//     assertTrue("Contract failed: equals-hashcode on var3 and var29", var3.equals(var29) ? var3.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var3
//     assertTrue("Contract failed: equals-hashcode on var29 and var3", var29.equals(var3) ? var29.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.util.Date var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMaximumDate(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    java.awt.Paint var6 = var1.getRangeTickBandPaint();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var1.removeRangeMarker(10, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var5 = var4.getRightArrow();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var8 = var7.getTickMarkInsideLength();
//     int var9 = var7.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
//     var11.setRangeWithMargins(var14);
//     var11.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var18 = var11.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var20 = var19.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
//     org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
//     var22.setDomainZeroBaselineVisible(false);
//     var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
//     var19.setDefaultEntityRadius((-1));
//     java.awt.Stroke var30 = null;
//     var19.setSeriesStroke(1, var30);
//     java.awt.Shape var33 = var19.lookupLegendShape(100);
//     var11.setDownArrow(var33);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var35);
//     var36.setWeight((-123));
//     var36.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var44 = var40.getItemOutlineStroke(0, 0, true);
//     var36.setRangeGridlineStroke(var44);
//     var4.setAxisLineStroke(var44);
//     org.jfree.chart.axis.ValueAxis[] var47 = new org.jfree.chart.axis.ValueAxis[] { var4};
//     var1.setDomainAxes(var47);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.data.general.DatasetGroup var2 = var1.getDatasetGroup();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getDataArea();
//     var4.handleClick(0, 1, var11);
//     java.awt.Paint var14 = var4.getRangeZeroBaselinePaint();
//     var1.remove((org.jfree.chart.plot.XYPlot)var4);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    java.awt.Stroke var39 = var30.getRangeMinorGridlineStroke();
    org.jfree.chart.LegendItemCollection var40 = var30.getFixedLegendItems();
    java.awt.Stroke var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setRangeMinorGridlineStroke(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var1.setMinorTickMarkInsideLength(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    boolean var19 = var0.getAutoPopulateSeriesShape();
    java.awt.Font var21 = var0.getLegendTextFont(0);
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var28 = null;
    org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 0.0d);
    var27.setRangeWithMargins(var30);
    boolean var32 = var23.equals((java.lang.Object)var30);
    org.jfree.chart.labels.XYSeriesLabelGenerator var33 = var23.getLegendItemToolTipGenerator();
    org.jfree.chart.ChartRenderingInfo var39 = null;
    org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
    java.awt.geom.Rectangle2D var41 = var40.getDataArea();
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
    org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
    java.awt.Paint var45 = var43.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var41, var45);
    java.awt.Font var47 = null;
    var46.setLabelFont(var47);
    java.awt.Shape var49 = var46.getLine();
    java.awt.Paint var50 = var46.getFillPaint();
    var23.setSeriesPaint(0, var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-123), var50, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

//  public void test191() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var35 = var32.getTickLabelInsets();
//     var31.setAxisOffset(var35);
//     var31.setRangePannable(false);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var31.setFixedDomainAxisSpace(var39, false);
//     boolean var42 = var0.equals((java.lang.Object)false);
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var44.configure();
//     org.jfree.chart.axis.NumberTickUnit var46 = var44.getTickUnit();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.plot.MultiplePiePlot var48 = new org.jfree.chart.plot.MultiplePiePlot(var47);
//     java.awt.Paint var49 = var48.getAggregatedItemsPaint();
//     int var50 = var46.compareTo((java.lang.Object)var48);
//     org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
//     var51.setLowerMargin((-1.0d));
//     var51.setAxisLineVisible(false);
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     java.awt.geom.Rectangle2D var62 = var61.getDataArea();
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var64 = new org.jfree.chart.plot.CombinedRangeXYPlot(var63);
//     org.jfree.chart.plot.DrawingSupplier var65 = var64.getDrawingSupplier();
//     java.awt.Paint var66 = var64.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var62, var66);
//     java.awt.Font var68 = null;
//     var67.setLabelFont(var68);
//     java.awt.Shape var70 = var67.getLine();
//     java.awt.Paint var71 = var67.getFillPaint();
//     var51.setAxisLinePaint(var71);
//     var0.setTickLabelPaint((java.lang.Comparable)var50, var71);
//     
//     // Checks the contract:  equals-hashcode on var17 and var64
//     assertTrue("Contract failed: equals-hashcode on var17 and var64", var17.equals(var64) ? var17.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var17
//     assertTrue("Contract failed: equals-hashcode on var64 and var17", var64.equals(var17) ? var64.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var65
//     assertTrue("Contract failed: equals-hashcode on var18 and var65", var18.equals(var65) ? var18.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var18
//     assertTrue("Contract failed: equals-hashcode on var65 and var18", var65.equals(var18) ? var65.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SerialDate.weekInMonthToString(): invalid code.", "ThreadContext", var3);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.awt.geom.Rectangle2D var15 = var14.getDataArea();
//     org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var15, "");
//     org.jfree.chart.util.RectangleAnchor var18 = null;
//     java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var18);
//     var1.zoomRangeAxes(100.0d, 4.0d, var12, var19);
//     
//     // Checks the contract:  equals-hashcode on var12 and var14
//     assertTrue("Contract failed: equals-hashcode on var12 and var14", var12.equals(var14) ? var12.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var12
//     assertTrue("Contract failed: equals-hashcode on var14 and var12", var14.equals(var12) ? var14.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getDataArea();
//     org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var36, "");
//     org.jfree.chart.entity.ChartEntity var40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var36, "");
//     org.jfree.chart.plot.CrosshairState var42 = new org.jfree.chart.plot.CrosshairState(false);
//     var42.setDatasetIndex(100);
//     org.jfree.chart.ChartRenderingInfo var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
//     java.awt.geom.Rectangle2D var47 = var46.getDataArea();
//     org.jfree.chart.entity.ChartEntity var49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var47, "");
//     org.jfree.chart.util.RectangleAnchor var50 = null;
//     java.awt.geom.Point2D var51 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var50);
//     var42.setAnchor(var51);
//     org.jfree.chart.plot.PlotState var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     var30.draw(var33, var36, var51, var53, var54);
//     
//     // Checks the contract:  equals-hashcode on var35 and var46
//     assertTrue("Contract failed: equals-hashcode on var35 and var46", var35.equals(var46) ? var35.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var35
//     assertTrue("Contract failed: equals-hashcode on var46 and var35", var46.equals(var35) ? var46.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(2.88E7d, 1.0d, 0.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("SerialDate.weekInMonthToString(): invalid code.", "0,0,1,1", "ThreadContext", "0,0,1,1", "0,0,1,1");

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var38 = var34.getItemOutlineStroke(0, 0, true);
    var30.setRangeGridlineStroke(var38);
    org.jfree.chart.axis.ValueAxis var41 = var30.getRangeAxisForDataset(10);
    org.jfree.chart.plot.CombinedRangeXYPlot var42 = new org.jfree.chart.plot.CombinedRangeXYPlot(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    var1.configureRangeAxes();
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeCrosshairStroke(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
//     java.lang.Object var4 = null;
//     boolean var5 = var3.equals(var4);
//     org.jfree.data.xy.XYDataset var6 = null;
//     java.lang.String var9 = var3.generateToolTip(var6, 100, (-1));
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
//     java.awt.Shape var4 = var0.getBaseShape();
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesPositiveItemLabelPosition(0);
//     var0.setSeriesPositiveItemLabelPosition(100, var8, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getPercentFormat();
    org.jfree.data.general.PieDataset var2 = null;
    java.lang.String var4 = var0.generateToolTip(var2, (java.lang.Comparable)(-2208959999990L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
//     java.awt.Paint var3 = var1.getDomainCrosshairPaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var12.setPlot((org.jfree.chart.plot.XYPlot)var16);
//     var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     var1.remove((org.jfree.chart.plot.XYPlot)var16);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var1.configure();
//     org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot(var4);
//     java.awt.Paint var6 = var5.getAggregatedItemsPaint();
//     int var7 = var3.compareTo((java.lang.Object)var5);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var11 = null;
//     var9.setSeriesItemLabelGenerator(100, var11);
//     java.awt.Paint var13 = var9.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getDataArea();
//     var9.setBaseLegendShape((java.awt.Shape)var16);
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getDataArea();
//     org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var20, "");
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var23);
//     org.jfree.chart.plot.PlotState var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     var5.draw(var8, var16, var24, var25, var26);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.plot.CategoryMarker var33 = null;
    org.jfree.chart.util.Layer var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.addDomainMarker(var33, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(-1L));
    boolean var5 = var2.getAllowDuplicateXValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     java.awt.Font var32 = var1.getTickLabelFont((java.lang.Comparable)4.0d);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = var39.getDataArea();
//     org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var40, "");
//     org.jfree.chart.util.RectangleAnchor var43 = null;
//     java.awt.geom.Point2D var44 = org.jfree.chart.util.RectangleAnchor.coordinates(var40, var43);
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.entity.PieSectionEntity var51 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var40, var45, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var53 = new org.jfree.chart.plot.CombinedRangeXYPlot(var52);
//     org.jfree.chart.plot.DrawingSupplier var54 = var53.getDrawingSupplier();
//     java.awt.Paint var55 = var53.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var56 = var53.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var57 = org.jfree.chart.util.RectangleEdge.opposite(var56);
//     boolean var59 = var56.equals((java.lang.Object)true);
//     org.jfree.chart.util.RectangleEdge var60 = org.jfree.chart.util.RectangleEdge.opposite(var56);
//     double var61 = var1.getCategorySeriesMiddle(0, (-123), 2147483647, 0, (-2.0d), var40, var60);
//     
//     // Checks the contract:  equals-hashcode on var16 and var53
//     assertTrue("Contract failed: equals-hashcode on var16 and var53", var16.equals(var53) ? var16.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var16
//     assertTrue("Contract failed: equals-hashcode on var53 and var16", var53.equals(var16) ? var53.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var54
//     assertTrue("Contract failed: equals-hashcode on var17 and var54", var17.equals(var54) ? var17.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var17
//     assertTrue("Contract failed: equals-hashcode on var54 and var17", var54.equals(var17) ? var54.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    float var8 = var7.getTickMarkInsideLength();
    int var9 = var7.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
    var11.setRangeWithMargins(var14);
    var11.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var18 = var11.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var20 = var19.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
    org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
    var22.setDomainZeroBaselineVisible(false);
    var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
    var19.setDefaultEntityRadius((-1));
    java.awt.Stroke var30 = null;
    var19.setSeriesStroke(1, var30);
    java.awt.Shape var33 = var19.lookupLegendShape(100);
    var11.setDownArrow(var33);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var35);
    var36.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var40 = null;
    org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
    java.awt.geom.Rectangle2D var42 = var41.getDataArea();
    java.awt.geom.Point2D var43 = null;
    var36.panDomainAxes(100.0d, var41, var43);
    java.awt.Stroke var45 = var36.getRangeMinorGridlineStroke();
    org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var48 = var47.getPaint();
    org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var51 = var49.lookupSeriesOutlineStroke(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(4.0d, (-2.0d), var5, var45, var48, var51, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
    var2.setGroupingUsed(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.axis.AxisLocation var5 = var1.getRangeAxisLocation();
    org.jfree.data.xy.XYDataset var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataset((-1), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var5 = null;
//     var1.markerChanged(var5);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     var12.setRangeWithMargins(var15);
//     var8.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     var8.setDomainAxis((org.jfree.chart.axis.ValueAxis)var19);
//     java.awt.Stroke var21 = var19.getMinorTickMarkStroke();
//     var1.setRangeGridlineStroke(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
    var1.setPosition(var7);
    org.jfree.chart.util.RectangleInsets var10 = var1.getPadding();
    org.jfree.chart.event.TitleChangeEvent var11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.block.BlockFrame var12 = var1.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    var1.setRangePannable(true);
    org.jfree.chart.plot.Plot var8 = var1.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-1));
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
    org.jfree.chart.labels.XYItemLabelGenerator var24 = var0.getItemLabelGenerator(0, 0, true);
    java.awt.Stroke var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlineStroke(var25, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var2 = var1.getPaint();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
//     java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
//     var1.setPosition(var7);
//     org.jfree.chart.util.RectangleInsets var10 = var1.getPadding();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var13 = var12.getPaint();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var18 = var15.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     var12.setPosition(var18);
//     org.jfree.chart.util.RectangleInsets var21 = var12.getPadding();
//     double var23 = var21.trimWidth(0.0d);
//     var1.setMargin(var21);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
    var0.setDrawBarOutline(true);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.data.Range var24 = var0.findDomainBounds(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     var1.addRangeMarker(0, var9, var10, false);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.data.general.DatasetGroup var2 = var1.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var4 = var3.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.plot.DrawingSupplier var7 = var6.getDrawingSupplier();
//     var6.setDomainZeroBaselineVisible(false);
//     var3.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     var3.setDefaultEntityRadius((-1));
//     java.awt.Stroke var14 = null;
//     var3.setSeriesStroke(1, var14);
//     int var16 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)86400000L, (-1.0d), 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.axis.AxisLocation var13 = var12.getDomainAxisLocation();
//     java.awt.Paint var14 = var12.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var14);
//     org.jfree.chart.util.Layer var16 = null;
//     var1.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var15, var16, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var2 = var0.lookupSeriesOutlineStroke(4);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.data.Range var4 = var0.findDomainBounds(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.util.StrokeMap var0 = new org.jfree.chart.util.StrokeMap();
    java.awt.Stroke var2 = var0.getStroke((java.lang.Comparable)'a');
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.util.Rotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    var11.setDatasetIndex(10);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.plot.MultiplePiePlot var15 = new org.jfree.chart.plot.MultiplePiePlot(var14);
    java.awt.Paint var16 = var15.getAggregatedItemsPaint();
    var11.setLinePaint(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTextAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.05d, (-1.0d), var2);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.axis.DateTickMarkPosition var5 = var0.getTickMarkPosition();
//     int var6 = var0.getMinorTickCount();
//     java.util.Date var7 = null;
//     java.util.Date var8 = null;
//     var0.setRange(var7, var8);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     java.awt.Font var33 = var2.getTickLabelFont((java.lang.Comparable)4.0d);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var36 = var35.getTickMarkInsideLength();
//     int var37 = var35.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var40 = null;
//     org.jfree.data.Range var42 = org.jfree.data.Range.expandToInclude(var40, 0.0d);
//     var39.setRangeWithMargins(var42);
//     var39.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var46 = var39.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var48 = var47.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot(var49);
//     org.jfree.chart.plot.DrawingSupplier var51 = var50.getDrawingSupplier();
//     var50.setDomainZeroBaselineVisible(false);
//     var47.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var50);
//     var47.setDefaultEntityRadius((-1));
//     java.awt.Stroke var58 = null;
//     var47.setSeriesStroke(1, var58);
//     java.awt.Shape var61 = var47.lookupLegendShape(100);
//     var39.setDownArrow(var61);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var34, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var63);
//     org.jfree.chart.event.AxisChangeEvent var65 = null;
//     var64.axisChanged(var65);
//     var64.clearDomainMarkers();
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", var33, (org.jfree.chart.plot.Plot)var64, false);
//     
//     // Checks the contract:  equals-hashcode on var17 and var50
//     assertTrue("Contract failed: equals-hashcode on var17 and var50", var17.equals(var50) ? var17.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var17
//     assertTrue("Contract failed: equals-hashcode on var50 and var17", var50.equals(var17) ? var50.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var51
//     assertTrue("Contract failed: equals-hashcode on var18 and var51", var18.equals(var51) ? var18.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var18
//     assertTrue("Contract failed: equals-hashcode on var51 and var18", var51.equals(var18) ? var51.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var64
//     assertTrue("Contract failed: equals-hashcode on var31 and var64", var31.equals(var64) ? var31.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var31
//     assertTrue("Contract failed: equals-hashcode on var64 and var31", var64.equals(var31) ? var64.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    org.jfree.chart.util.StandardGradientPaintTransformer var15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    org.jfree.data.xy.XYDataItem var6 = var2.addOrUpdate(var5);
    var2.add(0.05d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     java.awt.Stroke var14 = var12.getMinorTickMarkStroke();
//     var12.resizeRange((-1.0d));
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
//     java.awt.Paint var27 = var25.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var23, var27);
//     java.awt.Font var29 = null;
//     var28.setLabelFont(var29);
//     java.awt.Shape var31 = var28.getLine();
//     java.awt.Paint var32 = var28.getFillPaint();
//     java.awt.Stroke var33 = var28.getLineStroke();
//     var12.setMinorTickMarkStroke(var33);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.renderer.PaintScale var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
//     org.jfree.chart.plot.DrawingSupplier var3 = var2.getDrawingSupplier();
//     java.awt.Paint var4 = var2.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var2.setDomainAxis((org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
//     var2.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
//     java.awt.Stroke var15 = var13.getMinorTickMarkStroke();
//     org.jfree.chart.title.PaintScaleLegend var16 = new org.jfree.chart.title.PaintScaleLegend(var0, (org.jfree.chart.axis.ValueAxis)var13);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     var30.clearDomainAxes();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.axis.AxisLocation var38 = var37.getDomainAxisLocation();
//     java.awt.Paint var39 = var37.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var40 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var39);
//     var30.setRangeMinorGridlinePaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var16 and var37
//     assertTrue("Contract failed: equals-hashcode on var16 and var37", var16.equals(var37) ? var16.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var16
//     assertTrue("Contract failed: equals-hashcode on var37 and var16", var37.equals(var16) ? var37.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    var4.setDomainZeroBaselineVisible(false);
    var0.setPlot((org.jfree.chart.plot.XYPlot)var4);
    org.jfree.chart.plot.Marker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
//     org.jfree.data.xy.XYDataItem var6 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
//     org.jfree.data.xy.XYDataItem var7 = var3.addOrUpdate(var6);
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)var6);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(0);
    org.jfree.chart.labels.XYSeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    java.awt.Shape var5 = var0.lookupLegendShape(1);
    org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesPositiveItemLabelPosition(0);
    var0.setBaseNegativeItemLabelPosition(var8, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    int var2 = var1.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var4 = var1.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var1 = var0.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.event.PlotChangeEvent var4 = null;
//     var3.plotChanged(var4);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     java.lang.String var7 = var0.getLabelToolTip();
//     boolean var8 = var0.isVisible();
//     org.jfree.chart.axis.CategoryAnchor var9 = null;
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
//     var25.setDomainZeroBaselineVisible(false);
//     java.lang.Object var29 = var25.clone();
//     java.awt.Paint var30 = var25.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleEdge var32 = var25.getDomainAxisEdge(5);
//     double var33 = var0.getCategoryJava2DCoordinate(var9, 0, 1, var18, var32);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(0);
    org.jfree.chart.labels.XYSeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    java.awt.Font var17 = null;
    var16.setLabelFont(var17);
    java.awt.Shape var19 = var16.getLine();
    java.awt.Paint var20 = var16.getFillPaint();
    java.awt.Stroke var21 = var16.getLineStroke();
    var0.setSeriesStroke(1, var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     java.awt.Stroke var14 = var12.getMinorTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
//     var16.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var19 = var16.getTickLabelInsets();
//     double var21 = var19.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24, "");
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24, "");
//     org.jfree.chart.util.LengthAdjustmentType var29 = null;
//     org.jfree.chart.util.LengthAdjustmentType var30 = null;
//     java.awt.geom.Rectangle2D var31 = var19.createAdjustedRectangle(var24, var29, var30);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
//     java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var36 = var33.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var37 = org.jfree.chart.util.RectangleEdge.opposite(var36);
//     double var38 = var12.valueToJava2D(2.88E7d, var31, var36);
//     
//     // Checks the contract:  equals-hashcode on var2 and var34
//     assertTrue("Contract failed: equals-hashcode on var2 and var34", var2.equals(var34) ? var2.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var2
//     assertTrue("Contract failed: equals-hashcode on var34 and var2", var34.equals(var2) ? var34.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    double var2 = var1.getDomainCrosshairValue();
    boolean var3 = var1.isSubplot();
    var1.setNoDataMessage("");
    java.lang.String var6 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Combined Range XYPlot"+ "'", var6.equals("Combined Range XYPlot"));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    java.text.NumberFormat var1 = var0.getPercentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     var30.handleClick(100, 4, var35);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var0.setSeriesItemLabelPaint(1, var15, false);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     org.jfree.chart.renderer.xy.XYItemRendererState var22 = new org.jfree.chart.renderer.xy.XYItemRendererState(var21);
//     int var23 = var22.getFirstItemIndex();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     java.awt.Paint var28 = var26.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var29 = var26.getDomainAxisEdge();
//     var26.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
//     java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
//     var37.setRangeWithMargins(var40);
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var44);
//     java.awt.Stroke var46 = var44.getMinorTickMarkStroke();
//     var44.resizeRange((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     org.jfree.data.xy.XYDataset var51 = null;
//     var0.drawItem(var19, var22, var24, (org.jfree.chart.plot.XYPlot)var26, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.axis.ValueAxis)var50, var51, 4, 0, false, (-1));
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.05d, 0.05d, 0.05d, 2.88E7d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
//     var31.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
//     var30.setAxisOffset(var34);
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot(var43);
//     org.jfree.chart.plot.DrawingSupplier var45 = var44.getDrawingSupplier();
//     java.awt.Paint var46 = var44.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var42, var46);
//     java.awt.geom.Rectangle2D var48 = var34.createOutsetRectangle(var42);
//     
//     // Checks the contract:  equals-hashcode on var16 and var44
//     assertTrue("Contract failed: equals-hashcode on var16 and var44", var16.equals(var44) ? var16.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var16
//     assertTrue("Contract failed: equals-hashcode on var44 and var16", var44.equals(var16) ? var44.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var45
//     assertTrue("Contract failed: equals-hashcode on var17 and var45", var17.equals(var45) ? var17.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var17
//     assertTrue("Contract failed: equals-hashcode on var45 and var17", var45.equals(var17) ? var45.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-123), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot(var13);
    java.awt.Paint var15 = var14.getAggregatedItemsPaint();
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getDataArea();
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
    org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
    java.awt.Paint var26 = var24.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var22, var26);
    java.awt.Font var28 = null;
    var27.setLabelFont(var28);
    java.awt.Shape var30 = var27.getLine();
    var14.setLegendItemShape(var30);
    var0.setLegendShape(0, var30);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
    org.jfree.data.general.DatasetGroup var35 = var34.getDatasetGroup();
    var34.setRangeCrosshairVisible(true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var30, (org.jfree.chart.plot.Plot)var34);
    java.lang.String var39 = var38.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "PlotEntity: tooltip = null"+ "'", var39.equals("PlotEntity: tooltip = null"));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
    var1.setPosition(var7);
    org.jfree.chart.util.RectangleInsets var10 = var1.getPadding();
    java.lang.String var11 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    int var5 = var2.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var7 = var2.remove(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    java.lang.Comparable var15 = var11.getSeriesKey();
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setLinePaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("index.html?series=10&amp;item=-1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var1.setRangeWithMargins(var29);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
//     java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
//     var37.setRangeWithMargins(var40);
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.data.time.RegularTimePeriod var46 = var44.getLast();
//     var1.setFirst(var46);
//     
//     // Checks the contract:  equals-hashcode on var13 and var34
//     assertTrue("Contract failed: equals-hashcode on var13 and var34", var13.equals(var34) ? var13.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var13
//     assertTrue("Contract failed: equals-hashcode on var34 and var13", var34.equals(var13) ? var34.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
    java.awt.Paint var3 = var1.getDomainCrosshairPaint();
    var1.clearRangeMarkers(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(2.88E7d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     double var2 = var1.getDomainCrosshairValue();
//     boolean var3 = var1.isSubplot();
//     org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
//     var1.setForegroundAlpha(1.0f);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var10 = var9.getPaint();
//     var1.setNoDataMessagePaint(var10);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
//     org.jfree.chart.axis.AxisLocation var15 = var14.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var16 = org.jfree.chart.axis.AxisLocation.getOpposite(var15);
//     var1.setDomainAxisLocation(4, var15, true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var1.", var14.equals(var1) == var1.equals(var14));
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisSpace var2 = null;
    var1.setFixedRangeAxisSpace(var2);
    org.jfree.chart.LegendItemCollection var4 = new org.jfree.chart.LegendItemCollection();
    var1.setFixedLegendItems(var4);
    var1.setDomainMinorGridlinesVisible(true);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var10 = var9.getRightArrow();
    var9.zoomRange((-1.0d), 1.0d);
    double var14 = var9.getLowerMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAxis(2147483647, (org.jfree.chart.axis.ValueAxis)var9);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    java.awt.Stroke var39 = var30.getRangeMinorGridlineStroke();
    org.jfree.chart.LegendItemCollection var40 = var30.getFixedLegendItems();
    org.jfree.chart.util.SortOrder var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setColumnRenderingOrder(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentSize();
//     int var2 = var0.getSegmentsIncluded();
//     var0.addBaseTimelineExclusions(0L, (-2208960000000L));
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var3.addOrUpdate(var15, 10.0d);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     java.awt.Paint var21 = var19.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var23.setRangeWithMargins(var26);
//     var19.setDomainAxis((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.data.time.RegularTimePeriod var29 = var23.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var3.addOrUpdate(var29, 2.88E7d);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.lang.Object var3 = var1.clone();
//     java.awt.Paint var4 = var1.getDomainTickBandPaint();
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.event.PlotChangeEvent var7 = null;
//     var6.plotChanged(var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
//     var6.setRangeGridlinePaint(var12);
//     org.jfree.chart.plot.SeriesRenderingOrder var14 = var6.getSeriesRenderingOrder();
//     var1.setSeriesRenderingOrder(var14);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    boolean var19 = var0.getAutoPopulateSeriesShape();
    java.awt.Font var21 = var0.lookupLegendTextFont(5);
    org.jfree.chart.labels.ItemLabelPosition var25 = var0.getNegativeItemLabelPosition(0, 2147483647, false);
    org.jfree.chart.renderer.xy.XYBarPainter var26 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(var26);
    var0.setBarPainter(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.util.RectangleEdge var31 = var30.getRangeAxisEdge();
    int var32 = var30.getDatasetCount();
    var30.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
//     var31.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
//     var30.setAxisOffset(var34);
//     var30.setRangePannable(false);
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getDataArea();
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot(var45);
//     org.jfree.chart.plot.DrawingSupplier var47 = var46.getDrawingSupplier();
//     java.awt.Paint var48 = var46.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var44, var48);
//     java.awt.Font var50 = null;
//     var49.setLabelFont(var50);
//     java.awt.Shape var52 = var49.getLine();
//     java.awt.Paint var53 = var49.getFillPaint();
//     var30.setRangeZeroBaselinePaint(var53);
//     
//     // Checks the contract:  equals-hashcode on var16 and var46
//     assertTrue("Contract failed: equals-hashcode on var16 and var46", var16.equals(var46) ? var16.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var16
//     assertTrue("Contract failed: equals-hashcode on var46 and var16", var46.equals(var16) ? var46.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var47
//     assertTrue("Contract failed: equals-hashcode on var17 and var47", var17.equals(var47) ? var17.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var17
//     assertTrue("Contract failed: equals-hashcode on var47 and var17", var47.equals(var17) ? var47.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    boolean var14 = var0.getAutoPopulateSeriesPaint();
    java.awt.Paint var16 = var0.getLegendTextPaint((-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getDataArea();
//     java.awt.geom.Point2D var37 = null;
//     var30.panDomainAxes(100.0d, var35, var37);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var40 = var39.getTickMarkInsideLength();
//     boolean var41 = var39.isTickLabelsVisible();
//     int var42 = var30.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var39);
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var46 = var45.getTickMarkInsideLength();
//     int var47 = var45.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var49 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var50 = null;
//     org.jfree.data.Range var52 = org.jfree.data.Range.expandToInclude(var50, 0.0d);
//     var49.setRangeWithMargins(var52);
//     var49.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var56 = var49.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var58 = var57.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var60 = new org.jfree.chart.plot.CombinedRangeXYPlot(var59);
//     org.jfree.chart.plot.DrawingSupplier var61 = var60.getDrawingSupplier();
//     var60.setDomainZeroBaselineVisible(false);
//     var57.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var60);
//     var57.setDefaultEntityRadius((-1));
//     java.awt.Stroke var68 = null;
//     var57.setSeriesStroke(1, var68);
//     java.awt.Shape var71 = var57.lookupLegendShape(100);
//     var49.setDownArrow(var71);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var73 = null;
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var44, (org.jfree.chart.axis.CategoryAxis)var45, (org.jfree.chart.axis.ValueAxis)var49, var73);
//     java.awt.Font var76 = var45.getTickLabelFont((java.lang.Comparable)4.0d);
//     var39.setTickLabelFont((java.lang.Comparable)(short)10, var76);
//     
//     // Checks the contract:  equals-hashcode on var16 and var60
//     assertTrue("Contract failed: equals-hashcode on var16 and var60", var16.equals(var60) ? var16.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var16
//     assertTrue("Contract failed: equals-hashcode on var60 and var16", var60.equals(var16) ? var60.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var61
//     assertTrue("Contract failed: equals-hashcode on var17 and var61", var17.equals(var61) ? var17.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var17
//     assertTrue("Contract failed: equals-hashcode on var61 and var17", var61.equals(var17) ? var61.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.xy.XYItemRendererState var2 = new org.jfree.chart.renderer.xy.XYItemRendererState(var1);
    int var3 = var2.getFirstItemIndex();
    int var4 = var2.getLastItemIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var14};
//     var1.setRenderers(var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", "hi!", "");
    java.lang.String var6 = var5.getCopyright();
    var5.setVersion("PlotEntity: tooltip = null");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var30.axisChanged(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var30.setRenderer(var33);
//     boolean var35 = var30.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var38 = new org.jfree.chart.plot.CombinedRangeXYPlot(var37);
//     org.jfree.chart.plot.DrawingSupplier var39 = var38.getDrawingSupplier();
//     java.awt.Paint var40 = var38.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var42 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var43 = null;
//     org.jfree.data.Range var45 = org.jfree.data.Range.expandToInclude(var43, 0.0d);
//     var42.setRangeWithMargins(var45);
//     var38.setDomainAxis((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.axis.PeriodAxis var49 = new org.jfree.chart.axis.PeriodAxis("");
//     var38.setDomainAxis((org.jfree.chart.axis.ValueAxis)var49);
//     java.awt.Stroke var51 = var49.getMinorTickMarkStroke();
//     var30.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var49, false);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"", 14.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.lang.Object var3 = var1.clone();
    var1.setBackgroundAlpha(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var7 = var1.getQuadrantPaint((-123));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var3 = var1.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var4 = var1.getLegendItemURLGenerator();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var7 = var6.getTickMarkInsideLength();
//     int var8 = var6.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var10.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var17 = var10.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var21.setDomainZeroBaselineVisible(false);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     var18.setDefaultEntityRadius((-1));
//     java.awt.Stroke var29 = null;
//     var18.setSeriesStroke(1, var29);
//     java.awt.Shape var32 = var18.lookupLegendShape(100);
//     var10.setDownArrow(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
//     java.awt.Font var37 = var6.getTickLabelFont((java.lang.Comparable)4.0d);
//     var1.setBaseLegendTextFont(var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
//     org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
//     java.awt.Paint var42 = var40.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var43 = var40.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getDataArea();
//     var40.handleClick(0, 1, var47);
//     java.awt.Paint var50 = var40.getRangeZeroBaselinePaint();
//     org.jfree.chart.text.TextLine var51 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", var37, var50);
//     
//     // Checks the contract:  equals-hashcode on var21 and var40
//     assertTrue("Contract failed: equals-hashcode on var21 and var40", var21.equals(var40) ? var21.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var21
//     assertTrue("Contract failed: equals-hashcode on var40 and var21", var40.equals(var21) ? var40.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var41
//     assertTrue("Contract failed: equals-hashcode on var22 and var41", var22.equals(var41) ? var22.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var22
//     assertTrue("Contract failed: equals-hashcode on var41 and var22", var41.equals(var22) ? var41.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Combined Range XYPlot", var1);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var3 = var1.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    boolean var19 = var0.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    var30.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    org.jfree.chart.plot.CategoryMarker var36 = null;
    org.jfree.chart.util.Layer var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.addDomainMarker(var36, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot(var4);
    java.awt.Paint var6 = var5.getAggregatedItemsPaint();
    int var7 = var3.compareTo((java.lang.Object)var5);
    java.lang.String var9 = var3.valueToString(100.0d);
    java.lang.String var11 = var3.valueToString(14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "100"+ "'", var9.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "14"+ "'", var11.equals("14"));

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var3 = var2.getRightArrow();
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var6 = var5.getTickMarkInsideLength();
//     int var7 = var5.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var9.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var16 = var9.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var18 = var17.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     var20.setDomainZeroBaselineVisible(false);
//     var17.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     var17.setDefaultEntityRadius((-1));
//     java.awt.Stroke var28 = null;
//     var17.setSeriesStroke(1, var28);
//     java.awt.Shape var31 = var17.lookupLegendShape(100);
//     var9.setDownArrow(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var33);
//     var34.setWeight((-123));
//     var34.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var42 = var38.getItemOutlineStroke(0, 0, true);
//     var34.setRangeGridlineStroke(var42);
//     var2.setAxisLineStroke(var42);
//     java.awt.Stroke[] var45 = new java.awt.Stroke[] { var42};
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var47 = new org.jfree.chart.plot.CombinedRangeXYPlot(var46);
//     org.jfree.chart.plot.DrawingSupplier var48 = var47.getDrawingSupplier();
//     java.awt.Paint var49 = var47.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var52 = null;
//     org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 0.0d);
//     var51.setRangeWithMargins(var54);
//     var47.setDomainAxis((org.jfree.chart.axis.ValueAxis)var51);
//     org.jfree.chart.axis.PeriodAxis var58 = new org.jfree.chart.axis.PeriodAxis("");
//     var47.setDomainAxis((org.jfree.chart.axis.ValueAxis)var58);
//     java.awt.Stroke var60 = var58.getMinorTickMarkStroke();
//     java.awt.Stroke[] var61 = new java.awt.Stroke[] { var60};
//     java.awt.Shape[] var62 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var63 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var45, var61, var62);
//     
//     // Checks the contract:  equals-hashcode on var21 and var48
//     assertTrue("Contract failed: equals-hashcode on var21 and var48", var21.equals(var48) ? var21.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var21
//     assertTrue("Contract failed: equals-hashcode on var48 and var21", var48.equals(var21) ? var48.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(100, var1);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    var1.handleClick(0, 1, var8);
    int var11 = var8.getSubplotCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var13 = var8.getSubplotInfo((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.updateCrosshairY(0.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    var30.setCrosshairDatasetIndex(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     java.awt.Stroke var14 = var12.getMinorTickMarkStroke();
//     org.jfree.data.Range var15 = var12.getDefaultAutoRange();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var20 = var19.getTickMarkInsideLength();
//     int var21 = var19.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var23.setRangeWithMargins(var26);
//     var23.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var30 = var23.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var32 = var31.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     var34.setDomainZeroBaselineVisible(false);
//     var31.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var34);
//     var31.setDefaultEntityRadius((-1));
//     java.awt.Stroke var42 = null;
//     var31.setSeriesStroke(1, var42);
//     java.awt.Shape var45 = var31.lookupLegendShape(100);
//     var23.setDownArrow(var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var47);
//     org.jfree.chart.util.RectangleEdge var49 = var48.getRangeAxisEdge();
//     double var50 = var12.valueToJava2D(0.0d, var17, var49);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     var1.clearDomainMarkers((-123));
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.axis.AxisLocation var14 = var13.getDomainAxisLocation();
//     java.awt.Paint var15 = var13.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var15);
//     java.awt.Paint var17 = var16.getPaint();
//     boolean var18 = var1.removeRangeMarker((org.jfree.chart.plot.Marker)var16);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
//     java.awt.Font var12 = null;
//     var11.setLabelFont(var12);
//     java.awt.Shape var14 = var11.getLine();
//     java.awt.Paint var15 = var11.getFillPaint();
//     java.lang.String var16 = var11.getURLText();
//     java.lang.Comparable var17 = var11.getSeriesKey();
//     java.awt.Paint var18 = var11.getLabelPaint();
//     java.awt.Paint var19 = var11.getFillPaint();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     java.awt.Paint var30 = var28.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var26, var30);
//     java.awt.Font var32 = null;
//     var31.setLabelFont(var32);
//     java.awt.Shape var34 = var31.getLine();
//     var11.setShape(var34);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var29
//     assertTrue("Contract failed: equals-hashcode on var9 and var29", var9.equals(var29) ? var9.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var9
//     assertTrue("Contract failed: equals-hashcode on var29 and var9", var29.equals(var9) ? var29.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     var3.clear();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(0.0d, var7);
//     org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedWidth(1.0d);
//     org.jfree.data.Range var13 = var12.getHeightRange();
//     org.jfree.chart.util.Size2D var14 = var3.arrange(var5, var12);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
    float var3 = var2.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SerialDate.weekInMonthToString(): invalid code.", "ThreadContext", var3);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     var0.setDefaultEntityRadius((-1));
//     org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
//     double var11 = var0.getShadowXOffset();
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot();
//     var12.setIgnoreZeroValues(false);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.CrosshairState var17 = new org.jfree.chart.plot.CrosshairState(false);
//     var17.updateCrosshairY(0.05d, 10);
//     boolean var21 = var15.equals((java.lang.Object)0.05d);
//     var12.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     var12.setShadowYOffset(1.0d);
//     org.jfree.data.xy.XYSeries var27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getDataArea();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var36 = new org.jfree.chart.plot.CombinedRangeXYPlot(var35);
//     org.jfree.chart.plot.DrawingSupplier var37 = var36.getDrawingSupplier();
//     java.awt.Paint var38 = var36.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var34, var38);
//     java.awt.Font var40 = null;
//     var39.setLabelFont(var40);
//     boolean var42 = var27.equals((java.lang.Object)var39);
//     java.awt.Paint var43 = var39.getOutlinePaint();
//     var12.setShadowPaint(var43);
//     var0.setBaseOutlinePaint(var43);
//     
//     // Checks the contract:  equals-hashcode on var3 and var36
//     assertTrue("Contract failed: equals-hashcode on var3 and var36", var3.equals(var36) ? var3.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var3
//     assertTrue("Contract failed: equals-hashcode on var36 and var3", var36.equals(var3) ? var36.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var37
//     assertTrue("Contract failed: equals-hashcode on var4 and var37", var4.equals(var37) ? var4.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var4
//     assertTrue("Contract failed: equals-hashcode on var37 and var4", var37.equals(var4) ? var37.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.xy.XYItemRendererState var2 = new org.jfree.chart.renderer.xy.XYItemRendererState(var1);
    org.jfree.chart.entity.EntityCollection var3 = var2.getEntityCollection();
    org.jfree.chart.plot.XYCrosshairState var4 = var2.getCrosshairState();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    java.awt.Shape var3 = var0.getBaseLegendShape();
    var0.setSeriesVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var10 = var9.getLastTextFragment();
    java.awt.Font var11 = var10.getFont();
    java.awt.Paint var12 = var10.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint(2147483647, var12);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateDimensions(var3);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     java.awt.geom.Point2D var38 = null;
//     var31.panDomainAxes(100.0d, var36, var38);
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D();
//     var40.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var43 = var40.getTickLabelInsets();
//     double var45 = var43.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getDataArea();
//     org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var48, "");
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var48, "");
//     org.jfree.chart.util.LengthAdjustmentType var53 = null;
//     org.jfree.chart.util.LengthAdjustmentType var54 = null;
//     java.awt.geom.Rectangle2D var55 = var43.createAdjustedRectangle(var48, var53, var54);
//     var36.setPlotArea(var55);
//     boolean var57 = org.jfree.chart.util.LineUtilities.clipLine(var0, var55);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    long var2 = var1.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var4 = var1.getDataItem(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9223372036854775807L);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setDatasetIndex(100);
    java.awt.geom.Point2D var4 = null;
    var1.setAnchor(var4);
    double var6 = var1.getAnchorX();
    int var7 = var1.getRangeAxisIndex();
    var1.setAnchorX(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var0.setSeriesItemLabelPaint(1, var15, false);
//     java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
//     org.jfree.chart.labels.XYItemLabelGenerator var24 = var0.getItemLabelGenerator(0, 0, true);
//     boolean var26 = var0.isSeriesVisibleInLegend(100);
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var29 = var27.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var31 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 0.0d);
//     var31.setRangeWithMargins(var34);
//     boolean var36 = var27.equals((java.lang.Object)var34);
//     var27.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var40 = var27.getSeriesNegativeItemLabelPosition((-1));
//     var0.setBaseNegativeItemLabelPosition(var40, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var0.", var27.equals(var0) == var0.equals(var27));
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    float var4 = var3.getTickMarkInsideLength();
    int var5 = var3.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var7.setRangeWithMargins(var10);
    var7.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var14 = var7.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var16 = var15.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
    org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
    var18.setDomainZeroBaselineVisible(false);
    var15.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
    var15.setDefaultEntityRadius((-1));
    java.awt.Stroke var26 = null;
    var15.setSeriesStroke(1, var26);
    java.awt.Shape var29 = var15.lookupLegendShape(100);
    var7.setDownArrow(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var2, (org.jfree.chart.axis.CategoryAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var31);
    var32.setWeight((-123));
    var32.clearDomainAxes();
    org.jfree.chart.renderer.xy.XYBarRenderer var36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var40 = var36.getItemOutlineStroke(0, 0, true);
    var32.setRangeGridlineStroke(var40);
    var0.setAxisLineStroke(var40);
    boolean var44 = var0.isHiddenValue(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     boolean var11 = var2.equals((java.lang.Object)var9);
//     var2.setBaseItemLabelsVisible(false);
//     var2.setBase(2.88E7d);
//     var2.setItemLabelAnchorOffset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var23, "");
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var26);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.entity.PieSectionEntity var34 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var23, var28, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var36.configure();
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     java.awt.geom.Rectangle2D var41 = var40.getDataArea();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
//     java.awt.Paint var45 = var43.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var46 = var43.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.util.RectangleEdge.opposite(var46);
//     boolean var49 = var46.equals((java.lang.Object)true);
//     double var50 = var36.valueToJava2D(0.05d, var41, var46);
//     var0.paintBarShadow(var1, var2, 10, 1, false, (java.awt.geom.RectangularShape)var23, var46, true);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(5, var1);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    java.text.AttributedString var0 = null;
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
    float var6 = var5.getTickMarkInsideLength();
    int var7 = var5.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var9.setRangeWithMargins(var12);
    var9.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var16 = var9.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var18 = var17.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    var20.setDomainZeroBaselineVisible(false);
    var17.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
    var17.setDefaultEntityRadius((-1));
    java.awt.Stroke var28 = null;
    var17.setSeriesStroke(1, var28);
    java.awt.Shape var31 = var17.lookupLegendShape(100);
    var9.setDownArrow(var31);
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var33);
    var34.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
    java.awt.geom.Rectangle2D var40 = var39.getDataArea();
    java.awt.geom.Point2D var41 = null;
    var34.panDomainAxes(100.0d, var39, var41);
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D();
    var43.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var46 = var43.getTickLabelInsets();
    double var48 = var46.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var49 = null;
    org.jfree.chart.plot.PlotRenderingInfo var50 = new org.jfree.chart.plot.PlotRenderingInfo(var49);
    java.awt.geom.Rectangle2D var51 = var50.getDataArea();
    org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "");
    org.jfree.chart.entity.ChartEntity var55 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "");
    org.jfree.chart.util.LengthAdjustmentType var56 = null;
    org.jfree.chart.util.LengthAdjustmentType var57 = null;
    java.awt.geom.Rectangle2D var58 = var46.createAdjustedRectangle(var51, var56, var57);
    var39.setPlotArea(var58);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var63 = new org.jfree.chart.plot.CombinedRangeXYPlot(var62);
    org.jfree.chart.axis.AxisLocation var64 = var63.getDomainAxisLocation();
    java.awt.Paint var65 = var63.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var66 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var65);
    java.awt.Paint var67 = var66.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem(var0, "Combined Range XYPlot", "14", "Other", (java.awt.Shape)var58, var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.0d, var6);
//     org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var12 = var3.arrange(var4, var9);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
    var16.setRangeWithMargins(var19);
    var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var16);
    boolean var22 = var12.isSubplot();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.data.Range var25 = var0.findRangeBounds(var24);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var30.axisChanged(var31);
//     org.jfree.chart.axis.PeriodAxis var34 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var35 = null;
//     org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 0.0d);
//     var34.setRangeWithMargins(var37);
//     var34.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var41 = var34.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var43 = var42.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.plot.DrawingSupplier var46 = var45.getDrawingSupplier();
//     var45.setDomainZeroBaselineVisible(false);
//     var42.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var45);
//     var42.setDefaultEntityRadius((-1));
//     java.awt.Stroke var53 = null;
//     var42.setSeriesStroke(1, var53);
//     java.awt.Shape var56 = var42.lookupLegendShape(100);
//     var34.setDownArrow(var56);
//     double var58 = var34.getLowerMargin();
//     double var59 = var34.getUpperBound();
//     int var60 = var30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var34);
//     
//     // Checks the contract:  equals-hashcode on var16 and var45
//     assertTrue("Contract failed: equals-hashcode on var16 and var45", var16.equals(var45) ? var16.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var16
//     assertTrue("Contract failed: equals-hashcode on var45 and var16", var45.equals(var16) ? var45.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var46
//     assertTrue("Contract failed: equals-hashcode on var17 and var46", var17.equals(var46) ? var17.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var17
//     assertTrue("Contract failed: equals-hashcode on var46 and var17", var46.equals(var17) ? var46.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    boolean var3 = var2.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel((org.jfree.data.xy.XYDataset)var2, 5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.event.PlotChangeEvent var5 = null;
//     var4.plotChanged(var5);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     var8.setFixedDimension(14.0d);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var8, var11);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var15 = var14.getTickMarkInsideLength();
//     int var16 = var14.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
//     var18.setRangeWithMargins(var21);
//     var18.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var25 = var18.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var27 = var26.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot(var28);
//     org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
//     var29.setDomainZeroBaselineVisible(false);
//     var26.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var29);
//     var26.setDefaultEntityRadius((-1));
//     java.awt.Stroke var37 = null;
//     var26.setSeriesStroke(1, var37);
//     java.awt.Shape var40 = var26.lookupLegendShape(100);
//     var18.setDownArrow(var40);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var42);
//     var43.setWeight((-123));
//     var43.clearDomainAxes();
//     java.awt.Paint var47 = var43.getRangeGridlinePaint();
//     var8.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var43);
//     
//     // Checks the contract:  equals-hashcode on var4 and var29
//     assertTrue("Contract failed: equals-hashcode on var4 and var29", var4.equals(var29) ? var4.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var4
//     assertTrue("Contract failed: equals-hashcode on var29 and var4", var29.equals(var4) ? var29.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    var30.setRangePannable(false);
    org.jfree.chart.util.RectangleInsets var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setAxisOffset(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var10, var14);
    java.awt.Font var16 = null;
    var15.setLabelFont(var16);
    java.awt.Shape var18 = var15.getLine();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var21 = null;
    var19.setSeriesItemLabelGenerator(100, var21);
    java.awt.Paint var23 = var19.getBaseLegendTextPaint();
    org.jfree.chart.ChartRenderingInfo var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
    java.awt.geom.Rectangle2D var26 = var25.getDataArea();
    var19.setBaseLegendShape((java.awt.Shape)var26);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot(var29);
    org.jfree.chart.event.PlotChangeEvent var31 = null;
    var30.plotChanged(var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
    org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
    java.awt.Paint var36 = var34.getRangeZeroBaselinePaint();
    var30.setRangeGridlinePaint(var36);
    var19.setSeriesOutlinePaint(0, var36, true);
    java.awt.Stroke var40 = null;
    org.jfree.chart.ChartRenderingInfo var45 = null;
    org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
    java.awt.geom.Rectangle2D var47 = var46.getDataArea();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var49 = new org.jfree.chart.plot.CombinedRangeXYPlot(var48);
    org.jfree.chart.plot.DrawingSupplier var50 = var49.getDrawingSupplier();
    java.awt.Paint var51 = var49.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var47, var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("", "Combined Range XYPlot", "Combined Range XYPlot", "hi!", var18, var36, var40, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    var32.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var35 = var32.getTickLabelInsets();
    var31.setAxisOffset(var35);
    var0.setInsets(var35, false);
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
    java.awt.Paint var41 = var40.getAggregatedItemsPaint();
    var0.setBackgroundPaint(var41);
    org.jfree.chart.event.RendererChangeEvent var43 = null;
    var0.rendererChanged(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.xy.XYItemRendererState var2 = new org.jfree.chart.renderer.xy.XYItemRendererState(var1);
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    float var5 = var4.getTickMarkInsideLength();
    int var6 = var4.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    var8.setRangeWithMargins(var11);
    var8.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var15 = var8.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var17 = var16.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    var19.setDomainZeroBaselineVisible(false);
    var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var19);
    var16.setDefaultEntityRadius((-1));
    java.awt.Stroke var27 = null;
    var16.setSeriesStroke(1, var27);
    java.awt.Shape var30 = var16.lookupLegendShape(100);
    var8.setDownArrow(var30);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var3, (org.jfree.chart.axis.CategoryAxis)var4, (org.jfree.chart.axis.ValueAxis)var8, var32);
    org.jfree.chart.util.RectangleEdge var34 = var33.getRangeAxisEdge();
    boolean var35 = var1.equals((java.lang.Object)var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var37 = var1.getSubplotInfo(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.axis.AxisLocation var5 = var1.getRangeAxisLocation();
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    var30.setRangePannable(false);
    double var38 = var30.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    boolean var19 = var0.getAutoPopulateSeriesShape();
    java.awt.Font var21 = var0.getLegendTextFont(0);
    org.jfree.chart.util.GradientPaintTransformer var22 = var0.getGradientPaintTransformer();
    org.jfree.chart.annotations.XYAnnotation var23 = null;
    boolean var24 = var0.removeAnnotation(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.getFirst();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var16 = var13.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getDataArea();
//     var13.handleClick(0, 1, var20);
//     int var23 = var20.getSubplotCount();
//     boolean var24 = var5.equals((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var3 = var1.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var4 = var1.getLegendItemURLGenerator();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var7 = var6.getTickMarkInsideLength();
//     int var8 = var6.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var10.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var17 = var10.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var21.setDomainZeroBaselineVisible(false);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     var18.setDefaultEntityRadius((-1));
//     java.awt.Stroke var29 = null;
//     var18.setSeriesStroke(1, var29);
//     java.awt.Shape var32 = var18.lookupLegendShape(100);
//     var10.setDownArrow(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
//     java.awt.Font var37 = var6.getTickLabelFont((java.lang.Comparable)4.0d);
//     var1.setBaseLegendTextFont(var37);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var41 = var40.getTickMarkInsideLength();
//     int var42 = var40.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var45 = null;
//     org.jfree.data.Range var47 = org.jfree.data.Range.expandToInclude(var45, 0.0d);
//     var44.setRangeWithMargins(var47);
//     var44.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var51 = var44.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var53 = var52.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var55 = new org.jfree.chart.plot.CombinedRangeXYPlot(var54);
//     org.jfree.chart.plot.DrawingSupplier var56 = var55.getDrawingSupplier();
//     var55.setDomainZeroBaselineVisible(false);
//     var52.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var55);
//     var52.setDefaultEntityRadius((-1));
//     java.awt.Stroke var63 = null;
//     var52.setSeriesStroke(1, var63);
//     java.awt.Shape var66 = var52.lookupLegendShape(100);
//     var44.setDownArrow(var66);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var39, (org.jfree.chart.axis.CategoryAxis)var40, (org.jfree.chart.axis.ValueAxis)var44, var68);
//     var69.setWeight((-123));
//     var69.clearDomainAxes();
//     java.awt.Paint var73 = var69.getRangeGridlinePaint();
//     org.jfree.chart.text.TextLine var74 = new org.jfree.chart.text.TextLine("", var37, var73);
//     
//     // Checks the contract:  equals-hashcode on var21 and var55
//     assertTrue("Contract failed: equals-hashcode on var21 and var55", var21.equals(var55) ? var21.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var21
//     assertTrue("Contract failed: equals-hashcode on var55 and var21", var55.equals(var21) ? var55.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var56
//     assertTrue("Contract failed: equals-hashcode on var22 and var56", var22.equals(var56) ? var22.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var22
//     assertTrue("Contract failed: equals-hashcode on var56 and var22", var56.equals(var22) ? var56.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.Range var2 = var0.getDomainBounds(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getY(2147483647, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     var0.setDefaultEntityRadius((-1));
//     java.awt.Stroke var11 = null;
//     var0.setSeriesStroke(1, var11);
//     boolean var13 = var0.getBaseSeriesVisibleInLegend();
//     boolean var14 = var0.getAutoPopulateSeriesPaint();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
//     java.awt.Paint var18 = var17.getAggregatedItemsPaint();
//     var0.setSeriesItemLabelPaint(5, var18);
//     java.awt.Paint var21 = null;
//     var0.setSeriesPaint(100, var21, false);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     double var26 = var25.getDomainCrosshairValue();
//     boolean var27 = var25.isSubplot();
//     org.jfree.chart.util.RectangleEdge var29 = var25.getDomainAxisEdge(1);
//     var25.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
//     org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
//     java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var38 = null;
//     org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
//     var37.setRangeWithMargins(var40);
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var44);
//     java.awt.Stroke var46 = var44.getMinorTickMarkStroke();
//     var25.setOutlineStroke(var46);
//     var0.setBaseOutlineStroke(var46, true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var34
//     assertTrue("Contract failed: equals-hashcode on var4 and var34", var4.equals(var34) ? var4.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var4
//     assertTrue("Contract failed: equals-hashcode on var34 and var4", var34.equals(var4) ? var34.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setMaximumItemCount((-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
    org.jfree.chart.plot.PlotOrientation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    boolean var14 = var0.getAutoPopulateSeriesPaint();
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
    java.awt.Paint var18 = var17.getAggregatedItemsPaint();
    var0.setSeriesItemLabelPaint(5, var18);
    java.awt.Paint var21 = null;
    var0.setSeriesPaint(100, var21, false);
    org.jfree.chart.plot.DrawingSupplier var24 = var0.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot(var4);
    java.awt.Paint var6 = var5.getAggregatedItemsPaint();
    int var7 = var3.compareTo((java.lang.Object)var5);
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setAggregatedItemsPaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "100", "ChartEntity: tooltip = ", "", "ChartEntity: tooltip = ");
    java.lang.String var6 = var5.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = "+ "'", var6.equals("ChartEntity: tooltip = "));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisSpace var2 = null;
    var1.setFixedRangeAxisSpace(var2);
    boolean var4 = var1.isDomainZeroBaselineVisible();
    var1.setRangeCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
//     var4.setRangeWithMargins(var7);
//     boolean var9 = var0.equals((java.lang.Object)var7);
//     var0.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 0.0d);
//     var19.setRangeWithMargins(var22);
//     boolean var24 = var15.equals((java.lang.Object)var22);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var25 = var15.getLegendItemToolTipGenerator();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     java.awt.Paint var37 = var35.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var33, var37);
//     java.awt.Font var39 = null;
//     var38.setLabelFont(var39);
//     java.awt.Shape var41 = var38.getLine();
//     java.awt.Paint var42 = var38.getFillPaint();
//     var15.setSeriesPaint(0, var42);
//     boolean var44 = var14.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var15.", var0.equals(var15) == var15.equals(var0));
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "[size=1]"+ "'", var4.equals("[size=1]"));

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.entity.EntityCollection var2 = null;
//     org.jfree.chart.ChartRenderingInfo var3 = new org.jfree.chart.ChartRenderingInfo(var2);
//     java.awt.geom.Rectangle2D var4 = var3.getChartArea();
//     org.jfree.chart.plot.CrosshairState var6 = new org.jfree.chart.plot.CrosshairState(false);
//     var6.setDatasetIndex(100);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var6.setAnchor(var15);
//     org.jfree.chart.plot.PlotState var17 = null;
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getDataArea();
//     java.awt.geom.Rectangle2D var21 = var19.getPlotArea();
//     var0.draw(var1, var4, var15, var17, var19);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var1 = var0.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.event.PlotChangeEvent var4 = null;
//     var3.plotChanged(var4);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var13, var17);
//     var0.setLabelPaint(var17);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.JFreeChart var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var3 = new org.jfree.chart.entity.JFreeChartEntity(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    var30.setRangePannable(false);
    float var38 = var30.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0f);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
//     var4.setRangeWithMargins(var7);
//     boolean var9 = var0.equals((java.lang.Object)var7);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     var16.setRangeWithMargins(var19);
//     var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var16);
//     boolean var22 = var12.isSubplot();
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     org.jfree.chart.renderer.xy.XYBarRenderer var24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 0.0d);
//     var28.setRangeWithMargins(var31);
//     boolean var33 = var24.equals((java.lang.Object)var31);
//     var24.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var24.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.text.TextAnchor var38 = var37.getRotationAnchor();
//     var0.setBasePositiveItemLabelPosition(var37);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    var0.setIgnoreNullValues(true);
    java.lang.String var4 = var0.getPlotType();
    double var5 = var0.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Pie Plot"+ "'", var4.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var35 = var32.getTickLabelInsets();
//     var31.setAxisOffset(var35);
//     var0.setInsets(var35, false);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
//     java.awt.Paint var41 = var40.getAggregatedItemsPaint();
//     var0.setBackgroundPaint(var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot(var43);
//     org.jfree.chart.plot.DrawingSupplier var45 = var44.getDrawingSupplier();
//     var0.setDrawingSupplier(var45, true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var44
//     assertTrue("Contract failed: equals-hashcode on var17 and var44", var17.equals(var44) ? var17.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var17
//     assertTrue("Contract failed: equals-hashcode on var44 and var17", var44.equals(var17) ? var44.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    java.awt.Paint var5 = var3.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var6 = var3.getDomainAxisEdge();
    var0.ensureAtLeast(100.0d, var6);
    var0.setBottom(Double.NaN);
    var0.setLeft((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    java.util.Locale var0 = null;
    org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.data.xy.XYSeries var6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var8 = var6.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var11 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var6.add(var11);
    double var13 = var11.getXValue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var14 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 14.0d, (-1), (java.lang.Comparable)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var2 = var1.getNumberFormat();
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var2, var3);
    java.lang.Object var5 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAnchor var1 = var0.getDomainGridlinePosition();
//     org.jfree.data.category.CategoryDataset var3 = var0.getDataset((-1));
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var6.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var8 = org.jfree.chart.axis.AxisLocation.getOpposite(var7);
//     var0.setRangeAxisLocation(4, var8);
//     var0.zoom(4.0d);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    var0.setMinimumArcAngleToDraw(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    java.awt.Shape var3 = var0.getBaseLegendShape();
    var0.setSeriesVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var8 = var7.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
    org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
    var10.setDomainZeroBaselineVisible(false);
    var7.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    var7.setDefaultEntityRadius((-1));
    org.jfree.chart.labels.XYSeriesLabelGenerator var17 = var7.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var17);
    org.jfree.chart.axis.NumberAxis var19 = null;
    java.awt.Font var24 = null;
    org.jfree.chart.axis.MarkerAxisBand var25 = new org.jfree.chart.axis.MarkerAxisBand(var19, 10.0d, 10.0d, 1.0d, 100.0d, var24);
    boolean var26 = var0.equals((java.lang.Object)100.0d);
    boolean var29 = var0.getItemVisible(100, (-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    var0.removeAllSeries();
    org.jfree.chart.ChartRenderingInfo var2 = null;
    org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var2);
    org.jfree.chart.renderer.xy.XYItemRendererState var4 = new org.jfree.chart.renderer.xy.XYItemRendererState(var3);
    int var5 = var4.getFirstItemIndex();
    boolean var6 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
    var1.clearDomainMarkers((-123));
    var1.setDomainCrosshairLockedOnData(true);
    double var12 = var1.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.setQuadrantOrigin(var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
//     org.jfree.chart.util.RectangleInsets var19 = var17.getItemLabelPadding();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var23 = null;
//     var21.setSeriesItemLabelGenerator(100, var23);
//     java.awt.Paint var25 = var21.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getDataArea();
//     var21.setBaseLegendShape((java.awt.Shape)var28);
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var31.setDomainDescription("");
//     java.lang.Object var34 = var17.draw(var20, var28, (java.lang.Object)"");
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setShadowYOffset(10.0d);
    boolean var12 = var0.getItemVisible(10, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    double var2 = var1.getDomainCrosshairValue();
    boolean var3 = var1.isSubplot();
    org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
    var1.setForegroundAlpha(1.0f);
    var1.setDomainGridlinesVisible(false);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
    float var12 = var11.getTickMarkInsideLength();
    int var13 = var11.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var16 = null;
    org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
    var15.setRangeWithMargins(var18);
    var15.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var22 = var15.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var24 = var23.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
    org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
    var26.setDomainZeroBaselineVisible(false);
    var23.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
    var23.setDefaultEntityRadius((-1));
    java.awt.Stroke var34 = null;
    var23.setSeriesStroke(1, var34);
    java.awt.Shape var37 = var23.lookupLegendShape(100);
    var15.setDownArrow(var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var39);
    var40.setWeight((-123));
    var40.clearDomainAxes();
    boolean var44 = var40.isRangeZeroBaselineVisible();
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)false, (java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    var2.setRangeWithMargins(var5);
    var2.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var9 = var2.getPlot();
    java.lang.Object var10 = var2.clone();
    java.lang.Class var11 = var2.getMinorTickTimePeriodClass();
    java.lang.Class var12 = org.jfree.data.time.RegularTimePeriod.downsize(var11);
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    var14.setRangeWithMargins(var17);
    var14.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var21 = var14.getPlot();
    java.lang.Object var22 = var14.clone();
    java.lang.Class var23 = var14.getMinorTickTimePeriodClass();
    java.lang.Object var24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ChartEntity: tooltip = ", var12, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(-2208960000000L), false);
//     double var3 = var2.getMinX();
//     boolean var4 = var2.getAutoSort();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 10);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    var12.setDomainZeroBaselineVisible(false);
    var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    var9.setDefaultEntityRadius((-1));
    java.awt.Stroke var20 = null;
    var9.setSeriesStroke(1, var20);
    java.awt.Shape var23 = var9.lookupLegendShape(100);
    var1.setDownArrow(var23);
    float var25 = var1.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.util.VerticalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setVerticalAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    var30.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Other", var1);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     double var2 = var1.getDomainCrosshairValue();
//     boolean var3 = var1.isSubplot();
//     org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
//     var1.setForegroundAlpha(1.0f);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot(var8);
//     org.jfree.chart.plot.DrawingSupplier var10 = var9.getDrawingSupplier();
//     java.awt.Paint var11 = var9.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var14 = null;
//     org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 0.0d);
//     var13.setRangeWithMargins(var16);
//     var9.setDomainAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
//     var9.setDomainAxis((org.jfree.chart.axis.ValueAxis)var20);
//     java.awt.Stroke var22 = var20.getMinorTickMarkStroke();
//     var1.setOutlineStroke(var22);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     java.awt.geom.Rectangle2D var30 = var29.getDataArea();
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot(var31);
//     org.jfree.chart.plot.DrawingSupplier var33 = var32.getDrawingSupplier();
//     java.awt.Paint var34 = var32.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var30, var34);
//     java.awt.Font var36 = null;
//     var35.setLabelFont(var36);
//     java.awt.Shape var38 = var35.getLine();
//     java.awt.Paint var39 = var35.getFillPaint();
//     var1.setRangeCrosshairPaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var3 = var1.getRangeAxis();
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.data.Range var15 = var1.getDataRange((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var17 = var16.getRightArrow();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var20 = var19.getTickMarkInsideLength();
//     int var21 = var19.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var23.setRangeWithMargins(var26);
//     var23.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var30 = var23.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var32 = var31.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     var34.setDomainZeroBaselineVisible(false);
//     var31.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var34);
//     var31.setDefaultEntityRadius((-1));
//     java.awt.Stroke var42 = null;
//     var31.setSeriesStroke(1, var42);
//     java.awt.Shape var45 = var31.lookupLegendShape(100);
//     var23.setDownArrow(var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var47);
//     var48.setWeight((-123));
//     var48.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var52 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var56 = var52.getItemOutlineStroke(0, 0, true);
//     var48.setRangeGridlineStroke(var56);
//     var16.setAxisLineStroke(var56);
//     var1.setRangeGridlineStroke(var56);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     var3.setMaximumItemCount(1);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
//     var11.setRangeWithMargins(var14);
//     var7.setDomainAxis((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.data.time.RegularTimePeriod var17 = var11.getFirst();
//     java.util.Date var18 = var17.getEnd();
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     java.awt.Paint var26 = var24.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 0.0d);
//     var28.setRangeWithMargins(var31);
//     var24.setDomainAxis((org.jfree.chart.axis.ValueAxis)var28);
//     org.jfree.data.time.RegularTimePeriod var34 = var28.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var22.addOrUpdate(var34, 10.0d);
//     org.jfree.data.time.TimeSeries var37 = var3.createCopy(var17, var34);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAnchor var1 = var0.getDomainGridlinePosition();
    org.jfree.chart.axis.CategoryAxis var3 = var0.getDomainAxisForDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    var1.setDescription("Combined Range XYPlot");
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var9.setDomainDescription("");
    java.util.Collection var12 = var1.getTimePeriodsUniqueToOtherSeries(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var1.getValue(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("rect", "100", "PlotEntity: tooltip = null");

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
//     org.jfree.chart.LegendItemCollection var34 = null;
//     var33.addAll(var34);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    var30.zoom((-1.0d));
    org.jfree.data.general.DatasetGroup var36 = var30.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var7);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var7, var9);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var4 = var2.lookupSeriesPaint(0);
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var7 = var5.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var8 = var5.getLegendItemURLGenerator();
//     java.awt.Shape var10 = var5.lookupLegendShape(1);
//     var5.setSeriesVisibleInLegend(100, (java.lang.Boolean)true, false);
//     java.awt.Stroke var16 = var5.lookupSeriesStroke(5);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
//     org.jfree.chart.axis.AxisLocation var19 = var18.getDomainAxisLocation();
//     java.awt.Paint var20 = var18.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var22 = var21.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     var24.setDomainZeroBaselineVisible(false);
//     var21.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     var21.setDefaultEntityRadius((-1));
//     java.awt.Stroke var32 = null;
//     var21.setSeriesStroke(1, var32);
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var39 = var35.getItemOutlineStroke(0, 0, true);
//     var21.setSeriesStroke(10, var39, false);
//     org.jfree.chart.plot.IntervalMarker var43 = new org.jfree.chart.plot.IntervalMarker(0.05d, 0.0d, var4, var16, var20, var39, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var5
//     assertTrue("Contract failed: equals-hashcode on var35 and var5", var35.equals(var5) ? var35.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var5.", var2.equals(var5) == var5.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var5.", var35.equals(var5) == var5.equals(var35));
//     
//     // Checks the contract:  equals-hashcode on var18 and var24
//     assertTrue("Contract failed: equals-hashcode on var18 and var24", var18.equals(var24) ? var18.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var18
//     assertTrue("Contract failed: equals-hashcode on var24 and var18", var24.equals(var18) ? var24.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.ChartRenderingInfo var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
    java.awt.geom.Rectangle2D var21 = var20.getDataArea();
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
    org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
    java.awt.Paint var25 = var23.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var21, var25);
    java.awt.Font var27 = null;
    var26.setLabelFont(var27);
    java.awt.Shape var29 = var26.getLine();
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var29, "100", "hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-123), var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.plot.XYCrosshairState var0 = new org.jfree.chart.plot.XYCrosshairState();

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var3 = var0.getTickLabelInsets();
    var0.setCategoryLabelPositionOffset(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (-1.0d), 100.0d);
    org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.data.time.RegularTimePeriod var11 = var5.getFirst();
    java.util.Date var12 = var11.getEnd();
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     int var31 = var30.getDatasetCount();
//     var30.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.axis.AxisLocation var38 = var37.getDomainAxisLocation();
//     java.awt.Paint var39 = var37.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var40 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var39);
//     java.awt.Paint var41 = var40.getPaint();
//     org.jfree.chart.util.Layer var42 = null;
//     var30.addRangeMarker((org.jfree.chart.plot.Marker)var40, var42);
//     
//     // Checks the contract:  equals-hashcode on var16 and var37
//     assertTrue("Contract failed: equals-hashcode on var16 and var37", var16.equals(var37) ? var16.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var16
//     assertTrue("Contract failed: equals-hashcode on var37 and var16", var37.equals(var16) ? var37.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    org.jfree.chart.block.FlowArrangement var1 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var2 = null;
    org.jfree.chart.title.LegendItemBlockContainer var4 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, var2, (java.lang.Comparable)(byte)1);
    boolean var5 = var0.equals((java.lang.Object)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     java.awt.Font var33 = var2.getTickLabelFont((java.lang.Comparable)4.0d);
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     java.awt.Paint var37 = var35.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var38 = var35.getDomainAxisEdge();
//     var35.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", var33, (org.jfree.chart.plot.Plot)var35, true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var36
//     assertTrue("Contract failed: equals-hashcode on var18 and var36", var18.equals(var36) ? var18.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var18
//     assertTrue("Contract failed: equals-hashcode on var36 and var18", var36.equals(var18) ? var36.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.plot.CrosshairState var0 = new org.jfree.chart.plot.CrosshairState();
    double var1 = var0.getAnchorX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.plot.DrawingSupplier var11 = var0.getDrawingSupplier();
    java.awt.Paint var12 = var0.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    double var37 = var34.calculateTopInset(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var2 = var1.getNumberFormat();
    var2.setParseIntegerOnly(false);
    var2.setMinimumIntegerDigits(1);
    java.text.NumberFormat var7 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var2, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var4 = var0.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var0.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var10 = var9.getPaint();
    var0.setBaseItemLabelPaint(var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.data.general.DatasetGroup var2 = var1.getDatasetGroup();
//     var1.setRangeCrosshairVisible(true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.panRangeAxes(4.0d, var7, var15);
//     
//     // Checks the contract:  equals-hashcode on var7 and var10
//     assertTrue("Contract failed: equals-hashcode on var7 and var10", var7.equals(var10) ? var7.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var7
//     assertTrue("Contract failed: equals-hashcode on var10 and var7", var10.equals(var7) ? var10.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setDatasetIndex(100);
    java.awt.geom.Point2D var4 = null;
    var1.setAnchor(var4);
    java.awt.geom.Point2D var6 = var1.getAnchor();
    var1.updateCrosshairX(1.0d, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var1.setRangeWithMargins(var29);
//     var1.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     java.awt.geom.Rectangle2D var38 = var37.getDataArea();
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
//     org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
//     java.awt.Paint var42 = var40.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var43 = var40.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var44 = org.jfree.chart.util.RectangleEdge.opposite(var43);
//     boolean var46 = var43.equals((java.lang.Object)true);
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.util.RectangleEdge.opposite(var43);
//     double var48 = var1.java2DToValue(100.0d, var38, var43);
//     
//     // Checks the contract:  equals-hashcode on var12 and var40
//     assertTrue("Contract failed: equals-hashcode on var12 and var40", var12.equals(var40) ? var12.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var12
//     assertTrue("Contract failed: equals-hashcode on var40 and var12", var40.equals(var12) ? var40.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var41
//     assertTrue("Contract failed: equals-hashcode on var13 and var41", var13.equals(var41) ? var13.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var13
//     assertTrue("Contract failed: equals-hashcode on var41 and var13", var41.equals(var13) ? var41.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     var1.handleClick(0, 1, var8);
//     int var11 = var8.getSubplotCount();
//     org.jfree.chart.plot.CrosshairState var13 = new org.jfree.chart.plot.CrosshairState(false);
//     var13.setDatasetIndex(100);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
//     org.jfree.chart.util.RectangleAnchor var21 = null;
//     java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var18, var21);
//     var13.setAnchor(var22);
//     int var24 = var8.getSubplotIndex(var22);
//     
//     // Checks the contract:  equals-hashcode on var8 and var17
//     assertTrue("Contract failed: equals-hashcode on var8 and var17", var8.equals(var17) ? var8.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var8
//     assertTrue("Contract failed: equals-hashcode on var17 and var8", var17.equals(var8) ? var17.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.updateCrosshairY(0.05d, 10);
    int var5 = var1.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addAnnotation(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    boolean var14 = var0.getAutoPopulateSeriesPaint();
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
    java.awt.Paint var18 = var17.getAggregatedItemsPaint();
    var0.setSeriesItemLabelPaint(5, var18);
    java.awt.Paint var21 = null;
    var0.setSeriesPaint(100, var21, false);
    boolean var24 = var0.getUseYInterval();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 10);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var0.setSeriesItemLabelPaint(1, var15, false);
//     java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var23 = null;
//     var21.setSeriesItemLabelGenerator(100, var23);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Rectangle2D var32 = var31.getDataArea();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     java.awt.Paint var36 = var34.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var32, var36);
//     var21.setSeriesItemLabelPaint(1, var36, false);
//     java.awt.Paint var41 = var21.getSeriesFillPaint((-123));
//     org.jfree.chart.labels.XYItemLabelGenerator var45 = var21.getItemLabelGenerator(0, 0, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var48 = var46.getSeriesPositiveItemLabelPosition(0);
//     var21.setBaseNegativeItemLabelPosition(var48);
//     var0.setNegativeItemLabelPositionFallback(var48);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var34
//     assertTrue("Contract failed: equals-hashcode on var13 and var34", var13.equals(var34) ? var13.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var13
//     assertTrue("Contract failed: equals-hashcode on var34 and var13", var34.equals(var13) ? var34.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var37
//     assertTrue("Contract failed: equals-hashcode on var16 and var37", var16.equals(var37) ? var16.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var16
//     assertTrue("Contract failed: equals-hashcode on var37 and var16", var37.equals(var16) ? var37.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.Comparable[] var1 = null;
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var0, var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setDatasetIndex(100);
    java.awt.geom.Point2D var4 = null;
    var1.setAnchor(var4);
    double var6 = var1.getAnchorX();
    int var7 = var1.getRangeAxisIndex();
    double var8 = var1.getAnchorY();
    double var9 = var1.getCrosshairX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainMinorGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     var15.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.axis.AxisLocation var22 = var21.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var23 = org.jfree.chart.axis.AxisLocation.getOpposite(var22);
//     var15.setRangeAxisLocation(0, var23, true);
//     var1.setDomainAxisLocation(0, var23, false);
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var7
//     assertTrue("Contract failed: equals-hashcode on var21 and var7", var21.equals(var7) ? var21.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
    double var2 = var1.getItemLabelAnchorOffset();
    boolean var3 = var1.getShapesVisible();
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.ChartRenderingInfo var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
    org.jfree.chart.renderer.xy.XYItemRendererState var7 = new org.jfree.chart.renderer.xy.XYItemRendererState(var6);
    org.jfree.data.xy.XYDatasetSelectionState var8 = null;
    var7.setSelectionState(var8);
    org.jfree.chart.ChartRenderingInfo var12 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
    java.awt.geom.Rectangle2D var14 = var13.getDataArea();
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var14, "");
    java.awt.geom.Point2D var17 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 2.88E7d, var14);
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    var19.setDomainZeroBaselineVisible(false);
    var19.configureRangeAxes();
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var25.configure();
    org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var29 = null;
    org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 0.0d);
    var28.setRangeWithMargins(var31);
    var28.setNegativeArrowVisible(false);
    org.jfree.data.time.TimeSeriesCollection var35 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection();
    var35.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.drawItem(var4, var7, var14, (org.jfree.chart.plot.XYPlot)var19, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.data.xy.XYDataset)var36, (-1), 1, true, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    var0.removeAllSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.getStartXValue(0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var1.setMaximumCategoryLabelWidthRatio(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     var0.setDefaultEntityRadius((-1));
//     java.awt.Stroke var11 = null;
//     var0.setSeriesStroke(1, var11);
//     org.jfree.chart.plot.XYPlot var13 = var0.getPlot();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     var15.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.axis.AxisLocation var22 = var21.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var23 = org.jfree.chart.axis.AxisLocation.getOpposite(var22);
//     var15.setRangeAxisLocation(0, var23, true);
//     boolean var26 = var15.isDomainMinorGridlinesVisible();
//     var0.setPlot((org.jfree.chart.plot.XYPlot)var15);
//     
//     // Checks the contract:  equals-hashcode on var3 and var21
//     assertTrue("Contract failed: equals-hashcode on var3 and var21", var3.equals(var21) ? var3.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var3
//     assertTrue("Contract failed: equals-hashcode on var21 and var3", var21.equals(var3) ? var21.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    var12.setDomainZeroBaselineVisible(false);
    var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    var9.setDefaultEntityRadius((-1));
    java.awt.Stroke var20 = null;
    var9.setSeriesStroke(1, var20);
    java.awt.Shape var23 = var9.lookupLegendShape(100);
    var1.setDownArrow(var23);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
    var26.setRangeWithMargins(var29);
    var1.setRangeWithMargins(var29);
    var1.setAutoTickUnitSelection(false, false);
    var1.setLabelAngle(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.util.Size2D var7 = var5.calculateDimensions(var6);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
    var12.setLowerMargin((-1.0d));
    var12.setAxisLineVisible(false);
    org.jfree.chart.ChartRenderingInfo var21 = null;
    org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
    java.awt.geom.Rectangle2D var23 = var22.getDataArea();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
    org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
    java.awt.Paint var27 = var25.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var23, var27);
    java.awt.Font var29 = null;
    var28.setLabelFont(var29);
    java.awt.Shape var31 = var28.getLine();
    java.awt.Paint var32 = var28.getFillPaint();
    var12.setAxisLinePaint(var32);
    org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(0.05d, 1.0d, 2.88E7d, 0.0d, var32);
    boolean var35 = var7.equals((java.lang.Object)0.0d);
    org.jfree.chart.util.RectangleAnchor var38 = null;
    java.awt.geom.Rectangle2D var39 = org.jfree.chart.util.RectangleAnchor.createRectangle(var7, 10.0d, 0.0d, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    java.lang.Object var9 = var1.clone();
    java.lang.Class var10 = var1.getMinorTickTimePeriodClass();
    boolean var11 = org.jfree.chart.util.SerialUtilities.isSerializable(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    var11.setDatasetIndex(10);
    var11.setSeriesKey((java.lang.Comparable)"ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem(var15, 0.0d);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     java.awt.Paint var25 = var23.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 0.0d);
//     var27.setRangeWithMargins(var30);
//     var23.setDomainAxis((org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var35 = var21.addOrUpdate(var33, 10.0d);
//     org.jfree.data.time.TimeSeries var36 = var3.createCopy(var15, var33);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.urls.XYURLGenerator var11 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
//     int var4 = var2.indexOf((java.lang.Number)(byte)100);
//     int var5 = var2.getItemCount();
//     double var6 = var2.getMinX();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
    org.jfree.chart.util.HorizontalAlignment var6 = var5.getLineAlignment();
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var7.equals("HorizontalAlignment.CENTER"));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    var2.setMaximumItemCount(0);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = var11.getLabelFont();
    boolean var13 = var11.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.util.List var34 = var31.getCategories();
    var31.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var37 = var0.hasListener((java.util.EventListener)var31);
    org.jfree.chart.plot.Plot var38 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.CrosshairState var2 = new org.jfree.chart.plot.CrosshairState(false);
//     var2.updateCrosshairY(0.05d, 10);
//     boolean var6 = var0.equals((java.lang.Object)0.05d);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var9 = var8.getTickMarkInsideLength();
//     int var10 = var8.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     var12.setRangeWithMargins(var15);
//     var12.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var19 = var12.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var21 = var20.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     var23.setDomainZeroBaselineVisible(false);
//     var20.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
//     var20.setDefaultEntityRadius((-1));
//     java.awt.Stroke var31 = null;
//     var20.setSeriesStroke(1, var31);
//     java.awt.Shape var34 = var20.lookupLegendShape(100);
//     var12.setDownArrow(var34);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var7, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var36);
//     var37.setWeight((-123));
//     var37.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var45 = var41.getItemOutlineStroke(0, 0, true);
//     var37.setRangeGridlineStroke(var45);
//     org.jfree.chart.axis.ValueAxis var48 = var37.getRangeAxisForDataset(10);
//     java.awt.Stroke var49 = var37.getDomainCrosshairStroke();
//     boolean var50 = var0.equals((java.lang.Object)var37);
//     org.jfree.data.general.PieDataset var51 = null;
//     java.text.AttributedString var53 = var0.generateAttributedSectionLabel(var51, (java.lang.Comparable)(byte)1);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    var5.draw(var6, 1.0f, (-1.0f), var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    java.awt.Font var32 = var1.getTickLabelFont((java.lang.Comparable)4.0d);
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
    var33.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var36 = var33.getTickLabelInsets();
    var1.setTickLabelInsets(var36);
    double var39 = var36.calculateLeftInset(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 4.0d);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentSize();
//     long var2 = var0.getStartTime();
//     boolean var4 = var0.containsDomainValue(172800000L);
//     var0.addBaseTimelineException(9223372036854775807L);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    double var2 = var1.getDomainCrosshairValue();
    boolean var3 = var1.isSubplot();
    org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
    var1.setForegroundAlpha(1.0f);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var10 = var9.getPaint();
    var1.setNoDataMessagePaint(var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
    org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
    java.awt.Paint var16 = var14.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
    var18.setRangeWithMargins(var21);
    var14.setDomainAxis((org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    var14.setDomainAxis((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Stroke var27 = var25.getMinorTickMarkStroke();
    org.jfree.data.Range var28 = var25.getDefaultAutoRange();
    var1.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var25, true);
    boolean var31 = var25.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = null;
    var1.plotChanged(var2);
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    var1.setRangeGridlinePaint(var7);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
    var1.setQuadrantOrigin(var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
    org.jfree.chart.util.RectangleAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLegendItemGraphicAnchor(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    float var1 = var0.getTickMarkInsideLength();
    var0.setLabel("Rotation.CLOCKWISE");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    java.lang.Object var5 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var3.addOrUpdate(var15, 10.0d);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     java.awt.Paint var25 = var23.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 0.0d);
//     var27.setRangeWithMargins(var30);
//     var23.setDomainAxis((org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.getFirst();
//     org.jfree.data.time.TimeSeriesDataItem var35 = var21.addOrUpdate(var33, 10.0d);
//     java.lang.Number var36 = var3.getValue(var33);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.GradientBarPainter var0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter)var0);
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var2);
    float var4 = var3.getBackgroundImageAlpha();
    boolean var5 = var0.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     java.awt.Paint var4 = var0.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getDataArea();
//     var0.setBaseLegendShape((java.awt.Shape)var7);
//     org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var11 = var10.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     var13.setDomainZeroBaselineVisible(false);
//     var10.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var13);
//     boolean var20 = var10.getItemVisible(10, 100);
//     org.jfree.chart.labels.ItemLabelPosition var22 = var10.getSeriesPositiveItemLabelPosition(10);
//     var0.setSeriesPositiveItemLabelPosition(0, var22, true);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getDataArea();
//     org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var28, "");
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var31);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     var34.setDomainZeroBaselineVisible(false);
//     var34.configureRangeAxes();
//     var34.clearDomainMarkers();
//     double var40 = var34.getGap();
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     org.jfree.chart.renderer.xy.XYItemRendererState var44 = var0.initialise(var25, var28, (org.jfree.chart.plot.XYPlot)var34, var41, var43);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
    var1.setRangeAxisLocation(0, var9, true);
    org.jfree.chart.axis.AxisLocation var12 = var9.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     var30.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var38 = var34.getItemOutlineStroke(0, 0, true);
//     var30.setRangeGridlineStroke(var38);
//     org.jfree.chart.axis.ValueAxis var41 = var30.getRangeAxisForDataset(10);
//     java.awt.Stroke var42 = var30.getDomainCrosshairStroke();
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot(var45);
//     org.jfree.chart.plot.DrawingSupplier var47 = var46.getDrawingSupplier();
//     java.awt.Paint var48 = var46.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var49 = var46.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getDataArea();
//     var46.handleClick(0, 1, var53);
//     var30.handleClick(4, (-123), var53);
//     
//     // Checks the contract:  equals-hashcode on var16 and var46
//     assertTrue("Contract failed: equals-hashcode on var16 and var46", var16.equals(var46) ? var16.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var16
//     assertTrue("Contract failed: equals-hashcode on var46 and var16", var46.equals(var16) ? var46.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var47
//     assertTrue("Contract failed: equals-hashcode on var17 and var47", var17.equals(var47) ? var17.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var17
//     assertTrue("Contract failed: equals-hashcode on var47 and var17", var47.equals(var17) ? var47.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
//     java.text.NumberFormat var1 = var0.getNumberFormat();
//     var1.setMaximumIntegerDigits((-1));
//     java.text.ParsePosition var5 = null;
//     java.lang.Object var6 = var1.parseObject("Combined Range XYPlot", var5);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     var12.setRangeWithMargins(var15);
//     var12.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var19 = var12.getPlot();
//     java.lang.Object var20 = var12.clone();
//     org.jfree.chart.renderer.xy.XYBarRenderer var21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var22 = var21.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
//     org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
//     var24.setDomainZeroBaselineVisible(false);
//     var21.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     var21.setDefaultEntityRadius((-1));
//     java.awt.Stroke var32 = null;
//     var21.setSeriesStroke(1, var32);
//     boolean var34 = var21.getBaseSeriesVisibleInLegend();
//     boolean var35 = var21.getAutoPopulateSeriesPaint();
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.plot.MultiplePiePlot var38 = new org.jfree.chart.plot.MultiplePiePlot(var37);
//     java.awt.Paint var39 = var38.getAggregatedItemsPaint();
//     var21.setSeriesItemLabelPaint(5, var39);
//     var12.setLabelPaint(var39);
//     var1.setDomainZeroBaselinePaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    java.awt.Paint var4 = var0.getBaseLegendTextPaint();
    org.jfree.chart.ChartRenderingInfo var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
    java.awt.geom.Rectangle2D var7 = var6.getDataArea();
    var0.setBaseLegendShape((java.awt.Shape)var7);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var16 = var13.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var17 = org.jfree.chart.util.RectangleEdge.opposite(var16);
    var10.setPosition(var16);
    org.jfree.chart.util.RectangleInsets var19 = var10.getPadding();
    org.jfree.chart.event.TitleChangeEvent var20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var10);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var7, (org.jfree.chart.title.Title)var10, "ThreadContext", "SerialDate.weekInMonthToString(): invalid code.");
    var10.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    var1.setRangeCrosshairValue(10.0d);
    var1.setGap(4.0d);
    var1.clearSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    var0.setBoolean(0, (java.lang.Boolean)false);
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    boolean var6 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    java.awt.Paint var6 = var1.getRangeTickBandPaint();
    org.jfree.chart.util.RectangleEdge var8 = var1.getDomainAxisEdge(5);
    var1.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
//     var4.setRangeWithMargins(var7);
//     boolean var9 = var0.equals((java.lang.Object)var7);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     var16.setRangeWithMargins(var19);
//     var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var16);
//     boolean var22 = var12.isSubplot();
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.data.Range var25 = var0.findRangeBounds(var24);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     java.awt.Paint var37 = var35.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var33, var37);
//     java.awt.Font var39 = null;
//     var38.setLabelFont(var39);
//     java.awt.Shape var41 = var38.getLine();
//     var0.setSeriesShape(10, var41);
//     
//     // Checks the contract:  equals-hashcode on var13 and var36
//     assertTrue("Contract failed: equals-hashcode on var13 and var36", var13.equals(var36) ? var13.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var13
//     assertTrue("Contract failed: equals-hashcode on var36 and var13", var36.equals(var13) ? var36.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var6 = var5.getPlot();
    java.util.List var7 = var5.getSubtitles();
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
    var10.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var13 = var10.getTickLabelInsets();
    double var15 = var13.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
    org.jfree.chart.util.LengthAdjustmentType var23 = null;
    org.jfree.chart.util.LengthAdjustmentType var24 = null;
    java.awt.geom.Rectangle2D var25 = var13.createAdjustedRectangle(var18, var23, var24);
    var9.setPlotArea(var18);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var18, (-1.0d), (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setTextAntiAlias((java.lang.Object)(-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(10, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    double var9 = var2.getMinX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    java.lang.Object var9 = var1.clone();
    var1.setAutoTickUnitSelection(false, true);
    double var13 = var1.getUpperMargin();
    java.lang.String var14 = var1.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot(var4);
    java.awt.Paint var6 = var5.getAggregatedItemsPaint();
    int var7 = var3.compareTo((java.lang.Object)var5);
    java.lang.String var9 = var3.valueToString(100.0d);
    java.lang.String var11 = var3.valueToString((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "100"+ "'", var9.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "-2"+ "'", var11.equals("-2"));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.util.RectangleAnchor var5 = null;
    java.awt.geom.Point2D var6 = org.jfree.chart.util.RectangleAnchor.coordinates(var2, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.entity.PieSectionEntity var13 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var2, var7, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
    int var14 = var13.getSectionIndex();
    var13.setSectionKey((java.lang.Comparable)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
    var11.setRangeWithMargins(var14);
    var7.setDomainAxis((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.data.time.RegularTimePeriod var17 = var11.getFirst();
    var1.add(var17, (java.lang.Number)4, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
    boolean var8 = var1.canSelectByRegion();
    org.jfree.chart.axis.AxisSpace var9 = var1.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     var2.setIgnoreZeroValues(false);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     org.jfree.chart.plot.CrosshairState var7 = new org.jfree.chart.plot.CrosshairState(false);
//     var7.updateCrosshairY(0.05d, 10);
//     boolean var11 = var5.equals((java.lang.Object)0.05d);
//     var2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var5);
//     var2.setShadowYOffset(1.0d);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     java.awt.Paint var28 = var26.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var24, var28);
//     java.awt.Font var30 = null;
//     var29.setLabelFont(var30);
//     boolean var32 = var17.equals((java.lang.Object)var29);
//     java.awt.Paint var33 = var29.getOutlinePaint();
//     var2.setShadowPaint(var33);
//     var1.setNoDataMessagePaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 4.0d, 0.05d, 100.0d);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     var3.clear();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getDataArea();
//     org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var8, "");
//     var3.draw(var5, var8);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    boolean var14 = var0.getAutoPopulateSeriesPaint();
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
    java.awt.Paint var18 = var17.getAggregatedItemsPaint();
    var0.setSeriesItemLabelPaint(5, var18);
    org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var22 = var20.lookupSeriesPaint(0);
    org.jfree.chart.labels.ItemLabelPosition var24 = var20.getSeriesNegativeItemLabelPosition(100);
    var0.setPositiveItemLabelPositionFallback(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    var7.setY(4.0d);
    java.lang.Number var11 = var7.getX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 100.0d+ "'", var11.equals(100.0d));

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
//     org.jfree.chart.event.PlotChangeEvent var5 = null;
//     var4.plotChanged(var5);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     var8.setFixedDimension(14.0d);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var8, var11);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var18 = var17.getPaint();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var23 = var20.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var24 = org.jfree.chart.util.RectangleEdge.opposite(var23);
//     var17.setPosition(var23);
//     org.jfree.chart.util.RectangleInsets var26 = var17.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var27 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var17);
//     org.jfree.chart.util.RectangleEdge var28 = var17.getPosition();
//     double var29 = var1.getCategoryEnd(0, 10, var15, var28);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
//     long var9 = var8.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-15739200001L));
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
    java.awt.Font var24 = null;
    var23.setLabelFont(var24);
    java.awt.Shape var26 = var23.getLine();
    java.awt.Paint var27 = var23.getFillPaint();
    var0.setSeriesPaint(0, var27);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     var1.clearDomainMarkers((-123));
//     var1.setDomainCrosshairLockedOnData(true);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.axis.AxisLocation var17 = var16.getDomainAxisLocation();
//     java.awt.Paint var18 = var16.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var18);
//     java.awt.Paint var20 = var19.getLabelPaint();
//     org.jfree.chart.util.Layer var21 = null;
//     boolean var22 = var1.removeDomainMarker(2147483647, (org.jfree.chart.plot.Marker)var19, var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
//     var0.setDefaultEntityRadius((-1));
//     java.awt.Stroke var11 = null;
//     var0.setSeriesStroke(1, var11);
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var18 = var14.getItemOutlineStroke(0, 0, true);
//     var0.setSeriesStroke(10, var18, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var24 = var23.getTickMarkInsideLength();
//     int var25 = var23.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 0.0d);
//     var27.setRangeWithMargins(var30);
//     var27.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var34 = var27.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var36 = var35.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var38 = new org.jfree.chart.plot.CombinedRangeXYPlot(var37);
//     org.jfree.chart.plot.DrawingSupplier var39 = var38.getDrawingSupplier();
//     var38.setDomainZeroBaselineVisible(false);
//     var35.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var38);
//     var35.setDefaultEntityRadius((-1));
//     java.awt.Stroke var46 = null;
//     var35.setSeriesStroke(1, var46);
//     java.awt.Shape var49 = var35.lookupLegendShape(100);
//     var27.setDownArrow(var49);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var22, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var51);
//     var52.setWeight((-123));
//     var52.clearDomainAxes();
//     java.awt.Paint var56 = var52.getRangeGridlinePaint();
//     var0.setSeriesItemLabelPaint(0, var56, false);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var0.", var35.equals(var0) == var0.equals(var35));
//     
//     // Checks the contract:  equals-hashcode on var3 and var38
//     assertTrue("Contract failed: equals-hashcode on var3 and var38", var3.equals(var38) ? var3.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var3
//     assertTrue("Contract failed: equals-hashcode on var38 and var3", var38.equals(var3) ? var38.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var39
//     assertTrue("Contract failed: equals-hashcode on var4 and var39", var4.equals(var39) ? var4.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var4
//     assertTrue("Contract failed: equals-hashcode on var39 and var4", var39.equals(var4) ? var39.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    int var5 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var7 = var2.getDataItem(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    var30.setNotify(true);
    java.lang.Comparable var36 = var30.getDomainCrosshairRowKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    double var2 = var1.getDomainCrosshairValue();
    boolean var3 = var1.isSubplot();
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection();
    var4.removeAllSeries();
    var1.setDataset((org.jfree.data.xy.XYDataset)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     var30.clearDomainAxes();
//     boolean var34 = var30.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var35 = var30.getRangeAxisLocation();
//     var30.clearDomainAxes();
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var39 = new org.jfree.chart.plot.CombinedRangeXYPlot(var38);
//     org.jfree.chart.plot.DrawingSupplier var40 = var39.getDrawingSupplier();
//     var39.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.axis.AxisLocation var46 = var45.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var47 = org.jfree.chart.axis.AxisLocation.getOpposite(var46);
//     var39.setRangeAxisLocation(0, var47, true);
//     var30.setRangeAxisLocation(5, var47);
//     
//     // Checks the contract:  equals-hashcode on var16 and var45
//     assertTrue("Contract failed: equals-hashcode on var16 and var45", var16.equals(var45) ? var16.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var16
//     assertTrue("Contract failed: equals-hashcode on var45 and var16", var45.equals(var16) ? var45.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var40
//     assertTrue("Contract failed: equals-hashcode on var17 and var40", var17.equals(var40) ? var17.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var17
//     assertTrue("Contract failed: equals-hashcode on var40 and var17", var40.equals(var17) ? var40.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var4.setDomainDescription("");
    var4.clear();
    java.util.List var8 = var4.getItems();
    int var9 = var2.compareTo((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX((-2.0d));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    var4.setNegativeArrowVisible(false);
    var4.setLabelURL("hi!");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var4};
    var1.setRangeAxes(var13);
    var1.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(-1L));
    var2.add((java.lang.Number)1L, (java.lang.Number)0, false);
    org.jfree.data.xy.XYDataItem var11 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    var2.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var5 = var2.getTickLabelInsets();
    double var7 = var5.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var10, "");
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var10, "");
    org.jfree.chart.util.LengthAdjustmentType var15 = null;
    org.jfree.chart.util.LengthAdjustmentType var16 = null;
    java.awt.geom.Rectangle2D var17 = var5.createAdjustedRectangle(var10, var15, var16);
    var1.setPlotArea(var10);
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var10, (-1.0d), (-1.0d));
    org.jfree.chart.util.RectangleAnchor var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var10, var22, 14.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.lang.Comparable var34 = null;
    var31.setDomainCrosshairColumnKey(var34);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var38 = var37.clone();
    var31.setFixedRangeAxisSpace(var37);
    org.jfree.data.general.SeriesChangeEvent var40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var31);
    org.jfree.data.general.SeriesChangeInfo var41 = null;
    var40.setSummary(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    var2.add(2.88E7d, (java.lang.Number)(short)(-1), false);
    boolean var9 = var2.getAutoSort();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var4 = var3.getTickMarkInsideLength();
//     int var5 = var3.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
//     var7.setRangeWithMargins(var10);
//     var7.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var14 = var7.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var16 = var15.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
//     org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
//     var18.setDomainZeroBaselineVisible(false);
//     var15.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
//     var15.setDefaultEntityRadius((-1));
//     java.awt.Stroke var26 = null;
//     var15.setSeriesStroke(1, var26);
//     java.awt.Shape var29 = var15.lookupLegendShape(100);
//     var7.setDownArrow(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var2, (org.jfree.chart.axis.CategoryAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var31);
//     var32.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     java.awt.geom.Rectangle2D var38 = var37.getDataArea();
//     java.awt.geom.Point2D var39 = null;
//     var32.panDomainAxes(100.0d, var37, var39);
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var42 = var41.getTickMarkInsideLength();
//     boolean var43 = var41.isTickLabelsVisible();
//     int var44 = var32.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var41);
//     var32.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     var47.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var50 = var47.getTickLabelInsets();
//     var32.setAxisOffset(var50);
//     org.jfree.chart.event.RendererChangeEvent var52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var32);
//     var1.rendererChanged(var52);
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.ChartRenderingInfo var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = new org.jfree.chart.plot.PlotRenderingInfo(var57);
//     java.awt.geom.Rectangle2D var59 = var58.getDataArea();
//     org.jfree.chart.entity.ChartEntity var61 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var59, "");
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 2.88E7d, var59);
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var64 = new org.jfree.chart.plot.CombinedRangeXYPlot(var63);
//     org.jfree.chart.event.PlotChangeEvent var65 = null;
//     var64.plotChanged(var65);
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var68 = new org.jfree.chart.plot.CombinedRangeXYPlot(var67);
//     org.jfree.chart.plot.DrawingSupplier var69 = var68.getDrawingSupplier();
//     java.awt.Paint var70 = var68.getRangeZeroBaselinePaint();
//     var64.setRangeGridlinePaint(var70);
//     org.jfree.chart.ChartRenderingInfo var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = new org.jfree.chart.plot.PlotRenderingInfo(var72);
//     java.awt.geom.Rectangle2D var74 = var73.getDataArea();
//     org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var74, "");
//     org.jfree.chart.util.RectangleAnchor var77 = null;
//     java.awt.geom.Point2D var78 = org.jfree.chart.util.RectangleAnchor.coordinates(var74, var77);
//     var64.setQuadrantOrigin(var78);
//     org.jfree.chart.plot.PlotState var80 = null;
//     org.jfree.chart.ChartRenderingInfo var81 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var82 = new org.jfree.chart.plot.PlotRenderingInfo(var81);
//     java.awt.geom.Rectangle2D var83 = var82.getDataArea();
//     java.awt.geom.Rectangle2D var84 = var82.getPlotArea();
//     var1.draw(var54, var59, var78, var80, var82);
//     
//     // Checks the contract:  equals-hashcode on var18 and var68
//     assertTrue("Contract failed: equals-hashcode on var18 and var68", var18.equals(var68) ? var18.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var18
//     assertTrue("Contract failed: equals-hashcode on var68 and var18", var68.equals(var18) ? var68.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var69
//     assertTrue("Contract failed: equals-hashcode on var19 and var69", var19.equals(var69) ? var19.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var19
//     assertTrue("Contract failed: equals-hashcode on var69 and var19", var69.equals(var19) ? var69.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var58
//     assertTrue("Contract failed: equals-hashcode on var37 and var58", var37.equals(var58) ? var37.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var73
//     assertTrue("Contract failed: equals-hashcode on var37 and var73", var37.equals(var73) ? var37.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var82
//     assertTrue("Contract failed: equals-hashcode on var37 and var82", var37.equals(var82) ? var37.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var37
//     assertTrue("Contract failed: equals-hashcode on var58 and var37", var58.equals(var37) ? var58.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var73
//     assertTrue("Contract failed: equals-hashcode on var58 and var73", var58.equals(var73) ? var58.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var82
//     assertTrue("Contract failed: equals-hashcode on var58 and var82", var58.equals(var82) ? var58.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var37
//     assertTrue("Contract failed: equals-hashcode on var73 and var37", var73.equals(var37) ? var73.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var58
//     assertTrue("Contract failed: equals-hashcode on var73 and var58", var73.equals(var58) ? var73.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var82
//     assertTrue("Contract failed: equals-hashcode on var73 and var82", var73.equals(var82) ? var73.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var37
//     assertTrue("Contract failed: equals-hashcode on var82 and var37", var82.equals(var37) ? var82.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var58
//     assertTrue("Contract failed: equals-hashcode on var82 and var58", var82.equals(var58) ? var82.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var73
//     assertTrue("Contract failed: equals-hashcode on var82 and var73", var82.equals(var73) ? var82.hashCode() == var73.hashCode() : true);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ThreadContext", var1);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.KeyedValues var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var4 = null;
//     org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var5.calculateDimensions(var6);
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     var12.setLowerMargin((-1.0d));
//     var12.setAxisLineVisible(false);
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
//     java.awt.Paint var27 = var25.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var23, var27);
//     java.awt.Font var29 = null;
//     var28.setLabelFont(var29);
//     java.awt.Shape var31 = var28.getLine();
//     java.awt.Paint var32 = var28.getFillPaint();
//     var12.setAxisLinePaint(var32);
//     org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(0.05d, 1.0d, 2.88E7d, 0.0d, var32);
//     boolean var35 = var7.equals((java.lang.Object)0.0d);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var38 = var37.getTickMarkInsideLength();
//     int var39 = var37.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var41 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var42 = null;
//     org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 0.0d);
//     var41.setRangeWithMargins(var44);
//     var41.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var48 = var41.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var50 = var49.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var52 = new org.jfree.chart.plot.CombinedRangeXYPlot(var51);
//     org.jfree.chart.plot.DrawingSupplier var53 = var52.getDrawingSupplier();
//     var52.setDomainZeroBaselineVisible(false);
//     var49.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var52);
//     var49.setDefaultEntityRadius((-1));
//     java.awt.Stroke var60 = null;
//     var49.setSeriesStroke(1, var60);
//     java.awt.Shape var63 = var49.lookupLegendShape(100);
//     var41.setDownArrow(var63);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var36, (org.jfree.chart.axis.CategoryAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, var65);
//     boolean var67 = var7.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var25 and var52
//     assertTrue("Contract failed: equals-hashcode on var25 and var52", var25.equals(var52) ? var25.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var25
//     assertTrue("Contract failed: equals-hashcode on var52 and var25", var52.equals(var25) ? var52.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var53
//     assertTrue("Contract failed: equals-hashcode on var26 and var53", var26.equals(var53) ? var26.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var26
//     assertTrue("Contract failed: equals-hashcode on var53 and var26", var53.equals(var26) ? var53.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    java.awt.Paint var6 = var1.getRangeTickBandPaint();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.RenderingSource var10 = null;
    var1.select(0.0d, 0.0d, var9, var10);
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.axis.AxisLocation var17 = var16.getDomainAxisLocation();
    java.awt.Paint var18 = var16.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var18);
    java.awt.Paint var20 = var19.getLabelPaint();
    org.jfree.chart.util.Layer var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker((-123), (org.jfree.chart.plot.Marker)var19, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.util.List var34 = var31.getCategories();
//     var31.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var37 = var0.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.axis.ValueAxis var38 = var31.getRangeAxis();
//     org.jfree.chart.renderer.xy.XYBarRenderer var39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var41 = null;
//     var39.setSeriesItemLabelGenerator(100, var41);
//     java.awt.Paint var43 = var39.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     java.awt.geom.Rectangle2D var46 = var45.getDataArea();
//     var39.setBaseLegendShape((java.awt.Shape)var46);
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var50 = var49.getPaint();
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var52 = new org.jfree.chart.plot.CombinedRangeXYPlot(var51);
//     org.jfree.chart.plot.DrawingSupplier var53 = var52.getDrawingSupplier();
//     java.awt.Paint var54 = var52.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var55 = var52.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var56 = org.jfree.chart.util.RectangleEdge.opposite(var55);
//     var49.setPosition(var55);
//     org.jfree.chart.util.RectangleInsets var58 = var49.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var59 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var49);
//     org.jfree.chart.entity.TitleEntity var62 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var46, (org.jfree.chart.title.Title)var49, "ThreadContext", "SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.entity.AxisLabelEntity var65 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var38, (java.awt.Shape)var46, "{0}: ({1}, {2})", "index.html?series=10&amp;item=-1");
//     
//     // Checks the contract:  equals-hashcode on var17 and var52
//     assertTrue("Contract failed: equals-hashcode on var17 and var52", var17.equals(var52) ? var17.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var17
//     assertTrue("Contract failed: equals-hashcode on var52 and var17", var52.equals(var17) ? var52.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var53
//     assertTrue("Contract failed: equals-hashcode on var18 and var53", var18.equals(var53) ? var18.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var18
//     assertTrue("Contract failed: equals-hashcode on var53 and var18", var53.equals(var18) ? var53.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 5, 0);
    long var4 = var3.getSegmentsGroupSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 500L);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var6 = var5.getPlot();
    java.util.List var7 = var5.getSubtitles();
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    var5.handleClick(1, 0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { "Combined Range XYPlot"};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 2147483647};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    int var39 = var35.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     boolean var8 = var1.canSelectByRegion();
//     org.jfree.chart.plot.PlotOrientation var9 = var1.getOrientation();
//     org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var13 = var12.getTickMarkInsideLength();
//     int var14 = var12.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     var16.setRangeWithMargins(var19);
//     var16.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var23 = var16.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var25 = var24.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var27 = new org.jfree.chart.plot.CombinedRangeXYPlot(var26);
//     org.jfree.chart.plot.DrawingSupplier var28 = var27.getDrawingSupplier();
//     var27.setDomainZeroBaselineVisible(false);
//     var24.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var27);
//     var24.setDefaultEntityRadius((-1));
//     java.awt.Stroke var35 = null;
//     var24.setSeriesStroke(1, var35);
//     java.awt.Shape var38 = var24.lookupLegendShape(100);
//     var16.setDownArrow(var38);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var11, (org.jfree.chart.axis.CategoryAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var40);
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
//     var42.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var45 = var42.getTickLabelInsets();
//     var41.setAxisOffset(var45);
//     var10.setInsets(var45, false);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.plot.MultiplePiePlot var50 = new org.jfree.chart.plot.MultiplePiePlot(var49);
//     java.awt.Paint var51 = var50.getAggregatedItemsPaint();
//     var10.setBackgroundPaint(var51);
//     boolean var53 = var9.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var27
//     assertTrue("Contract failed: equals-hashcode on var1 and var27", var1.equals(var27) ? var1.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var1
//     assertTrue("Contract failed: equals-hashcode on var27 and var1", var27.equals(var1) ? var27.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var28
//     assertTrue("Contract failed: equals-hashcode on var2 and var28", var2.equals(var28) ? var2.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var2
//     assertTrue("Contract failed: equals-hashcode on var28 and var2", var28.equals(var2) ? var28.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    float var15 = var14.getTickMarkInsideLength();
    int var16 = var14.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
    var18.setRangeWithMargins(var21);
    var18.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var25 = var18.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var27 = var26.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot(var28);
    org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
    var29.setDomainZeroBaselineVisible(false);
    var26.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var29);
    var26.setDefaultEntityRadius((-1));
    java.awt.Stroke var37 = null;
    var26.setSeriesStroke(1, var37);
    java.awt.Shape var40 = var26.lookupLegendShape(100);
    var18.setDownArrow(var40);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var42);
    var43.setWeight((-123));
    java.util.List var46 = var43.getCategories();
    var43.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var49 = var12.hasListener((java.util.EventListener)var43);
    boolean var50 = var11.equals((java.lang.Object)var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var51 = var5.createBufferedImage(0, 5, 2147483647, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var5 = var4.getTickMarkInsideLength();
//     int var6 = var4.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
//     var8.setRangeWithMargins(var11);
//     var8.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var15 = var8.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var17 = var16.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     var19.setDomainZeroBaselineVisible(false);
//     var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var19);
//     var16.setDefaultEntityRadius((-1));
//     java.awt.Stroke var27 = null;
//     var16.setSeriesStroke(1, var27);
//     java.awt.Shape var30 = var16.lookupLegendShape(100);
//     var8.setDownArrow(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var3, (org.jfree.chart.axis.CategoryAxis)var4, (org.jfree.chart.axis.ValueAxis)var8, var32);
//     var33.setWeight((-123));
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     java.awt.geom.Rectangle2D var39 = var38.getDataArea();
//     java.awt.geom.Point2D var40 = null;
//     var33.panDomainAxes(100.0d, var38, var40);
//     java.awt.Stroke var42 = var33.getRangeMinorGridlineStroke();
//     var1.setRangeCrosshairStroke(var42);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var2.setFixedRangeAxisSpace(var3);
//     org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
//     var2.setFixedLegendItems(var5);
//     var0.add((org.jfree.chart.plot.XYPlot)var2);
//     java.util.List var8 = var0.getSubplots();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var11.configure();
//     org.jfree.chart.ChartRenderingInfo var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getDataArea();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
//     org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
//     java.awt.Paint var20 = var18.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var21 = var18.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.util.RectangleEdge.opposite(var21);
//     boolean var24 = var21.equals((java.lang.Object)true);
//     double var25 = var11.valueToJava2D(0.05d, var16, var21);
//     var0.drawOutline(var9, var16);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.util.List var34 = var31.getCategories();
//     var31.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var37 = var0.hasListener((java.util.EventListener)var31);
//     int var38 = var31.getWeight();
//     org.jfree.chart.axis.AxisSpace var39 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var42 = new org.jfree.chart.plot.CombinedRangeXYPlot(var41);
//     org.jfree.chart.plot.DrawingSupplier var43 = var42.getDrawingSupplier();
//     java.awt.Paint var44 = var42.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var45 = var42.getDomainAxisEdge();
//     var39.ensureAtLeast(100.0d, var45);
//     var31.setFixedRangeAxisSpace(var39);
//     
//     // Checks the contract:  equals-hashcode on var17 and var42
//     assertTrue("Contract failed: equals-hashcode on var17 and var42", var17.equals(var42) ? var17.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var17
//     assertTrue("Contract failed: equals-hashcode on var42 and var17", var42.equals(var17) ? var42.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var43
//     assertTrue("Contract failed: equals-hashcode on var18 and var43", var18.equals(var43) ? var18.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var18
//     assertTrue("Contract failed: equals-hashcode on var43 and var18", var43.equals(var18) ? var43.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    boolean var3 = var1.isMinorTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
//     var0.setSeriesItemLabelPaint(1, var15, false);
//     java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
//     org.jfree.chart.labels.XYItemLabelGenerator var24 = var0.getItemLabelGenerator(0, 0, true);
//     org.jfree.chart.urls.StandardXYURLGenerator var26 = new org.jfree.chart.urls.StandardXYURLGenerator();
//     org.jfree.data.xy.XYDataset var27 = null;
//     java.lang.String var30 = var26.generateURL(var27, 10, (-1));
//     org.jfree.chart.axis.PeriodAxis var32 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var33 = null;
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 0.0d);
//     var32.setRangeWithMargins(var35);
//     var32.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var39 = var32.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var41 = var40.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
//     var43.setDomainZeroBaselineVisible(false);
//     var40.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var43);
//     var40.setDefaultEntityRadius((-1));
//     java.awt.Stroke var51 = null;
//     var40.setSeriesStroke(1, var51);
//     java.awt.Shape var54 = var40.lookupLegendShape(100);
//     var32.setDownArrow(var54);
//     boolean var56 = var26.equals((java.lang.Object)var32);
//     org.jfree.data.time.TimeSeriesCollection var57 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.time.TimeSeriesCollection var58 = new org.jfree.data.time.TimeSeriesCollection();
//     var57.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var58);
//     java.lang.String var62 = var26.generateURL((org.jfree.data.xy.XYDataset)var58, 0, 2147483647);
//     var0.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var26, false);
//     
//     // Checks the contract:  equals-hashcode on var13 and var43
//     assertTrue("Contract failed: equals-hashcode on var13 and var43", var13.equals(var43) ? var13.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var13
//     assertTrue("Contract failed: equals-hashcode on var43 and var13", var43.equals(var13) ? var43.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var44
//     assertTrue("Contract failed: equals-hashcode on var14 and var44", var14.equals(var44) ? var14.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var14
//     assertTrue("Contract failed: equals-hashcode on var44 and var14", var44.equals(var14) ? var44.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setRangeZeroBaselineVisible(false);
    var30.configureRangeAxes();
    org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var37 = null;
    org.jfree.data.Range var39 = org.jfree.data.Range.expandToInclude(var37, 0.0d);
    var36.setRangeWithMargins(var39);
    var36.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var43 = var36.getPlot();
    java.awt.Shape var44 = var36.getUpArrow();
    var30.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var36, true);
    var36.setMinorTickMarksVisible(true);
    java.awt.Paint var49 = var36.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

}
